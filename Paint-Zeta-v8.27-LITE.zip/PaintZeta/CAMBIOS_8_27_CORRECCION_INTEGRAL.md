# Paint Zeta v8.27 — Corrección integral (balde, brocha, capas, Marioneta, Borrar fondo, rendimiento, ZIP ligero)

Versión 8.27 (versionCode 65). Base: el ZIP v8.26 «Colorear manga» (incluye Marioneta de v8.25). Sin IA, sin librerías nuevas, sin OpenGL.

Cómo leer este documento:
- **CONFIRMADO** = lo reproduje con el código real de la app (el mismo `CanvasView`) y con tus imágenes de `tests/assets`, y hay un número que lo prueba.
- **HIPÓTESIS** = probable, pero no lo pude reproducir exactamente (por ejemplo, porque no llegaron las 5 capturas).
- Todas las pruebas usan el `CanvasView` real dentro de un Android **simulado** en un servidor. **No es un teléfono.** No afirmo FPS ni ausencia de tirones en ningún teléfono.
- De las 5 capturas solo llegó la imagen del manga (es `tests/assets/manga_chaqueta.png`). Trabajé con tu descripción de cada captura.

---

## 1. Qué cambia para ti

- **El balde ya no crea «Color_1» por su cuenta.** De fábrica pinta exactamente en la capa que elegiste (por ejemplo, tu capa_1). En la barra del balde se ve el destino: «→ capa_1 · Normal». Si tocas ese texto se abre el panel del balde con:
  - **Pintar en capa actual** (de fábrica).
  - **Capa de color automática:** una sola capa «Color», creada la primera vez y reutilizada siempre. Tu capa elegida no cambia.
  - **Por líneas (manga blanco y negro):** la trama y los grises no cortan la zona.
  - **Vista previa** con ✓ (pintar) y ✕ (cancelar).
  - La elección se guarda al cerrar la app.
- **Colorear manga** sigue igual: Tinta B/N bloqueada y una sola Color base en Multiplicar.
- **Brocha:**
  - El pincel de fábrica es **«Color plano (tinta de cómic)»**: borde duro con un antialias de 1 píxel, opaco y parejo, sin nubecitas.
  - **«Brocha suave (difuminada)»** es un pincel aparte, solo si la eliges.
  - La dureza ahora **se guarda**. Antes, al volver a abrir la app, quedaba en 70 % y el borde salía borroso.
- **«Proteger contornos negros»** (antes «No pasar la línea»):
  - Pinta solo la zona donde empiezas y no tapa la tinta.
  - Ya no deja manchitas blancas en la trama.
  - Ya no toma tu color anterior como si fuera una línea.
  - La brocha también muestra «→ capa · modo · Límites».
- **Borrar fondo:**
  - El filo gris o blanco junto al contorno se limpia al borrar.
  - Botón nuevo **Refinar borde** (en la barra de Borrar fondo) para PNG ya recortados con halo:
    - Vista previa en el lienzo; Aceptar o Cancelar.
    - Controles: quitar el color del fondo, contraer o expandir con fracciones de píxel, suavizar solo el borde, quitar restos sueltos y «no comerse las líneas oscuras».
    - Para revisar puedes cambiar el fondo de la vista: cuadros, blanco, negro, **gris** (nuevo) o verde.
- **Marioneta:**
  - La malla **no se dibuja** de fábrica. «Ver malla» la muestra solo sobre el dibujo; el motor la usa igual.
  - La malla se arma solo sobre el dibujo útil. Con tu PNG de prueba pasa de 1331 a 422 puntos y de 188 pedacitos sueltos a 1.
  - Si al aplicar el dibujo sale del lienzo, la app pregunta antes de aplicar (con el lienzo nuevo dibujado en azul):
    - **Ampliar lienzo y aplicar:** agrega justo lo que falta. Se puede deshacer, y «Ampliar lienzo» del menú ya no borra el historial.
    - **Mover dentro del lienzo** (si cabe).
    - **Aplicar recortando.**
    - **Seguir editando.**
  - Si la capa no tiene fondo transparente, avisa que se deformará toda la escena y cómo recortar antes.
- **Capas:** «Imagen color» salió de la barra principal. Ahora está en Capas > Más > «Referencia de color: tomar muestras (no crea capa)».
- **Menú > «Medir rendimiento (prueba en este teléfono)»:**
  - Muestra los tiempos reales de lo que hiciste desde que abriste la app.
  - Corre una prueba automática con obras de prueba: rápida (720p y 1080p) o completa (hasta 4K y A4).
  - Tu obra se guarda antes y no se toca.
  - El informe se puede copiar.

---

## 2. Causas: confirmadas e hipótesis

### I. Brocha sobre capa_1 (capturas 1-2)
- **CONFIRMADO — la dureza volvía a 70 % al abrir la app.** El pincel guardado no guardaba la dureza. Con radio 20, el alfa del borde medido fue `255 … 221 178 136 93 51 8 0`: una rampa de 6 px, que es el «brochazo borroso».
  - Con «Color plano» ahora mide `255 … 255 180 0`: un antialias de ~1 px.
- **CONFIRMADO — «No pasar la línea» buscaba líneas con el detector general en TODO el dibujo.** Los puntitos de la trama de la chaqueta contaban como línea, y quedaba un moteado rojo y blanco. Está en las imágenes de reproducción.
- **CONFIRMADO — la referencia de líneas incluía la propia capa donde se pinta.** Un rojo (brillo 89, menor que el umbral 110) contaba como línea y cortaba el siguiente brochazo.
- **CONFIRMADO — la mezcla con la línea se hacía en cualquier píxel cuyo papel no fuera igual al de la zona (la trama).** Eso ensuciaba el color con puntos oscuros.
- **CONFIRMADO — el primer trazo con protección calculaba las líneas de toda la imagen en el hilo de la pantalla.** Medido en servidor: máximo 114-277 ms por evento en v8.26.
- **CONFIRMADO — `cov` (byte[w×h]) se llenaba entero en cada trazo:** 8 MB por toque en 4K. Además, `stampPaint` recalculaba píxeles ya cubiertos al 100 %. Es un costo medible, no un diagnóstico de FPS.

### II. Balde y Color_1 (capturas 3-4)
- **CONFIRMADO — Color_1 nacía solo.** Con «capa aparte» prendido de fábrica, `runBucket` reconocía la capa de color por el NOMBRE («Color»/«Color_N») y solo si estaba JUSTO encima. Con capa_1 elegida creaba Color_1 y **además la dejaba elegida**.
  - Reproducido: tras 30 toques alternando brocha y balde, las capas quedaban «imagen | capa_1 | Color_1» con activa = Color_1.
- **CONFIRMADO — un balde por COLOR no puede cruzar la trama de la chaqueta.** Pinta 94 px y deja la zona llena de manchas. «Por líneas» pinta 46 049 px en la misma zona.
- **HIPÓTESIS — los «contornos pálidos alrededor de letras».** Con papel blanco y letras negras, el motor del balde ya daba 0 px sin pintar junto a la letra (T05). Lo más probable es que vinieran de pintar en una Color_1 en modo Normal encima de un dibujo con trama o JPEG. Sin la captura no lo pude reproducir píxel a píxel.

### III. Marioneta (video de 39 s)
- **CONFIRMADO — la malla se dibujaba siempre** (`puppetShowMesh = true`).
- **CONFIRMADO — 22 293 píxeles casi invisibles (alfa 1-7, restos del recorte)** formaban 188 pedacitos de malla (550 de 1212 triángulos) por toda la imagen. No se veían, pero llenaban el resolvedor y los cálculos.
- **CONFIRMADO — la vista previa pintaba siempre ~701 100 px por movimiento, sin importar el zoom.** Acercado ×3 eso daba 0,67 px de vista previa por px del lienzo (borroso). En la imagen grande, 0,28. Además se creaba un Bitmap nuevo por cada vista previa.
- **CONFIRMADO — los cuadros verdes son el fondo de VISTA** (`VIEW_BG[4]`), no píxeles del PNG. No se exportan. Ahora hay también gris neutro.
- La tasa de FPS no se puede calcular desde la descripción del video, ni se afirma aquí.

### IV. Borrar fondo: halo (captura 5)
- **CONFIRMADO con un píxel concreto del manga real (871, 1005).** Un gris 167 entre el contorno negro y el fondo blanco quedaba OPACO.
  - La línea negra (3 px) caía dentro de la franja «cerca del fondo», así que no contaba como «color sólido del personaje».
  - Entonces se tomaba el gris de la trama de la chaqueta (151) o un gris de la paleta, que «explicaban» al píxel como color propio.
  - Sobre verde o negro eso se ve como un borde gris claro irregular.
- **CONFIRMADO — no es efecto de la vista.** La pantalla compone píxel por píxel sobre opaco. El PNG exportado tiene el mismo alfa que la capa (diferencia 0 px).

---

## 3. Qué se cambió

### Capas y balde
- Nuevo papel de capa **`ROLE_COLOR`**: la capa de color automática se reconoce por su papel, no por el nombre ni por la posición. Se guarda en la obra.
  - Una obra vieja (v8.24-8.26) con «Color_1» la adopta una sola vez, en vez de crear otra.
- Destino:
  - `FILL_TARGET_CURRENT` (de fábrica): exactamente la capa elegida.
  - `FILL_TARGET_AUTO`: una sola capa «Color», creada encima de la elegida sin cambiar la elegida.
  - La preferencia nueva `fill_target_v827` no hereda el «capa aparte» viejo.
- Si la capa destino está en **Multiplicar**, el color va plano y puede entrar bajo la línea, sin oscurecer dos veces.
- Si es **Normal**, el filo copia el antialias de la tinta.
- La referencia de límites en modo automático excluye la capa de color. Así, rellenar otra vez la misma zona cambia el color de verdad.
- **Por líneas:** zona con el mapa de tinta del modo manga (la trama no corta) más el filo antialias del balde normal.
- **Vista previa** del balde normal con la misma máscara exacta que se pinta, Aceptar/Cancelar y un solo Deshacer.
- Aviso único si «Pintar en capa actual» apunta a tu única capa (la imagen).

### Brocha
- Presets: 0 = Color plano (dureza 1,0); 1 = Brocha suave (0,35); 2 = el «Pincel de color» viejo (0,85). Se migra el índice guardado.
- La dureza se guarda (`brush_hardness_v827`). Dureza inicial de fábrica: 1,0.
- **Proteger contornos:**
  - La tinta se calcula **por bloques de 64×64** (con 8 px de margen) solo donde pasa el pincel.
  - La referencia es la Tinta B/N si existe; si no, las capas visibles que no son de color, con la capa del trazo tal como estaba antes del trazo.
  - **Tinta = oscuro Y poco saturado**, o muy oscuro. Un color vivo nunca es tinta.
  - Los puntos de trama no son tinta (mismo mapa que el balde manga).
  - La mezcla con la tinta solo ocurre a 2 px o menos de una línea de verdad, y solo en capas que tapan.
- `cov` se limpia solo en la zona que tocó el trazo anterior. Los píxeles ya cubiertos al 100 % no se recalculan.

### Borrar fondo
- `refineEdges`: primero busca **tinta oscura más adentro** del píxel. Si el píxel es mezcla de esa tinta con el fondo, es filo: baja su alfa y toma la tinta. Nunca toca algo que está **detrás** del contorno.
- **Refinar borde** (`core/EdgeRefine`), con 2 pasadas de descontaminación:
  - El filo se mira como se veía sobre el fondo original.
  - Mechones de 1-2 px: tinta pegada a la misma distancia.
  - «Color a alfa» solo en filos finos pegados a lo transparente con el contorno justo detrás. Los huecos de papel sin borrar y las camisas blancas no se tocan.
  - Contraer/expandir subpíxel (con «no comerse líneas oscuras»), suavizado solo en el borde y restos sueltos.
  - Vista previa en otro hilo sobre una copia. Cancelar deja la capa exacta.

### Marioneta
- La malla usa alfa útil (≥ 8 = 3 %); se puede volver a 1 en Opciones.
- «Ver malla» está apagado de fábrica y guardado. Solo dibuja triángulos con dibujo dentro. Los pliegues en rojo se ven siempre.
- Vista previa:
  - Solo lo visible (+25 %), a la resolución de pantalla (tope 0,7 M px al arrastrar y 3 M al soltar).
  - Bitmaps reutilizables: el que se muestra nunca se toca ni se recicla; el anterior vuelve a la reserva 100 ms después.
  - Se repinta al terminar el zoom.
- **Ampliar lienzo y aplicar** y **Mover dentro** (traslación pura, que ARAP no deforma).
- `UndoManager` tiene un tipo nuevo, **GEOM**: Ampliar lienzo se deshace recortando y se rehace agrandando, y el historial anterior se conserva.

### Rendimiento
- **`core/PerfStats`**: p50, p95, p99, máximo y cuántos eventos pasan de 16,7 / 33 / 700 ms.
- Se mide: dibujo de pantalla, evento táctil, pincel por evento, inicio de trazo, balde, recomposición, Marioneta (vista previa y resolvedor), Borrar fondo y Refinar borde.
- **`view/PerfBench`**: la prueba automática que trae el APK.

### Interfaz
- Chip de destino «→ capa · modo» en la barra de la brocha y del balde, y el panel del balde.
- Botón Refinar borde, fondo gris de vista, diálogo «Fuera del lienzo», ítem «Medir rendimiento».
- «Imagen color» movido a Capas > Más.

---

## 4. Pruebas T01-T15 (resultados reales)

Salida completa: `docs/RESULTADOS_PRUEBAS_8_27.txt`. Imágenes: `docs/qa827/`.

| | Prueba | Resultado medido |
|---|---|---|
| T01 | Brocha dura sobre capa_1 (manga real; zoom 100/400/800 %) | Huecos dentro del trazo: **0** en los tres zooms. Borde semitransparente **0,91-0,98 px**. Original tocado 0. Capas: imagen, capa_1. Deshacer deja la capa vacía. Sobre blanco y sobre transparencia: 0 sin cubrir. Con Proteger contornos: tinta tapada **0** de 523 px centrales; agujeros sin color **0**. |
| T02 | Brocha suave | Rampa pareja `255 255 255 255 227 188 149 110 71 32 0`. Diferencia entre 5 tramos del trazo: **0** niveles. Manchas: **0**. |
| T03 | 30 toques alternando brocha y balde en capa_1 | Pintar en capa actual: capas «imagen \| capa_1», activa capa_1, original 0 px. Automática: «imagen \| capa_1 \| Color», **una** capa de color, activa capa_1, original 0 px. |
| T04 | Modo manga | Una Color base en Multiplicar. Tinta bloqueada, **0** px cambiados. Pantalla = imagen completa = PNG exportado (**0** distintos). |
| T05 | Papel blanco con letras negras | PNG: papel sin pintar a 3 px de la letra **0** de 10 278. Fuga a contraformas **0**. Brillo de la tinta 0,0 → 0,0. Artefactos de color 0. JPEG 70: igual, tinta 1,4 → 1,3. |
| T06 | Trama densa y JPG 50 | Por color: 94 px (la trama corta la zona). Por líneas: 46 049 px, con 163 puntitos grises sueltos dentro, **y una franja del lado derecho del panel, donde la trama es más tupida, queda sin pintar** (se ve en `docs/qa827/T06_trama_por_color_vs_por_lineas.png`). JPEG: 447 y 45 618 px. Vista previa: Cancelar = 0 cambios; Aceptar = una sola capa «Color» y la activa no cambia. **Límite:** la trama tupida que forma red cuenta como línea; para eso, Lazo + Rellenar selección. |
| T07 | Piel, ojos, pelo y ropa | Manga real en modo manga: cara+cuello 127 175 px (una zona: están unidos), iris 939 px, cuello de camisa 11 954, mano 117 734, mechón 1287. PNG a color: chaqueta 283 px en capa_1, original 0. Imagen: `docs/qa827/t07_manga_piel_ojos_pelo_ropa.png`. |
| T08 | Borrar fondo: halo | Sintético: PNG con halo **300 → 0** con Refinar borde; Borrar fondo v8.27: **0**. Manga real: PNG con halo **1736 → 30** con Refinar borde (−98 %); Borrar fondo v8.27: **1**. Tinta con menos de la mitad de alfa: **0**. Alfa del PNG exportado = capa. Blanco puro en franja fina: sintético **0**; manga 7-21 (casi todo en huecos de papel entre mechones que el balde no borró). |
| T09 | Malla de Marioneta | «Ver malla» apagado de fábrica. 422 vértices, 674 triángulos, **1** pieza (v8.26: 1331 / 1212 / 188). Triángulos a más de una celda del dibujo: **0**. Aplicar sin mover: **0** píxeles visibles distintos. |
| T10 | Pies fijos, fuera del lienzo | Puntos fijos movidos **0,00 px**. Sale 97 px por arriba. Ampliar lienzo y aplicar: 1024×1536 → 1024×1633, alfa útil 99,19 %, nada toca el borde nuevo, pies **0** píxeles visibles distintos. Deshacer ×2 = original exacto. Rehacer ×2 = resultado exacto. Cancelar = 0. Mover dentro: sale 118 px → todo dentro. |
| T11 | Dos dedos | Brocha, Goma, Balde, Borrar fondo, Difuminar, Borrosidad, Especial, Lazo y Marioneta: **0** cambios, 0 selecciones, 0 puntos movidos. |
| T12 | Rendimiento antes/después | Ver §5. |
| T13 | Guardar/abrir y compatibilidad | Papel de la capa conservado, capas idénticas 3 de 3. Una obra guardada por v8.26 (imagen \| capa_1 \| Color_1) abre y el balde automático **reutiliza Color_1**. Imagen exportada = pantalla (0 distintos). |
| T14 | ZIP LITE para Actions | Ver §6: contiene `.github/workflows/build.yml`, `settings.gradle`, `build.gradle`, `gradle.properties` y `app/` completo. El código de la app compila sin errores sin SDK (612 clases). |
| T15 | Regresión 8.22-8.26 | Toda la batería anterior: **OK**. Especial, Herramientas, Brocha, Balde, Marioneta (motor y simulado), Colorear manga y fuentes. `EXIT 0`. |

Cosas que no son perfectas, dicho claro:
- **T06:** el balde por color no sirve en zonas con trama (es su naturaleza). «Por líneas» llena casi todo el panel, pero donde la trama se vuelve muy tupida la toma como línea y deja esa franja sin pintar: hay que completarla con la brocha (con Proteger contornos) o con Lazo + Rellenar selección.
- **T08 manga:**
  - Quedan 30 píxeles de franja de 1736 en el PNG con halo. Están en puntas de mechones muy finos.
  - En la obra borrada con v8.27, Refinar borde además quita restos de papel junto a las puntas, y deja al descubierto 16 píxeles claros de huecos entre mechones que el balde no borró. Esos huecos se borran con un toque de Borrar fondo.
- **T07:** cara y cuello son UNA zona en ese dibujo (no hay línea entre ellos), así que van del mismo color.

---

## 5. Rendimiento (servidor; NO es un teléfono)

Misma prueba sobre v8.26 y v8.27 (`docs/RENDIMIENTO_8_27.txt`). Tiempos en el hilo de la pantalla por evento táctil (16 ms entre eventos):

| Caso | v8.26 | v8.27 |
|---|---|---|
| Brocha + Proteger contornos, manga 1024×1536 | p99 59,2 ms · max 113,7 ms · 6,8 MB por trazo | p99 13,0 ms · max 15,4 ms · 2,6 MB |
| Brocha + Proteger contornos, 4K | p99 37,1 ms · max 276,6 ms · 29,7 MB por trazo | p99 5,5 ms · max 8,2 ms · 10,1 MB |
| Brocha normal, 4K | p95 0,89 ms | p95 0,66 ms |
| Marioneta, PNG 1024×1536 | CPU del hilo de vista previa 778 ms en 40 eventos · 0,7 MB en el hilo de pantalla · un Bitmap nuevo por vista previa | 669 ms · 0,2 MB · 7 Bitmaps en total |
| Marioneta con zoom ×3 | 835 ms · detalle 0,67 px por px (borroso) | 413 ms · detalle 1,00 (nítido) |
| Resolvedor de Marioneta | malla de 1331 vértices | 422 vértices |
| Balde (cálculo) | 66-272 ms según tamaño | igual: no se cambió el motor de búsqueda |

En el teléfono: Menú > «Medir rendimiento».
- La prueba automática del APK ya se corrió de punta a punta en el Android simulado (`PerfBenchSimTest`), en 720p, 1080p, 2K, 4K y A4 con 6 capas.
- **Objetivos iniciales (a calibrar en tu teléfono, no probados):** p95 menor de 33 ms al pintar y hacer zoom; ninguna pausa de más de 700 ms; sin cierres por memoria; exportación idéntica a la pantalla.
- Copia el informe y mándamelo para calibrar.

---

## 6. Tamaño de los ZIP (medido)

| Archivo | Bytes |
|---|---|
| v8.23 (referencia) | 3 451 677 |
| v8.26 recibido | 10 240 858 |
| **v8.27 FULL** (todo: código, pruebas, imágenes de prueba, documentos, imágenes QA nuevas 6,9 MB) | ~17,5 MB (500 archivos) |
| **v8.27 LITE** (solo lo que necesita GitHub Actions) | ~1,1 MB (235 archivos) |

- Lo pesado de v8.26 no era código: eran las imágenes de `tests/assets` (manga 3,0 MB y personaje 1,2 MB), las comparaciones de `docs` (2,8 MB) y `branding` (2,3 MB sin comprimir).
- La LITE no lleva nada de eso, ni las pruebas. **El workflow no corre pruebas** (solo `gradle :app:assembleDebug`), así que la LITE compila igual.
- `app/src/main/res` (iconos y recursos que sí van en el APK) queda completo en las dos.
- **El tamaño del APK no se puede medir aquí** (no hay SDK de Android). Míralo en el artefacto de Actions.
  - v8.27 no agrega recursos: el APK debería pesar casi lo mismo que v8.26 (unos KB más de código).
  - Recursos empaquetados (sin comprimir): 750 475 bytes, igual que v8.26.

---

## 7. Pasos para probar en tu teléfono

1. Sube **Paint-Zeta-v8.27-LITE.zip** a GitHub (como siempre) y descarga el APK de Actions.
2. **Capas y balde:**
   - Abre el manga, crea capa_1 y elige balde.
   - La barra debe decir «→ capa_1 · Normal».
   - Rellena varias zonas: no debe aparecer ninguna capa nueva.
   - Toca «→ capa_1», elige «Capa de color automática», Listo y rellena dos veces: aparece UNA «Color» y capa_1 sigue elegida.
3. **Brocha:**
   - Pinta rojo al 100 % en capa_1: borde limpio, sin manchas.
   - Prende el escudo (Proteger contornos) y pinta sobre la chaqueta con trama: color parejo y la tinta visible.
   - Cierra y abre la app: el borde debe seguir duro.
4. **Borrar fondo:**
   - Borra el fondo de un personaje sobre blanco y pon la vista en gris o negro (Capas, fondos de abajo): no debe haber borde blanco.
   - Con un PNG viejo con halo: Borrar fondo > Refinar borde > Aceptar.
5. **Marioneta:**
   - No se ve la malla.
   - Fija los pies, endereza; al pulsar ✓ debe ofrecer «Ampliar lienzo y aplicar».
   - Luego Deshacer dos veces vuelve al original.
6. **Menú > Medir rendimiento > Medir rápida:** copia el informe y envíamelo, junto con la RAM de tu teléfono.

---

## 8. Archivos cambiados

Lista con líneas agregadas y quitadas: `docs/ARCHIVOS_CAMBIADOS_8_27.txt`. Diferencia completa del código de la app: `docs/diff_8_26_a_8_27.patch`.

- **Nuevos:** `core/EdgeRefine`, `core/InkGuard`, `core/PerfStats`, `view/PerfBench`, `tests/QA827Test`, `tests/PerfBenchSimTest`, `tests/sdkcheck/compile_without_sdk.sh` (con `android_stubs_sin_sdk`), `tests/assets/obra_v826_capa1_color1.pzp`.
- **Cambiados:** `CanvasView`, `MainActivity`, `BackgroundEraseAlpha`, `BrushPreset`, `BucketFill` (solo agrega `edgeBand`), `Layer`, `Project` (`crop`), `ProjectIO`, `PuppetMesh`, `PuppetSession`, `UndoManager`, `app/build.gradle`, `tests/run_jvm_tests.sh`, `tests/test_regressions.py`, `tests/DeformSimTest.java` y el Android simulado de pruebas.
- **No se tocó:** el motor de Especial (licuar), Malla y Puntos de anclaje de Transformar, Curva, Polilínea, Lazo, el workflow de GitHub y los recursos de la app.
