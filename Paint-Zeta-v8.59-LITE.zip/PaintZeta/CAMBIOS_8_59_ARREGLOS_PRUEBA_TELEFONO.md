# Paint Zeta v8.59: arreglos de lo que probaste en tu teléfono (8.58)

## 1. Colorear pintaba en otros lugares (imágenes 11 a 15)

- **Causa**:
  - Al pintar una zona, la app cierra los huecos de las líneas y corta lo que se "escapó" por ellos.
  - Ese corte dejaba pedacitos sueltos lejos del toque. Por eso la piel aparecía en la ropa y el rojo de la ropa en el pelo.
  - Medido con una imagen como la tuya: entre 1.400 y 6.600 pixeles sueltos por toque, en hasta 65 pedacitos, algunos a 139 pixeles de donde tocaste.
- **Ahora**:
  - Solo se pinta lo que está unido al lugar que tocaste. Medido: 1 sola pieza en cada toque.
  - Imagen: colorear_antes_despues.png.
- **Animaciones**: se quitaron las que salían solas al colorear y al elegir herramientas.
  - La de Colorear todavía se puede ver con el botón "?".
  - La de las herramientas se vuelve a prender en ⋮ > Animación.

## 2. Luz: borrosa y con el color lavado (imágenes 16 a 19)

- **Causa**: mientras ajustabas, la vista previa mostraba TODO tu dibujo en una copia chica estirada, por eso se veía borroso. Además, cada cambio esperaba 150 ms y los cálculos viejos no se cancelaban, así que había trabas.
- **Ahora**:
  - Tu dibujo queda nítido en la pantalla y encima solo se dibujan los efectos (sombra en Multiplicar, luz en Superponer, brillo en Trama), igual que como quedan al aceptar. Esto funciona en Android 10 o más nuevo; en Android 8 y 9 se sigue viendo como antes.
  - Sin la espera fija, y el cálculo viejo se corta al mover de nuevo.
- **Sobre tu pregunta**: al tocar ✓, Luz SÍ crea capas aparte (✦ Sombra, ✦ Luz, ✦ Brillo) y tu dibujo no cambia. Su opacidad es la fuerza del efecto. Si vuelves a usar Luz, reemplaza las ✦ de antes y, mientras pruebas, las esconde.
- **Estilo (la rueda de colores)**: se dejó igual, como te gustó. Solo responde más rápido.

## 3. B/N de Borrar fondo, al instante

El contraste y el brillo ahora se ven en el momento: los aplica la tarjeta gráfica del teléfono mientras la imagen exacta se vuelve a armar por detrás. El canal y la saturación siguen como antes.

## 4. Filtros (imágenes 2 a 9 y 4-5 de la segunda tanda)

- **Resultado real con zoom**:
  - Al soltar la barra, después de la vista rápida, se calcula el resultado real. Es el tamaño real si la imagen tiene hasta 2048 px (1400 px en teléfonos con poca memoria); si es más grande, una copia de ese tamaño.
  - Pellizca con dos dedos para acercar y mover, o toca dos veces para acercar y volver.
  - Si ya está el resultado real, Aceptar lo usa sin recalcular. Medido: idéntico a lo que se aplica.
- **Extraer líneas en imágenes a color**: ahora deja solo las líneas, con su color. Antes dejaba el sombreado del pelo y los colores lavados. En manga blanco y negro (incluso con papel amarillo) sigue igual de bien.
- **Pictorizar líneas**: líneas más finas de fábrica.
- **Pictorizar color**: ahora conserva las líneas y los ojos, sin mancharlos.
- **Nitidez**: ya no deja bordes blancos junto a las líneas, ni al máximo.
- Imagen: filtros_antes_despues.png.

## 5. Interfaz

- **Capas**:
  - Hay un tirador arriba del panel para estirarlo o achicarlo con el dedo, hasta la mitad de la pantalla.
  - Recuerda el tamaño aunque cierres la app.
  - Se quitó el botón Más/Menos.
- **Rueda de modos**:
  - Al abrirla, Capas se esconde, la rueda va abajo y Capas vuelve al cerrarla.
  - Es más chica.
  - Se puede mover a cualquier lugar arrastrando desde su título (⠿).
  - El modo y la opacidad se ven al instante.
- **Una cosa a la vez**: Herramientas, Capas y las tarjetas (Luz, Estilo, Colorear) ya no se tapan entre sí. Al abrir uno se cierra o se esconde el otro.
- **Menú ⋮ más compacto**: 5 por fila, iconos y textos más chicos, y una ✕ arriba en vez del botón grande.
- **Marioneta**: el anillo para girar está más lejos del punto naranja (de 30 a 50). Así arrastras el punto sin girarlo sin querer.
- **"¿Extraer las líneas?"**: texto corto, sale siempre al abrir una imagen nueva, y deja de salir con "No volver a preguntar".

## Qué no cambió

"Mejorar imagen" y "Recortar con IA" siguen idénticos a la 8.56.

## Cómo probarlo

1. **Colorear**: toca la cara y luego la ropa con otro color. No debe aparecer color en otros lugares.
2. **Luz**: con la tarjeta abierta, haz zoom: el dibujo debe verse nítido. Mueve las barras y mira que responda rápido.
3. **Filtros**:
   - suelta la barra y espera "Resultado real";
   - pellizca para ver de cerca;
   - Aceptar.
4. **Capas**: estira el panel desde el tirador, cierra la app, ábrela y mira que quede igual.
5. **Rueda de modos**: muévela arrastrando el título y mueve la opacidad.
6. **Una cosa a la vez**: abre Herramientas con Capas o Luz abiertos; no deben quedar uno encima del otro.
