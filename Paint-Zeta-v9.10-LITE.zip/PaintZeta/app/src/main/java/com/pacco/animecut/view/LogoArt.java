package com.pacco.animecut.view;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.pacco.animecut.core.LogoShapes;

/**
 * v9.10: dibujo de los logos. Lo usa la marca "Logo" en la pantalla (vista previa y lo que queda
 * pintado): asi se ve igual mientras lo acomodas y despues. Antes estaba dentro de la ventana
 * aparte del logo.
 */
public final class LogoArt {

    private LogoArt() { }

    /** Color de letra que se lee sobre ese fondo. */
    static int readableOn(int c) {
        int l = (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
        return l > 150 ? 0xFF1A1A1A : 0xFFFFFFFF;
    }

    /**
     * Dibuja el logo en una caja de boxW x boxH con centro (cx, cy). outline: 0 sin borde, 1 negro,
     * 2 blanco. top = texto de arriba (en curva en las formas redondas), mid = el nombre.
     */
    public static void draw(Canvas c, float cx, float cy, float boxW, float boxH, int shape, int fill,
                            int outline, String top, String mid) {
        if (shape < 0 || shape >= LogoShapes.ASPECT.length) shape = 0;
        float asp = LogoShapes.ASPECT[shape];
        float w = boxW, h = boxW / asp;
        if (h > boxH) { h = boxH; w = boxH * asp; }
        float x0 = cx - w / 2f, y0 = cy - h / 2f;
        float m = Math.min(w, h);
        boolean none = shape == LogoShapes.NONE;
        int edge = outline == 1 ? 0xFF111111 : 0xFFFFFFFF;
        if (!none) {
            Path path = new Path();
            RectF r = new RectF(x0, y0, x0 + w, y0 + h);
            if (shape == LogoShapes.RECT) path.addRect(r, Path.Direction.CW);
            else if (shape == LogoShapes.ROUND) path.addRoundRect(r, h * 0.24f, h * 0.24f, Path.Direction.CW);
            else if (shape == LogoShapes.OVAL || shape == LogoShapes.CIRCLE) path.addOval(r, Path.Direction.CW);
            else {
                float[] pts = LogoShapes.points(shape);
                for (int i = 0; i + 1 < pts.length; i += 2) {
                    float x = x0 + pts[i] * w, y = y0 + pts[i + 1] * h;
                    if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
                }
                path.close();
            }
            Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
            pf.setStyle(Paint.Style.FILL);
            pf.setColor(fill);
            c.drawPath(path, pf);
            if (outline != 0) {
                Paint ps = new Paint(Paint.ANTI_ALIAS_FLAG);
                ps.setStyle(Paint.Style.STROKE);
                ps.setStrokeJoin(Paint.Join.ROUND);
                ps.setStrokeWidth(Math.max(2f, m * 0.045f));
                ps.setColor(edge);
                c.drawPath(path, ps);
            }
        }
        boolean hasTop = top != null && !top.trim().isEmpty();
        boolean hasMid = mid != null && !mid.trim().isEmpty();
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(none ? fill : readableOn(fill));
        pt.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        pt.setTextAlign(Paint.Align.CENTER);
        Paint ptEdge = null;
        if (none && outline != 0) {
            // solo letras: el borde va alrededor de cada letra
            ptEdge = new Paint(pt);
            ptEdge.setStyle(Paint.Style.STROKE);
            ptEdge.setStrokeJoin(Paint.Join.ROUND);
            ptEdge.setColor(edge);
        }
        if (LogoShapes.wide(shape) && shape != LogoShapes.RIBBON) {
            // rectangulo, redondeado, ovalo y solo letras: texto derecho, el de arriba mas chico
            float midY = cy + (hasTop ? h * 0.13f : 0f);
            if (hasMid) {
                float ts = h * (hasTop ? 0.42f : 0.55f);
                float maxW = w * (shape == LogoShapes.OVAL ? 0.70f : none ? 0.96f : 0.84f);
                ts = fit(pt, mid.trim(), ts, maxW);
                drawLine(c, mid.trim(), cx, midY, ts, pt, ptEdge);
            }
            if (hasTop) {
                float ts = h * 0.2f;
                float maxW = w * (shape == LogoShapes.OVAL ? 0.62f : none ? 0.9f : 0.8f);
                ts = fit(pt, top.trim(), ts, maxW);
                float ty = hasMid ? cy - h * 0.25f : cy;
                drawLine(c, top.trim(), cx, ty, ts, pt, ptEdge);
            }
            return;
        }
        boolean round = shape != LogoShapes.RIBBON;
        if (hasMid) {
            String t = mid.trim();
            float ts = round ? m * 0.26f : h * 0.5f;
            float maxW = round ? m * 0.72f : w * 0.78f;
            ts = fit(pt, t, ts, maxW);
            float my = cy + (round && hasTop ? m * 0.08f : 0f);
            drawLine(c, t, cx, my, ts, pt, ptEdge);
        }
        if (hasTop) {
            String t = top.trim();
            // en curva: dentro de la forma redonda, o arriba de la cinta
            float r = round ? m * 0.33f : w * 0.42f;
            float acy = round ? cy + m * 0.04f : cy + h * 0.15f + r * 0.55f;
            RectF ov = new RectF(cx - r, acy - r, cx + r, acy + r);
            Path arc = new Path();
            float sweep = round ? 180f : 110f;
            arc.addArc(ov, 270f - sweep / 2f, sweep);
            float arcLen = (float) (Math.PI * r * sweep / 180f);
            float ts = round ? m * 0.12f : h * 0.42f;
            pt.setTextSize(ts);
            pt.setTextAlign(Paint.Align.LEFT);
            float tw = pt.measureText(t);
            if (tw > arcLen * 0.92f) { ts *= arcLen * 0.92f / tw; pt.setTextSize(ts); tw = pt.measureText(t); }
            if (!round) pt.setColor(fill == 0xFFFFFFFF ? 0xFF1A1A1A : fill);   // encima de la cinta: del color de la cinta
            c.drawTextOnPath(t, arc, (arcLen - tw) / 2f, round ? ts * 0.35f : 0f, pt);
        }
    }

    private static float fit(Paint pt, String t, float ts, float maxW) {
        pt.setTextSize(ts);
        float tw = pt.measureText(t);
        if (tw > maxW && tw > 0f) { ts *= maxW / tw; pt.setTextSize(ts); }
        return ts;
    }

    private static void drawLine(Canvas c, String t, float x, float y, float ts, Paint pt, Paint edge) {
        pt.setTextSize(ts);
        pt.setTextAlign(Paint.Align.CENTER);
        float by = y - (pt.ascent() + pt.descent()) / 2f;
        if (edge != null) {
            edge.setTextSize(ts);
            edge.setTextAlign(Paint.Align.CENTER);
            edge.setStrokeWidth(Math.max(2f, ts * 0.12f));
            c.drawText(t, x, by, edge);
        }
        c.drawText(t, x, by, pt);
    }
}
