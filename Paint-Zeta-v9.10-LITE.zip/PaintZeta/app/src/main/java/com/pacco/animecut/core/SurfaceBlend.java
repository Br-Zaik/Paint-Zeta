package com.pacco.animecut.core;

/**
 * v9.10 "En pared / piso" (video 2 de Photoshop: texto pintado en la pista). Despues de acostar
 * el texto (o el logo, o un sticker) con la perspectiva, la capa toma la textura de lo que esta
 * debajo: las grietas, el grano y la luz/sombra del piso o la pared se ven a traves de la pintura.
 *
 * Lo mismo que "Opciones de fusion > Capa subyacente" de Photoshop, pero automatico:
 *  - detalle chico (grano, grietas): la pintura se oscurece/aclara con el piso;
 *  - luz grande (una sombra que cruza): la pintura queda mas oscura donde el piso es mas oscuro;
 *  - desgaste: en las grietas mas oscuras la pintura se gasta (se ve el piso).
 *
 * Java puro (sin Android) para probarlo aparte.
 */
public final class SurfaceBlend {

    private SurfaceBlend() { }

    /** Margen alrededor del cuadro que hay que mirar debajo (para la luz grande). */
    public static int margin(int x0, int y0, int x1, int y1) {
        int diag = (int) Math.sqrt((double) (x1 - x0) * (x1 - x0) + (double) (y1 - y0) * (y1 - y0));
        return Math.max(8, Math.min(80, diag / 10));
    }

    /**
     * @param layer  pixeles de la capa (ARGB sin premultiplicar, todo el lienzo w x h); solo
     *               cambia dentro del cuadro x0,y0-x1,y1
     * @param under  lo que se ve DEBAJO de la capa, en el cuadro (ux0, uy0, uw x uh) que debe
     *               cubrir el cuadro agrandado con margin()
     * @param amount 0..1 (0 = no cambia nada)
     */
    public static void apply(int[] layer, int w, int h, int x0, int y0, int x1, int y1,
                             int[] under, int ux0, int uy0, int uw, int uh, float amount) {
        if (amount <= 0f) return;
        if (amount > 1f) amount = 1f;
        x0 = Math.max(0, x0); y0 = Math.max(0, y0);
        x1 = Math.min(w, x1); y1 = Math.min(h, y1);
        if (x1 <= x0 || y1 <= y0) return;
        int diag = (int) Math.sqrt((double) (x1 - x0) * (x1 - x0) + (double) (y1 - y0) * (y1 - y0));
        int rs = Math.max(2, Math.min(10, diag / 90));      // detalle chico
        int rb = margin(x0, y0, x1, y1);                     // luz grande
        int ex0 = Math.max(ux0, x0 - rb), ey0 = Math.max(uy0, y0 - rb);
        int ex1 = Math.min(ux0 + uw, x1 + rb), ey1 = Math.min(uy0 + uh, y1 + rb);
        if (ex0 > x0 || ey0 > y0 || ex1 < x1 || ey1 < y1) return;     // lo de abajo no cubre el cuadro
        int ew = ex1 - ex0, eh = ey1 - ey0;
        float[] lum = new float[ew * eh];
        for (int y = 0; y < eh; y++) {
            int row = (ey0 - uy0 + y) * uw + (ex0 - ux0);
            for (int x = 0; x < ew; x++) {
                int c = under[row + x];
                lum[y * ew + x] = ((c >> 16) & 255) * 0.299f + ((c >> 8) & 255) * 0.587f + (c & 255) * 0.114f;
            }
        }
        double[] ii = integral(lum, ew, eh);
        // promedio de todo lo que esta debajo de la pintura (para la luz grande)
        double sum = 0;
        int cnt = 0;
        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++)
                if ((layer[y * w + x] >>> 24) > 20) { sum += lum[(y - ey0) * ew + (x - ex0)]; cnt++; }
        if (cnt == 0) return;
        float meanAll = (float) (sum / cnt);
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                int i = y * w + x;
                int c = layer[i];
                int a = c >>> 24;
                if (a == 0) continue;
                int lx = x - ex0, ly = y - ey0;
                float l = lum[ly * ew + lx];
                float ms = boxMean(ii, ew, eh, lx, ly, rs);
                float mb = boxMean(ii, ew, eh, lx, ly, rb);
                float d = (l + 10f) / (ms + 10f);                // grano y grietas
                if (d < 0.35f) d = 0.35f; else if (d > 1.6f) d = 1.6f;
                float g = (mb + 12f) / (meanAll + 12f);          // luz y sombra grandes
                if (g < 0.45f) g = 0.45f; else if (g > 1.35f) g = 1.35f;
                float shade = (1f + (d - 1f) * amount) * (1f + (g - 1f) * amount * 0.75f);
                int r = clamp((int) (((c >> 16) & 255) * shade + .5f));
                int gg = clamp((int) (((c >> 8) & 255) * shade + .5f));
                int b = clamp((int) ((c & 255) * shade + .5f));
                // desgaste: en lo mas oscuro del grano la pintura se gasta un poco
                if (d < 0.85f) {
                    float wear = (0.85f - d) / 0.5f;
                    if (wear > 1f) wear = 1f;
                    a = (int) (a * (1f - wear * amount * 0.7f) + .5f);
                }
                layer[i] = (a << 24) | (r << 16) | (gg << 8) | b;
            }
        }
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : v > 255 ? 255 : v;
    }

    private static double[] integral(float[] v, int w, int h) {
        double[] ii = new double[(w + 1) * (h + 1)];
        for (int y = 0; y < h; y++) {
            double row = 0;
            for (int x = 0; x < w; x++) {
                row += v[y * w + x];
                ii[(y + 1) * (w + 1) + x + 1] = ii[y * (w + 1) + x + 1] + row;
            }
        }
        return ii;
    }

    private static float boxMean(double[] ii, int w, int h, int x, int y, int r) {
        int ax = Math.max(0, x - r), ay = Math.max(0, y - r);
        int bx = Math.min(w, x + r + 1), by = Math.min(h, y + r + 1);
        int W = w + 1;
        double s = ii[by * W + bx] - ii[ay * W + bx] - ii[by * W + ax] + ii[ay * W + ax];
        return (float) (s / Math.max(1, (bx - ax) * (by - ay)));
    }
}
