package com.pacco.animecut.core;

/**
 * v9.08 Formas para logos: circulo, escudo, estrella, sello y cinta. Cada forma es una lista de
 * puntos (x, y, x, y...) dentro de una caja de 0 a 1, asi se puede dibujar de cualquier tamano.
 * Java puro (sin Android) para poder probarla aparte.
 */
public final class LogoShapes {

    private LogoShapes() { }

    public static final int CIRCLE = 0, SHIELD = 1, STAR = 2, SEAL = 3, RIBBON = 4;
    /** v9.10: mas formas (no todo es redondo) y "Solo letras" (sin forma). */
    public static final int RECT = 5, ROUND = 6, OVAL = 7, HEX = 8, NONE = 9;
    public static final String[] NAMES = {"Circulo", "Escudo", "Estrella", "Sello", "Cinta",
            "Rectangulo", "Redondeado", "Ovalo", "Hexagono", "Solo letras"};
    /** Orden en que se muestran (lo mas usado primero). */
    public static final int[] ORDER = {NONE, CIRCLE, ROUND, RECT, OVAL, SHIELD, STAR, SEAL, HEX, RIBBON};
    /** Proporcion ancho / alto de cada forma. */
    public static final float[] ASPECT = {1f, 0.86f, 1f, 1f, 3.2f, 1.7f, 1.7f, 1.55f, 1.15f, 2.6f};

    /** Formas anchas: el texto va derecho (no en curva). */
    public static boolean wide(int shape) {
        return shape == RIBBON || shape == RECT || shape == ROUND || shape == OVAL || shape == NONE;
    }

    /** Los puntos de la forma (caja 0..1). El circulo va con muchos puntos. */
    public static float[] points(int shape) {
        switch (shape) {
            case SHIELD: return shield();
            case STAR: return star(5, 0.5f, 0.2f);
            case SEAL: return seal(24);
            case RIBBON: return ribbon();
            case RECT: return new float[]{0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f};
            case ROUND: return rounded(0.22f, 10);
            case OVAL: return circle(96);           // se estira con la proporcion de la caja
            case HEX: return new float[]{0.25f, 0f, 0.75f, 0f, 1f, 0.5f, 0.75f, 1f, 0.25f, 1f, 0f, 0.5f};
            case NONE: return new float[0];
            default: return circle(96);
        }
    }

    static float[] circle(int n) {
        float[] p = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            p[i * 2] = 0.5f + 0.5f * (float) Math.cos(a);
            p[i * 2 + 1] = 0.5f + 0.5f * (float) Math.sin(a);
        }
        return p;
    }

    /** Estrella de n puntas: radio de afuera ro y de adentro ri (en la caja 0..1), punta arriba. */
    static float[] star(int n, float ro, float ri) {
        float[] p = new float[n * 4];
        // un poco mas abajo para que quede centrada a la vista (la estrella pesa arriba)
        float cy = 0.5f + (ro - ro * (float) Math.cos(Math.PI / n)) / 2f;
        for (int i = 0; i < n * 2; i++) {
            double a = -Math.PI / 2 + Math.PI * i / n;
            float r = i % 2 == 0 ? ro : ri;
            p[i * 2] = 0.5f + r * (float) Math.cos(a);
            p[i * 2 + 1] = cy + r * (float) Math.sin(a);
        }
        return p;
    }

    /** Sello con picos (como una medalla): n picos alrededor. */
    static float[] seal(int n) {
        float[] p = new float[n * 4];
        for (int i = 0; i < n * 2; i++) {
            double a = -Math.PI / 2 + Math.PI * i / n;
            float r = i % 2 == 0 ? 0.5f : 0.44f;
            p[i * 2] = 0.5f + r * (float) Math.cos(a);
            p[i * 2 + 1] = 0.5f + r * (float) Math.sin(a);
        }
        return p;
    }

    /** Escudo: arriba recto con hombros y abajo en punta curva. */
    static float[] shield() {
        java.util.ArrayList<Float> l = new java.util.ArrayList<Float>();
        add(l, 0.5f, 0f);
        add(l, 1f, 0.08f);
        add(l, 1f, 0.45f);
        // lado derecho que baja en curva hasta la punta
        for (int i = 1; i <= 12; i++) {
            float t = i / 12f;
            add(l, 1f - 0.5f * t * t, 0.45f + 0.55f * t);
        }
        // lado izquierdo (espejo)
        for (int i = 11; i >= 0; i--) {
            float t = i / 12f;
            add(l, 0.5f * t * t, 0.45f + 0.55f * t);
        }
        add(l, 0f, 0.08f);
        float[] p = new float[l.size()];
        for (int i = 0; i < p.length; i++) p[i] = l.get(i);
        return p;
    }

    /** Rectangulo redondeado: radio r (de la altura, en la caja 0..1), n puntos por esquina. */
    static float[] rounded(float r, int n) {
        float[] p = new float[4 * (n + 1) * 2];
        float[][] c = {{1f - r, r, -90f}, {1f - r, 1f - r, 0f}, {r, 1f - r, 90f}, {r, r, 180f}};
        int k = 0;
        for (float[] cc : c) {
            for (int i = 0; i <= n; i++) {
                double a = Math.toRadians(cc[2] + 90.0 * i / n);
                p[k++] = cc[0] + r * (float) Math.cos(a);
                p[k++] = cc[1] + r * (float) Math.sin(a);
            }
        }
        return p;
    }

    /** Cinta: una banda con las puntas en V. */
    static float[] ribbon() {
        return new float[]{0f, 0f, 1f, 0f, 0.93f, 0.5f, 1f, 1f, 0f, 1f, 0.07f, 0.5f};
    }

    private static void add(java.util.ArrayList<Float> l, float x, float y) {
        l.add(x);
        l.add(y);
    }

    /** Caja {minX, minY, maxX, maxY} de los puntos (para las pruebas y para centrar). */
    public static float[] box(float[] p) {
        float a = Float.MAX_VALUE, b = Float.MAX_VALUE, c = -Float.MAX_VALUE, d = -Float.MAX_VALUE;
        for (int i = 0; i + 1 < p.length; i += 2) {
            a = Math.min(a, p[i]); b = Math.min(b, p[i + 1]);
            c = Math.max(c, p[i]); d = Math.max(d, p[i + 1]);
        }
        return new float[]{a, b, c, d};
    }
}
