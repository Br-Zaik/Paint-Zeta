package com.pacco.animecut.core;

/**
 * v9.10 "Cambiar color" (video 3: la gorra verde que pasa a naranja igual que la polera).
 * Pintar encima con un color plano tapa los pliegues; aqui se cambia el COLOR pero se quedan las
 * luces, sombras y la textura de la tela (como Photoshop: desaturar + capa de color en modo Color
 * + Niveles para igualar el brillo, todo en un solo paso).
 *
 * En OKLab:
 *  - el tono y la saturacion pasan a ser los del color nuevo;
 *  - la claridad se corre para que el tono medio quede como el color nuevo (los pliegues se
 *    mantienen: lo oscuro sigue oscuro y lo claro, claro);
 *  - cada pixel conserva su variacion de saturacion respecto del color original.
 * Ademas parecido(): cuanto se parece un pixel al color que tocaste (asi no se pasa a la piel o al
 * fondo aunque el pincel los toque).
 *
 * Java puro (sin Android) para probarlo aparte.
 */
public final class Recolor {

    private final float sL, sA, sB, sC, tL, tA, tB, tC;

    /** source = color de lo que tocaste; target = el color nuevo. */
    public Recolor(int source, int target) {
        float[] s = ZoneTone.oklab(source), t = ZoneTone.oklab(target);
        sL = s[0]; sA = s[1]; sB = s[2];
        tL = t[0]; tA = t[1]; tB = t[2];
        sC = (float) Math.hypot(sA, sB);
        tC = (float) Math.hypot(tA, tB);
    }

    /** El pixel con el color nuevo (alfa igual). */
    public int apply(int c) {
        int a = c >>> 24;
        if (a == 0) return c;
        float[] k = ZoneTone.oklab(c);
        // claridad: el medio de la tela pasa a ser el del color nuevo, los pliegues se mantienen
        float L = k[0];
        float nl;
        if (L <= sL) nl = sL > 1e-3f ? tL * (L / sL) : tL;
        else nl = sL < 0.999f ? tL + (1f - tL) * ((L - sL) / (1f - sL)) : tL;
        // un poco del contraste original tal cual (para que no quede lavado)
        nl = nl * 0.8f + (L + (tL - sL)) * 0.2f;
        nl = Math.max(0f, Math.min(1f, nl));
        // saturacion: la del color nuevo, con la variacion que tenia cada pixel
        float pc = (float) Math.hypot(k[1], k[2]);
        float ratio = sC > 0.025f ? Math.max(0.35f, Math.min(1.6f, pc / sC)) : 1f;
        // lo muy oscuro o muy claro tiene menos color (como en una foto real)
        float edge = Math.min(1f, Math.min(nl / 0.18f, (1f - nl) / 0.08f));
        float sat = ratio * Math.max(0f, edge);
        float na = tA * sat, nb = tB * sat;
        return (a << 24) | (ZoneTone.fromOklab(nl, na, nb) & 0xFFFFFF);
    }

    /**
     * 1 = es el mismo color que tocaste, 0 = otro color (piel, fondo). La claridad pesa poco: la
     * misma tela con sombra o con luz sigue siendo "el mismo color".
     */
    public float similar(int c) {
        if ((c >>> 24) < 8) return 0f;
        float[] k = ZoneTone.oklab(c);
        float da = k[1] - sA, db = k[2] - sB, dl = (k[0] - sL) * 0.35f;
        float d = (float) Math.sqrt(da * da + db * db + dl * dl);
        // grises: comparar sobre todo la claridad, mas estricto
        float t0 = sC < 0.03f ? 0.035f : 0.06f, t1 = sC < 0.03f ? 0.09f : 0.15f;
        if (d <= t0) return 1f;
        if (d >= t1) return 0f;
        float u = (t1 - d) / (t1 - t0);
        return u * u * (3f - 2f * u);
    }
}
