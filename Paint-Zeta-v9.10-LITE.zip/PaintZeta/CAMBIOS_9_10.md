# Paint Zeta 9.10 — Diseño Grafito, todo en la misma pantalla y herramientas nuevas útiles

Lo pedido después de los videos del 27/11: diseño A (Grafito), arreglos de Texto, Toques, Fundir,
Luz/Estilo, capas, Especial, Sticker, Logo, Separar, Flechas, Recortar; y las ideas de los videos
de otras apps (textura de jean, texto en el piso, cambiar color de la gorra).

## Diseño (Grafito)
- **Causa:** los botones de opciones usaban dos dibujos fijos: rojo (sin elegir) y verde (elegido).
- **Ahora:** gris oscuro con un solo azul. Lo elegido va con borde azul y fondo azul suave. Los
  colores para elegir son redondos. El check de abajo es un círculo azul. Barras y casillas en azul.
- Las filas con pocas opciones se reparten a lo ancho (antes todo a la izquierda y un hueco).
  Texto: ya no sale el botón "Escribir" solo a la izquierda (el botón grande hace lo mismo).

## Menú de herramientas
- **Separar:** quitado del menú.
- **Causa del "no hace caso":** el menú marcaba la herramienta de dibujo de abajo (Mano o Brocha)
  aunque estuvieras en Luz, Toques o Estilo, y nunca marcaba Sticker ni Logo.
- **Ahora:** marca lo que de verdad tienes abierto (pasos de Colorear, Sticker, Logo, Cambiar color).

## Texto
- **Causa de lo lento:** la imagen esperaba 220 ms después de cada letra antes de dibujar.
- **Ahora:** cada letra sale en la imagen al instante (se junta en un dibujo por cuadro si escribes
  muy rápido). Sin sombra oscura encima de la imagen mientras escribes.
- **Causa de las "E" una debajo de otra:** la tecla azul ↵ del teclado ponía un renglón nuevo.
- **Ahora:** esa tecla es "Listo". Lo largo igual se ve en varias líneas.

## Flechas
- **Antes:** 13 botones y el color escondido.
- **Ahora:** arriba siempre la forma y los colores; abajo solo Grosor, Punta, Línea y "Más"
  (Tipo, Inicio, Relleno, Opacidad, Borde, Mover). Con una flecha elegida: Copiar y Quitar.

## Colorear
- **Toques (video 5).** Causa: pintaba fuerte y al soltar lo difuminaba mucho (se veía distinto).
  Ahora el pincel de Toques es suave desde el principio: lo que ves es lo que queda. Al soltar solo
  se limpia la línea negra, como antes.
- **Fundir (video 6).** Causa: difuminaba toda la capa de una vez, sin prendido/apagado. Ahora es un
  pincel: se prende (queda marcado), pasas el dedo por los toques y se funden solo ahí, con el
  tamaño de la barra. La segunda barra es su fuerza. Otro toque lo apaga.
- **Salto al pasar a Luz o Estilo (video 7).** Causa: se quitaba la tarjeta, se veían un momento las
  barras de siempre y después aparecía la nueva. Ahora aparece en su lugar una tarjeta del mismo alto
  con "Preparando..." y cambia sin saltar. En Toques, Luz y Estilo ya no sale la fila del pincel
  (Plano, puntas...) que no se usa ahí.
- **Capas en Estilo/Luz (video 8).** Causa: se sacaba una foto del dibujo al abrir y se mostraba esa
  foto. Ahora si ocultas, borras o cambias una capa, la foto se vuelve a sacar y la vista cambia.

## Especial (video 9)
- **Causa:** al agrandar (Expandir, Arrastrar) los pixeles se estiraban con un paso de 2 a 4 pixeles
  entre colores: líneas y pelo borrosos.
- **Ahora:** donde la imagen se agranda, el paso entre colores dura 1 pixel de pantalla (sin halos:
  nunca sale de los colores vecinos). Casi 1:1 queda igual que antes.
- Prueba: línea agrandada 2,5 veces: 16 pixeles a medio camino (borroso) antes, 8 ahora.

## Sticker
- Ya no pregunta "Tu imagen todavía tiene fondo": sale tal cual, con o sin fondo.
- Ya no es una ventana aparte: la vista previa sale encima de la imagen y las opciones abajo
  (Borde, Sombra, Archivo, Compartir, Guardar). La X o Atrás lo cierran.

## Logo
- Ya no es una ventana aparte: sale en el medio de la imagen como un sticker. Se mueve con el dedo y
  el punto lo gira y agranda. Abajo: forma, colores, Nombre, Arriba (texto de arriba), Borde,
  Pared/piso, Copiar, Quitar. El nombre se escribe con la misma barrita del texto.
- Formas nuevas: Solo letras (sin forma), Redondeado, Rectángulo, Óvalo, Hexágono (además de
  Círculo, Escudo, Estrella, Sello, Cinta). En las anchas el texto va derecho.
- El check lo pinta en la capa de las marcas.

## Nuevo: En pared / piso (video 2)
- En Texto, Logo y Sticker: botón "Pared/piso". La marca va a una capa nueva y se abre la
  Perspectiva ya puesta como Piso.
- Botones rápidos en la barra de Perspectiva: Piso, Pared izq., Pared der., Techo, Recto. Si
  ninguno sirve, arrastras cada esquina a mano.
- "Textura: Suave / Fuerte / No": al tocar el check, la capa toma el grano, las grietas y la luz y
  sombra de lo que está debajo (como pintado ahí). Un Deshacer aparte.
- También sirve con cualquier capa (imagen, dibujo): Transformar > Perspectiva.

## Nuevo: Cambiar color (video 3)
- En Pintar y retocar. Eliges el color nuevo y pintas encima: cambia el color y se quedan las
  sombras, luces y pliegues (foto real, anime, manga a color).
- Solo cambia lo que se parece al color donde empezaste el trazo: no se pasa a la piel ni al fondo.
- Para igualar otro color de la imagen: mantén el dedo en la imagen para tomarlo.

## Nuevo: Repetir (video 1)
- En Transformar (Mover): "Repetir" llena todo el lienzo con la capa en mosaico (textura de jean,
  tela, pared). Después: Flecha y Multiplicar sobre la ropa. Lo demás del video (Clonar,
  Perspectiva, Malla, Multiplicar) ya estaba.

## Recortar
- Forma "Dibujar": rodeas con el dedo lo que quieres dejar; al soltar se cierra y el cuadro se
  ajusta. Se puede mover y estirar después. El check recorta con esa forma.

## Lo que NO se probó en el teléfono
- Todo lo de pantalla (diseño, paneles, Sticker, Logo, Pared/piso, Recortar a mano, Texto rápido,
  Toques, Fundir): no hay Android en la computadora de pruebas. Se revisó el código y que no haya
  errores de Java.
- El Pincel de Colorear sigue poniendo su acabado al soltar (no se cambió en esta versión).

## Pruebas hechas en la computadora (con tus imágenes y con imágenes hechas aquí)
- Cambiar color: chaqueta celeste a naranja y vestido rosa a azul, con sombras y pliegues.
- En pared / piso: "ALTO" en el asfalto y "ZETA" en una pared de ladrillo, sin y con textura.
- Especial: pelo agrandado 2,6 veces, antes y ahora.

## Cómo probar
1. Menú > Cambiar color: elige naranja y pinta sobre una chaqueta.
2. Marcar > Texto: escribe, toca "Pared/piso", prueba Piso / Pared y el check.
3. Menú > Logo: muévelo, cambia la forma a "Solo letras", toca Nombre.
4. 2 Toques: pinta un rubor (queda igual al soltar), prende Fundir y pásalo.
5. 4 Estilo: abre Capas y oculta una capa: la imagen debe cambiar.
6. Especial > Expandir sobre el pelo: debe quedar nítido.

## Archivos
- `app/src/main/java/com/pacco/animecut/MainActivity.java`
- `app/src/main/java/com/pacco/animecut/view/CanvasView.java`
- `app/src/main/java/com/pacco/animecut/view/LogoArt.java` (nuevo)
- `app/src/main/java/com/pacco/animecut/view/BlendThumbs.java`
- `app/src/main/java/com/pacco/animecut/core/Recolor.java` (nuevo)
- `app/src/main/java/com/pacco/animecut/core/SurfaceBlend.java` (nuevo)
- `app/src/main/java/com/pacco/animecut/core/LogoShapes.java`
- `app/src/main/java/com/pacco/animecut/core/LiquifyRaster.java`
- `app/src/main/res/layout/activity_main.xml`
- `app/src/main/res/values/themes.xml`
- `app/src/main/res/drawable/bg_seg_on.xml`, `bg_seg_off.xml`, `bg_seg.xml`, `bg_tool_on.xml`,
  `bg_save.xml`, `bg_row_on.xml`
- `app/build.gradle` (versión 9.10, código 148)
