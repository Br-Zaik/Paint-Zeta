package com.pacco.animecut.core;

/**
 * v9.11 Mover: copia la imagen corrida (dx, dy) dentro del lienzo. Lo que cae afuera no se copia
 * (pero la imagen entera queda guardada aparte, asi se puede regresar). Java puro para probarlo.
 */
public final class MoveShift {

    private MoveShift() { }

    public static void shift(int[] src, int[] dst, int w, int h, int dx, int dy) {
        java.util.Arrays.fill(dst, 0);
        int x0 = Math.max(0, -dx), x1 = Math.min(w, w - dx);
        if (x0 >= x1) return;
        for (int y = 0; y < h; y++) {
            int ty = y + dy;
            if (ty < 0 || ty >= h) continue;
            System.arraycopy(src, y * w + x0, dst, ty * w + x0 + dx, x1 - x0);
        }
    }
}
