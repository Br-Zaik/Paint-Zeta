# Paint Zeta 9.11 — Arreglos de los videos del 28/11

Solo se tocaron las herramientas de los videos: Pincel de Colorear, cambio de herramienta desde el
menú, capa de color copiada, Toques, Mover y Especial.

## 1. Pincel de Colorear tardaba ~5 segundos
- **Causa:** para no pasarse de la línea, el pincel usa un "mapa" de las líneas del dibujo. Un
  segundo después de cada trazo la app empaca (comprime) las capas que no se usan, también la
  tinta. El mapa se guardaba con "qué memoria usa la capa" y, al empacarse, la app creía que el
  dibujo había cambiado: volvía a calcular todo el mapa en casi cada trazo ("Preparando las
  líneas…", "Mirando las líneas…"). Además la primera vez se calculaba dos veces.
- **Ahora:** el mapa se guarda con la HUELLA del dibujo (la misma esté empacada o no). Se calcula
  una vez y se reusa: el pincel pinta al instante, como la Brocha, y respeta las líneas y lo gris
  igual que el Balde. Si cambias la tinta (otra capa, otro ajuste) se vuelve a calcular solo esa vez.

## 2. Elegir otra herramienta no hacía caso
- **Causa:** al tocar otra herramienta en el menú, la tarjeta de Toques, Luz, Estilo o Colorear se
  quedaba abierta (y el menú la escondía y la volvía a mostrar: el "tik").
- **Ahora:** al elegir cualquier herramienta del menú (o Sticker / Logo) se cierra lo de Colorear
  que estaba abierto. Queda solo la que tocaste.

## 3. Copia de la capa de color no pintaba
- **Causa:** la copia también es "capa de color". Colorear pintaba siempre en la primera: la
  original que ocultaste. Por eso no se veía nada y decía "Esta parte ya tiene ese color".
- **Ahora:** si hay varias, pinta en la que se ve (la elegida, o la de más arriba que se vea). Si
  todas están ocultas, la muestra y avisa: "Tu capa de color estaba oculta".

## 4. Toques pintaba muy fuerte
- **Causa (culpa de la 9.10):** se quitó el suavizado al soltar y se escondió la barra de abajo;
  el pincel quedó al 100 % sin forma de bajarlo.
- **Ahora:** Toques empieza suave (40 %) y la barra de abajo vuelve: más suave o más fuerte. Pasar
  otra vez suma. Lo que ves al pintar sigue siendo lo que queda. Guarda la suavidad que dejaste.

## 5. Mover se comía la imagen
- **Causa:** al soltar, Mover recortaba la capa al borde del lienzo: lo de afuera se perdía.
- **Ahora:** mientras sigas moviendo esa capa, se recuerda la imagen entera. Puedes sacarla y
  regresarla sin perder nada (prueba: antes se perdía el 47 % al sacarla y regresarla, ahora 0).
  Mientras arrastras ves la imagen entera (también lo que está afuera), así al soltar no salta.
  Si pintas o deshaces en medio, empieza de nuevo desde lo que hay.

## 6. Especial dejaba borroso
- **Causa:** la 9.10 solo arregló cuando la imagen se agranda. Al arrastrar poquito cada pixel cae
  "entre dos" y se mezclaban: la línea negra salía gris y más gruesa.
- **Ahora:** otra forma de calcular cada pixel (bicúbica con tope, sin halos). Nitidez del arrastre
  comparada con el original: antes 84 %, ahora 94 %. Con el motor real de Especial (6 trazos sobre
  un dibujo): la zona arrastrada queda tan nítida como el original. Tarda un poco más en calcular
  (de 29 a 59 ms en 6 trazos en la computadora), sigue fluido.

## No se probó en el teléfono
- No hay Android en la computadora de pruebas. Se revisó el código y que no haya errores de Java.
  Lo de Mover y Especial se probó con el mismo cálculo en la computadora (imágenes de prueba).
- La velocidad del Pincel de Colorear depende del teléfono: la primera vez que pintas en una obra
  igual calcula el mapa una vez (unos segundos en imágenes grandes); después ya no.

## Cómo probar
1. Colorear > Pincel: pinta varios trazos seguidos en partes distintas: deben salir al instante.
2. En Toques (o en Colorear) abre el menú y elige Brocha: debe quedar solo la Brocha.
3. Duplica "Color zonas", oculta la original y pinta con el Balde: se debe ver en la copia.
4. Toques: pinta; baja y sube la barra de abajo.
5. Mover: saca la imagen del lienzo, suelta, y regrésala: debe volver entera.
6. Especial > Arrastrar sobre líneas negras: deben quedar firmes.

## Archivos
- `app/src/main/java/com/pacco/animecut/MainActivity.java`
- `app/src/main/java/com/pacco/animecut/view/CanvasView.java`
- `app/src/main/java/com/pacco/animecut/core/Layer.java`
- `app/src/main/java/com/pacco/animecut/core/LiquifyRaster.java`
- `app/src/main/java/com/pacco/animecut/core/MoveShift.java` (nuevo)
- `app/build.gradle` (versión 9.11, código 149)
