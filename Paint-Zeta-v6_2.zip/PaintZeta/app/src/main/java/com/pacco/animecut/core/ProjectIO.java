package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Guarda y abre la obra. Por dentro es un ZIP con un PNG por capa (con su
 * transparencia), la seleccion y los datos de cada capa.
 *
 * Tambien abre las obras de la version anterior, donde las capas eran
 * recortes de la imagen, y las convierte a capas de verdad.
 */
public final class ProjectIO {

    public static class Loaded {
        public Project project;
        public int color;
    }

    private ProjectIO() {
    }

    /**
     * v3: cada capa se guarda solo con su recorte (x, y, ancho, alto). Es mas
     * rapido y liviano que guardar el lienzo entero por cada capa.
     */
    public static void save(OutputStream out, Project p, int color) throws IOException {
        ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(out));
        z.setLevel(1);
        try {
            java.util.List<Layer> layers = new java.util.ArrayList<Layer>(p.layers);
            int w = p.w, h = p.h;
            Layer.Packed[] snaps = new Layer.Packed[layers.size()];
            StringBuilder m = new StringBuilder();
            m.append("v3\n");
            m.append(w).append(' ').append(h).append('\n');
            m.append(color).append('\n');
            m.append(p.active).append('\n');
            m.append(layers.size()).append('\n');
            for (int i = 0; i < layers.size(); i++) {
                Layer l = layers.get(i);
                Layer.Packed pk = l.snapshot(w, h);
                snaps[i] = pk;
                m.append(l.visible ? 1 : 0).append('|').append(l.opacity).append('|')
                        .append(pk.x).append('|').append(pk.y).append('|')
                        .append(pk.w).append('|').append(pk.h).append('|')
                        .append(l.name.replace('|', '_').replace('\n', ' ')).append('\n');
            }
            z.putNextEntry(new ZipEntry("meta.txt"));
            z.write(m.toString().getBytes("UTF-8"));
            z.closeEntry();

            for (int i = 0; i < snaps.length; i++) {
                Layer.Packed pk = snaps[i];
                snaps[i] = null;
                Bitmap b = Layer.cropBitmap(pk);
                if (b == null) continue;
                z.putNextEntry(new ZipEntry(String.format(Locale.US, "layer_%03d.png", i)));
                b.compress(Bitmap.CompressFormat.PNG, 100, z);
                z.closeEntry();
                b.recycle();
            }
            z.putNextEntry(new ZipEntry("seleccion.bin"));
            z.write(p.selection);
            z.closeEntry();
            z.finish();
        } finally {
            try {
                z.close();
            } catch (IOException ignored) {
            }
        }
    }

    public static Loaded load(InputStream in) throws IOException {
        Map<String, byte[]> blobs = new HashMap<String, byte[]>();
        ZipInputStream z = new ZipInputStream(new BufferedInputStream(in));
        try {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                blobs.put(e.getName(), readAll(z));
                z.closeEntry();
            }
        } finally {
            try {
                z.close();
            } catch (IOException ignored) {
            }
        }
        byte[] meta = blobs.get("meta.txt");
        if (meta == null) throw new IOException("No es una obra de Paint Zeta");
        String[] lines = new String(meta, "UTF-8").split("\n");
        if (lines.length > 0 && lines[0].trim().equals("v3")) return loadV3(lines, blobs);
        if (lines.length > 0 && lines[0].trim().equals("v2")) return loadV2(lines, blobs);
        return loadV1(lines, blobs);
    }

    private static Loaded loadV2(String[] lines, Map<String, byte[]> blobs) throws IOException {
        String[] wh = lines[1].trim().split(" ");
        int w = parse(wh[0], 1), h = parse(wh[1], 1);
        Project p = new Project(w, h);
        int color = parse(lines[2], 0xFFE05A5A);
        int active = parse(lines[3], 0);
        int n = parse(lines[4], 0);
        for (int i = 0; i < n && 5 + i < lines.length; i++) {
            String[] parts = lines[5 + i].split("\\|", 3);
            byte[] png = blobs.get(String.format(Locale.US, "layer_%03d.png", i));
            if (png == null) continue;
            int[] px = decode(png, w, h);
            if (px == null) continue;
            Layer l = new Layer(parts.length >= 3 ? parts[2] : "capa_" + (i + 1), px);
            l.visible = parts.length < 1 || "1".equals(parts[0]);
            l.opacity = parts.length >= 2 ? parse(parts[1], 255) : 255;
            l.pack(w, h);
            p.layers.add(l);
            blobs.remove(String.format(Locale.US, "layer_%03d.png", i));
        }
        if (p.layers.isEmpty()) throw new IOException("La obra no tiene capas");
        byte[] sel = blobs.get("seleccion.bin");
        if (sel != null && sel.length == w * h) System.arraycopy(sel, 0, p.selection, 0, sel.length);
        p.active = active >= Project.SEL && active < p.layers.size() ? active : 0;
        p.markDirty();
        Loaded r = new Loaded();
        r.project = p;
        r.color = color;
        return r;
    }

    private static Loaded loadV3(String[] lines, Map<String, byte[]> blobs) throws IOException {
        String[] wh = lines[1].trim().split(" ");
        int w = parse(wh[0], 1), h = parse(wh[1], 1);
        Project p = new Project(w, h);
        int color = parse(lines[2], 0xFFE05A5A);
        int active = parse(lines[3], 0);
        int n = parse(lines[4], 0);
        for (int i = 0; i < n && 5 + i < lines.length; i++) {
            String[] parts = lines[5 + i].split("\\|", 7);
            if (parts.length < 7) continue;
            int x = parse(parts[2], 0), y = parse(parts[3], 0), cw = parse(parts[4], 0), ch = parse(parts[5], 0);
            String name = parts[6];
            Layer l;
            String key = String.format(Locale.US, "layer_%03d.png", i);
            byte[] png = blobs.get(key);
            if (png == null || cw <= 0 || ch <= 0) {
                l = new Layer(name, w, h);
            } else {
                int[] crop = decode(png, cw, ch);
                blobs.remove(key);
                if (crop == null || x < 0 || y < 0 || x + cw > w || y + ch > h) continue;
                l = Layer.fromCrop(name, x, y, cw, ch, w, h, crop);
            }
            l.visible = "1".equals(parts[0]);
            l.opacity = parse(parts[1], 255);
            p.layers.add(l);
        }
        if (p.layers.isEmpty()) throw new IOException("La obra no tiene capas");
        byte[] sel = blobs.get("seleccion.bin");
        if (sel != null && sel.length == w * h) System.arraycopy(sel, 0, p.selection, 0, sel.length);
        p.active = active >= Project.SEL && active < p.layers.size() ? active : 0;
        p.markDirty();
        Loaded r = new Loaded();
        r.project = p;
        r.color = color;
        return r;
    }

    /** Obras de la version anterior: imagen + recortes. Se pasan a capas de verdad. */
    private static Loaded loadV1(String[] lines, Map<String, byte[]> blobs) throws IOException {
        byte[] basePng = blobs.get("base.png");
        if (basePng == null) throw new IOException("Obra incompleta");
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap base = BitmapFactory.decodeByteArray(basePng, 0, basePng.length, o);
        if (base == null) throw new IOException("No se pudo leer la imagen");
        int w = base.getWidth(), h = base.getHeight();
        int[] img = new int[w * h];
        base.getPixels(img, 0, w, 0, 0, w, h);
        base.recycle();

        Project p = new Project(w, h);
        boolean baseVisible = true;
        byte[] st = blobs.get("estado.txt");
        if (st != null) {
            String[] parts = new String(st, "UTF-8").trim().split(" ");
            if (parts.length >= 1) baseVisible = "1".equals(parts[0]);
        }
        Layer imagen = new Layer("imagen", img);
        imagen.visible = baseVisible;
        p.layers.add(imagen);

        int color = lines.length > 2 ? parse(lines[2], 0xFFE05A5A) : 0xFFE05A5A;
        int n = lines.length > 3 ? parse(lines[3], 0) : 0;
        for (int i = 0; i < n && 4 + i < lines.length; i++) {
            byte[] mask = blobs.get(String.format(Locale.US, "capa_%03d.bin", i));
            if (mask == null || mask.length != w * h) continue;
            String[] parts = lines[4 + i].split("\\|", 3);
            int[] src = img;
            byte[] opng = blobs.get(String.format(Locale.US, "capa_%03d_px.png", i));
            byte[] otxt = blobs.get(String.format(Locale.US, "capa_%03d_px.txt", i));
            if (opng != null && otxt != null) {
                String[] r = new String(otxt, "UTF-8").trim().split(" ");
                Bitmap ob = BitmapFactory.decodeByteArray(opng, 0, opng.length);
                if (r.length == 4 && ob != null) {
                    int l = parse(r[0], 0), t = parse(r[1], 0), rw = ob.getWidth(), rh = ob.getHeight();
                    src = img.clone();
                    int[] row = new int[rw];
                    for (int y = 0; y < rh && t + y < h; y++) {
                        ob.getPixels(row, 0, rw, 0, y, rw, 1);
                        for (int x = 0; x < rw && l + x < w; x++) src[(t + y) * w + l + x] = row[x];
                    }
                    ob.recycle();
                }
            }
            int[] px = new int[w * h];
            for (int k = 0; k < px.length; k++) {
                int a = mask[k] & 0xFF;
                px[k] = a == 0 ? 0 : ((a << 24) | (src[k] & 0x00FFFFFF));
            }
            Layer lay = new Layer(parts.length >= 3 ? parts[2] : "capa_" + (i + 1), px);
            lay.visible = parts.length < 1 || "1".equals(parts[0]);
            lay.opacity = parts.length >= 2 ? parse(parts[1], 255) : 255;
            lay.pack(w, h);
            p.layers.add(lay);
        }
        byte[] sel = blobs.get("seleccion.bin");
        if (sel != null && sel.length == w * h) System.arraycopy(sel, 0, p.selection, 0, sel.length);
        p.active = p.layers.size() - 1;
        p.markDirty();
        Loaded r = new Loaded();
        r.project = p;
        r.color = color;
        return r;
    }

    private static int[] decode(byte[] png, int w, int h) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        o.inPremultiplied = false;
        Bitmap b = BitmapFactory.decodeByteArray(png, 0, png.length, o);
        if (b == null || b.getWidth() != w || b.getHeight() != h) return null;
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        b.recycle();
        return px;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    private static int parse(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }
}
