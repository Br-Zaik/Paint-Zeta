package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

/**
 * Una capa de verdad, como en Ibis: tiene sus propios pixeles con
 * transparencia. Se puede pintar en cualquier lado, incluso donde esta vacia.
 *
 * Los pixeles van en ARGB sin premultiplicar: el alfa esta aparte del color.
 *
 * Para gastar poca memoria, las capas que no se estan usando se guardan
 * "empacadas": solo el rectangulo donde hay algo dibujado. Un pelo o un brazo
 * ocupan una parte chica de la imagen, asi que la capa pesa mucho menos. La
 * capa elegida se desempaca sola la primera vez que se pinta en ella (px()).
 */
public class Layer {

    /** Recorte con contenido: rectangulo x,y,w,h dentro del lienzo pw x ph. No se modifica nunca. */
    public static final class Packed {
        public final int x, y, w, h, pw, ph;
        public final int[] px;

        Packed(int x, int y, int w, int h, int pw, int ph, int[] px) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.pw = pw;
            this.ph = ph;
            this.px = px;
        }

        public boolean empty() {
            return w <= 0 || h <= 0;
        }

        public int at(int sx, int sy) {
            int lx = sx - x, ly = sy - y;
            if (lx < 0 || ly < 0 || lx >= w || ly >= h) return 0;
            return px[ly * w + lx];
        }
    }

    public String name;
    public boolean visible = true;
    /** 0 a 255. */
    public int opacity = 255;

    private volatile int[] dense;
    private volatile Packed packed;

    public Layer(String name, int[] px) {
        this.name = name;
        this.dense = px;
    }

    /** Capa vacia que no gasta memoria hasta que se pinta. */
    public Layer(String name, int w, int h) {
        this.name = name;
        this.packed = new Packed(0, 0, 0, 0, w, h, new int[0]);
    }

    private Layer(String name, Packed p) {
        this.name = name;
        this.packed = p;
    }

    /** Capa creada directo desde un recorte (al abrir obras o separar partes). */
    public static Layer fromCrop(String name, int x, int y, int w, int h, int pw, int ph, int[] crop) {
        return new Layer(name, new Packed(x, y, w, h, pw, ph, crop));
    }

    /** Los pixeles de todo el lienzo para editar. Si estaba empacada, la desempaca. */
    public int[] px() {
        int[] d = dense;
        if (d != null) return d;
        synchronized (this) {
            d = dense;
            if (d != null) return d;
            Packed p = packed;
            d = new int[p.pw * p.ph];
            for (int yy = 0; yy < p.h; yy++) System.arraycopy(p.px, yy * p.w, d, (p.y + yy) * p.pw + p.x, p.w);
            dense = d;
            packed = null;
            return d;
        }
    }

    /** Reemplaza todos los pixeles (girar, voltear). */
    public synchronized void setPx(int[] px) {
        dense = px;
        packed = null;
    }

    public boolean isPacked() {
        return dense == null;
    }

    /** Empaca la capa: se queda solo con el rectangulo que tiene algo. */
    public synchronized void pack(int w, int h) {
        int[] d = dense;
        if (d == null || d.length != w * h) return;
        Packed p = crop(d, w, h);
        packed = p;
        dense = null;
    }

    /** Recorta sin tocar la capa. */
    private static Packed crop(int[] d, int w, int h) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w, first = -1, last = -1;
            for (int x = 0; x < w; x++) {
                if ((d[row + x] >>> 24) != 0) {
                    first = x;
                    break;
                }
            }
            if (first < 0) continue;
            for (int x = w - 1; x >= first; x--) {
                if ((d[row + x] >>> 24) != 0) {
                    last = x;
                    break;
                }
            }
            if (first < minX) minX = first;
            if (last > maxX) maxX = last;
            if (y < minY) minY = y;
            maxY = y;
        }
        if (maxX < 0) return new Packed(0, 0, 0, 0, w, h, new int[0]);
        int cw = maxX - minX + 1, ch = maxY - minY + 1;
        int[] out = new int[cw * ch];
        for (int y = 0; y < ch; y++) System.arraycopy(d, (minY + y) * w + minX, out, y * cw, cw);
        return new Packed(minX, minY, cw, ch, w, h, out);
    }

    /**
     * Foto del contenido para leer sin cambiar la capa (sirve desde otro hilo,
     * por ejemplo al guardar). Si la capa esta abierta, la recorta en una copia.
     */
    public Packed snapshot(int w, int h) {
        int[] d = dense;
        if (d != null && d.length == w * h) return crop(d, w, h);
        Packed p = packed;
        if (p != null) return p;
        d = dense;
        if (d != null && d.length == w * h) return crop(d, w, h);
        return new Packed(0, 0, 0, 0, w, h, new int[0]);
    }

    /** Lee un pixel sin desempacar. */
    public int at(int x, int y, int w) {
        int[] d = dense;
        if (d != null) return d[y * w + x];
        Packed p = packed;
        if (p != null) return p.at(x, y);
        d = dense;
        return d == null ? 0 : d[y * w + x];
    }

    /** Lo que hace falta para leer rapido una fila: el arreglo completo o el recorte. */
    public int[] denseOrNull() {
        return dense;
    }

    public Packed packedOrNull() {
        return packed;
    }

    /** Copia todo el lienzo a out (tamano w*h) sin desempacar la capa. */
    public void copyTo(int[] out, int w, int h) {
        int[] d = dense;
        if (d != null && d.length == out.length) {
            System.arraycopy(d, 0, out, 0, out.length);
            return;
        }
        Packed p = snapshot(w, h);
        java.util.Arrays.fill(out, 0);
        for (int yy = 0; yy < p.h; yy++) System.arraycopy(p.px, yy * p.w, out, (p.y + yy) * w + p.x, p.w);
    }

    /** Rectangulo con contenido (null si esta vacia). */
    public Rect bounds(int w, int h) {
        Packed p = snapshot(w, h);
        if (p.empty()) return null;
        return new Rect(p.x, p.y, p.x + p.w, p.y + p.h);
    }

    /** Bitmap solo del recorte, para guardar la obra rapido y liviano. */
    public static Bitmap cropBitmap(Packed p) {
        if (p.empty()) return null;
        Bitmap b = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        b.setPixels(p.px, 0, p.w, 0, 0, p.w, p.h);
        return b;
    }

    /** Memoria que ocupa ahora (aprox, en bytes). */
    public long memory() {
        int[] d = dense;
        if (d != null) return (long) d.length * 4;
        Packed p = packed;
        return p == null ? 0 : (long) p.px.length * 4;
    }

    /** Copia empacada: gasta solo lo que ocupa el dibujo. */
    public Layer copy(String newName, int w, int h) {
        Layer l = new Layer(newName, snapshot(w, h));
        l.visible = visible;
        l.opacity = opacity;
        return l;
    }
}
