package com.pacco.animecut.core;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Exporta cada capa visible como PNG transparente dentro de un ZIP. Todas del
 * mismo tamano de lienzo, asi entran alineadas en Alight Motion.
 */
public final class Exporter {

    private Exporter() {
    }

    public static int exportZip(ContentResolver cr, Project p, Uri uri, int outW, int outH,
                                int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os));
        zos.setLevel(1);
        int count = 0;
        try {
            int idx = 1;
            for (Layer l : p.layers) {
                if (!l.visible) continue;
                zos.putNextEntry(new ZipEntry(String.format(Locale.US, "%02d_%s.png", idx++, safe(l.name))));
                writePng(p, prepare(p, l, edgeClean), outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            zos.finish();
        } finally {
            try {
                zos.close();
            } catch (IOException ignored) {
            }
        }
        return count;
    }

    public static void exportLayer(ContentResolver cr, Project p, Layer l, Uri uri, int edgeClean)
            throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writePng(p, prepare(p, l, edgeClean), p.w, p.h, bos);
            bos.flush();
        } finally {
            try {
                bos.close();
            } catch (IOException ignored) {
            }
        }
    }

    /**
     * Aplica la opacidad de la capa y, si se pide, limpia el borde: el color
     * de los pixeles semitransparentes se toma de adentro para que no quede
     * halo sobre otro fondo.
     */
    private static int[] prepare(Project p, Layer l, int edgeClean) {
        int n = p.w * p.h;
        int[] out = new int[n];
        l.copyTo(out, p.w, p.h);
        byte[] mask = edgeClean > 0 ? new byte[n] : null;
        for (int i = 0; i < n; i++) {
            int c = out[i];
            int a = ((c >>> 24) * l.opacity) / 255;
            out[i] = (a << 24) | (c & 0x00FFFFFF);
            if (mask != null) mask[i] = (byte) a;
        }
        if (mask == null) return out;
        int[] rgb = new int[n];
        for (int i = 0; i < n; i++) rgb[i] = out[i] | 0xFF000000;
        int bg = edgeClean >= 2 ? Defringe.guessBackground(rgb, mask, p.w, p.h) : 0;
        int[] clean = Defringe.clean(rgb, mask, p.w, p.h, 3, edgeClean >= 2, bg);
        rgb = null;
        for (int i = 0; i < n; i++) out[i] = (out[i] & 0xFF000000) | (clean[i] & 0x00FFFFFF);
        return out;
    }

    private static void writePng(Project p, int[] px, int outW, int outH, OutputStream out) {
        Bitmap bmp;
        if (outW <= 0 || outH <= 0 || (outW == p.w && outH == p.h)) {
            bmp = Bitmap.createBitmap(px, p.w, p.h, Bitmap.Config.ARGB_8888);
        } else {
            bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
            int[] row = new int[outW];
            for (int y = 0; y < outH; y++) {
                int y0 = (int) ((long) y * p.h / outH), y1 = Math.max(y0 + 1, (int) ((long) (y + 1) * p.h / outH));
                for (int x = 0; x < outW; x++) {
                    int x0 = (int) ((long) x * p.w / outW), x1 = Math.max(x0 + 1, (int) ((long) (x + 1) * p.w / outW));
                    long sa = 0, sr = 0, sg = 0, sb = 0;
                    int n = 0;
                    for (int yy = y0; yy < Math.min(y1, p.h); yy++) {
                        for (int xx = x0; xx < Math.min(x1, p.w); xx++) {
                            int c = px[yy * p.w + xx];
                            int a = c >>> 24;
                            sa += a;
                            sr += (long) ((c >> 16) & 0xFF) * a;
                            sg += (long) ((c >> 8) & 0xFF) * a;
                            sb += (long) (c & 0xFF) * a;
                            n++;
                        }
                    }
                    row[x] = n == 0 || sa == 0 ? 0 : ((int) (sa / n) << 24) | ((int) (sr / sa) << 16)
                            | ((int) (sg / sa) << 8) | (int) (sb / sa);
                }
                bmp.setPixels(row, 0, outW, 0, y, outW, 1);
            }
        }
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        bmp.recycle();
    }

    private static String safe(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(Character.isLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
        return sb.length() == 0 ? "capa" : sb.toString();
    }
}
