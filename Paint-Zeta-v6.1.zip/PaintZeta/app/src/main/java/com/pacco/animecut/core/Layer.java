package com.pacco.animecut.core;

/**
 * Una capa de verdad, como en Ibis: tiene sus propios pixeles con
 * transparencia. Se puede pintar en cualquier lado, incluso donde esta vacia.
 *
 * Los pixeles van en ARGB sin premultiplicar: el alfa esta aparte del color.
 */
public class Layer {

    public String name;
    public boolean visible = true;
    /** 0 a 255. */
    public int opacity = 255;
    public int[] px;

    public Layer(String name, int[] px) {
        this.name = name;
        this.px = px;
    }

    public Layer copy(String newName) {
        Layer l = new Layer(newName, px.clone());
        l.visible = visible;
        l.opacity = opacity;
        return l;
    }
}
