package com.pacco.animecut.core;

import android.graphics.Bitmap;

/** Miniaturas para el panel de capas, con cuadros grises donde es transparente. */
public final class Thumbs {

    private Thumbs() {
    }

    public static Bitmap forLayer(Project p, Layer l, int size) {
        return make(p, l.px, null, size);
    }

    public static Bitmap forSelection(Project p, int size) {
        return make(p, null, p.selection, size);
    }

    private static Bitmap make(Project p, int[] px, byte[] mask, int size) {
        int max = Math.max(p.w, p.h);
        float s = (float) size / max;
        int tw = Math.max(1, Math.round(p.w * s)), th = Math.max(1, Math.round(p.h * s));
        Bitmap b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        int[] row = new int[tw];
        for (int y = 0; y < th; y++) {
            int sy = Math.min(p.h - 1, y * p.h / th);
            for (int x = 0; x < tw; x++) {
                int sx = Math.min(p.w - 1, x * p.w / tw);
                int i = sy * p.w + sx;
                int checker = (((x >> 2) + (y >> 2)) & 1) == 0 ? 0xFFEDEDED : 0xFFC9C9C9;
                if (px != null) {
                    int c = px[i];
                    row[x] = Project.over(checker, c, c >>> 24);
                } else {
                    int a = mask[i] & 0xFF;
                    row[x] = a == 0 ? checker : Project.over(checker, 0xFF3D7BFF, a);
                }
            }
            b.setPixels(row, 0, tw, 0, y, tw, 1);
        }
        return b;
    }
}
