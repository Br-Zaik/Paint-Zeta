package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.pacco.animecut.core.CloneStamp;
import com.pacco.animecut.core.FloodFill;
import com.pacco.animecut.core.LineArt;
import com.pacco.animecut.core.MaskOps;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.UndoManager;

import java.util.Arrays;

/**
 * El lienzo. Dibuja una copia reducida de la imagen para ir fluido,
 * pero TODAS las operaciones se hacen sobre los pixeles a resolucion real.
 */
public class CanvasView extends View {

    public static final int MODE_PAN = 0;
    public static final int MODE_WAND = 1;
    public static final int MODE_BRUSH = 2;
    public static final int MODE_ERASER = 3;
    public static final int MODE_LASSO = 4;
    public static final int MODE_CLONE = 5;
    public static final int MODE_PAINT = 6;
    public static final int MODE_BUCKET = 7;
    public static final int MODE_PICKER = 8;

    public interface Callback {
        void onBusy(boolean busy);

        void onChanged();

        void onMessage(String msg);

        void onColorPicked(int color);
    }

    private Project project;
    private UndoManager undo;
    private Callback callback;

    private Bitmap display;
    private float dispScale = 1f;
    private Bitmap overlay;
    private int ovScale = 1;

    private final Matrix view = new Matrix();
    private final Matrix inverse = new Matrix();
    private final float[] point = new float[2];
    private ScaleGestureDetector scaleDetector;

    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ovPaint = new Paint();
    private final Paint lassoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int mode = MODE_WAND;
    private int tolerance = 28;
    private float brushRadius = 40f;
    private float hardness = 0.7f;
    private int paintColor = Color.parseColor("#FFE05A5A");
    private boolean wandGlobal = false;
    private boolean useBarrier = false;
    private boolean subtract = false;
    private boolean smart = false;
    private boolean busy = false;
    private int insetTop = 0;
    private int insetBottom = 0;

    private byte[] scratch;
    private byte[] selBackup;
    private int[] pxBackup;

    private boolean drawing = false;
    private boolean panning = false;
    private boolean midValid = false;
    private float lastX, lastY, lastMidX, lastMidY;
    private float ringX, ringY;
    private boolean showRing = false;
    private Rect strokeRect;

    private final Path lasso = new Path();
    private final Path lassoScreen = new Path();

    private boolean cloneSrcSet = false;
    private float cloneSrcX, cloneSrcY;
    private int cloneOffX, cloneOffY;

    private int refColor;
    private boolean selectionActive;
    private Rect lastFillRect;

    public CanvasView(Context c) {
        super(c);
        init(c);
    }

    public CanvasView(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        ovPaint.setFilterBitmap(false);
        lassoPaint.setStyle(Paint.Style.STROKE);
        lassoPaint.setColor(Color.parseColor("#FF3D7BFF"));
        lassoPaint.setStrokeWidth(3f);
        markPaint.setStyle(Paint.Style.STROKE);
        markPaint.setColor(Color.parseColor("#FFFF5252"));
        markPaint.setStrokeWidth(3f);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(Color.parseColor("#CCFFFFFF"));
        ringPaint.setStrokeWidth(2f);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float f = d.getScaleFactor();
                float cur = currentScale();
                if (cur * f < 0.03f || cur * f > 60f) return true;
                view.postScale(f, f, d.getFocusX(), d.getFocusY());
                invalidate();
                return true;
            }
        });
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    public void setProject(Project p) {
        this.project = p;
        this.undo = p == null ? null : new UndoManager(p);
        this.scratch = null;
        this.selBackup = null;
        this.pxBackup = null;
        this.cloneSrcSet = false;
        lasso.reset();
        if (p != null) {
            buildDisplay();
            buildOverlay();
            post(new Runnable() {
                @Override
                public void run() {
                    fit();
                }
            });
        }
        invalidate();
    }

    public Project getProject() {
        return project;
    }

    public void setMode(int m) {
        mode = m;
        invalidate();
    }

    public int getMode() {
        return mode;
    }

    public void setTolerance(int t) {
        tolerance = t;
    }

    public int getTolerance() {
        return tolerance;
    }

    public void setBrushSize(float px) {
        brushRadius = Math.max(0.5f, px / 2f);
    }

    public float getBrushSize() {
        return brushRadius * 2f;
    }

    public void setHardness(float hMin1) {
        hardness = Math.max(0.05f, Math.min(1f, hMin1));
    }

    public void setColor(int c) {
        paintColor = c;
    }

    public int getColor() {
        return paintColor;
    }

    public void setWandGlobal(boolean g) {
        wandGlobal = g;
    }

    public boolean isWandGlobal() {
        return wandGlobal;
    }

    public void setUseBarrier(boolean b) {
        useBarrier = b;
    }

    public boolean isUseBarrier() {
        return useBarrier;
    }

    public void setSubtract(boolean s) {
        subtract = s;
    }

    public boolean isSubtract() {
        return subtract;
    }

    public void setSmart(boolean s) {
        smart = s;
    }

    public boolean isSmart() {
        return smart;
    }

    public void resetCloneSource() {
        cloneSrcSet = false;
        invalidate();
        msg("Toca el punto de donde quieres copiar");
    }

    // ------------------------------------------------------------------
    // Render
    // ------------------------------------------------------------------

    private void buildDisplay() {
        Bitmap old = display;
        int max = Math.max(project.w, project.h);
        float s = max > 2048 ? max / 2048f : 1f;
        int dw = Math.max(1, Math.round(project.w / s));
        int dh = Math.max(1, Math.round(project.h / s));
        Bitmap scaled = Bitmap.createScaledBitmap(project.base, dw, dh, true);
        // Si la imagen ya era pequena createScaledBitmap puede devolver el mismo
        // objeto: hay que copiarlo o al reciclarlo perderiamos el original.
        if (scaled == project.base) scaled = project.base.copy(Bitmap.Config.ARGB_8888, true);
        display = scaled;
        dispScale = (float) project.w / dw;
        if (old != null && old != project.base && !old.isRecycled()) old.recycle();
    }

    public void refreshDisplay() {
        if (project == null) return;
        buildDisplay();
        invalidate();
    }

    private void buildOverlay() {
        if (overlay != null) overlay.recycle();
        int max = Math.max(project.w, project.h);
        ovScale = max > 1440 ? (int) Math.ceil(max / 1440f) : 1;
        int ow = Math.max(1, project.w / ovScale);
        int oh = Math.max(1, project.h / ovScale);
        overlay = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
        paintOverlay(new Rect(0, 0, project.w, project.h));
    }

    private void paintOverlay(Rect r) {
        if (overlay == null || project == null) return;
        int ow = overlay.getWidth();
        int oh = overlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale);
        int y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1);
        int y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            int base = sy * project.w;
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int a = project.selection[base + sx] & 0xFF;
                row[i] = a == 0 ? 0 : (((a * 150) / 255) << 24) | 0x0080FF;
            }
            overlay.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    public void refreshOverlay(Rect r) {
        if (project == null) return;
        if (r == null) r = new Rect(0, 0, project.w, project.h);
        paintOverlay(r);
        invalidate();
    }

    /** Altura que tapan la barra de arriba y el panel de abajo. */
    public void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
    }

    public void fit() {
        if (project == null || getWidth() == 0) return;
        int usable = getHeight() - insetTop - insetBottom;
        if (usable < 80) usable = getHeight();
        float sx = (float) getWidth() / project.w;
        float sy = (float) usable / project.h;
        float s = Math.min(sx, sy) * 0.96f;
        view.reset();
        view.postScale(s, s);
        view.postTranslate((getWidth() - project.w * s) / 2f,
                insetTop + (usable - project.h * s) / 2f);
        invalidate();
    }

    private float currentScale() {
        float[] v = new float[9];
        view.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(Color.parseColor("#FF121212"));
        if (project == null || display == null) return;

        // Al acercar mucho conviene ver el pixel nitido, no borroso.
        float shown = currentScale() * dispScale;
        bmpPaint.setFilterBitmap(shown < 1f);

        c.save();
        c.concat(view);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, bmpPaint);
        c.restore();

        if (overlay != null) {
            c.save();
            c.concat(view);
            c.scale(ovScale, ovScale);
            c.drawBitmap(overlay, 0, 0, ovPaint);
            c.restore();
        }

        if (mode == MODE_LASSO && !lasso.isEmpty()) {
            lassoScreen.reset();
            lasso.transform(view, lassoScreen);
            c.drawPath(lassoScreen, lassoPaint);
        }

        if (mode == MODE_CLONE && cloneSrcSet) {
            point[0] = cloneSrcX;
            point[1] = cloneSrcY;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 22f, markPaint);
            c.drawLine(point[0] - 30, point[1], point[0] + 30, point[1], markPaint);
            c.drawLine(point[0], point[1] - 30, point[0], point[1] + 30, markPaint);
        }

        if (showRing && usesBrush()) {
            c.drawCircle(ringX, ringY, brushRadius * currentScale(), ringPaint);
        }
    }

    private boolean usesBrush() {
        return mode == MODE_BRUSH || mode == MODE_ERASER || mode == MODE_CLONE || mode == MODE_PAINT;
    }

    // ------------------------------------------------------------------
    // Toque
    // ------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (project == null || busy) return true;
        scaleDetector.onTouchEvent(e);
        int action = e.getActionMasked();

        if (e.getPointerCount() >= 2) {
            if (drawing) endStroke();
            panning = false;
            showRing = false;
            handleTwoFingers(e);
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                midValid = false;
                ringX = e.getX();
                ringY = e.getY();
                showRing = usesBrush();
                if (mode == MODE_PAN) {
                    panning = true;
                    lastX = e.getX();
                    lastY = e.getY();
                } else {
                    startStroke(e.getX(), e.getY());
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                ringX = e.getX();
                ringY = e.getY();
                if (panning) {
                    view.postTranslate(e.getX() - lastX, e.getY() - lastY);
                    lastX = e.getX();
                    lastY = e.getY();
                    invalidate();
                } else if (drawing) {
                    moveStroke(e.getX(), e.getY());
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (drawing) endStroke();
                panning = false;
                midValid = false;
                showRing = false;
                invalidate();
                return true;
        }
        return true;
    }

    private void handleTwoFingers(MotionEvent e) {
        float mx = (e.getX(0) + e.getX(1)) / 2f;
        float my = (e.getY(0) + e.getY(1)) / 2f;
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_POINTER_DOWN || !midValid) {
            lastMidX = mx;
            lastMidY = my;
            midValid = true;
        } else if (a == MotionEvent.ACTION_MOVE) {
            view.postTranslate(mx - lastMidX, my - lastMidY);
            lastMidX = mx;
            lastMidY = my;
            invalidate();
        }
        if (a == MotionEvent.ACTION_POINTER_UP) midValid = false;
    }

    private void toImage(float x, float y) {
        view.invert(inverse);
        point[0] = x;
        point[1] = y;
        inverse.mapPoints(point);
    }

    private void startStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0];
        float iy = point[1];
        int px = (int) ix;
        int py = (int) iy;
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;

        switch (mode) {
            case MODE_WAND:
                runWand(px, py);
                return;

            case MODE_PICKER:
                if (inside) {
                    paintColor = project.pixels[py * project.w + px] | 0xFF000000;
                    if (callback != null) callback.onColorPicked(paintColor);
                }
                return;

            case MODE_BUCKET:
                runBucket(px, py);
                return;

            case MODE_BRUSH:
            case MODE_ERASER:
                ensureSelBackup();
                System.arraycopy(project.selection, 0, selBackup, 0, selBackup.length);
                refColor = inside ? project.pixels[py * project.w + px] : 0;
                strokeRect = null;
                drawing = true;
                stampBrush(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_PAINT:
                ensurePxBackup();
                System.arraycopy(project.pixels, 0, pxBackup, 0, pxBackup.length);
                selectionActive = project.hasSelection();
                strokeRect = null;
                drawing = true;
                stampPaint(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_LASSO:
                lasso.reset();
                lasso.moveTo(ix, iy);
                drawing = true;
                lastX = ix;
                lastY = iy;
                invalidate();
                return;

            case MODE_CLONE:
                if (!cloneSrcSet) {
                    cloneSrcX = ix;
                    cloneSrcY = iy;
                    cloneSrcSet = true;
                    msg("Origen fijado. Ahora arrastra donde quieres copiarlo");
                    invalidate();
                    return;
                }
                ensurePxBackup();
                System.arraycopy(project.pixels, 0, pxBackup, 0, pxBackup.length);
                cloneOffX = (int) (ix - cloneSrcX);
                cloneOffY = (int) (iy - cloneSrcY);
                strokeRect = null;
                drawing = true;
                stampClone(ix, iy);
                lastX = ix;
                lastY = iy;
                return;
        }
    }

    private void moveStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0];
        float iy = point[1];

        if (mode == MODE_LASSO) {
            lasso.lineTo(ix, iy);
            invalidate();
            return;
        }

        float dx = ix - lastX;
        float dy = iy - lastY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float step = Math.max(0.6f, brushRadius * 0.3f);
        int n = (int) (dist / step);
        for (int i = 1; i <= n; i++) {
            float t = i / (float) n;
            float bx = lastX + dx * t;
            float by = lastY + dy * t;
            if (mode == MODE_CLONE) stampClone(bx, by);
            else if (mode == MODE_PAINT) stampPaint(bx, by);
            else stampBrush(bx, by);
        }
        if (n > 0) {
            lastX = ix;
            lastY = iy;
        }
        invalidate();
    }

    private void endStroke() {
        drawing = false;
        if (mode == MODE_LASSO) {
            applyLasso();
            return;
        }
        if (strokeRect != null) {
            if (mode == MODE_CLONE || mode == MODE_PAINT) {
                undo.recordFromBackup(UndoManager.PIXELS, strokeRect, null, pxBackup);
            } else {
                undo.recordFromBackup(UndoManager.SELECTION, strokeRect, selBackup, null);
            }
            changed();
        }
        strokeRect = null;
    }

    // ------------------------------------------------------------------
    // Herramientas de trazo
    // ------------------------------------------------------------------

    /** Pincel de seleccion. Con "fino" activado solo agarra el color que
     *  tocaste al empezar y respeta el line art: puedes pintar rapido sin
     *  salirte de la figura. */
    private void stampBrush(float cx, float cy) {
        Rect r;
        if (smart) {
            r = smartSelectStamp(cx, cy);
        } else {
            r = MaskOps.stamp(project.selection, project.w, project.h, cx, cy,
                    brushRadius, hardness, mode == MODE_ERASER);
        }
        if (r == null) return;
        grow(r);
        paintOverlay(r);
        invalidate();
    }

    private Rect smartSelectStamp(float cx, float cy) {
        int w = project.w;
        int h = project.h;
        int x0 = (int) Math.floor(cx - brushRadius) - 1;
        int y0 = (int) Math.floor(cy - brushRadius) - 1;
        int x1 = (int) Math.ceil(cx + brushRadius) + 1;
        int y1 = (int) Math.ceil(cy + brushRadius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return null;

        boolean erase = mode == MODE_ERASER;
        float inner = brushRadius * hardness;
        float band = Math.max(1f, brushRadius - inner);

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > brushRadius) continue;
                int i = row + x;
                if (!erase) {
                    if (project.barrier != null && useBarrier && project.barrier[i] != 0) continue;
                    if (!FloodFill.similar(project.pixels[i], refColor, tolerance)) continue;
                }
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (a <= 0f) continue;
                int cur = project.selection[i] & 0xFF;
                int add = (int) (a * 255f);
                if (erase) {
                    int v = cur - add;
                    project.selection[i] = (byte) (v < 0 ? 0 : v);
                } else if (add > cur) {
                    project.selection[i] = (byte) add;
                }
            }
        }
        return new Rect(x0, y0, x1, y1);
    }

    /** Pincel de color. Si hay seleccion activa solo pinta dentro de ella,
     *  y con "fino" no pisa las lineas del dibujo. */
    private void stampPaint(float cx, float cy) {
        int w = project.w;
        int h = project.h;
        int x0 = (int) Math.floor(cx - brushRadius) - 1;
        int y0 = (int) Math.floor(cy - brushRadius) - 1;
        int x1 = (int) Math.ceil(cx + brushRadius) + 1;
        int y1 = (int) Math.ceil(cy + brushRadius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return;

        float inner = brushRadius * hardness;
        float band = Math.max(1f, brushRadius - inner);

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > brushRadius) continue;
                int i = row + x;
                if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (a <= 0f) continue;
                project.pixels[i] = blend(project.pixels[i], paintColor, a);
            }
        }
        Rect r = new Rect(x0, y0, x1, y1);
        grow(r);
        project.pushPixels(r);
        updateDisplayRegion(r);
    }

    private void stampClone(float cx, float cy) {
        Rect r = CloneStamp.stamp(project.pixels, pxBackup, project.w, project.h, cx, cy,
                brushRadius, hardness, cloneOffX, cloneOffY);
        if (r == null) return;
        grow(r);
        project.pushPixels(r);
        updateDisplayRegion(r);
    }

    private static int blend(int dst, int src, float a) {
        int ia = (int) (a * 256f);
        if (ia <= 0) return dst;
        if (ia > 256) ia = 256;
        int r = (((src >> 16) & 0xFF) * ia + ((dst >> 16) & 0xFF) * (256 - ia)) >> 8;
        int g = (((src >> 8) & 0xFF) * ia + ((dst >> 8) & 0xFF) * (256 - ia)) >> 8;
        int b = ((src & 0xFF) * ia + (dst & 0xFF) * (256 - ia)) >> 8;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Actualiza solo el trozo de la copia de pantalla que cambio. */
    private void updateDisplayRegion(Rect r) {
        if (display == null) return;
        int dw = display.getWidth();
        int dh = display.getHeight();
        int x0 = Math.max(0, (int) (r.left / dispScale));
        int y0 = Math.max(0, (int) (r.top / dispScale));
        int x1 = Math.min(dw, (int) Math.ceil(r.right / dispScale));
        int y1 = Math.min(dh, (int) Math.ceil(r.bottom / dispScale));
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, (int) (y * dispScale));
            int base = sy * project.w;
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (int) ((x0 + i) * dispScale));
                row[i] = project.pixels[base + sx];
            }
            display.setPixels(row, 0, rw, x0, y, rw, 1);
        }
        invalidate();
    }

    private void grow(Rect r) {
        if (strokeRect == null) strokeRect = new Rect(r);
        else strokeRect.union(r);
    }

    private void applyLasso() {
        Path closed = new Path(lasso);
        closed.close();
        RectF b = new RectF();
        closed.computeBounds(b, true);
        int l = Math.max(0, (int) Math.floor(b.left));
        int t = Math.max(0, (int) Math.floor(b.top));
        int rr = Math.min(project.w, (int) Math.ceil(b.right) + 1);
        int bb = Math.min(project.h, (int) Math.ceil(b.bottom) + 1);
        lasso.reset();
        if (l >= rr || t >= bb) {
            invalidate();
            return;
        }
        Rect region = new Rect(l, t, rr, bb);
        undo.record(UndoManager.SELECTION, region);

        int rw = region.width();
        int rh = region.height();
        Bitmap tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        pt.setStyle(Paint.Style.FILL);
        c.translate(-l, -t);
        c.drawPath(closed, pt);

        int[] row = new int[rw];
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (t + y) * project.w + l;
            for (int x = 0; x < rw; x++) {
                int a = (row[x] >>> 24);
                if (a == 0) continue;
                if (subtract) {
                    int cur = project.selection[off + x] & 0xFF;
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > (project.selection[off + x] & 0xFF)) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        paintOverlay(region);
        invalidate();
        changed();
    }

    private void runWand(final int sx, final int sy) {
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                byte[] barrier = useBarrier ? project.barrier : null;
                lastFillRect = wandGlobal
                        ? FloodFill.global(project.pixels, project.w, project.h, scratch, sx, sy, tolerance, false)
                        : FloodFill.contiguous(project.pixels, project.w, project.h, scratch, barrier, sx, sy, tolerance, false);
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.record(UndoManager.SELECTION, r);
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * project.w;
                        for (int x = r.left; x < r.right; x++) {
                            if (scratch[off + x] == 0) continue;
                            project.selection[off + x] = (byte) (subtract ? 0 : 255);
                        }
                    }
                    paintOverlay(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    /** Balde de pintura. Respeta el line art y, si hay seleccion, se queda dentro. */
    private void runBucket(final int sx, final int sy) {
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return;
        setBusy(true);
        ensureScratch();
        final boolean useSel = project.hasSelection();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                byte[] barrier = useBarrier ? project.barrier : null;
                lastFillRect = FloodFill.contiguous(project.pixels, project.w, project.h,
                        scratch, barrier, sx, sy, tolerance, false);
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.record(UndoManager.PIXELS, r);
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * project.w;
                        for (int x = r.left; x < r.right; x++) {
                            int i = off + x;
                            if (scratch[i] == 0) continue;
                            float a = 1f;
                            if (useSel) a = (project.selection[i] & 0xFF) / 255f;
                            if (a <= 0f) continue;
                            project.pixels[i] = blend(project.pixels[i], paintColor, a);
                        }
                    }
                    project.pushPixels(r);
                    updateDisplayRegion(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    private void ensureScratch() {
        if (scratch == null || scratch.length != project.w * project.h)
            scratch = new byte[project.w * project.h];
    }

    private void ensureSelBackup() {
        if (selBackup == null || selBackup.length != project.w * project.h)
            selBackup = new byte[project.w * project.h];
    }

    private void ensurePxBackup() {
        if (pxBackup == null || pxBackup.length != project.w * project.h)
            pxBackup = new int[project.w * project.h];
    }

    private void setBusy(boolean b) {
        busy = b;
        if (callback != null) callback.onBusy(b);
    }

    private void changed() {
        if (callback != null) callback.onChanged();
    }

    private void msg(String s) {
        if (callback != null) callback.onMessage(s);
    }

    // ------------------------------------------------------------------
    // Acciones de la barra
    // ------------------------------------------------------------------

    public void doUndo() {
        if (undo == null) return;
        Rect r = undo.undo();
        if (r != null) applyRestored(r);
    }

    public void doRedo() {
        if (undo == null) return;
        Rect r = undo.redo();
        if (r != null) applyRestored(r);
    }

    private void applyRestored(Rect r) {
        if (undo.lastRestoredType() == UndoManager.PIXELS) {
            updateDisplayRegion(r);
        } else {
            paintOverlay(r);
        }
        invalidate();
        changed();
    }

    public void clearSelection() {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void invertSelection() {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        MaskOps.invert(project.selection);
        refreshOverlay(null);
        changed();
    }

    public void loadSelection(byte[] mask) {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        MaskOps.copyInto(project.selection, mask);
        refreshOverlay(null);
        changed();
    }

    /** kind: 0 expandir, 1 contraer, 2 suavizar, 3 endurecer */
    public void edgeOp(final int kind, final int radius) {
        if (project == null) return;
        setBusy(true);
        undo.record(UndoManager.SELECTION, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        MaskOps.dilate(project.selection, project.w, project.h, radius);
                        break;
                    case 1:
                        MaskOps.erode(project.selection, project.w, project.h, radius);
                        break;
                    case 2:
                        MaskOps.feather(project.selection, project.w, project.h, radius);
                        break;
                    case 4:
                        MaskOps.closeHoles(project.selection, project.w, project.h, radius);
                        break;
                    default:
                        MaskOps.threshold(project.selection, 128);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void buildBarrier(final int threshold, final int closeGap) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                project.barrier = LineArt.build(project.pixels, project.w, project.h,
                        threshold, closeGap);
            }
        }, new Runnable() {
            @Override
            public void run() {
                useBarrier = true;
                setBusy(false);
                msg("Line art listo: la varita y el balde ya no se escapan por las lineas");
                changed();
            }
        });
    }

    /** Gira o voltea todo el documento: imagen, seleccion, line art y capas. */
    public void transform(final int kind) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        project.rotate90(true);
                        break;
                    case 1:
                        project.rotate90(false);
                        break;
                    case 2:
                        project.flip(true);
                        break;
                    default:
                        project.flip(false);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.clear();
                buildDisplay();
                buildOverlay();
                fit();
                setBusy(false);
                msg("Listo. El historial de deshacer se reinicia al girar");
                changed();
            }
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (project != null && ow == 0) fit();
    }
}
