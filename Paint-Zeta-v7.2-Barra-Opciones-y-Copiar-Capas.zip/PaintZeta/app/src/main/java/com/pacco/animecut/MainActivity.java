package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.core.ProjectStore;
import com.pacco.animecut.core.Thumbs;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.view.CanvasView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements CanvasView.Callback {

    private static final int[] PALETTE = {
            0xFF000000, 0xFF444444, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF, 0xFF7A4A2B,
            0xFFE05A5A, 0xFFFF7A45, 0xFFFFB03A, 0xFFFFE05C, 0xFFB5E05A, 0xFF4FC66B,
            0xFF3DD6C0, 0xFF4DA3FF, 0xFF3D6BFF, 0xFF7B5CFF, 0xFFB558FF, 0xFFFF6FC3,
            0xFFFFE0C4, 0xFFF5C9A6, 0xFFD9A377, 0xFF9C6B4A, 0xFF2B2B3A, 0xFF1B3358
    };

    private CanvasView canvas;
    private TextView status;
    private TextView sliderLabel;
    private SeekBar slider;
    private TextView opacityValue;
    private SeekBar opacitySlider;
    private LinearLayout contextActionRow;
    private boolean updatingContext = false;

    private ActivityResultLauncher<String> openImage;
    private ActivityResultLauncher<String> importImageLayer;
    private boolean updatingLayerOpacity = false;
    private final android.os.Handler edgePreviewHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private ActivityResultLauncher<String> createZip;
    private ActivityResultLauncher<String> createPng;
    private ActivityResultLauncher<String> createProject;
    private ActivityResultLauncher<String[]> openProject;

    public static final String EXTRA_PROJECT = "obra";

    private String projectId;

    private byte[] pendingPngMask;
    private Layer pendingPngLayer;
    private String lastError;
    private int lastExportCount;
    private int outW, outH;
    private int edgeClean = 1;
    private boolean saving = false;
    private final android.os.Handler previewHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private ProjectIO.Loaded loaded;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        canvas = findViewById(R.id.canvas);
        status = findViewById(R.id.status);
        sliderLabel = findViewById(R.id.sliderLabel);
        slider = findViewById(R.id.slider);
        opacityValue = findViewById(R.id.opacityValue);
        opacitySlider = findViewById(R.id.opacitySlider);
        canvas.setCallback(this);
        contextActionRow = findViewById(R.id.contextActionRow);

        openImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) loadImage(uri);
                    }
                });

        importImageLayer = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null) importAsLayer(uri);
        });

        createZip = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/zip"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportZip(uri);
                    }
                });

        createPng = registerForActivityResult(new ActivityResultContracts.CreateDocument("image/png"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportPng(uri);
                    }
                });

        createProject = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) saveProjectTo(uri);
                    }
                });

        openProject = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) openProjectFrom(uri);
                    }
                });

        tool(R.id.btnWand, CanvasView.MODE_WAND);
        tool(R.id.btnScissors, CanvasView.MODE_SCISSORS);
        tool(R.id.btnMove, CanvasView.MODE_MOVE);
        tool(R.id.btnBrush, CanvasView.MODE_BRUSH);
        tool(R.id.btnEraser, CanvasView.MODE_ERASE_PIXELS);
        tool(R.id.btnSelEraser, CanvasView.MODE_ERASER);
        tool(R.id.btnLasso, CanvasView.MODE_LASSO);
        tool(R.id.btnClone, CanvasView.MODE_CLONE);
        tool(R.id.btnPaint, CanvasView.MODE_PAINT);
        tool(R.id.btnBucket, CanvasView.MODE_BUCKET);
        tool(R.id.btnPicker, CanvasView.MODE_PICKER);
        tool(R.id.btnPan, CanvasView.MODE_PAN);

        // La tira lateral compacta queda visible; los tres puntos despliegan TODO.
        quickTool(R.id.railWand, CanvasView.MODE_WAND);
        quickTool(R.id.railLasso, CanvasView.MODE_LASSO);
        quickTool(R.id.railPaint, CanvasView.MODE_PAINT);
        quickTool(R.id.railEraser, CanvasView.MODE_ERASE_PIXELS);
        quickTool(R.id.railBrush, CanvasView.MODE_BRUSH);
        quickTool(R.id.railBucket, CanvasView.MODE_BUCKET);
        quickTool(R.id.railPicker, CanvasView.MODE_PICKER);
        quickTool(R.id.railMove, CanvasView.MODE_MOVE);
        quickTool(R.id.railPan, CanvasView.MODE_PAN);
        click(R.id.railMore, () -> toggleToolPalette());
        click(R.id.btnToolbox, () -> toggleToolPalette());
        click(R.id.btnActiveTool, () -> showContextHelp());
        click(R.id.btnOpen, () -> openImage.launch("image/*"));
        click(R.id.btnFilter, () -> { closeToolPalette(); filtersDialog(); });
        click(R.id.btnBlank, () -> { closeToolPalette(); blankCanvasDialog(); });
        click(R.id.btnText, () -> { closeToolPalette(); textLayerDialog(); });
        click(R.id.btnStabilizer, () -> stabilizerDialog());
        click(R.id.btnGrid, () -> gridDialog());
        click(R.id.btnImportLayer, () -> { if (needProject()) importImageLayer.launch("image/*"); });
        bindLayerControls();
        click(R.id.btnSizeMinus, () -> slider.setProgress(Math.max(0, slider.getProgress() - 2)));
        click(R.id.btnSizePlus, () -> slider.setProgress(Math.min(slider.getMax(), slider.getProgress() + 2)));
        click(R.id.btnOpacityMinus, () -> opacitySlider.setProgress(Math.max(1, opacitySlider.getProgress() - 5)));
        click(R.id.btnOpacityPlus, () -> opacitySlider.setProgress(Math.min(100, opacitySlider.getProgress() + 5)));
        click(R.id.btnMenu, new Runnable() {
            public void run() {
                mainMenu();
            }
        });
        click(R.id.btnFit, new Runnable() {
            public void run() {
                if (needProject()) canvas.fit();
            }
        });
        click(R.id.btnUndo, new Runnable() {
            public void run() {
                canvas.doUndo();
                updateUi();
            }
        });
        click(R.id.btnRedo, new Runnable() {
            public void run() {
                canvas.doRedo();
                updateUi();
            }
        });
        click(R.id.btnColor, new Runnable() {
            public void run() {
                colorDialog();
            }
        });
        click(R.id.btnSmart, new Runnable() {
            public void run() {
                canvas.setSmart(!canvas.isSmart());
                toast(canvas.isSmart()
                        ? "Pincel fino: se queda en el color que tocas y respeta la linea"
                        : "Pincel normal");
                updateUi();
            }
        });
        click(R.id.btnLineart, new Runnable() {
            public void run() {
                lineArtDialog();
            }
        });
        click(R.id.btnGlobal, new Runnable() {
            public void run() {
                canvas.setWandGlobal(!canvas.isWandGlobal());
                updateUi();
            }
        });
        click(R.id.btnSub, new Runnable() {
            public void run() {
                canvas.setSubtract(!canvas.isSubtract());
                updateUi();
            }
        });
        click(R.id.btnEdge, new Runnable() {
            public void run() {
                edgeDialog();
            }
        });
        click(R.id.btnLayerAdd, new Runnable() {
            public void run() {
                addLayerFromSelection();
            }
        });
        click(R.id.btnLayers, new Runnable() {
            public void run() {
                toggleLayersPanel();
            }
        });
        click(R.id.btnLayersClose, new Runnable() {
            public void run() {
                findViewById(R.id.layersPanel).setVisibility(View.GONE);
            }
        });
        click(R.id.btnLayerFromSel, new Runnable() {
            public void run() {
                addLayerFromSelection();
            }
        });
        click(R.id.btnExport, new Runnable() {
            public void run() {
                exportDialog();
            }
        });
        click(R.id.btnMoreTools, () -> toggleToolPalette());

        installTooltips();

        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                if (fromUser) applySlider(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });

        opacitySlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                if (v < 1) v = 1;
                canvas.setToolOpacity(v / 100f);
                opacityValue.setText("Opac. " + v + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });

        updateUi();
        syncSlider();
        configureContextActions();
        measureBars();
        // Los paneles superpuestos no deben abrirse a la fuerza al iniciar.
        closeToolPalette();

        projectId = getIntent().getStringExtra(EXTRA_PROJECT);
        if (projectId != null) {
            recoverFrom(ProjectStore.fileFor(this, projectId));
        } else {
            openImage.launch("image/*");
        }
    }

    /** Le dice al lienzo cuanto tapan las barras, para centrar bien la imagen. */
    private void measureBars() {
        final View top = findViewById(R.id.topBar);
        final View bottom = findViewById(R.id.bottomPanel);
        top.post(new Runnable() {
            @Override
            public void run() {
                canvas.setInsets(top.getHeight() + dp(12), bottom.getHeight());
                if (canvas.getProject() != null) canvas.fit();
            }
        });
    }

    private void toggleToolPalette() {
        View palette = findViewById(R.id.toolPalette);
        if (palette.getVisibility() == View.VISIBLE) closeToolPalette();
        else {
            findViewById(R.id.layersPanel).setVisibility(View.GONE);
            findViewById(R.id.toolsPanel).setVisibility(View.GONE);
            palette.setVisibility(View.VISIBLE);
        }
    }

    private void closeToolPalette() {
        View palette = findViewById(R.id.toolPalette);
        if (palette != null) {
            boolean wasVisible = palette.getVisibility() == View.VISIBLE;
            palette.setVisibility(View.GONE);
            if (wasVisible && contextActionRow != null) configureContextActions();
        }
    }

    private void toggleWandOptions() {
        closeToolPalette();
        configureContextActions();
        findViewById(R.id.toolsPanel).setVisibility(View.VISIBLE);
        syncSlider();
    }

    /** Opciones inferiores según la herramienta, siempre a mano y sin otra barra gigante. */
    private void configureContextActions() {
        if (contextActionRow == null || updatingContext) return;
        updatingContext = true;
        try {
            contextActionRow.removeAllViews();
            int mode = canvas.getMode();
            boolean select = mode == CanvasView.MODE_WAND || mode == CanvasView.MODE_LASSO
                    || mode == CanvasView.MODE_SCISSORS || mode == CanvasView.MODE_BRUSH
                    || mode == CanvasView.MODE_ERASER;
            View fixedWand = findViewById(R.id.wandActions);
            if (fixedWand != null) fixedWand.setVisibility(mode == CanvasView.MODE_WAND ? View.VISIBLE : View.GONE);
            if (select) {
                action("COPIAR A CAPA", () -> copySelectedPiece());
                action("CÓMO SACAR PIEZA", () -> showExtractGuide());
                action("INVERTIR", () -> {if(needProject())canvas.invertSelection();});
                action("LIMPIAR AZUL", () -> {if(needProject())canvas.clearSelection();});
                if (mode == CanvasView.MODE_LASSO || mode == CanvasView.MODE_SCISSORS) {
                    action("BORDE", () -> edgeDialog());
                }
                if (mode == CanvasView.MODE_SCISSORS) {
                    action("CERRAR FIGURA", () -> {if(needProject())canvas.scissorsClose();});
                }
            } else if (mode == CanvasView.MODE_PAINT || mode == CanvasView.MODE_ERASE_PIXELS
                    || mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_BUCKET) {
                action("COLOR", () -> colorDialog());
                action("DUREZA", () -> hardnessDialog());
                action("ESTABILIZADOR", () -> stabilizerDialog());
                action("NUEVA CAPA", () -> addLayerFromSelection());
                action("CAPAS", () -> toggleLayersPanel());
                action("CÓMO DIBUJAR", () -> showContextHelp());
            } else if (mode == CanvasView.MODE_MOVE) {
                action("CAPAS", () -> toggleLayersPanel());
                action("CÓMO MOVER", () -> showContextHelp());
            } else {
                action("HERRAMIENTAS", () -> toggleToolPalette());
                action("CAPAS", () -> toggleLayersPanel());
            }
            // La misma barra inferior está disponible al cambiar de herramienta.
            findViewById(R.id.toolsPanel).setVisibility(View.VISIBLE);
        } finally { updatingContext = false; }
    }

    private void action(String label, Runnable work) {
        TextView button = new TextView(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(11);
        button.setGravity(android.view.Gravity.CENTER);
        button.setPadding(dp(11), dp(7), dp(11), dp(7));
        button.setBackgroundResource(R.drawable.bg_tool);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(53));
        lp.setMargins(dp(2), 0, dp(2), 0);
        contextActionRow.addView(button, lp);
        button.setOnClickListener(v -> work.run());
    }

    private void copySelectedPiece() {
        if (!needProject()) return;
        if (!canvas.getProject().hasSelection()) {
            showExtractGuide();
            return;
        }
        int before = canvas.getProject().layers.size();
        addLayerFromSelection();
        if (canvas.getProject().layers.size() == before) return;
        // Vista inmediata de la pieza recién copiada y accesible desde el ojo de capas.
        buildLayersPanel();
        findViewById(R.id.toolsPanel).setVisibility(View.GONE);
        findViewById(R.id.layersPanel).setVisibility(View.VISIBLE);
        toast("Copia lista. Oculta el fondo con el ojo para comprobar la transparencia.");
    }

    private void showExtractGuide() {
        new AlertDialog.Builder(this).setTitle("Copiar ojos, pelo o partes del personaje")
            .setMessage("1. Elige VARITA para un color o LAZO para rodear la pieza.\n\n"
                + "2. Acerca con dos dedos y selecciona la parte; debe verse marcada en azul. "
                + "Con RESTAR puedes quitar lo que sobra.\n\n"
                + "3. Toca COPIAR A CAPA, abajo. Se crea una copia independiente y transparente. "
                + "No se destruye el original.\n\n"
                + "4. Abre CAPAS, oculta el fondo con el ojo y comprueba el recorte. "
                + "Repite con cada ojo, pelo, boca o brazo.\n\n"
                + "5. Exporta las capas como PNG alineados para Alight Motion.")
            .setPositiveButton("Elegir varita", (d,w) -> findViewById(R.id.railWand).performClick())
            .setNeutralButton("Elegir lazo", (d,w) -> findViewById(R.id.railLasso).performClick())
            .setNegativeButton("Cerrar", null).show();
    }

    private void showContextHelp() {
        int m = canvas.getMode();
        if(m == CanvasView.MODE_WAND || m == CanvasView.MODE_LASSO
                || m == CanvasView.MODE_SCISSORS || m == CanvasView.MODE_BRUSH
                || m == CanvasView.MODE_ERASER) { showExtractGuide(); return; }
        new AlertDialog.Builder(this).setTitle("Pincel y capas")
            .setMessage("Selecciona PINCEL en la izquierda y dibuja con el dedo. "
                + "El primer deslizador inferior cambia el tamaño y el segundo la opacidad. "
                + "En la barra inferior están DUREZA y ESTABILIZADOR.\n\n"
                + "El botón + de capas crea una capa transparente cuando no hay selección azul. "
                + "Si hay selección azul, copia esa parte a una nueva capa. "
                + "El BORRADOR borra píxeles; PINCEL SELECCIÓN solo cambia la marca azul.")
            .setPositiveButton("Entendido", null).show();
    }

    private void quickTool(int id, int mode) {
        click(id, () -> {
            // Igual que el selector completo: no duplica ni reemplaza la lógica existente.
            int originalId;
            switch (mode) {
                case CanvasView.MODE_WAND: originalId = R.id.btnWand; break;
                case CanvasView.MODE_LASSO: originalId = R.id.btnLasso; break;
                case CanvasView.MODE_PAINT: originalId = R.id.btnPaint; break;
                case CanvasView.MODE_ERASE_PIXELS: originalId = R.id.btnEraser; break;
                case CanvasView.MODE_BRUSH: originalId = R.id.btnBrush; break;
                case CanvasView.MODE_BUCKET: originalId = R.id.btnBucket; break;
                case CanvasView.MODE_PICKER: originalId = R.id.btnPicker; break;
                case CanvasView.MODE_MOVE: originalId = R.id.btnMove; break;
                default: originalId = R.id.btnPan;
            }
            findViewById(originalId).performClick();
        });
    }

    private void mainMenu() {
        final String[] items = {
                "Abrir otra imagen",
                "Ajustes de la varita",
                "Cerrar figura de las tijeras",
                "Refinar borde (pelo y bordes finos)",
                "Rellenar zonas sin pintar",
                "Filtros de limpieza",
                "Estabilizador del trazo",
                "Guia rapida: como se usa",
                "Gama de colores",
                "Copiar seleccion",
                "Cortar seleccion",
                "Pegar",
                "Expandir borde con decimales",
                "Cerrar huecos de la trama",
                "Invertir la seleccion",
                "Limpiar la seleccion",
                "Girar la imagen",
                "Dureza del pincel",
                "Guardar ahora",
                "Guardar copia en un archivo",
                "Que hace cada icono",
                "Crear lienzo blanco para dibujar",
                "Guardar dibujo como PNG"
        };
        new AlertDialog.Builder(this)
                .setTitle("Paint Zeta")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                openImage.launch("image/*");
                                break;
                            case 1:
                                wandDialog();
                                break;
                            case 2:
                                if (needProject()) canvas.scissorsClose();
                                break;
                            case 3:
                                refineDialog();
                                break;
                            case 4:
                                unpaintedDialog();
                                break;
                            case 5:
                                filtersDialog();
                                break;
                            case 6:
                                stabilizerDialog();
                                break;
                            case 7:
                                guideDialog();
                                break;
                            case 8:
                                colorRangeDialog();
                                break;
                            case 9:
                                if (needProject()) canvas.copySelection(false);
                                break;
                            case 10:
                                if (needProject()) canvas.copySelection(true);
                                break;
                            case 11:
                                if (needProject()) canvas.paste(0, 0);
                                break;
                            case 12:
                                expandDialog();
                                break;
                            case 13:
                                closeHolesDialog();
                                break;
                            case 14:
                                if (needProject()) canvas.invertSelection();
                                break;
                            case 15:
                                if (needProject()) canvas.clearSelection();
                                break;
                            case 16:
                                rotateDialog();
                                break;
                            case 17:
                                hardnessDialog();
                                break;
                            case 18:
                                if (needProject()) autosave(true);
                                break;
                            case 19:
                                projectDialog();
                                break;
                            case 20:
                                helpDialog();
                                break;
                            case 21:
                                blankCanvasDialog();
                                break;
                            case 22:
                                if (!needProject()) break;
                                Project original = canvas.getProject();
                                pendingPngLayer = null;
                                pendingPngMask = new byte[]{1};
                                createPng.launch("Paint-Zeta-dibujo.png");
                                break;
                            default: helpDialog(); break;
                        }
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Ajustes de la varita, al estilo de los de Ibis. */
    private void wandDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Fuerza: " + canvas.getTolerance());
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tTol.setText("Fuerza: " + v);
            }
        });
        root.addView(tTol);
        root.addView(sTol);

        final TextView tSoft = new TextView(this);
        final SeekBar sSoft = new SeekBar(this);
        sSoft.setMax(120);
        sSoft.setProgress(canvas.getSoftness());
        tSoft.setText("Suavidad del borde: " + canvas.getSoftness());
        sSoft.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tSoft.setText("Suavidad del borde: " + v);
            }
        });
        root.addView(tSoft);
        root.addView(sSoft);

        final TextView tExp = new TextView(this);
        final SeekBar sExp = new SeekBar(this);
        sExp.setMax(80); // -3.0 .. +5.0 en pasos de 0.1
        sExp.setProgress(Math.round((canvas.getExpansion() + 3f) * 10f));
        tExp.setText(expLabel(canvas.getExpansion()));
        sExp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tExp.setText(expLabel(v / 10f - 3f));
            }
        });
        root.addView(tExp);
        root.addView(sExp);

        final CheckBox cbGap = new CheckBox(this);
        cbGap.setText("Reconocimiento de huecos (linea abierta)");
        cbGap.setChecked(canvas.isGapOn());
        root.addView(cbGap);

        final TextView tGap = new TextView(this);
        final SeekBar sGap = new SeekBar(this);
        sGap.setMax(12);
        sGap.setProgress(canvas.getGapRadius());
        tGap.setText("Tamano del hueco que tapa: " + canvas.getGapRadius() + " px");
        sGap.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tGap.setText("Tamano del hueco que tapa: " + v + " px");
            }
        });
        root.addView(tGap);
        root.addView(sGap);

        final TextView tMode = new TextView(this);
        tMode.setText("Como compara el color");
        tMode.setPadding(0, dp(10), 0, 0);
        root.addView(tMode);
        final RadioGroup rg = new RadioGroup(this);
        String[] names = {"Exacto (RGB)", "Por tono, ignora sombras", "Como lo ve el ojo (Lab)"};
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(1000 + i);
            rg.addView(rb);
        }
        rg.check(1000 + canvas.getColorMode());
        root.addView(rg);

        new AlertDialog.Builder(this)
                .setTitle("Varita y balde")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.setSoftness(sSoft.getProgress());
                        canvas.setExpansion(sExp.getProgress() / 10f - 3f);
                        canvas.setGap(cbGap.isChecked(), Math.max(1, sGap.getProgress()));
                        int m = rg.getCheckedRadioButtonId() - 1000;
                        canvas.setColorMode(m < 0 ? ColorDist.RGB : m);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNeutralButton("Valores de fabrica", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(28);
                        canvas.setSoftness(24);
                        canvas.setExpansion(1.5f);
                        canvas.setGap(false, 4);
                        canvas.setColorMode(ColorDist.RGB);
                        syncSlider();
                        updateUi();
                        toast("Restablecido");
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private String expLabel(float v) {
        return String.format(Locale.US, "Expansion del borde: %.1f px", v);
    }

    /** Gama de colores, con vista previa mientras mueves el margen. */
    private void colorRangeDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView info = new TextView(this);
        info.setText("Se usa el color cargado. Mueve el margen y mira el lienzo: la seleccion se actualiza sola.");
        root.addView(info);

        final View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        lp.topMargin = dp(8);
        sw.setLayoutParams(lp);
        sw.setBackgroundColor(canvas.getColor());
        root.addView(sw);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Margen: " + canvas.getTolerance());
        root.addView(tTol);
        root.addView(sTol);

        final CheckBox replace = new CheckBox(this);
        replace.setText("Reemplazar la seleccion actual");
        replace.setChecked(true);
        root.addView(replace);

        canvas.beginPreview();
        final Runnable[] pending = new Runnable[1];
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, final int v, boolean u) {
                tTol.setText("Margen: " + v);
                if (pending[0] != null) previewHandler.removeCallbacks(pending[0]);
                pending[0] = new Runnable() {
                    @Override
                    public void run() {
                        canvas.previewColorRange(canvas.getColor(), v, replace.isChecked());
                    }
                };
                previewHandler.postDelayed(pending[0], 180);
            }
        });
        canvas.previewColorRange(canvas.getColor(), sTol.getProgress(), replace.isChecked());

        new AlertDialog.Builder(this)
                .setTitle("Gama de colores")
                .setView(scroll)
                .setCancelable(false)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.endPreview(true);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.endPreview(false);
                    }
                })
                .show();
    }

    private void refineDialog() {
        if (!needProject()) return;
        final String[] items = {"Suave (pelo fino)", "Medio", "Fuerte"};
        final int[] rad = {6, 12, 20};
        final float[] eps = {0.0004f, 0.0016f, 0.006f};
        new AlertDialog.Builder(this)
                .setTitle("Refinar borde")
                .setMessage("Hace que el borde de la seleccion siga el dibujo real. Para pelo y bordes finos.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.refineEdge(rad[i], eps[i]);
                    }
                })
                .show();
    }

    private void unpaintedDialog() {
        if (!needProject()) return;
        final String[] items = {"Solo huecos chicos", "Huecos medianos", "Huecos grandes", "Todos los huecos"};
        final int[] vals = {2, 8, 30, 0};
        new AlertDialog.Builder(this)
                .setTitle("Rellenar zonas sin pintar")
                .setMessage("Rellena los huecos que quedaron encerrados dentro de la seleccion, sin deformar el contorno de afuera.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(5, vals[i]);
                    }
                })
                .show();
    }

    private void filtersDialog() {
        if (!needProject()) return;
        final String[] items = {
                "Quitar ruido de JPEG (mediana)",
                "Aplanar tonos (posterizar)",
                "Niveles: mas contraste",
                "Extraer line art"
        };
        new AlertDialog.Builder(this)
                .setTitle("Filtros de limpieza")
                .setMessage("Aplicar uno antes de seleccionar hace que la varita agarre mucho mejor.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                canvas.applyFilter(0, 0, 0, 0);
                                break;
                            case 1:
                                posterizeDialog();
                                break;
                            case 2:
                                canvas.applyFilter(2, 25, 230, 100);
                                break;
                            default:
                                lineArtFilterDialog();
                                break;
                        }
                    }
                })
                .show();
    }

    private void posterizeDialog() {
        final String[] items = {"4 tonos", "6 tonos", "10 tonos", "16 tonos"};
        final int[] vals = {4, 6, 10, 16};
        new AlertDialog.Builder(this)
                .setTitle("Aplanar tonos")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.applyFilter(1, vals[i], 0, 0);
                    }
                })
                .show();
    }

    /** Extraer line art con sus tres controles, como el filtro de Ibis. */
    private void lineArtFilterDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tw = new TextView(this);
        final SeekBar sw = new SeekBar(this);
        sw.setMax(255);
        sw.setProgress(210);
        tw.setText("Blanco: 210");
        sw.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tw.setText("Blanco: " + v);
            }
        });
        root.addView(tw);
        root.addView(sw);

        final TextView tb = new TextView(this);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(255);
        sb.setProgress(40);
        tb.setText("Negro: 40");
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tb.setText("Negro: " + v);
            }
        });
        root.addView(tb);
        root.addView(sb);

        final TextView tm = new TextView(this);
        final SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(50);
        tm.setText("Medio: 50");
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tm.setText("Medio: " + Math.max(1, v));
            }
        });
        root.addView(tm);
        root.addView(sm);

        new AlertDialog.Builder(this)
                .setTitle("Extraer line art")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.applyFilter(3, sw.getProgress(), sb.getProgress(),
                                Math.max(1, sm.getProgress()));
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void stabilizerDialog() {
        LinearLayout root=dialogForm();
        final TextView label=dialogText(root,"Estabilización: "+(int)(canvas.getStabilizer()*100)+"%");
        SeekBar amount=new SeekBar(this); amount.setMax(92);
        amount.setProgress(Math.round(canvas.getStabilizer()*100));root.addView(amount);
        dialogText(root,"Suaviza la brocha al dibujar con el dedo. 0% no introduce retraso.");
        final float initial=canvas.getStabilizer();
        amount.setOnSeekBarChangeListener(new SimpleSeek(){
            @Override public void onProgressChanged(SeekBar b,int n,boolean u){
                label.setText("Estabilización: "+n+"%");canvas.setStabilizer(n/100f);
            }
        });
        new AlertDialog.Builder(this).setTitle("Estabilizador").setView(root)
            .setPositiveButton("Listo",(d,i)->{})
            .setNegativeButton("Cancelar",(d,i)->canvas.setStabilizer(initial))
            .setOnCancelListener(d->canvas.setStabilizer(initial)).show();
    }

    private void gridDialog() {
        if(!needProject())return;
        LinearLayout root=dialogForm();
        final android.widget.CheckBox enabled=new android.widget.CheckBox(this);
        enabled.setText("Mostrar cuadrícula (solo guía)"); enabled.setChecked(canvas.isGridEnabled());root.addView(enabled);
        final TextView label=dialogText(root,"Tamaño: "+canvas.getGridSpacing()+" px");
        SeekBar step=new SeekBar(this);step.setMax(248);step.setProgress(Math.max(0,canvas.getGridSpacing()-8));root.addView(step);
        final android.widget.CheckBox mirror=new android.widget.CheckBox(this);
        mirror.setText("Regla: simetría vertical (dibuja a ambos lados)");
        mirror.setChecked(canvas.isMirrorEnabled());root.addView(mirror);
        final android.widget.CheckBox pixel=new android.widget.CheckBox(this);
        pixel.setText("Zoom pixelado (bordes nítidos)");pixel.setChecked(canvas.isPixelatedZoom());root.addView(pixel);
        final boolean wasEnabled=canvas.isGridEnabled(),wasPixel=canvas.isPixelatedZoom(),wasMirror=canvas.isMirrorEnabled();
        final int wasStep=canvas.getGridSpacing();
        enabled.setOnCheckedChangeListener((b,v)->canvas.setGridEnabled(v));
        pixel.setOnCheckedChangeListener((b,v)->canvas.setPixelatedZoom(v));
        mirror.setOnCheckedChangeListener((b,v)->canvas.setMirrorEnabled(v));
        step.setOnSeekBarChangeListener(new SimpleSeek(){
            @Override public void onProgressChanged(SeekBar b,int n,boolean u){
                int v=n+8;label.setText("Tamaño: "+v+" px");canvas.setGridSpacing(v);
            }
        });
        Runnable restore=()->{canvas.setGridEnabled(wasEnabled);canvas.setGridSpacing(wasStep);
            canvas.setPixelatedZoom(wasPixel);canvas.setMirrorEnabled(wasMirror);};
        new AlertDialog.Builder(this).setTitle("Guías de lienzo").setView(root)
            .setPositiveButton("Listo",(d,i)->{})
            .setNegativeButton("Cancelar",(d,i)->restore.run())
            .setOnCancelListener(d->restore.run()).show();
    }

    private void expandDialog() {
        if (!needProject()) return;
        final String[] items = {"+0.5 px", "+1.0 px", "+1.5 px", "+2.0 px", "-0.5 px", "-1.0 px"};
        final float[] vals = {0.5f, 1f, 1.5f, 2f, -0.5f, -1f};
        new AlertDialog.Builder(this)
                .setTitle("Expandir o contraer con decimales")
                .setMessage("Lo positivo se come el antialias del contorno y quita los cuadraditos blancos.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.expandSelection(vals[i]);
                    }
                })
                .show();
    }

    /** Quita los puntitos que deja la trama del manga dentro de la seleccion. */
    private void closeHolesDialog() {
        if (!needProject()) return;
        final String[] items = {"Puntos chicos (1 px)", "Medianos (2 px)", "Grandes (3 px)", "Muy grandes (5 px)"};
        final int[] vals = {1, 2, 3, 5};
        new AlertDialog.Builder(this)
                .setTitle("Cerrar huecos de la trama")
                .setMessage("Rellena los puntitos blancos que la trama deja dentro de lo que seleccionaste.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(4, vals[i]);
                    }
                })
                .show();
    }

    private void guideIfFirstTime() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("guia", false)) return;
        sp.edit().putBoolean("guia", true).apply();
        guideDialog();
    }

    /** Lo minimo para entender la app. */
    private void guideDialog() {
        String t = "La app trabaja con SELECCION y con COLOR. Son dos cosas distintas.\n\n"
                + "1. SELECCIONAR (se ve azul)\n"
                + "Varita: tocas y agarra el color que tocaste.\n"
                + "Pincel y borrador: corriges esa mancha azul a mano.\n"
                + "El azul no es pintura. Es lo que tienes marcado.\n\n"
                + "2. GUARDARLO COMO CAPA\n"
                + "Cuando el azul cubre la parte que quieres, toca el boton de capas y despues el boton azul de arriba. Esa parte queda guardada y el azul se limpia.\n\n"
                + "3. PINTAR CON COLOR\n"
                + "El circulo de abajo elige el color.\n"
                + "El rodillo pinta con ese color.\n"
                + "El balde rellena una zona entera.\n"
                + "Ojo: si hay algo azul seleccionado, solo se pinta dentro de lo azul. Para pintar libre, limpia la seleccion primero.\n\n"
                + "4. EXPORTAR\n"
                + "La flecha de abajo guarda un ZIP con cada capa en PNG, todas del mismo tamano para Alight Motion.\n\n"
                + "Manten pulsado cualquier boton y te dice como se llama.";
        new AlertDialog.Builder(this)
                .setTitle("Como se usa, en corto")
                .setMessage(t)
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void helpDialog() {
        String t = "ARRIBA\n"
                + "Tres puntos: este menu\n"
                + "Flechas: deshacer y rehacer\n"
                + "Esquinas: encuadrar la imagen\n"
                + "Rombo con mas: crear capa de la seleccion\n"
                + "Rombos: lista de capas\n"
                + "Flecha abajo: exportar el ZIP\n\n"
                + "IZQUIERDA, herramientas\n"
                + "Varita: selecciona el color que tocas\n"
                + "Lazo: rodea una zona con el dedo\n"
                + "Tijeras: la linea se pega sola al contorno\n"
                + "Cuadros con flecha: mover la seleccion\n"
                + "Pincel y goma: corrigen la seleccion\n"
                + "Rodillo: pinta con el color cargado\n"
                + "Balde: rellena de color una zona\n"
                + "Gotero: toma un color de la imagen\n"
                + "Dos cuadros: clonar, copia de un lado a otro\n"
                + "Cruz: mover la imagen\n\n"
                + "ABAJO\n"
                + "Circulo de color: abre la paleta\n"
                + "Diana: pincel fino, se queda en el color que tocas\n"
                + "Globo: la varita busca ese color en toda la imagen\n"
                + "Menos: restar de la seleccion\n"
                + "Linea: usa el line art como barrera\n"
                + "Cuadro punteado: ajustar el borde\n\n"
                + "GESTOS\n"
                + "Dos dedos, toque: deshacer\n"
                + "Tres dedos, toque: rehacer\n"
                + "Dos dedos arrastrando: mover y hacer zoom\n"
                + "Dos dedos en circulo: girar el lienzo\n"
                + "Mantener pulsado: gotero rapido con burbuja de color";
        new AlertDialog.Builder(this)
                .setTitle("Que hace cada icono")
                .setMessage(t)
                .setPositiveButton("Entendido", null)
                .show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        autosave(false);
    }

    /**
     * Manten pulsado cualquier boton y te dice como se llama. Asi no hace
     * falta llenar la pantalla de letras.
     */
    private void installTooltips() {
        int[] ids = {R.id.btnMenu, R.id.btnUndo, R.id.btnRedo, R.id.btnFit, R.id.btnLayerAdd,
                R.id.btnLayers, R.id.btnExport, R.id.btnWand, R.id.btnLasso, R.id.btnScissors,
                R.id.btnMove, R.id.btnBrush, R.id.btnEraser, R.id.btnSelEraser, R.id.btnPaint, R.id.btnBucket,
                R.id.btnPicker, R.id.btnClone, R.id.btnPan, R.id.btnColor, R.id.btnSmart,
                R.id.btnGlobal, R.id.btnSub, R.id.btnLineart, R.id.btnEdge, R.id.btnMoreTools};
        String[] names = {"Menu", "Deshacer", "Rehacer", "Encuadrar", "Crear capa de la seleccion",
                "Capas", "Exportar", "Varita: selecciona por color", "Lazo",
                "Tijeras: se pega al contorno", "Mover la seleccion",
                "Pincel de seleccion (azul)", "Borrador: borra pixeles reales",
                "Borrar seleccion azul", "Pincel: dibujar con color", "Balde: rellena de color",
                "Gotero: toma un color", "Clonar", "Mano: mover la imagen",
                "Color para pintar", "Fino: se queda en el color que tocas",
                "Global: ese color en toda la imagen", "Restar de la seleccion",
                "Line art como barrera", "Ajustar el borde", "Mas herramientas"};
        for (int i = 0; i < ids.length; i++) {
            final String n = names[i];
            findViewById(ids[i]).setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    toast(n);
                    return true;
                }
            });
        }
    }

    private void blankCanvasDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), dp(8));
        TextView hint = new TextView(this);
        hint.setText("Nueva imagen blanca. Si ya tienes trabajo abierto, guárdalo antes.");
        form.addView(hint);
        final EditText width = new EditText(this), height = new EditText(this);
        width.setInputType(InputType.TYPE_CLASS_NUMBER); height.setInputType(InputType.TYPE_CLASS_NUMBER);
        width.setText("1080"); height.setText("1920");
        width.setHint("Ancho (px)"); height.setHint("Alto (px)");
        form.addView(width); form.addView(height);
        new AlertDialog.Builder(this).setTitle("Nuevo dibujo").setView(form)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear", (dialog, id) -> {
                    int w, h;
                    try {
                        w = Integer.parseInt(width.getText().toString());
                        h = Integer.parseInt(height.getText().toString());
                    } catch (NumberFormatException e) { toast("Dimensiones no válidas"); return; }
                    if (w < 64 || h < 64 || w > 4096 || h > 4096 || (long) w * h > 10000000L) {
                        toast("Usa entre 64 y 4096 px, máximo 10 millones de píxeles"); return;
                    }
                    Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    b.eraseColor(Color.WHITE);
                    canvas.setProject(new Project(b));
                    canvas.setMode(CanvasView.MODE_PAINT);
                    findViewById(R.id.layersPanel).setVisibility(View.GONE);
                    updateUi(); syncSlider(); toast("Lienzo blanco creado. Ya puedes dibujar.");
                }).show();
    }

    private void tool(int id, final int mode) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (canvas.getIsolatedLayer() != null) canvas.isolateLayer(null);
                closeToolPalette();
                canvas.setMode(mode);
                if ((mode == CanvasView.MODE_PAINT || mode == CanvasView.MODE_ERASE_PIXELS) && !canvas.isBaseVisible() && canvas.getActiveLayer() == null) {
                    canvas.setBaseVisible(true);
                    if (findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE) buildLayersPanel();
                }
                if (mode == CanvasView.MODE_CLONE) canvas.resetCloneSource();
                if (mode == CanvasView.MODE_PICKER) toast("Toca la imagen para tomar ese color");
                if (mode == CanvasView.MODE_SCISSORS) {
                    toast("Arrastra siguiendo el contorno. Vuelve al punto verde para cerrar");
                }
                if (mode == CanvasView.MODE_MOVE) toast("Si hay selección azul, mueves selección. Si no, mueves la capa activa.");
                if (mode == CanvasView.MODE_BRUSH || mode == CanvasView.MODE_ERASER) toast("Editas lo azul (selección). Para dibujar usa Pincel color.");
                syncSlider();
                configureContextActions();
                updateUi();
            }
        });
    }

    private void click(int id, final Runnable r) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
    }

    // ------------------------------------------------------------------
    // Imagen
    // ------------------------------------------------------------------

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    private void loadImage(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            if (bmp == null) {
                toast("No se pudo leer la imagen");
                return;
            }
            canvas.setProject(new Project(bmp));
            toast("Cargada a " + bmp.getWidth() + " x " + bmp.getHeight());
            updateUi();
            guideIfFirstTime();
        } catch (OutOfMemoryError err) {
            toast("La imagen es demasiado grande para la memoria del telefono");
        } catch (Exception ex) {
            toast("Error al abrir: " + ex.getMessage());
        }
    }

    private void importAsLayer(Uri uri) {
        if (!needProject()) return;
        Project project=canvas.getProject();
        try (InputStream in=getContentResolver().openInputStream(uri)) {
            Bitmap original=BitmapFactory.decodeStream(in);
            if(original==null){toast("No se pudo leer imagen");return;}
            float scale=Math.min(1f,Math.min(project.w/(float)original.getWidth(),project.h/(float)original.getHeight()));
            int w=Math.max(1,Math.round(original.getWidth()*scale));
            int h=Math.max(1,Math.round(original.getHeight()*scale));
            Bitmap scaled=Bitmap.createScaledBitmap(original,w,h,true);
            int[] src=new int[w*h];scaled.getPixels(src,0,w,0,0,w,h);
            int[] pixels=new int[project.w*project.h];
            byte[] mask=new byte[pixels.length];
            int offX=(project.w-w)/2,offY=(project.h-h)/2;
            for(int y=0;y<h;y++){
                int dst=(offY+y)*project.w+offX;
                System.arraycopy(src,y*w,pixels,dst,w);
                for(int x=0;x<w;x++)mask[dst+x]=(byte)(src[y*w+x]>>>24);
            }
            Layer layer=new Layer("Imagen "+(project.layers.size()+1),mask);
            layer.rasterPixels=pixels;project.layers.add(layer);
            canvas.setActiveLayer(layer);canvas.refreshLayersPreview();buildLayersPanel();autosave(false);
            toast("Imagen importada a una capa independiente");
            if(scaled!=original)scaled.recycle();original.recycle();
        } catch(OutOfMemoryError err){toast("Memoria insuficiente para esta imagen");}
        catch(Exception err){toast("Error al importar: "+err.getMessage());}
    }

    private void textLayerDialog(){
        if(!needProject())return;
        LinearLayout root=dialogForm();
        EditText field=new EditText(this);field.setHint("Escribe tu texto");root.addView(field);
        TextView sizeLabel=dialogText(root,"Tamaño del texto: 64 px");
        SeekBar size=new SeekBar(this);size.setMax(190);size.setProgress(48);root.addView(size);
        size.setOnSeekBarChangeListener(new SimpleSeek(){
            @Override public void onProgressChanged(SeekBar b,int n,boolean u){sizeLabel.setText("Tamaño del texto: "+(16+n)+" px");}
        });
        new AlertDialog.Builder(this).setTitle("Texto en nueva capa").setView(root)
            .setNegativeButton("Cancelar",null)
            .setPositiveButton("Crear capa",(d,i)->{
                String content=field.getText().toString().trim();if(content.isEmpty())return;
                Project project=canvas.getProject();
                try {
                    int[] px=new int[project.w*project.h];
                    Bitmap b=Bitmap.createBitmap(project.w,project.h,Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas c=new android.graphics.Canvas(b);
                    android.graphics.Paint pen=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
                    pen.setColor(canvas.getColor());pen.setTextSize(size.getProgress()+16f);
                    pen.setTextAlign(android.graphics.Paint.Align.CENTER);
                    c.drawText(content,project.w/2f,project.h/2f,pen);
                    b.getPixels(px,0,project.w,0,0,project.w,project.h);b.recycle();
                    Layer layer=new Layer(content, new byte[px.length]);layer.rasterPixels=px;layer.syncMask();
                    project.layers.add(layer);canvas.setActiveLayer(layer);canvas.refreshLayersPreview();
                    if(findViewById(R.id.layersPanel).getVisibility()==View.VISIBLE)buildLayersPanel();
                    autosave(false);toast("Texto creado en capa; puedes moverlo y borrarlo");
                }catch(OutOfMemoryError e){toast("Memoria insuficiente para texto");}
            }).show();
    }

    // ------------------------------------------------------------------
    // Capas
    // ------------------------------------------------------------------

    /** + crea una capa transparente, o extrae la selección a una capa ARGB editable. */
    private void addLayerFromSelection() {
        if (!needProject()) return;
        Project p = canvas.getProject();
        try {
            int n = p.w * p.h;
            long requested = (long) n * 5; // RGBA+mascara por capa
            long free = Runtime.getRuntime().maxMemory() -
                    (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory());
            if (requested > free * 0.8) {
                toast("Memoria insuficiente para otra capa. Guarda primero el proyecto.");
                return;
            }
            boolean selected = p.hasSelection();
            byte[] mask = new byte[n];
            int[] colors = new int[n];
            if (selected) {
                Layer fromLayer = canvas.getActiveLayer();
                int[] source = fromLayer != null && fromLayer.rasterPixels != null
                        ? fromLayer.rasterPixels : p.pixels;
                for (int i = 0; i < n; i++) {
                    int opacity = (p.selection[i] & 255) * ((source[i] >>> 24) & 255) / 255;
                    colors[i] = (opacity << 24) | (source[i] & 0xFFFFFF);
                    mask[i] = (byte) opacity;
                }
            }
            Layer layer = new Layer(selected ? "Pieza " + (p.layers.size() + 1)
                    : "Capa " + (p.layers.size() + 1), mask);
            layer.rasterPixels = colors;
            p.layers.add(layer);
            canvas.setActiveLayer(layer);
            if (selected) canvas.clearSelection();
            canvas.refreshLayersPreview();
            toast(selected ? "Pieza extraída: ya puedes dibujar sobre ella"
                    : "Capa transparente creada: dibuja aquí");
            updateUi();
            if (findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE) buildLayersPanel();
            autosave(false);
        } catch (OutOfMemoryError oom) {
            toast("No hay memoria para una capa de esta resolución");
        }
    }

    private int activeLayerIndex(){
        Project p=canvas.getProject();
        return p==null?-1:p.layers.indexOf(canvas.getActiveLayer());
    }
    private void setLayerControlState(){
        Layer layer=canvas.getActiveLayer();
        SeekBar bar=findViewById(R.id.layerOpacity);
        TextView label=findViewById(R.id.layerOpacityText);
        updatingLayerOpacity=true;
        bar.setEnabled(layer!=null);
        bar.setProgress(layer==null?100:layer.opacity*100/255);
        label.setText(layer==null?"Fondo":"Opac. "+bar.getProgress()+"%");
        updatingLayerOpacity=false;
        toggle(R.id.btnLayerAlpha,layer!=null && layer.alphaLock);
        toggle(R.id.btnLayerGray,layer!=null && layer.grayscale);
        int[] buttons={R.id.btnLayerAlpha,R.id.btnLayerGray,R.id.btnLayerCopy,
            R.id.btnLayerUp,R.id.btnLayerDown,R.id.btnLayerMerge,R.id.btnLayerDelete};
        for(int id:buttons)findViewById(id).setEnabled(layer!=null);
    }
    private void bindLayerControls(){
        SeekBar bar=findViewById(R.id.layerOpacity);
        bar.setOnSeekBarChangeListener(new SimpleSeek(){
            @Override public void onProgressChanged(SeekBar seek,int v,boolean user){
                if(updatingLayerOpacity || !user)return;
                Layer layer=canvas.getActiveLayer();if(layer==null)return;
                layer.opacity=v*255/100;
                ((TextView)findViewById(R.id.layerOpacityText)).setText("Opac. "+v+"%");
                canvas.refreshLayersPreview();
            }
            @Override public void onStopTrackingTouch(SeekBar seek){
                Layer l=canvas.getActiveLayer();if(l!=null){buildLayersPanel();autosave(false);}
            }
        });
        click(R.id.btnLayerAlpha,()->{
            Layer l=canvas.getActiveLayer();if(l==null)return;
            l.alphaLock=!l.alphaLock;buildLayersPanel();autosave(false);
        });
        click(R.id.btnLayerGray,()->{
            Layer l=canvas.getActiveLayer();if(l==null)return;
            l.grayscale=!l.grayscale;canvas.refreshLayersPreview();buildLayersPanel();autosave(false);
        });
        click(R.id.btnLayerCopy,()->{
            Project p=canvas.getProject();int idx=activeLayerIndex();if(idx<0)return;
            Layer l=p.layers.get(idx);
            try {
                Layer dup=new Layer(l.name+" copia",l.mask.clone());
                dup.visible=l.visible;dup.opacity=l.opacity;dup.grayscale=l.grayscale;
                dup.alphaLock=l.alphaLock;dup.rasterPixels=l.rasterPixels==null?null:l.rasterPixels.clone();
                p.layers.add(idx+1,dup);canvas.setActiveLayer(dup);
                canvas.refreshLayersPreview();buildLayersPanel();autosave(false);
            }catch(OutOfMemoryError e){toast("Memoria insuficiente para duplicar");}
        });
        click(R.id.btnLayerUp,()->{int i=activeLayerIndex();if(i>=0)move(i,1);});
        click(R.id.btnLayerDown,()->{int i=activeLayerIndex();if(i>=0)move(i,-1);});
        click(R.id.btnLayerMerge,()->{int i=activeLayerIndex();if(i>=0)mergeWithBelow(canvas.getProject(),i);});
        click(R.id.btnLayerDelete,()->{
            Layer l=canvas.getActiveLayer();if(l!=null)confirmDeleteLayer(canvas.getProject(),l);
        });
    }

    private void toggleLayersPanel() {
        if (!needProject()) return;
        View panel = findViewById(R.id.layersPanel);
        if (panel.getVisibility() == View.VISIBLE) {
            panel.setVisibility(View.GONE);
        } else {
            closeToolPalette();
            findViewById(R.id.toolsPanel).setVisibility(View.GONE);
            buildLayersPanel();
            panel.setVisibility(View.VISIBLE);
        }
    }

    /** Panel tipo Ibis: una selección, capas con miniaturas legibles y controles comunes abajo. */
    private void buildLayersPanel() {
        final Project project = canvas.getProject();
        if (project == null) return;
        final ScrollView scroll = findViewById(R.id.layersScroll);
        final int keepY = scroll.getScrollY();
        final LinearLayout list = findViewById(R.id.layersList);
        list.removeAllViews();
        ((TextView)findViewById(R.id.layersTitle)).setText("Capas (" + project.layers.size() + ")");

        list.addView(selectionRow(project));
        for (int i = project.layers.size()-1; i >= 0; i--) list.addView(layerRow(project,i));
        list.addView(baseRow(project));
        setLayerControlState();
        scroll.post(() -> scroll.scrollTo(0,keepY));
    }

    private View selectionRow(final Project project) {
        final LinearLayout row = rowBase(false);
        row.setBackgroundColor(0xFFF8E9EE);
        ImageView image = new ImageView(this);
        image.setLayoutParams(new LinearLayout.LayoutParams(dp(68),dp(70)));
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setImageBitmap(Thumbs.forMask(project,project.selection,140));
        row.addView(image);
        TextView label = new TextView(this);
        label.setText("Selección\n"+(project.hasSelection()?"● Zona azul activa":"Sin seleccionar"));
        label.setTextSize(14); label.setTextColor(0xFF1C2028);
        label.setPadding(dp(9),0,0,0);
        label.setGravity(android.view.Gravity.CENTER_VERTICAL);
        label.setLayoutParams(new LinearLayout.LayoutParams(0,dp(70),1f));
        row.addView(label);
        row.addView(iconButton(R.drawable.ic_sub,"Limpiar selección",()->{canvas.clearSelection();buildLayersPanel();}));
        row.addView(iconButton(R.drawable.ic_edge,"Invertir selección",()->{canvas.invertSelection();buildLayersPanel();}));
        return row;
    }

    private View layerRow(final Project project,final int index) {
        final Layer layer=project.layers.get(index);
        final boolean selected=canvas.getActiveLayer()==layer;
        LinearLayout row=rowBase(selected);
        row.setBackgroundColor(selected?0xFFBEDAFF:0xFFF5F5F7);
        ImageView image=new ImageView(this);
        image.setLayoutParams(new LinearLayout.LayoutParams(dp(72),dp(86)));
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackgroundColor(0xFFCCCCCC);
        image.setImageBitmap(Thumbs.forLayer(project,layer,160));
        row.addView(image);
        TextView label=new TextView(this);
        label.setText(layer.name+"\n"+(layer.opacity*100/255)+"%  ·  "+(layer.grayscale?"B/N":"Normal")+(layer.alphaLock?"  α":""));
        label.setTextColor(layer.visible?0xFF16191E:0xFF888888);
        label.setTextSize(14);
        label.setGravity(android.view.Gravity.CENTER_VERTICAL);
        label.setPadding(dp(9),0,0,0);
        label.setLayoutParams(new LinearLayout.LayoutParams(0,dp(86),1f));
        row.addView(label);
        View.OnClickListener choose=v->{canvas.setActiveLayer(layer);buildLayersPanel();};
        image.setOnClickListener(choose); label.setOnClickListener(choose);
        image.setOnLongClickListener(v->{canvas.isolateLayer(canvas.getIsolatedLayer()==layer?null:layer);toast("Vista de capa: "+layer.name);return true;});
        row.addView(iconButton(layer.visible?R.drawable.ic_eye:R.drawable.ic_eye_off,
                layer.visible?"Ocultar":"Mostrar",()->{
                    layer.visible=!layer.visible;canvas.refreshLayersPreview();buildLayersPanel();autosave(false);
                }));
        row.addView(iconButton(R.drawable.ic_menu,"Opciones: "+layer.name,()->layerQuickActions(project,index)));
        return row;
    }

    private View baseRow(final Project project) {
        LinearLayout row=rowBase(canvas.getActiveLayer()==null);
        row.setBackgroundColor(canvas.getActiveLayer()==null?0xFFBEDAFF:0xFFF5F5F7);
        ImageView image=new ImageView(this);
        image.setLayoutParams(new LinearLayout.LayoutParams(dp(72),dp(86)));
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setImageBitmap(Thumbs.forBase(project,160));
        row.addView(image);
        TextView t=new TextView(this);
        t.setLayoutParams(new LinearLayout.LayoutParams(0,dp(86),1f));
        t.setPadding(dp(9),0,0,0);t.setGravity(android.view.Gravity.CENTER_VERTICAL);
        t.setTextSize(14);t.setTextColor(0xFF14181D);
        t.setText("Fondo original\n"+(canvas.isBaseVisible()?"Visible":"Oculto")+" · Normal");
        row.addView(t);
        View.OnClickListener choose=v->{canvas.setActiveLayer(null);canvas.isolateLayer(null);buildLayersPanel();};
        image.setOnClickListener(choose);t.setOnClickListener(choose);
        row.addView(iconButton(canvas.isBaseVisible()?R.drawable.ic_eye:R.drawable.ic_eye_off,
                "Mostrar u ocultar fondo",()->{
                    canvas.setBaseVisible(!canvas.isBaseVisible());buildLayersPanel();autosave(false);
                }));
        return row;
    }

    private LinearLayout rowBase(boolean on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);
        return row;
    }

    private ImageButton iconButton(int icon, final String name, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setImageResource(icon);
        b.setContentDescription(name);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                toast(name);
                return true;
            }
        });
        return b;
    }

    private void opacityDialog(final Layer l) {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(l.opacity * 100 / 255);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        final TextView t = new TextView(this);
        t.setText("Opacidad: " + bar.getProgress() + "%");
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Opacidad: " + v + "%");
            }
        });
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setView(root)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        l.opacity = bar.getProgress() * 255 / 100;
                        canvas.refreshLayersPreview();
                        buildLayersPanel();
                        if (canvas.getIsolatedLayer() == l) canvas.isolateLayer(l);
                        autosave(false);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void confirmDeleteLayer(final Project p, final Layer l) {
        new AlertDialog.Builder(this).setTitle("¿Eliminar " + l.name + "?")
                .setMessage("Esto elimina esta capa independiente.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", (d, i) -> {
                    if (canvas.getIsolatedLayer() == l) canvas.isolateLayer(null);
                    if (canvas.getActiveLayer() == l) canvas.setActiveLayer(null);
                    p.layers.remove(l); canvas.clearUndoHistory(); canvas.refreshLayersPreview(); buildLayersPanel(); autosave(false); updateUi();
                }).show();
    }

    /** Combina dos raster sobre el lienzo sin modificar el fondo. */
    private void mergeWithBelow(Project p, int index) {
        if (index <= 0 || index >= p.layers.size()) {
            toast("No hay una capa inferior para combinar"); return;
        }
        new AlertDialog.Builder(this).setTitle("Combinar capas")
                .setMessage("Se unirán las dos piezas en una capa raster. Guarda copia del proyecto si deseas conservarlas separadas.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Combinar", (d, which) -> {
                    try {
                        Layer upper = p.layers.get(index);
                        Layer lower = p.layers.get(index - 1);
                        int[] top = layerPixels(p, upper);
                        int[] bottom = layerPixels(p, lower);
                        int[] merged = new int[top.length];
                        for (int i = 0; i < merged.length; i++) {
                            int base = lower.grayscale ? grayColor(bottom[i]) : bottom[i];
                            base = (base & 0xFFFFFF) | ((base >>> 24) * lower.opacity / 255 << 24);
                            int src = upper.grayscale ? grayColor(top[i]) : top[i];
                            merged[i] = compositeColor(base, src, upper.opacity);
                        }
                        lower.rasterPixels = merged;
                        lower.opacity = 255;
                        lower.grayscale = false;
                        lower.name = lower.name + " + " + upper.name;
                        lower.syncMask();
                        p.layers.remove(index);
                        canvas.setActiveLayer(lower);
                        canvas.clearUndoHistory();
                        canvas.refreshLayersPreview();
                        buildLayersPanel(); autosave(false); updateUi();
                    } catch (OutOfMemoryError e) {
                        toast("Memoria insuficiente para combinar capas");
                    }
                }).show();
    }

    private int[] layerPixels(Project p, Layer l) {
        if (l.rasterPixels != null) return l.rasterPixels;
        int[] out = new int[p.pixels.length];
        for (int i = 0; i < out.length; i++) {
            int orig = p.pixels[i];
            int alpha = ((orig >>> 24) & 255) * (l.mask[i] & 255) / 255;
            out[i] = (alpha << 24) | (orig & 0xFFFFFF);
        }
        return out;
    }

    private static int grayColor(int c) {
        int g = (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 150 + (c & 255) * 29 + 128) >> 8;
        return (c & 0xFF000000) | (g << 16) | (g << 8) | g;
    }

    private static int compositeColor(int dst, int src, int opacity) {
        int sa = ((src >>> 24) & 255) * opacity / 255, da = dst >>> 24;
        int oa = sa + da * (255 - sa) / 255;
        if (oa <= 0) return 0;
        int r = (((src >> 16) & 255) * sa * 255 + ((dst >> 16) & 255) * da * (255-sa)) / (oa*255);
        int g = (((src >> 8) & 255) * sa * 255 + ((dst >> 8) & 255) * da * (255-sa)) / (oa*255);
        int b = ((src & 255) * sa * 255 + (dst & 255) * da * (255-sa)) / (oa*255);
        return (oa << 24)|(Math.min(255,r)<<16)|(Math.min(255,g)<<8)|Math.min(255,b);
    }

    /** Opciones con texto claro; no es necesario memorizar los iconos del panel. */
    private void layerQuickActions(final Project p, final int index) {
        if (index < 0 || index >= p.layers.size()) return;
        final Layer l = p.layers.get(index);
        final String[] actions = {"Seleccionar para dibujar", "Ver esta capa sola", "Volver a imagen completa",
                "Cargar como selección azul", "Duplicar capa", "Blanco y negro: " + (l.grayscale ? "ACTIVADO" : "DESACTIVADO"),
                "Bloquear transparencia α: " + (l.alphaLock ? "ACTIVADO" : "DESACTIVADO"),
                "Cambiar nombre", "Combinar con capa inferior", "Eliminar capa"};
        new AlertDialog.Builder(this).setTitle(l.name).setItems(actions, (d, which) -> {
            switch (which) {
                case 0: canvas.setActiveLayer(l); break;
                case 1: canvas.setActiveLayer(l); canvas.isolateLayer(l); break;
                case 2: canvas.isolateLayer(null); break;
                case 3: canvas.isolateLayer(null); canvas.loadSelection(l.mask); break;
                case 4:
                    Layer copy = new Layer(l.name + " copia", l.mask.clone());
                    copy.visible = l.visible; copy.opacity = l.opacity; copy.grayscale = l.grayscale;
                    copy.alphaLock = l.alphaLock;
                    copy.rasterPixels = l.rasterPixels == null ? null : l.rasterPixels.clone();
                    p.layers.add(index + 1, copy);
                    canvas.setActiveLayer(copy);
                    canvas.refreshLayersPreview();
                    break;
                case 5:
                    l.grayscale = !l.grayscale;
                    canvas.refreshLayersPreview();
                    if (canvas.getIsolatedLayer() == l) canvas.isolateLayer(l);
                    break;
                case 6:
                    l.alphaLock = !l.alphaLock;
                    break;
                case 7: renameDialog(l); return;
                case 8: mergeWithBelow(p, index); return;
                case 9:
                    new AlertDialog.Builder(this).setTitle("¿Eliminar " + l.name + "?")
                            .setMessage("Esta capa desaparecerá del proyecto al guardar.")
                            .setNegativeButton("Cancelar", null)
                            .setPositiveButton("Eliminar", (dialog, id) -> {
                                if (canvas.getIsolatedLayer() == l) canvas.isolateLayer(null);
                                if (canvas.getActiveLayer() == l) canvas.setActiveLayer(null);
                                p.layers.remove(l); canvas.clearUndoHistory(); canvas.refreshLayersPreview(); buildLayersPanel(); autosave(false); updateUi();
                            }).show();
                    return;
            }
            buildLayersPanel(); autosave(false); updateUi();
        }).show();
    }

    private void layersDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        if (p.layers.isEmpty()) {
            toast("Todavia no hay capas");
            return;
        }
        final String[] items = new String[p.layers.size()];
        for (int i = 0; i < items.length; i++) {
            Layer l = p.layers.get(i);
            items[i] = (l.visible ? "[visible] " : "[oculta]  ") + l.name;
        }
        new AlertDialog.Builder(this)
                .setTitle("Capas (" + items.length + ")")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        layerOptions(which);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void layerOptions(final int index) {
        final Project p = canvas.getProject();
        final Layer l = p.layers.get(index);
        final String[] opts = {
                l.visible ? "Ocultar" : "Mostrar",
                "Subir (va mas adelante)",
                "Bajar (va mas atras)",
                "Cargar a la seleccion",
                "Renombrar",
                "Exportar solo esta capa",
                "Eliminar"
        };
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(opts, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                l.visible = !l.visible;
                                updateUi();
                                break;
                            case 1:
                                move(index, -1);
                                break;
                            case 2:
                                move(index, 1);
                                break;
                            case 3:
                                canvas.loadSelection(l.mask);
                                toast("Capa cargada en la seleccion");
                                break;
                            case 4:
                                renameDialog(l);
                                break;
                            case 5:
                                pendingPngLayer = l;
                                pendingPngMask = l.mask;
                                createPng.launch(l.name + ".png");
                                break;
                            default:
                                p.layers.remove(index);
                                toast("Capa eliminada");
                                updateUi();
                                break;
                        }
                    }
                })
                .show();
    }

    /** Cambia el orden de la capa. El orden manda en el numero del PNG exportado. */
    private void move(int index, int delta) {
        Project p = canvas.getProject();
        int target = index + delta;
        if (target < 0 || target >= p.layers.size()) {
            toast("Ya esta en el extremo");
            return;
        }
        Layer a = p.layers.get(index);
        p.layers.set(index, p.layers.get(target));
        p.layers.set(target, a);
        canvas.refreshLayersPreview();
        buildLayersPanel();
        autosave(false);
    }

    private void renameDialog(final Layer l) {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        in.setText(l.name);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la capa")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        if (!s.isEmpty()) l.name = s;
                        updateUi();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Color
    // ------------------------------------------------------------------

    private void colorDialog() {
        final int[] chosen = {canvas.getColor()};

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final View preview = new View(this);
        LinearLayout.LayoutParams pvp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        pvp.bottomMargin = dp(10);
        preview.setLayoutParams(pvp);
        preview.setBackgroundColor(chosen[0]);
        root.addView(preview);

        final SeekBar sr = new SeekBar(this);
        final SeekBar sg = new SeekBar(this);
        final SeekBar sb = new SeekBar(this);
        sr.setMax(255);
        sg.setMax(255);
        sb.setMax(255);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        root.addView(grid);

        LinearLayout row = null;
        for (int i = 0; i < PALETTE.length; i++) {
            if (i % 6 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row);
            }
            final int c = PALETTE[i];
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            sw.setLayoutParams(lp);
            sw.setBackgroundColor(c);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chosen[0] = c;
                    preview.setBackgroundColor(c);
                    sr.setProgress(Color.red(c));
                    sg.setProgress(Color.green(c));
                    sb.setProgress(Color.blue(c));
                }
            });
            row.addView(sw);
        }

        SeekBar.OnSeekBarChangeListener rgb = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                if (!fromUser) return;
                chosen[0] = Color.rgb(sr.getProgress(), sg.getProgress(), sb.getProgress());
                preview.setBackgroundColor(chosen[0]);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        };

        addLabeled(root, "Rojo", sr, Color.red(chosen[0]), rgb);
        addLabeled(root, "Verde", sg, Color.green(chosen[0]), rgb);
        addLabeled(root, "Azul", sb, Color.blue(chosen[0]), rgb);

        new AlertDialog.Builder(this)
                .setTitle("Color para pintar")
                .setView(scroll)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setColor(chosen[0]);
                        updateUi();
                    }
                })
                .setNeutralButton("Tomar de la imagen", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setMode(CanvasView.MODE_PICKER);
                        toast("Toca la imagen para tomar ese color");
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void addLabeled(LinearLayout root, String name, SeekBar bar, int value,
                            SeekBar.OnSeekBarChangeListener l) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(l);
        root.addView(bar);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------
    // Dialogos
    // ------------------------------------------------------------------

    private void hardnessDialog() {
        final String[] items = {"Muy suave 20%", "Suave 40%", "Media 70%", "Dura 100%"};
        final float[] vals = {0.2f, 0.4f, 0.7f, 1f};
        new AlertDialog.Builder(this)
                .setTitle("Dureza del pincel")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setHardness(vals[i]);
                        toast("Dureza " + items[i]);
                    }
                })
                .show();
    }

    private void rotateDialog() {
        if (!needProject()) return;
        final String[] items = {"Girar a la derecha", "Girar a la izquierda",
                "Voltear horizontal", "Voltear vertical"};
        new AlertDialog.Builder(this)
                .setTitle("Girar imagen")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.transform(i);
                    }
                })
                .show();
    }

    /** El slider calcula SIEMPRE desde la selección inicial, nunca acumula el ajuste. */
    private void edgeDialog() {
        if (!needProject() || !canvas.getProject().hasSelection()) {
            toast("Primero selecciona una zona con varita o lazo"); return;
        }
        final String[] names={"Expandir","Contraer","Suavizar","Endurecer","Cerrar huecos"};
        final android.widget.Spinner types=new android.widget.Spinner(this);
        types.setAdapter(new android.widget.ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        LinearLayout form=dialogForm();
        final TextView current=dialogText(form,"Expandir · 0 px");
        form.addView(types);
        SeekBar amount=new SeekBar(this);amount.setMax(12);amount.setProgress(0);form.addView(amount);
        dialogText(form,"Mueve la barra y mira el borde azul antes de confirmar.");
        canvas.beginPreview();
        final Runnable calculate=()->{
            if (canvas.getProject()==null)return;
            int kind=types.getSelectedItemPosition();
            int radius=amount.getProgress();
            current.setText(names[kind]+" · "+radius+" px");
            canvas.previewEdge(kind,radius);
        };
        final Runnable queue=()->{
            edgePreviewHandler.removeCallbacks(calculate);
            edgePreviewHandler.postDelayed(calculate,150);
        };
        types.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> a, View v,int pos,long id){queue.run();}
            public void onNothingSelected(android.widget.AdapterView<?> a){}
        });
        amount.setOnSeekBarChangeListener(new SimpleSeek(){
            @Override public void onProgressChanged(SeekBar b,int value,boolean user){
                current.setText(names[types.getSelectedItemPosition()]+" · "+value+" px");
                queue.run();
            }
        });
        new AlertDialog.Builder(this).setTitle("Borde de selección · vista previa")
                .setView(form).setPositiveButton("Aplicar",(d,i)->{
                    edgePreviewHandler.removeCallbacks(calculate);
                    // La última posición de slider se computa sin depender del retraso del debounce.
                    canvas.endPreview(false);
                    int k=types.getSelectedItemPosition(),r=amount.getProgress();
                    if(r>0 || k==3)canvas.edgeOp(k,r);
                }).setNegativeButton("Cancelar",(d,i)->{
                    edgePreviewHandler.removeCallbacks(calculate);canvas.endPreview(false);
                }).setOnCancelListener(d->{
                    edgePreviewHandler.removeCallbacks(calculate);canvas.endPreview(false);
                }).show();
    }

    private void lineArtDialog() { if(needProject()) thresholdDialog(); }

    private void thresholdDialog() {
        if(!needProject())return;
        LinearLayout form=dialogForm();
        final TextView headline=dialogText(form,"Sensibilidad: 120");
        SeekBar strength=new SeekBar(this);strength.setMax(255);strength.setProgress(120);form.addView(strength);
        final TextView gapTitle=dialogText(form,"Cerrar huecos: 0 px");
        SeekBar gap=new SeekBar(this);gap.setMax(4);form.addView(gap);
        dialogText(form,"Las líneas detectadas aparecen en color cian, sin modificar el dibujo.");
        final Runnable compute=()->canvas.previewLine(strength.getProgress(),gap.getProgress());
        final Runnable queue=()->{edgePreviewHandler.removeCallbacks(compute);edgePreviewHandler.postDelayed(compute,180);};
        strength.setOnSeekBarChangeListener(new SimpleSeek(){
            @Override public void onProgressChanged(SeekBar b,int v,boolean u){headline.setText("Sensibilidad: "+v);queue.run();}
        });
        gap.setOnSeekBarChangeListener(new SimpleSeek(){
            @Override public void onProgressChanged(SeekBar b,int v,boolean u){gapTitle.setText("Cerrar huecos: "+v+" px");queue.run();}
        });
        queue.run();
        new AlertDialog.Builder(this).setTitle("Detección de líneas en vivo").setView(form)
                .setPositiveButton("Usar para varita / relleno",(d,i)->{
                    edgePreviewHandler.removeCallbacks(compute);
                    canvas.cancelLinePreview();canvas.buildBarrier(strength.getProgress(),gap.getProgress());
                }).setNeutralButton("Desactivar",(d,i)->{
                    edgePreviewHandler.removeCallbacks(compute);canvas.cancelLinePreview();canvas.setUseBarrier(false);updateUi();
                }).setNegativeButton("Cancelar",(d,i)->{
                    edgePreviewHandler.removeCallbacks(compute);canvas.cancelLinePreview();
                }).setOnCancelListener(d->{edgePreviewHandler.removeCallbacks(compute);canvas.cancelLinePreview();})
                .show();
    }

    private LinearLayout dialogForm(){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(16),dp(8),dp(16),dp(8));return r;
    }
    private TextView dialogText(LinearLayout r,String value){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(15f);
        t.setPadding(dp(2),dp(8),dp(2),dp(8));r.addView(t);return t;
    }

    // ------------------------------------------------------------------
    // Exportar
    // ------------------------------------------------------------------

    private void exportDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        if (p.layers.isEmpty()) {
            pendingPngLayer=null;pendingPngMask=new byte[]{1};
            createPng.launch("Paint-Zeta-dibujo.png");
            return;
        }
        new AlertDialog.Builder(this).setTitle("Guardar o exportar")
            .setItems(new String[]{"Dibujo completo PNG", "Capas separadas PNG (ZIP)"}, (d, choice)->{
                if(choice==0){pendingPngLayer=null;pendingPngMask=new byte[]{1};
                    createPng.launch("Paint-Zeta-dibujo.png");}
                else chooseExportZipSize();
            }).show();
    }

    private void chooseExportZipSize(){
        final Project p=canvas.getProject();
        final int[][] sizes = {
                {p.w, p.h},
                {Math.max(1, p.w / 2), Math.max(1, p.h / 2)},
                longSide(p, 1920),
                longSide(p, 1280)
        };
        final String[] items = new String[sizes.length];
        items[0] = "Original  " + sizes[0][0] + "x" + sizes[0][1];
        items[1] = "Mitad  " + sizes[1][0] + "x" + sizes[1][1];
        items[2] = "Lado largo 1920  " + sizes[2][0] + "x" + sizes[2][1];
        items[3] = "Lado largo 1280  " + sizes[3][0] + "x" + sizes[3][1];

        new AlertDialog.Builder(this)
                .setTitle("Tamano de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        outW = sizes[i][0];
                        outH = sizes[i][1];
                        edgeDialogExport();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /**
     * Limpieza del borde al exportar. Es lo que evita el halo blanco cuando
     * pones la capa sobre otro fondo en Alight Motion.
     */
    private void edgeDialogExport() {
        final String[] items = {
                "Limpiar borde y quitar el fondo pegado (recomendado)",
                "Solo limpiar borde",
                "No tocar el borde"
        };
        final int[] vals = {2, 1, 0};
        new AlertDialog.Builder(this)
                .setTitle("Borde de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        edgeClean = vals[i];
                        createZip.launch("capas_anime.zip");
                    }
                })
                .show();
    }

    /** Mantiene la proporcion para que todas las capas sigan cuadrando entre si. */
    private int[] longSide(Project p, int target) {
        int max = Math.max(p.w, p.h);
        if (max <= target) return new int[]{p.w, p.h};
        float f = target / (float) max;
        return new int[]{Math.max(1, Math.round(p.w * f)), Math.max(1, Math.round(p.h * f))};
    }

    private void doExportZip(final Uri uri) {
        final Project p = canvas.getProject();
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    lastExportCount = Exporter.exportZip(getContentResolver(), p, uri, canvas.isBaseVisible(), outW, outH, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al exportar: " + lastError);
                else toast(lastExportCount + " PNG de " + outW + "x" + outH + " guardados en el ZIP");
            }
        });
    }

    private void doExportPng(final Uri uri) {
        final Project p = canvas.getProject();
        final byte[] mask = pendingPngMask;
        final Layer selectedLayer = pendingPngLayer;
        pendingPngMask = null;
        pendingPngLayer = null;
        if (mask == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    if (selectedLayer != null)
                        Exporter.exportLayerPng(getContentResolver(), p, selectedLayer, uri, p.w, p.h, edgeClean);
                    else Exporter.exportCombinedPng(getContentResolver(), p, uri, canvas.isBaseVisible());
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error: " + lastError);
                else toast("PNG guardado a " + p.w + " x " + p.h);
            }
        });
    }

    // ------------------------------------------------------------------
    // Guardar y abrir el proyecto
    // ------------------------------------------------------------------

    private void projectDialog() {
        final boolean has = canvas.getProject() != null;
        final String[] items = {
                "Guardar proyecto en un archivo",
                "Abrir un proyecto guardado",
                "Guardar ahora en la app"
        };
        new AlertDialog.Builder(this)
                .setTitle("Proyecto")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 1) {
                            openProject.launch(new String[]{"*/*"});
                            return;
                        }
                        if (!has) {
                            toast("Abre una imagen primero");
                            return;
                        }
                        if (i == 0) createProject.launch("proyecto.acut");
                        else autosave(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void saveProjectTo(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int color = canvas.getColor();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    ProjectIO.save(os, p, color);
                    if (os != null) os.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al guardar: " + lastError);
                else toast("Proyecto guardado con sus " + p.layers.size() + " capas");
            }
        });
    }

    private void openProjectFrom(final Uri uri) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    loaded = ProjectIO.load(is);
                    if (is != null) is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void recoverFrom(final File f) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileInputStream is = new FileInputStream(f);
                    loaded = ProjectIO.load(is);
                    is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void applyLoaded() {
        if (lastError != null) {
            toast("No se pudo abrir: " + lastError);
            return;
        }
        if (loaded == null || loaded.project == null) return;
        canvas.setProject(loaded.project);
        canvas.setColor(loaded.color);
        toast("Proyecto abierto: " + loaded.project.layers.size() + " capas");
        loaded = null;
        updateUi();
    }

    /**
     * Guardado automatico dentro de la app. Se dispara al crear una capa y
     * al salir, para que una llamada o que Android cierre la app no borre
     * media hora de trabajo.
     */
    /**
     * Guardado automatico en la carpeta de obras. Se dispara al crear una
     * capa y al salir. Guarda tambien la miniatura para la galeria.
     */
    private void autosave(final boolean notify) {
        final Project p = canvas.getProject();
        if (p == null || saving) return;
        saving = true;
        if (projectId == null) projectId = ProjectStore.newId();
        final String id = projectId;
        final int color = canvas.getColor();
        final File dest = ProjectStore.fileFor(this, id);
        final File tmp = new File(dest.getAbsolutePath() + ".tmp");
        if (notify) toast("Guardando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileOutputStream fo = new FileOutputStream(tmp);
                    ProjectIO.save(fo, p, color);
                    fo.close();
                    if (dest.exists() && !dest.delete()) throw new java.io.IOException("No se pudo reemplazar");
                    if (!tmp.renameTo(dest)) throw new java.io.IOException("No se pudo renombrar");
                    ProjectStore.saveThumb(MainActivity.this, id, p);
                    lastError = null;
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                saving = false;
                if (notify) {
                    if (lastError != null) toast("Error al guardar: " + lastError);
                    else toast("Guardado en la galeria");
                }
            }
        });
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    private boolean sliderIsTolerance() {
        int m = canvas.getMode();
        return m == CanvasView.MODE_WAND || m == CanvasView.MODE_BUCKET;
    }

    private void applySlider(int v) {
        if (sliderIsTolerance()) {
            canvas.setTolerance(v);
            sliderLabel.setText(String.format(Locale.US, "T %d", v));
        } else {
            // Curva cuadratica: casi la mitad del recorrido queda entre 1 y 40 px,
            // que es donde de verdad hace falta precision.
            float t = v / 120f;
            float size = 1f + t * t * 299f;
            canvas.setBrushSize(size);
            sliderLabel.setText(size < 10f
                    ? String.format(Locale.US, "%.1f px", size)
                    : String.format(Locale.US, "%d px", (int) size));
        }
    }

    private void syncSlider() {
        if (sliderIsTolerance()) {
            slider.setProgress(canvas.getTolerance());
            sliderLabel.setText(String.format(Locale.US, "T %d", canvas.getTolerance()));
        } else {
            float t = (float) Math.sqrt(Math.max(0f, (canvas.getBrushSize() - 1f) / 299f));
            slider.setProgress(Math.round(t * 120f));
            sliderLabel.setText(String.format(Locale.US, "%d px", (int) canvas.getBrushSize()));
        }
        int op = Math.round(canvas.getToolOpacity() * 100f);
        opacitySlider.setProgress(op);
        opacityValue.setText("Opac. " + op + "%");
    }

    private void updateUi() {
        Project p = canvas.getProject();
        StringBuilder sb = new StringBuilder();
        if (p == null) {
            sb.append(getString(R.string.open_hint));
        } else {
            sb.append(modeName()).append(": ").append(modeHint());
            sb.append("  |  capas: ").append(p.layers.size());
            if (canvas.isSmart()) sb.append("  |  FINO");
            if (canvas.isWandGlobal()) sb.append("  |  GLOBAL");
            if (canvas.isSubtract()) sb.append("  |  RESTAR");
            if (canvas.isUseBarrier() && p.barrier != null) sb.append("  |  LINE ART");
            if (p.hasSelection()) sb.append("  |  TOCA COPIAR A CAPA ABAJO");
        }
        status.setText(sb.toString());
        toggle(R.id.btnGlobal, canvas.isWandGlobal());
        toggle(R.id.btnSub, canvas.isSubtract());
        toggle(R.id.btnSmart, canvas.isSmart());
        toggle(R.id.btnLineart, canvas.isUseBarrier() && p != null && p.barrier != null);
        ImageButton color = findViewById(R.id.btnColor);
        color.setColorFilter(canvas.getColor());
        highlightTools();
        ImageButton active=findViewById(R.id.btnActiveTool);
        int[] icons={R.drawable.ic_hand,R.drawable.ic_wand,R.drawable.ic_brush,
                R.drawable.ic_eraser,R.drawable.ic_lasso,R.drawable.ic_clone,
                R.drawable.ic_paint,R.drawable.ic_bucket,R.drawable.ic_picker,
                R.drawable.ic_scissors,R.drawable.ic_move,R.drawable.ic_eraser};
        int mode=canvas.getMode();
        if(mode>=0 && mode<icons.length)active.setImageResource(icons[mode]);
    }

    /** Marca en azul lo que esta activado, para que se vea sin leer nada. */
    private void toggle(int id, boolean on) {
        findViewById(id).setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
    }

    private void highlightTools() {
        int[] ids = {R.id.btnWand, R.id.btnLasso, R.id.btnScissors, R.id.btnMove,
                R.id.btnBrush, R.id.btnEraser, R.id.btnSelEraser, R.id.btnPaint,
                R.id.btnBucket, R.id.btnPicker, R.id.btnClone, R.id.btnPan};
        int[] modes = {CanvasView.MODE_WAND, CanvasView.MODE_LASSO,
                CanvasView.MODE_SCISSORS, CanvasView.MODE_MOVE, CanvasView.MODE_BRUSH,
                CanvasView.MODE_ERASE_PIXELS, CanvasView.MODE_ERASER, CanvasView.MODE_PAINT, CanvasView.MODE_BUCKET,
                CanvasView.MODE_PICKER, CanvasView.MODE_CLONE, CanvasView.MODE_PAN};
        for (int i = 0; i < ids.length; i++) {
            toggle(ids[i], canvas.getMode() == modes[i]);
        }
        int[] quickIds = {R.id.railWand, R.id.railLasso, R.id.railPaint,
                R.id.railEraser, R.id.railBrush, R.id.railBucket,
                R.id.railPicker, R.id.railMove, R.id.railPan};
        int[] quickModes = {CanvasView.MODE_WAND, CanvasView.MODE_LASSO,
                CanvasView.MODE_PAINT, CanvasView.MODE_ERASE_PIXELS,
                CanvasView.MODE_BRUSH, CanvasView.MODE_BUCKET,
                CanvasView.MODE_PICKER, CanvasView.MODE_MOVE, CanvasView.MODE_PAN};
        for (int i = 0; i < quickIds.length; i++) {
            toggle(quickIds[i], canvas.getMode() == quickModes[i]);
        }
    }

    private int luminance(int c) {
        return (Color.red(c) * 77 + Color.green(c) * 151 + Color.blue(c) * 28) >> 8;
    }

    /** Una linea que dice que hace la herramienta activa. */
    private String modeHint() {
        switch (canvas.getMode()) {
            case CanvasView.MODE_WAND:
                return "toca y agarra ese color";
            case CanvasView.MODE_BRUSH:
                return "pinta la SELECCION azul";
            case CanvasView.MODE_ERASER:
                return "quita de la selección azul";
            case CanvasView.MODE_ERASE_PIXELS:
                return "borra los píxeles de la imagen";
            case CanvasView.MODE_LASSO:
                return "rodea con el dedo";
            case CanvasView.MODE_SCISSORS:
                return "arrastra por el contorno";
            case CanvasView.MODE_MOVE:
                return "arrastra la seleccion";
            case CanvasView.MODE_CLONE:
                return "copia de un lado a otro";
            case CanvasView.MODE_PAINT:
                return "pinta con el COLOR de abajo";
            case CanvasView.MODE_BUCKET:
                return "rellena de color";
            case CanvasView.MODE_PICKER:
                return "toma un color de la imagen";
            default:
                return "mueve la imagen";
        }
    }

    private String modeName() {
        switch (canvas.getMode()) {
            case CanvasView.MODE_WAND:
                return "Varita";
            case CanvasView.MODE_BRUSH:
                return "Selección +";
            case CanvasView.MODE_ERASER:
                return "Selección −";
            case CanvasView.MODE_ERASE_PIXELS:
                return "Borrar imagen";
            case CanvasView.MODE_LASSO:
                return "Lazo";
            case CanvasView.MODE_CLONE:
                return "Clonar";
            case CanvasView.MODE_PAINT:
                return "Pincel color";
            case CanvasView.MODE_BUCKET:
                return "Balde";
            case CanvasView.MODE_PICKER:
                return "Cuentagotas";
            case CanvasView.MODE_SCISSORS:
                return "Tijeras";
            case CanvasView.MODE_MOVE:
                return "Mover";
            default:
                return "Mano";
        }
    }

    private boolean needProject() {
        if (canvas.getProject() == null) {
            toast("Abre una imagen primero");
            return false;
        }
        return true;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------
    // CanvasView.Callback
    // ------------------------------------------------------------------

    @Override
    public void onBusy(boolean busy) {
        status.setAlpha(busy ? 0.5f : 1f);
        findViewById(R.id.btnExport).setEnabled(!busy);
    }

    @Override
    public void onChanged() {
        if (canvas.getIsolatedLayer() != null) canvas.isolateLayer(canvas.getIsolatedLayer());
        else if (!canvas.isBaseVisible()) canvas.refreshLayersPreview();
        if (findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE) buildLayersPanel();
        updateUi();
    }

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    @Override
    public void onColorPicked(int color) {
        updateUi();
        canvas.showHud(String.format(Locale.US, "#%06X", color & 0xFFFFFF));
    }

    @Override
    public void onUndoGesture() {
        canvas.doUndo();
        updateUi();
    }

    @Override
    public void onRedoGesture() {
        canvas.doRedo();
        updateUi();
    }

    /** Para no repetir los tres metodos del SeekBar en cada dialogo. */
    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }
}
