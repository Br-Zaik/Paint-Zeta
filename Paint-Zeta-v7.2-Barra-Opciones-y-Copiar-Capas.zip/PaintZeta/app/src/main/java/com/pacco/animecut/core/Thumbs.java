package com.pacco.animecut.core;

import android.graphics.Bitmap;

/** Miniaturas de capa para el panel, con cuadros grises donde hay transparencia. */
public final class Thumbs {

    private Thumbs() {
    }

    public static Bitmap forLayer(Project p, Layer layer, int size) {
        return make(p, layer.mask, layer.rasterPixels, size, layer.grayscale, layer.opacity);
    }

    public static Bitmap forMask(Project p, byte[] mask, int size) {
        return make(p, mask, null, size, false, 255);
    }

    public static Bitmap forBase(Project p, int size) {
        return make(p, null, p.pixels, size, false, 255);
    }

    private static Bitmap make(Project p, byte[] mask, int[] raster, int size, boolean gray, int opacity) {
        // Recorta solo la MINIATURA alrededor de las partes pintadas: un ojo pequeño
        // no queda invisible por mostrar todo el lienzo de 2048x1536.
        int left = 0, top = 0, right = p.w, bottom = p.h;
        if (mask != null && p.w > 0 && p.h > 0) {
            int lx = p.w, ly = p.h, rx = -1, ry = -1;
            int stride = Math.max(1, Math.min(p.w, p.h) / 600);
            for (int y = 0; y < p.h; y += stride) {
                for (int x = 0; x < p.w; x += stride) {
                    int i = y * p.w + x;
                    int alpha = raster != null ? (raster[i] >>> 24) : (mask[i] & 255);
                    if (alpha > 4) {
                        if (x < lx) lx = x; if (x > rx) rx = x;
                        if (y < ly) ly = y; if (y > ry) ry = y;
                    }
                }
            }
            if (rx >= lx && ry >= ly) {
                int pad = Math.max(5, Math.max(rx-lx, ry-ly)/9);
                left = Math.max(0,lx-pad); top = Math.max(0,ly-pad);
                right = Math.min(p.w,rx+stride+pad); bottom = Math.min(p.h,ry+stride+pad);
            }
        }
        int width = Math.max(1,right-left), height=Math.max(1,bottom-top);
        float scale = (float) size / Math.max(width,height);
        int tw = Math.max(1, Math.round(width * scale));
        int th = Math.max(1, Math.round(height * scale));
        Bitmap b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        int[] row = new int[tw];
        for (int y = 0; y < th; y++) {
            int sy = Math.min(p.h - 1, top + y * height / th);
            int base = sy * p.w;
            for (int x = 0; x < tw; x++) {
                int sx = Math.min(p.w - 1, left + x * width / tw);
                int i = base + sx;
                int col = raster == null ? p.pixels[i] : raster[i];
                int a = (raster != null ? ((col >>> 24) & 255) : (mask == null ? 255 : (mask[i] & 0xFF))) * opacity / 255;
                if (gray) {
                    int g = (((col >> 16) & 255) * 77 + ((col >> 8) & 255) * 150 + (col & 255) * 29 + 128) >> 8;
                    col = (col & 0xFF000000) | (g << 16) | (g << 8) | g;
                }
                int checker = (((x >> 2) + (y >> 2)) & 1) == 0 ? 0xFF555555 : 0xFF3A3A3A;
                if (a == 0) {
                    row[x] = checker;
                } else if (a == 255) {
                    row[x] = 0xFF000000 | (col & 0xFFFFFF);
                } else {
                    row[x] = mix(checker, col, a);
                }
            }
            b.setPixels(row, 0, tw, 0, y, tw, 1);
        }
        return b;
    }

    private static int mix(int bg, int fg, int a) {
        int r = (((fg >> 16) & 0xFF) * a + ((bg >> 16) & 0xFF) * (255 - a)) / 255;
        int g = (((fg >> 8) & 0xFF) * a + ((bg >> 8) & 0xFF) * (255 - a)) / 255;
        int b = ((fg & 0xFF) * a + (bg & 0xFF) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
