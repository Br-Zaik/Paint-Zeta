package com.pacco.animecut.core;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Exporta cada capa como PNG transparente dentro de un ZIP.
 * Todas las capas salen del MISMO tamano de lienzo, tanto si exportas a
 * resolucion original como si reduces, asi que en Alight Motion entran
 * alineadas sin tocar nada.
 *
 * El bitmap se rellena fila por fila para no cargar la imagen entera
 * duplicada en memoria.
 */
public final class Exporter {

    private Exporter() {
    }

    public static int exportZip(ContentResolver cr, Project p, Uri uri, boolean includeRest,
                                int outW, int outH, int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");

        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os));
        zos.setLevel(1); // el PNG ya viene comprimido
        int count = 0;
        try {
            byte[] union = includeRest ? new byte[p.w * p.h] : null;
            int idx = 1;
            for (Layer l : p.layers) {
                if (!l.visible) continue;
                if (union != null) {
                    for (int i = 0; i < union.length; i++) {
                        int v = l.mask[i] & 0xFF;
                        if (v > (union[i] & 0xFF)) union[i] = (byte) v;
                    }
                }
                byte[] mask = l.rasterPixels != null ? flatOpacity(p.w * p.h, l.opacity) : withOpacity(l);
                int[] source = l.rasterPixels != null ? l.rasterPixels : pixelsFor(p, l.mask, edgeClean);
                String name = String.format(Locale.US, "%02d_%s.png", idx++, safe(l.name));
                zos.putNextEntry(new ZipEntry(name));
                writePng(p, l.grayscale ? toGray(source) : source, mask, false, outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            if (union != null && count > 0) {
                zos.putNextEntry(new ZipEntry("99_fondo_restante.png"));
                writePng(p, p.pixels, union, true, outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            zos.finish();
        } finally {
            try {
                zos.close();
            } catch (IOException ignored) {
            }
        }
        return count;
    }

    /** Dibujo compuesto a resolución ORIGINAL: el PNG debe incluir capas y su opacidad. */
    public static void exportCombinedPng(ContentResolver cr, Project p, Uri uri,
                                         boolean showBase) throws IOException {
        OutputStream stream = cr.openOutputStream(uri);
        if (stream == null) throw new IOException("No se pudo abrir el archivo de salida");
        try (BufferedOutputStream out = new BufferedOutputStream(stream)) {
            Bitmap result = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
            try {
                int[] row = new int[p.w];
                for (int y = 0; y < p.h; y++) {
                    int off = y * p.w;
                    for (int x = 0; x < p.w; x++) {
                        int pos=off+x;
                        int col=showBase?p.pixels[pos]:0;
                        for (Layer l : p.layers) {
                            if (!l.visible || (showBase && l.rasterPixels==null)) continue;
                            int src=l.rasterPixels!=null?l.rasterPixels[pos]:p.pixels[pos];
                            int op=l.opacity * (l.rasterPixels==null?(l.mask[pos]&255):255)/255;
                            if (l.grayscale) {
                                int gray=(((src>>16)&255)*77+((src>>8)&255)*150+(src&255)*29+128)>>8;
                                src=(src&0xFF000000)|(gray<<16)|(gray<<8)|gray;
                            }
                            col=over(col,src,op);
                        }
                        row[x]=col;
                    }
                    result.setPixels(row,0,p.w,0,y,p.w,1);
                }
                if(!result.compress(Bitmap.CompressFormat.PNG,100,out))
                    throw new IOException("No se pudo guardar PNG");
            } finally { result.recycle(); }
        }
    }

    private static int over(int dst,int src,int opacity) {
        int sa=((src>>>24)&255)*opacity/255;
        if(sa==0)return dst;
        int da=(dst>>>24)&255;
        int oa=sa+da*(255-sa)/255;
        if(oa==0)return 0;
        int r=(((src>>16)&255)*sa*255+((dst>>16)&255)*da*(255-sa))/(oa*255);
        int g=(((src>>8)&255)*sa*255+((dst>>8)&255)*da*(255-sa))/(oa*255);
        int b=((src&255)*sa*255+(dst&255)*da*(255-sa))/(oa*255);
        return (oa<<24)|(Math.min(255,r)<<16)|(Math.min(255,g)<<8)|Math.min(255,b);
    }

    private static byte[] flatOpacity(int len, int opacity) {
        byte[] m = new byte[len];
        java.util.Arrays.fill(m, (byte) opacity);
        return m;
    }

    /** Exporta el contenido REAL de una capa raster, preservando su transparencia. */
    public static void exportLayerPng(ContentResolver cr, Project p, Layer l, Uri uri,
                                      int outW, int outH, int edgeClean) throws IOException {
        if (l.rasterPixels == null) {
            exportPng(cr, p, l.mask, uri, outW, outH, edgeClean);
            return;
        }
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        try (BufferedOutputStream bos = new BufferedOutputStream(os)) {
            writePng(p, l.grayscale ? toGray(l.rasterPixels) : l.rasterPixels,
                    flatOpacity(p.w * p.h, l.opacity), false, outW, outH, bos);
        }
    }

    private static int[] toGray(int[] src) {
        int[] dst = new int[src.length];
        for (int i = 0; i < src.length; i++) {
            int c = src[i];
            int gray = (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 150 + (c & 255) * 29 + 128) >> 8;
            dst[i] = (c & 0xFF000000) | (gray << 16) | (gray << 8) | gray;
        }
        return dst;
    }

    /** Guarda una sola capa como PNG suelto. */
    public static void exportPng(ContentResolver cr, Project p, byte[] mask, Uri uri,
                                 int outW, int outH, int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writePng(p, pixelsFor(p, mask, edgeClean), mask, false, outW, outH, bos);
            bos.flush();
        } finally {
            try {
                bos.close();
            } catch (IOException ignored) {
            }
        }
    }

    /**
     * edgeClean: 0 nada, 1 defringe, 2 defringe y ademas quitar el color del
     * fondo que se quedo pegado en el borde.
     */
    /** Si la capa no esta al 100%, se baja su alfa antes de guardarla. */
    private static byte[] withOpacity(Layer l) {
        if (l.opacity >= 255) return l.mask;
        byte[] m = new byte[l.mask.length];
        for (int i = 0; i < m.length; i++) {
            m[i] = (byte) (((l.mask[i] & 0xFF) * l.opacity) / 255);
        }
        return m;
    }

    private static int[] pixelsFor(Project p, byte[] mask, int edgeClean) {
        if (edgeClean <= 0) return p.pixels;
        int bg = edgeClean >= 2 ? Defringe.guessBackground(p.pixels, mask, p.w, p.h) : 0;
        return Defringe.clean(p.pixels, mask, p.w, p.h, 3, edgeClean >= 2, bg);
    }

    private static void writePng(Project p, int[] pixels, byte[] mask, boolean invert,
                                 int outW, int outH, OutputStream out) {
        if (outW <= 0 || outH <= 0 || (outW == p.w && outH == p.h)) {
            writeFull(p, pixels, mask, invert, out);
        } else {
            writeScaled(p, pixels, mask, invert, outW, outH, out);
        }
    }

    private static void writeFull(Project p, int[] pixels, byte[] mask, boolean invert,
                                  OutputStream out) {
        Bitmap bmp = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        int[] row = new int[p.w];
        for (int y = 0; y < p.h; y++) {
            int off = y * p.w;
            for (int x = 0; x < p.w; x++) {
                int a = mask[off + x] & 0xFF;
                if (invert) a = 255 - a;
                a = a * ((pixels[off + x] >>> 24) & 255) / 255;
                row[x] = (a << 24) | (pixels[off + x] & 0x00FFFFFF);
            }
            bmp.setPixels(row, 0, p.w, 0, y, p.w, 1);
        }
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        bmp.recycle();
    }

    /**
     * Reduce promediando el bloque de pixeles que cae en cada pixel de salida.
     * El color se promedia pesado por el alfa para que el borde no arrastre
     * el color de lo que quedo transparente.
     */
    private static void writeScaled(Project p, int[] pixels, byte[] mask, boolean invert,
                                    int outW, int outH, OutputStream out) {
        Bitmap bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        int[] row = new int[outW];
        for (int y = 0; y < outH; y++) {
            int sy0 = (int) ((long) y * p.h / outH);
            int sy1 = (int) ((long) (y + 1) * p.h / outH);
            if (sy1 <= sy0) sy1 = sy0 + 1;
            if (sy1 > p.h) sy1 = p.h;
            for (int x = 0; x < outW; x++) {
                int sx0 = (int) ((long) x * p.w / outW);
                int sx1 = (int) ((long) (x + 1) * p.w / outW);
                if (sx1 <= sx0) sx1 = sx0 + 1;
                if (sx1 > p.w) sx1 = p.w;

                long sumA = 0, sumR = 0, sumG = 0, sumB = 0;
                int n = 0;
                for (int sy = sy0; sy < sy1; sy++) {
                    int off = sy * p.w;
                    for (int sx = sx0; sx < sx1; sx++) {
                        int i = off + sx;
                        int a = mask[i] & 0xFF;
                        if (invert) a = 255 - a;
                        int c = pixels[i];
                        a = a * ((c >>> 24) & 255) / 255;
                        sumA += a;
                        sumR += (long) ((c >> 16) & 0xFF) * a;
                        sumG += (long) ((c >> 8) & 0xFF) * a;
                        sumB += (long) (c & 0xFF) * a;
                        n++;
                    }
                }
                if (n == 0 || sumA == 0) {
                    row[x] = 0;
                } else {
                    int a = (int) (sumA / n);
                    int r = (int) (sumR / sumA);
                    int g = (int) (sumG / sumA);
                    int b = (int) (sumB / sumA);
                    row[x] = (a << 24) | (r << 16) | (g << 8) | b;
                }
            }
            bmp.setPixels(row, 0, outW, 0, y, outW, 1);
        }
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        bmp.recycle();
    }

    private static String safe(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c) || c == '_' || c == '-') sb.append(c);
            else sb.append('_');
        }
        String r = sb.toString();
        return r.isEmpty() ? "capa" : r;
    }
}
