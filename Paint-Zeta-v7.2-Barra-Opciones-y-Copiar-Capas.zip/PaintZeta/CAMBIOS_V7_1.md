# Paint Zeta v7.1 — barra lateral compacta y opciones de varita

- Barra compacta de accesos directos, siempre disponible a la izquierda (56 dp). No abre el panel grande por defecto.
- Botón de tres puntos en la barra compacta: muestra la paleta completa de herramientas (incluye tijeras, clonar, texto, filtros y lienzo).
- Varita mágica, en la barra compacta o en la paleta: activa selección por color y despliega automáticamente ajustes FINO, GLOBAL, RESTAR, LÍNEAS y BORDE, con nombres visibles.
- Barra contextual por encima del panel inferior para que no quede tapada por los sliders.
- Las otras herramientas cierran esa barra contextual; los accesos usan los mismos controladores que el proyecto base.
- No se han modificado el motor de dibujo, exportación ni la gestión de capas en esta corrección focalizada.
- Versión Android: versionCode 8, versionName 1.7.1-barra-compacta; applicationId conservado.

Comprobado: estructura de recursos XML, ids únicos y empaquetado del proyecto. Compilación Android pendiente de GitHub Actions.
