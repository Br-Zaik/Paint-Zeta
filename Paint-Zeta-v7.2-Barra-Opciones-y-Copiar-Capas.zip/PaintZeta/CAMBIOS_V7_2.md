# Paint Zeta v7.2 — accesos inferiores y copiar partes

Partimos de v7.1, sin borrar herramientas ni capas existentes.

- Se conserva la barra estrecha de herramientas a la izquierda.
- Bajo el lienzo se muestra una tira horizontal desplazable de opciones según la herramienta elegida.
- Varita: COPIAR A CAPA, FINO, GLOBAL, RESTAR, LÍNEAS, BORDE e instrucciones para sacar partes.
- Lazo/tijeras/pincel de selección: COPIAR A CAPA, invertir, limpiar azul, ajustes de borde e instrucciones.
- Pincel de dibujo y borrador: COLOR, DUREZA, ESTABILIZADOR, NUEVA CAPA y CAPAS.
- El botón de herramienta activa muestra una ayuda contextual, no abre inesperadamente la paleta.
- Si se toca COPIAR A CAPA sin una selección, se explica cómo crearla. Con una selección válida se copia a una capa ARGB y se abre la vista de capas para comprobar la miniatura/visibilidad.
- Los tres puntos mantienen la paleta completa y al cerrarla vuelven las opciones de la herramienta actual.
- El botón + inferior sigue creando capa transparente sin selección, o copiando la parte marcada en azul si la hay.
- Versión Android versionCode 9, versionName 1.7.2-controles-y-copia.

Este cambio NO reimplementa el motor de dibujo ni reemplaza las opciones avanzadas pendientes; requiere compilación/prueba en el dispositivo.
