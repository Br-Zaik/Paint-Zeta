# Paint Zeta v7 — interfaz lateral y funciones reales

## Cambios de esta entrega

- Menú flotante de herramientas a la IZQUIERDA, dos columnas con icono y nombre, desplegable desde el botón Herramientas o desde la herramienta activa. Se cierra tras elegir una herramienta. Ya no hay dos hileras fijas de herramientas abajo.
- Barra superior compacta y barra inferior con tamaño y opacidad, botones + y −, color, crear capa, panel de capas y exportar.
- Panel de capas ancho con selección, miniaturas con recorte visual para piezas pequeñas, capa activa resaltada, ojo visible, capa fondo, opacidad de capa con previsualización inmediata y controles de alfa, escala de grises, duplicar, ordenar, combinar y eliminar.
- Importar imagen dentro de un proyecto como NUEVA capa independiente, sin reemplazar el lienzo.
- Crear texto rasterizado en su propia capa (mover, pintar, borrar; no es texto vectorial reeditable).
- Panel de selección con radio 0 a 12 px, operaciones expandir/contraer/suavizar/endurecer/cerrar huecos. Vista previa sobre selección inicial, aplicar o cancelar.
- Panel sensibilidad de líneas con barras 0 a 255 y cerrar huecos 0 a 4, previsualización cian temporal; no altera imagen hasta confirmar el modo de barrera.
- Estabilizador ajustable 0-92% en vivo; cuadrícula y zoom pixelado/suave; simetría vertical aplicada a los trazos de pintar, borrar y selección, sin exportar guías.
- Exportar PNG compuesto REAL del dibujo completo (con capas, su visibilidad y opacidad), sin exigir crear capas. Sigue disponible ZIP de capas separadas para Alight Motion.
- Iconos HD originales, mismo applicationId com.pacco.animecut, versionCode 7 y corrección del conflicto Kotlin conservados.

## Alcance y limitaciones que no son botones ficticios

- No se implementaron capas vectoriales, carpetas de capas, varios modos de fusión ni capas de ajuste no destructivas: siguen fuera de la v7. Blanco/negro es un ajuste individual real, no una capa de ajuste general.
- Regla de simetría vertical + cuadrícula funcionan; no se añadieron reglas circular, perspectiva ni estabilización diferida como las de Ibis.
- Transformar incluye mover capas raster y las operaciones globales de giro/volteo que ya tenía la app; no se añadió escalado libre con controladores.
- La UI y recursos fueron verificados estáticamente (IDs, drawables, XML, sintaxis Java); no se ejecutó la APK en un teléfono en este entorno. Compilar con GitHub Actions y probar guardar/abrir antes de usar en proyectos importantes.
