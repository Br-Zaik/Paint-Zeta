package com.pacco.animecut;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * v8.62: cosas del sistema que van al abrir cada pantalla.
 * 1) Nivel del celular (gama baja/media/alta) para adaptar memoria e hilos.
 * 2) Registro de errores: si la app se cierra por un error, se guarda y la proxima vez se muestra
 *    con un boton para copiarlo (antes los errores se perdian).
 * 3) Android 15/16: la app se dibuja debajo de las barras del sistema (obligatorio desde Android
 *    16); se deja el espacio justo para que nada quede tapado.
 */
final class PzSystem {
    private PzSystem() { }

    private static boolean crashInstalled;
    private static final String CRASH_FILE = "ultimo_error.txt";

    /**
     * v8.86: letra grande del telefono. Los botones de la app tienen medida fija: con la letra del
     * sistema muy grande los textos se cortaban o se montaban. La letra de la app crece con la del
     * telefono, pero hasta 115%.
     */
    static final float FONT_MAX = 1.15f;

    static android.content.Context fontCap(android.content.Context base) {
        try {
            android.content.res.Configuration c = base.getResources().getConfiguration();
            if (c.fontScale <= FONT_MAX) return base;
            android.content.res.Configuration n = new android.content.res.Configuration(c);
            n.fontScale = FONT_MAX;
            return base.createConfigurationContext(n);
        } catch (Throwable t) {
            return base;
        }
    }

    /** Llamar al empezar onCreate (antes de setContentView). */
    static void init(Activity a) {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) a.getSystemService(Activity.ACTIVITY_SERVICE);
            long total = 0;
            boolean low = false;
            if (am != null) {
                android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                total = mi.totalMem;
                low = am.isLowRamDevice();
            }
            com.pacco.animecut.core.DeviceTier.init(total, low);
        } catch (Throwable t) {
            com.pacco.animecut.core.DeviceTier.init(0, false);
        }
        installCrashLog(a);
    }

    private static synchronized void installCrashLog(Activity a) {
        if (crashInstalled) return;
        crashInstalled = true;
        final File f = new File(a.getApplicationContext().getFilesDir(), CRASH_FILE);
        String v = "?";
        try { v = a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        final String version = v;
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread th, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    PrintWriter pw = new PrintWriter(sw);
                    pw.println("Paint Zeta " + version);
                    pw.println("Celular: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
                            + " | Android " + android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")");
                    pw.println("Nivel: " + com.pacco.animecut.core.DeviceTier.describe());
                    pw.println("Hilo: " + th.getName());
                    e.printStackTrace(pw);
                    pw.flush();
                    FileOutputStream fo = new FileOutputStream(f);
                    fo.write(sw.toString().getBytes("UTF-8"));
                    fo.close();
                } catch (Throwable ignored) {
                    // si no se puede guardar, igual sigue el cierre normal
                }
                if (prev != null) prev.uncaughtException(th, e);
            }
        });
    }

    /** Si la ultima vez la app se cerro por un error, lo muestra con "Copiar" (y lo borra). */
    static void showLastCrash(final Activity a) {
        final File f = new File(a.getFilesDir(), CRASH_FILE);
        if (!f.exists()) return;
        String text;
        try {
            byte[] b = new byte[(int) Math.min(f.length(), 60000)];
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            int n = 0, r;
            while (n < b.length && (r = in.read(b, n, b.length - n)) > 0) n += r;
            in.close();
            text = new String(b, 0, n, "UTF-8");
        } catch (Throwable t) {
            text = null;
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
        if (text == null || text.length() == 0) return;
        final String err = text;
        try {
            new AlertDialog.Builder(a)
                    .setTitle("La app se cerró por un error")
                    .setMessage("Se guardó lo que pasó. Toca \"Copiar\" y pégalo en el chat para arreglarlo.")
                    .setPositiveButton("Copiar", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) {
                            try {
                                android.content.ClipboardManager cm = (android.content.ClipboardManager) a.getSystemService(Activity.CLIPBOARD_SERVICE);
                                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("Error Paint Zeta", err));
                                android.widget.Toast.makeText(a, "Error copiado", android.widget.Toast.LENGTH_SHORT).show();
                            } catch (Throwable ignored) { }
                        }
                    })
                    .setNegativeButton("Cerrar", null)
                    .show();
        } catch (Throwable ignored) { }
    }

    /** Llamar despues de setContentView: deja el espacio de las barras del sistema (Android 15/16). */
    static void edgeToEdge(Activity a) {
        try {
            View content = a.findViewById(android.R.id.content);
            if (content == null) return;
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(content, new androidx.core.view.OnApplyWindowInsetsListener() {
                @Override public androidx.core.view.WindowInsetsCompat onApplyWindowInsets(View v, androidx.core.view.WindowInsetsCompat insets) {
                    androidx.core.graphics.Insets b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()
                            | androidx.core.view.WindowInsetsCompat.Type.displayCutout());
                    v.setPadding(b.left, b.top, b.right, b.bottom);
                    return androidx.core.view.WindowInsetsCompat.CONSUMED;
                }
            });
            androidx.core.view.ViewCompat.requestApplyInsets(content);
            // fondo oscuro: iconos de la barra de arriba y de abajo en claro
            androidx.core.view.WindowInsetsControllerCompat c =
                    androidx.core.view.WindowCompat.getInsetsController(a.getWindow(), a.getWindow().getDecorView());
            if (c != null) {
                c.setAppearanceLightStatusBars(false);
                c.setAppearanceLightNavigationBars(false);
            }
        } catch (Throwable ignored) {
            // en Android viejos no hace falta nada
        }
    }
}
