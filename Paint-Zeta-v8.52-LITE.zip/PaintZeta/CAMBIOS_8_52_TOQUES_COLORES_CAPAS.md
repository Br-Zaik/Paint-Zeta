# Paint Zeta v8.52: Toques suaves, colores como Ibis y capas como Ibis (sobre la v8.51)

Viene de tus 15 capturas:
- 1 a 3: la técnica de Procreate para piel natural.
- 4 a 7: la ventana de color de Ibis.
- 8 a 15: las capas de Ibis.

## 1. Toques suaves (técnica de Procreate para piel natural)

En el video, en una capa nueva se pintan manchas grandes: rojo en las mejillas, verde agua y azul cerca de los ojos, azul y amarillo en el mentón. Después se desenfoca todo y se baja la opacidad a 58 %. En internet se llama "técnica arcoíris".

- **Dónde**:
  - menú ⋮ → **COLOREAR (EN ORDEN)** → **2 Toques**;
  - Colorear fácil, paso 3;
  - Colorear manga ("Sombra rápida" y "Luz rápida" ahora abren Toques).
- **Tres tipos**, uno por ícono. Cada uno usa **una sola capa**, que se reutiliza:
  - **Color** (rubor, piel natural). Es Normal, y Multiplicar si debajo hay tinta de manga, para no tapar las líneas.
  - **Sombra** suave, en Multiplicar.
  - **Luz** "dar vida", en Superponer. Es la capa blanca en Superposición al 68 % de tus capturas de Ibis.
- **Al soltar el dedo, el trazo se funde solo.** Solo se difumina lo que acabas de pintar, así las manchas de antes no se vuelven cada vez más borrosas.
- **Controles**:
  - Fundir: cuánto se difumina cada trazo.
  - Fuerza: opacidad de la capa.
  - Goma suave, también se funde.
  - Fundir todo otra vez.
  - Borrar estos toques.
  - ✓ para terminar.
- **Colores listos** para cada tipo, más **+** para elegir otro.
- **El pincel**: mientras estás en Toques es una brocha suave y grande. Al terminar vuelve tu pincel con su tamaño.
- **Si no pintas nada**, al tocar ✓ la capa vacía se quita.

## 2. Ventana de color como Ibis

- **Un botón cambia** entre la **rueda** y la **paleta**.
- **Rueda**:
  - aro con cuadro;
  - deslizadores H, S y V (o R, G y B) con botones **− y +** para ajustar de a uno;
  - código HEX;
  - opacidad.
- **Paleta**:
  - **Mis colores** en una rejilla de 8 por fila, que se guardan para siempre y para todas las obras;
  - **+** guarda el color actual;
  - mantener pulsado un color lo quita;
  - debajo están los **Recientes** (24).
- **La primera vez**, Mis colores trae los 18 colores básicos. Se pueden quitar.
- Mezclar dos colores e Imagen de referencia siguen en "Más opciones".

## 3. Capas como Ibis

- **Opciones de capa en íconos**:
  - Modo, Flecha, Solo sobre lo pintado, Bloquear, Líneas balde y Nombre;
  - **Voltear ↔** y **Voltear ↕**, solo esa capa;
  - **Quitar blanco** (el "Blanco claro" de Ibis), en dos versiones:
    - una deja solo las líneas en negro;
    - otra guarda el color de las líneas;
  - **Difuminar** toda la capa, con deslizador;
  - Cambiar color, Fijar color y Guardar PNG.
- **24 modos de mezcla** (antes 6), en grupos con ícono:
  - Normal;
  - Oscurecer: Oscurecer, Multiplicar, Subexposición color, Subexposición lineal;
  - Aclarar: Aclarar, Pantalla, Sobreexposición color, Añadir;
  - Contraste: Superponer, Luz suave, Luz intensa, Luz viva, Luz lineal, Luz focal, Mezcla definida;
  - Diferencia: Diferencia, Exclusión, Sustraer, Dividir;
  - Color: Color, Tono, Saturación, Luminosidad.
- Mantener pulsado un modo dice para qué sirve. Por ejemplo, Aclarar con amarillo pinta lo negro de amarillo, que es la capa amarilla de tus capturas.

## Qué ya tenía la app (de tus capturas de Ibis)

- Girar y voltear toda la imagen.
- Girar el lienzo con dos dedos.
- Espejo de la vista.
- Fondo de capas (blanco o cuadros).
- Flecha (recorte) y bloquear alfa.
- Opacidad y Guardar capa como PNG.

## Pruebas

Lo que se probó en la PC:
- **Los 24 modos** comparados con la fórmula oficial en 4000 colores al azar cada uno: diferencia máxima de 3 de 255.
- **Fundir trazo**:
  - la mancha vieja queda igual;
  - el borde nuevo queda suave y sin borde oscuro;
  - la cantidad de color no cambia (0,04 %).
- **Velocidad en la PC**:
  - trazo normal 32 ms;
  - trazo gigante 106 ms;
  - difuminar una capa de 2000 × 2000: 0,3 s.
- **Quitar blanco**: el blanco queda transparente; al volver a poner fondo blanco da el mismo color.
- **Rubor en tu Horikita**: las mejillas quedan rosadas y suaves, y las líneas siguen negras.

Lo que falta probar en tu teléfono:
- La barra de Toques, la ventana de color nueva y las opciones de capa **solo se compilaron**.
