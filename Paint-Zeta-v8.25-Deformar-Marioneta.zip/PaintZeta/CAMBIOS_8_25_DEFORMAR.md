# Paint Zeta v8.25 — Deformar: Malla mejorada + Marioneta (ARAP)

Versión 8.25 (versionCode 63). Sin inteligencia artificial. Todo número de este documento sale de una prueba que se puede repetir (`sh tests/run_jvm_tests.sh`). Resultados completos: `docs/RESULTADOS_PRUEBAS_8_25.txt`. Imágenes: `docs/marioneta_antes_despues.png` y `docs/marioneta_sin_ampliar_lienzo.png`.

Sobre las pruebas:
- Usan el `CanvasView` real de la app dentro de un Android **simulado** en la computadora. No es un teléfono.
- Los tiempos son de la CPU del servidor. Un teléfono económico puede ser de 3 a 8 veces más lento.
- No se probó en un teléfono físico y no se pudo generar el APK.

## Qué cambió para ti

- Nuevo botón **Deformar** en el menú de herramientas (grupo MOVER Y ANIMAR), con dos pestañas:
  - **Malla**: la cuadrícula de antes, mejorada.
  - **Marioneta**: reemplaza a "Puntos de anclaje" con un motor nuevo.
- **Transformar** queda solo con Mover/escalar/girar y Perspectiva. Malla y Puntos ya no están ahí: no hay botones duplicados.
- Barra de Marioneta (botones chicos): Malla | Marioneta | Poner puntos | Fijar/soltar | Eliminar | Ver malla | Opciones | X | ✓.
- **Opciones** (panel aparte, no tapa al personaje): Rigidez (Flexible, Normal, Rígido), Densidad (Menos, Normal, Más), Expansión 0–20 px, Proteger la zona del punto (cara, manos), tamaño de la zona protegida, Evitar pliegues, Quitar todos los puntos.
- **Deshacer y Rehacer** de arriba, mientras deformas, deshacen puntos o nodos (no la obra).
- **Girar un punto**: tocas un punto naranja y arrastras el anillo blanco que aparece alrededor.
- **Menú > Ampliar lienzo**: agrega espacio transparente (arriba, abajo o a los lados). Hace falta para enderezar tu PNG: de pie, el personaje es más alto que la imagen.

## Marioneta: el motor nuevo (no es solo cambio de nombre)

- **Malla de silueta**: se arma sola sobre el dibujo (alfa > 0, más la Expansión). Partes que no se tocan tienen malla propia aunque estén a pocos píxeles. Ejemplo: un brazo separado del torso por un hueco transparente.
- **ARAP en dos pasos** (Igarashi 2005/2009): el giro se propaga por la malla. Antes, "Puntos de anclaje" solo promediaba traslaciones por distancia (Shepard) y estiraba en vez de girar.
- **Solver**: Cholesky de perfil con reordenación RCM, propio, sin librerías. Se factoriza al poner o quitar un punto. Al arrastrar solo se sustituye.
- **Punto fijo (azul)**: no se mueve y sujeta su zona (2 celdas). Así los pies quedan exactos.
- **Evitar pliegues**: si un arrastre invertiría triángulos, el punto se detiene antes. Si se apaga, los pliegues se ven en rojo con "Ver malla".
- **Vista previa = resultado final**: los dos salen del mismo rasterizador (`TriWarp`): bilineal en alfa premultiplicado y hasta 3x3 muestras donde se comprime.
  - La vista previa se calcula en un hilo propio y nunca frena el dedo.
  - En imágenes grandes, mientras arrastras se ve con menos resolución. Al soltar se ve más fina.
- **Dos dedos**: siempre zoom y desplazamiento. Si el primer dedo ya había empezado a mover un punto, ese movimiento se deshace.

## Malla: qué se mejoró

- Se quitó el límite de vecinos. Ahora el control es real: un nodo solo se detiene si la malla se doblaría sobre sí misma.
- El nodo ya no salta al dedo: conserva la distancia a la que lo tocaste.
- El resultado final se calcula en la CPU con el mismo rasterizador de calidad. Antes dependía de `drawBitmapMesh`.
- Deshacer y Rehacer de nodos dentro de la sesión. "Restablecer malla" está en Opciones.

## Resultados con tu PNG (personaje inclinado)

Flujo de la prueba: importar → Ampliar lienzo +220 px arriba → Deformar > Marioneta → poner los puntos tocando → fijar pies y rodilla → arrastrar pecho, hombro, cuello, cabeza y corbata en 8 rondas (40 arrastres con el dedo simulado) → aplicar → exportar PNG.

- Inclinación cadera→cabeza: de 35,7° a 5,1° respecto a la vertical.
- Triángulos invertidos: 0 durante todo el proceso.
- Pies fijos: 0 píxeles distintos en un círculo de 20 px alrededor de cada pie.
  - En toda la zona de zapatos y tobillos: 334 de 30 148 píxeles cambian, como mucho 5 niveles.
- Estiramiento máximo (σ mayor / σ menor): cabeza 1,21; torso 1,44. Solo 4 de 593 triángulos pasan de 1,3.
- Vista previa vs resultado aplicado: 0 píxeles distintos.
- PNG exportado vs capa: 0 píxeles distintos. El fondo sigue transparente y no aparece basura en lo transparente.
- Alfa total conservado: 99,0 %.
  - Lo que falta son brillos casi invisibles (alfa 1 a 8) que quedaron fuera del lienzo por la derecha.
- Deshacer devuelve el original exacto y Rehacer el resultado exacto. Cancelar no cambia ningún píxel.
- 100 gestos de dos dedos empezando encima de un punto: 0 px de desplazamiento y 0 puntos nuevos.

Lo que NO es perfecto, dicho claro:
- **Cadera y trasero del pantalón**: ahí se concentra el doblez. La curva trasera del pantalón queda algo abultada. Un retoque a mano con Especial o Malla lo mejora.
- **Corbata**: es una pieza aparte. Para que cuelgue recta hay que ponerle un punto en la punta y llevarla abajo (así se hizo en la prueba).
- **Sin ampliar el lienzo**: el personaje enderezado no cabe en 1024x1536. La cabeza llega a y = −142 y se corta. Ver `docs/marioneta_sin_ampliar_lienzo.png`.
  - La app avisa cuando una parte sale del lienzo.
- **Partes tapadas**: lo que estaba tapado (por ejemplo, detrás del brazo) no se inventa. Si una postura descubre algo, hay que separar esa parte en una capa y dibujarlo.

## Pruebas A–N

- **A** Enderezar inclinado: hecho, con los números de arriba.
- **B** Pies fijos: 0 píxeles distintos en 20 px alrededor de cada pie.
- **C** Mover un brazo separado 10 px del torso:
  - Torso con Marioneta: 0,00 px de desplazamiento medio. Con el método anterior (Shepard): 3,39 px.
  - Quedan 23 píxeles de borde distintos lejos del hombro.
- **D** Espalda curvada: la flecha de la curva baja de 88,9 a 2,7 px. Estiramiento peor 1,14.
- **E** Mover una pierna: la otra pierna tiene 0 píxeles distintos por debajo de la rodilla. Junto a la cadera cambian 179 (es la unión).
- **F** Proporciones (Flexible): la barra se alarga 10 % y el centro queda en el 50,0 %. Estiramiento 1,00.
- **G** Transparencia: sin basura en lo transparente y 99 % del alfa conservado.
- **H** Selección dentro de una escena: 0 píxeles cambiados fuera de la zona seleccionada y su forma deformada.
- **I** Líneas y colores: al girar la cara 30°, los píxeles de línea cambian +6,1 %. Color plano: 0 píxeles distintos.
- **J** Halos: 0 píxeles de borde sucios.
- **K** Aplicar, Cancelar, Deshacer y Rehacer: exactos (0 píxeles).
- **L** Dos dedos: 0 px en Marioneta y 0 nodos movidos en Malla.
- **M** Rendimiento: solo en el servidor (Normal: mover punto 0,13 ms, factorizar 2,3 ms, vista previa completa 43 ms; imagen 3000x4500: render final 377 ms). **No se midió en un teléfono.**
- **N** PNG exportado = resultado final: 0 píxeles distintos.
- Movimientos sueltos con tu PNG:
  - Mover solo la cabeza: el torso se mueve 0,07 px.
  - Mover solo el codo: el frente del torso se mueve 0,45 px.
  - Mover un pie: el otro zapato no se mueve. En tu dibujo las piernas se tocan, así que no quedan separadas.
- Malla: girar toda la cuadrícula 110° nodo por nodo, con 0 pliegues y la fila invertida (v8.24 no lo permitía).

## Archivos

Nuevos:
- `core/PuppetMesh.java`, `core/ArapSolver.java`, `core/ProfileCholesky.java`
- `core/TriWarp.java`, `core/PuppetSession.java`, `core/PixelTiles.java`, `core/LatestWorker.java`
- `res/drawable/ic_deform.xml`, `ic_mesh_grid.xml`, `ic_puppet.xml`, `ic_pin_add.xml`
- `tests/DeformTest.java`, `tests/DeformSimTest.java`, `tests/assets/personaje_inclinado.png`
- `docs/RESULTADOS_PRUEBAS_8_25.txt`, `docs/marioneta_antes_despues.png`, `docs/marioneta_sin_ampliar_lienzo.png`

Modificados:
- `view/CanvasView.java`:
  - Deformar, Malla con control de pliegues y Marioneta.
  - Render final en CPU y Deshacer dentro de la sesión.
  - Ampliar lienzo.
  - Se quitó el motor de Shepard.
- `MainActivity.java`: botón Deformar, barra, opciones y Ampliar lienzo.
- `core/Project.java`: `enlarge`.
- `app/build.gradle`: 8.25.
- `tests/run_jvm_tests.sh` y `tests/test_regressions.py`.

No se tocó: Especial (sus pruebas siguen pasando), balde y coloreado de v8.24, capas, formato de obra.

## Compilación

- Todo el código Java compila sin errores contra el `android.jar` oficial de Android 34 (469 clases). Script: `tests/sdkcheck/compile_with_android_jar.sh`.
- **No se pudo generar el APK.** En este entorno faltan Gradle con el plugin de Android, aapt2, d8 y AndroidX (Google Maven bloqueado).
- 41 grupos de pruebas y 23 comprobaciones del código: todos pasan.

## Pendiente

- Compilar en Android Studio y probar en el teléfono: fluidez de la vista previa y tiempo de "Creando la malla" en imágenes grandes.
- Opcional, no hecho: profundidad de puntos (qué parte queda delante), "Cortar malla" y modo Esqueleto.

## Cómo probarlo en tu teléfono

1. Abre tu PNG.
2. Menú ⋮ > Ampliar lienzo > Arriba 15 %.
3. Herramientas > Deformar. Se abre en Marioneta.
4. Toca los dos zapatos y la rodilla. Con cada uno elegido, toca Fijar (se ponen azules).
5. Toca la cadera (queda naranja, no la muevas).
6. Toca cabeza, cuello, hombro, pecho y la punta de la corbata.
7. Arrastra de a poco cabeza, cuello, hombro y pecho hacia atrás y arriba. Lleva la corbata hacia abajo.
8. Con dos dedos haz zoom para revisar. Con "Ver malla" puedes ver si hay rojo.
9. Toca ✓ y exporta la capa como PNG.
