package com.pacco.animecut.core;

import java.util.Arrays;
import java.util.HashMap;

/**
 * Deformacion "lo mas rigida posible" (ARAP) en dos pasos, segun
 * Igarashi, Moscovich y Hughes (2005) en la formulacion por aristas de
 * Igarashi e Igarashi (2009, "Implementing As-Rigid-As-Possible Shape
 * Manipulation and Surface Flattening").
 *
 * - Paso 1 (similitud): cada arista con sus vecinos busca el giro+escala que
 *   mejor explica la posicion. Es un sistema lineal: la rotacion se propaga
 *   por la conectividad de la malla, no por cercania.
 * - Paso 2 (escala): se quita la escala de cada arista y se resuelve otro
 *   sistema lineal para que las aristas recuperen su largo.
 * - Modo Rigido: ademas 3 iteraciones local/global (Sorkine y Alexa 2007)
 *   reutilizando la misma factorizacion del paso 2.
 * - Modo Flexible: solo el paso 1 (permite agrandar o achicar zonas).
 *
 * Los puntos (pines) son restricciones blandas de peso 1000 en cualquier
 * posicion de un triangulo (baricentricas). Las matrices dependen solo de la
 * malla y de DONDE estan los pines, no de a donde se arrastran: se factorizan
 * al agregar o quitar un pin y al arrastrar solo se sustituye.
 */
public final class ArapSolver {
    public static final int FLEXIBLE = 0, NORMAL = 1, RIGID = 2;
    private static final double W = 1000.0, W2 = W * W;
    private static final double EPS = 1e-9;

    private final PuppetMesh mesh;
    private final int nv;

    // Aristas: i, j y hasta 2 vertices opuestos (l, r; -1 si no hay)
    private int ne;
    private int[] eV;        // 4 por arista
    private double[] eP;     // 16 por arista: filas (c, s) sobre 8 variables locales
    private double[] eEx, eEy;
    private double[] eW;

    // Estado de restricciones
    private int nc;
    private int[] cV;        // 3 por restriccion
    private float[] cB;      // 3 por restriccion
    private int[] act;       // vertice -> indice activo (-1 si no se resuelve)
    private int na;
    private int[] actVert;   // indice activo -> vertice
    private int[] compMode;  // 0 sin pines, 1 un pin (traslada), 2 resuelve
    private int[] compPin;   // restriccion usada para trasladar
    private int[] follow;    // por componente sin pines: vertice a seguir
    private ProfileCholesky f1, f2;
    private double[] rhs1, x1, rhs2x, rhs2y, x2x, x2y;
    private boolean ready;

    public long lastFactorNanos, lastSolveNanos;

    public ArapSolver(PuppetMesh mesh) {
        this.mesh = mesh;
        this.nv = mesh.vertCount;
        buildEdges();
    }

    public int edgeCount() { return ne; }
    public int activeVertexCount() { return na; }

    private void buildEdges() {
        HashMap<Long, Integer> map = new HashMap<Long, Integer>(mesh.triCount * 4);
        int[] v = new int[mesh.triCount * 3 * 4];
        int n = 0;
        for (int t = 0; t < mesh.triCount; t++) {
            for (int k = 0; k < 3; k++) {
                int a = mesh.tri[t * 3 + k], b = mesh.tri[t * 3 + (k + 1) % 3], o = mesh.tri[t * 3 + (k + 2) % 3];
                int i = Math.min(a, b), j = Math.max(a, b);
                long key = ((long) i << 32) | j;
                Integer e = map.get(key);
                if (e == null) {
                    map.put(key, n);
                    v[n * 4] = i; v[n * 4 + 1] = j; v[n * 4 + 2] = o; v[n * 4 + 3] = -1;
                    n++;
                } else if (v[e * 4 + 3] == -1 && v[e * 4 + 2] != o) {
                    v[e * 4 + 3] = o;
                }
            }
        }
        ne = n;
        eV = Arrays.copyOf(v, n * 4);
        eP = new double[n * 16];
        eEx = new double[n];
        eEy = new double[n];
        eW = new double[n];
        Arrays.fill(eW, 1.0);
        float[] r = mesh.rest;
        double[] G = new double[8 * 4];
        double[] GtG = new double[16], inv = new double[16];
        for (int e = 0; e < n; e++) {
            int i = eV[e * 4];
            double ox = r[i * 2], oy = r[i * 2 + 1];
            int cnt = eV[e * 4 + 3] >= 0 ? 4 : 3;
            for (int k = 0; k < cnt; k++) {
                int q = eV[e * 4 + k];
                double x = r[q * 2] - ox, y = r[q * 2 + 1] - oy;
                int rr = 2 * k;
                G[rr * 4] = x; G[rr * 4 + 1] = y; G[rr * 4 + 2] = 1; G[rr * 4 + 3] = 0;
                G[(rr + 1) * 4] = y; G[(rr + 1) * 4 + 1] = -x; G[(rr + 1) * 4 + 2] = 0; G[(rr + 1) * 4 + 3] = 1;
            }
            int rows = cnt * 2;
            for (int a = 0; a < 4; a++)
                for (int b = 0; b < 4; b++) {
                    double s = 0;
                    for (int k = 0; k < rows; k++) s += G[k * 4 + a] * G[k * 4 + b];
                    GtG[a * 4 + b] = s;
                }
            if (!invert4(GtG, inv)) continue;
            // P = inv * G^T, filas 0 (c) y 1 (s)
            for (int row = 0; row < 2; row++) {
                for (int k = 0; k < rows; k++) {
                    double s = 0;
                    for (int a = 0; a < 4; a++) s += inv[row * 4 + a] * G[k * 4 + a];
                    eP[e * 16 + row * 8 + k] = s;
                }
            }
            int j = eV[e * 4 + 1];
            eEx[e] = r[j * 2] - ox;
            eEy[e] = r[j * 2 + 1] - oy;
        }
    }

    private static boolean invert4(double[] m, double[] out) {
        double[] a = new double[32];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) a[i * 8 + j] = m[i * 4 + j];
            a[i * 8 + 4 + i] = 1;
        }
        for (int c = 0; c < 4; c++) {
            int p = c;
            for (int r = c + 1; r < 4; r++) if (Math.abs(a[r * 8 + c]) > Math.abs(a[p * 8 + c])) p = r;
            if (Math.abs(a[p * 8 + c]) < 1e-12) return false;
            if (p != c) for (int k = 0; k < 8; k++) { double t = a[c * 8 + k]; a[c * 8 + k] = a[p * 8 + k]; a[p * 8 + k] = t; }
            double d = a[c * 8 + c];
            for (int k = 0; k < 8; k++) a[c * 8 + k] /= d;
            for (int r = 0; r < 4; r++) {
                if (r == c) continue;
                double f = a[r * 8 + c];
                if (f == 0) continue;
                for (int k = 0; k < 8; k++) a[r * 8 + k] -= f * a[c * 8 + k];
            }
        }
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) out[i * 4 + j] = a[i * 8 + 4 + j];
        return true;
    }

    /**
     * Define DONDE estan las restricciones (triangulo + baricentricas) y las
     * zonas rigidas (x, y, radio, factor) y factoriza. Devuelve false si no se
     * pudo (la malla queda sin deformar).
     */
    public boolean setup(int[] triOf, float[] bary, int count, float[] stiff, int stiffCount) {
        long t0 = System.nanoTime();
        ready = false;
        nc = count;
        cV = new int[count * 3];
        cB = new float[count * 3];
        for (int c = 0; c < count; c++) {
            int t = triOf[c];
            for (int k = 0; k < 3; k++) {
                cV[c * 3 + k] = mesh.tri[t * 3 + k];
                cB[c * 3 + k] = bary[c * 3 + k];
            }
        }
        // Pesos de aristas (zonas rigidas)
        Arrays.fill(eW, 1.0);
        float[] r = mesh.rest;
        for (int z = 0; z < stiffCount; z++) {
            float zx = stiff[z * 4], zy = stiff[z * 4 + 1], zr = stiff[z * 4 + 2], zf = stiff[z * 4 + 3];
            float r2 = zr * zr;
            for (int e = 0; e < ne; e++) {
                int i = eV[e * 4], j = eV[e * 4 + 1];
                float mx = (r[i * 2] + r[j * 2]) * .5f - zx, my = (r[i * 2 + 1] + r[j * 2 + 1]) * .5f - zy;
                if (mx * mx + my * my <= r2) eW[e] = Math.max(eW[e], zf);
            }
        }
        // Componentes con pines
        int[] pins = new int[mesh.compCount];
        compPin = new int[mesh.compCount];
        Arrays.fill(compPin, -1);
        for (int c = 0; c < count; c++) {
            int comp = mesh.vertComp[cV[c * 3]];
            pins[comp]++;
            if (compPin[comp] < 0) compPin[comp] = c;
        }
        compMode = new int[mesh.compCount];
        for (int k = 0; k < mesh.compCount; k++) compMode[k] = pins[k] == 0 ? 0 : pins[k] == 1 ? 1 : 2;
        act = new int[nv];
        Arrays.fill(act, -1);
        na = 0;
        actVert = new int[nv];
        for (int v = 0; v < nv; v++) if (compMode[mesh.vertComp[v]] == 2) { act[v] = na; actVert[na++] = v; }
        // Componentes sin pines: siguen al vertice con pines mas cercano.
        follow = new int[mesh.compCount];
        Arrays.fill(follow, -1);
        boolean anyMoved = false;
        for (int k = 0; k < mesh.compCount; k++) if (compMode[k] != 0) anyMoved = true;
        if (anyMoved) {
            float[] cxs = new float[mesh.compCount], cys = new float[mesh.compCount];
            int[] cn = new int[mesh.compCount];
            for (int v = 0; v < nv; v++) {
                int k = mesh.vertComp[v];
                cxs[k] += r[v * 2]; cys[k] += r[v * 2 + 1]; cn[k]++;
            }
            for (int k = 0; k < mesh.compCount; k++) {
                if (compMode[k] != 0 || cn[k] == 0) continue;
                float x = cxs[k] / cn[k], y = cys[k] / cn[k];
                float bd = Float.MAX_VALUE;
                for (int v = 0; v < nv; v++) {
                    if (compMode[mesh.vertComp[v]] == 0) continue;
                    float dx = r[v * 2] - x, dy = r[v * 2 + 1] - y, d = dx * dx + dy * dy;
                    if (d < bd) { bd = d; follow[k] = v; }
                }
            }
        }
        f1 = f2 = null;
        if (na > 0) {
            ProfileCholesky.Sym A1 = new ProfileCholesky.Sym(2 * na);
            ProfileCholesky.Sym A2 = new ProfileCholesky.Sym(na);
            double[] h0 = new double[8], h1 = new double[8];
            int[] var = new int[8];
            for (int e = 0; e < ne; e++) {
                int i = eV[e * 4];
                if (act[i] < 0) continue;
                int cnt = eV[e * 4 + 3] >= 0 ? 4 : 3;
                double w = eW[e];
                double ex = eEx[e], ey = eEy[e];
                int nvar = cnt * 2;
                for (int k = 0; k < nvar; k++) {
                    double p0 = eP[e * 16 + k], p1 = eP[e * 16 + 8 + k];
                    h0[k] = -(ex * p0 + ey * p1);
                    h1[k] = -(ey * p0 - ex * p1);
                }
                h0[0] -= 1; h0[2] += 1;
                h1[1] -= 1; h1[3] += 1;
                for (int k = 0; k < cnt; k++) {
                    int a = act[eV[e * 4 + k]];
                    var[2 * k] = 2 * a;
                    var[2 * k + 1] = 2 * a + 1;
                }
                for (int a = 0; a < nvar; a++)
                    for (int b = 0; b <= a; b++) {
                        double v = w * (h0[a] * h0[b] + h1[a] * h1[b]);
                        A1.add(var[a], var[b], v);
                    }
                int ai = act[i], aj = act[eV[e * 4 + 1]];
                A2.add(ai, ai, w);
                A2.add(aj, aj, w);
                A2.add(ai, aj, -w);
            }
            for (int c = 0; c < count; c++) {
                if (act[cV[c * 3]] < 0) continue;
                for (int a = 0; a < 3; a++)
                    for (int b = 0; b <= a; b++) {
                        int va = act[cV[c * 3 + a]], vb = act[cV[c * 3 + b]];
                        double v = W2 * cB[c * 3 + a] * cB[c * 3 + b];
                        if (va == vb && a != b) v *= 2; // (a,b) y (b,a) caen en la misma diagonal
                        A1.add(2 * va, 2 * vb, v);
                        A1.add(2 * va + 1, 2 * vb + 1, v);
                        A2.add(va, vb, v);
                    }
            }
            for (int a = 0; a < na; a++) {
                A1.add(2 * a, 2 * a, EPS);
                A1.add(2 * a + 1, 2 * a + 1, EPS);
                A2.add(a, a, EPS);
            }
            f1 = ProfileCholesky.factor(A1);
            f2 = ProfileCholesky.factor(A2);
            if (f1 == null || f2 == null) { lastFactorNanos = System.nanoTime() - t0; return false; }
            rhs1 = new double[2 * na];
            x1 = new double[2 * na];
            rhs2x = new double[na];
            rhs2y = new double[na];
            x2x = new double[na];
            x2y = new double[na];
        }
        ready = true;
        lastFactorNanos = System.nanoTime() - t0;
        return true;
    }

    public boolean isReady() { return ready; }

    /**
     * Calcula las posiciones deformadas (locales) para los destinos de cada
     * restriccion (x, y por restriccion).
     */
    public void solve(float[] target, int mode, float[] out) {
        long t0 = System.nanoTime();
        float[] r = mesh.rest;
        System.arraycopy(r, 0, out, 0, nv * 2);
        if (!ready) return;
        // Componentes con un solo pin: traslacion pura.
        float[] tx = new float[mesh.compCount], ty = new float[mesh.compCount];
        for (int k = 0; k < mesh.compCount; k++) {
            if (compMode[k] != 1) continue;
            int c = compPin[k];
            float px = 0, py = 0;
            for (int q = 0; q < 3; q++) {
                int v = cV[c * 3 + q];
                px += cB[c * 3 + q] * r[v * 2];
                py += cB[c * 3 + q] * r[v * 2 + 1];
            }
            tx[k] = target[c * 2] - px;
            ty[k] = target[c * 2 + 1] - py;
        }
        if (na > 0) {
            // Paso 1
            Arrays.fill(rhs1, 0);
            for (int a = 0; a < na; a++) {
                int v = actVert[a];
                rhs1[2 * a] = EPS * r[v * 2];
                rhs1[2 * a + 1] = EPS * r[v * 2 + 1];
            }
            for (int c = 0; c < nc; c++) {
                if (act[cV[c * 3]] < 0) continue;
                for (int q = 0; q < 3; q++) {
                    int a = act[cV[c * 3 + q]];
                    rhs1[2 * a] += W2 * cB[c * 3 + q] * target[c * 2];
                    rhs1[2 * a + 1] += W2 * cB[c * 3 + q] * target[c * 2 + 1];
                }
            }
            f1.solve(rhs1, x1);
            if (mode == FLEXIBLE) {
                for (int a = 0; a < na; a++) {
                    int v = actVert[a];
                    out[v * 2] = (float) x1[2 * a];
                    out[v * 2 + 1] = (float) x1[2 * a + 1];
                }
            } else {
                for (int a = 0; a < na; a++) { x2x[a] = x1[2 * a]; x2y[a] = x1[2 * a + 1]; }
                int iters = mode == RIGID ? 4 : 1;
                for (int it = 0; it < iters; it++) {
                    step2(target);
                }
                for (int a = 0; a < na; a++) {
                    int v = actVert[a];
                    out[v * 2] = (float) x2x[a];
                    out[v * 2 + 1] = (float) x2y[a];
                }
            }
        }
        for (int v = 0; v < nv; v++) {
            int k = mesh.vertComp[v];
            if (compMode[k] == 1) {
                out[v * 2] = r[v * 2] + tx[k];
                out[v * 2 + 1] = r[v * 2 + 1] + ty[k];
            }
        }
        for (int v = 0; v < nv; v++) {
            int k = mesh.vertComp[v];
            if (compMode[k] == 0 && follow[k] >= 0) {
                int f = follow[k];
                out[v * 2] = r[v * 2] + (out[f * 2] - r[f * 2]);
                out[v * 2 + 1] = r[v * 2 + 1] + (out[f * 2 + 1] - r[f * 2 + 1]);
            }
        }
        lastSolveNanos = System.nanoTime() - t0;
    }

    /** Un paso global con las rotaciones (similitud normalizada) de x2. */
    private void step2(float[] target) {
        float[] r = mesh.rest;
        for (int a = 0; a < na; a++) {
            int v = actVert[a];
            rhs2x[a] = EPS * r[v * 2];
            rhs2y[a] = EPS * r[v * 2 + 1];
        }
        for (int e = 0; e < ne; e++) {
            int i = eV[e * 4];
            if (act[i] < 0) continue;
            int cnt = eV[e * 4 + 3] >= 0 ? 4 : 3;
            double c = 0, s = 0;
            for (int k = 0; k < cnt; k++) {
                int a = act[eV[e * 4 + k]];
                double vx = x2x[a], vy = x2y[a];
                c += eP[e * 16 + 2 * k] * vx + eP[e * 16 + 2 * k + 1] * vy;
                s += eP[e * 16 + 8 + 2 * k] * vx + eP[e * 16 + 8 + 2 * k + 1] * vy;
            }
            double n = Math.sqrt(c * c + s * s);
            if (n < 1e-12) { c = 1; s = 0; } else { c /= n; s /= n; }
            double ex = eEx[e], ey = eEy[e];
            double tx = c * ex + s * ey, ty = -s * ex + c * ey;
            double w = eW[e];
            int ai = act[i], aj = act[eV[e * 4 + 1]];
            rhs2x[ai] -= w * tx; rhs2y[ai] -= w * ty;
            rhs2x[aj] += w * tx; rhs2y[aj] += w * ty;
        }
        for (int c = 0; c < nc; c++) {
            if (act[cV[c * 3]] < 0) continue;
            for (int q = 0; q < 3; q++) {
                int a = act[cV[c * 3 + q]];
                rhs2x[a] += W2 * cB[c * 3 + q] * target[c * 2];
                rhs2y[a] += W2 * cB[c * 3 + q] * target[c * 2 + 1];
            }
        }
        f2.solve(rhs2x, x2x);
        f2.solve(rhs2y, x2y);
    }
}
