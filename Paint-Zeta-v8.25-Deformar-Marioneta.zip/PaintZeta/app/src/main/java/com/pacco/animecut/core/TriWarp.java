package com.pacco.animecut.core;

/**
 * Rasterizador por triangulos con mapa INVERSO: para cada pixel destino se
 * calcula, con baricentricas del triangulo deformado, el punto exacto de la
 * imagen original y se toma su color. Lo usan la vista previa y el resultado
 * final de Marioneta y el resultado final de Malla, por eso coinciden.
 *
 * Calidad (igual criterio que el rasterizador de Especial, LiquifyRaster):
 * - bilineal en alfa premultiplicado: sin halo oscuro ni claro en bordes
 *   transparentes;
 * - si el triangulo se comprime (huella &gt; 1,3 px) se promedian hasta 3x3
 *   muestras repartidas en el pixel: sin dientes ni muare;
 * - malla en reposo: devuelve el pixel original exacto (bit a bit).
 *
 * Partes separadas (PuppetMesh): en una celda con varias partes, cada
 * triangulo solo toma los pixeles de SU parte, asi un brazo no "arrastra"
 * pixeles del torso vecino.
 *
 * Solapes: el primer triangulo que pone un pixel visible gana (sin doble
 * mezcla en las aristas compartidas).
 */
public final class TriWarp {

    private TriWarp() {}

    /** Datos opcionales de partes por triangulo (null en Malla). */
    public static final class Parts {
        public final PuppetMesh mesh;
        public Parts(PuppetMesh m) { mesh = m; }
    }

    /**
     * @param src     imagen original (coordenadas locales 0..src.width)
     * @param srcX    posicion en el lienzo del pixel (0,0) de src
     * @param srcY    idem
     * @param rest    posiciones de reposo (locales) por vertice
     * @param def     posiciones deformadas (en el LIENZO) por vertice
     * @param tri     indices, 3 por triangulo
     * @param triCount numero de triangulos
     * @param triPiece parte por triangulo (o null)
     * @param mesh    malla con etiquetas de partes (o null)
     * @param ox      origen del buffer en el lienzo
     * @param oy      origen del buffer en el lienzo
     * @param ow      ancho del buffer
     * @param oh      alto del buffer
     * @param scale   pixeles del buffer por pixel del lienzo (1 = final)
     * @param out     ARGB sin premultiplicar; debe venir en 0
     * @return pixeles escritos
     */
    public static long render(PixelTiles src, float srcX, float srcY,
            float[] rest, float[] def, int[] tri, int triCount, int[] triPiece, PuppetMesh mesh,
            int ox, int oy, int ow, int oh, float scale, int[] out) {
        long written = 0;
        final double inv = 1.0 / scale;
        for (int t = 0; t < triCount; t++) {
            int a = tri[t * 3], b = tri[t * 3 + 1], c = tri[t * 3 + 2];
            // Vertices deformados en coordenadas del buffer
            double ax = (def[a * 2] - ox) * scale, ay = (def[a * 2 + 1] - oy) * scale;
            double bx = (def[b * 2] - ox) * scale, by = (def[b * 2 + 1] - oy) * scale;
            double cx = (def[c * 2] - ox) * scale, cy = (def[c * 2 + 1] - oy) * scale;
            double minX = Math.min(ax, Math.min(bx, cx)), maxX = Math.max(ax, Math.max(bx, cx));
            double minY = Math.min(ay, Math.min(by, cy)), maxY = Math.max(ay, Math.max(by, cy));
            int x0 = Math.max(0, (int) Math.floor(minX - .5)), x1 = Math.min(ow - 1, (int) Math.ceil(maxX - .5));
            int y0 = Math.max(0, (int) Math.floor(minY - .5)), y1 = Math.min(oh - 1, (int) Math.ceil(maxY - .5));
            if (x0 > x1 || y0 > y1) continue;
            double den = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
            if (Math.abs(den) < 1e-9) continue;
            // l1 = ((px-ax)(cy-ay) - (py-ay)(cx-ax)) / den ; l2 = ((bx-ax)(py-ay) - (by-ay)(px-ax)) / den
            double l1x = (cy - ay) / den, l1y = -(cx - ax) / den;
            double l2x = -(by - ay) / den, l2y = (bx - ax) / den;
            // Reposo (indice de pixel = coordenada - 0.5)
            double rax = rest[a * 2] - .5, ray = rest[a * 2 + 1] - .5;
            double rbx = rest[b * 2] - .5, rby = rest[b * 2 + 1] - .5;
            double rcx = rest[c * 2] - .5, rcy = rest[c * 2 + 1] - .5;
            double ubx = rbx - rax, uby = rby - ray, ucx = rcx - rax, ucy = rcy - ray;
            // Jacobiano fuente / pixel de buffer
            double jxx = ubx * l1x + ucx * l2x, jyx = uby * l1x + ucy * l2x;
            double jxy = ubx * l1y + ucx * l2y, jyy = uby * l1y + ucy * l2y;
            double fpx = Math.sqrt(jxx * jxx + jyx * jyx), fpy = Math.sqrt(jxy * jxy + jyy * jyy);
            int nX = fpx <= 1.3 ? 1 : Math.min(3, (int) Math.ceil(fpx));
            int nY = fpy <= 1.3 ? 1 : Math.min(3, (int) Math.ceil(fpy));
            int n = nX * nY;
            // Partes
            byte[] lab = null;
            int lab0x = 0, lab0y = 0, labW = 0, myLab = 0;
            if (mesh != null && triPiece != null) {
                int p = triPiece[t];
                int cell = mesh.pieceCell[p];
                lab = mesh.cellLabels[cell];
                if (lab != null) {
                    labW = mesh.spacing + 2;
                    lab0x = (cell % mesh.cellsX) * mesh.spacing - 1;
                    lab0y = (cell / mesh.cellsX) * mesh.spacing - 1;
                    myLab = mesh.pieceLabel[p] & 255;
                }
            }
            final double eps = -1e-7;
            for (int y = y0; y <= y1; y++) {
                double py = y + .5;
                int row = y * ow;
                for (int x = x0; x <= x1; x++) {
                    int o = row + x;
                    if ((out[o] >>> 24) != 0) continue;
                    double px = x + .5;
                    double dx = px - ax, dy = py - ay;
                    double l1 = dx * l1x + dy * l1y, l2 = dx * l2x + dy * l2y;
                    if (l1 < eps || l2 < eps || 1 - l1 - l2 < eps) continue;
                    double sx = rax + ubx * l1 + ucx * l2;
                    double sy = ray + uby * l1 + ucy * l2;
                    int col;
                    if (n == 1) {
                        col = sample(src, sx, sy, lab, lab0x, lab0y, labW, myLab, srcX, srcY);
                    } else {
                        float sa = 0, sr = 0, sg = 0, sb = 0;
                        for (int j = 0; j < nY; j++) {
                            double oyv = (j + .5) / nY - .5;
                            for (int i = 0; i < nX; i++) {
                                double oxv = (i + .5) / nX - .5;
                                double qx = sx + jxx * oxv + jxy * oyv;
                                double qy = sy + jyx * oxv + jyy * oyv;
                                int s = sample(src, qx, qy, lab, lab0x, lab0y, labW, myLab, srcX, srcY);
                                float al = s >>> 24;
                                sa += al;
                                sr += ((s >>> 16) & 255) * al;
                                sg += ((s >>> 8) & 255) * al;
                                sb += (s & 255) * al;
                            }
                        }
                        int ia = (int) (sa / n + .5f);
                        if (ia <= 0) { col = 0; } else {
                            float k = 1f / sa;
                            col = (Math.min(255, ia) << 24) | (Math.min(255, (int) (sr * k + .5f)) << 16)
                                    | (Math.min(255, (int) (sg * k + .5f)) << 8) | Math.min(255, (int) (sb * k + .5f));
                        }
                    }
                    if ((col >>> 24) != 0) { out[o] = col; written++; }
                }
            }
        }
        return written;
    }

    /** Bilineal premultiplicada en indice de pixel (sx, sy). */
    private static int sample(PixelTiles src, double sx, double sy, byte[] lab, int l0x, int l0y, int lw, int my,
            float srcX, float srcY) {
        int x0 = (int) Math.floor(sx), y0 = (int) Math.floor(sy);
        double fx = sx - x0, fy = sy - y0;
        // Pegado a la rejilla: la malla en reposo devuelve el pixel exacto.
        if (fx < 1.0 / 512) fx = 0; else if (fx > 1 - 1.0 / 512) { fx = 0; x0++; }
        if (fy < 1.0 / 512) fy = 0; else if (fy > 1 - 1.0 / 512) { fy = 0; y0++; }
        int c00 = tap(src, x0, y0, lab, l0x, l0y, lw, my);
        if (fx == 0 && fy == 0) return c00;
        int c10 = fx == 0 ? 0 : tap(src, x0 + 1, y0, lab, l0x, l0y, lw, my);
        int c01 = fy == 0 ? 0 : tap(src, x0, y0 + 1, lab, l0x, l0y, lw, my);
        int c11 = (fx == 0 || fy == 0) ? 0 : tap(src, x0 + 1, y0 + 1, lab, l0x, l0y, lw, my);
        double w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
        double a00 = (c00 >>> 24) * w00, a10 = (c10 >>> 24) * w10, a01 = (c01 >>> 24) * w01, a11 = (c11 >>> 24) * w11;
        double sa = a00 + a10 + a01 + a11;
        if (sa < 1e-3) return 0;
        double r = ((c00 >>> 16) & 255) * a00 + ((c10 >>> 16) & 255) * a10 + ((c01 >>> 16) & 255) * a01 + ((c11 >>> 16) & 255) * a11;
        double g = ((c00 >>> 8) & 255) * a00 + ((c10 >>> 8) & 255) * a10 + ((c01 >>> 8) & 255) * a01 + ((c11 >>> 8) & 255) * a11;
        double b = (c00 & 255) * a00 + (c10 & 255) * a10 + (c01 & 255) * a01 + (c11 & 255) * a11;
        int ia = (int) (sa + .5);
        if (ia <= 0) return 0;
        if (ia > 255) ia = 255;
        double k = 1.0 / sa;
        return (ia << 24) | (Math.min(255, (int) (r * k + .5)) << 16) | (Math.min(255, (int) (g * k + .5)) << 8)
                | Math.min(255, (int) (b * k + .5));
    }

    private static int tap(PixelTiles src, int x, int y, byte[] lab, int l0x, int l0y, int lw, int my) {
        if (lab != null) {
            int lx = x - l0x, ly = y - l0y;
            if (lx >= 0 && ly >= 0 && lx < lw && ly < lw) {
                int l = lab[ly * lw + lx] & 255;
                if (l != 0 && l != my) return 0;
            }
        }
        return src.get(x, y);
    }
}
