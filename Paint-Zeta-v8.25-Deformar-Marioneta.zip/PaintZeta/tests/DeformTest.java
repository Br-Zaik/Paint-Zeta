import com.pacco.animecut.core.ArapSolver;
import com.pacco.animecut.core.PixelTiles;
import com.pacco.animecut.core.PuppetMesh;
import com.pacco.animecut.core.PuppetSession;
import com.pacco.animecut.core.TriWarp;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * v8.25 Motor de Marioneta (sin Android): malla de silueta + ARAP + TriWarp.
 * Pruebas C, D, E, F, I, J, M y movimientos aislados con el PNG real.
 * Uso: java DeformTest [rutaPNG]
 */
public final class DeformTest {
    static void log(String s) { System.out.println(s); }
    static void check(boolean ok, String m) { if (!ok) throw new AssertionError(m); }

    /** Sesion sobre un int[] (origen 0,0). */
    static PuppetSession session(int[] px, int w, int h, int density, int rig) {
        PuppetSession s = new PuppetSession(PixelTiles.of(px, w), w, h, 0, 0);
        s.setDensity(density);
        s.setRigidity(rig);
        s.buildMesh();
        return s;
    }

    static int[] render(PuppetSession s, int w, int h, int[] px) {
        int[] out = new int[w * h];
        PuppetSession.render(s.mesh(), s.positionsCopy(), new PixelTiles(PixelTiles.of(px, w), w, h, 256), 0, 0, w, h, 1f, out);
        return out;
    }

    static void fillRect(int[] px, int w, int x0, int y0, int x1, int y1, int c) {
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) px[y * w + x] = c;
    }

    /** Desplazamiento medio de los vertices cuyo reposo esta en el rectangulo. */
    static double meanDisp(PuppetSession s, float x0, float y0, float x1, float y1) {
        PuppetMesh m = s.mesh();
        float[] p = s.positionsCopy();
        double sum = 0; int n = 0;
        for (int v = 0; v < m.vertCount; v++) {
            float x = m.rest[v * 2], y = m.rest[v * 2 + 1];
            if (x < x0 || x > x1 || y < y0 || y > y1) continue;
            sum += Math.hypot(p[v * 2] - x, p[v * 2 + 1] - y);
            n++;
        }
        return n == 0 ? 0 : sum / n;
    }

    /** Metodo anterior (v8.24, Puntos de anclaje): promedio de Shepard de traslaciones. */
    static double shepardMeanDisp(float[][] pins, float[][] targets, boolean[] fixed, float x0, float y0, float x1, float y1, float step) {
        double sum = 0; int n = 0;
        float radius = 260f;
        for (float y = y0; y <= y1; y += step) for (float x = x0; x <= x1; x += step) {
            float numX = 0, numY = 0, den = 0;
            for (int i = 0; i < pins.length; i++) {
                float dx = x - pins[i][0], dy = y - pins[i][1], d2 = dx * dx + dy * dy;
                if (d2 > radius * radius * 4) continue;
                float dist = (float) Math.sqrt(Math.max(.0001f, d2));
                float q = Math.max(0, 1 - dist / (radius * 2));
                float wgt = (q * q + .0005f) / (d2 + 36f);
                if (fixed[i]) wgt *= 5.5f;
                float ddx = fixed[i] ? 0 : targets[i][0] - pins[i][0], ddy = fixed[i] ? 0 : targets[i][1] - pins[i][1];
                numX += ddx * wgt; numY += ddy * wgt; den += wgt;
            }
            if (den > 1e-6) { sum += Math.hypot(numX / den, numY / den); }
            n++;
        }
        return sum / n;
    }

    public static void main(String[] a) throws Exception {
        armTest();
        legTest();
        backTest();
        proportionTest();
        lineArtTest();
        haloTest();
        if (a.length > 0) pngIsolated(a[0]);
        if (a.length > 0) performance(a[0]);
        log("OK Motor de Marioneta");
    }

    // C: mover un brazo separado por un hueco de 10 px del torso
    static void armTest() {
        log("== C: mover un brazo sin arrastrar el torso ==");
        int w = 520, h = 520;
        int[] px = new int[w * h];
        fillRect(px, w, 180, 80, 300, 440, 0xFF3060A0);   // torso
        fillRect(px, w, 300, 90, 330, 130, 0xFF3060A0);   // hombro (une)
        fillRect(px, w, 310, 130, 336, 420, 0xFFE0B090); // brazo, separado 10 px del torso
        for (int y = 130; y < 420; y++) for (int x = 300; x < 310; x++) px[y * w + x] = 0;
        PuppetSession s = session(px, w, h, 1, ArapSolver.NORMAL);
        log("   Malla: " + s.mesh().vertCount + " vertices, celda " + s.mesh().spacing + " px");
        int t0 = s.addPin(240, 150, true), t1 = s.addPin(240, 400, true), t2 = s.addPin(200, 270, true);
        int sh = s.addPin(318, 108, true);
        int hand = s.addPin(323, 405, false);
        check(t0 >= 0 && t1 >= 0 && t2 >= 0 && sh >= 0 && hand >= 0, "puntos");
        s.beginGesture();
        for (int k = 1; k <= 10; k++) s.movePin(hand, 323 + 9 * k, 405 - 4 * k);
        double torso = meanDisp(s, 180, 160, 300, 440);
        double arm = meanDisp(s, 310, 300, 336, 420);
        float[][] pins = {{240, 150}, {240, 400}, {200, 270}, {318, 108}, {323, 405}};
        float[][] tg = {{240, 150}, {240, 400}, {200, 270}, {318, 108}, {413, 365}};
        boolean[] fx = {true, true, true, true, false};
        double old = shepardMeanDisp(pins, tg, fx, 180, 160, 300, 440, 8);
        log(String.format("   Mano movida 98 px. Desplazamiento medio del torso: Marioneta %.2f px; metodo anterior (Shepard) %.2f px. Brazo: %.1f px. Invertidos=%d",
                torso, old, arm, s.invertedCount()));
        check(torso < 1.0 && torso < old, "el torso se arrastro");
        int[] out = render(s, w, h, px);
        int torsoPx = 0;
        for (int y = 160; y < 440; y++) for (int x = 180; x < 300; x++) if (out[y * w + x] != px[y * w + x]) torsoPx++;
        int far = 0;
        for (int y = 200; y < 440; y++) for (int x = 180; x < 300; x++) if (out[y * w + x] != px[y * w + x]) far++;
        log("   Pixeles del torso distintos tras mover el brazo=" + torsoPx + " (debajo de y=200, lejos del hombro: " + far + ")");
    }

    // E: mover una pierna sin tocar la otra
    static void legTest() {
        log("== E: mover una pierna preservando la otra ==");
        int w = 400, h = 520;
        int[] px = new int[w * h];
        fillRect(px, w, 120, 40, 280, 160, 0xFF404048);  // cadera
        fillRect(px, w, 120, 160, 190, 480, 0xFF404048); // pierna izquierda
        fillRect(px, w, 210, 160, 280, 480, 0xFF505058); // pierna derecha (hueco de 20 px)
        PuppetSession s = session(px, w, h, 1, ArapSolver.NORMAL);
        s.addPin(155, 470, true);
        s.addPin(155, 300, true);
        s.addPin(200, 80, true);
        int foot = s.addPin(245, 470, false);
        s.beginGesture();
        for (int k = 1; k <= 10; k++) s.movePin(foot, 245 + 6 * k, 470 - 3 * k);
        int[] out = render(s, w, h, px);
        int other = 0, low = 0, maxL = 0, minY = 9999;
        for (int y = 170; y < 480; y++) for (int x = 120; x < 190; x++) {
            int o = out[y * w + x], q = px[y * w + x];
            if (o == q) continue;
            other++;
            minY = Math.min(minY, y);
            if (y >= 300) low++;
            for (int sh = 0; sh < 32; sh += 8) maxL = Math.max(maxL, Math.abs(((o >>> sh) & 255) - ((q >>> sh) & 255)));
        }
        log(String.format("   Pie derecho movido 67 px: pierna derecha media %.1f px; pierna izquierda: %d pixeles distintos (todos arriba de y=%d, junto a la cadera; max %d niveles), debajo de la rodilla=%d; invertidos=%d",
                meanDisp(s, 210, 300, 280, 480), other, minY, maxL, low, s.invertedCount()));
        check(low == 0 && meanDisp(s, 120, 170, 190, 480) < .5, "la otra pierna cambio");
    }

    // D: enderezar una espalda curvada (tira en arco)
    static void backTest() {
        log("== D: corregir una espalda curvada ==");
        int w = 700, h = 420;
        int[] px = new int[w * h];
        double cx = 350, cy = 520, R = 380, half = 22;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double d = Math.hypot(x + .5 - cx, y + .5 - cy), ang = Math.toDegrees(Math.atan2(y + .5 - cy, x + .5 - cx));
            if (Math.abs(d - R) <= half && ang > -140 && ang < -40) px[y * w + x] = 0xFF8A2030;
        }
        PuppetSession s = session(px, w, h, 2, ArapSolver.RIGID);
        // 5 puntos en la linea central del arco
        int np = 5;
        double a0 = Math.toRadians(-130), a1 = Math.toRadians(-50), arc = R * (a1 - a0);
        int[] ids = new int[np];
        float[][] tg = new float[np][2];
        for (int i = 0; i < np; i++) {
            double t = i / (double) (np - 1), an = a0 + (a1 - a0) * t;
            ids[i] = s.addPin((float) (cx + R * Math.cos(an)), (float) (cy + R * Math.sin(an)), i == np / 2);
            tg[i][0] = (float) (350 - arc / 2 + arc * t);
            tg[i][1] = (float) (cy - R);
        }
        // curvatura antes: flecha del arco
        double before = R - R * Math.cos((a1 - a0) / 2);
        for (int st = 1; st <= 10; st++) {
            for (int i = 0; i < np; i++) {
                if (i == np / 2) continue;
                PuppetSession.Pin p = s.pin(ids[i]);
                s.beginGesture();
                double t = i / (double) (np - 1), an = a0 + (a1 - a0) * t;
                float ox = (float) (cx + R * Math.cos(an)), oy = (float) (cy + R * Math.sin(an));
                s.movePin(ids[i], ox + (tg[i][0] - ox) * st / 10f, oy + (tg[i][1] - oy) * st / 10f);
            }
        }
        // linea central deformada: muestras entre puntos
        PuppetMesh m = s.mesh();
        float[] pos = s.positionsCopy();
        double maxDev = 0;
        float[] bc = new float[3];
        for (int i = 0; i <= 40; i++) {
            double an = a0 + (a1 - a0) * i / 40.0;
            float x = (float) (cx + R * Math.cos(an)), y = (float) (cy + R * Math.sin(an));
            int piece = m.pieceForPoint(x, y, 20);
            int t = m.locateInPiece(piece, x, y, bc);
            float dy = 0;
            for (int q = 0; q < 3; q++) dy += bc[q] * pos[m.tri[t * 3 + q] * 2 + 1];
            maxDev = Math.max(maxDev, Math.abs(dy - (cy - R)));
        }
        float[] sv = new float[m.triCount * 2];
        PuppetSession.singularValues(m, s.localPositionsCopy(), sv);
        double worst = 1;
        for (int t = 0; t < m.triCount; t++) worst = Math.max(worst, sv[t * 2] / Math.max(1e-6, Math.abs(sv[t * 2 + 1])));
        log(String.format("   Flecha de la curva: antes %.1f px, despues %.1f px (desvio max de la linea central). Estiramiento peor %.2f, invertidos=%d",
                before, maxDev, worst, s.invertedCount()));
        check(maxDev < before * .15 && s.invertedCount() == 0, "no se enderezo");
    }

    // F: proporciones (modo Flexible)
    static void proportionTest() {
        log("== F: cambiar proporciones (Flexible) ==");
        int w = 500, h = 200;
        int[] px = new int[w * h];
        fillRect(px, w, 100, 80, 400, 120, 0xFF20A060);
        PuppetSession s = session(px, w, h, 1, ArapSolver.FLEXIBLE);
        int a = s.addPin(105, 100, false), b = s.addPin(395, 100, false);
        s.beginGesture();
        s.movePin(b, 395 + 29, 100); // +10 %
        // punto medio sin pin
        PuppetMesh m = s.mesh();
        float[] pos = s.positionsCopy();
        float[] bc = new float[3];
        int t = m.locateInPiece(m.pieceForPoint(250, 100, 10), 250, 100, bc);
        float mx = 0;
        for (int q = 0; q < 3; q++) mx += bc[q] * pos[m.tri[t * 3 + q] * 2];
        double ratio = (mx - 105) / (424 - 105);
        float[] sv = new float[m.triCount * 2];
        PuppetSession.singularValues(m, s.localPositionsCopy(), sv);
        double worst = 1;
        for (int k = 0; k < m.triCount; k++) worst = Math.max(worst, sv[k * 2] / Math.max(1e-6, Math.abs(sv[k * 2 + 1])));
        log(String.format("   Barra alargada 10%%: el centro queda al %.1f%% del largo (ideal 50%%). Estiramiento peor %.2f", ratio * 100, worst));
        check(Math.abs(ratio - .5) < .02 && worst < 1.3, "proporciones");
    }

    // I: lineas y colores de anime al girar una parte
    static void lineArtTest() {
        log("== I: conservar lineas negras y colores planos ==");
        int w = 400, h = 400;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double d = Math.hypot(x + .5 - 200, y + .5 - 200);
            if (d < 100) px[y * w + x] = 0xFFF2C8A0;          // piel plana
            double ink = Math.max(0, Math.min(1, 1.5 + .5 - Math.abs(d - 98.5)));
            if (ink > 0) {
                int base = d < 100 ? 0xFFF2C8A0 : 0;
                int ia = (int) Math.round(ink * 255);
                if (base == 0) px[y * w + x] = (ia << 24) | 0x101010;
                else {
                    int r = (int) (0xF2 * (1 - ink) + 0x10 * ink), g = (int) (0xC8 * (1 - ink) + 0x10 * ink), bb = (int) (0xA0 * (1 - ink) + 0x10 * ink);
                    px[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | bb;
                }
            }
        }
        PuppetSession s = session(px, w, h, 1, ArapSolver.RIGID);
        float[][] p = {{200, 200}, {200, 130}, {270, 200}};
        int[] id = new int[3];
        for (int i = 0; i < 3; i++) id[i] = s.addPin(p[i][0], p[i][1], false);
        double ang = Math.toRadians(30);
        for (int st = 1; st <= 6; st++) {
            double an = ang * st / 6, c = Math.cos(an), sn = Math.sin(an);
            for (int i = 1; i < 3; i++) {
                s.beginGesture();
                float dx = p[i][0] - 200, dy = p[i][1] - 200;
                s.movePin(id[i], (float) (200 + dx * c - dy * sn), (float) (200 + dx * sn + dy * c));
            }
        }
        int[] out = render(s, w, h, px);
        int ink0 = 0, ink1 = 0, flatBad = 0, flatN = 0;
        for (int i = 0; i < px.length; i++) {
            if (dark(px[i])) ink0++;
            if (dark(out[i])) ink1++;
        }
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            if (Math.hypot(x + .5 - 200, y + .5 - 200) > 80) continue;
            flatN++;
            int c = out[y * w + x];
            int dd = Math.max(Math.abs(((c >> 16) & 255) - 0xF2), Math.max(Math.abs(((c >> 8) & 255) - 0xC8), Math.abs((c & 255) - 0xA0)));
            if (dd > 2 || (c >>> 24) != 255) flatBad++;
        }
        log(String.format("   Cara girada 30 grados: pixeles de linea %d -> %d (%.1f%%); color plano distinto en %d de %d pixeles",
                ink0, ink1, 100.0 * (ink1 - ink0) / ink0, flatBad, flatN));
        check(Math.abs(ink1 - ink0) < ink0 * .15 && flatBad == 0, "lineas o colores alterados");
    }

    static boolean dark(int c) {
        if ((c >>> 24) < 128) return false;
        int l = (((c >> 16) & 255) * 30 + ((c >> 8) & 255) * 59 + (c & 255) * 11) / 100;
        return l < 90;
    }

    // J: halos en bordes transparentes
    static void haloTest() {
        log("== J: sin halos en bordes transparentes ==");
        int w = 400, h = 300;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double d = Math.hypot((x + .5 - 200) / 1.6, y + .5 - 150);
            double a = Math.max(0, Math.min(1, 80.5 - d));
            if (a > 0) px[y * w + x] = ((int) Math.round(a * 255) << 24) | 0xE02020;
        }
        PuppetSession s = session(px, w, h, 1, ArapSolver.NORMAL);
        s.addPin(80, 150, true);
        s.addPin(200, 150, true);
        int tip = s.addPin(320, 150, false);
        s.beginGesture();
        for (int k = 1; k <= 8; k++) s.movePin(tip, 320 - 2 * k, 150 - 8 * k);
        int[] out = render(s, w, h, px);
        int edge = 0, bad = 0, maxDev = 0;
        for (int c : out) {
            int al = c >>> 24;
            if (al == 0 || al == 255) continue;
            edge++;
            int dev = Math.max(Math.abs(((c >> 16) & 255) - 0xE0), Math.max(Math.abs(((c >> 8) & 255) - 0x20), Math.abs((c & 255) - 0x20)));
            maxDev = Math.max(maxDev, dev);
            if (dev > 6) bad++;
        }
        log("   Borde semitransparente doblado: " + edge + " pixeles de borde, con color sucio (halo)=" + bad + ", desvio max=" + maxDev + " niveles");
        check(bad == 0, "halo en el borde");
    }

    // Movimientos aislados con el PNG real
    static void pngIsolated(String path) throws Exception {
        log("== PNG real: mover solo la cabeza, solo el brazo, solo una pierna ==");
        BufferedImage bi = ImageIO.read(new File(path));
        int w = bi.getWidth(), h = bi.getHeight();
        int[] px = bi.getRGB(0, 0, w, h, null, 0, w);
        float[][] fixed = {{520, 1490}, {770, 1460}, {690, 1040}, {710, 720}, {690, 420}};
        // cabeza
        PuppetSession s = session(px, w, h, 1, ArapSolver.NORMAL);
        for (float[] f : fixed) s.addPin(f[0], f[1], true);
        s.addPin(450, 290, true); // cuello
        int head = s.addPin(300, 150, false);
        s.beginGesture();
        for (int k = 1; k <= 6; k++) s.movePin(head, 300 + 8 * k, 150 - 6 * k);
        log(String.format("   Cabeza movida 60 px: cabeza %.1f px; torso (pecho/espalda) %.2f px; piernas %.2f px; invertidos=%d",
                meanDisp(s, 200, 60, 420, 240), meanDisp(s, 560, 380, 860, 640), meanDisp(s, 590, 760, 800, 1400), s.invertedCount()));
        // brazo (codo / manga)
        s = session(px, w, h, 1, ArapSolver.NORMAL);
        for (float[] f : fixed) s.addPin(f[0], f[1], true);
        s.addPin(430, 290, true);
        s.addPin(640, 640, true); // mano en el bolsillo
        int elbow = s.addPin(800, 540, false);
        s.beginGesture();
        for (int k = 1; k <= 6; k++) s.movePin(elbow, 800 + 6 * k, 540 + 2 * k);
        log(String.format("   Codo movido 38 px: manga %.1f px; frente del torso %.2f px; cabeza %.2f px; invertidos=%d",
                meanDisp(s, 760, 480, 860, 600), meanDisp(s, 480, 360, 600, 560), meanDisp(s, 200, 60, 420, 240), s.invertedCount()));
        // pierna (las dos piernas se tocan en este dibujo: se mueven juntas cerca del contacto)
        s = session(px, w, h, 1, ArapSolver.NORMAL);
        s.addPin(770, 1460, true);
        s.addPin(710, 720, true);
        s.addPin(740, 1100, true);
        int foot = s.addPin(520, 1490, false);
        s.beginGesture();
        for (int k = 1; k <= 6; k++) s.movePin(foot, 520 - 6 * k, 1490);
        log(String.format("   Pie izquierdo movido 36 px: zapato izq. %.1f px; zapato der. %.2f px; torso %.2f px. Las piernas se tocan: la otra pierna no queda separada",
                meanDisp(s, 470, 1440, 640, 1530), meanDisp(s, 730, 1400, 815, 1490), meanDisp(s, 480, 360, 860, 640)));
    }

    // M: rendimiento (servidor, NO telefono)
    static void performance(String path) throws Exception {
        log("== M: rendimiento en el servidor de pruebas (NO es un telefono) ==");
        BufferedImage bi = ImageIO.read(new File(path));
        int w = bi.getWidth(), h = bi.getHeight();
        int[] px = bi.getRGB(0, 0, w, h, null, 0, w);
        String[] names = {"Menos", "Normal", "Mas"};
        for (int d = 0; d < 3; d++) {
            PuppetSession s = session(px, w, h, d, ArapSolver.NORMAL);
            s.addPin(520, 1490, true); s.addPin(770, 1460, true); s.addPin(690, 1040, true);
            s.addPin(710, 720, false);
            int head = s.addPin(300, 150, false);
            s.beginGesture();
            long t0 = System.nanoTime();
            for (int k = 1; k <= 20; k++) s.movePin(head, 300 + 3 * k, 150 - k);
            double solve = (System.nanoTime() - t0) / 20e6;
            int[] out = new int[w * h];
            long r0 = System.nanoTime();
            PuppetSession.render(s.mesh(), s.positionsCopy(), new PixelTiles(PixelTiles.of(px, w), w, h, 192), 0, 0, w, h, 1f, out);
            double rend = (System.nanoTime() - r0) / 1e6;
            log(String.format("   %s: %d vertices, %d triangulos; crear malla %.0f ms; factorizar %.1f ms; mover punto %.2f ms; vista previa completa %.0f ms",
                    names[d], s.mesh().vertCount, s.mesh().triCount, s.lastBuildNanos / 1e6, s.lastFactorNanos() / 1e6, solve, rend));
        }
        // imagen grande sintetica 3000 x 4500
        int W = 3000, H = 4500;
        int[] big = new int[W * H];
        for (int y = 300; y < 4300; y++) for (int x = 900; x < 2100; x++) big[y * W + x] = 0xFF000000 | ((x * 7 + y * 3) & 0xFFFFFF);
        PuppetSession s = new PuppetSession(PixelTiles.of(big, W), W, H, 0, 0);
        s.setDensity(1);
        s.buildMesh();
        s.addPin(1500, 4200, true); s.addPin(1500, 2300, false);
        int top = s.addPin(1500, 500, false);
        s.beginGesture();
        long t0 = System.nanoTime();
        s.movePin(top, 1700, 520);
        double mv = (System.nanoTime() - t0) / 1e6;
        int tw = 256;
        int[] buf = new int[tw * tw];
        long r0 = System.nanoTime();
        float[] pos = s.positionsCopy();
        PixelTiles tiles = new PixelTiles(PixelTiles.of(big, W), W, H, 256);
        for (int y = 0; y < H; y += tw) for (int x = 0; x < W; x += tw) {
            java.util.Arrays.fill(buf, 0);
            PuppetSession.render(s.mesh(), pos, tiles, x, y, Math.min(tw, W - x), Math.min(tw, H - y), 1f, buf);
        }
        log(String.format("   Imagen grande 3000x4500: malla %d vertices, crear %.0f ms, mover %.1f ms, render final por bloques %.0f ms",
                s.mesh().vertCount, s.lastBuildNanos / 1e6, mv, (System.nanoTime() - r0) / 1e6));
        log("   No se midio en un telefono: no hay dispositivo Android disponible en este entorno.");
    }
}
