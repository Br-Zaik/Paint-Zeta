"""Pruebas estaticas del codigo fuente. No reemplazan ejecutar APK en Android."""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VIEW = (ROOT / 'app/src/main/java/com/pacco/animecut/view/CanvasView.java').read_text()
MAIN = (ROOT / 'app/src/main/java/com/pacco/animecut/MainActivity.java').read_text()


class SourceRegressions(unittest.TestCase):
    def test_paint_allocates_coverage_before_use(self):
        # Fallo reproducible de la version 8.14: stampPaint leia cov[i],
        # pero beginLayerStroke dejaba cov en null para MODE_PAINT.
        section = VIEW[VIEW.index('private boolean needsStrokeCoverage()'):VIEW.index('private boolean beginLayerStroke()')]
        self.assertIn('return mode == MODE_PAINT ||', section)
        paint_section = VIEW[VIEW.index('private void stampPaint(float cx, float cy)'):VIEW.index('private void stampParticles(')]
        self.assertIn('if (cov == null || strokeLayer == null) return;', paint_section)
        self.assertIn('int old = cov[i] & 0xFF;', VIEW)

    def test_liquify_modes_are_reachable(self):
        self.assertIn('String[] names = {"Arrastrar", "Contraer", "Expandir", "Suavizar", "Restaurar"}', MAIN)
        self.assertIn('canvas.setLiquifyType(which);', MAIN)
        self.assertIn('"Grosor\\n" + sizeText + "px"', MAIN)
        self.assertIn('"Fuerza " + v + "%"', MAIN)

    def test_color_and_liquify_strength_not_mixed(self):
        self.assertIn('if (canvas.getMode() != CanvasView.MODE_LIQUIFY) bottomOp.setProgress(op);', MAIN)
        self.assertIn('canvas.setEffectStrength(v / 100f);', MAIN)
        self.assertIn('canvas.setBrushOpacity(v / 100f);', MAIN)

    def test_liquify_engine_runs_off_ui_thread(self):
        core = ROOT / 'app/src/main/java/com/pacco/animecut/core'
        for name in ('LiquifyField', 'LiquifyStroke', 'LiquifyRaster', 'LiquifySource', 'LiquifySession', 'LiquifyFalloff'):
            self.assertTrue((core / (name + '.java')).exists(), name)
        for old in ('InverseLiquifyEngine', 'LiquifyFrameRenderer', 'LiquifyTopologyGuard'):
            self.assertFalse((core / (old + '.java')).exists(), old)
            self.assertNotIn(old, VIEW)
        # El View no calcula campo ni pixeles de Especial.
        self.assertIn('new com.pacco.animecut.core.LiquifySession(', VIEW)
        self.assertNotIn('renderLiquifyRegion', VIEW)
        self.assertNotIn('LIQUIFY_RENDER_WORKER', VIEW)
        self.assertNotIn('liquifyDx', VIEW)
        self.assertIn('android.view.Choreographer', VIEW)

    def test_liquify_composition_and_fold_guard(self):
        field = (ROOT / 'app/src/main/java/com/pacco/animecut/core/LiquifyField.java').read_text()
        # Arrastrar compone: U'(p) = U(T p) + (T p - p), no suma vectores.
        drag = field[field.index('case DRAG: {'):field.index('case PINCH:')]
        self.assertIn('coefAt((px + ox) * invS, (py + oy) * invS, q);', drag)
        self.assertIn('newU = q[0] + ox;', drag)
        self.assertIn('private boolean guard(', field)
        self.assertIn('evalDets(', field)
        self.assertIn('static void bspline(', field)
        stroke = (ROOT / 'app/src/main/java/com/pacco/animecut/core/LiquifyStroke.java').read_text()
        self.assertIn('LiquifyField.KAPPA * r / (k * falloff.maxSlope)', stroke)

    def test_liquify_input_uses_full_history_and_time(self):
        self.assertIn('getHistoricalX(0, hk)', VIEW)
        self.assertIn('liquifyEventTime = e.getHistoricalEventTime(hk);', VIEW)
        self.assertIn('|| mode == MODE_ERASER || mode == MODE_BRUSH || mode == MODE_LIQUIFY;', VIEW)
        self.assertIn('!isShapeTool() && mode != MODE_LIQUIFY', VIEW)
        self.assertNotIn('mode == MODE_LIQUIFY ? 32 : 48', VIEW)

    def test_all_resource_xml_parses(self):
        for file in ROOT.glob('app/src/main/res/**/*.xml'):
            with self.subTest(file=file.name):
                ET.parse(file)

    def test_simple_tools_and_automatic_lasso_copy(self):
        main_menu = MAIN[MAIN.index('private static final int[][] TOOLS = {'):MAIN.index('private String[] toolInfo(')]
        for removed in ('MODE_WAND', 'MODE_BRUSH', 'MODE_SCISSORS', 'MODE_MAGNET',
                        'MODE_ZONE', 'MODE_PATCH', 'MODE_CLONE', 'MODE_TONE',
                        'MODE_HEAL', 'MODE_LINE'):
            self.assertNotIn(removed, main_menu)
        for kept in ('MODE_LASSO', 'MODE_PAINT', 'MODE_ERASER', 'MODE_BUCKET',
                     'MODE_LIQUIFY', 'MODE_MARKER', 'MODE_BGERASE', 'MODE_TRANSFORM'):
            self.assertIn(kept, main_menu)
        self.assertIn('callback.onLassoCompleted()', VIEW)
        self.assertIn('partFromSelectionDialog(false)', MAIN)
        self.assertIn('canvas.clearTemporarySelectionAfterCopy()', MAIN)

    def test_two_fingers_use_single_transform_pipeline(self):
        touch = VIEW[VIEW.index('public boolean onTouchEvent(MotionEvent e)'):
                     VIEW.index('private void beginPending()')]
        self.assertNotIn('scaleDetector.onTouchEvent(e)', touch)
        zoom = VIEW[VIEW.index('private void twoFingers('):
                    VIEW.index('private void armQuickPick()')]
        self.assertIn('view.postTranslate(', zoom)
        self.assertIn('view.postScale(', zoom)
        # v8.23: transformacion ABSOLUTA desde el inicio del gesto (sin acumular
        # errores evento a evento) y dedos seguidos por su id, no por su indice.
        self.assertIn('view.set(navStart)', zoom)
        self.assertIn('findPointerIndex', zoom)
        self.assertIn('postInvalidateOnAnimation()', zoom)

    def test_menu_opens_visible_tool_and_guided_workflow(self):
        section = MAIN[MAIN.index('private void afterProjectLoaded('): MAIN.index('private void applyLoaded(')]
        self.assertIn('canvas.setMode(CanvasView.MODE_PAN)', section)
        self.assertIn('animationWorkflowDialog()', MAIN)
        self.assertIn('exportAnimationZip()', MAIN)
        self.assertIn('selectTool(CanvasView.MODE_LASSO)', MAIN)

    def test_auto_save_has_recoverable_backup(self):
        self.assertIn('final File bak = new File(dest.getAbsolutePath() + ".bak")', MAIN)
        self.assertIn('dest.renameTo(bak)', MAIN)
        self.assertIn('tmp.renameTo(dest)', MAIN)
        self.assertIn('recoveredBackup = true', MAIN)
        store = (ROOT / 'app/src/main/java/com/pacco/animecut/core/ProjectStore.java').read_text()
        self.assertIn('n.endsWith(".acut.bak")', store)
        self.assertIn('if (bak.exists()) bak.delete()', store)

    def test_lasso_copy_and_cut_are_available(self):
        self.assertIn('finishPartExtraction(!cut', MAIN)
        self.assertIn('finishPartExtraction(cut', MAIN)
        self.assertIn('canvas.clearTemporarySelectionAfterCopy()', MAIN)

    def test_special_hold_processing_and_alpha_clean_blur(self):
        # Presion fija: el tiempo avanza en cada fotograma.
        self.assertIn('s.tick(android.os.SystemClock.uptimeMillis());', VIEW)
        self.assertNotIn('liquifyHold', VIEW)
        raster = (ROOT / 'app/src/main/java/com/pacco/animecut/core/LiquifyRaster.java').read_text()
        self.assertIn('AlphaColors.mix(before, after, m / 255f)', raster)
        # v8.23 Borrosidad: original del trazo + original desenfocado (premultiplicado)
        # mezclados por la cobertura maxima: no depende de la velocidad.
        self.assertIn('PremulColor.blur(blurSrc, sw, sh, rb, blurTmp, blurOut)', VIEW)
        self.assertIn('AlphaColors.mix(strokeOriginalAt(row + x), blurred, nv / 255f * str)', VIEW)
        exporter = (ROOT / 'app/src/main/java/com/pacco/animecut/core/Exporter.java').read_text()
        self.assertIn('LEEME_Partes.txt', exporter)

    def test_optimized_background_eraser_keeps_undo_and_alpha(self):
        bg = VIEW[VIEW.index('private void runBgBucket('):VIEW.index('private void ensureGradient(int[] px)')]
        self.assertIn('final byte[][] preparedAlpha', bg)
        self.assertIn('undo.recordLayer(t, r);', bg)
        self.assertIn('BackgroundEraseAlpha.prepare(', bg)
        self.assertIn('System.arraycopy(', VIEW)  # fallback and other batch paths
        self.assertIn('setBusy(false);', bg)
        self.assertIn('despeckle(r);', bg)  # fallback when low RAM

    def test_zoom_and_large_strokes_defer_compositing(self):
        self.assertIn('(mode == MODE_LIQUIFY ? 260_000L : 20_000L) : 60_000L)', VIEW)
        self.assertIn('if (!drawing) scheduleDetail();', VIEW)
        self.assertIn('private final float[] viewMatrixValues', VIEW)

    def test_heavy_tools_do_not_replay_all_event_history(self):
        touch = VIEW[VIEW.index('public boolean onTouchEvent(MotionEvent e)'):VIEW.index('private void beginPending()')]
        self.assertIn('boolean processHistory = mode == MODE_LASSO', touch)
        self.assertIn('if (processHistory && e.getPointerCount() == 1)', touch)
        self.assertIn('mode == MODE_BGERASE ? .48f', VIEW)

    def test_liquify_preview_and_final_use_same_sampler(self):
        session = (ROOT / 'app/src/main/java/com/pacco/animecut/core/LiquifySession.java').read_text()
        # Un unico rasterizador para vista previa y confirmacion.
        self.assertEqual(session.count('raster.renderTile('), 2)  # render normal + reconstruccion al cancelar
        end = session[session.index('case CMD_END:'):session.index('case CMD_CANCEL:')]
        self.assertIn('stroke.finish(sink);', end)
        self.assertIn('renderSome(true);', end)

    def test_keep_curva_polilinea_malla_unchanged_and_distinct_eraser_icons(self):
        main_menu = MAIN[MAIN.index('private static final int[][] TOOLS = {'):MAIN.index('private String[] toolInfo(')]
        self.assertIn('MODE_CURVE', main_menu)
        self.assertIn('MODE_POLY', main_menu)
        self.assertIn('MODE_TRANSFORM', main_menu)
        self.assertIn('R.drawable.ic_feather_edge', MAIN)
        self.assertIn('R.drawable.ic_range', MAIN)
        self.assertIn('"Suavizar borde del recorte"', MAIN)
        self.assertNotIn('dotsButton("Ajustar borde"', MAIN)

    def test_pinching_does_not_rotate_accidentally(self):
        zoom = VIEW[VIEW.index('private void twoFingers('):VIEW.index('private void armQuickPick()')]
        # v8.23: girar con dos dedos existe, pero solo pasa el umbral (temblor no gira),
        # sin salto (se resta el umbral) y se puede apagar.
        self.assertIn('NAV_ROT_START', zoom)
        self.assertIn('navRotOffset', zoom)
        self.assertIn('rotateEnabled', zoom)
        self.assertIn('view.postScale(', zoom)
        self.assertIn('view.postTranslate(', zoom)

    def test_preview_is_async_and_discarded_on_commit(self):
        # Bloques de otro trazo (cancelado o viejo) nunca se copian a la capa.
        self.assertIn('s.tileGeneration(k) != apply', VIEW)
        self.assertIn('if (!captureEffectStrokeBackup(liquifyTmpRect)) continue;', VIEW)
        # Deshacer/Rehacer/guardar esperan a que el ultimo trazo quede confirmado.
        # (v8.25: antes se atiende Deformar, cuya sesion no usa Especial)
        undo = VIEW[VIEW.index('public void doUndo() {'):VIEW.index('public void doRedo() {')]
        redo = VIEW[VIEW.index('public void doRedo() {'):VIEW.index('private void afterRestore(')]
        self.assertIn('finishLiquifyCommitNow();\n        if (isShapeTool()', undo)
        self.assertIn('finishLiquifyCommitNow();\n        if (undo == null) return;', redo)
        self.assertIn('finishLiquifyCommitNow();\n        if (!beginLayerStroke()) return;', VIEW)
        self.assertIn('recordEffectStrokeUndo("Especial");', VIEW)

    def test_v824_bucket_engine_and_simpler_layers_panel(self):
        bucket = VIEW[VIEW.index('private void runBucket('):VIEW.index('private boolean hasReferenceLayers()')]
        # un solo motor de balde para misma capa, otra capa y capa Color
        self.assertIn('BucketFill.compute(ref, owner.w, owner.h, sx, sy, prm, scratch)', bucket)
        self.assertIn('BucketFill.colorFor(', bucket)
        self.assertNotIn('darkestBand', VIEW)
        self.assertNotIn('buildFillBarrier', VIEW)
        actions = MAIN[MAIN.index('private void buildLayerActions()'):MAIN.index('private void layersMoreMenu()')]
        # "De lo azul" ya no es un boton fijo; crear capa desde la seleccion sigue en "Mas"
        self.assertNotIn('De lo azul', actions)
        self.assertIn('"Mas"', actions)
        self.assertIn('Crear capa desde la seleccion', MAIN)
        self.assertIn('partFromSelectionDialog(false)', MAIN)
        # "Preparar para colorear" se unio con "Lineas" (sin funciones duplicadas)
        self.assertNotIn('prepareColoringDialog', MAIN)
        self.assertNotIn('prepareForColoring', VIEW)
        self.assertIn('extractLinesLayer(ex, withColor.isChecked())', MAIN)
        # la proteccion de lineas de la brocha mezcla con la linea en vez de taparla
        self.assertIn('BucketFill.paperFraction(local, lw, lh, li, stopSeedColor)', VIEW)
        # iconos distintos para funciones distintas
        self.assertIn('R.drawable.ic_line_guard, "No pasar la linea negra"', MAIN)

    def test_v825_deformar_malla_marioneta(self):
        # Un solo boton DEFORMAR en el menu, con Malla y Marioneta; Transformar sin duplicados
        self.assertIn('{2, CanvasView.MODE_DEFORM, 0, 0}', MAIN)
        trans = MAIN[MAIN.index('} else if (mode == CanvasView.MODE_TRANSFORM) {'):MAIN.index('} else if (mode == CanvasView.MODE_DEFORM) {')]
        self.assertNotIn('setTransformType(2)', trans)
        self.assertNotIn('setTransformType(3)', trans)
        self.assertIn('private void buildDeformBar(LinearLayout bar)', MAIN)
        # El motor anterior de Puntos de anclaje (Shepard) ya no existe
        self.assertNotIn('sampleAnchorDisp', VIEW)
        self.assertNotIn('transformAnchors', VIEW)
        # Marioneta: malla de silueta + ARAP de dos pasos + render inverso por triangulos
        core = ROOT / 'app/src/main/java/com/pacco/animecut/core'
        self.assertIn('Igarashi', (core / 'ArapSolver.java').read_text())
        self.assertIn('ProfileCholesky.factor', (core / 'ArapSolver.java').read_text())
        self.assertIn('PuppetMesh.build', (core / 'PuppetSession.java').read_text())
        self.assertIn('TriWarp.render', VIEW)
        # Malla: sin limite de vecinos, con control real de pliegues
        self.assertNotIn('transformVerts[(transformNode - 1) * 2] + eps', VIEW)
        self.assertIn('countMeshFolds()', VIEW)
        # Deshacer durante la sesion actua sobre puntos/nodos, no sobre la obra apartada
        self.assertIn('deformHistory(true)', VIEW)
        # Ampliar lienzo para poder enderezar personajes que quedan mas altos
        self.assertIn('public void enlarge(int left, int top, int right, int bottom)', (core / 'Project.java').read_text())

    def test_version(self):
        gradle = (ROOT / 'app/build.gradle').read_text()
        self.assertIn('versionCode 63', gradle)
        self.assertIn('versionName "8.25"', gradle)


if __name__ == '__main__':
    unittest.main()
