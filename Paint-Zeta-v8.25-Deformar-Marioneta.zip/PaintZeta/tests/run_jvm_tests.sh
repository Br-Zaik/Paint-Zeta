#!/bin/sh
# Pruebas sin Android (JDK 17+). No sustituyen compilar el APK ni probar en un telefono.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
DIR="$(mktemp -d)"
trap 'rm -rf "$DIR"' EXIT
CORE="$ROOT/app/src/main/java/com/pacco/animecut/core"
javac -d "$DIR" \
    "$CORE/ColorDist.java" \
    "$CORE/BackgroundEraseAlpha.java" \
    "$CORE/AlphaColors.java" \
    "$CORE/LiquifyFalloff.java" \
    "$CORE/LiquifyField.java" \
    "$CORE/LiquifyStroke.java" \
    "$CORE/LiquifySource.java" \
    "$CORE/LiquifyRaster.java" \
    "$CORE/LiquifySession.java" \
    "$ROOT/tests/legacy/InverseLiquifyEngine.java" \
    "$ROOT/tests/legacy/LiquifyTopologyGuard.java" \
    "$ROOT/tests/BackgroundEraseAlphaTest.java" \
    "$ROOT/tests/AlphaColorsTest.java" \
    "$ROOT/tests/LiquifyEngineTest.java"
java -cp "$DIR" BackgroundEraseAlphaTest
java -cp "$DIR" AlphaColorsTest
# --quick omite la medicion de rendimiento (tarda mas)
java -Xmx2g -cp "$DIR" LiquifyEngineTest "${1:---quick}"
# Integracion: CanvasView REAL + simulacion minima de Android (tests/androidsim).
# Comprueba tambien que CanvasView y core compilan contra esas firmas de Android.
SIM="$(mktemp -d)"
trap 'rm -rf "$DIR" "$SIM"' EXIT
javac -nowarn -d "$SIM" -sourcepath "$ROOT/app/src/main/java:$ROOT/tests/androidsim" \
    "$ROOT/app/src/main/java/com/pacco/animecut/view/CanvasView.java" \
    "$ROOT"/app/src/main/java/com/pacco/animecut/core/*.java \
    "$ROOT/tests/androidsim/android/os/Sim.java" \
    "$ROOT/tests/LiquifyEngineTest.java" "$ROOT"/tests/legacy/*.java \
    "$ROOT/tests/CanvasEspecialSimTest.java" \
    "$ROOT/tests/SimKit.java" "$ROOT/tests/ToolsSimTest.java" "$ROOT/tests/StrokeEngineTest.java" "$ROOT/tests/BucketTest.java" \
    "$ROOT/tests/DeformTest.java" "$ROOT/tests/DeformSimTest.java"
java -cp "$SIM" CanvasEspecialSimTest
# v8.23: recorrido de pinceles y comportamiento de las herramientas (Android simulado)
java -cp "$SIM" StrokeEngineTest
java -Xmx2g -cp "$SIM" ToolsSimTest
# v8.24: balde (motor BucketFill) con imagenes parecidas a las capturas reales
java -Xmx2g -cp "$SIM" BucketTest
# v8.25: Deformar (Malla + Marioneta ARAP) con el PNG real del personaje inclinado
java -Xmx3g -cp "$SIM" DeformTest "$ROOT/tests/assets/personaje_inclinado.png"
java -Xmx3g -Dpz.root="$ROOT" -cp "$SIM" DeformSimTest
python3 -m unittest discover -s "$ROOT/tests" -p test_regressions.py -q
