package com.pacco.animecut.view;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;

import com.pacco.animecut.core.Vectorize;

/**
 * v8.41: dibuja el resultado de Vectorize con el motor de Android (curvas con antialias) a la
 * escala pedida. Las formas van apiladas (grandes primero) con un trazo de 1 px del mismo color
 * para que no queden rendijas; el alfa (personaje recortado) se dibuja aparte y se aplica.
 */
public final class VectorPaint {
    private VectorPaint() { }

    public static int[] render(Vectorize.Result r, float s) {
        int W = Math.max(1, Math.round(r.w * s)), H = Math.max(1, Math.round(r.h * s));
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL_AND_STROKE);
        p.setStrokeWidth(s);
        p.setStrokeJoin(Paint.Join.ROUND);
        Path path = new Path();
        for (Vectorize.Shape sh : r.shapes) {
            build(path, sh.path, s);
            p.setColor(sh.color | 0xFF000000);
            c.drawPath(path, p);
        }
        int[] out = new int[W * H];
        b.getPixels(out, 0, W, 0, 0, W, H);
        b.recycle();
        if (!r.alpha.isEmpty()) {
            Bitmap a = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
            Canvas ca = new Canvas(a);
            Paint pa = new Paint(Paint.ANTI_ALIAS_FLAG);
            pa.setStyle(Paint.Style.FILL);
            PorterDuffXfermode clear = new PorterDuffXfermode(PorterDuff.Mode.CLEAR);
            for (Vectorize.Shape sh : r.alpha) {
                build(path, sh.path, s);
                pa.setXfermode(sh.clear ? clear : null);
                pa.setColor(0xFFFFFFFF);
                ca.drawPath(path, pa);
            }
            int[] row = new int[W];
            for (int y = 0; y < H; y++) {
                a.getPixels(row, 0, W, 0, y, W, 1);
                int o = y * W;
                for (int x = 0; x < W; x++) out[o + x] = (out[o + x] & 0x00FFFFFF) | (row[x] & 0xFF000000);
            }
            a.recycle();
        }
        return out;
    }

    static void build(Path g, float[] p, float s) {
        g.reset();
        int i = 0;
        while (i < p.length) {
            int op = (int) p[i++];
            if (op == 0) g.moveTo(p[i++] * s, p[i++] * s);
            else if (op == 1) g.lineTo(p[i++] * s, p[i++] * s);
            else if (op == 2) g.quadTo(p[i++] * s, p[i++] * s, p[i++] * s, p[i++] * s);
            else g.close();
        }
    }
}
