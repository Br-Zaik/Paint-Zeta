package com.pacco.animecut.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * v8.41 "Vectorizar": convierte la imagen en FORMAS de color liso con bordes curvos (como un
 * dibujo vectorial). Sirve para quitar el fondo y colorear mas facil (cada zona es un solo color,
 * sin ruido JPEG ni dientes) y para ampliar x2/x4 sin que se pixele. Codigo propio, Java puro
 * (sin Potrace ni AutoTrace, que son GPL). Se prueba en PC con las imagenes reales.
 *
 * Pasos:
 *  1. Paleta: k-medias en OKLab (8-32 colores) sobre una muestra; cada pixel al color mas cercano.
 *     Lo transparente es una "zona" aparte.
 *  2. Limpieza: un filtro de mayoria 3x3 quita el ruido y las zonas chicas (menos de minArea) se
 *     unen a la vecina con la que comparten mas borde.
 *  3. Contorno de cada zona siguiendo los bordes de los pixeles; luego puntos medios (adios a la
 *     escalera), simplificacion (Douglas-Peucker) y curvas cuadraticas; las esquinas agudas
 *     se respetan.
 *  4. Se dibuja "apilado": primero las zonas grandes y encima las chicas (sin huecos entre zonas).
 *     El alfa (personaje recortado) se vectoriza igual y se aplica aparte.
 */
public final class Vectorize {
    private Vectorize() { }

    public static final class Params {
        /** Cantidad de colores (8..32). */
        public int colors = 16;
        /** 0 simple (formas grandes), 1 normal, 2 fino (mas detalle). */
        public int detail = 1;
    }

    /** Una forma: color y contorno. path: 0=M x y, 1=L x y, 2=Q cx cy x y, 3=Z. */
    public static final class Shape {
        public int color;
        public float[] path;
        public int area;
        /** Solo en las formas del alfa: true = transparente. */
        public boolean clear;
    }

    public static final class Result {
        public int w, h;
        public final List<Shape> shapes = new ArrayList<Shape>();
        /** Formas del alfa (vacio si la imagen no tiene transparencia). */
        public final List<Shape> alpha = new ArrayList<Shape>();
        public int[] palette;
        public int regions;
    }

    public interface Progress {
        /** pct 0..100; devolver false = cancelar. */
        boolean step(int pct);
    }

    public static Result trace(int[] px, int W, int H, Params p, Progress pr) {
        Result res = new Result();
        res.w = W;
        res.h = H;
        int N = W * H;
        boolean hasAlpha = false;
        for (int i = 0; i < N; i += 3) if ((px[i] >>> 24) < 128) { hasAlpha = true; break; }
        int k = Math.max(2, Math.min(64, p.colors));
        // ---- 1. paleta (k-medias OKLab)
        float[][] cen = palette(px, W, H, k);
        k = cen.length;
        res.palette = new int[k];
        for (int c = 0; c < k; c++) res.palette[c] = ZoneTone.fromOklab(cen[c][0], cen[c][1], cen[c][2]);
        if (pr != null && !pr.step(10)) return null;
        final int T = k;                       // etiqueta de lo transparente
        byte[] lab = new byte[N];
        java.util.HashMap<Integer, Integer> cache = new java.util.HashMap<Integer, Integer>();
        for (int i = 0; i < N; i++) {
            int c = px[i];
            if ((c >>> 24) < 128) { lab[i] = (byte) T; continue; }
            int key = c & 0x00FFFFFF;
            Integer hit = cache.get(key);
            if (hit == null) {
                float[] o = ZoneTone.oklab(c);
                int best = 0;
                float bd = Float.MAX_VALUE;
                for (int q = 0; q < k; q++) {
                    float d = dist(o, cen[q]);
                    if (d < bd) { bd = d; best = q; }
                }
                hit = best;
                if (cache.size() < 200000) cache.put(key, hit);
            }
            lab[i] = (byte) (int) hit;
        }
        // tinta: los pixeles mas oscuros que su entorno (lineas finas con antialias) van todos al
        // color mas oscuro; asi una linea no se corta en pedazos grises
        {
            int darkest = 0;
            for (int q = 1; q < k; q++) if (cen[q][0] < cen[darkest][0]) darkest = q;
            if (cen[darkest][0] < 0.45f) {
                float[] lum = new float[N];
                for (int i = 0; i < N; i++) lum[i] = ZoneTone.lum(px[i]);
                float[] bl = lum.clone();
                ZoneTone.box(bl, W, H, 3);
                for (int i = 0; i < N; i++)
                    if ((lab[i] & 0xFF) != T && lum[i] < 150f && bl[i] - lum[i] > 22f) lab[i] = (byte) darkest;
            }
        }
        if (pr != null && !pr.step(25)) return null;
        // ---- 2. mayoria 3x3 (quita puntitos sueltos de 1 px)
        if (p.detail < 2) lab = majority(lab, W, H, T + 1);
        int minArea = Math.max(p.detail == 0 ? 12 : p.detail == 1 ? 5 : 2,
                Math.round(N * (p.detail == 0 ? 0.0003f : p.detail == 1 ? 0.00008f : 0.00002f)));
        // las lineas oscuras finas (ojos, boca, contornos) valen mas: aguantan 4 veces mas chicas
        boolean[] dark = new boolean[k + 1];
        for (int q = 0; q < k; q++) dark[q] = cen[q][0] < 0.45f;
        int[] comp = new int[N];
        int nc = components(lab, W, H, comp);
        nc = mergeSmall(lab, comp, W, H, nc, minArea, T, dark);
        if (pr != null && !pr.step(45)) return null;
        // ---- 3. contornos
        float eps = p.detail == 0 ? 1.1f : p.detail == 1 ? 0.75f : 0.5f;
        res.regions = nc;
        int[] area = new int[nc];
        int[] first = new int[nc];
        Arrays.fill(first, -1);
        for (int i = 0; i < N; i++) {
            int c = comp[i];
            area[c]++;
            if (first[c] < 0) first[c] = i;
        }
        Integer[] order = new Integer[nc];
        for (int c = 0; c < nc; c++) order[c] = c;
        Arrays.sort(order, (a, b) -> Integer.compare(area[b], area[a]));
        int doneShapes = 0;
        for (int oi = 0; oi < nc; oi++) {
            int c = order[oi];
            if (first[c] < 0) continue;
            int l = lab[first[c]] & 0xFF;
            if (l == T) continue;                   // lo transparente va en el alfa
            float[] pts = outline(comp, W, H, c, first[c]);
            Shape s = new Shape();
            s.color = res.palette[l];
            s.area = area[c];
            s.path = smoothPath(pts, eps);
            res.shapes.add(s);
            if (pr != null && (++doneShapes & 63) == 0 && !pr.step(45 + 40 * oi / Math.max(1, nc))) return null;
        }
        // ---- 4. alfa
        if (hasAlpha) {
            byte[] al = new byte[N];
            for (int i = 0; i < N; i++) al[i] = (byte) ((lab[i] & 0xFF) == T ? 0 : 1);
            int[] ac = new int[N];
            int na = components(al, W, H, ac);
            na = mergeSmall(al, ac, W, H, na, minArea, -1, null);
            int[] aa = new int[na], af = new int[na];
            Arrays.fill(af, -1);
            for (int i = 0; i < N; i++) { aa[ac[i]]++; if (af[ac[i]] < 0) af[ac[i]] = i; }
            Integer[] ao = new Integer[na];
            for (int c = 0; c < na; c++) ao[c] = c;
            Arrays.sort(ao, (a, b) -> Integer.compare(aa[b], aa[a]));
            for (int c : ao) {
                if (af[c] < 0) continue;
                Shape s = new Shape();
                s.clear = al[af[c]] == 0;
                s.color = s.clear ? 0 : 0xFFFFFFFF;
                s.area = aa[c];
                s.path = smoothPath(outline(ac, W, H, c, af[c]), eps);
                res.alpha.add(s);
            }
        }
        if (pr != null) pr.step(100);
        return res;
    }

    // ------------------------------------------------------------------ paleta
    static float dist(float[] a, float[] b) {
        float dl = a[0] - b[0], da = a[1] - b[1], db = a[2] - b[2];
        return dl * dl + da * da + db * db;
    }

    static float[][] palette(int[] px, int W, int H, int k) {
        int step = Math.max(1, (int) Math.sqrt(W * (double) H / 40000.0));
        List<float[]> pts = new ArrayList<float[]>();
        for (int y = step / 2; y < H; y += step)
            for (int x = step / 2; x < W; x += step) {
                int c = px[y * W + x];
                if ((c >>> 24) < 128) continue;
                pts.add(ZoneTone.oklab(c));
            }
        int n = pts.size();
        if (n == 0) return new float[][]{{1f, 0f, 0f}};
        k = Math.min(k, n);
        float[][] cen = new float[k][];
        float[] dmin = new float[n];
        Arrays.fill(dmin, Float.MAX_VALUE);
        // inicio: el mas oscuro y luego el mas lejano (determinista; la tinta negra queda seguro)
        int dark = 0;
        for (int i = 1; i < n; i++) if (pts.get(i)[0] < pts.get(dark)[0]) dark = i;
        cen[0] = pts.get(dark).clone();
        for (int c = 1; c < k; c++) {
            int best = 0;
            float bd = -1;
            for (int i = 0; i < n; i++) {
                float d = dist(pts.get(i), cen[c - 1]);
                if (d < dmin[i]) dmin[i] = d;
                if (dmin[i] > bd) { bd = dmin[i]; best = i; }
            }
            cen[c] = pts.get(best).clone();
        }
        for (int it = 0; it < 12; it++) {
            float[][] sum = new float[k][3];
            int[] cnt = new int[k];
            for (float[] q : pts) {
                int bi = 0;
                float bd = Float.MAX_VALUE;
                for (int c = 0; c < k; c++) {
                    float d = dist(q, cen[c]);
                    if (d < bd) { bd = d; bi = c; }
                }
                cnt[bi]++;
                sum[bi][0] += q[0]; sum[bi][1] += q[1]; sum[bi][2] += q[2];
            }
            for (int c = 0; c < k; c++)
                if (cnt[c] > 0) cen[c] = new float[]{sum[c][0] / cnt[c], sum[c][1] / cnt[c], sum[c][2] / cnt[c]};
        }
        return cen;
    }

    // ------------------------------------------------------------------ limpieza
    static byte[] majority(byte[] lab, int W, int H, int nl) {
        byte[] out = lab.clone();
        int[] cnt = new int[nl];
        for (int y = 1; y < H - 1; y++)
            for (int x = 1; x < W - 1; x++) {
                int i = y * W + x;
                int self = lab[i] & 0xFF;
                // rapido: si los 4 vecinos son iguales a el, nada que hacer
                if ((lab[i - 1] & 0xFF) == self && (lab[i + 1] & 0xFF) == self
                        && (lab[i - W] & 0xFF) == self && (lab[i + W] & 0xFF) == self) continue;
                int best = self, bc = 0;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) {
                        int v = lab[i + dy * W + dx] & 0xFF;
                        if (++cnt[v] > bc) { bc = cnt[v]; best = v; }
                    }
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) cnt[lab[i + dy * W + dx] & 0xFF] = 0;
                if (bc >= 5 && cnt.length > 0) out[i] = (byte) best;
            }
        return out;
    }

    /** Zonas conexas (4 vecinos) de la misma etiqueta. Devuelve la cantidad. */
    static int components(byte[] lab, int W, int H, int[] comp) {
        int N = W * H;
        Arrays.fill(comp, -1);
        int[] q = new int[N];
        int nc = 0;
        for (int s = 0; s < N; s++) {
            if (comp[s] >= 0) continue;
            byte l = lab[s];
            int qh = 0, qt = 0;
            q[qt++] = s;
            comp[s] = nc;
            while (qh < qt) {
                int i = q[qh++], x = i % W;
                if (x > 0 && comp[i - 1] < 0 && lab[i - 1] == l) { comp[i - 1] = nc; q[qt++] = i - 1; }
                if (x < W - 1 && comp[i + 1] < 0 && lab[i + 1] == l) { comp[i + 1] = nc; q[qt++] = i + 1; }
                if (i >= W && comp[i - W] < 0 && lab[i - W] == l) { comp[i - W] = nc; q[qt++] = i - W; }
                if (i + W < N && comp[i + W] < 0 && lab[i + W] == l) { comp[i + W] = nc; q[qt++] = i + W; }
            }
            nc++;
        }
        return nc;
    }

    /**
     * Zonas chicas (menos de minArea) se unen a la vecina con la que mas borde comparten (no a lo
     * transparente si keepLabel >= 0 es esa etiqueta). Renumera comp y devuelve la cantidad final.
     */
    static int mergeSmall(byte[] lab, int[] comp, int W, int H, int nc, int minArea, int keepLabel, boolean[] dark) {
        int N = W * H;
        int[] area = new int[nc];
        byte[] cl = new byte[nc];
        for (int i = N - 1; i >= 0; i--) { area[comp[i]]++; cl[comp[i]] = lab[i]; }
        int[] parent = new int[nc];
        for (int c = 0; c < nc; c++) parent[c] = c;
        int[] start = new int[nc + 1];
        int[] lim = new int[nc];
        for (int c = 0; c < nc; c++) lim[c] = dark != null && (cl[c] & 0xFF) < dark.length && dark[cl[c] & 0xFF] ? Math.max(2, minArea / 4) : minArea;
        for (int c = 0; c < nc; c++) start[c + 1] = start[c] + (area[c] < lim[c] ? area[c] : 0);
        if (start[nc] > 0) {
            int[] list = new int[start[nc]];
            int[] fill = new int[nc];
            for (int i = 0; i < N; i++) {
                int c = comp[i];
                if (area[c] < lim[c]) list[start[c] + fill[c]++] = i;
            }
            Integer[] ord = new Integer[nc];
            for (int c = 0; c < nc; c++) ord[c] = c;
            final int[] a0 = area.clone();
            Arrays.sort(ord, (x, y) -> Integer.compare(a0[x], a0[y]));
            java.util.HashMap<Integer, Integer> nb = new java.util.HashMap<Integer, Integer>();
            for (int c : ord) {
                if (a0[c] >= minArea) break;
                if (a0[c] >= lim[c]) continue;
                if (keepLabel >= 0 && (cl[c] & 0xFF) == keepLabel) continue;
                nb.clear();
                for (int t = start[c]; t < start[c + 1]; t++) {
                    int i = list[t], x = i % W;
                    for (int q = 0; q < 4; q++) {
                        int j = q == 0 ? (x > 0 ? i - 1 : -1) : q == 1 ? (x < W - 1 ? i + 1 : -1) : q == 2 ? (i >= W ? i - W : -1) : (i + W < N ? i + W : -1);
                        if (j < 0) continue;
                        int o = find(parent, comp[j]);
                        if (o == c) continue;
                        if (keepLabel >= 0 && (cl[o] & 0xFF) == keepLabel) continue;
                        Integer v = nb.get(o);
                        nb.put(o, v == null ? 1 : v + 1);
                    }
                }
                int best = -1, bv = 0;
                for (java.util.Map.Entry<Integer, Integer> e : nb.entrySet())
                    if (e.getValue() > bv || (e.getValue() == bv && best >= 0 && e.getKey() < best)) { bv = e.getValue(); best = e.getKey(); }
                if (best < 0) continue;
                parent[c] = best;
                area[best] += area[c];
            }
        }
        int[] remap = new int[nc];
        Arrays.fill(remap, -1);
        int n2 = 0;
        for (int i = 0; i < N; i++) {
            int r = find(parent, comp[i]);
            if (remap[r] < 0) remap[r] = n2++;
            comp[i] = remap[r];
            lab[i] = cl[r];                  // el color de la zona final (tambien lo unido en cadena)
        }
        return n2;
    }

    private static int find(int[] p, int c) {
        while (p[c] != c) { p[c] = p[p[c]]; c = p[c]; }
        return c;
    }

    // ------------------------------------------------------------------ contorno
    private static final int[] DX = {1, 0, -1, 0}, DY = {0, 1, 0, -1};

    private static boolean in(int[] comp, int W, int H, int x, int y, int c) {
        return x >= 0 && y >= 0 && x < W && y < H && comp[y * W + x] == c;
    }

    /**
     * Borde exterior de la zona c (empieza en su primer pixel, arriba a la izquierda), por las
     * esquinas de los pixeles, con la zona a la derecha. Devuelve las esquinas (x,y) donde cambia
     * la direccion.
     */
    static float[] outline(int[] comp, int W, int H, int c, int firstIdx) {
        int sx = firstIdx % W, sy = firstIdx / W;
        int x = sx, y = sy, d = 0;                // esquina de arriba a la izquierda, hacia la derecha
        float[] pts = new float[64];
        int n = 0;
        pts[n++] = x;
        pts[n++] = y;
        long guard = 4L * (W + 1) * (H + 1) + 8;
        while (guard-- > 0) {
            x += DX[d];
            y += DY[d];
            if (x == sx && y == sy) break;
            int dx = DX[d], dy = DY[d];
            boolean rIn = in(comp, W, H, (int) Math.floor(x + 0.5f * dx - 0.5f * dy), (int) Math.floor(y + 0.5f * dy + 0.5f * dx), c);
            boolean lIn = in(comp, W, H, (int) Math.floor(x + 0.5f * dx + 0.5f * dy), (int) Math.floor(y + 0.5f * dy - 0.5f * dx), c);
            int nd = !rIn ? (d + 1) & 3 : lIn ? (d + 3) & 3 : d;
            if (nd != d) {
                if (n + 2 > pts.length) pts = Arrays.copyOf(pts, pts.length * 2);
                pts[n++] = x;
                pts[n++] = y;
                d = nd;
            }
        }
        return Arrays.copyOf(pts, n);
    }

    // ------------------------------------------------------------------ suavizado
    /** Puntos medios + Douglas-Peucker + curvas cuadraticas (esquinas agudas se respetan). */
    static float[] smoothPath(float[] corners, float eps) {
        int n = corners.length / 2;
        if (n < 3) return new float[0];
        // punto medio de CADA borde de pixel (quita la escalera; las esquinas quedan a medio pixel)
        int total = 0;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            total += Math.round(Math.abs(corners[2 * j] - corners[2 * i]) + Math.abs(corners[2 * j + 1] - corners[2 * i + 1]));
        }
        float[] mid = new float[Math.max(2, total) * 2];
        int mn = 0;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            float ax = corners[2 * i], ay = corners[2 * i + 1], bx = corners[2 * j], by = corners[2 * j + 1];
            int len = Math.round(Math.abs(bx - ax) + Math.abs(by - ay));
            float ux = Math.signum(bx - ax), uy = Math.signum(by - ay);
            for (int t = 0; t < len; t++) {
                mid[mn++] = ax + ux * (t + 0.5f);
                mid[mn++] = ay + uy * (t + 0.5f);
            }
        }
        mid = Arrays.copyOf(mid, mn);
        // 2 pasadas de suavizado [1 2 1]/4: quita el "temblor" de pixel en los bordes curvos
        int q = mn / 2;
        if (q >= 8) {
            float[] t = new float[mn];
            for (int pass = 0; pass < 2; pass++) {
                for (int i = 0; i < q; i++) {
                    int a = (i + q - 1) % q, b = (i + 1) % q;
                    t[2 * i] = (mid[2 * a] + 2 * mid[2 * i] + mid[2 * b]) * 0.25f;
                    t[2 * i + 1] = (mid[2 * a + 1] + 2 * mid[2 * i + 1] + mid[2 * b + 1]) * 0.25f;
                }
                float[] sw = mid; mid = t; t = sw;
            }
        }
        float[] s = simplifyClosed(mid, eps);
        int m = s.length / 2;
        if (m < 3) s = mid;
        m = s.length / 2;
        // cada vertice se redondea solo cerca (radio R): los tramos largos quedan rectos y las
        // esquinas del dibujo no se "derriten"
        float R = eps * 2.4f + 0.6f;
        float[] out = new float[m * 12 + 8];
        int o = 0;
        for (int i = 0; i < m; i++) {
            int a = (i + m - 1) % m, b = (i + 1) % m;
            float px = s[2 * i], py = s[2 * i + 1];
            float ax = s[2 * a] - px, ay = s[2 * a + 1] - py, bx = s[2 * b] - px, by = s[2 * b + 1] - py;
            float la = (float) Math.hypot(ax, ay), lb = (float) Math.hypot(bx, by);
            float ta = la > 0 ? Math.min(0.5f, R / la) : 0f, tb = lb > 0 ? Math.min(0.5f, R / lb) : 0f;
            float ex = px + ax * ta, ey = py + ay * ta;   // entrada a la curva
            float sx2 = px + bx * tb, sy2 = py + by * tb; // salida
            float cos = la > 0 && lb > 0 ? (-ax * bx - ay * by) / (la * lb) : 1f;
            boolean sharp = cos < -0.2f;                   // giro de mas de ~100 grados: punta
            if (i == 0) { out[o++] = 0; out[o++] = sharp ? px : ex; out[o++] = sharp ? py : ey; }
            else { out[o++] = 1; out[o++] = sharp ? px : ex; out[o++] = sharp ? py : ey; }
            if (!sharp) { out[o++] = 2; out[o++] = px; out[o++] = py; out[o++] = sx2; out[o++] = sy2; }
        }
        out[o++] = 3;
        return Arrays.copyOf(out, o);
    }

    static float[] simplifyClosed(float[] p, float eps) {
        int n = p.length / 2;
        if (n < 4) return p;
        // partir en el punto mas lejano del primero
        int far = 0;
        float fd = -1;
        for (int i = 1; i < n; i++) {
            float d = (p[2 * i] - p[0]) * (p[2 * i] - p[0]) + (p[2 * i + 1] - p[1]) * (p[2 * i + 1] - p[1]);
            if (d > fd) { fd = d; far = i; }
        }
        boolean[] keep = new boolean[n];
        keep[0] = keep[far] = true;
        dp(p, 0, far, eps, keep, n);
        dp(p, far, n, eps, keep, n);
        int m = 0;
        for (boolean k : keep) if (k) m++;
        float[] out = new float[m * 2];
        int o = 0;
        for (int i = 0; i < n; i++) if (keep[i]) { out[o++] = p[2 * i]; out[o++] = p[2 * i + 1]; }
        return out;
    }

    /** Douglas-Peucker sin recursion entre a y b (b puede ser n = vuelve al 0). */
    private static void dp(float[] p, int a0, int b0, float eps, boolean[] keep, int n) {
        int[] st = new int[64];
        int sp = 0;
        st[sp++] = a0; st[sp++] = b0;
        float e2 = eps * eps;
        while (sp > 0) {
            int b = st[--sp], a = st[--sp];
            if (b - a < 2) continue;
            float ax = p[2 * a], ay = p[2 * a + 1];
            int bi = b % n;
            float bx = p[2 * bi], by = p[2 * bi + 1];
            float dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy;
            int best = -1;
            float bd = e2;
            for (int i = a + 1; i < b; i++) {
                float px = p[2 * i] - ax, py = p[2 * i + 1] - ay, d;
                if (L2 < 1e-6f) d = px * px + py * py;
                else { float cr = px * dy - py * dx; d = cr * cr / L2; }
                if (d > bd) { bd = d; best = i; }
            }
            if (best < 0) continue;
            keep[best] = true;
            if (sp + 4 > st.length) st = Arrays.copyOf(st, st.length * 2);
            st[sp++] = a; st[sp++] = best;
            st[sp++] = best; st[sp++] = b;
        }
    }

    // ------------------------------------------------------------------ SVG
    /** El resultado como SVG (escala s). Con alfa: las formas van dentro de una mascara. */
    public static String svg(Result r, float s) {
        StringBuilder sb = new StringBuilder(r.shapes.size() * 120 + 256);
        int W = Math.round(r.w * s), H = Math.round(r.h * s);
        sb.append("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"").append(W).append("\" height=\"").append(H)
                .append("\" viewBox=\"0 0 ").append(W).append(' ').append(H).append("\">\n");
        if (!r.alpha.isEmpty()) {
            sb.append("<defs><mask id=\"a\" maskUnits=\"userSpaceOnUse\">\n");
            for (Shape a : r.alpha) path(sb, a.path, s, a.clear ? "#000000" : "#ffffff", false);
            sb.append("</mask></defs>\n<g mask=\"url(#a)\">\n");
        }
        for (Shape sh : r.shapes) path(sb, sh.path, s, String.format(java.util.Locale.US, "#%06x", sh.color & 0xFFFFFF), true);
        if (!r.alpha.isEmpty()) sb.append("</g>\n");
        sb.append("</svg>\n");
        return sb.toString();
    }

    private static void path(StringBuilder sb, float[] p, float s, String col, boolean stroke) {
        if (p == null || p.length == 0) return;
        sb.append("<path fill=\"").append(col).append('"');
        if (stroke) sb.append(" stroke=\"").append(col).append("\" stroke-width=\"").append(fmt(s)).append('"');
        sb.append(" d=\"");
        int i = 0;
        while (i < p.length) {
            int op = (int) p[i++];
            if (op == 0) { sb.append('M').append(fmt(p[i++] * s)).append(' ').append(fmt(p[i++] * s)); }
            else if (op == 1) { sb.append('L').append(fmt(p[i++] * s)).append(' ').append(fmt(p[i++] * s)); }
            else if (op == 2) {
                sb.append('Q').append(fmt(p[i++] * s)).append(' ').append(fmt(p[i++] * s)).append(' ')
                        .append(fmt(p[i++] * s)).append(' ').append(fmt(p[i++] * s));
            } else sb.append('Z');
        }
        sb.append("\"/>\n");
    }

    private static String fmt(float v) {
        float r = Math.round(v * 10f) / 10f;
        return r == (int) r ? Integer.toString((int) r) : Float.toString(r);
    }
}
