package com.pacco.animecut.ai;

/**
 * v8.41 "Mejorar imagen": amplia x2 o x4 con una IA de anime (Real-ESRGAN, BSD-3) por PEDAZOS
 * (tiles) con borde de solape, asi la memoria no depende del tamano de la imagen: sirve en
 * cualquier telefono. Java puro (la IA se pasa como Model): lo usan la app y las pruebas de PC.
 *
 *  - Lo transparente (fondo ya borrado) no deja halo oscuro: antes de ampliar, el color de los
 *    pixeles transparentes se rellena con el del borde opaco mas cercano; el alfa se amplia
 *    aparte (bilineal) y se aplica al final.
 *  - x2 = la IA amplia x4 y se reduce a la mitad promediando 2x2 (mas nitido que ampliar x2 directo).
 *  - Cancelable entre pedazos; si se cancela devuelve null y no queda nada a medias.
 */
public final class Upscaler {
    private Upscaler() { }

    /** La red: recibe RGB 0..1 en planos (3*h*w) y devuelve 3*(4h)*(4w). */
    public interface Model {
        float[] run(float[] chw, int h, int w) throws Exception;
    }

    /** Avance: done de total pedazos. Devolver false = cancelar. */
    public interface Progress {
        boolean step(int done, int total);
    }

    /** Solape alrededor de cada pedazo (pixeles de entrada): sin costuras entre pedazos. */
    public static final int PAD = 12;

    /** Tamano de salida para scale (2 o 4). */
    public static long outPixels(int w, int h, int scale) {
        return (long) w * scale * h * scale;
    }

    /**
     * @param tile lado del pedazo de entrada (sin el solape): 96-256 segun memoria y modelo
     * @return pixeles ARGB de (w*scale) x (h*scale), o null si se cancelo
     */
    public static int[] upscale(int[] px, int w, int h, int scale, int tile, Model m, Progress pr) throws Exception {
        return upscale(px, w, h, scale, tile, PAD, m, pr);
    }

    /** pad = solape: 12 para el modelo rapido, 32 para el de calidad (ve mas lejos). */
    public static int[] upscale(int[] px, int w, int h, int scale, int tile, int pad, Model m, Progress pr) throws Exception {
        if (scale != 2 && scale != 4) throw new IllegalArgumentException("escala");
        int ow = w * scale, oh = h * scale;
        boolean hasAlpha = false;
        for (int c : px) if ((c >>> 24) < 255) { hasAlpha = true; break; }
        int[] rgb = hasAlpha ? fillTransparent(px, w, h) : px;
        int[] out = new int[ow * oh];
        int tx = (w + tile - 1) / tile, ty = (h + tile - 1) / tile, total = tx * ty, done = 0;
        if (pr != null && !pr.step(0, total)) return null;
        for (int j = 0; j < ty; j++) {
            for (int i = 0; i < tx; i++) {
                int x0 = i * tile, y0 = j * tile;
                int x1 = Math.min(w, x0 + tile), y1 = Math.min(h, y0 + tile);
                int px0 = Math.max(0, x0 - pad), py0 = Math.max(0, y0 - pad);
                int px1 = Math.min(w, x1 + pad), py1 = Math.min(h, y1 + pad);
                int tw = px1 - px0, th = py1 - py0;
                float[] in = new float[3 * tw * th];
                int plane = tw * th;
                for (int y = 0; y < th; y++) {
                    int o = (py0 + y) * w + px0, d = y * tw;
                    for (int x = 0; x < tw; x++) {
                        int c = rgb[o + x];
                        in[d + x] = ((c >> 16) & 255) / 255f;
                        in[plane + d + x] = ((c >> 8) & 255) / 255f;
                        in[2 * plane + d + x] = (c & 255) / 255f;
                    }
                }
                float[] res = m.run(in, th, tw);
                int rw = tw * 4, rplane = rw * th * 4;
                if (res == null || res.length < 3 * rplane) throw new IllegalStateException("salida de la IA corta");
                // copiar solo la parte sin solape
                int cx0 = (x0 - px0) * 4, cy0 = (y0 - py0) * 4, cw = (x1 - x0) * 4, ch = (y1 - y0) * 4;
                if (scale == 4) {
                    for (int y = 0; y < ch; y++) {
                        int so = (cy0 + y) * rw + cx0, dO = (y0 * 4 + y) * ow + x0 * 4;
                        for (int x = 0; x < cw; x++) {
                            int s = so + x;
                            out[dO + x] = 0xFF000000 | (b(res[s]) << 16) | (b(res[rplane + s]) << 8) | b(res[2 * rplane + s]);
                        }
                    }
                } else {
                    for (int y = 0; y < ch / 2; y++) {
                        int dO = (y0 * 2 + y) * ow + x0 * 2;
                        for (int x = 0; x < cw / 2; x++) {
                            int s = (cy0 + 2 * y) * rw + cx0 + 2 * x;
                            int r = b4(res, s, rw), g = b4(res, rplane + s, rw), bl = b4(res, 2 * rplane + s, rw);
                            out[dO + x] = 0xFF000000 | (r << 16) | (g << 8) | bl;
                        }
                    }
                }
                done++;
                if (pr != null && !pr.step(done, total)) return null;
            }
        }
        if (hasAlpha) applyAlpha(px, w, h, out, ow, oh);
        return out;
    }

    private static int b(float v) {
        int i = Math.round(v * 255f);
        return i < 0 ? 0 : i > 255 ? 255 : i;
    }

    private static int b4(float[] a, int s, int rw) {
        return b((a[s] + a[s + 1] + a[s + rw] + a[s + rw + 1]) * 0.25f);
    }

    /**
     * Color de lo transparente = el del opaco mas cercano (hasta 16 px; mas lejos, blanco). Asi la
     * IA no ve un borde negro inventado alrededor del personaje recortado.
     */
    static int[] fillTransparent(int[] px, int w, int h) {
        int n = w * h;
        int[] c = new int[n];
        boolean[] ok = new boolean[n];
        for (int i = 0; i < n; i++) {
            if ((px[i] >>> 24) >= 128) { c[i] = px[i] | 0xFF000000; ok[i] = true; }
        }
        int[] front = new int[n];
        int fn = 0;
        for (int i = 0; i < n; i++) if (ok[i]) front[fn++] = i;
        int[] next = new int[n];
        for (int pass = 0; pass < 16 && fn > 0; pass++) {
            int nn = 0;
            for (int k = 0; k < fn; k++) {
                int i = front[k], x = i % w, y = i / w;
                for (int d = 0; d < 4; d++) {
                    int q = d == 0 ? (x > 0 ? i - 1 : -1) : d == 1 ? (x < w - 1 ? i + 1 : -1)
                            : d == 2 ? (y > 0 ? i - w : -1) : (y < h - 1 ? i + w : -1);
                    if (q < 0 || ok[q]) continue;
                    ok[q] = true;
                    c[q] = c[i];
                    next[nn++] = q;
                }
            }
            int[] t = front; front = next; next = t; fn = nn;
        }
        for (int i = 0; i < n; i++) if (!ok[i]) c[i] = 0xFFFFFFFF;
        return c;
    }

    /** Alfa ampliado bilineal sobre el resultado (el color ya esta ampliado por la IA). */
    static void applyAlpha(int[] px, int w, int h, int[] out, int ow, int oh) {
        float sx = w / (float) ow, sy = h / (float) oh;
        for (int y = 0; y < oh; y++) {
            float fy = (y + 0.5f) * sy - 0.5f;
            int y0 = (int) Math.floor(fy);
            float ty = fy - y0;
            int ya = Math.max(0, Math.min(h - 1, y0)), yb = Math.max(0, Math.min(h - 1, y0 + 1));
            for (int x = 0; x < ow; x++) {
                float fx = (x + 0.5f) * sx - 0.5f;
                int x0 = (int) Math.floor(fx);
                float tx = fx - x0;
                int xa = Math.max(0, Math.min(w - 1, x0)), xb = Math.max(0, Math.min(w - 1, x0 + 1));
                float a = (px[ya * w + xa] >>> 24) * (1 - tx) * (1 - ty) + (px[ya * w + xb] >>> 24) * tx * (1 - ty)
                        + (px[yb * w + xa] >>> 24) * (1 - tx) * ty + (px[yb * w + xb] >>> 24) * tx * ty;
                int ai = Math.round(a);
                int i = y * ow + x;
                out[i] = (out[i] & 0x00FFFFFF) | (Math.max(0, Math.min(255, ai)) << 24);
            }
        }
    }
}
