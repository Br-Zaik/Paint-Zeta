# Paint Zeta v8.41 — Mejorar imagen y Vectorizar (sobre la v8.40)

Dos opciones nuevas en el menú principal (⋮), justo debajo de **Filtros de la capa**. Las dos funcionan **dentro de la app y sin internet**, en cualquier teléfono: el trabajo se hace por pedazos, así la memoria no depende del tamaño de la imagen.

## Cómo se usa

**Mejorar imagen con IA (x2 / x4)**

1. Menú ⋮ → **Mejorar imagen con IA (x2 / x4)**.
2. Elige:
   - **Qué mejorar**: la capa elegida o todo lo visible;
   - **Tamaño**: x2 o x4 (la ventana te dice el tamaño final);
   - **Modo**: **Rápido** (líneas limpias, tarda poco) o **Máxima calidad** (más detalle, tarda bastante más).
3. **Mejorar**. Sale una barra con "Pedazo 3 de 20 · faltan ~1 min" y **Cancelar**.
4. El resultado se abre como **obra nueva**. Tu obra de antes se guarda sola y no cambia.

**Vectorizar (colores lisos, bordes suaves)**

1. Menú ⋮ → **Vectorizar**.
2. Elige:
   - **Qué vectorizar**: la capa elegida o todo lo visible;
   - **Colores**: 8, 16, 24 o 32 (menos colores = más plano y más fácil de recortar);
   - **Detalle**: Simple, Normal o Fino;
   - **Tamaño**: x1 queda como capa nueva **"vector"** encima, en la misma obra; x2 o x4 se abre como obra nueva con bordes limpios;
   - si quieres, también guarda el **.svg** en Descargas › Paint Zeta.
3. Después, con **Varita** o **Borrar fondo**, un toque elige una zona entera, porque cada zona ya es de un solo color.

## Qué se investigó y qué se eligió

**Para mejorar la imagen**

- **Real-ESRGAN** (Tencent ARC, licencia **BSD-3**: se puede usar en una app gratis de Play Store). Se usan sus dos modelos de anime:
  - **realesr-animevideov3** → modo **Rápido**: 621 mil parámetros, muy liviano;
  - **RealESRGAN_x4plus_anime_6B** → modo **Máxima calidad**: más pesado, más detalle.
  - Se convirtieron a ONNX en media precisión: 1,2 MB y 9 MB dentro del APK. Corren con el mismo ONNX Runtime que ya usa Recortar con IA, sin librerías nuevas.
- **Descartados**:
  - **APISR** (muy bueno para anime): licencia GPL-3 y uso académico. No sirve para una app de tienda.
  - **Real-CUGAN** y **waifu2x-ncnn**: necesitan la librería ncnn (código nativo nuevo para cada tipo de teléfono).
  - Cualquier servicio en internet: tú pediste que todo quede dentro de la app y sin pagar.

**Para vectorizar**

- **Potrace** y **AutoTrace**: licencia GPL. No se pueden meter en una app cerrada de Play Store.
- **VTracer**: licencia MIT y buena calidad, pero está hecho en Rust: haría falta compilar código nativo para cada tipo de teléfono.
- **ImageTracer**: dominio público, pero usa mucha memoria con imágenes grandes.
- **Elegido: vectorizador propio en Java.** Sigue la misma idea que VTracer, pero hecho para dibujos y manga:
  - agrupa los colores en OKLab (como ve el ojo);
  - protege las **líneas finas oscuras** para que no se corten;
  - junta los puntitos sueltos;
  - sigue el borde de cada zona, lo suaviza y lo pasa a curvas;
  - deja esquinas en punta donde el dibujo las tiene.

## YA EXISTÍA (se reutilizó, no se duplicó)

- **ONNX Runtime**: el mismo motor de Recortar con IA.
- **Capas, Deshacer, guardado automático** y la carpeta Paint Zeta.
- **Varita y Borrar fondo**: se usan después del vector, sin cambios.

## MODIFICADO

- **Menú principal**: dos entradas nuevas debajo de Filtros de la capa.
- **Capas**: la capa "vector" se agrega encima de la elegida y se puede deshacer.
- **Licencias**: LICENCIAS_IA.txt (dentro de la app) y LICENCIAS_TERCEROS.txt agregan Real-ESRGAN (texto BSD-3 completo) y aclaran que el vectorizador es propio, sin GPL.
- **Versión**: 8.41 (código 79).

## NUEVO

- **Mejorar imagen**:
  - trabaja por pedazos con borde de solape (12 px en Rápido, 24 px en Calidad), así no quedan costuras;
  - elige el tamaño del pedazo según la memoria libre del teléfono, así sirve en teléfonos chicos y grandes;
  - **lo transparente se conserva**: un personaje recortado no queda con halo negro;
  - x2 = la IA amplía x4 y luego se promedia a la mitad (más nítido);
  - **Cancelar** de verdad: detiene la IA a mitad de un pedazo y no queda nada a medias;
  - la pantalla no se apaga mientras trabaja;
  - si el resultado no entra en la memoria del teléfono, lo avisa **antes** de empezar ("usa x2").
- **Vectorizar**:
  - el motor propio descrito arriba;
  - dibujo con curvas suaves (antialias) a x1, x2 o x4;
  - lo transparente se conserva;
  - opción de guardar el .svg.

## PENDIENTE

- **Probar en tu teléfono.** No hay emulador aquí. La interfaz (ventanas, barra, Cancelar) solo se compiló.
- **El tiempo real en el teléfono.**
  - Las pruebas de PC (2 núcleos) dan, para una imagen de 500 × 500 a x4:
    - Rápido: unos 3 s;
    - Calidad: unos 30 s.
  - En un teléfono puede ser de 2 a 5 veces más.
  - **Máxima calidad con imágenes grandes puede tardar varios minutos**: por eso hay barra y Cancelar.
- **El APK pesa unos 10 MB más** por los dos modelos.
- **La IA no inventa detalles que no existen**: limpia y afila líneas. En fotos reales funciona, pero está pensada para dibujos y anime.
- **El vectorizador junta detalles muy pequeños** (brillos de 1–2 px, trama muy fina). Para más detalle usa **Fino** y 24–32 colores.

## Registro de pruebas

### Pruebas ejecutadas de verdad en PC

Usan el código real de la app (Java) y los modelos ONNX reales, con tus imágenes.

1. **Modelos convertidos contra la cuenta original** de Real-ESRGAN: diferencia máxima 0,0019 (Rápido) y 0,0030 (Calidad), sobre 1. No se nota a la vista.
2. **Memoria y tiempo por pedazo** (ONNX Runtime, 2 hilos):
   - Rápido: 128 px → 0,12 s y 43 MB; 192 px → 0,21 s y 76 MB;
   - Calidad: 96–128 px → 0,8 s y 236 MB; 192 px → 2,2 s y 461 MB (por eso Calidad usa pedazos de 96–128).
3. **Pedazos contra imagen entera de una vez**:
   - Rápido: diferencia máxima 2 de 255;
   - Calidad con solape de 24: máxima 3 de 255. Sin costuras visibles.
   - **Fallo encontrado y corregido**: con solape de 12, Calidad dejaba costuras (17 de 255). Se subió a 24.
4. **Transparencia**: personaje recortado a x4, sin halo oscuro.
5. **Cancelar a mitad**: devuelve "nada" y no cambia la obra.
6. **Vectorizar**, con tus imágenes a color, manga B/N y personaje recortado:
   - 0,1–0,6 s para trazar y 0,1–0,2 s para dibujar (0,8–1,7 MP);
   - diferencia media de color entre 7 y 11 de 255;
   - con 4,9 MP y 32 colores: 1,3 s y menos de 90 MB de memoria.
   - **Fallos encontrados y corregidos**:
     - las esquinas de la imagen salían redondeadas;
     - las líneas finas se perdían o salían cortadas;
     - las zonas chicas se juntaban lento.
7. **Compilación**: todo el código de la app compila contra el Android real (android.jar 34).

### Solo compilado, pendiente en tu teléfono

- Las dos ventanas, la barra de avance y Cancelar.
- La copia del modelo a la memoria interna (solo la primera vez, unos segundos).
- Abrir el resultado como obra nueva y la capa "vector".
- Guardar el .svg.
- Tiempos y memoria reales.

## Fuentes

- [Real-ESRGAN (BSD-3)](https://github.com/xinntao/Real-ESRGAN)
- [APISR (GPL-3)](https://github.com/Kiteretsu77/APISR)
- [VTracer (MIT, Rust)](https://github.com/visioncortex/vtracer)
- [Potrace (GPL)](https://potrace.sourceforge.net/)
- [AutoTrace (GPL)](https://github.com/autotrace/autotrace)
- [ImageTracer Java (dominio público)](https://github.com/jankovicsandras/imagetracerjava)
