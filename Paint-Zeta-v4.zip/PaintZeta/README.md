# Paint Zeta

App Android para extraer partes de dibujos anime y manga por capas, y exportarlas
como PNG transparentes listos para animar en Alight Motion.

Todo funciona sin internet. No usa modelos de IA ni librerias nativas pesadas.

---

## Como compilar el APK

1. Sube esta carpeta completa a un repositorio de GitHub.
2. Entra a la pestana Actions del repositorio.
3. El workflow "Compilar APK" arranca solo con cada push. Si no, toca
   "Run workflow" a mano.
4. Cuando termine, abre la ejecucion y descarga el artefacto `PaintZeta-debug`.
5. Dentro viene el APK. Descomprime e instala.

No hace falta `gradle-wrapper.jar`: el workflow instala Gradle 8.7 por su cuenta.

---

## Como se usa

1. Toca **Abrir** y elige la imagen. Se carga a su resolucion original, sin recortar
   ni reescalar nada.
2. Elige una herramienta abajo y selecciona la parte que quieres sacar.
3. Toca **Crear capa**. Eso guarda la seleccion como una capa y limpia el lienzo
   para seguir con la siguiente parte.
4. Repite por cada parte: pelo, cara, brazo, ropa, fondo.
5. Ordena las capas desde el menu Capas, con Subir y Bajar. El orden decide el
   numero del PNG y en animacion eso importa: el brazo va delante o detras del
   torso segun el movimiento.
6. Toca **Exportar** y elige el tamano.

Todos los PNG salen del mismo tamano de lienzo, tanto a resolucion original como
reducidos, asi que al importarlos en Alight Motion entran ya alineados y no hay
que reposicionar nada.

Al exportar puedes elegir original, mitad, lado largo 1920 o lado largo 1280.
Para un video de 1080p no tiene sentido cargar capas de 3000 px: pesan mucho y
ponen lento Alight Motion.

**Alight Motion no abre ZIP.** Descomprime primero con ZArchiver o similar y
despues importa los PNG.

---

## Herramientas

**Varita** — Toca una zona y selecciona todo el color parecido que este pegado.
El slider de tolerancia decide cuanto se parece: bajo para colores planos,
alto si hay sombras o degradado.

**Global** — Con esto activado la varita selecciona ese color en TODA la imagen,
no solo la mancha que tocaste. Util para sacar todo el pelo de un color de golpe.

**Line art** — Convierte las lineas oscuras del dibujo en una barrera. La varita
deja de escaparse por los huecos de la linea. Es lo que hace que funcione bien
en manga blanco y negro. Puedes elegir que tan oscura cuenta como linea y cuantos
pixeles engordarla para cerrar huecos.

**Pincel / Borrador** — Pinta o borra la seleccion a mano, con borde suave.
Para arreglar lo que la varita no agarro bien.

**Lazo** — Rodea una zona con el dedo y se selecciona al soltar.

**Restar** — Con esto activado, la varita, el lazo y el pincel quitan de la
seleccion en vez de agregar.

**Borde** — Expandir, contraer, suavizar o endurecer el borde de la seleccion.
En manga conviene expandir 1 o 2 px para no cortar la linea negra por la mitad.

**Clonar** — Primer toque fija el origen (sale una cruz roja). Despues arrastras
y copia esa zona donde pases el dedo. Sirve para tapar el hueco que queda al sacar
una parte, o para rellenar copiando un trozo del propio dibujo.

**Pintar** — Pincel de color normal. Si hay una seleccion activa, solo pinta
dentro de ella, igual que en Ibis Paint. Con **Fino** activado no pisa las lineas
del dibujo, asi que puedes pintar rapido por encima sin borrar el contorno.

**Balde** — Rellena de color toda la zona parecida que toques. Usa la misma
tolerancia que la varita y respeta el line art.

**Color de la imagen** — Cuentagotas. Toca cualquier punto y ese color pasa a ser
el color de pintar.

**Color** — Abre la paleta: 24 colores listos, tres barras de rojo, verde y azul
para cualquier tono, y un boton para tomar el color de la imagen. El boton se tine
del color actual para que veas cual tienes cargado.

**Fino** — Modo de deteccion. En el pincel de seleccion solo agarra el color que
tocaste al empezar el trazo y se detiene en las lineas, asi que puedes pasar el dedo
rapido sin salirte de la figura. En el pincel de pintar, protege las lineas.

**Dureza** — Que tan suave es el borde del pincel, de 20% a 100%.

**Girar** — Gira 90 grados a un lado o al otro, o voltea la imagen. Gira todo junto:
imagen, seleccion, line art y cada capa, asi que nada se desalinea. El historial de
deshacer se reinicia al girar.

**Invertir / Limpiar** — Invierte la seleccion o la borra entera.

**Capas** — Lista de capas creadas. Cada una se puede ocultar, renombrar, eliminar,
exportar sola, o cargar de vuelta a la seleccion para seguir editandola.

**Proyecto** — Guarda el trabajo completo en un archivo `.acut`: la imagen, la
seleccion, el line art y todas las capas con sus nombres. Desde ahi tambien se abre
un proyecto guardado.

**Encuadrar** — Devuelve la imagen al centro de la pantalla si te perdiste con el zoom.

**Mano** — Mueve la imagen con un dedo. Con dos dedos puedes mover y hacer zoom
en cualquier herramienta.

---

## Lo que trae el ZIP

- Un PNG por cada capa visible, numerado: `01_capa_1.png`, `02_capa_2.png`...
- Un `99_fondo_restante.png` con lo que queda de la imagen al quitar todas las capas.
  Sirve como fondo del video.

---

## El trabajo no se pierde

La app guarda sola dentro de su almacenamiento cada vez que creas una capa y
cada vez que sales. Si entra una llamada o Android cierra la app, al volver a
abrirla te pregunta si quieres recuperar el proyecto.

Para algo mas seguro, usa **Proyecto > Guardar proyecto en un archivo** y guardalo
donde tu quieras. Ese archivo se puede copiar, respaldar o mover a otro telefono.

Dos avisos:

- El autoguardado corre en segundo plano. Si el telefono mata la app justo en
  ese momento, puede quedar a medias. El guardado manual es el seguro.
- Antes de crear la capa, tapa con **Clonar** el hueco que deja la parte que
  sacaste. Si no, en el video se vera el agujero cuando esa parte se mueva.

---

## Notas tecnicas

- Las capas se guardan como mascaras de 1 byte por pixel, no como imagenes
  completas. Ocupan 4 veces menos memoria.
- Deshacer guarda solo el rectangulo que cambio, con un tope de 32 MB.
- La imagen se dibuja en pantalla desde una copia reducida para ir fluido, pero
  todas las operaciones se aplican sobre los pixeles reales.
- El relleno usa un algoritmo por lineas (scanline), no recursivo, para que no
  se desborde la pila en imagenes grandes.
- Al pintar o clonar solo se actualiza el trozo de pantalla que cambio, no la
  imagen entera, para que el trazo no se trabe.
- Al acercar mas alla del 100% el filtrado se apaga solo: el pixel se ve nitido
  para trabajar fino en vez de borroso.
- No pide permisos: usa el selector del sistema para abrir y guardar.
- El proyecto `.acut` es un ZIP por dentro. Las mascaras son casi todo ceros y
  doscientos cincuenta y cinco, asi que se comprimen muchisimo.
- Al exportar reducido, cada pixel de salida es el promedio del bloque que le
  toca, pesado por el alfa, para que el borde no arrastre color de lo transparente.

---

## Siguientes versiones

- v2: click-to-segment con MobileSAM (tocar una parte y que la recorte sola),
  suavizado de bordes tipo pelo, recorte de fondo con modelo descargable.
- v3: relleno inteligente del hueco con IA.


## Identidad visual

Nombre visible en Android: **Paint Zeta**. Icono HD para launchers cuadrados y circulares, y adaptive icon Android 8+ con zona segura central. Fuentes PNG de 1024 × 1024 en `branding/`. El identificador de instalacion `com.pacco.animecut` se conserva para no romper las actualizaciones de la misma app.


---

## Novedades de esta version

### Se acabaron los cuadraditos blancos del borde

El contorno de un dibujo no pasa de negro a color de golpe: tiene una franja
de pixeles intermedios por el antialias, mas el ruido del JPEG. La varita los
dejaba fuera y quedaba el escaloncito.

Tres cosas nuevas lo arreglan:

**Suavidad del borde.** La seleccion ya no es si o no. Los pixeles del filo
entran a medias segun cuanto se parecen. El borde sale suave, no escalonado.

**Expansion con decimales.** La seleccion se engorda 1.5 px por defecto, que es
justo lo que mide el antialias. Es el mismo valor que usa Ibis. Se ajusta de
-3 a +5 px en pasos de 0.1.

**Limpieza del borde al exportar.** A cada pixel del filo se le devuelve el
color de adentro y se le quita el color del fondo que se le habia pegado.
Esto es lo que evita el halo blanco al poner la capa sobre otro fondo en
Alight Motion.

### Ajustes de la varita

En el menu, "Ajustes de la varita":

- **Fuerza**: hasta que diferencia de color sigue seleccionando
- **Suavidad del borde**: franja donde el pixel entra a medias
- **Expansion**: la de arriba, con decimales
- **Reconocimiento de huecos**: engorda la linea para tapar los cortes,
  rellena dentro, y devuelve el relleno a su sitio. Asi no se escapa por una
  linea abierta
- **Como compara el color**: exacto, por tono ignorando sombras, o como lo ve
  el ojo. El de tono sirve cuando una zona tiene sombreado del mismo color

### Galeria de obras

La app arranca en la galeria. Ahi estan todas tus obras con su miniatura,
ordenadas por la ultima vez que las tocaste. Se guardan solas al crear una
capa y al salir. Mantener pulsada una obra la abre o la elimina.

### Gestos

- **Dos dedos, toque**: deshacer
- **Tres dedos, toque**: rehacer
- **Dos dedos arrastrando**: mover y hacer zoom
- **Dos dedos en circulo**: girar el lienzo
- **Mantener pulsado**: gotero rapido, sale una burbuja con el color antes de
  soltar

### Otras

- **Gama de colores**: selecciona un color en toda la imagen, con margen
- **Copiar, cortar y pegar** la seleccion
- **Aviso flotante** con el porcentaje de zoom y con lo que se deshizo

---

## Notas tecnicas de lo nuevo

- La expansion con decimales usa una transformada de distancia exacta
  (Felzenszwalb y Huttenlocher). Coste lineal, sin importar cuanto expandas.
- La morfologia pasa a van Herk y Gil-Werman: tres comparaciones por pixel sin
  importar el radio. Expandir y contraer ya no se pone lento con radios grandes.
- La transformada de distancia guarda tambien cual es el pixel opaco mas
  cercano, y con eso el defringe sabe de donde tomar el color.
- La limpieza del fondo despeja la mezcla: el pixel visto es
  C = a*F + (1-a)*B, asi que el color real es F = (C - (1-a)*B) / a.
- Todo se calcula solo dentro del rectangulo que hace falta, no sobre la
  imagen entera, para no reservar decenas de MB.
- El cierre de huecos es una version del metodo de la bola atrapada que se usa
  para colorear line art.


---

## Segunda tanda: lo que faltaba

### Tijeras inteligentes

La herramienta nueva de la columna. Arrastras siguiendo el contorno y la
linea se pega sola al borde del dibujo. Al soltar se fija ese tramo y sigues
con el siguiente. Cuando vuelves al punto verde del principio, la figura se
cierra y se convierte en seleccion.

Por dentro busca el camino mas barato desde el ultimo punto fijado hasta tu
dedo, donde pasar por un borde cuesta barato y pasar por una zona plana cuesta
caro. El calculo se hace en una ventana de 320 px alrededor del punto fijado,
no en toda la imagen, para que responda al instante.

Es la funcion que Ibis no tiene y la que mas tiempo ahorra para sacar un
personaje completo.

### Mover seleccion

Si la varita agarro bien la forma pero esta corrida, arrastras y la mueves
sin volver a seleccionar.

### Refinar borde

Hace que el alfa siga el borde real del dibujo. Es para pelo y bordes finos,
donde una mascara de si o no siempre queda mal. Tres intensidades.

### Rellenar zonas sin pintar

Rellena los huecos que quedaron encerrados dentro de la seleccion. A
diferencia de cerrar huecos, este no deforma el contorno de afuera: busca los
huecos de verdad, los que no salen al exterior.

### Filtros de limpieza

Aplicar uno antes de seleccionar hace que la varita agarre mucho mejor:

- **Quitar ruido de JPEG**: mediana de 3x3. Se come el ruido de bloque sin
  desdibujar las lineas
- **Aplanar tonos**: reduce la cantidad de colores, aplana el degradado
- **Niveles**: mas contraste
- **Extraer line art**: con sus tres controles, blanco, negro y medio

### Estabilizador del trazo

Corrige el pulso al dibujar. Cuatro niveles.

### Gama de colores con vista previa

Ahora ves la seleccion actualizarse en el lienzo mientras mueves el margen,
en vez de aplicar a ciegas.

### Aviso de que se deshizo

Dice "Deshacer: Varita", "Deshacer: Pincelada", y asi con cada cosa.

### Renombrar obras

En la galeria, manten pulsada una obra para abrirla, renombrarla o borrarla.

---

## Lo que sigue sin estar, y por que

- **Capa de referencia** y **Debajo de la linea de borde** de Ibis: necesitan
  que el line art viva en una capa aparte. Nosotros trabajamos sobre una sola
  imagen con mascaras, asi que no aplican tal cual.
- **Capas de dibujo de verdad**, con modos de fusion y clipping. Las nuestras
  son mascaras de recorte, que es lo que hace falta para exportar a Alight
  Motion. Meter capas pintables seria rehacer el motor entero.
- **Transformar libre** con escalar y rotar la seleccion. Solo esta mover.
- **Carpetas** en la galeria.


---

## Lo basico, en corto

La app trabaja con dos cosas distintas y es lo que mas confunde al principio:

**SELECCION** es la mancha azul. No es pintura. Es lo que tienes marcado para
convertirlo en capa. La hacen la varita, el pincel, el borrador, el lazo y las
tijeras.

**COLOR** es pintura de verdad. La ponen el rodillo y el balde, con el color
del circulo de abajo.

Por eso, si eliges un color y pintas con el pincel, no pasa nada de color: el
pincel pinta seleccion, no color. El que pinta color es el rodillo.

Y si tienes algo azul seleccionado, el rodillo solo pinta dentro de lo azul.
Para pintar libre, limpia la seleccion primero.

## Panel de capas

El boton de los rombos abre un panel de verdad, no una lista de texto:

- Miniatura de cada capa, con cuadros grises donde es transparente
- Arriba del todo, la fila de la Seleccion actual
- Ojo para mostrar u ocultar
- Opacidad por capa, de 0 a 100%
- Flechas para subir y bajar el orden
- Papelera para eliminar
- Tocar la miniatura devuelve esa capa a la seleccion para seguir editandola
- Tocar el nombre lo cambia

## Que hace cada boton

Manten pulsado cualquier boton, de la barra o del panel de capas, y te dice
como se llama.
