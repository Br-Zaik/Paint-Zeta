package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.core.ProjectStore;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.Thumbs;
import com.pacco.animecut.view.CanvasView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Pantalla principal. Funciona como Ibis: capas de verdad, capa de seleccion,
 * herramientas en un panel chico abajo a la izquierda.
 */
public class MainActivity extends AppCompatActivity implements CanvasView.Callback {

    public static final String EXTRA_PROJECT = "obra";

    private static final int[] PALETTE = {
            0xFF000000, 0xFF444444, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF, 0xFF7A4A2B,
            0xFFE05A5A, 0xFFFF7A45, 0xFFFFB03A, 0xFFFFE05C, 0xFFB5E05A, 0xFF4FC66B,
            0xFF3DD6C0, 0xFF4DA3FF, 0xFF3D6BFF, 0xFF7B5CFF, 0xFFB558FF, 0xFFFF6FC3,
            0xFFFFE0C4, 0xFFF5C9A6, 0xFFD9A377, 0xFF9C6B4A, 0xFF2B2B3A, 0xFF1B3358
    };

    private CanvasView canvas;
    private TextView sliderLabel;
    private SeekBar slider;

    private ActivityResultLauncher<String> openImage;
    private ActivityResultLauncher<String> addImage;
    private ActivityResultLauncher<String> createZip;
    private ActivityResultLauncher<String> createPng;
    private ActivityResultLauncher<String> createProject;
    private ActivityResultLauncher<String[]> openProject;

    private String projectId;
    private String lastError;
    private int lastExportCount;
    private int outW, outH;
    private int edgeClean = 2;
    private boolean saving = false;
    private boolean showAdvanced = false;
    private Layer pendingLayerExport;
    private ProjectIO.Loaded loaded;
    private int[] tintNext;
    private Runnable hideDemo;
    private final android.os.Handler previewHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        canvas = findViewById(R.id.canvas);
        sliderLabel = findViewById(R.id.sliderLabel);
        slider = findViewById(R.id.slider);
        canvas.setCallback(this);

        openImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) loadImage(uri);
                        else if (canvas.getProject() == null) finish();
                    }
                });
        addImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) addImageLayer(uri);
                    }
                });
        createZip = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/zip"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportZip(uri);
                    }
                });
        createPng = registerForActivityResult(new ActivityResultContracts.CreateDocument("image/png"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportLayer(uri);
                    }
                });
        createProject = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) saveProjectTo(uri);
                    }
                });
        openProject = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) openProjectFrom(uri);
                    }
                });

        click(R.id.btnUndo, new Runnable() {
            public void run() {
                canvas.doUndo();
                updateUi();
            }
        });
        click(R.id.btnRedo, new Runnable() {
            public void run() {
                canvas.doRedo();
                updateUi();
            }
        });
        click(R.id.btnSelMenu, new Runnable() {
            public void run() {
                selectionMenu();
            }
        });
        click(R.id.btnMenu, new Runnable() {
            public void run() {
                mainMenu();
            }
        });
        click(R.id.btnTools, new Runnable() {
            public void run() {
                toolGrid();
            }
        });
        click(R.id.btnSize, new Runnable() {
            public void run() {
                brushPresets();
            }
        });
        click(R.id.btnColor, new Runnable() {
            public void run() {
                colorDialog();
            }
        });
        click(R.id.btnLayers, new Runnable() {
            public void run() {
                toggleLayersPanel();
            }
        });
        click(R.id.btnLayersClose, new Runnable() {
            public void run() {
                closeLayers();
            }
        });
        click(R.id.btnExport, new Runnable() {
            public void run() {
                exportDialog();
            }
        });
        click(R.id.btnAddMode, new Runnable() {
            public void run() {
                canvas.setSubtract(false);
                updateUi();
            }
        });
        click(R.id.btnSubMode, new Runnable() {
            public void run() {
                canvas.setSubtract(true);
                updateUi();
            }
        });
        click(R.id.btnSmart, new Runnable() {
            public void run() {
                canvas.setSmart(!canvas.isSmart());
                canvas.showHud(canvas.isSmart() ? "Fino: SI (se queda en el color que tocas)" : "Fino: NO");
                updateUi();
            }
        });
        click(R.id.btnLineart, new Runnable() {
            public void run() {
                lineArtDialog();
            }
        });
        click(R.id.btnSizeMinus, new Runnable() {
            public void run() {
                slider.setProgress(Math.max(0, slider.getProgress() - 1));
            }
        });
        click(R.id.btnSizePlus, new Runnable() {
            public void run() {
                slider.setProgress(Math.min(slider.getMax(), slider.getProgress() + 1));
            }
        });
        final SeekBar op = findViewById(R.id.opacity);
        click(R.id.btnOpMinus, new Runnable() {
            public void run() {
                op.setProgress(Math.max(2, op.getProgress() - 5));
            }
        });
        click(R.id.btnOpPlus, new Runnable() {
            public void run() {
                op.setProgress(Math.min(100, op.getProgress() + 5));
            }
        });
        op.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                v = Math.max(2, v);
                canvas.setBrushOpacity(v / 100f);
                ((TextView) findViewById(R.id.opacityLabel)).setText(String.valueOf(v));
            }
        });
        slider.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                applySlider(v);
            }
        });
        installTooltips();

        canvas.setBrushSize(20f);
        syncSlider();
        updateUi();
        measureBars();

        projectId = getIntent().getStringExtra(EXTRA_PROJECT);
        if (projectId != null) recoverFrom(ProjectStore.fileFor(this, projectId));
        else openImage.launch("image/*");
    }

    @Override
    protected void onPause() {
        super.onPause();
        autosave(false);
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    private void installTooltips() {
        int[] ids = {R.id.btnUndo, R.id.btnRedo, R.id.btnSelMenu, R.id.btnMenu, R.id.btnTools, R.id.btnSize,
                R.id.btnColor, R.id.btnLayers, R.id.btnExport, R.id.btnAddMode, R.id.btnSubMode, R.id.btnSmart,
                R.id.btnLineart};
        String[] names = {"Deshacer (o toca con dos dedos)", "Rehacer (o toca con tres dedos)",
                "Seleccion: acciones con lo azul", "Mas opciones", "Herramientas", "Tipo de pincel",
                "Color", "Capas", "Exportar", "Agregar a lo azul", "Quitar de lo azul",
                "Fino: se queda en el color que tocas", "Line art: la linea hace de pared"};
        for (int i = 0; i < ids.length; i++) {
            final String n = names[i];
            findViewById(ids[i]).setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    toast(n);
                    return true;
                }
            });
        }
    }

    // ==================================================================
    // Abrir, agregar imagen, guardar
    // ==================================================================

    private Bitmap decode(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            return bmp;
        } catch (OutOfMemoryError e) {
            toast("La imagen es demasiado grande para la memoria del telefono");
        } catch (Exception e) {
            toast("No se pudo abrir: " + e.getMessage());
        }
        return null;
    }

    private void loadImage(Uri uri) {
        Bitmap bmp = decode(uri);
        if (bmp == null) return;
        projectId = null;
        canvas.setProject(new Project(bmp));
        bmp.recycle();
        afterProjectLoaded();
        toast("Imagen abierta en la capa \"imagen\"");
        guideIfFirstTime();
    }

    private void addImageLayer(Uri uri) {
        if (!needProject()) return;
        Bitmap bmp = decode(uri);
        if (bmp == null) return;
        canvas.addImageLayer(bmp);
        bmp.recycle();
        updateUi();
    }

    private void afterProjectLoaded() {
        closeTools();
        closeLayers();
        canvas.setMode(CanvasView.MODE_WAND);
        canvas.setSubtract(false);
        syncSlider();
        updateUi();
    }

    private void applyLoaded() {
        if (lastError != null) {
            toast("No se pudo abrir: " + lastError);
            return;
        }
        if (loaded == null || loaded.project == null) return;
        canvas.setProject(loaded.project);
        canvas.setColor(loaded.color);
        loaded = null;
        afterProjectLoaded();
    }

    /** Guarda sola en la galeria al salir y al hacer cambios de capas. */
    private void autosave(final boolean notify) {
        final Project p = canvas.getProject();
        if (p == null || saving) return;
        saving = true;
        if (projectId == null) projectId = ProjectStore.newId();
        final String id = projectId;
        final int color = canvas.getColor();
        final File dest = ProjectStore.fileFor(this, id);
        final File tmp = new File(dest.getAbsolutePath() + ".tmp");
        if (notify) toast("Guardando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileOutputStream fo = new FileOutputStream(tmp);
                    ProjectIO.save(fo, p, color);
                    fo.close();
                    if (dest.exists() && !dest.delete()) throw new java.io.IOException("No se pudo reemplazar");
                    if (!tmp.renameTo(dest)) throw new java.io.IOException("No se pudo renombrar");
                    Bitmap th = p.previewBitmap(320);
                    ProjectStore.saveThumb(MainActivity.this, id, th);
                    th.recycle();
                    lastError = null;
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                saving = false;
                if (notify) toast(lastError != null ? "Error al guardar: " + lastError : "Guardado en la galeria");
            }
        });
    }

    // ==================================================================
    // Herramientas
    // ==================================================================

    private static final String[] GROUPS = {"SACAR", "PINTAR Y BORRAR", "REHACER LO DE ATRAS", "MOVER"};
    // {grupo, modo, sub, avanzada}   sub: 1 agrega a lo azul, 2 quita de lo azul
    private static final int[][] TOOLS = {
            {0, CanvasView.MODE_WAND, 0, 0}, {0, CanvasView.MODE_BGERASE, 0, 0},
            {0, CanvasView.MODE_BRUSH, 1, 0}, {0, CanvasView.MODE_BRUSH, 2, 0},
            {0, CanvasView.MODE_MARKER, 0, 0}, {0, CanvasView.MODE_LASSO, 0, 0},
            {0, CanvasView.MODE_SCISSORS, 0, 1}, {0, CanvasView.MODE_MAGNET, 0, 1},
            {1, CanvasView.MODE_PAINT, 0, 0}, {1, CanvasView.MODE_ERASER, 0, 0},
            {1, CanvasView.MODE_BUCKET, 0, 0}, {1, CanvasView.MODE_PICKER, 0, 0},
            {2, CanvasView.MODE_ZONE, 0, 0}, {2, CanvasView.MODE_CLONE, 0, 0},
            {2, CanvasView.MODE_LINE, 0, 1}, {2, CanvasView.MODE_PATCH, 0, 1},
            {2, CanvasView.MODE_HEAL, 0, 1}, {2, CanvasView.MODE_TONE, 0, 1},
            {3, CanvasView.MODE_PAN, 0, 0}, {3, CanvasView.MODE_MOVE, 0, 0}
    };

    private String[] toolInfo(int mode, int sub) {
        switch (mode) {
            case CanvasView.MODE_BGERASE: return new String[]{"Borrar fondo",
                    "Borra el fondo de la capa sin tocar al personaje.",
                    "Pasa el pincel por el borde. Solo borra el color que queda en el centro del circulo.",
                    "Mira el resultado sobre negro o verde en Capas."};
            case CanvasView.MODE_WAND: return new String[]{"Varita",
                    "Marca en azul una zona del mismo color.",
                    "Toca una zona. Abajo, el + agrega y el - quita.",
                    "Despues: en el cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_BRUSH: return sub == 2 ? new String[]{"Borrar azul",
                    "Quita parte de lo marcado en azul. No borra el dibujo.",
                    "Pinta sobre lo azul que sobra.", "Sirve para corregir lo que marco la Varita."}
                    : new String[]{"Marcar azul", "Marca a mano lo que quieres sacar.",
                    "Pinta encima. Lo azul es lo que vas a copiar o borrar.",
                    "Despues: cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_ERASER: return new String[]{"Goma",
                    "Borra el dibujo de la capa elegida, como la goma de Ibis.",
                    "Elige la capa en Capas y borra. Si hay algo azul, solo borra dentro.",
                    "Si en Capas esta elegida la capa de seleccion, borra lo azul."};
            case CanvasView.MODE_MARKER: return new String[]{"Separar",
                    "Separa varias partes de una sola vez.",
                    "Raya cada parte con un color distinto y el fondo en gris. Toca el check verde.",
                    "Cada parte sale en su capa y la original se oculta."};
            case CanvasView.MODE_SCISSORS: return new String[]{"Tijeras", "Marca siguiendo el contorno.",
                    "Arrastra cerca de la linea y se pega sola. Vuelve al punto verde para cerrar.",
                    "Queda azul."};
            case CanvasView.MODE_MAGNET: return new String[]{"Magnetico", "Como las tijeras, de un solo trazo.",
                    "Arrastra por el contorno sin soltar. Al soltar se cierra.", "Queda azul."};
            case CanvasView.MODE_LASSO: return new String[]{"Lazo", "Marca rodeando con el dedo.",
                    "Dibuja alrededor de la zona.", "Queda azul."};
            case CanvasView.MODE_PAINT: return new String[]{"Brocha",
                    "Pinta con el color del cuadro de abajo, tambien donde es transparente.",
                    "Elige la capa en Capas y pinta. Si hay algo azul, solo pinta dentro.",
                    "Si en Capas esta elegida la capa de seleccion, pinta lo azul."};
            case CanvasView.MODE_BUCKET: return new String[]{"Relleno",
                    "Pinta de un color toda una zona de golpe.",
                    "Toca la zona. Usa el color del cuadro de abajo y la capa elegida.",
                    "Pinta el dibujo de verdad. Si fue sin querer, toca con dos dedos."};
            case CanvasView.MODE_PICKER: return new String[]{"Gotero", "Toma un color de la imagen.",
                    "Toca un color. Tambien manteniendo pulsado con cualquier herramienta.", "Despues: Brocha o Relleno."};
            case CanvasView.MODE_ZONE: return new String[]{"Zona",
                    "Rellena lo azul con el color plano que tiene alrededor.",
                    "Marca en azul lo que hay que rehacer (donde estaba el ojo). Toca dentro de lo azul.",
                    "Hazlo en la capa de atras, la que quedo con el hueco."};
            case CanvasView.MODE_CLONE: return new String[]{"Clonar", "Copia un trozo de la capa a otro lugar.",
                    "Toca de donde copiar (cruz roja). Despues pinta. Tiene espejo y giro abajo.",
                    "Para tapar huecos copiando algo parecido."};
            case CanvasView.MODE_LINE: return new String[]{"Linea",
                    "Continua una linea cortada dentro de lo azul.",
                    "Traza por donde seguia la linea. Se engancha a la linea real.", "Despues: Zona."};
            case CanvasView.MODE_PATCH: return new String[]{"Copiar zona",
                    "Rellena lo azul copiando sombras o brillos de otro lado.",
                    "Pinta en verde de donde copiar y toca el check.", "Para cuando Zona queda muy plano."};
            case CanvasView.MODE_HEAL: return new String[]{"Corrector",
                    "Copia de un lado a otro y funde el color para que no se note.",
                    "Toca de donde copiar. Despues pinta donde quieres.", "Para disimular cortes."};
            case CanvasView.MODE_TONE: return new String[]{"Trama",
                    "Continua la trama de puntos del manga dentro de lo azul.",
                    "Toca la trama que esta al lado de lo azul.", "Solo para manga."};
            case CanvasView.MODE_MOVE: return new String[]{"Mover",
                    "Mueve la capa entera, o solo lo azul si hay algo marcado.",
                    "Arrastra.", ""};
            default: return new String[]{"Mano", "Mueve y acerca la imagen sin pintar.",
                    "Arrastra con un dedo. Con dos dedos haces zoom en cualquier herramienta.", ""};
        }
    }

    private void toolGrid() {
        final View panel = findViewById(R.id.toolPanel);
        final View scrim = findViewById(R.id.toolScrim);
        if (panel.getVisibility() == View.VISIBLE) {
            closeTools();
            return;
        }
        closeLayers();
        LinearLayout box = findViewById(R.id.toolPanelContent);
        box.removeAllViews();
        TextView tip = new TextView(this);
        tip.setText("Manten pulsada una herramienta para ver que hace");
        tip.setTextColor(0xFF9FC6FF);
        tip.setTextSize(10f);
        tip.setPadding(dp(4), dp(2), dp(4), dp(2));
        box.addView(tip);
        int cols = 4, lastGroup = -1, inRow = 0;
        LinearLayout row = null;
        for (int[] tdef : TOOLS) {
            final int group = tdef[0], mode = tdef[1], sub = tdef[2];
            if (tdef[3] == 1 && !showAdvanced) continue;
            if (group != lastGroup) {
                if (row != null) fillRow(row, inRow, cols);
                TextView h = new TextView(this);
                h.setText(GROUPS[group]);
                h.setTextColor(0xFF8A8A92);
                h.setTextSize(10f);
                h.setPadding(dp(4), dp(8), 0, dp(2));
                box.addView(h);
                row = null;
                inRow = 0;
                lastGroup = group;
            }
            if (row == null || inRow == cols) {
                if (row != null) fillRow(row, inRow, cols);
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row);
                inRow = 0;
            }
            boolean active = canvas.getMode() == mode && (sub == 0 || (sub == 2) == canvas.isSubtract());
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(2), dp(6), dp(2), dp(5));
            cell.setBackgroundResource(active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(1), dp(1), dp(1), dp(1));
            cell.setLayoutParams(clp);
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
            img.setImageResource(sub == 2 ? R.drawable.ic_remove : toolIcon(mode));
            cell.addView(img);
            TextView t = new TextView(this);
            t.setText(toolInfo(mode, sub)[0]);
            t.setTextColor(0xFFE0E0E0);
            t.setTextSize(9.5f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setMaxLines(1);
            t.setPadding(0, dp(3), 0, 0);
            cell.addView(t);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closeTools();
                    if (sub == 1) canvas.setSubtract(false);
                    if (sub == 2) canvas.setSubtract(true);
                    selectTool(mode);
                    cardFirstTime(mode, sub);
                }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showToolCard(mode, sub);
                    return true;
                }
            });
            row.addView(cell);
            inRow++;
        }
        if (row != null) fillRow(row, inRow, cols);
        TextView more = new TextView(this);
        more.setText(showAdvanced ? "Menos herramientas" : "Mas herramientas");
        more.setTextColor(0xFFFFFFFF);
        more.setTextSize(12f);
        more.setGravity(android.view.Gravity.CENTER);
        more.setPadding(0, dp(8), 0, dp(6));
        more.setBackgroundResource(R.drawable.bg_cell);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAdvanced = !showAdvanced;
                closeTools();
                toolGrid();
            }
        });
        box.addView(more);

        View bottom = findViewById(R.id.bottomPanel);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) panel.getLayoutParams();
        lp.bottomMargin = bottom.getHeight() + dp(4);
        panel.setLayoutParams(lp);
        final int limit = canvas.getHeight() - bottom.getHeight() - findViewById(R.id.topBar).getHeight() - dp(16);
        scrim.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        panel.post(new Runnable() {
            @Override
            public void run() {
                if (limit > 0 && panel.getHeight() > limit) {
                    FrameLayout.LayoutParams l2 = (FrameLayout.LayoutParams) panel.getLayoutParams();
                    l2.height = limit;
                    panel.setLayoutParams(l2);
                }
            }
        });
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeTools();
            }
        });
    }

    private void selectTool(int mode) {
        canvas.setMode(mode);
        if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) canvas.resetCloneSource();
        syncSlider();
        updateUi();
    }

    /** Opciones propias de cada herramienta, solo iconos. */
    private void buildOptBar(int mode) {
        LinearLayout bar = findViewById(R.id.optBar);
        bar.removeAllViews();
        bar.setVisibility(View.VISIBLE);
        if (mode == CanvasView.MODE_BGERASE) {
            bar.addView(iconButton(canvas.isBgOnce() ? R.drawable.ic_once : R.drawable.ic_cont,
                    canvas.isBgOnce() ? "Toma el color una vez" : "Toma el color todo el rato", new Runnable() {
                        public void run() {
                            canvas.setBgOnce(!canvas.isBgOnce());
                            canvas.showHud(canvas.isBgOnce() ? "Color: una vez al tocar" : "Color: sigue al pincel");
                            updateUi();
                        }
                    }));
            int lim = canvas.getBgLimit();
            final String[] names = {"Contiguo: solo lo pegado", "Disperso: tambien entre mechones",
                    "Bordes: respeta el contorno"};
            bar.addView(iconButton(lim == 0 ? R.drawable.ic_lim_cont : lim == 1 ? R.drawable.ic_lim_disp
                    : R.drawable.ic_lim_edge, names[lim], new Runnable() {
                public void run() {
                    canvas.setBgLimit((canvas.getBgLimit() + 1) % 3);
                    canvas.showHud(names[canvas.getBgLimit()]);
                    updateUi();
                }
            }));
            ImageButton lock = iconButton(R.drawable.ic_lock, "Proteger el color de pintar", new Runnable() {
                public void run() {
                    canvas.setProtect(!canvas.isProtect());
                    canvas.showHud(canvas.isProtect() ? "Protegido el color cargado" : "Sin proteccion");
                    updateUi();
                }
            });
            lock.setBackgroundResource(canvas.isProtect() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(lock);
            bar.addView(iconButton(R.drawable.ic_range, "Cuanto se parece el color", new Runnable() {
                public void run() {
                    toleranceDialog();
                }
            }));
        } else if (mode == CanvasView.MODE_MARKER) {
            int lab = canvas.getMarkerLabel();
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            sw.setLayoutParams(lp);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(CanvasView.LABEL_COLORS[lab - 1]);
            g.setStroke(dp(2), 0xFFFFFFFF);
            sw.setBackground(g);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    labelPicker();
                }
            });
            bar.addView(sw);
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar rayones", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todos los rayones", new Runnable() {
                public void run() {
                    canvas.clearMarkers();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Separar las partes", new Runnable() {
                public void run() {
                    canvas.separateParts();
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else if (mode == CanvasView.MODE_LINE) {
            bar.addView(iconButton(R.drawable.ic_join, "Unir solas las lineas cortadas", new Runnable() {
                public void run() {
                    canvas.autoJoinLines();
                }
            }));
        } else if (mode == CanvasView.MODE_ZONE || mode == CanvasView.MODE_TONE) {
            bar.addView(iconButton(R.drawable.ic_patch, "Tapar todo lo azul de una vez", new Runnable() {
                public void run() {
                    canvas.fillHoleInSelection();
                }
            }));
        } else if (mode == CanvasView.MODE_PATCH) {
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar lo verde", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todo lo verde", new Runnable() {
                public void run() {
                    canvas.clearPatchSource();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Rellenar lo azul", new Runnable() {
                public void run() {
                    canvas.runPatchFill();
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) {
            bar.addView(iconButton(R.drawable.ic_aim, "Elegir otro origen", new Runnable() {
                public void run() {
                    canvas.resetCloneSource();
                }
            }));
            ImageButton mir = iconButton(R.drawable.ic_mirror, "Espejo", new Runnable() {
                public void run() {
                    canvas.setCloneMirror(!canvas.isCloneMirror());
                    canvas.showHud(canvas.isCloneMirror() ? "Espejo: SI" : "Espejo: NO");
                    updateUi();
                }
            });
            mir.setBackgroundResource(canvas.isCloneMirror() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(mir);
            bar.addView(iconButton(R.drawable.ic_rotate, "Girar el origen", new Runnable() {
                public void run() {
                    cloneAngleDialog();
                }
            }));
        } else {
            bar.setVisibility(View.GONE);
        }
    }

    private void cloneAngleDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(360);
        bar.setProgress(Math.round(canvas.getCloneAngle()) + 180);
        final TextView t = new TextView(this);
        t.setText(Math.round(canvas.getCloneAngle()) + "°");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int a = v - 180;
                for (int snap : new int[]{-180, -90, 0, 90, 180}) if (Math.abs(a - snap) <= 4) a = snap;
                t.setText(a + "°");
                canvas.setCloneAngle(a);
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    // ==================================================================
    // Menu de seleccion (cuadro punteado de arriba)
    // ==================================================================

    private void selectionMenu() {
        if (!needProject()) return;
        int[] icons = {R.drawable.ic_layer_add, R.drawable.ic_sel_delete, R.drawable.ic_clone,
                R.drawable.ic_sel_keep, R.drawable.ic_sel_invert, R.drawable.ic_close,
                R.drawable.ic_grow, R.drawable.ic_refine, R.drawable.ic_holes,
                R.drawable.ic_range, R.drawable.ic_patch, R.drawable.ic_scissors};
        String[] names = {"Copiar a capa", "Cortar a capa", "Duplicar capa", "Dejar solo esto",
                "Invertir", "Quitar azul", "Ampliar", "Refinar borde", "Cerrar puntos",
                "Gama color", "Tapar hueco", "Cerrar tijeras"};
        Runnable[] actions = {
                new Runnable() { public void run() { canvas.layerFromSelection(false); updateUi(); } },
                new Runnable() { public void run() { canvas.layerFromSelection(true); updateUi(); } },
                new Runnable() { public void run() { canvas.duplicateActive(); updateUi(); } },
                new Runnable() { public void run() { canvas.keepSelectionInLayer(); } },
                new Runnable() { public void run() { canvas.invertSelection(); } },
                new Runnable() { public void run() { canvas.clearSelection(); } },
                new Runnable() { public void run() { expandDialog(); } },
                new Runnable() { public void run() { refineDialog(); } },
                new Runnable() { public void run() { closeHolesDialog(); } },
                new Runnable() { public void run() { colorRangeDialog(); } },
                new Runnable() { public void run() { canvas.fillHoleInSelection(); } },
                new Runnable() { public void run() { canvas.scissorsClose(); } }
        };
        showIconGrid(null, icons, names, actions, 3, -1);
    }

    // ==================================================================
    // Panel de capas, como Ibis
    // ==================================================================

    private void toggleLayersPanel() {
        if (!needProject()) return;
        View panel = findViewById(R.id.layersPanel);
        if (panel.getVisibility() == View.VISIBLE) {
            closeLayers();
        } else {
            closeTools();
            panel.setVisibility(View.VISIBLE);
            hideForLayers(true);
            buildLayersPanel();
        }
    }

    private void closeLayers() {
        findViewById(R.id.layersPanel).setVisibility(View.GONE);
        hideForLayers(false);
        updateUi();
    }

    private void hideForLayers(boolean hide) {
        int v = hide ? View.GONE : View.VISIBLE;
        findViewById(R.id.sizeRow).setVisibility(v);
        findViewById(R.id.opacityRow).setVisibility(v);
        if (hide) {
            findViewById(R.id.selBar).setVisibility(View.GONE);
            findViewById(R.id.optBar).setVisibility(View.GONE);
        }
    }

    private boolean layersOpen() {
        return findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE;
    }

    private void buildLayersPanel() {
        final Project p = canvas.getProject();
        if (p == null) return;
        buildViewBg();
        LinearLayout list = findViewById(R.id.layersList);
        list.removeAllViews();

        // capa de seleccion: tocarla hace que la brocha y la goma pinten lo azul
        LinearLayout sel = rowBase(p.active == Project.SEL);
        sel.addView(thumb(Thumbs.forSelection(p, 96)));
        sel.addView(rowText("Capa de seleccion", p.active == Project.SEL
                ? "la brocha y la goma pintan lo azul" : (p.hasSelection() ? "con algo en azul" : "vacia"), true));
        sel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canvas.setActive(Project.SEL);
                buildLayersPanel();
                canvas.showHud("Ahora la brocha y la goma pintan lo azul");
            }
        });
        list.addView(sel);

        for (int i = p.layers.size() - 1; i >= 0; i--) {
            final int idx = i;
            final Layer l = p.layers.get(i);
            LinearLayout row = rowBase(p.active == i);
            row.addView(thumb(Thumbs.forLayer(p, l, 96)));
            row.addView(rowText(l.name, (l.opacity * 100 / 255) + "%", l.visible));
            row.addView(iconButton(l.visible ? R.drawable.ic_eye : R.drawable.ic_eye_off,
                    l.visible ? "Ocultar" : "Mostrar", new Runnable() {
                        public void run() {
                            l.visible = !l.visible;
                            canvas.layersChanged();
                            buildLayersPanel();
                        }
                    }));
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    canvas.setActive(idx);
                    buildLayersPanel();
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    layerOptions(l);
                    return true;
                }
            });
            list.addView(row);
        }
        buildLayerActions();
    }

    /** Fondo para mirar: cuadros claros, cuadros oscuros, blanco, negro, verde. */
    private void buildViewBg() {
        LinearLayout row = findViewById(R.id.viewBgRow);
        row.removeAllViews();
        for (int k = 0; k < CanvasView.VIEW_BG.length; k++) {
            final int idx = k;
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
            lp.setMargins(dp(3), 0, dp(3), 0);
            sw.setLayoutParams(lp);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(6));
            int[] c = CanvasView.VIEW_BG[k];
            if (c[0] != c[1]) g.setColors(new int[]{c[0], c[1]});
            else g.setColor(c[0]);
            boolean on = canvas.getViewBg() == k;
            g.setStroke(dp(on ? 3 : 1), on ? 0xFF2F6BD8 : 0xFF777777);
            sw.setBackground(g);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    canvas.setViewBg(idx);
                    buildViewBg();
                }
            });
            row.addView(sw);
        }
    }

    /** Botones de abajo del panel: actuan sobre la capa marcada en azul. */
    private void buildLayerActions() {
        LinearLayout bar = findViewById(R.id.layersActions);
        bar.removeAllViews();
        addAction(bar, R.drawable.ic_add, "Nueva", new Runnable() {
            public void run() {
                canvas.addEmptyLayer();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_dup, "Duplicar", new Runnable() {
            public void run() {
                canvas.duplicateActive();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_layer_add, "De lo azul", new Runnable() {
            public void run() {
                canvas.layerFromSelection(false);
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_down, "Combinar", new Runnable() {
            public void run() {
                canvas.mergeDown();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_up, "Subir", new Runnable() {
            public void run() {
                canvas.moveActive(1);
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_down, "Bajar", new Runnable() {
            public void run() {
                canvas.moveActive(-1);
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_opacity, "Opacidad", new Runnable() {
            public void run() {
                Layer l = canvas.getProject().activeLayer();
                if (l == null) toast("Toca una capa primero");
                else opacityDialog(l);
            }
        });
        addAction(bar, R.drawable.ic_open, "Imagen", new Runnable() {
            public void run() {
                addImage.launch("image/*");
            }
        });
        addAction(bar, R.drawable.ic_sel_delete, "Limpiar", new Runnable() {
            public void run() {
                canvas.clearActive();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_trash, "Eliminar", new Runnable() {
            public void run() {
                canvas.deleteActive();
                afterLayerOp();
            }
        });
    }

    private void addAction(LinearLayout bar, int icon, String name, final Runnable r) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(android.view.Gravity.CENTER);
        cell.setPadding(dp(6), dp(4), dp(6), dp(4));
        cell.setBackgroundResource(R.drawable.bg_cell);
        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(24)));
        img.setImageResource(icon);
        cell.addView(img);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFDDDDDD);
        t.setTextSize(10f);
        t.setPadding(0, dp(2), 0, 0);
        cell.addView(t);
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        bar.addView(cell);
    }

    private void afterLayerOp() {
        if (layersOpen()) buildLayersPanel();
        updateUi();
    }

    private void layerOptions(final Layer l) {
        final String[] items = {"Cambiar nombre", "Exportar solo esta capa"};
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 0) {
                            renameDialog(l);
                        } else {
                            pendingLayerExport = l;
                            createPng.launch(l.name + ".png");
                        }
                    }
                })
                .show();
    }

    // ==================================================================
    // Menu de tres puntos
    // ==================================================================

    private void mainMenu() {
        final List<String> items = new ArrayList<String>();
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        items.add("Guia rapida: como se usa");
        items.add("Que hace cada herramienta");
        items.add("Encuadrar la imagen");
        items.add(canvas.isAim() ? "Cursor separado con lupa: SI" : "Cursor separado con lupa: NO");
        items.add(sp.getBoolean("demo_on", true) ? "Animacion al elegir herramienta: SI"
                : "Animacion al elegir herramienta: NO");
        items.add("Abrir otra imagen");
        items.add("Agregar una imagen como capa");
        items.add("Ajustes de la varita");
        items.add(canvas.isWandGlobal() ? "Varita en toda la imagen: SI" : "Varita en toda la imagen: NO");
        items.add("Filtros de la capa");
        items.add("Girar la imagen");
        items.add("Estabilizador del trazo");
        items.add("Dureza del pincel");
        items.add("Guardar ahora");
        items.add("Guardar copia en un archivo");
        new AlertDialog.Builder(this)
                .setTitle("Paint Zeta")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        runMenu(items.get(i));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void runMenu(String item) {
        if (item.startsWith("Guia")) {
            guideDialog();
        } else if (item.startsWith("Que hace")) {
            toolCardsList();
        } else if (item.startsWith("Encuadrar")) {
            if (needProject()) canvas.fit();
        } else if (item.startsWith("Cursor")) {
            canvas.setAim(!canvas.isAim());
            canvas.showHud(canvas.isAim() ? "Cursor separado del dedo, con lupa" : "Cursor normal");
        } else if (item.startsWith("Animacion")) {
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean on = !sp.getBoolean("demo_on", true);
            sp.edit().putBoolean("demo_on", on).apply();
            toast(on ? "Animacion al elegir herramienta: SI" : "Animaciones apagadas");
        } else if (item.startsWith("Abrir otra")) {
            autosave(false);
            openImage.launch("image/*");
        } else if (item.startsWith("Agregar una imagen")) {
            addImage.launch("image/*");
        } else if (item.startsWith("Ajustes de la varita")) {
            wandDialog();
        } else if (item.startsWith("Varita en toda")) {
            canvas.setWandGlobal(!canvas.isWandGlobal());
            toast(canvas.isWandGlobal() ? "La varita busca ese color en toda la imagen" : "La varita agarra solo lo pegado");
        } else if (item.startsWith("Filtros")) {
            filtersDialog();
        } else if (item.startsWith("Girar")) {
            rotateDialog();
        } else if (item.startsWith("Estabilizador")) {
            stabilizerDialog();
        } else if (item.startsWith("Dureza")) {
            hardnessDialog();
        } else if (item.startsWith("Guardar ahora")) {
            if (needProject()) autosave(true);
        } else if (item.startsWith("Guardar copia")) {
            projectDialog();
        }
    }

    /** Lista de todas las herramientas; al tocar una, sale su ficha animada. */
    private void toolCardsList() {
        final List<int[]> defs = new ArrayList<int[]>();
        List<String> names = new ArrayList<String>();
        for (int[] t : TOOLS) {
            defs.add(t);
            names.add(toolInfo(t[1], t[2])[0]);
        }
        new AlertDialog.Builder(this)
                .setTitle("Toca una para ver que hace")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        showToolCard(defs.get(i)[1], defs.get(i)[2]);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    // ==================================================================
    // Exportar
    // ==================================================================

    private void exportDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        final int[][] sizes = {{p.w, p.h}, {Math.max(1, p.w / 2), Math.max(1, p.h / 2)},
                longSide(p, 1920), longSide(p, 1280)};
        final String[] items = {"Original  " + sizes[0][0] + "x" + sizes[0][1],
                "Mitad  " + sizes[1][0] + "x" + sizes[1][1],
                "Lado largo 1920  " + sizes[2][0] + "x" + sizes[2][1],
                "Lado largo 1280  " + sizes[3][0] + "x" + sizes[3][1]};
        new AlertDialog.Builder(this)
                .setTitle("Exportar las capas visibles")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        outW = sizes[i][0];
                        outH = sizes[i][1];
                        edgeDialogExport();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void edgeDialogExport() {
        final String[] items = {"Limpiar borde y quitar el fondo pegado (recomendado)", "Solo limpiar borde",
                "No tocar el borde"};
        final int[] vals = {2, 1, 0};
        new AlertDialog.Builder(this)
                .setTitle("Borde de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        edgeClean = vals[i];
                        createZip.launch("capas_anime.zip");
                    }
                })
                .show();
    }

    private void doExportZip(final Uri uri) {
        final Project p = canvas.getProject();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    lastExportCount = Exporter.exportZip(getContentResolver(), p, uri, outW, outH, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al exportar: " + lastError
                        : lastExportCount + " PNG de " + outW + "x" + outH + " guardados en el ZIP");
            }
        });
    }

    private void doExportLayer(final Uri uri) {
        final Project p = canvas.getProject();
        final Layer l = pendingLayerExport;
        pendingLayerExport = null;
        if (l == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    Exporter.exportLayer(getContentResolver(), p, l, uri, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error: " + lastError : "PNG guardado");
            }
        });
    }

    // ==================================================================
    // Interfaz
    // ==================================================================

    private void updateUi() {
        Project p = canvas.getProject();
        ((TextView) findViewById(R.id.layerCount)).setText(String.valueOf(p == null ? 0 : p.layers.size()));
        ((TextView) findViewById(R.id.btnSize)).setText(String.format(Locale.US,
                canvas.getBrushSize() < 10 ? "%.1f" : "%.0f", canvas.getBrushSize()));
        android.graphics.drawable.GradientDrawable sw = new android.graphics.drawable.GradientDrawable();
        sw.setCornerRadius(dp(4));
        sw.setColor(canvas.getColor());
        sw.setStroke(dp(2), 0xFFFFFFFF);
        findViewById(R.id.btnColor).setBackground(sw);
        ((ImageButton) findViewById(R.id.btnTools)).setImageResource(
                canvas.getMode() == CanvasView.MODE_BRUSH && canvas.isSubtract() ? R.drawable.ic_remove
                        : toolIcon(canvas.getMode()));

        if (layersOpen()) {
            hideForLayers(true);
            buildLayersPanel();
            return;
        }
        int m = canvas.getMode();
        boolean selTool = m == CanvasView.MODE_WAND || m == CanvasView.MODE_LASSO
                || m == CanvasView.MODE_SCISSORS || m == CanvasView.MODE_MAGNET || m == CanvasView.MODE_BRUSH;
        findViewById(R.id.selBar).setVisibility(selTool ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnAddMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg : R.drawable.bg_seg_on);
        findViewById(R.id.btnSubMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_seg);
        toggle(R.id.btnSmart, canvas.isSmart());
        toggle(R.id.btnLineart, canvas.isUseBarrier() && p != null && p.barrier != null);
        buildOptBar(m);
    }

    // ==================================================================
    // Avisos del lienzo
    // ==================================================================

    @Override
    public void onBusy(boolean busy) {
        findViewById(R.id.btnExport).setEnabled(!busy);
    }

    @Override
    public void onChanged() {
        updateUi();
    }

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    @Override
    public void onColorPicked(int color) {
        updateUi();
        canvas.showHud(String.format(Locale.US, "Color #%06X", color & 0xFFFFFF));
    }

    @Override
    public void onUndoGesture() {
        canvas.doUndo();
        updateUi();
    }

    @Override
    public void onRedoGesture() {
        canvas.doRedo();
        updateUi();
    }


    // ==================================================================
    // Dialogos
    // ==================================================================

    /** Ajustes de la varita, al estilo de los de Ibis. */
    private void wandDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Fuerza: " + canvas.getTolerance());
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tTol.setText("Fuerza: " + v);
            }
        });
        root.addView(tTol);
        root.addView(sTol);

        final TextView tSoft = new TextView(this);
        final SeekBar sSoft = new SeekBar(this);
        sSoft.setMax(120);
        sSoft.setProgress(canvas.getSoftness());
        tSoft.setText("Suavidad del borde: " + canvas.getSoftness());
        sSoft.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tSoft.setText("Suavidad del borde: " + v);
            }
        });
        root.addView(tSoft);
        root.addView(sSoft);

        final TextView tExp = new TextView(this);
        final SeekBar sExp = new SeekBar(this);
        sExp.setMax(80); // -3.0 .. +5.0 en pasos de 0.1
        sExp.setProgress(Math.round((canvas.getExpansion() + 3f) * 10f));
        tExp.setText(expLabel(canvas.getExpansion()));
        sExp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tExp.setText(expLabel(v / 10f - 3f));
            }
        });
        root.addView(tExp);
        root.addView(sExp);

        final CheckBox cbGap = new CheckBox(this);
        cbGap.setText("Reconocimiento de huecos (linea abierta)");
        cbGap.setChecked(canvas.isGapOn());
        root.addView(cbGap);

        final TextView tGap = new TextView(this);
        final SeekBar sGap = new SeekBar(this);
        sGap.setMax(12);
        sGap.setProgress(canvas.getGapRadius());
        tGap.setText("Tamano del hueco que tapa: " + canvas.getGapRadius() + " px");
        sGap.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tGap.setText("Tamano del hueco que tapa: " + v + " px");
            }
        });
        root.addView(tGap);
        root.addView(sGap);

        final TextView tMode = new TextView(this);
        tMode.setText("Como compara el color");
        tMode.setPadding(0, dp(10), 0, 0);
        root.addView(tMode);
        final RadioGroup rg = new RadioGroup(this);
        String[] names = {"Exacto (RGB)", "Por tono, ignora sombras", "Como lo ve el ojo (Lab)"};
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(1000 + i);
            rg.addView(rb);
        }
        rg.check(1000 + canvas.getColorMode());
        root.addView(rg);

        new AlertDialog.Builder(this)
                .setTitle("Varita y balde")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.setSoftness(sSoft.getProgress());
                        canvas.setExpansion(sExp.getProgress() / 10f - 3f);
                        canvas.setGap(cbGap.isChecked(), Math.max(1, sGap.getProgress()));
                        int m = rg.getCheckedRadioButtonId() - 1000;
                        canvas.setColorMode(m < 0 ? ColorDist.RGB : m);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNeutralButton("Valores de fabrica", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(28);
                        canvas.setSoftness(24);
                        canvas.setExpansion(1.5f);
                        canvas.setGap(false, 4);
                        canvas.setColorMode(ColorDist.RGB);
                        syncSlider();
                        updateUi();
                        toast("Restablecido");
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private String expLabel(float v) {
        return String.format(Locale.US, "Expansion del borde: %.1f px", v);
    }

    /** Gama de colores, con vista previa mientras mueves el margen. */
    private void colorRangeDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView info = new TextView(this);
        info.setText("Se usa el color cargado. Mueve el margen y mira el lienzo: la seleccion se actualiza sola.");
        root.addView(info);

        final View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        lp.topMargin = dp(8);
        sw.setLayoutParams(lp);
        sw.setBackgroundColor(canvas.getColor());
        root.addView(sw);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Margen: " + canvas.getTolerance());
        root.addView(tTol);
        root.addView(sTol);

        final CheckBox replace = new CheckBox(this);
        replace.setText("Reemplazar la seleccion actual");
        replace.setChecked(true);
        root.addView(replace);

        canvas.beginPreview();
        final Runnable[] pending = new Runnable[1];
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, final int v, boolean u) {
                tTol.setText("Margen: " + v);
                if (pending[0] != null) previewHandler.removeCallbacks(pending[0]);
                pending[0] = new Runnable() {
                    @Override
                    public void run() {
                        canvas.previewColorRange(canvas.getColor(), v, replace.isChecked());
                    }
                };
                previewHandler.postDelayed(pending[0], 180);
            }
        });
        canvas.previewColorRange(canvas.getColor(), sTol.getProgress(), replace.isChecked());

        new AlertDialog.Builder(this)
                .setTitle("Gama de colores")
                .setView(scroll)
                .setCancelable(false)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.endPreview(true);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.endPreview(false);
                    }
                })
                .show();
    }

    private void refineDialog() {
        if (!needProject()) return;
        final String[] items = {"Suave (pelo fino)", "Medio", "Fuerte"};
        final int[] rad = {6, 12, 20};
        final float[] eps = {0.0004f, 0.0016f, 0.006f};
        new AlertDialog.Builder(this)
                .setTitle("Refinar borde")
                .setMessage("Hace que el borde de la seleccion siga el dibujo real. Para pelo y bordes finos.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.refineEdge(rad[i], eps[i]);
                    }
                })
                .show();
    }

    private void unpaintedDialog() {
        if (!needProject()) return;
        final String[] items = {"Solo huecos chicos", "Huecos medianos", "Huecos grandes", "Todos los huecos"};
        final int[] vals = {2, 8, 30, 0};
        new AlertDialog.Builder(this)
                .setTitle("Rellenar zonas sin pintar")
                .setMessage("Rellena los huecos que quedaron encerrados dentro de la seleccion, sin deformar el contorno de afuera.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(5, vals[i]);
                    }
                })
                .show();
    }

    private void filtersDialog() {
        if (!needProject()) return;
        final String[] items = {
                "Quitar ruido de JPEG (mediana)",
                "Aplanar tonos (posterizar)",
                "Niveles: mas contraste",
                "Extraer line art"
        };
        new AlertDialog.Builder(this)
                .setTitle("Filtros de limpieza")
                .setMessage("Aplicar uno antes de seleccionar hace que la varita agarre mucho mejor.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                canvas.applyFilter(0, 0, 0, 0);
                                break;
                            case 1:
                                posterizeDialog();
                                break;
                            case 2:
                                canvas.applyFilter(2, 25, 230, 100);
                                break;
                            default:
                                lineArtFilterDialog();
                                break;
                        }
                    }
                })
                .show();
    }

    private void posterizeDialog() {
        final String[] items = {"4 tonos", "6 tonos", "10 tonos", "16 tonos"};
        final int[] vals = {4, 6, 10, 16};
        new AlertDialog.Builder(this)
                .setTitle("Aplanar tonos")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.applyFilter(1, vals[i], 0, 0);
                    }
                })
                .show();
    }

    /** Extraer line art con sus tres controles, como el filtro de Ibis. */
    private void lineArtFilterDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tw = new TextView(this);
        final SeekBar sw = new SeekBar(this);
        sw.setMax(255);
        sw.setProgress(210);
        tw.setText("Blanco: 210");
        sw.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tw.setText("Blanco: " + v);
            }
        });
        root.addView(tw);
        root.addView(sw);

        final TextView tb = new TextView(this);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(255);
        sb.setProgress(40);
        tb.setText("Negro: 40");
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tb.setText("Negro: " + v);
            }
        });
        root.addView(tb);
        root.addView(sb);

        final TextView tm = new TextView(this);
        final SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(50);
        tm.setText("Medio: 50");
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tm.setText("Medio: " + Math.max(1, v));
            }
        });
        root.addView(tm);
        root.addView(sm);

        new AlertDialog.Builder(this)
                .setTitle("Extraer line art")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.applyFilter(3, sw.getProgress(), sb.getProgress(),
                                Math.max(1, sm.getProgress()));
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void stabilizerDialog() {
        final String[] items = {"Apagado", "Suave", "Medio", "Fuerte"};
        final float[] vals = {0f, 0.5f, 0.72f, 0.88f};
        new AlertDialog.Builder(this)
                .setTitle("Estabilizador del trazo")
                .setMessage("Corrige el pulso. Cuanto mas fuerte, mas suave sale la linea, pero responde con mas retraso.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setStabilizer(vals[i]);
                        toast("Estabilizador: " + items[i]);
                    }
                })
                .show();
    }

    private void expandDialog() {
        if (!needProject()) return;
        final String[] items = {"+0.5 px", "+1.0 px", "+1.5 px", "+2.0 px", "-0.5 px", "-1.0 px"};
        final float[] vals = {0.5f, 1f, 1.5f, 2f, -0.5f, -1f};
        new AlertDialog.Builder(this)
                .setTitle("Expandir o contraer con decimales")
                .setMessage("Lo positivo se come el antialias del contorno y quita los cuadraditos blancos.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.expandSelection(vals[i]);
                    }
                })
                .show();
    }

    /** Quita los puntitos que deja la trama del manga dentro de la seleccion. */
    private void closeHolesDialog() {
        if (!needProject()) return;
        final String[] items = {"Puntos chicos (1 px)", "Medianos (2 px)", "Grandes (3 px)", "Muy grandes (5 px)"};
        final int[] vals = {1, 2, 3, 5};
        new AlertDialog.Builder(this)
                .setTitle("Cerrar huecos de la trama")
                .setMessage("Rellena los puntitos blancos que la trama deja dentro de lo que seleccionaste.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(4, vals[i]);
                    }
                })
                .show();
    }

    private void hardnessDialog() {
        final String[] items = {"Muy suave 20%", "Suave 40%", "Media 70%", "Dura 100%"};
        final float[] vals = {0.2f, 0.4f, 0.7f, 1f};
        new AlertDialog.Builder(this)
                .setTitle("Dureza del pincel")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setHardness(vals[i]);
                        toast("Dureza " + items[i]);
                    }
                })
                .show();
    }

    private void rotateDialog() {
        if (!needProject()) return;
        final String[] items = {"Girar a la derecha", "Girar a la izquierda",
                "Voltear horizontal", "Voltear vertical"};
        new AlertDialog.Builder(this)
                .setTitle("Girar imagen")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.transform(i);
                    }
                })
                .show();
    }

    private void lineArtDialog() {
        if (!needProject()) return;
        if (canvas.isUseBarrier() && canvas.getProject().barrier != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Line art")
                    .setMessage("La barrera esta activa. La varita y el balde se detienen en las lineas.")
                    .setPositiveButton("Desactivar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.setUseBarrier(false);
                            updateUi();
                        }
                    })
                    .setNegativeButton("Recalcular", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            thresholdDialog();
                        }
                    })
                    .show();
            return;
        }
        thresholdDialog();
    }

    private void thresholdDialog() {
        final String[] items = {"Lineas muy oscuras (60)", "Oscuras (90)", "Normal (120)", "Tenues (160)"};
        final int[] vals = {60, 90, 120, 160};
        new AlertDialog.Builder(this)
                .setTitle("Que tan oscura es la linea")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int i) {
                        final String[] gaps = {"Sin cerrar huecos", "Cerrar 1 px", "Cerrar 2 px", "Cerrar 3 px"};
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cerrar huecos de la linea")
                                .setItems(gaps, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int g) {
                                        canvas.buildBarrier(vals[i], g);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    private void colorDialog() {
        final int[] chosen = {canvas.getColor()};

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final View preview = new View(this);
        LinearLayout.LayoutParams pvp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        pvp.bottomMargin = dp(10);
        preview.setLayoutParams(pvp);
        preview.setBackgroundColor(chosen[0]);
        root.addView(preview);

        final SeekBar sr = new SeekBar(this);
        final SeekBar sg = new SeekBar(this);
        final SeekBar sb = new SeekBar(this);
        sr.setMax(255);
        sg.setMax(255);
        sb.setMax(255);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        root.addView(grid);

        LinearLayout row = null;
        for (int i = 0; i < PALETTE.length; i++) {
            if (i % 6 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row);
            }
            final int c = PALETTE[i];
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            sw.setLayoutParams(lp);
            sw.setBackgroundColor(c);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chosen[0] = c;
                    preview.setBackgroundColor(c);
                    sr.setProgress(Color.red(c));
                    sg.setProgress(Color.green(c));
                    sb.setProgress(Color.blue(c));
                }
            });
            row.addView(sw);
        }

        SeekBar.OnSeekBarChangeListener rgb = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                if (!fromUser) return;
                chosen[0] = Color.rgb(sr.getProgress(), sg.getProgress(), sb.getProgress());
                preview.setBackgroundColor(chosen[0]);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        };

        addLabeled(root, "Rojo", sr, Color.red(chosen[0]), rgb);
        addLabeled(root, "Verde", sg, Color.green(chosen[0]), rgb);
        addLabeled(root, "Azul", sb, Color.blue(chosen[0]), rgb);

        new AlertDialog.Builder(this)
                .setTitle("Color para pintar")
                .setView(scroll)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setColor(chosen[0]);
                        updateUi();
                    }
                })
                .setNeutralButton("Tomar de la imagen", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setMode(CanvasView.MODE_PICKER);
                        toast("Toca la imagen para tomar ese color");
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void addLabeled(LinearLayout root, String name, SeekBar bar, int value,
                            SeekBar.OnSeekBarChangeListener l) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(l);
        root.addView(bar);
    }

    private void renameDialog(final Layer l) {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        in.setText(l.name);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la capa")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        if (!s.isEmpty()) l.name = s;
                        updateUi();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void opacityDialog(final Layer l) {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(l.opacity * 100 / 255);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        final TextView t = new TextView(this);
        t.setText("Opacidad: " + bar.getProgress() + "%");
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Opacidad: " + v + "%");
            }
        });
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setView(root)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        l.opacity = bar.getProgress() * 255 / 100;
                        canvas.layersChanged();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Tipos de pincel, como la lista de brochas de Ibis. */
    private void brushPresets() {
        final String[] names = {"Pluma suave", "Pluma fuerte", "Rotulador fino", "Rotulador",
                "Lapiz difuminado", "Aerografo"};
        final float[] sizes = {22f, 30f, 3f, 8f, 60f, 80f};
        final float[] hard = {0.35f, 1f, 0.9f, 0.9f, 0.1f, 0.05f};
        final int[] opac = {100, 100, 100, 100, 100, 30};

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < names.length; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setBackgroundResource(R.drawable.bg_cell);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
            img.setImageBitmap(strokePreview(dp(260), dp(36), sizes[i], hard[i], opac[i]));
            row.addView(img);
            TextView t = new TextView(this);
            t.setText(names[i] + "   " + (int) sizes[i] + " px");
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12f);
            row.addView(t);
            final int idx = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dlg[0].dismiss();
                    canvas.setBrushSize(sizes[idx]);
                    canvas.setHardness(hard[idx]);
                    ((SeekBar) findViewById(R.id.opacity)).setProgress(opac[idx]);
                    syncSlider();
                    updateUi();
                    canvas.showHud(names[idx]);
                }
            });
            root.addView(row);
        }
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        dlg[0] = new AlertDialog.Builder(this).setView(sc).create();
        dlg[0].show();
    }

    /** Dibuja una muestra del trazo para la lista de pinceles. */
    private Bitmap strokePreview(int w, int h, float size, float hardness, int opacity) {
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setStyle(android.graphics.Paint.Style.STROKE);
        p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        p.setColor(0xFFFFFFFF);
        p.setAlpha(opacity * 255 / 100);
        float sw = Math.max(1.5f, Math.min(h * 0.7f, size * 0.35f));
        p.setStrokeWidth(sw);
        if (hardness < 0.8f) {
            p.setMaskFilter(new android.graphics.BlurMaskFilter(
                    Math.max(1f, sw * (1f - hardness) * 0.6f),
                    android.graphics.BlurMaskFilter.Blur.NORMAL));
        }
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(sw, h / 2f);
        path.cubicTo(w * 0.3f, h * 0.1f, w * 0.6f, h * 0.9f, w - sw, h / 2f);
        c.drawPath(path, p);
        return b;
    }

    private void toleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getTolerance());
        final TextView t = new TextView(this);
        t.setText(String.valueOf(canvas.getTolerance()));
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText(String.valueOf(v));
                canvas.setTolerance(v);
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Elegir que parte se esta rayando: un color por parte, el gris es el fondo. */
    private void labelPicker() {
        int n = CanvasView.LABEL_NAMES.length;
        int[] icons = new int[n];
        String[] names = new String[n];
        Runnable[] actions = new Runnable[n];
        for (int i = 0; i < n; i++) {
            icons[i] = R.drawable.ic_color;
            names[i] = i == n - 1 ? "fondo" : "parte " + (i + 1);
            final int lab = i + 1;
            actions[i] = new Runnable() {
                public void run() {
                    canvas.setMarkerLabel(lab);
                    canvas.setSubtract(false);
                    canvas.showHud(lab == CanvasView.LABEL_NAMES.length ? "Rayando el fondo" : "Rayando parte " + lab);
                    updateUi();
                }
            };
        }
        showIconGridTinted(icons, names, actions, 3, canvas.getMarkerLabel() - 1, CanvasView.LABEL_COLORS);
    }

    private void showIconGridTinted(int[] icons, String[] names, Runnable[] actions, int cols,
                                    int active, int[] tints) {
        tintNext = tints;
        showIconGrid(null, icons, names, actions, cols, active);
        tintNext = null;
    }

    /** Cuadricula de iconos con su nombre corto debajo. */
    private void showIconGrid(String title, int[] icons, String[] names, final Runnable[] actions,
                              int cols, int active) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                root.addView(row);
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(4), dp(10), dp(4), dp(10));
            cell.setBackgroundResource(i == active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(3), dp(3), dp(3), dp(3));
            cell.setLayoutParams(clp);

            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
            img.setImageResource(icons[i]);
            if (tintNext != null && i < tintNext.length) img.setColorFilter(tintNext[i]);
            cell.addView(img);

            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, dp(4), 0, 0);
            cell.addView(t);

            final int idx = i;
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    actions[idx].run();
                }
            });
            row.addView(cell);
        }
        // rellenar la ultima fila para que no se estiren las celdas
        int rest = icons.length % cols;
        if (rest != 0 && row != null) {
            for (int k = rest; k < cols; k++) {
                View v = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
                v.setLayoutParams(lp);
                row.addView(v);
            }
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setView(root);
        if (title != null) b.setTitle(title);
        dlg[0] = b.create();
        dlg[0].show();
    }

    /** Ficha de la herramienta: dibujo de antes y despues y tres lineas cortas. */
    private void showToolCard(int mode, int sub) {
        String[] info = toolInfo(mode, sub);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(info[0]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        com.pacco.animecut.view.ToolDemoView art =
                new com.pacco.animecut.view.ToolDemoView(this, mode, sub == 2);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        root.addView(cardLine("Para que:", info[1]));
        root.addView(cardLine("Como:", info[2]));
        if (!info[3].isEmpty()) root.addView(cardLine("", info[3]));
        new AlertDialog.Builder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    private TextView cardLine(String head, String text) {
        TextView t = new TextView(this);
        t.setText(head.isEmpty() ? text : head + " " + text);
        t.setTextColor(head.isEmpty() ? 0xFF9FC6FF : 0xFFE0E0E0);
        t.setTextSize(13f);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    /**
     * La primera vez que eliges una herramienta sale su ficha completa. Las
     * siguientes veces, un cuadrito con la animacion unos segundos.
     */
    private void cardFirstTime(int mode, int sub) {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        String key = "card_" + mode + "_" + sub;
        if (!sp.getBoolean(key, false)) {
            sp.edit().putBoolean(key, true).apply();
            showToolCard(mode, sub);
            return;
        }
        if (sp.getBoolean("demo_on", true)) showDemo(mode, sub);
    }

    /** Cuadrito arriba a la izquierda con la herramienta trabajando. Se va solo. */
    private void showDemo(int mode, int sub) {
        final View box = findViewById(R.id.demoBox);
        FrameLayout holder = findViewById(R.id.demoHolder);
        holder.removeAllViews();
        holder.addView(new com.pacco.animecut.view.ToolDemoView(this, mode, sub == 2),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        ((TextView) findViewById(R.id.demoName)).setText(toolInfo(mode, sub)[0]);
        box.setVisibility(View.VISIBLE);
        box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                box.setVisibility(View.GONE);
            }
        });
        if (hideDemo != null) box.removeCallbacks(hideDemo);
        hideDemo = new Runnable() {
            @Override
            public void run() {
                box.setVisibility(View.GONE);
                ((FrameLayout) findViewById(R.id.demoHolder)).removeAllViews();
            }
        };
        box.postDelayed(hideDemo, 4500);
    }

    private void tutorialPage(final int page) {
        final int[] modes = {CanvasView.MODE_BGERASE, CanvasView.MODE_MARKER, CanvasView.MODE_ZONE,
                CanvasView.MODE_PAN};
        final String[] titles = {"1. Saca el personaje", "2. Separa las partes",
                "3. Rellena lo de atras", "4. Exporta"};
        final String[] texts = {
                "Tu imagen queda en la capa \"imagen\". Con Borrar fondo pasas el pincel por el borde y "
                        + "solo se borra el fondo. En Capas puedes mirar sobre negro o verde para ver si quedo limpio.",
                "Separar: raya cada parte con un color (pelo, cara, ojos) y el fondo en gris, y toca el check "
                        + "verde. Cada parte sale en su capa. Tambien: Varita y en el cuadro punteado, Copiar a capa.",
                "Donde sacaste un ojo o un brazo, en la capa de atras queda el dibujo viejo. Marca esa zona en azul, "
                        + "toca esa capa en Capas y usa Zona tocando dentro de lo azul: queda con el color de alrededor.",
                "La flecha de abajo guarda un PNG por cada capa visible, todas del mismo tamano, "
                        + "listas para Alight Motion."
        };        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(titles[page]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        com.pacco.animecut.view.ToolDemoView art =
                new com.pacco.animecut.view.ToolDemoView(this, modes[page], false);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        TextView t = new TextView(this);
        t.setText(texts[page]);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(14f);
        root.addView(t);
        TextView foot = new TextView(this);
        foot.setText((page + 1) + " de 4    Manten pulsada cualquier herramienta para ver su ficha");
        foot.setTextColor(0xFF8A8A92);
        foot.setTextSize(11f);
        foot.setPadding(0, dp(10), 0, 0);
        root.addView(foot);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setView(root);
        if (page < 3) {
            b.setPositiveButton("Siguiente", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    tutorialPage(page + 1);
                }
            });
            b.setNegativeButton("Saltar", null);
        } else {
            b.setPositiveButton("Empezar", null);
        }
        b.show();
    }

    /** Tutorial: cuatro fichas con dibujo, una detras de otra. */
    private void guideDialog() {
        tutorialPage(0);
    }

    private void guideIfFirstTime() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("guia3", false)) return;
        sp.edit().putBoolean("guia3", true).apply();
        guideDialog();
    }

    private void projectDialog() {
        final boolean has = canvas.getProject() != null;
        final String[] items = {
                "Guardar proyecto en un archivo",
                "Abrir un proyecto guardado",
                "Guardar ahora en la app"
        };
        new AlertDialog.Builder(this)
                .setTitle("Proyecto")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 1) {
                            openProject.launch(new String[]{"*/*"});
                            return;
                        }
                        if (!has) {
                            toast("Abre una imagen primero");
                            return;
                        }
                        if (i == 0) createProject.launch("proyecto.acut");
                        else autosave(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void saveProjectTo(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int color = canvas.getColor();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    ProjectIO.save(os, p, color);
                    if (os != null) os.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al guardar: " + lastError);
                else toast("Proyecto guardado con sus " + p.layers.size() + " capas");
            }
        });
    }

    private void openProjectFrom(final Uri uri) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    loaded = ProjectIO.load(is);
                    if (is != null) is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void recoverFrom(final File f) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileInputStream is = new FileInputStream(f);
                    loaded = ProjectIO.load(is);
                    is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    /** Mantiene la proporcion para que todas las capas sigan cuadrando entre si. */
    private int[] longSide(Project p, int target) {
        int max = Math.max(p.w, p.h);
        if (max <= target) return new int[]{p.w, p.h};
        float f = target / (float) max;
        return new int[]{Math.max(1, Math.round(p.w * f)), Math.max(1, Math.round(p.h * f))};
    }

    private int toolIcon(int mode) {
        switch (mode) {
            case CanvasView.MODE_LASSO: return R.drawable.ic_lasso;
            case CanvasView.MODE_SCISSORS: return R.drawable.ic_scissors;
            case CanvasView.MODE_BRUSH: return R.drawable.ic_brush;
            case CanvasView.MODE_ERASER: return R.drawable.ic_eraser;
            case CanvasView.MODE_PAINT: return R.drawable.ic_paint;
            case CanvasView.MODE_BUCKET: return R.drawable.ic_bucket;
            case CanvasView.MODE_PICKER: return R.drawable.ic_picker;
            case CanvasView.MODE_CLONE: return R.drawable.ic_clone;
            case CanvasView.MODE_MOVE: return R.drawable.ic_move;
            case CanvasView.MODE_PAN: return R.drawable.ic_hand;
            case CanvasView.MODE_BGERASE: return R.drawable.ic_bgerase;
            case CanvasView.MODE_MARKER: return R.drawable.ic_marker;
            case CanvasView.MODE_MAGNET: return R.drawable.ic_magnet;
            case CanvasView.MODE_LINE: return R.drawable.ic_line_cont;
            case CanvasView.MODE_ZONE: return R.drawable.ic_zone;
            case CanvasView.MODE_PATCH: return R.drawable.ic_patch_fill;
            case CanvasView.MODE_HEAL: return R.drawable.ic_heal;
            case CanvasView.MODE_TONE: return R.drawable.ic_tone;
            default: return R.drawable.ic_wand;
        }
    }

    private void fillRow(LinearLayout row, int used, int cols) {
        for (int k = used; k < cols; k++) {
            View v = new View(this);
            v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
            row.addView(v);
        }
    }

    private void closeTools() {
        findViewById(R.id.toolPanel).setVisibility(View.GONE);
        findViewById(R.id.toolScrim).setVisibility(View.GONE);
        FrameLayout.LayoutParams l = (FrameLayout.LayoutParams) findViewById(R.id.toolPanel).getLayoutParams();
        l.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        findViewById(R.id.toolPanel).setLayoutParams(l);
    }

    private ImageButton iconButton(int icon, final String name, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setImageResource(icon);
        b.setContentDescription(name);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                toast(name);
                return true;
            }
        });
        return b;
    }

    private ImageView thumb(Bitmap b) {
        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageBitmap(b);
        return img;
    }

    private TextView rowText(String name, String sub, boolean bright) {
        TextView t = new TextView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(10);
        t.setLayoutParams(lp);
        t.setText(name + "\n" + sub);
        t.setTextColor(bright ? 0xFFFFFFFF : 0xFF7A7A7A);
        t.setTextSize(13f);
        return t;
    }

    private LinearLayout rowBase(boolean on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);
        return row;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void click(int id, final Runnable r) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
    }

    private boolean needProject() {
        if (canvas.getProject() == null) {
            toast("Abre una imagen primero");
            return false;
        }
        return true;
    }

    /** Marca en azul lo que esta activado, para que se vea sin leer nada. */
    private void toggle(int id, boolean on) {
        findViewById(id).setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
    }

    private boolean sliderIsTolerance() {
        int m = canvas.getMode();
        return m == CanvasView.MODE_WAND || m == CanvasView.MODE_BUCKET;
    }

    private void applySlider(int v) {
        if (sliderIsTolerance()) {
            canvas.setTolerance(v);
            sliderLabel.setText(String.valueOf(v));
        } else {
            float t = v / 120f;
            float size = 1f + t * t * 299f;
            canvas.setBrushSize(size);
            sliderLabel.setText(String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
            ((TextView) findViewById(R.id.btnSize)).setText(
                    String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void syncSlider() {
        if (sliderIsTolerance()) {
            slider.setProgress(canvas.getTolerance());
            sliderLabel.setText(String.valueOf(canvas.getTolerance()));
        } else {
            float t = (float) Math.sqrt(Math.max(0f, (canvas.getBrushSize() - 1f) / 299f));
            slider.setProgress(Math.round(t * 120f));
            float size = canvas.getBrushSize();
            sliderLabel.setText(String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void measureBars() {
        final View top = findViewById(R.id.topBar);
        final View bottom = findViewById(R.id.bottomPanel);
        top.post(new Runnable() {
            @Override
            public void run() {
                canvas.setInsets(top.getHeight() + dp(12), bottom.getHeight());
                if (canvas.getProject() != null) canvas.fit();
            }
        });
    }

    /** Para no repetir los tres metodos del SeekBar en cada dialogo. */
    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }
}
