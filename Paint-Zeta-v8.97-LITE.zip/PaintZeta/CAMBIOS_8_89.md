# Paint Zeta v8.89 — Herramienta nueva: Recortar

Donde: Herramientas > "MARCAR Y AJUSTAR" > Recortar.

- Cuadro sobre la imagen: esquinas y lados para cambiarlo, arrastrar adentro para moverlo.
  Afuera se oscurece, cuadricula de tercios y arriba la medida en vivo (por ejemplo 960 x 1187).
- Abajo: Proporcion · Resolucion · Girar · Voltear · Tamano · Ampliar lienzo · Cuadro de nuevo · Check.
- Proporcion: Libre, 1:1, 4:5, 3:4, 2:3, 9:16, 5:4, 4:3, 3:2, 16:9 y Personalizado (ancho x alto).
  Con proporcion fija se usan las esquinas.
- Resolucion final: 1080x1080, 1080x1350, 1080x1920, 1920x1080, 800x600, 600x800, 1200x1600,
  1600x1200 o Personalizado. Al recortar la imagen sale exactamente de esa medida.
- Tamano: cambia toda la imagen por porcentaje (25, 50, 75, 150, 200 %) o ancho x alto, con
  "Mantener la forma".
- Recortar, Tamano, Girar y Voltear cambian TODAS las capas y se pueden deshacer.
  Antes, Girar y Voltear borraban todo el historial de Deshacer: ya no.
- "Ampliar lienzo" se paso aqui (ya no esta en los 3 puntos, para no repetir).
