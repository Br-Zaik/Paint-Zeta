# Paint Zeta v8.95 — Marcar con todo abajo (nada tapa la imagen), formas guardadas, lupa y números con diseños

## Nada sale en el medio
- Todos los ajustes de Marcar (Destacar, Tapar, Lupa, Numeros, Flechas) estan ahora abajo, como
  en iMarkup: una tira (barrita, colores o formas), la fila de opciones y la fila de tipos.
- Ya no hay ventana flotante encima de la imagen: lo que cambias se ve al instante.
- Fila de abajo: X · Texto · Destacar · Tapar · Lupa · Numeros · Flechas · check.
  - Check: pinta las marcas y vuelve a la herramienta de antes.
  - X: sale sin ponerlas. Si hay marcas sin pintar, avisa y hay que tocar la X otra vez.
  - Atras: pinta las marcas y sale.
- Con una marca elegida aparecen Copiar, Mover (flechas para moverla poquito a poquito) y Quitar.
- Color y tamano propios de Marcar: la paleta con gotero y la barrita de grosor estan en el mismo
  panel. Ya no dependen de la barra del pincel.

## Escribir texto
- Mientras escribes solo hay una X y un check arriba. Ya no se arma un panel que despues tapa el
  teclado.
- Al tocar el check (o cerrar el teclado) sale abajo Estilo · Borde · Ajustar.

## Tapar (mosaico, borroso, color)
- Linea entrecortada blanca y negra con la forma exacta: se ve donde tapa aunque el mosaico casi
  no se note. Al pintar las marcas, la linea no queda.
- Cambiar la forma se ve al instante (antes el panel lo tapaba).

## Formas guardadas (Destacar, Tapar y Lupa)
- Elige "A mano", rodea tu forma con el dedo y tocala: sale "Guardar".
- La forma queda en la lista de formas para usarla cuando quieras, a cualquier tamano.
- Se guardan hasta 12. Mantener apretada una forma tuya la borra de la lista.

## Lupa
- Formas: circulo, cuadro, redondeado, corazon, estrella y las guardadas.
- Aumento de 1.25x a 6x con barrita, grosor del borde (0 = sin borde) y color.

## Numeros
- Disenos: circulo, cuadro, redondeado, gota y rombo. Estilo: relleno o solo borde.
- Contorno: sin, automatico o el color que elijas.
- Si quitas un numero, los que siguen bajan uno. Asi no queda un hueco (1, 2, 3...).

## Recortar
- Arreglado: al probar varias proporciones seguidas el cuadro se achicaba cada vez. Ahora cada
  proporcion pone el cuadro mas grande que entra en la imagen.
- Resolucion y Cambiar tamano van en una tira abajo (botones). Solo "Otra..." y "Medida..." abren
  el teclado para escribir numeros.

## Revision
- Revisado con el compilador de Java sobre todo el codigo; solo faltan las piezas de Android, como
  siempre. No probado en un telefono.
