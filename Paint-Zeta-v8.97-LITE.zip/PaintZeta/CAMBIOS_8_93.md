# Paint Zeta v8.93 — Marcar como iMarkup: texto completo, flechas y formas, recorte con forma

Incluye todo lo de la 8.92.

## Botones de la marca elegida (todas las marcas)
- X roja (arriba a la izquierda): quita la marca.
- +1 verde (abajo a la izquierda): hace una copia un poco corrida. En Numeros, la copia lleva el
  numero siguiente.
- Se quito el boton de basurero de la barra, porque ahora esta la X en la misma marca.

## Texto
- Punto verde (abajo a la derecha): gira y agranda a la vez, con un solo dedo. Se engancha derecho.
- Punto del lado derecho: el ancho. Las palabras bajan solas a la linea siguiente.
- Ajustes nuevos:
  - Tamano y opacidad.
  - Formato: normal, negrita, cursiva o las dos.
  - Alineado: izquierda, centro o derecha.
  - Contorno: no, automatico o un color, con su grosor.
  - Fondo: no, el color del texto o un color, con su opacidad.
  - Sombra: no, suave o fuerte.
- Los estilos rapidos (Normal, Meme, Con fondo) siguen y ponen esos ajustes de un toque.
- El texto nuevo sale con el estilo del ultimo texto que tocaste.

## Flechas (nuevo en Marcar)
- Formas: flecha, flecha doble, flecha a mano (curva, la punta sigue el trazo), lapiz, linea,
  cuadro y circulo (solo el borde).
- Flecha, doble y linea: se estiran desde sus dos puntas azules. Se enganchan derechas, de pie o
  en diagonal.
- Grosor: la barra de tamano de abajo. Al moverla cambia la flecha elegida. Color: el de abajo.
- Opacidad y "Borde" (un contorno que contrasta, para que se vea sobre cualquier fondo).
- Todas quedan editables hasta el check, igual que las demas marcas.
- La barra de tamano tambien cambia el numero elegido en Numeros.

## Recortar: forma
- Boton nuevo "Forma": cuadro, circulo, redondeado, triangulo, corazon y estrella.
- Se ve la forma dentro del cuadro. Al aplicar, lo de afuera de la forma queda transparente en
  todas las capas. Deshacer lo devuelve.
- Para que se vea transparente, guarda en PNG.

## Revision
- Revisado con el compilador de Java sobre todo el codigo; solo faltan las piezas de Android, como
  siempre. No probado en un telefono.
