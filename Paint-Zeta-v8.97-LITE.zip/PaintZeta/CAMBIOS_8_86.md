# Paint Zeta v8.86 — Arreglos del analisis de futuras fallas

## Toques rapidos y dobles
- Galeria: un doble toque ya no abre dos veces la misma obra (antes, la de abajo quedaba vieja y
  podia pisar lo nuevo al guardar). Igual con "Acerca de".
- Girar 90°, Quitar fondo con marcas, Separar partes, Rellenar hueco, Unir lineas, Refinar borde,
  Agrandar seleccion, Borde, Filtros de seleccion, Luz de borde, Degradado, Sugerir zonas,
  Lineas automaticas y Colorear por zonas: si ya se esta aplicando algo, el segundo toque solo
  avisa "Espera". Ya no se aplica dos veces ni se borra el historial dos veces.
- Efectos: un doble toque en Aceptar ya no crea dos capas.

## Imagenes grandes
- Tope de la obra: 24 millones de puntos (por ejemplo 6000 x 4000). Android no deja dibujar en
  pantalla imagenes de mas de unos 26 millones de puntos: Mover se cerraba y Transformar o
  Marioneta se cancelaban. Aplica al abrir, a Mejorar imagen x2/x4 y a Ampliar lienzo.
- Telefonos de gama media: pueden abrir hasta ese tope (antes 16 millones).
- Mover: en capas enormes la copia que se ve al arrastrar es mas chica (fluida y sin cierre).
  Al soltar se aplica la capa real, igual que antes.
- Agregar imagen: si queda poca memoria libre en el telefono avisa en vez de arriesgar un cierre,
  y antes de agregar guarda la obra.

## Colorear
- Al tocar una parte, los pedazos vecinos del mismo color solo se repintan si su medida cambia de
  verdad (toques mas rapidos). La busqueda de pedazos que se tocan es mas rapida con muchas zonas.
- El resultado es el mismo que en 8.85 (comprobado en computadora, imagen identica).
- Probado tambien con papel gris y sucio: el Acabado sigue poniendo su sombra normal.

## Sistema
- Letra grande del telefono: la de la app crece solo hasta 115% (botones sin textos cortados).
- Galeria: el boton Atras para salir de "seleccionar" usa la forma nueva de Android.
- Copia de seguridad de Google: ya no incluye los modelos de IA (con ellos se pasaba el limite y no
  se copiaba nada). Las obras y ajustes si se copian. Los modelos se vuelven a bajar o copiar solos.
- Version para Google Play: si falta la llave de subida, la compilacion se detiene con un mensaje
  (antes salia firmada con la llave de prueba sin avisar). El APK de prueba no cambia.

## Interfaz
- Figuras, Curva y Polilinea ya no se repiten en Herramientas: estan en el boton Figuras de arriba.

## Lo que no se cambio (a proposito)
- Guardado en su propio carril: guardar y girar/efectos no deben correr a la vez sobre la misma obra;
  separarlos podria dejar una obra guardada a medias.
- Armado nuevo de la app (plugin de Android mas nuevo): necesita cambiar tambien el archivo de
  GitHub y no se puede comprobar aqui.
- Proteccion del codigo (R8) para Play: hay que probarla con la version de Play en un telefono.
- Llave de prueba: cambiarla obliga a desinstalar. Mejor dejar el repositorio de GitHub privado.

## Comprobacion
- Revisado con el compilador de Java contra 8.85: solo aparecen los avisos de las piezas de Android
  que no existen en la computadora. Colorear y Acabado probados en computadora.
- No se compilo el APK ni se probo en telefono.
