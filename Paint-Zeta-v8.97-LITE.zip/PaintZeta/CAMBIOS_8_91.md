# Paint Zeta v8.91 — Revision a fondo de Marcar, Recortar y Guardar

## Fallos que se encontraron y se arreglaron
- Tapar con Borroso sobre una parte grande podia cerrar la app por memoria (se armaban 4 copias
  grandes de la imagen). Ahora el borroso se hace en una copia chica y se agranda suave: casi igual,
  de 16 a 100 veces menos memoria y tiempo (0,05 s en la prueba).
- Destacar, Tapar y Lupa se pintaban en el hilo de la pantalla: con imagenes grandes la pantalla
  se trababa un momento. Ahora se pintan en segundo plano (la pantalla sigue fluida).
- Un texto muy grande que salia de la imagen armaba un dibujo enorme (podia faltar memoria).
  Ahora solo se arma lo que cae dentro, y el tamano tiene tope.
- Si cambiabas el color o el estilo justo mientras se pintaba una marca, podia mezclarse. Ahora
  cada marca guarda sus ajustes al pintarse.
- El primer Destacar copiaba una capa vacia entera para Deshacer (memoria de mas). Ya no.
- Girar, Voltear y Ampliar lienzo dejaban las zonas de "1 Color" en el lugar viejo (el Acabado
  salia corrido). Ahora giran, se voltean y se corren junto con el dibujo; Recortar tambien.
- Recortar con el lienzo girado con dos dedos se dibujaba torcido. Ya no.
- Recortar y Tamano: si falta memoria ahora avisa (antes no decia nada). Lo pesado de cambiar
  el tamano tambien paso a segundo plano.
- Peso maximo al guardar: si ni con calidad baja entra, ahora calcula de una vez cuanto achicar
  (antes probaba muchas veces: mas lento).

## Mas fluido
- El texto ya no se vuelve a armar en cada cuadro mientras lo mueves o giras.
- Tapar con el dedo ya no rehace el contorno en cada cuadro.

## Comprobacion
- Cuadritos, borroso y lupa probados en computadora con tu imagen.
- Revisado con el compilador de Java contra 8.90 (solo avisos de piezas de Android).
- No se compilo el APK ni se probo en telefono.
