# Paint Zeta v8.94 — Texto como iMarkup, flechas completas, mosaico con formas, Recortar ordenado

## Arreglado: pantalla negra en Recortar (grave)
- Al entrar a Recortar la imagen se achicaba para dejar lugar alrededor, pero la pantalla quedaba
  marcada como "no lista" y no se dibujaba nada. Venia de la 8.92. Ya no pasa.
- Al salir de Recortar la imagen vuelve a su tamano normal en la pantalla.

## Texto (rehecho como iMarkup)
- Se escribe directo sobre la imagen con el teclado del telefono.
  - Sale "Escribe algo" transparente y la imagen se oscurece un poco.
  - Lo que escribes se ve en vivo, con su color y su contorno.
  - Ya no hay ventana con fondo.
  - Si tocas abajo, el texto sube para que el teclado no lo tape.
  - Tocar afuera o Atras cierra el teclado. Tocar el texto otra vez lo vuelve a abrir.
- Panel abajo (tapa la barra de siempre mientras editas): X · Estilo · Borde · Ajustar · check.
  - X: deja el texto como estaba (si era nuevo, lo quita).
  - Check: listo con ese texto. Sigue editable hasta el check de Marcar.
- Estilo: cada icono abre una sola tira encima.
  - Rapido: Normal, Meme, Con fondo, Sombra, Brillo y Etiqueta.
  - Letra: 13 letras del telefono, con vista "Aa".
  - Tamano.
  - Formato: izquierda, centro, derecha, negrita, cursiva y subrayado (nuevo).
  - Color: opacidad, paleta y gotero.
  - Fondo: opacidad, paleta, "sin" y "Texto" (fondo del color y letra que contrasta).
  - Contorno: grosor, paleta, "sin" y "Auto".
  - Sombra: difuminado, distancia, paleta, "sin" y "Brillo" (sombra del mismo color = brillo).
- Borde: grosor, color y 9 bordes o globos: sin borde, cuadro, pildora, ovalo, explosion, globo
  de dialogo, nube de pensamiento, etiqueta y senalar. Si no hay fondo, el globo va blanco.
- Ajustar: espacio entre letras, entre lineas y giro exacto.
- Siguen los puntos de antes: X, +1, girar y agrandar, y ancho.

## Flechas
- Nueva: "Se ensancha" (fina al inicio y gruesa con punta grande).
- Tamano de la punta y grosor del inicio, aparte del grosor de la linea (la barra de abajo).
- Punta: triangulo, abierta (V) o redonda.
- Linea continua o punteada. Cuadro y circulo: solo borde o con relleno.
- La X va atras del inicio de la flecha y las puntas azules la estiran.
- Con una marca elegida, la barra muestra copiar y mover ← → ↑ ↓. Si lo mantienes apretado, se
  sigue moviendo.

## Tapar (cuadritos, borroso, color) y Destacar
- Formas con iconos:
  - Tapar: cuadro, circulo, redondeado, triangulo, corazon, estrella, a mano y con el dedo.
  - Destacar: las mismas formas, menos con el dedo.

## Recortar ordenado (como iMarkup)
- Panel abajo: X · Proporcion · Forma · Girar · Tamano · check.
  - Proporcion: iconos con la forma (Libre, 1:1, 4:5, 3:4, 2:3, 9:16, 5:4, 4:3, 3:2, 16:9, Otra).
    Ya no hay ventana gris en el medio.
  - Forma: cuadro, circulo, redondeado, triangulo, corazon y estrella.
  - Girar: izquierda, derecha, voltear horizontal y vertical.
  - Tamano: resolucion final, cambiar tamano y "cuadro nuevo" (icono propio, no el de deshacer).
- X o Atras: sale sin recortar. Check: recorta y vuelve a la herramienta de antes.

## Letras
- Se usan las letras que ya trae el telefono. No se agregaron archivos.
- Para letras de meme (tipo Bangers o Anton): se pueden agregar archivos de letras libres (OFL)
  o bajarlas de Google Fonts mas adelante.

## Revision
- Revisado con el compilador de Java sobre todo el codigo; solo faltan las piezas de Android, como
  siempre. No probado en un telefono.
