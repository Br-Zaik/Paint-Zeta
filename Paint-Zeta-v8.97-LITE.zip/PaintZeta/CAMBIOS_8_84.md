# Paint Zeta v8.84 — Acabado sin manchas (capa en Blanco y negro) y panel mas simple

Incluye todo lo de la 8.73 a la 8.83. Sale de las 6 capturas de la prueba de la 8.83.

## 1. La causa de las manchas del Acabado
- La imagen de abajo es a color y se pinta con el "Blanco y negro" de la capa prendido.
- El Acabado (y el balde) leian los pixeles de abajo SIN el Blanco y negro: veian la imagen a
  color aunque en pantalla se viera gris. El Acabado creia que la obra ya estaba coloreada y
  mezclaba ese color escondido con el color pintado: por eso salia piel "original" en unas
  partes y parches grises, rosados o rojos en otras.
- Ahora todas las herramientas que miran las capas de abajo (Acabado, Colorear, balde con
  referencia) leen lo mismo que se ve en pantalla, con el Blanco y negro o el cambio de color
  de la capa. Con la capa en gris, el Acabado trabaja solo con el color pintado y la luz llega
  pareja a toda la parte.
- Si la capa de abajo se ve a color (sin Blanco y negro), todo sigue como antes.

## 2. Las partes que "ya tienen ese color" pero se ven grises (paso 1)
- Eran restos del acabado viejo (con las manchas). Para limpiarlos: entra a "2 Acabado" y
  acepta con el check: se vuelve a calcular todo con el arreglo.

## 3. Panel de Acabado mas simple
- Arriba, en amarillo, dice que hacer: "Arrastra el ☀ sobre el dibujo: la luz viene de ahi".
- Luz: Dia, Tarde, Atardecer, Luna llena, Media luna, Interior (aqui se elige la luna).
- Estilo: Manhwa o Anime.
- Fuerza.
- Abajo: Antes · Mas · ✕ · ✓.
- "Mas" guarda lo avanzado, con titulos:
  - Retocar con el dedo: Mover sol, Sombra +, Luz +, Quitar mancha y deshacer retoque.
  - Tela: Brillante y Estampado.
  - Extras: Puntas del pelo, ＋ Otra luz (un segundo sol o una luna), − Quitar esa luz,
    Lineas de color o negras.
- Al cerrar "Mas", el dedo vuelve a mover el sol.

## Pruebas en PC
- Misma imagen, mismas zonas: leyendo el color escondido (como en la 8.83) salen los parches
  grises; leyendo el gris que se ve (8.84) la piel queda pareja. Imagen:
  prueba_8_84_acabado_bn.png.

## No se pudo probar aqui
- El panel nuevo (necesita Android).
