# Paint Zeta v8.92 — Marcar editable, Lienzo a tu gusto y Comprimir fotos

## Marcar (Texto, Destacar, Tapar, Lupa, Numeros)
- Cada marca queda editable hasta que tocas el check o sales de Marcar: tocala para elegirla y
  moverla, cambiarle el tamano (esquina) o los ajustes. Puedes poner varias antes de aplicar.
- El color de abajo cambia la marca elegida: el borde de la lupa, el texto o el numero toman el
  color nuevo al instante.
- Formas nuevas:
  - Destacar: circulo, cuadro, redondeado y a mano.
  - Tapar: cuadro, circulo, a mano (rodear) y con el dedo.
- Numeros mas grandes (en proporcion a la imagen) y se pueden mover y agrandar despues.
- Varias marcas de Destacar se juntan en un solo oscuro con varios huecos.
- Nuevo boton para quitar la marca elegida. Deshacer quita la marca elegida o la ultima.
- El check pinta todas juntas, en segundo plano, con un solo paso de Deshacer.
- Si otro trabajo estaba en curso al salir de Marcar, las marcas se pintan apenas termine.

## Paneles de ajustes
- El panel de ajustes de las herramientas de abajo sale encima del boton y ya no tapa las barras
  de tamano y color.

## Recortar y Lienzo
- Voltear tiene dos botones directos: izquierda-derecha y arriba-abajo. Ya no hay ventana que
  pregunte. Para girar sigue el boton de girar.
- Lienzo a tu gusto: arrastra un lado o una esquina hacia afuera para agregar espacio de ese lado.
  - El espacio nuevo se ve con cuadritos (transparente).
  - Los bordes se pegan solos al borde de la imagen.
  - La medida se ve arriba con "(+ espacio)".
  - Hacia adentro recorta, como antes.
- Al entrar a Recortar la imagen se ve un poco mas chica, para tener lugar alrededor.
- Se quito el boton de la ventana de Ampliar lienzo, porque ahora se hace con el cuadro.

## Guardar imagen: "Para"
- Un toque para WhatsApp, Instagram, Historias, Facebook, Correo o X. Cada uno pone la medida,
  el formato JPG, la calidad y el peso maximo.

## Comprimir fotos (nuevo, en la pantalla de obras)
- Boton nuevo arriba. Eliges una o varias fotos del telefono y para que app son.
- Opciones: WhatsApp, Instagram, Historias, Facebook, Correo, X, Muy liviano y Misma medida.
- Salen en JPG en Imagenes > Paint Zeta > Comprimidas. Las fotos originales no se tocan.
- Al final muestra cuanto pesaban antes y cuanto pesan ahora, y se pueden compartir todas juntas.
- Se quitan los datos ocultos de la foto (lugar y telefono). Todo pasa en el telefono, sin internet.
- Si una foto ya era mas liviana, no se hace una copia mas pesada.

## Medidas usadas
| Para | Medida | Calidad | Peso maximo |
|---|---|---|---|
| WhatsApp | lado largo 1600 | 85 | 500 kB |
| Instagram | 1080 de ancho | 90 | — |
| Historias, Reels y TikTok | entra en 1080 x 1920 | 90 | — |
| Facebook | lado largo 2048 | 88 | — |
| Correo | lado largo 1920 | 80 | 500 kB |
| X | lado largo 1600 | 88 | — |
| Muy liviano | lado largo 1280 | 75 | 200 kB |

Nunca se agranda una imagen chica.

## Revision
- Revisado con el compilador de Java sobre todo el codigo; solo faltan las piezas de Android, como
  siempre. No probado en un telefono.
