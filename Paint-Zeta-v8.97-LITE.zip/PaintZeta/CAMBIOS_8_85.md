# Paint Zeta v8.85 — Colorear y Acabado a fondo

Problema: en un dibujo que ya trae sus sombras (grises), el Acabado ponía encima otra sombra
inventada, con forma de mancha, y dejaba el color pálido. Además en "1 Color" quedaban pedazos
lisos y pedazos grises sin color.

## 1 Color
- Un gris oscuro ancho del dibujo es sombra: toma el color de sombra (antes quedaba gris).
- La misma parte pintada en varios toques usa una sola medida de claro y oscuro: ya no queda un
  pedazo liso al lado de otro con sombra. Al pintar un pedazo nuevo, los pedazos vecinos del mismo
  color se repintan solos para quedar parejos.

## 2 Acabado
- Si el dibujo ya trae sombras, el Acabado las sigue: les da color (base, sombra, sombra profunda)
  enteras y parejas. No se inventa otra sombra encima.
- El sol es un degradado ancho y suave que cruza toda la figura: luz del lado del sol y un poco más
  de sombra del otro lado. Sin bordes duros ni cuadros.
- Qué es línea se mide mejor: algo fino y más oscuro que su alrededor. Una sombra ancha ya no sale
  a medias como línea (eso hacía los cortes cuadrados).
- Sombra + y Luz + con el dedo siguen funcionando, también suaves.
- En dibujos de solo líneas (sin grises) el Acabado trabaja como antes.

## Comprobación
- Probado en computadora con la ilustración del gimnasio en gris, pintando la piel a toques como
  en la app, con sol a la izquierda y a la derecha, en Manhwa y Anime, y con un dibujo de solo líneas.
- El código se revisó con el compilador de Java contra la versión anterior (mismos avisos, solo
  los de Android que faltan en la computadora). No se compiló el APK ni se probó en teléfono.
