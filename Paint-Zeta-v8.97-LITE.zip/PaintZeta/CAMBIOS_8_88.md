# Paint Zeta v8.88 — Herramienta nueva: Marcar (memes y guias)

Donde: Herramientas > seccion nueva "MARCAR Y AJUSTAR" > Marcar.
Abajo salen 5 iconos: Texto · Destacar · Tapar · Lupa · Numeros, mas Ajustes y Check.
Todo se pinta en la capa "Marcas" (se crea sola arriba de todo): el dibujo no se toca.
Deshacer quita la marca. Tocar afuera de la marca tambien la pinta (como Figuras).

## Texto
- Toca la imagen donde va el texto: sale el teclado. Escribe y "Listo".
- Muevelo con el dedo. Esquina: mas grande o mas chico. Punto verde: girar (se engancha derecho).
- Tocar el texto lo deja cambiar o quitar.
- Ajustes: Estilo Normal / Meme (borde que contrasta) / Con fondo; 6 letras del telefono
  (Normal, Gruesa, Angosta, Clasica, A mano, Maquina). El color es el de abajo. Varias lineas.

## Destacar
- Arrastra sobre lo importante: todo lo demas se oscurece (borde suave).
- Ajustes: Circulo / Cuadro / A mano (rodea con el dedo) y cuanto oscuro (5 a 95 %).

## Tapar
- Arrastra un cuadro sobre lo que quieres tapar, o "Con el dedo" (grosor = barra de abajo).
- Cuadritos, Borroso o Color (el de abajo), con Fuerza. Se ve tapado mientras eliges.

## Lupa
- Arrastra o toca: un circulo muestra esa parte agrandada (1.5x, 2x, 3x o 4x), con borde del
  color de abajo. Esquina: tamano.

## Numeros
- Cada toque pone 1, 2, 3... (circulo del color de abajo con borde). Tamano = barra de abajo.
- Ajustes: -1, Volver a 1, +1.

## Comprobacion
- Cuadritos, borroso y lupa probados en computadora con tu imagen (rapidos: menos de 0,1 s).
- Revisado con el compilador de Java contra 8.87 (solo avisos de piezas de Android).
- No se compilo el APK ni se probo en telefono.
