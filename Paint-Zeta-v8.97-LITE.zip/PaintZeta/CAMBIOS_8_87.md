# Paint Zeta v8.87 — Lo que faltaba: armado nuevo, R8, Android 10, presion del lapiz, extrusion con perspectiva

## IMPORTANTE: cambiar UNA vez el archivo de GitHub
Para usar lo nuevo del armado, en tu repositorio de GitHub reemplaza el archivo
`.github/workflows/build.yml` por el que viene dentro de este ZIP (misma ruta).
- Si no lo cambias, el ZIP igual compila como siempre (con el armado de antes).
- Con el archivo nuevo: Gradle 8.13 y plugin de Android 8.13.2 (hecho para Android 16). Si el
  plugin nuevo fallara, se vuelve a compilar solo con el de antes y el APK sale igual.
- Con el archivo nuevo salen dos APK: "Paint-Zeta-APK" (el de siempre) y "Paint-Zeta-R8-prueba-APK".

## R8 (codigo encogido y protegido)
- La version para Google Play sale con R8: app mas liviana y codigo dificil de copiar.
- "Paint-Zeta-R8-prueba.apk" es igual a la de Play pero con la llave de prueba: instalala encima y
  prueba sobre todo Recortar con IA y Mejorar imagen. Si algo falla ahi, avisa antes de subir a Play.
- La IA (ONNX Runtime) tiene sus reglas para que R8 no la rompa.

## Android 10 o mas
- La app ahora pide Android 10 como minimo (antes Android 8). Los telefonos con Android 8 y 9 ya
  casi no se usan. Asi la Marioneta fluida y la exportacion directa funcionan siempre.

## Presion del lapiz (fluidez parte 2)
- Con lapiz (S Pen u otro), apretar mas hace el trazo mas grueso: de 20% a 100% del tamano elegido.
  Funciona en Pintar y Goma, con puntas, estabilizador y "Al soltar".
- Se apaga en Mas opciones > Vista > "Presion del lapiz". Con el dedo no cambia nada.

## Pantalla mas fluida
- El lienzo y el zoom nitido se escriben en la pantalla por bloques de filas (antes fila por fila):
  menos trabajo en cada trazo.

## Guardado y agregar imagen
- Leer una imagen para agregarla ya no espera detras del guardado automatico (carril aparte).
  Lo que cambia la obra sigue en el mismo carril que el guardado (seguro).

## Efectos > Extrusion con perspectiva
- Nuevo ajuste "Perspectiva" (en Mas): 0 = como antes (paralela). Al subirlo, la parte de atras se
  achica hacia un punto de fuga, como letras 3D. 100% = la parte de atras queda al 30%.
- Rapida: las copias se juntan de a mitades (unas 12 pasadas aunque sean miles de copias).

## Lo que queda para otra version
- App en ingles: son unos 1700 textos; se hace aparte y completa (una app a medio traducir confunde).
- Pantalla especial para tablet: hace falta ver capturas en una tablet para saber que ajustar.
- Envio a pantalla por pedazos: con los telefonos de hoy la mejora es chica y el cambio es grande.

## Comprobacion
- Revisado con el compilador de Java contra 8.86: solo avisos de piezas de Android que no existen
  en la computadora. Extrusion con perspectiva probada en computadora (texto "ZETA", 0,3 s).
- No se compilo el APK ni se probo en telefono.
