# Paint Zeta v8.83 — Arreglos de la prueba en telefono (8.82)

Incluye todo lo de la 8.73 a la 8.82. Sale de las 12 capturas de la prueba.

## 1. La pregunta "Extraer las lineas" ya no sale encima del tutorial
- Primero sale la pregunta. Con "No" (o tocando afuera) recien sale el tutorial.
- Con "Si" se abre Filtros y el tutorial sale al cerrar Filtros (aplicando o no).
- Con "No volver a preguntar" sale el tutorial directo. El tutorial sigue saliendo una sola vez.

## 2. Blanco y negro de la capa: mismos ajustes que el de Borrar fondo, y abajo
- Panel ABAJO (ya no en el centro): la imagen queda libre para mirar, mover y hacer zoom
  mientras se ajusta.
- Ajustes: de que color sale el gris (Normal, Rojo, Verde, Azul), Saturacion, Contraste y Brillo.
- Botones: Ver color / Ver B/N (comparar), De fabrica, Apagar B/N y Listo. Atras = cancelar.
- Sigue sin tocar los pixeles: el color no se pierde y se puede apagar despues.
- Las obras guardadas con el B/N de antes se ven igual.

## 3. Acabado (Sol): ya no quedan parches sin acabado
Dos causas, las dos arregladas:
- Una misma parte pintada en varias veces (varios toques del mismo color, pegados) se trataba
  como pedazos separados, cada uno con su propio volumen: quedaban parches planos o de sombra.
  Ahora los pedazos del mismo color que se tocan comparten UN solo volumen.
- Lo retocado a mano con pincel o balde en la capa "Color zonas" (con el color de una zona)
  no era zona y el Acabado lo saltaba. Ahora tambien recibe el acabado y queda guardado como
  zona al aceptar. Otros detalles pintados a mano (brillos blancos, adornos de otro color)
  no se tocan.

## 4. Ajustes de figura un poco transparentes
- El panel de Contorno y Relleno deja ver la figura detras.

## 5. Blanco y negro + Marioneta / Transformar
- La capa con Blanco y negro se sigue viendo en blanco y negro mientras se usa Marioneta,
  Malla, Mover o Perspectiva (antes volvia a verse a color, como si se hubiera apagado).
- Cambiar de capa con Marioneta o Mover abiertos SIN haber movido nada ya no "aplica" nada:
  se cierra al instante (antes repintaba toda la capa y parecia pegado en
  "Aplicando transformacion...").

## 6. Marioneta mas fluida y nitida
- La imagen deformada ahora la dibuja la pantalla del telefono (la imagen como textura sobre
  la malla) en vez de calcularse pixel por pixel en cada movimiento: se ve nitida, no en
  cuadros, y el procesador queda libre para mover la malla.
- Funciona desde Android 10. En telefonos mas viejos, o con imagenes mas grandes que lo que
  aguanta la pantalla, sigue el metodo de antes.
- Si en algun telefono la imagen no se viera al mover: Marioneta > Opciones > apagar
  "Vista fluida" (vuelve al metodo de antes). Si el telefono da error, se apaga sola.
- Al aplicar, el resultado final se calcula igual que siempre (misma calidad).

## Pruebas en PC
- Blanco y negro: 6 pruebas OK (sin contraste ni canal es identico al de antes; gris total;
  lo que muestra Marioneta es igual a lo que queda en la capa; canales; luminancia).
- Acabado: retoque a mano de 1500 pixeles: 0 quedaron sin acabado; un brillo blanco pintado a
  mano quedo intacto. Imagen prueba_8_83_acabado_parches.png (antes y ahora con 6 pedazos del
  mismo color).

## No se pudo probar aqui (falta el telefono)
- El panel nuevo de Blanco y negro, el orden pregunta/tutorial y la Marioneta fluida dependen
  de Android. La Marioneta fluida es el cambio mas grande: por eso tiene interruptor.
