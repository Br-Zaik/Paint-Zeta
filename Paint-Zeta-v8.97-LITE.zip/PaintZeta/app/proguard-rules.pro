# v8.87 Reglas de R8 para Paint Zeta (version para Play y APK "r8prueba").
# La app no usa reflexion propia. ONNX Runtime (la IA) llama a sus clases Java desde su parte
# nativa: sus nombres no se pueden cambiar ni quitar.
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**
# Para que los errores guardados (Mas opciones > ultimo error) sigan mostrando donde fallo.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
