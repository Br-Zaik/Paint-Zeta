package com.pacco.animecut;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

/**
 * v8.96: todas las ventanas de opciones salen ABAJO (como una hoja que sube), con el mismo fondo
 * oscuro y poca sombra, para que la imagen se siga viendo arriba. Antes salian en el medio y
 * tapaban lo que estabas cambiando.
 */
final class SheetBuilder extends AlertDialog.Builder {

    SheetBuilder(Context c) {
        super(c, android.R.style.Theme_Material_Dialog_Alert);
    }

    @Override
    public AlertDialog create() {
        AlertDialog d = super.create();
        sheet(d);
        return d;
    }

    @Override
    public AlertDialog show() {
        AlertDialog d = create();
        d.show();
        Window w = d.getWindow();
        if (w != null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        return d;
    }

    /** Pone una ventana abajo, a lo ancho, con esquinas de arriba redondeadas. */
    static void sheet(Dialog d) {
        Window w = d.getWindow();
        if (w == null) return;
        float r = 18f * d.getContext().getResources().getDisplayMetrics().density;
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF202026);
        g.setCornerRadii(new float[]{r, r, r, r, 0f, 0f, 0f, 0f});
        w.setBackgroundDrawable(g);
        w.setGravity(Gravity.BOTTOM);
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        w.setDimAmount(0.25f);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        w.setWindowAnimations(android.R.style.Animation_InputMethod);
    }
}
