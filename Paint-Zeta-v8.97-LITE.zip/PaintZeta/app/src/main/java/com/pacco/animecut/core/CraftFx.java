package com.pacco.animecut.core;

import java.util.ArrayList;

/**
 * v8.82: bisel, extrusion, destellos en cruz, desenfoque de giro y mosaico. Java puro (pruebas
 * de PC). Bisel, extrusion y destellos devuelven solo el efecto (capa nueva); giro y mosaico
 * cambian la capa como los otros desenfoques.
 *
 * Trabajan por franjas como los demas filtros: (ox,oy) = donde empieza la franja dentro de la
 * imagen (fw x fh), s = escala (1 = tamano real).
 */
public final class CraftFx {
    private CraftFx() { }

    public static final int INNER = 0, OUTER = 1;
    private static final float INF = 1e12f;

    // ================================================================== bisel

    /**
     * Bisel: luz y sombra que siguen el borde de la forma (tambien sus huecos). v0 ancho (px),
     * v1 profundidad %, v2 direccion de la luz (grados, 0 = desde arriba, sentido del reloj),
     * v3 suavidad. Interior: dentro de la forma. Exterior: alrededor, por fuera.
     * Devuelve blanco (luz) y negro (sombra) con transparencia, para una capa normal encima.
     */
    static int[] bevel(int[] in, int w, int h, Fx.P p, float s, Fx.Job job) {
        int n = w * h;
        int[] out = new int[n];
        float wid = Math.max(1f, p.v[0] * s);
        float depth = Math.max(0, Math.min(100, p.v[1])) / 100f;
        if (depth <= 0f) return out;
        boolean outer = p.mode == OUTER;
        boolean[] inside = new boolean[n];
        boolean any = false, anyOut = false;
        for (int i = 0; i < n; i++) {
            inside[i] = (in[i] >>> 24) >= 128;
            if (inside[i]) any = true; else anyOut = true;
        }
        if (!any || !anyOut) return out;
        chk(job);
        float[] d = EdgeFx.edt(inside, w, h, outer);        // interior: distancia a lo de afuera
        chk(job);
        float[] hgt = new float[n];
        for (int i = 0; i < n; i++) {
            float dist = d[i] >= INF ? INF : (float) Math.sqrt(d[i]);
            if (!outer) hgt[i] = inside[i] ? Math.min(1f, dist / wid) : 0f;
            else hgt[i] = inside[i] ? 1f : Math.max(0f, 1f - (dist - 0.5f) / wid);
        }
        float soft = Math.max(0, Math.min(100, p.v[3])) / 100f;
        Fx.gaussPlaneF(hgt, new float[n], w, h, Math.max(0.7f, soft * wid * 0.5f));
        chk(job);
        double az = Math.toRadians(p.v[2]);
        float elev = (float) Math.toRadians(35);
        float lx = (float) (Math.sin(az) * Math.cos(elev)), ly = (float) (-Math.cos(az) * Math.cos(elev));
        float lz = (float) Math.sin(elev);
        float k = wid * depth * 1.6f;
        for (int y = 0; y < h; y++) {
            int ym = Math.max(0, y - 1) * w, yp = Math.min(h - 1, y + 1) * w, row = y * w;
            for (int x = 0; x < w; x++) {
                int i = row + x;
                float a = (in[i] >>> 24) / 255f;
                float m = outer ? 1f - a : a;
                if (m <= 0f) continue;
                float gx = (hgt[row + Math.min(w - 1, x + 1)] - hgt[row + Math.max(0, x - 1)]) * 0.5f;
                float gy = (hgt[yp + x] - hgt[ym + x]) * 0.5f;
                if (gx == 0f && gy == 0f) continue;
                float nx = -gx * k, ny = -gy * k;
                float inv = 1f / (float) Math.sqrt(nx * nx + ny * ny + 1f);
                float sh = (nx * lx + ny * ly + lz) * inv - lz;   // 0 = plano
                float al = Math.min(1f, Math.abs(sh) * 2.4f) * m;
                if (al <= 0.003f) continue;
                int a8 = Math.min(255, (int) (al * 255f + .5f));
                out[i] = (a8 << 24) | (sh > 0 ? 0xFFFFFF : 0x000000);
            }
        }
        return out;
    }

    // ================================================================== extrusion

    /**
     * Extrusion paralela: copias de la forma corridas en una direccion, unidas (sin huecos
     * entre copias). v0 largo (px), v1 angulo (grados, 0 = derecha, 90 = abajo), v2 opacidad %,
     * v3 sombreado (lo lejano mas oscuro). Va DEBAJO del dibujo: la forma queda delante.
     */
    static int[] extrude(int[] in, int w, int h, Fx.P p, float s, Fx.Job job) {
        int n = w * h;
        int[] out = new int[n];
        int len = Math.round(p.v[0] * s);
        float op = Math.max(0, Math.min(100, p.v[2])) / 100f * ((p.color >>> 24) / 255f);
        if (len <= 0 || op <= 0f) return out;
        if (p.v[4] > 0) return extrudePersp(in, w, h, p, s, job, len, op);
        double ang = Math.toRadians(p.v[1]);
        float dx = (float) Math.cos(ang), dy = (float) Math.sin(ang);
        float[] u = EdgeFx.alphaPlane(in);                   // union de corrimientos 0..2^k-1
        float[] du = new float[n];                           // menor corrimiento que tapa (profundidad)
        boolean any = false;
        for (int i = 0; i < n; i++) {
            du[i] = u[i] >= 0.5f ? 0f : INF;
            if (u[i] > 0f) any = true;
        }
        if (!any) return out;
        float[] rc = new float[n], rd = new float[n];
        java.util.Arrays.fill(rd, INF);
        int total = len + 1, offset = 0;
        for (int k = 0; (1 << k) <= total; k++) {
            chk(job);
            int step = 1 << k;
            if ((total & step) != 0) {
                // resultado U= resultado U (este bloque corrido por 'offset')
                unionShift(rc, rd, u, du, w, h, offset * dx, offset * dy, offset);
                offset += step;
            }
            if ((step << 1) <= total) {
                // bloque siguiente: el doble de largo
                float[] u2 = u.clone(), d2 = du.clone();
                unionShift(u2, d2, u, du, w, h, step * dx, step * dy, step);
                u = u2;
                du = d2;
            }
        }
        float shade = Math.max(0, Math.min(100, p.v[3])) / 100f;
        int cr = (p.color >> 16) & 255, cg = (p.color >> 8) & 255, cb = p.color & 255;
        for (int i = 0; i < n; i++) {
            float c = rc[i];
            if (c <= 0.002f) continue;
            float t = rd[i] >= INF ? 1f : Math.min(1f, rd[i] / len);
            float f = 1f - shade * 0.75f * t;
            int a8 = Math.min(255, (int) (c * op * 255f + .5f));
            if (a8 <= 0) continue;
            out[i] = (a8 << 24) | (Fx.clampf(cr * f) << 16) | (Fx.clampf(cg * f) << 8) | Fx.clampf(cb * f);
        }
        return out;
    }

    /**
     * v8.87 EXTRUSION CON PERSPECTIVA. Cada copia hacia atras es la anterior achicada un poquito
     * hacia el PUNTO DE FUGA V (escala g, siempre la misma). Asi la copia k es "achicar g^k hacia V"
     * y se pueden juntar N copias con el mismo truco de duplicar (log2 N pasadas, no N).
     *  - El centro del dibujo termina corrido 'len' en la direccion elegida y achicado a 'fin'
     *    (100% de perspectiva = la parte de atras queda al 30%).
     *  - g se elige para que ningun punto salte mas de 0,7 px entre copias (sin huecos).
     * Se lee con el punto mas cercano (sin desenfocar al repetir).
     */
    static int[] extrudePersp(int[] in, int w, int h, Fx.P p, float s, Fx.Job job, int len, float op) {
        int n = w * h;
        int[] out = new int[n];
        float[] u = EdgeFx.alphaPlane(in);
        float[] du = new float[n];
        double sx = 0, sy = 0, sw = 0;
        int bx0 = w, by0 = h, bx1 = -1, by1 = -1;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                float a = u[i];
                du[i] = a >= 0.5f ? 0f : INF;
                if (a <= 0f) continue;
                sx += x * a; sy += y * a; sw += a;
                if (x < bx0) bx0 = x;
                if (x > bx1) bx1 = x;
                if (y < by0) by0 = y;
                if (y > by1) by1 = y;
            }
        if (sw <= 0) return out;
        float cx = (float) (sx / sw), cy = (float) (sy / sw);
        double ang = Math.toRadians(p.v[1]);
        float dx = (float) Math.cos(ang), dy = (float) Math.sin(ang);
        float fin = 1f - 0.7f * Math.min(100, p.v[4]) / 100f;          // tamano de la copia de atras
        float vx = cx + len * dx / (1f - fin), vy = cy + len * dy / (1f - fin);   // punto de fuga
        double rmax = 1;
        int[][] cs = {{bx0, by0}, {bx1, by0}, {bx0, by1}, {bx1, by1}};
        for (int[] c : cs) rmax = Math.max(rmax, Math.hypot(c[0] - vx, c[1] - vy));
        double g = Math.max(0.5, 1.0 - 0.7 / rmax);
        int steps = (int) Math.min(4096, Math.ceil(Math.log(fin) / Math.log(g)));
        if (steps < 1) steps = 1;
        float[] rc = new float[n], rd = new float[n];
        java.util.Arrays.fill(rd, INF);
        int total = steps + 1, offset = 0;
        for (int k = 0; (1 << k) <= total; k++) {
            chk(job);
            int step = 1 << k;
            if ((total & step) != 0) {
                unionScale(rc, rd, u, du, w, h, vx, vy, Math.pow(g, offset), offset);
                offset += step;
            }
            if ((step << 1) <= total) {
                float[] u2 = u.clone(), d2 = du.clone();
                unionScale(u2, d2, u, du, w, h, vx, vy, Math.pow(g, step), step);
                u = u2;
                du = d2;
            }
        }
        rc = soften(rc, w, h);   // borde sin escalones (la lectura por punto cercano los deja)
        float shade = Math.max(0, Math.min(100, p.v[3])) / 100f;
        int cr = (p.color >> 16) & 255, cg = (p.color >> 8) & 255, cb = p.color & 255;
        for (int i = 0; i < n; i++) {
            float c = rc[i];
            if (c <= 0.002f) continue;
            float t = rd[i] >= INF ? 1f : Math.min(1f, rd[i] / steps);
            float f = 1f - shade * 0.75f * t;
            int a8 = Math.min(255, (int) (c * op * 255f + .5f));
            if (a8 <= 0) continue;
            out[i] = (a8 << 24) | (Fx.clampf(cr * f) << 16) | (Fx.clampf(cg * f) << 8) | Fx.clampf(cb * f);
        }
        return out;
    }

    /** Promedio 3x3 solo en el borde (donde los vecinos son distintos); lo de adentro no cambia. */
    private static float[] soften(float[] a, int w, int h) {
        float[] o = a.clone();
        for (int y = 1; y < h - 1; y++)
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                float c = a[i], mn = c, mx = c, sum = 0;
                for (int dy = -w; dy <= w; dy += w)
                    for (int dx = -1; dx <= 1; dx++) {
                        float v = a[i + dy + dx];
                        sum += v;
                        if (v < mn) mn = v;
                        if (v > mx) mx = v;
                    }
                if (mx - mn > 0.02f) o[i] = sum / 9f;
            }
        return o;
    }

    /** dst = max(dst, src achicado 'sc' hacia (vx,vy)); profundidad como en unionShift. */
    private static void unionScale(final float[] dc, final float[] dd, final float[] sc, final float[] sd,
                                   final int w, final int h, final float vx, final float vy, double scale, final int add) {
        if (add == 0 && scale == 1.0) {
            for (int i = 0; i < dc.length; i++) {
                if (sc[i] > dc[i]) dc[i] = sc[i];
                if (sd[i] < INF && sd[i] < dd[i]) dd[i] = sd[i];
            }
            return;
        }
        final float inv = (float) (1.0 / scale);
        int th = Math.max(1, Math.min(8, Runtime.getRuntime().availableProcessors()));
        Thread[] ts = new Thread[th];
        for (int t = 0; t < th; t++) {
            final int r0 = h * t / th, r1 = h * (t + 1) / th;
            ts[t] = new Thread(new Runnable() {
                @Override public void run() {
                    for (int y = r0; y < r1; y++) {
                        int qy = Math.round(vy + (y - vy) * inv);
                        if (qy < 0 || qy >= h) continue;
                        int row = y * w, srow = qy * w;
                        for (int x = 0; x < w; x++) {
                            int qx = Math.round(vx + (x - vx) * inv);
                            if (qx < 0 || qx >= w) continue;
                            int i = row + x, j = srow + qx;
                            float v = sc[j];
                            if (v > dc[i]) dc[i] = v;
                            float dv = sd[j];
                            if (dv < INF && dv + add < dd[i]) dd[i] = dv + add;
                        }
                    }
                }
            });
            ts[t].start();
        }
        for (Thread t : ts) {
            try { t.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    /**
     * dst = max(dst, src corrido (sx,sy)); profundidad = min(dst, add + src corrido). El corrimiento
     * se redondea a pixeles enteros: asi el borde suave del dibujo se conserva y no se va
     * desenfocando al repetir (un corrimiento con decimales repetido 8 veces engorda el borde).
     */
    private static void unionShift(float[] dc, float[] dd, float[] sc, float[] sd, int w, int h,
                                   float sx, float sy, int add) {
        int ix = Math.round(sx), iy = Math.round(sy);
        for (int y = 0; y < h; y++) {
            int qy = y - iy;
            if (qy < 0 || qy >= h) continue;
            int row = y * w, srow = qy * w;
            for (int x = 0; x < w; x++) {
                int qx = x - ix;
                if (qx < 0 || qx >= w) continue;
                int i = row + x, j = srow + qx;
                float v = sc[j];
                if (v > dc[i]) dc[i] = v;
                float dv = sd[j];
                if (dv < INF && dv + add < dd[i]) dd[i] = dv + add;
            }
        }
    }

    // ================================================================== destellos en cruz

    /** Puntos de luz encontrados (en coordenadas del nivel). */
    static final class Stars {
        final float[] x, y, k;

        Stars(float[] x, float[] y, float[] k) { this.x = x; this.y = y; this.k = k; }
    }

    /**
     * Busca puntos de luz PEQUENOS y claros (no zonas claras grandes: el papel blanco no tiene
     * estrellas). v0 umbral, v5 cantidad maxima, v6 separacion minima (px). Siempre igual.
     */
    static Stars findStars(int[] src, int w, int h, Fx.P p, float s) {
        int det = 768;
        int[] dims = new int[2];
        int[] sm = Math.max(w, h) > det ? Fx.downscale(src, w, h, det, dims) : src;
        int dw = sm == src ? w : dims[0], dh = sm == src ? h : dims[1];
        float k = dw / (float) w;                             // escala de busqueda respecto del nivel
        int n = dw * dh;
        float[] lum = new float[n];
        for (int i = 0; i < n; i++) {
            int c = sm[i];
            lum[i] = Fx.lum(c) / 255f * ((c >>> 24) / 255f);
        }
        float[] ls = lum.clone(), lb = lum.clone(), tmp = new float[n];
        float detS = s * k;                                    // px de tamano real -> px de busqueda
        Fx.gaussPlaneF(ls, tmp, dw, dh, Math.max(0.6f, 1.2f * detS));
        Fx.gaussPlaneF(lb, tmp, dw, dh, Math.max(3f, 14f * detS));
        float thr = Math.max(0, Math.min(100, p.v[0])) / 100f;
        ArrayList<float[]> cand = new ArrayList<>();
        for (int y = 1; y < dh - 1; y++) {
            for (int x = 1; x < dw - 1; x++) {
                int i = y * dw + x;
                float v = ls[i];
                if (v < thr) continue;
                float con = v - lb[i];
                if (con < 0.06f) continue;                    // zona clara grande: no
                boolean max = true;
                for (int yy = -1; yy <= 1 && max; yy++)
                    for (int xx = -1; xx <= 1; xx++) {
                        if (xx == 0 && yy == 0) continue;
                        float o = ls[i + yy * dw + xx];
                        if (o > v || (o == v && (yy < 0 || (yy == 0 && xx < 0)))) { max = false; break; }
                    }
                if (!max) continue;
                cand.add(new float[]{x, y, con * v});
            }
        }
        cand.sort((a, b) -> {
            int c = Float.compare(b[2], a[2]);
            if (c != 0) return c;
            c = Float.compare(a[1], b[1]);
            return c != 0 ? c : Float.compare(a[0], b[0]);
        });
        int maxN = Math.max(1, Math.min(300, p.v[5]));
        float sep = Math.max(1f, p.v[6] * detS);
        ArrayList<float[]> keep = new ArrayList<>();
        for (float[] c : cand) {
            boolean ok = true;
            for (float[] q : keep) {
                float ddx = c[0] - q[0], ddy = c[1] - q[1];
                if (ddx * ddx + ddy * ddy < sep * sep) { ok = false; break; }
            }
            if (ok) keep.add(c);
            if (keep.size() >= maxN) break;
        }
        int m = keep.size();
        float[] xs = new float[m], ys = new float[m], ks = new float[m];
        float top = m > 0 ? keep.get(0)[2] : 1f;
        for (int i = 0; i < m; i++) {
            float[] c = keep.get(i);
            xs[i] = (c[0] + .5f) / k;
            ys[i] = (c[1] + .5f) / k;
            ks[i] = 0.35f + 0.65f * (float) Math.sqrt(c[2] / Math.max(1e-6f, top));
        }
        return new Stars(xs, ys, ks);
    }

    /**
     * Dibuja las estrellas en esta franja. v1 intensidad %, v2 largo (px), v3 angulo, v4 brazos.
     * Luz para el modo Anadir (como Rayos de luz).
     */
    static int[] drawStars(Stars st, int w, int h, int ox, int oy, Fx.P p, float s) {
        int[] out = new int[w * h];
        if (st == null || st.x.length == 0) return out;
        float inten = Math.max(0, Math.min(200, p.v[1])) / 100f;
        if (inten <= 0f) return out;
        float len = Math.max(2f, p.v[2] * s);
        int arms = Math.max(2, Math.min(8, p.v[4]));
        float rot = (float) Math.toRadians(p.v[3]);
        float hw0 = Math.max(0.55f, 1.3f * s);
        float core = Math.max(0.8f, len * 0.05f);
        float[] lt = new float[w * h];
        float step = (float) (Math.PI * 2 / arms);
        for (int k = 0; k < st.x.length; k++) {
            float cx = st.x[k] - ox, cy = st.y[k] - oy, str = st.k[k] * inten;
            int x0 = Math.max(0, (int) Math.floor(cx - len - 2)), x1 = Math.min(w - 1, (int) Math.ceil(cx + len + 2));
            int y0 = Math.max(0, (int) Math.floor(cy - len - 2)), y1 = Math.min(h - 1, (int) Math.ceil(cy + len + 2));
            for (int y = y0; y <= y1; y++) {
                float dy = y + .5f - cy;
                for (int x = x0; x <= x1; x++) {
                    float dx = x + .5f - cx;
                    float r = (float) Math.sqrt(dx * dx + dy * dy);
                    if (r > len + 1f) continue;
                    float v = str * (float) Math.exp(-(r * r) / (2f * core * core));
                    if (r > 0.01f) {
                        float th = (float) Math.atan2(dy, dx) - rot;
                        float rel = th / step;
                        float da = (rel - Math.round(rel)) * step;     // angulo al brazo mas cercano
                        float along = r * (float) Math.cos(da), dist = r * Math.abs((float) Math.sin(da));
                        if (along > 0f && along < len) {
                            float t = along / len;
                            float half = hw0 * (1f - 0.7f * t);
                            float cov = Math.max(0f, Math.min(1f, half - dist + 0.5f));
                            float fall = (1f - t);
                            v += str * cov * fall * fall * 1.1f;
                        }
                    }
                    lt[y * w + x] += v;
                }
            }
        }
        float r0 = (p.color >> 16) & 255, g0 = (p.color >> 8) & 255, b0 = p.color & 255;
        for (int i = 0; i < out.length; i++) if (lt[i] > 0f) out[i] = GodRays.encode(lt[i], r0, g0, b0);
        return out;
    }

    // ================================================================== desenfoque de giro

    /**
     * Desenfoque de giro: cada punto se reparte por un arco alrededor del centro (no hacia el
     * centro como el radial). v0 angulo total (grados). Se hace por anillos (rapido aunque el
     * angulo sea grande) con alfa premultiplicado. Angulo 0 = la imagen igual.
     */
    static int[] twirl(int[] in, int w, int h, Fx.P p, Fx.Job job) {
        float th = (float) Math.toRadians(Math.max(0, Math.min(180, p.v[0])));
        int n = w * h;
        if (th <= 0f) return in.clone();
        int[] out = new int[n];
        float cx = p.px * w, cy = p.py * h;
        float rmax = 0f;
        float[][] cs = {{0, 0}, {w, 0}, {0, h}, {w, h}};
        for (float[] c : cs) rmax = Math.max(rmax, (float) Math.hypot(c[0] - cx, c[1] - cy));
        int rings = (int) Math.ceil(rmax) + 2;
        // anillo r: n_r muestras; se guardan dos anillos a la vez
        float[][] ra = new float[2][], rr = new float[2][], rg = new float[2][], rb = new float[2][];
        int[] rn = new int[2];
        int[] ringId = {-1, -1};
        // pixeles agrupados por anillo: para cada fila, el radio de cada pixel
        int[] ringOf = new int[n];
        int[] counts = new int[rings + 1];
        for (int y = 0; y < h; y++) {
            float dy = y + .5f - cy;
            for (int x = 0; x < w; x++) {
                float dx = x + .5f - cx;
                int r = Math.min(rings - 1, (int) Math.sqrt(dx * dx + dy * dy));
                ringOf[y * w + x] = r;
                counts[r]++;
            }
        }
        int[] start = new int[rings + 1];
        for (int r = 0; r < rings; r++) start[r + 1] = start[r] + counts[r];
        int[] order = new int[n], fill = start.clone();
        for (int i = 0; i < n; i++) order[fill[ringOf[i]]++] = i;
        ringOf = null;
        for (int r = 0; r < rings - 1; r++) {
            if ((r & 31) == 0) {
                chk(job);
                if (job != null) job.progress(100 * r / rings);
            }
            if (start[r + 1] == start[r]) continue;
            // anillos r y r+1 listos
            for (int q = r; q <= r + 1; q++) {
                int slot = q & 1;
                if (ringId[slot] == q) continue;
                ring(in, w, h, cx, cy, q, th, ra, rr, rg, rb, rn, slot);
                ringId[slot] = q;
            }
            int s0 = r & 1, s1 = (r + 1) & 1;
            for (int k = start[r]; k < start[r + 1]; k++) {
                int i = order[k];
                int x = i % w, y = i / w;
                float dx = x + .5f - cx, dy = y + .5f - cy;
                float rad = (float) Math.sqrt(dx * dx + dy * dy);
                if (rad * th < 1f) { out[i] = in[i]; continue; }    // arco menor a 1 px: igual
                float phi = (float) Math.atan2(dy, dx);
                if (phi < 0) phi += (float) (Math.PI * 2);
                float f = rad - r;
                float a = mix(sampleRing(ra[s0], rn[s0], phi), sampleRing(ra[s1], rn[s1], phi), f);
                if (a <= 0.5f) continue;
                float cr = mix(sampleRing(rr[s0], rn[s0], phi), sampleRing(rr[s1], rn[s1], phi), f);
                float cg = mix(sampleRing(rg[s0], rn[s0], phi), sampleRing(rg[s1], rn[s1], phi), f);
                float cb = mix(sampleRing(rb[s0], rn[s0], phi), sampleRing(rb[s1], rn[s1], phi), f);
                int al = Math.min(255, (int) (a + .5f));
                out[i] = (al << 24) | (Fx.clampf(cr / a * 255f) << 16) | (Fx.clampf(cg / a * 255f) << 8) | Fx.clampf(cb / a * 255f);
            }
        }
        return out;
    }

    /** Muestrea el anillo q (premultiplicado) y le aplica el promedio movil del arco. */
    private static void ring(int[] in, int w, int h, float cx, float cy, int q, float th,
                             float[][] ra, float[][] rr, float[][] rg, float[][] rb, int[] rn, int slot) {
        float rad = Math.max(0.5f, q);
        int m = Math.max(8, (int) Math.ceil(Math.PI * 2 * rad));
        float[] a = new float[m], r = new float[m], g = new float[m], b = new float[m];
        for (int j = 0; j < m; j++) {
            double phi = Math.PI * 2 * j / m;
            float x = cx + rad * (float) Math.cos(phi) - .5f, y = cy + rad * (float) Math.sin(phi) - .5f;
            premulBil(in, w, h, x, y, a, r, g, b, j);
        }
        int win = Math.max(1, Math.round(th / (float) (Math.PI * 2) * m));
        if (win > 1) {
            win = Math.min(win, m);
            boxCirc(a, m, win);
            boxCirc(r, m, win);
            boxCirc(g, m, win);
            boxCirc(b, m, win);
        }
        ra[slot] = a; rr[slot] = r; rg[slot] = g; rb[slot] = b;
        rn[slot] = m;
    }

    private static void boxCirc(float[] v, int m, int win) {
        float[] o = new float[m];
        int half = win / 2;
        double acc = 0;
        for (int k = -half; k < win - half; k++) acc += v[((k % m) + m) % m];
        for (int j = 0; j < m; j++) {
            o[j] = (float) (acc / win);
            acc += v[((j + win - half) % m + m) % m] - v[((j - half) % m + m) % m];
        }
        System.arraycopy(o, 0, v, 0, m);
    }

    private static float sampleRing(float[] v, int m, float phi) {
        float t = phi / (float) (Math.PI * 2) * m;
        int j0 = (int) Math.floor(t);
        float f = t - j0;
        int a = ((j0 % m) + m) % m, b = (a + 1) % m;
        return v[a] + (v[b] - v[a]) * f;
    }

    private static float mix(float a, float b, float f) { return a + (b - a) * f; }

    /** Bilineal premultiplicado; fuera de la imagen repite el borde (como el desenfoque radial). */
    private static void premulBil(int[] in, int w, int h, float x, float y, float[] a, float[] r, float[] g,
                                  float[] b, int j) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        float fx = x - x0, fy = y - y0;
        float sa = 0, sr = 0, sg = 0, sb = 0;
        for (int k = 0; k < 4; k++) {
            int xx = Math.max(0, Math.min(w - 1, x0 + (k & 1))), yy = Math.max(0, Math.min(h - 1, y0 + (k >> 1)));
            float wt = ((k & 1) == 0 ? 1 - fx : fx) * ((k >> 1) == 0 ? 1 - fy : fy);
            int c = in[yy * w + xx];
            float al = (c >>> 24) * wt;
            sa += al;
            sr += ((c >> 16) & 255) / 255f * al;
            sg += ((c >> 8) & 255) / 255f * al;
            sb += (c & 255) / 255f * al;
        }
        a[j] = sa; r[j] = sr; g[j] = sg; b[j] = sb;
    }

    // ================================================================== mosaico

    /**
     * Mosaico cuadrado: celdas alineadas a la esquina de la imagen (siempre en el mismo lugar).
     * v0 tamano (px). Promedio con alfa premultiplicado (sin negro en lo transparente).
     */
    static int[] mosaic(int[] in, int w, int h, int oy, Fx.P p, float s) {
        float cs = Math.max(1f, p.v[0] * s);
        if (cs <= 1.0001f) return in.clone();
        int[] out = new int[w * h];
        int ky0 = (int) Math.floor(oy / cs), ky1 = (int) Math.floor((oy + h - 1) / cs);
        int kx1 = (int) Math.floor((w - 1) / cs);
        for (int ky = ky0; ky <= ky1; ky++) {
            int ya = Math.max(0, (int) Math.floor(ky * cs) - oy), yb = Math.min(h, (int) Math.floor((ky + 1) * cs) - oy);
            if (yb <= ya) continue;
            for (int kx = 0; kx <= kx1; kx++) {
                int xa = (int) Math.floor(kx * cs), xb = Math.min(w, (int) Math.floor((kx + 1) * cs));
                if (xb <= xa) continue;
                long sa = 0, sr = 0, sg = 0, sb = 0;
                for (int y = ya; y < yb; y++)
                    for (int x = xa; x < xb; x++) {
                        int c = in[y * w + x], a = c >>> 24;
                        if (a == 0) continue;
                        sa += a;
                        sr += (long) ((c >> 16) & 255) * a;
                        sg += (long) ((c >> 8) & 255) * a;
                        sb += (long) (c & 255) * a;
                    }
                int cnt = (yb - ya) * (xb - xa);
                int c = 0;
                if (sa > 0) {
                    int al = (int) ((sa + cnt / 2) / cnt);
                    if (al > 0) c = (Math.min(255, al) << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
                }
                for (int y = ya; y < yb; y++) java.util.Arrays.fill(out, y * w + xa, y * w + xb, c);
            }
        }
        return out;
    }

    private static void chk(Fx.Job j) {
        if (j != null && j.cancelled()) throw new Fx.Cancelled();
    }
}
