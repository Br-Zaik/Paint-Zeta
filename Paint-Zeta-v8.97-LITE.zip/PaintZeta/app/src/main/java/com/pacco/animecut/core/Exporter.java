package com.pacco.animecut.core;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Exporta capas como PNG transparente conservando el tamano/posicion del
 * lienzo para que entren alineadas en Alight Motion.
 *
 * v8.7: la limpieza y el trabajo temporal se hacen solo sobre el rectangulo
 * con contenido de cada capa. En una pieza pequena ya no se crean 3-4 buffers
 * del tamano completo del lienzo.
 */
public final class Exporter {

    private Exporter() {}

    private static final class Prepared {
        final Rect r;
        final int[] px;
        Prepared(Rect r, int[] px) { this.r = r; this.px = px; }
        boolean empty() { return r == null || px == null || r.isEmpty(); }
    }

    public static int exportZip(ContentResolver cr, Project p, Uri uri, int outW, int outH,
                                int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os));
        zos.setLevel(1);
        int count = 0;
        try {
            int idx = 1;
            for (Layer l : p.layers) {
                if (!l.visible) continue;
                zos.putNextEntry(new ZipEntry(String.format(Locale.US, "%02d_%s.png", idx++, safe(l.name))));
                writePng(p, prepare(p, l, edgeClean), outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            zos.putNextEntry(new ZipEntry("LEEME_Partes.txt"));
            String help = "Paint Zeta - Capas para animacion\n"
                    + "Lienzo: " + outW + " x " + outH + " px\n"
                    + "Cada PNG tiene transparencia y el mismo origen (0,0).\n"
                    + "Extrae los PNG e importalos como capas individuales en tu editor de animacion.\n"
                    + "No recortes automaticamente los PNG: perderian su alineacion.\n"
                    + "Las capas en Multiplicar u otro modo (por ejemplo la capa Color) se guardan ya\n"
                    + "mezcladas con lo de abajo, porque un PNG no guarda el modo: usalas en modo Normal.\n";
            zos.write(help.getBytes("UTF-8"));
            zos.closeEntry();
            zos.finish();
        } finally {
            try { zos.close(); } catch (IOException ignored) {}
        }
        return count;
    }

    public static void exportLayer(ContentResolver cr, Project p, Layer l, Uri uri, int outW, int outH,
                                   int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writePng(p, prepare(p, l, edgeClean), outW, outH, bos);
            bos.flush();
        } finally {
            try { bos.close(); } catch (IOException ignored) {}
        }
    }

    public static void exportLayer(ContentResolver cr, Project p, Layer l, Uri uri, int edgeClean)
            throws IOException {
        exportLayer(cr, p, l, uri, p.w, p.h, edgeClean);
    }

    /** Prepara solo el rectangulo que realmente ocupa la capa. */
    private static Prepared prepare(Project p, Layer l, int edgeClean) {
        Rect b = l.bounds(p.w, p.h);
        if (b == null || b.isEmpty()) return new Prepared(new Rect(0, 0, 0, 0), new int[0]);
        int rw = b.width(), rh = b.height(), n = rw * rh;
        int[] out = new int[n];
        l.read(b.left, b.top, rw, rh, out, p.w, p.h);
        // v8.26: "Cambiar color" no destructivo se ve igual en el PNG
        ColorAdjust adj = l.adjuster();
        if (adj != null) for (int i = 0; i < n; i++) out[i] = adj.apply(out[i]);

        int[] base = null;
        if (l.clip) {
            int idx = p.layers.indexOf(l);
            for (int k = idx - 1; k >= 0; k--) {
                Layer below = p.layers.get(k);
                if (!below.clip) {
                    base = new int[n];
                    below.read(b.left, b.top, rw, rh, base, p.w, p.h);
                    break;
                }
            }
        }

        // v8.23: un PNG no guarda el modo de mezcla. Una capa en Multiplicar (por
        // ejemplo "Color (sin tapar lineas)") se exporta YA mezclada con lo que tiene
        // debajo, asi se ve igual en Alight Motion en modo Normal. Las capas en
        // modo Normal se exportan exactamente como antes.
        if (l.mode != Layer.MODE_NORMAL) bakeBlend(p, l, b, out);

        byte[] mask = edgeClean > 0 ? new byte[n] : null;
        for (int i = 0; i < n; i++) {
            int c = out[i];
            int a = ((c >>> 24) * l.opacity) / 255;
            if (base != null) a = Layer.clipA(a, base[i] >>> 24, l.clipOut);
            out[i] = (a << 24) | (c & 0x00FFFFFF);
            if (mask != null) mask[i] = (byte) a;
        }
        base = null;
        if (mask == null) return new Prepared(b, out);

        // Defringe tambien regional: evita buffers gigantes cuando solo se
        // exporta un brazo/cabello/cabeza.
        int[] rgb = new int[n];
        for (int i = 0; i < n; i++) rgb[i] = out[i] | 0xFF000000;
        // Una capa transparente no conserva el color real que habia detras.
        // Intentar adivinarlo desde RGB=0 de los transparentes crea halos negros.
        // Por eso limpiamos tomando color de adentro; modo 2 usa un radio mayor.
        int radius = edgeClean >= 2 ? 4 : 3;
        int[] clean = Defringe.clean(rgb, mask, rw, rh, radius, false, 0);
        for (int i = 0; i < n; i++) out[i] = (out[i] & 0xFF000000) | (clean[i] & 0x00FFFFFF);
        return new Prepared(b, out);
    }

    /**
     * Mezcla la capa con la composicion de las capas visibles de debajo (solo color;
     * conserva su alfa). v8.26: la composicion de abajo respeta recortes, bases ocultas
     * y "Cambiar color" (antes ignoraba el recorte de las capas de abajo).
     */
    static void bakeBlend(Project p, Layer l, Rect b, int[] out) {
        int idx = p.layers.indexOf(l);
        if (idx <= 0) return;
        int rw = b.width(), rh = b.height(), n = rw * rh;
        int[] below = new int[n];
        Compositor.composite(p.layers, idx, p.w, p.h, b.left, b.top, rw, rh, below);
        for (int i = 0; i < n; i++) {
            int c = out[i];
            if ((c >>> 24) == 0 || (below[i] >>> 24) == 0) continue;
            out[i] = Project.mixMode(below[i], c, l.mode);
        }
    }

    /**
     * v8.26 "Imagen completa": un solo PNG con todas las capas visibles juntas, igual
     * que en pantalla (Multiplicar, recorte, opacidad, Cambiar color). Lo transparente
     * queda transparente. La referencia de colores nunca entra (no es una capa).
     */
    public static void exportFlattened(ContentResolver cr, Project p, Uri uri, int outW, int outH) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writeFlattened(p, outW, outH, bos);
            bos.flush();
        } finally {
            try { bos.close(); } catch (IOException ignored) {}
        }
    }

    /** Una capa como PNG (lo mismo que exportLayer, sin ContentResolver; lo usan las pruebas). */
    public static void writeLayerPng(Project p, Layer l, int edgeClean, OutputStream out) {
        writePng(p, prepare(p, l, edgeClean), p.w, p.h, out);
    }

    /** Escribe la imagen completa como PNG (tambien lo usan las pruebas). */
    public static void writeFlattened(Project p, int outW, int outH, OutputStream out) {
        int[] px = Compositor.flatten(p);
        writePng(p, new Prepared(new Rect(0, 0, p.w, p.h), px), outW, outH, out);
    }

    private static void writePng(Project p, Prepared prep, int outW, int outH, OutputStream out) {
        if (outW <= 0) outW = p.w;
        if (outH <= 0) outH = p.h;
        final Bitmap dst = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        // sin premultiplicar: el PNG guarda el color exacto aun donde es casi transparente
        dst.setPremultiplied(false);
        try {
            if (!prep.empty()) {
                int rw = prep.r.width(), rh = prep.r.height();
                if (outW == p.w && outH == p.h) {
                    dst.setPixels(prep.px, 0, rw, prep.r.left, prep.r.top, rw, rh);
                } else {
                    // v8.73: antes se dibujaba con Canvas sobre esta imagen sin premultiplicar y
                    // Android lo rechaza: "Mitad", "1920" y "1280" fallaban. Ahora se reduce en Java.
                    Resample.resize(prep.px, prep.r.left, prep.r.top, rw, rh, p.w, p.h, outW, outH,
                            new Resample.RowSink() {
                                @Override public void row(int[] line, int x, int y, int len) {
                                    dst.setPixels(line, 0, len, x, y, len, 1);
                                }
                            });
                }
            }
            if (!dst.compress(Bitmap.CompressFormat.PNG, 100, out))
                throw new IllegalStateException("No se pudo escribir el PNG");
        } finally {
            dst.recycle();
        }
    }

    // ------------------------------------------------------------------ v8.90 Guardar imagen
    public static final int FMT_PNG = 0, FMT_JPG = 1, FMT_WEBP = 2;
    public static final String[] FMT_EXT = {"png", "jpg", "webp"};
    public static final String[] FMT_MIME = {"image/png", "image/jpeg", "image/webp"};

    /** Resultado de codificar: los bytes del archivo, su medida y la calidad que quedo. */
    public static final class Encoded {
        public final byte[] bytes;
        public final int w, h, quality;

        Encoded(byte[] b, int w, int h, int q) { bytes = b; this.w = w; this.h = h; quality = q; }
    }

    /**
     * La imagen completa (como se ve) en PNG, JPG o WebP. JPG no tiene transparencia: lo
     * transparente queda blanco. maxBytes > 0 (solo JPG/WebP): se baja la calidad (hasta 35) y si
     * no alcanza se achica la imagen, hasta que el archivo pese eso o menos.
     */
    public static Encoded encodeFlattened(Project p, int outW, int outH, int fmt, int quality, long maxBytes) {
        if (outW <= 0) outW = p.w;
        if (outH <= 0) outH = p.h;
        return encodePixels(Compositor.flatten(p), p.w, p.h, outW, outH, fmt, quality, maxBytes);
    }

    /**
     * v8.92: lo mismo para cualquier imagen (pixeles sin premultiplicar de sw x sh). La usa
     * tambien "Comprimir fotos". Con peso maximo: la mejor calidad que entra y, si ni con poca
     * calidad entra, se achica la medida.
     */
    public static Encoded encodePixels(int[] flat, int sw, int sh, int outW, int outH, int fmt, int quality, long maxBytes) {
        int w = outW, h = outH;
        quality = Math.max(10, Math.min(100, quality));
        if (fmt == FMT_PNG) maxBytes = 0;
        long lastLow = 0;
        for (int round = 0; round < 8; round++) {
            if (round > 0) {
                // (viene de "continue": se achica antes de probar de nuevo)
                float k = lastLow > 0 ? (float) Math.sqrt(maxBytes / (double) lastLow) * 0.95f : 0.8f;
                k = Math.max(0.3f, Math.min(0.9f, k));
                w = Math.max(1, Math.round(w * k));
                h = Math.max(1, Math.round(h * k));
            }
            int[] px = scaled(flat, sw, sh, w, h);
            if (fmt == FMT_JPG) onWhite(px);
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            if (fmt == FMT_PNG) b.setPremultiplied(false);
            b.setPixels(px, 0, w, 0, 0, w, h);
            px = null;
            try {
                byte[] best = compress(b, fmt, quality);
                if (maxBytes <= 0 || best.length <= maxBytes) return new Encoded(best, w, h, quality);
                // buscar la calidad mas alta que entra
                // v8.91: primero la calidad mas baja: si ni asi entra, se achica sin probar las demas
                byte[] low = compress(b, fmt, 35);
                lastLow = low.length;
                if (low.length > maxBytes) continue;
                int lo = 36, hi = quality - 1, okQ = 35;
                byte[] okB = low;
                while (lo <= hi) {
                    int mid = (lo + hi) >>> 1;
                    byte[] t = compress(b, fmt, mid);
                    if (t.length <= maxBytes) { okQ = mid; okB = t; lo = mid + 1; } else hi = mid - 1;
                }
                return new Encoded(okB, w, h, okQ);
            } finally {
                b.recycle();
            }
        }
        throw new IllegalStateException("No se pudo llegar a ese peso");
    }

    private static byte[] compress(Bitmap b, int fmt, int q) {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(1 << 16);
        Bitmap.CompressFormat cf = fmt == FMT_JPG ? Bitmap.CompressFormat.JPEG
                : fmt == FMT_WEBP ? (android.os.Build.VERSION.SDK_INT >= 30 ? Bitmap.CompressFormat.WEBP_LOSSY
                : Bitmap.CompressFormat.WEBP) : Bitmap.CompressFormat.PNG;
        if (!b.compress(cf, fmt == FMT_PNG ? 100 : q, bo)) throw new IllegalStateException("No se pudo escribir la imagen");
        return bo.toByteArray();
    }

    private static int[] scaled(int[] px, int sw, int sh, final int w, int h) {
        if (w == sw && h == sh) return px.clone();
        final int[] out = new int[w * h];
        Resample.resize(px, 0, 0, sw, sh, sw, sh, w, h, new Resample.RowSink() {
            @Override public void row(int[] line, int x, int y, int len) { System.arraycopy(line, 0, out, y * w + x, len); }
        });
        return out;
    }

    /** JPG: lo transparente o a medias se mezcla con blanco. */
    static void onWhite(int[] px) {
        for (int i = 0; i < px.length; i++) {
            int c = px[i], a = c >>> 24;
            if (a == 255) continue;
            int r = (((c >> 16) & 255) * a + 255 * (255 - a)) / 255;
            int g = (((c >> 8) & 255) * a + 255 * (255 - a)) / 255;
            int bl = ((c & 255) * a + 255 * (255 - a)) / 255;
            px[i] = 0xFF000000 | (r << 16) | (g << 8) | bl;
        }
    }

    private static String safe(String s) {
        if (s == null) return "capa";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(Character.isLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
        return sb.length() == 0 ? "capa" : sb.toString();
    }
}
