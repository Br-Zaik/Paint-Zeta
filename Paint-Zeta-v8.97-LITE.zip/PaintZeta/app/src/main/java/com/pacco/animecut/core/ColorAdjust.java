package com.pacco.animecut.core;

/**
 * v8.26 "Cambiar color" no destructivo: gira el tono y sube/baja saturacion y
 * luminosidad (modelo HSL). El alfa no cambia nunca.
 *
 * Una capa de color base casi siempre tiene pocos colores distintos, por eso se
 * guarda una cache chica (4096 entradas). Cada hilo debe usar su propia instancia
 * (Layer.adjuster() crea una nueva cada vez).
 */
public final class ColorAdjust {
    public final int hue, sat, lit;
    /** v8.83: contraste (-100..100) y canal del gris (0 normal, 1 rojo, 2 verde, 3 azul). */
    public final int con, gch;
    private final int[] keys = new int[4096];
    private final int[] vals = new int[4096];

    public ColorAdjust(int hue, int sat, int lit) {
        this(hue, sat, lit, 0, 0);
    }

    public ColorAdjust(int hue, int sat, int lit, int con, int gch) {
        this.hue = Math.max(-180, Math.min(180, hue));
        this.sat = Math.max(-100, Math.min(100, sat));
        this.lit = Math.max(-100, Math.min(100, lit));
        this.con = Math.max(-100, Math.min(100, con));
        this.gch = Math.max(0, Math.min(4, gch));
    }

    /** ARGB sin premultiplicar -> ARGB ajustado (mismo alfa). */
    public int apply(int c) {
        int a = c & 0xFF000000;
        if (a == 0) return c;
        int rgb = c & 0x00FFFFFF;
        int k = (rgb ^ (rgb >>> 12) ^ (rgb >>> 7)) & 4095;
        int key = rgb | 0x01000000; // marca: entrada ocupada
        if (keys[k] == key) return a | vals[k];
        int out = adjustRgb(rgb, hue, sat, lit, con, gch);
        keys[k] = key;
        vals[k] = out;
        return a | out;
    }

    /**
     * v8.83: con contraste y canal del gris. Con con = 0 y gch = 0 da exactamente lo de antes
     * (las obras guardadas se ven igual). Con gch distinto de 0 es el "Blanco y negro" nuevo, con
     * la misma cuenta que el B/N de Borrar fondo: gris del canal (1 rojo, 2 verde, 3 azul,
     * 4 normal = luminancia), cuanto color queda, brillo y contraste. Esa cuenta es una matriz de
     * color: por eso Transformar y Marioneta pueden mostrarla igual sin gastar memoria.
     */
    public static int adjustRgb(int rgb, int hue, int sat, int lit, int con, int gch) {
        if (gch == 0) {
            int out = adjustRgb(rgb, hue, sat, lit);
            if (con != 0) {
                float k = con < 0 ? 1f + con / 100f : 1f + con / 50f;
                int r = clamp(Math.round(((out >> 16) & 255) * k + 128f * (1f - k)));
                int g = clamp(Math.round(((out >> 8) & 255) * k + 128f * (1f - k)));
                int b = clamp(Math.round((out & 255) * k + 128f * (1f - k)));
                out = (r << 16) | (g << 8) | b;
            }
            return out;
        }
        if (hue != 0 || sat > 0) rgb = adjustRgb(rgb, hue, Math.max(0, sat), 0);
        float[] m = bwMatrix(sat, lit, con, gch);
        float r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        int nr = clamp(Math.round(m[0] * r + m[1] * g + m[2] * b + m[4]));
        int ng = clamp(Math.round(m[5] * r + m[6] * g + m[7] * b + m[9]));
        int nb = clamp(Math.round(m[10] * r + m[11] * g + m[12] * b + m[14]));
        return (nr << 16) | (ng << 8) | nb;
    }

    /**
     * Matriz 4x5 (como ColorMatrix de Android) del Blanco y negro nuevo: gris del canal, mezcla
     * con el color segun sat (-100 = todo gris), brillo y contraste.
     */
    public static float[] bwMatrix(int sat, int lit, int con, int gch) {
        float wr, wg, wb;
        switch (gch) {
            case 1: wr = 1f; wg = 0f; wb = 0f; break;
            case 2: wr = 0f; wg = 1f; wb = 0f; break;
            case 3: wr = 0f; wg = 0f; wb = 1f; break;
            default: wr = 0.299f; wg = 0.587f; wb = 0.114f;
        }
        float t = sat < 0 ? Math.min(1f, -sat / 100f) : 0f, s = 1f - t;
        // brillo: hacia blanco (positivo) o hacia negro (negativo)
        float bk = lit > 0 ? 1f - lit / 100f : 1f + lit / 100f, bo = lit > 0 ? 255f * lit / 100f : 0f;
        float k = con < 0 ? 1f + con / 100f : 1f + con / 50f;
        float mul = bk * k, off = bo * k + 128f * (1f - k);
        float[] m = new float[20];
        for (int row = 0; row < 3; row++) {
            m[row * 5] = mul * (t * wr + (row == 0 ? s : 0f));
            m[row * 5 + 1] = mul * (t * wg + (row == 1 ? s : 0f));
            m[row * 5 + 2] = mul * (t * wb + (row == 2 ? s : 0f));
            m[row * 5 + 4] = off;
        }
        m[18] = 1f;
        return m;
    }

    /**
     * Matriz para MOSTRAR una capa con este ajuste mientras se transforma (null = sin ajuste que
     * se pueda mostrar asi). El Blanco y negro nuevo sale exacto; el de versiones viejas, muy parecido.
     */
    public static float[] showMatrix(int hue, int sat, int lit, int con, int gch) {
        if (gch != 0 && hue == 0 && sat <= 0) return bwMatrix(sat, lit, con, gch);
        if (gch == 0 && sat <= -100) return bwMatrix(-100, lit, con, 4);
        return null;
    }

    /** El calculo sin cache (para pruebas y para "fijar" el ajuste en los pixeles). */
    public static int adjustRgb(int rgb, int hue, int sat, int lit) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float l = (max + min) / 2f, h = 0f, s = 0f;
        float d = max - min;
        if (d > 1e-6f) {
            s = l > .5f ? d / (2f - max - min) : d / (max + min);
            if (max == r) h = (g - b) / d + (g < b ? 6f : 0f);
            else if (max == g) h = (b - r) / d + 2f;
            else h = (r - g) / d + 4f;
            h /= 6f;
        }
        h += hue / 360f;
        h -= (float) Math.floor(h);
        if (sat > 0) s += (1f - s) * sat / 100f;
        else if (sat < 0) s *= 1f + sat / 100f;
        if (lit > 0) l += (1f - l) * lit / 100f;
        else if (lit < 0) l *= 1f + lit / 100f;
        s = Math.max(0f, Math.min(1f, s));
        l = Math.max(0f, Math.min(1f, l));
        float nr, ng, nb;
        if (s <= 1e-6f) {
            nr = ng = nb = l;
        } else {
            float q = l < .5f ? l * (1f + s) : l + s - l * s;
            float p = 2f * l - q;
            nr = hue2rgb(p, q, h + 1f / 3f);
            ng = hue2rgb(p, q, h);
            nb = hue2rgb(p, q, h - 1f / 3f);
        }
        int ir = Math.round(nr * 255f), ig = Math.round(ng * 255f), ib = Math.round(nb * 255f);
        return (clamp(ir) << 16) | (clamp(ig) << 8) | clamp(ib);
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : v > 255 ? 255 : v;
    }

    private static float hue2rgb(float p, float q, float t) {
        if (t < 0f) t += 1f;
        if (t > 1f) t -= 1f;
        if (t < 1f / 6f) return p + (q - p) * 6f * t;
        if (t < .5f) return q;
        if (t < 2f / 3f) return p + (q - p) * (2f / 3f - t) * 6f;
        return p;
    }
}
