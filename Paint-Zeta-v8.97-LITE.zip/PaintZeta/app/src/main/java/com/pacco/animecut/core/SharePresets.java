package com.pacco.animecut.core;

/**
 * v8.92: medidas y peso listos para mandar o publicar (WhatsApp, Instagram, historias, Facebook,
 * correo, X). Las usan "Guardar imagen" y "Comprimir fotos". Nunca se agranda una imagen: si ya
 * es mas chica que la medida, queda como esta. Todas salen en JPG (fondo blanco), que es lo que
 * esas apps aceptan sin volver a convertir.
 */
public final class SharePresets {

    private SharePresets() { }

    /** Como se calcula la medida: lado mas largo, ancho, o que entre en una caja. */
    public static final int LONG = 0, WIDTH = 1, BOX = 2, SAME = 3;

    public static final String[] NAMES = {"WhatsApp", "Instagram", "Historias", "Facebook", "Correo", "X", "Muy liviano", "Misma medida"};

    public static final String[] DESC = {
            "1600 px, hasta 500 kB: WhatsApp casi no la vuelve a achicar",
            "1080 de ancho (publicacion 4:5 = 1080 x 1350)",
            "Historias, Reels y TikTok: entra en 1080 x 1920",
            "2048 px, calidad alta",
            "Correo o Gmail: 1920 px, hasta 500 kB",
            "X (Twitter): 1600 px",
            "1280 px, hasta 200 kB: para mandar muchas rapido",
            "La misma medida, solo mas liviana (calidad 80)"};

    private static final int[][] SIZE = {
            {LONG, 1600, 0}, {WIDTH, 1080, 0}, {BOX, 1080, 1920}, {LONG, 2048, 0},
            {LONG, 1920, 0}, {LONG, 1600, 0}, {LONG, 1280, 0}, {SAME, 0, 0}};
    private static final int[] QUALITY = {85, 90, 90, 88, 80, 88, 75, 80};
    private static final long[] MAX_BYTES = {500_000L, 0L, 0L, 0L, 500_000L, 0L, 200_000L, 0L};

    public static int count() { return NAMES.length; }

    public static int quality(int i) { return QUALITY[clamp(i)]; }

    public static long maxBytes(int i) { return MAX_BYTES[clamp(i)]; }

    private static int clamp(int i) { return Math.max(0, Math.min(NAMES.length - 1, i)); }

    /** Medida final para una imagen de w x h (sin agrandar). */
    public static int[] outSize(int i, int w, int h) {
        int[] s = SIZE[clamp(i)];
        float k = 1f;
        switch (s[0]) {
            case LONG: k = s[1] / (float) Math.max(w, h); break;
            case WIDTH: k = s[1] / (float) w; break;
            case BOX: k = Math.min(s[1] / (float) w, s[2] / (float) h); break;
            default: break;
        }
        if (k >= 1f) return new int[]{w, h};
        return new int[]{Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k))};
    }
}
