package com.pacco.animecut.core;

/**
 * v8.88 Marcar: calculos de Tapar (cuadritos y borroso) y de la Lupa. Sin Android: se prueba en
 * la computadora. Colores ARGB sin premultiplicar.
 */
public final class MarkFx {
    private MarkFx() { }

    /**
     * Cuadritos de lado 'b'. La cuadricula sale de la esquina de la IMAGEN (ox, oy = donde empieza
     * este pedazo): dos tapados juntos tienen los mismos cuadritos. Promedio con transparencia.
     */
    public static int[] pixelate(int[] src, int w, int h, int ox, int oy, int b) {
        b = Math.max(2, b);
        int[] out = new int[w * h];
        int gx0 = Math.floorDiv(ox, b), gy0 = Math.floorDiv(oy, b);
        int gx1 = Math.floorDiv(ox + w - 1, b), gy1 = Math.floorDiv(oy + h - 1, b);
        for (int gy = gy0; gy <= gy1; gy++) {
            int y0 = Math.max(0, gy * b - oy), y1 = Math.min(h, gy * b + b - oy);
            for (int gx = gx0; gx <= gx1; gx++) {
                int x0 = Math.max(0, gx * b - ox), x1 = Math.min(w, gx * b + b - ox);
                long sa = 0, sr = 0, sg = 0, sb = 0;
                int n = 0;
                for (int y = y0; y < y1; y++) {
                    int o = y * w;
                    for (int x = x0; x < x1; x++) {
                        int c = src[o + x], a = c >>> 24;
                        n++;
                        if (a == 0) continue;
                        sa += a;
                        sr += (long) ((c >> 16) & 255) * a;
                        sg += (long) ((c >> 8) & 255) * a;
                        sb += (long) (c & 255) * a;
                    }
                }
                int c = 0;
                if (sa > 0 && n > 0) {
                    int a = (int) (sa / n);
                    c = (a << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
                }
                for (int y = y0; y < y1; y++) java.util.Arrays.fill(out, y * w + x0, y * w + x1, c);
            }
        }
        return out;
    }

    /**
     * Borroso fuerte: tres pasadas de promedio de caja (radio r), con transparencia.
     * v8.91: con radio grande se trabaja en una copia chica (r/4 veces menor) y se agranda suave:
     * el resultado es casi igual, pero usa 16 a 100 veces menos memoria y tiempo.
     */
    public static int[] blur(int[] src, int w, int h, int r) {
        r = Math.max(1, r);
        int f = r >= 8 ? Math.max(2, r / 4) : 1;
        if (f > 1 && w / f >= 2 && h / f >= 2) {
            int sw = (w + f - 1) / f, sh = (h + f - 1) / f;
            int[] small = shrink(src, w, h, f, sw, sh);
            int[] bs = blurDirect(small, sw, sh, Math.max(1, Math.round(r / (float) f)));
            int[] out = new int[w * h];
            float k = 1f / f;
            for (int y = 0; y < h; y++) {
                float sy = (y + 0.5f) * k - 0.5f;
                for (int x = 0; x < w; x++) out[y * w + x] = sample(bs, sw, sh, (x + 0.5f) * k - 0.5f, sy);
            }
            return out;
        }
        return blurDirect(src, w, h, r);
    }

    /** Copia chica: cada punto es el promedio (con transparencia) de un cuadro f x f. */
    private static int[] shrink(int[] src, int w, int h, int f, int sw, int sh) {
        int[] out = new int[sw * sh];
        for (int gy = 0; gy < sh; gy++) {
            int y0 = gy * f, y1 = Math.min(h, y0 + f);
            for (int gx = 0; gx < sw; gx++) {
                int x0 = gx * f, x1 = Math.min(w, x0 + f);
                long sa = 0, sr = 0, sg = 0, sb = 0;
                int n = 0;
                for (int y = y0; y < y1; y++)
                    for (int x = x0; x < x1; x++) {
                        int c = src[y * w + x], a = c >>> 24;
                        n++;
                        if (a == 0) continue;
                        sa += a; sr += (long) ((c >> 16) & 255) * a; sg += (long) ((c >> 8) & 255) * a; sb += (long) (c & 255) * a;
                    }
                if (sa > 0) out[gy * sw + gx] = ((int) (sa / n) << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
            }
        }
        return out;
    }

    private static int[] blurDirect(int[] src, int w, int h, int r) {
        int n = w * h;
        // se trabaja premultiplicado para que lo transparente no oscurezca los bordes
        float[] a = new float[n], cr = new float[n], cg = new float[n], cb = new float[n];
        for (int i = 0; i < n; i++) {
            int c = src[i];
            float al = (c >>> 24) / 255f;
            a[i] = al;
            cr[i] = ((c >> 16) & 255) * al;
            cg[i] = ((c >> 8) & 255) * al;
            cb[i] = (c & 255) * al;
        }
        float[] t = new float[Math.max(w, h)];
        for (int pass = 0; pass < 3; pass++) {
            for (float[] ch : new float[][]{a, cr, cg, cb}) {
                box(ch, w, h, r, true, t);
                box(ch, w, h, r, false, t);
            }
        }
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            float al = a[i];
            if (al <= 0.002f) continue;
            int A = Math.min(255, Math.round(al * 255f));
            out[i] = (A << 24) | (clamp(cr[i] / al) << 16) | (clamp(cg[i] / al) << 8) | clamp(cb[i] / al);
        }
        return out;
    }

    private static int clamp(float v) {
        return v <= 0f ? 0 : v >= 255f ? 255 : Math.round(v);
    }

    /** Promedio de caja en filas (horiz) o columnas, con el borde repetido. */
    private static void box(float[] ch, int w, int h, int r, boolean horiz, float[] t) {
        int lines = horiz ? h : w, len = horiz ? w : h, step = horiz ? 1 : w;
        float inv = 1f / (2 * r + 1);
        for (int l = 0; l < lines; l++) {
            int base = horiz ? l * w : l;
            float s = 0f;
            for (int k = -r; k <= r; k++) s += ch[base + Math.max(0, Math.min(len - 1, k)) * step];
            for (int i = 0; i < len; i++) {
                t[i] = s * inv;
                int add = Math.min(len - 1, i + r + 1), sub = Math.max(0, i - r);
                s += ch[base + add * step] - ch[base + sub * step];
            }
            for (int i = 0; i < len; i++) ch[base + i * step] = t[i];
        }
    }

    /** Un pedazo (ancho cw, alto ch) de una imagen de ancho w, desde (x0, y0). */
    public static int[] crop(int[] src, int w, int x0, int y0, int cw, int ch) {
        int[] out = new int[cw * ch];
        for (int y = 0; y < ch; y++) System.arraycopy(src, (y0 + y) * w + x0, out, y * cw, cw);
        return out;
    }

    /** Lectura suave (bilineal, con transparencia) en (x, y); afuera = transparente. */
    public static int sample(int[] src, int w, int h, float x, float y) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        float fx = x - x0, fy = y - y0;
        float sa = 0, sr = 0, sg = 0, sb = 0;
        for (int k = 0; k < 4; k++) {
            int xx = x0 + (k & 1), yy = y0 + (k >> 1);
            float wt = ((k & 1) == 1 ? fx : 1f - fx) * ((k >> 1) == 1 ? fy : 1f - fy);
            if (wt <= 0f) continue;
            xx = Math.max(0, Math.min(w - 1, xx));
            yy = Math.max(0, Math.min(h - 1, yy));
            int c = src[yy * w + xx];
            float a = (c >>> 24) / 255f * wt;
            sa += a;
            sr += ((c >> 16) & 255) * a;
            sg += ((c >> 8) & 255) * a;
            sb += (c & 255) * a;
        }
        if (sa <= 0.002f) return 0;
        return (clamp(sa * 255f) << 24) | (clamp(sr / sa) << 16) | (clamp(sg / sa) << 8) | clamp(sb / sa);
    }
}
