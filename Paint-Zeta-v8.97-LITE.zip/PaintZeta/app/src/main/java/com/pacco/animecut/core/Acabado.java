package com.pacco.animecut.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * v8.60 ACABADO (Java puro, sin Android: se prueba en PC).
 *
 * Toma las zonas de "Colorear" (mascara + color base que eligio la usuaria) y el dibujo de tinta,
 * y hace el acabado de ilustracion: sombra de color, segunda sombra en huecos, sombra del pelo
 * sobre la cara, luces, luz de borde, pelo con degradado y brillo que sigue los mechones, ojos,
 * rubor, lineas de color, resplandor y tinte. Todo queda DENTRO de la mascara de cada zona.
 *
 * Por que antes salian manchas: la sombra era la mascara de la zona corrida unos pixeles (si/no),
 * con escalones y sin volumen. Ahora cada zona es una "almohada": se resuelve la ecuacion de
 * Poisson dentro de la zona (Ink-and-Ray, Sykora et al. 2014) a resolucion reducida, su raiz da
 * un perfil redondo SIN la cresta del eje medio, de ahi salen normales suaves; el sol da
 * s = n.L y el corte de luz/sombra es un smoothstep de ~1,5 px a resolucion final. Las islitas se
 * quitan antes del corte. La sombra del pelo usa una distancia con signo (transformada de
 * distancia de Felzenszwalb-Huttenlocher) muestreada con bilineal: borde liso.
 *
 * La vista previa y el resultado final son LA MISMA cuenta a resolucion completa (no hay otro
 * camino). Lo que no depende del sol (volumen, lineas, pelo, sombras con signo) se calcula una sola
 * vez en {@link Session}; al mover el sol solo se rehace s = n.L, el corte y la mezcla.
 *
 * Nota honesta: el inflado 2D no entiende anatomia; los pinceles Mas sombra / Mas luz y Quitar
 * mancha estan para corregir. Las detecciones de pelo, cara y ojos son reglas simples y, si no
 * hay seguridad, ese paso se OMITE.
 */
public final class Acabado {
    private Acabado() { }

    /** Lo que mueve la usuaria. */
    public static final class Params {
        /** Sol en coordenadas 0..1 de la imagen (puede quedar afuera, -0.5..1.5). */
        public float sunX = 0.15f, sunY = 0.05f;
        /** 0..100: fuerza de sombras y luces. */
        public int strength = 60;
        /** Lineas de color (marron en piel, tono oscuro del pelo...). false = negras como estan. */
        public boolean colorLines = true;
        /** v8.61: tipo de luz (ver LIGHT_NAMES). */
        public int lightType = 0;
        /** v8.61: borrador rapido mientras se arrastra (1 de cada 4 pixeles, sin resplandor). */
        public boolean draft = false;
        /** v8.63: false = Manhwa (degradados suaves), true = Anime (sombra dura, contraluz fuerte). */
        public boolean anime = false;
        /** v8.63: color de las puntas del pelo (0 = sin puntas de color). */
        public int hairTip = 0;
        /** v8.63: luces extra (luna, otro sol, lampara...): hasta MAX_EXTRA, cada una con lugar y tipo. */
        public int extraN = 0;
        public float[] exX = new float[MAX_EXTRA], exY = new float[MAX_EXTRA];
        public int[] exType = new int[MAX_EXTRA];

        public Params copy() {
            Params p = new Params();
            p.sunX = sunX; p.sunY = sunY; p.strength = strength; p.colorLines = colorLines;
            p.lightType = lightType; p.draft = draft; p.anime = anime; p.hairTip = hairTip;
            p.extraN = extraN; p.exX = exX.clone(); p.exY = exY.clone(); p.exType = exType.clone();
            return p;
        }

        /** Para la clave del cache. */
        String extrasKey() {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < extraN; i++) b.append(exX[i]).append(',').append(exY[i]).append(',').append(exType[i]).append(';');
            return b.toString();
        }
    }

    /** v8.63: luces extra ademas del sol principal. */
    public static final int MAX_EXTRA = 2;

    /** v8.63: estampados propios (genericos) para la ropa. 0 = ninguno. */
    public static final String[] PATTERN_NAMES = {"Quitar", "Cuadros", "Rombos", "Rayas", "Lunares", "Olas"};

    /** Cuanto cubre el estampado en (x,y): 0..1 con antialias (4 muestras). */
    static float patternAt(int type, float x, float y, float cell) {
        if (type <= 0) return 0f;
        float acc = 0f;
        for (int k = 0; k < 4; k++) {
            float sx = (x + (k & 1) * 0.5f + 0.25f) / cell, sy = (y + (k >> 1) * 0.5f + 0.25f) / cell;
            boolean on;
            switch (type) {
                case 1: on = ((((int) Math.floor(sx)) + ((int) Math.floor(sy))) & 1) == 0; break;
                case 2: {
                    float fx = sx - (float) Math.floor(sx) - 0.5f, fy = sy * 0.75f - (float) Math.floor(sy * 0.75f) - 0.5f;
                    on = Math.abs(fx) + Math.abs(fy) < 0.40f;
                    break;
                }
                case 3: { float d = (sx + sy) * 0.5f; on = d - (float) Math.floor(d) < 0.42f; break; }
                case 4: {
                    float fx = sx - (float) Math.floor(sx) - 0.5f, fy = sy - (float) Math.floor(sy) - 0.5f;
                    on = fx * fx + fy * fy < 0.075f;
                    break;
                }
                default: {
                    float d = sy * 0.8f + 0.22f * (float) Math.sin(sx * Math.PI);
                    on = d - (float) Math.floor(d) < 0.38f;
                    break;
                }
            }
            if (on) acc += 0.25f;
        }
        return acc;
    }

    /** v8.61: tipos de luz. El sol (o la luna) se sigue arrastrando igual. */
    public static final String[] LIGHT_NAMES = {"☀ Día", "🌇 Tarde", "🌅 Atardecer", "🌕 Luna llena", "🌙 Media luna", "💡 Interior"};

    /** Como cambia cada tipo de luz los colores del acabado. */
    static final class LK {
        float[] light = {1f, 1f, 1f};     // color de la luz (multiplica luces, brillo y borde)
        float[] rim = {1f, 1f, 1f};
        float rimMul = 1f;
        float[] shTint = {1f, 1f, 1f};    // las sombras se tinen hacia este color
        float shAmt = 0f;
        float dim = 1f;                   // noche: todo un poco mas oscuro (salvo lineas)
        float shadowMul = 1f;             // fuerza de las sombras
        float[] tintTop = {1.0f, 0.80f, 0.58f}, tintBot = {0.55f, 0.66f, 1.0f};
        float tintOp = 0.12f, glowMul = 1f;
    }

    static LK lightKind(int type) {
        LK l = new LK();
        switch (type) {
            case 1: // tarde dorada
                l.light = new float[]{1f, 0.86f, 0.62f}; l.rim = new float[]{1f, 0.80f, 0.48f}; l.rimMul = 1.2f;
                l.shTint = new float[]{0.86f, 0.72f, 0.92f}; l.shAmt = 0.25f;
                l.tintTop = new float[]{1f, 0.78f, 0.50f}; l.tintBot = new float[]{0.72f, 0.60f, 0.92f}; l.tintOp = 0.17f; l.glowMul = 1.2f;
                break;
            case 2: // atardecer: naranja y rosa, contraluz fuerte
                l.light = new float[]{1f, 0.66f, 0.55f}; l.rim = new float[]{1f, 0.58f, 0.48f}; l.rimMul = 1.6f;
                l.shTint = new float[]{0.70f, 0.58f, 0.95f}; l.shAmt = 0.35f; l.shadowMul = 1.1f;
                l.tintTop = new float[]{1f, 0.62f, 0.50f}; l.tintBot = new float[]{0.52f, 0.46f, 0.88f}; l.tintOp = 0.22f; l.glowMul = 1.35f;
                break;
            case 3: // luna llena: plateada y brillante, sombras frias (la piel NO se vuelve celeste)
                l.light = new float[]{0.86f, 0.92f, 1f}; l.rim = new float[]{0.78f, 0.90f, 1f}; l.rimMul = 1.45f;
                l.shTint = new float[]{0.62f, 0.68f, 0.98f}; l.shAmt = 0.45f; l.shadowMul = 1.15f;
                l.dim = 0.90f;
                l.tintTop = new float[]{0.80f, 0.86f, 1f}; l.tintBot = new float[]{0.48f, 0.52f, 0.82f}; l.tintOp = 0.20f; l.glowMul = 1.45f;
                break;
            case 4: // media luna: mas tenue
                l.light = new float[]{0.74f, 0.80f, 0.96f}; l.rim = new float[]{0.66f, 0.76f, 0.98f}; l.rimMul = 0.9f;
                l.shTint = new float[]{0.55f, 0.58f, 0.92f}; l.shAmt = 0.55f; l.shadowMul = 1.2f;
                l.dim = 0.80f;
                l.tintTop = new float[]{0.62f, 0.68f, 0.92f}; l.tintBot = new float[]{0.36f, 0.38f, 0.70f}; l.tintOp = 0.24f; l.glowMul = 0.8f;
                break;
            case 5: // interior: suave y pareja
                l.light = new float[]{1f, 0.95f, 0.86f}; l.rim = new float[]{1f, 0.93f, 0.82f}; l.rimMul = 0.5f;
                l.shTint = new float[]{0.92f, 0.85f, 0.88f}; l.shAmt = 0.15f; l.shadowMul = 0.75f;
                l.tintTop = new float[]{1f, 0.90f, 0.75f}; l.tintBot = new float[]{0.85f, 0.82f, 0.90f}; l.tintOp = 0.10f; l.glowMul = 0.8f;
                break;
            default: break;
        }
        return l;
    }

    public interface Cancel { boolean cancelled(); }

    /** Se lanza si la vista previa quedo vieja (se movio el sol otra vez). */
    public static final class Cancelled extends RuntimeException {
        public Cancelled() { super(null, null, false, false); }
    }

    static boolean DBG = false;
    static final Cancel NEVER = new Cancel() { public boolean cancelled() { return false; } };

    // ==================================================================================== util

    static float smooth(float e0, float e1, float x) {
        if (e1 <= e0) return x < e0 ? 0f : 1f;
        float t = (x - e0) / (e1 - e0);
        t = t < 0f ? 0f : t > 1f ? 1f : t;
        return t * t * (3f - 2f * t);
    }

    static float clamp01(float v) { return v < 0f ? 0f : v > 1f ? 1f : v; }

    static int clampi(int v, int a, int b) { return v < a ? a : v > b ? b : v; }

    /** Percentil q de un histograma de 256. */
    static int pct(int[] hist, int n, float q) {
        int lim = Math.max(1, Math.round(n * q)), s = 0;
        for (int i = 0; i < 256; i++) { s += hist[i]; if (s >= lim) return i; }
        return 255;
    }

    // ------------------------------------------------------------------ transformada de distancia
    private static final float INF = 1e20f;

    /** Una pasada 1D de Felzenszwalb-Huttenlocher (distancia al cuadrado). */
    private static void dt1(float[] f, int n, float[] d, int[] v, float[] z) {
        int k = 0;
        v[0] = 0;
        z[0] = -INF;
        z[1] = INF;
        for (int q = 1; q < n; q++) {
            if (f[q] >= INF) continue;
            if (f[v[k]] >= INF) { v[k] = q; continue; }
            float s;
            while (true) {
                int p = v[k];
                s = ((f[q] + q * (float) q) - (f[p] + p * (float) p)) / (2f * (q - p));
                if (s <= z[k] && k > 0) { k--; continue; }
                break;
            }
            k++;
            v[k] = q;
            z[k] = s;
            z[k + 1] = INF;
        }
        if (f[v[0]] >= INF) { for (int q = 0; q < n; q++) d[q] = INF; return; }
        k = 0;
        for (int q = 0; q < n; q++) {
            while (z[k + 1] < q) k++;
            int p = v[k];
            d[q] = (q - p) * (float) (q - p) + f[p];
        }
    }

    /**
     * Distancia euclidea exacta (en pixeles) de cada celda a la celda "semilla" mas cercana.
     * seed[i] != 0 = semilla. Sin semillas: todo INF.
     */
    public static float[] edt(boolean[] seed, int w, int h) {
        float[] g = new float[w * h];
        for (int i = 0; i < g.length; i++) g[i] = seed[i] ? 0f : INF;
        int m = Math.max(w, h);
        float[] f = new float[m], d = new float[m], z = new float[m + 1];
        int[] v = new int[m];
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) f[y] = g[y * w + x];
            dt1(f, h, d, v, z);
            for (int y = 0; y < h; y++) g[y * w + x] = d[y];
        }
        for (int y = 0; y < h; y++) {
            int o = y * w;
            for (int x = 0; x < w; x++) f[x] = g[o + x];
            dt1(f, w, d, v, z);
            for (int x = 0; x < w; x++) g[o + x] = d[x] >= INF ? INF : (float) Math.sqrt(d[x]);
        }
        return g;
    }

    // ------------------------------------------------------------------ desenfoque de caja (3 pasadas ~ gauss)
    static void blur(float[] a, int w, int h, float sigma) {
        if (sigma < 0.5f) return;
        int r = Math.max(1, Math.round(sigma * 0.95f));
        for (int k = 0; k < 3; k++) ZoneTone.box(a, w, h, r);
    }

    /** Desenfoque que solo promedia celdas 'in' (no oscurece el borde con lo de afuera). */
    static void blurMasked(float[] a, boolean[] in, int w, int h, float sigma) {
        if (sigma < 0.5f) return;
        float[] wt = new float[a.length];
        for (int i = 0; i < a.length; i++) { if (in[i]) wt[i] = 1f; else a[i] = 0f; }
        blur(a, w, h, sigma);
        blur(wt, w, h, sigma);
        for (int i = 0; i < a.length; i++) if (in[i] && wt[i] > 1e-4f) a[i] /= wt[i];
    }

    // ------------------------------------------------------------------ Poisson (inflado)
    /**
     * Resuelve -lap(f) = 1 dentro de 'in' con f = 0 afuera (SOR). Arranca de una estimacion por
     * distancia, asi bastan pocas vueltas aun en 200x200.
     */
    static float[] poisson(boolean[] in, int w, int h, Cancel c) {
        float[] d = edtInside(in, w, h);
        float dm = 1f;
        for (int i = 0; i < d.length; i++) if (in[i] && d[i] > dm) dm = d[i];
        float[] f = new float[w * h];
        for (int i = 0; i < f.length; i++) if (in[i]) f[i] = d[i] * (2f * dm - d[i]) / 3f;
        int iters = Math.max(60, Math.min(260, (int) (dm * 6f)));
        float om = 1.85f;
        for (int it = 0; it < iters; it++) {
            if ((it & 15) == 0 && c.cancelled()) throw new Cancelled();
            for (int y = 1; y < h - 1; y++) {
                int o = y * w;
                for (int x = 1; x < w - 1; x++) {
                    int i = o + x;
                    if (!in[i]) continue;
                    float nb = f[i - 1] + f[i + 1] + f[i - w] + f[i + w];
                    float gs = (nb + 1f) * 0.25f;
                    f[i] += om * (gs - f[i]);
                }
            }
        }
        return f;
    }

    /** Distancia de cada celda de 'in' al afuera (0 afuera). El borde de la caja cuenta como afuera. */
    static float[] edtInside(boolean[] in, int w, int h) {
        boolean[] out = new boolean[in.length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                out[i] = !in[i] || x == 0 || y == 0 || x == w - 1 || y == h - 1;
            }
        float[] d = edt(out, w, h);
        for (int i = 0; i < d.length; i++) if (d[i] >= INF) d[i] = 0f;
        return d;
    }

    /**
     * Normales (nx, ny, nz) de la almohada h = sqrt(f/fmax). Se escalan con el radio para que
     * un circulo de cualquier tamano de una esfera. Las celdas de afuera copian a sus vecinas
     * (para que el bilineal en el borde no traiga normales planas).
     */
    static float[][] normals(float[] f, boolean[] in, int w, int h) {
        float fm = 1e-6f;
        for (int i = 0; i < f.length; i++) if (in[i] && f[i] > fm) fm = f[i];
        float[] hh = new float[f.length];
        for (int i = 0; i < f.length; i++) hh[i] = in[i] ? (float) Math.sqrt(Math.max(0f, f[i]) / fm) : 0f;
        float rp = 2f * (float) Math.sqrt(fm);
        float[] nx = new float[f.length], ny = new float[f.length], nz = new float[f.length];
        boolean[] done = new boolean[f.length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (!in[i]) { nz[i] = 1f; continue; }
                float l = x > 0 ? hh[i - 1] : 0f, r = x < w - 1 ? hh[i + 1] : 0f;
                float u = y > 0 ? hh[i - w] : 0f, dn = y < h - 1 ? hh[i + w] : 0f;
                float gx = (r - l) * 0.5f * rp, gy = (dn - u) * 0.5f * rp;
                float gm = (float) Math.hypot(gx, gy);
                if (gm > 3.2f) { gx *= 3.2f / gm; gy *= 3.2f / gm; }
                float inv = 1f / (float) Math.sqrt(gx * gx + gy * gy + 1f);
                nx[i] = -gx * inv; ny[i] = -gy * inv; nz[i] = inv;
                done[i] = true;
            }
        // afuera: copiar de las vecinas (2 vueltas)
        for (int pass = 0; pass < 2; pass++) {
            boolean[] nd = done.clone();
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int i = y * w + x;
                    if (done[i]) continue;
                    float sx = 0, sy = 0, sz = 0;
                    int n = 0;
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx, yy = y + dy;
                            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                            int j = yy * w + xx;
                            if (!done[j]) continue;
                            sx += nx[j]; sy += ny[j]; sz += nz[j]; n++;
                        }
                    if (n == 0) continue;
                    float m = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
                    if (m < 1e-6f) continue;
                    nx[i] = sx / m; ny[i] = sy / m; nz[i] = sz / m;
                    nd[i] = true;
                }
            done = nd;
        }
        return new float[][]{nx, ny, nz, hh};
    }

    // ------------------------------------------------------------------ hilos
    /** v8.62: segun el nivel del celular (gama baja 2, media 3, alta 4). */
    private static final int THREADS = DeviceTier.threads();
    private static java.util.concurrent.ExecutorService pool;

    interface Rows { void run(int y0, int y1); }

    static synchronized java.util.concurrent.ExecutorService pool() {
        if (pool == null) {
            pool = java.util.concurrent.Executors.newFixedThreadPool(THREADS, new java.util.concurrent.ThreadFactory() {
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "pz-acabado");
                    t.setDaemon(true);
                    return t;
                }
            });
        }
        return pool;
    }

    /** Reparte filas [0,h) entre los hilos y espera. */
    static void parallel(int h, final Rows body) {
        int n = Math.min(THREADS, Math.max(1, h / 32));
        if (n <= 1) { body.run(0, h); return; }
        final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(n);
        final Throwable[] err = new Throwable[1];
        int step = (h + n - 1) / n;
        for (int k = 0; k < n; k++) {
            final int a = k * step, b = Math.min(h, a + step);
            pool().execute(new Runnable() {
                public void run() {
                    try { if (a < b) body.run(a, b); }
                    catch (Throwable t) { synchronized (err) { if (err[0] == null) err[0] = t; } }
                    finally { done.countDown(); }
                }
            });
        }
        try { done.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new Cancelled(); }
        if (err[0] instanceof RuntimeException) throw (RuntimeException) err[0];
        if (err[0] instanceof Error) throw (Error) err[0];
    }

    // ==================================================================================== colores

    /** Colores del acabado para un color base (sRGB 0..1). */
    static final class Pal {
        float[] base, s1, s2, light, rim, line, ring;
        boolean skin, dark, neutral;
    }

    static float[] rgb(int c) { return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f}; }

    static int lab(float L, float C, float hue) {
        return ZoneTone.fromOklab(Math.max(0f, Math.min(1f, L)), C * (float) Math.cos(hue), C * (float) Math.sin(hue));
    }

    /** Gira el tono 'h' hacia 'target' (radianes) como mucho 'amt' radianes. */
    static float toward(float h, float target, float amt) {
        float d = (float) Math.atan2(Math.sin(target - h), Math.cos(target - h));
        if (Math.abs(d) <= amt) return target;
        return h + Math.signum(d) * amt;
    }

    /** Piel: tono calido (entre rojo y amarillo), croma moderado y claro. */
    static boolean isSkin(int c) {
        float[] k = ZoneTone.oklab(c);
        float C = (float) Math.hypot(k[1], k[2]);
        float hue = (float) Math.toDegrees(Math.atan2(k[2], k[1]));
        return k[0] > 0.55f && k[0] < 0.97f && C > 0.018f && C < 0.115f && hue > 18f && hue < 80f;
    }

    static Pal palette(int base) {
        Pal p = new Pal();
        float[] k = ZoneTone.oklab(base);
        float L = k[0], C = (float) Math.hypot(k[1], k[2]);
        float h = (float) Math.atan2(k[2], k[1]);
        final float VIOLET = (float) Math.toRadians(305), RED = (float) Math.toRadians(22), WARM = (float) Math.toRadians(85);
        p.skin = isSkin(base);
        p.dark = L < 0.38f;
        p.neutral = C < 0.03f;
        p.base = rgb(base);
        int s1, s2, li, line;
        if (p.skin) {
            // piel: sombra rojiza/rosada (nunca gris)
            s1 = lab(L * 0.87f, Math.max(C * 1.30f, 0.045f), toward(h, RED, (float) Math.toRadians(14)));
            s2 = lab(L * 0.74f, Math.max(C * 1.45f, 0.06f), toward(h, RED, (float) Math.toRadians(24)));
            li = lab(L + (1f - L) * 0.55f, C * 0.75f, toward(h, WARM, (float) Math.toRadians(8)));
            line = lab(Math.max(0.24f, L * 0.42f), Math.max(0.05f, C * 0.95f), toward(h, RED, (float) Math.toRadians(10)));
        } else if (p.neutral) {
            // blanco, gris, negro: sombra lavanda/azulada
            float ls = L > 0.8f ? L * 0.83f : L * 0.78f;
            s1 = lab(ls, 0.035f + C * 0.5f, VIOLET - (float) Math.toRadians(25));
            s2 = lab(ls * 0.82f, 0.045f + C * 0.5f, VIOLET);
            li = lab(Math.min(1f, L + (1f - L) * 0.5f + 0.02f), C * 0.5f + 0.01f, WARM);
            line = lab(Math.max(0.16f, L * 0.35f), 0.03f, VIOLET - (float) Math.toRadians(20));
        } else {
            float dl = p.dark ? 0.72f : 0.80f;
            s1 = lab(L * dl, C * 1.12f + 0.012f, toward(h, VIOLET, (float) Math.toRadians(16)));
            s2 = lab(L * dl * 0.80f, C * 1.2f + 0.015f, toward(h, VIOLET, (float) Math.toRadians(28)));
            li = lab(L + (1f - L) * (p.dark ? 0.32f : 0.45f), C * 0.9f, toward(h, WARM, (float) Math.toRadians(8)));
            line = lab(Math.max(0.12f, L * 0.38f), Math.max(0.03f, C * 0.9f), toward(h, RED, (float) Math.toRadians(8)));
        }
        p.s1 = rgb(s1);
        p.s2 = rgb(s2);
        p.light = rgb(li);
        float[] lr = rgb(li);
        p.rim = new float[]{lr[0] * 0.5f + 0.5f, lr[1] * 0.5f + 0.47f, lr[2] * 0.5f + 0.42f};
        p.line = rgb(line);
        // brillo del pelo: mas claro y tibio que la base, nunca blanco puro
        p.ring = rgb(lab(Math.min(0.97f, L + (1f - L) * 0.62f + 0.06f), C * 0.7f, toward(h, WARM, (float) Math.toRadians(10))));
        return p;
    }

    // ==================================================================================== sesion

    /** Una zona con todo lo que no depende del sol. */
    static final class ZCtx {
        int idx;
        ZoneTone.Zone z;
        int x0, y0, w, h;          // recuadro en la imagen (recortado)
        int f, gw, gh;             // celda de la grilla (pixeles) y tamano de la grilla
        boolean[] in;              // grilla: dentro de la zona
        float[] nx, ny, nz;        // normales combinadas (zona + personaje)
        float[] edit;              // Mas sombra / Mas luz (+ = mas luz)
        float[] dens;              // densidad de lineas normalizada (oclusion), grilla
        int area;
        boolean thin, bg, skin, hair, eye, face;
        /**
         * v8.83: zonas del mismo color pegadas (la misma parte pintada en varias veces, o retocada
         * a mano) comparten UN volumen: el del grupo. Sin esto cada pedazo era una almohadita
         * aparte y quedaban parches planos o de sombra con forma de cuadro.
         */
        ZCtx grp;
        boolean isGroup;
        int paper = 245, p50 = 245;
        boolean darkZone, author;
        /**
         * v8.85: el dibujo YA trae sus sombras (grises pintados por el autor). 0 = no (solo lineas),
         * 1 = si. Con sombras propias el acabado las SIGUE (les da color) y la luz del sol es un
         * degradado ancho que llega a toda la parte; no se inventa otra sombra encima (parches).
         */
        float follow;
        int refL = 245;            // gris "claro tipico" de la parte (lo que queda del color base)
        int nSh, nAll;             // pixeles con sombra del autor / pixeles sin linea
        int[] hist;                // grises de la zona (solo al preparar)
        float[] uLut;              // gris del dibujo -> cuanta sombra (0 luz .. 1 negro)
        float rpx;                 // radio aproximado en pixeles
        // sombra proyectada (solo piel con algo encima)
        float[] sdf; int sx0, sy0, sw, sh;
        // pelo
        float hairTop0, faceTop; boolean ring;
        int[] colTop;              // primera fila de pelo por columna (relativa)
        float[] licN;              // brillo en mechones (0..1) a resolucion completa del recuadro, o null
        // ojos
        float eyeCx, eyeCy, eyeRx, eyeRy;
        boolean eyeOwnHL;          // el dibujo ya trae brillo en el ojo: no se agrega otro
        // v8.63: sombra del menton cuando cara y cuello son la misma zona
        float chinY = -1f, neckCx, neckHalfW, chinDepth;
        int[] chinCol;
        boolean[] foldG;           // v8.63: celdas de la grilla con linea de pliegue (de adentro)
        // v8.63: puntas del pelo
        int[] colBot;
        boolean tipZone;          // pelo (o del mismo color que el pelo): lleva puntas de color
        // v8.63: material (0 normal, 1 brillante) y estampado
        int material, pattern, patColor;
    }

    public static final class Session {
        public final int W, H;
        final float D;
        final List<ZoneTone.Zone> zones;
        final int[] ref;
        final byte[] lum;          // gris del dibujo (0..255) en la caja de union
        final byte[] lineA;        // cuanto es linea (0..255) en la caja de union
        final boolean colored;
        int ux0, uy0, ux1, uy1, uw, uh;   // caja de union (+ margen)
        short[] owner;             // zona de arriba en cada pixel de la caja (+1), 0 = ninguna
        ZCtx[] ctx;
        // personaje
        float charCx, charCy;
        int cgf, cgw, cgh, cgx0, cgy0;
        float[] cnx, cny;          // normales del personaje (para la luz de borde)
        float[] dExt;              // distancia al exterior (caja de union), para la luz de borde
        int faceIdx = -1;
        final List<Integer> eyes = new ArrayList<Integer>();
        public int hairZones, skinZones;
        /** Solo pruebas: si no es null, guarda la sombra 1 de cada pixel (caja de union). */
        float[] dbgShadow;
        public long buildMs;
        /** Historial de retoques (para deshacer el ultimo dentro del Acabado). */
        private final ArrayList<float[][]> undoEdits = new ArrayList<float[][]>();

        /** Prepara todo lo que no depende del sol. Pesado: llamar fuera del hilo de la pantalla. */
        public Session(int[] ref, int W, int H, List<ZoneTone.Zone> zones, Cancel c) {
            long t0 = System.currentTimeMillis();
            if (c == null) c = NEVER;
            this.W = W; this.H = H; this.ref = ref;
            this.zones = new ArrayList<ZoneTone.Zone>(zones);
            D = (float) Math.sqrt((double) W * W + (double) H * H);
            colored = LineArt.isColored(ref);
            // caja de union
            int x0 = W, y0 = H, x1 = 0, y1 = 0;
            for (ZoneTone.Zone z : this.zones) {
                x0 = Math.min(x0, z.x); y0 = Math.min(y0, z.y);
                x1 = Math.max(x1, z.x + z.w); y1 = Math.max(y1, z.y + z.h);
            }
            int pad = 6;
            ux0 = Math.max(0, x0 - pad); uy0 = Math.max(0, y0 - pad);
            ux1 = Math.min(W, x1 + pad); uy1 = Math.min(H, y1 + pad);
            if (ux1 <= ux0 || uy1 <= uy0) { ux0 = uy0 = 0; ux1 = uy1 = 1; }
            uw = ux1 - ux0; uh = uy1 - uy0;
            int un = uw * uh;
            lum = new byte[un];
            lineA = new byte[un];
            owner = new short[un];
            for (int y = 0; y < uh; y++) {
                int gy = y + uy0, o = y * uw;
                for (int x = 0; x < uw; x++) lum[o + x] = (byte) ZoneTone.lum(ref[gy * W + x + ux0]);
            }
            int nz = this.zones.size();
            for (int k = 0; k < nz; k++) {
                ZoneTone.Zone z = this.zones.get(k);
                for (int y = 0; y < z.h; y++) {
                    int gy = y + z.y - uy0;
                    if (gy < 0 || gy >= uh) continue;
                    for (int x = 0; x < z.w; x++) {
                        if ((z.m[y * z.w + x] & 0xFF) < 128) continue;
                        int gx = x + z.x - ux0;
                        if (gx < 0 || gx >= uw) continue;
                        owner[gy * uw + gx] = (short) (k + 1);
                    }
                }
            }
            if (c.cancelled()) throw new Cancelled();
            ctx = new ZCtx[nz];
            long big = (long) W * H * 35 / 100;
            int[] ghist = new int[256];
            int gn = 0;
            for (int k = 0; k < nz; k++) {
                ZCtx q = new ZCtx();
                q.idx = k;
                q.z = this.zones.get(k);
                q.x0 = Math.max(0, q.z.x); q.y0 = Math.max(0, q.z.y);
                q.w = Math.min(W, q.z.x + q.z.w) - q.x0; q.h = Math.min(H, q.z.y + q.z.h) - q.y0;
                if (q.w <= 0 || q.h <= 0) { q.w = q.h = 0; ctx[k] = q; continue; }
                q.area = q.z.area();
                // fondo: muy grande, o grande y pegado a 2 o mas bordes de la imagen
                int sides = (q.z.x <= 1 ? 1 : 0) + (q.z.y <= 1 ? 1 : 0) + (q.z.x + q.z.w >= W - 1 ? 1 : 0) + (q.z.y + q.z.h >= H - 1 ? 1 : 0);
                q.bg = q.area > big || (sides >= 2 && q.area > (long) W * H * 8 / 100 && edgeShare(q.z, W, H) > 0.15f);
                q.skin = isSkin(q.z.s.base);
                // papel y grises propios de la zona
                int[] hist = new int[256];
                int cnt = 0;
                for (int y = 0; y < q.z.h; y++)
                    for (int x = 0; x < q.z.w; x++) {
                        if ((q.z.m[y * q.z.w + x] & 0xFF) < 128) continue;
                        int gx = x + q.z.x - ux0, gy = y + q.z.y - uy0;
                        if (gx < 0 || gy < 0 || gx >= uw || gy >= uh) continue;
                        int v = lum[gy * uw + gx] & 0xFF;
                        hist[v]++; cnt++;
                        ghist[v]++; gn++;
                    }
                if (cnt > 0) {
                    q.paper = Math.max(60, pct(hist, cnt, 0.97f));
                    q.p50 = pct(hist, cnt, 0.5f);
                    q.refL = lightRef(hist, q.paper);
                    q.hist = hist;
                }
                ctx[k] = q;
            }
            int gpaper = gn > 0 ? Math.max(120, pct(ghist, gn, 0.97f)) : 245;
            for (ZCtx q : ctx) {
                if (q.w == 0) continue;
                if (q.area < 400) q.paper = Math.max(q.paper, gpaper);
                q.darkZone = q.p50 < 95 && !colored;
                q.author = !q.darkZone && q.p50 < q.paper - 22;
            }
            // v8.85: primero los grupos (la misma parte pintada en varios toques comparte papel y
            // grises): asi lo que es linea se mide igual en todos los pedazos, sin cortes entre ellos
            buildCharacter(c);
            buildGroups(c);
            buildFollow();
            // lineas: cuanto de linea tiene cada pixel.
            // v8.85: una linea es algo FINO y mas oscuro que lo que tiene alrededor. Se compara cada
            // pixel con el mismo dibujo "sin lineas finas" (cierre: lo mas claro cerca y luego lo mas
            // oscuro cerca). Una sombra ancha del dibujo, clara u oscura, ya no cuenta como linea:
            // antes salia a medias como linea, con cortes cuadrados (parches).
            {
                final int rr = Math.max(3, Math.round(0.003f * D));
                final byte[] bg = minMax(minMax(lum, uw, uh, rr, true), uw, uh, rr, false);
                final int gp = gpaper;
                parallel(uh, new Rows() {
                    public void run(int r0, int r1) {
                        for (int y = r0; y < r1; y++) {
                            int o = y * uw;
                            for (int x = 0; x < uw; x++) {
                                int ow = owner[o + x];
                                int P = ow > 0 ? ctx[ow - 1].paper : gp;
                                int v = lum[o + x] & 0xFF, b = Math.max(1, bg[o + x] & 0xFF);
                                float rel = clamp01((0.84f * b - v) / (0.40f * b));
                                float blk = clamp01((0.30f * P - v) / (0.12f * P));   // negro tinta de verdad
                                lineA[o + x] = (byte) Math.round(Math.max(rel, blk) * 255f);
                            }
                        }
                    }
                });
            }
            if (c.cancelled()) throw new Cancelled();
            for (ZCtx q : ctx) if (q.w > 0) buildZone(q, c);
            findRoles();
            buildDensity(c);
            for (ZCtx q : ctx) if (q.w > 0 && q.skin && !q.bg) buildCast(q, c);
            for (ZCtx q : ctx) if (q.w > 0 && q.hair) buildHair(q, c);
            for (int e : eyes) buildEye(ctx[e]);
            for (ZCtx q : ctx) if (q.w > 0) {
                q.material = q.z.s.material; q.pattern = q.z.s.pattern; q.patColor = q.z.s.patColor;
                buildFoldGrid(q);
                if (!q.hair && !q.bg && !q.tipZone)
                    for (ZCtx o : ctx) if (o != q && o.hair && o.z.s.base == q.z.s.base) {
                        // mismo color que el pelo (mechon que no se reconocio): tambien lleva puntas
                        q.colTop = new int[q.w];
                        for (int x = 0; x < q.w; x++) {
                            q.colTop[x] = -1;
                            for (int y = 0; y < q.h; y++)
                                if ((q.z.m[(y + q.y0 - q.z.y) * q.z.w + x + q.x0 - q.z.x] & 0xFF) >= 128) { q.colTop[x] = y; break; }
                        }
                        hairBottoms(q);
                        q.tipZone = true;
                        break;
                    }
            }
            if (faceIdx >= 0) buildChin(ctx[faceIdx]);
            buildMs = System.currentTimeMillis() - t0;
        }

        /**
         * Lo mas claro (max=true) o lo mas oscuro en un cuadro de radio r. El costo no depende de r
         * (metodo de van Herk: 3 comparaciones por pixel), asi no pesa en fotos grandes.
         */
        static byte[] minMax(final byte[] a, final int w, final int h, final int r, final boolean max) {
            final byte[] t = new byte[a.length], o = new byte[a.length];
            parallel(h, new Rows() {
                public void run(int r0, int r1) {
                    int[] g = new int[w], hh = new int[w];
                    for (int y = r0; y < r1; y++) line(a, y * w, 1, w, r, max, g, hh, t);
                }
            });
            parallel(w, new Rows() {
                public void run(int c0, int c1) {
                    int[] g = new int[h], hh = new int[h];
                    for (int x = c0; x < c1; x++) line(t, x, w, h, r, max, g, hh, o);
                }
            });
            return o;
        }

        private static void line(byte[] a, int off, int step, int n, int r, boolean max, int[] g, int[] hh, byte[] out) {
            int k = 2 * r + 1;
            for (int i = 0; i < n; i++) {
                int v = a[off + i * step] & 0xFF;
                g[i] = i % k == 0 ? v : (max ? Math.max(g[i - 1], v) : Math.min(g[i - 1], v));
            }
            for (int i = n - 1; i >= 0; i--) {
                int v = a[off + i * step] & 0xFF;
                hh[i] = (i == n - 1 || (i + 1) % k == 0) ? v : (max ? Math.max(hh[i + 1], v) : Math.min(hh[i + 1], v));
            }
            for (int i = 0; i < n; i++) {
                int lo = Math.max(0, i - r), hi = Math.min(n - 1, i + r);
                int m = i < r ? g[hi] : max ? Math.max(hh[lo], g[hi]) : Math.min(hh[lo], g[hi]);
                out[off + i * step] = (byte) m;
            }
        }

        /** Gris "claro tipico": lo claro de la zona sin contar lineas ni brillos sueltos. */
        static int lightRef(int[] hist, int paper) {
            int ink = Math.max(40, Math.min(115, paper - 95));
            int c2 = 0;
            for (int i = ink; i < 256; i++) c2 += hist[i];
            if (c2 == 0) return paper;
            int need = Math.round(c2 * 0.85f), acc = 0;
            for (int i = ink; i < 256; i++) { acc += hist[i]; if (acc >= need) return Math.max(ink + 20, i); }
            return paper;
        }

        /**
         * v8.85: cuanto trae cada parte de sombra propia del dibujo. Las zonas del mismo grupo (la
         * misma parte pintada en varios toques) comparten la medida, y si el dibujo entero viene
         * sombreado todas las partes lo siguen.
         */
        private void buildFollow() {
            // medida comun del grupo
            java.util.HashMap<ZCtx, int[]> gh = new java.util.HashMap<ZCtx, int[]>();
            for (ZCtx q : ctx) {
                if (q.w == 0 || q.hist == null || q.grp == null) continue;
                int[] h = gh.get(q.grp);
                if (h == null) { h = new int[256]; gh.put(q.grp, h); }
                for (int i = 0; i < 256; i++) h[i] += q.hist[i];
            }
            for (ZCtx q : ctx) {
                if (q.w == 0 || q.hist == null) continue;
                int[] h = q.grp != null ? gh.get(q.grp) : q.hist;
                int n = 0;
                for (int i = 0; i < 256; i++) n += h[i];
                if (n == 0) continue;
                if (q.grp != null) {
                    q.paper = Math.max(60, pct(h, n, 0.97f));
                    q.p50 = pct(h, n, 0.5f);
                    q.darkZone = q.p50 < 95 && !colored;
                    q.author = !q.darkZone && q.p50 < q.paper - 22;
                    q.refL = lightRef(h, q.paper);
                }
                int ink = Math.max(40, Math.min(115, q.paper - 95));
                int all = 0, sh = 0, thr = Math.round(q.refL * 0.86f);
                for (int i = ink; i < 256; i++) { all += h[i]; if (i < thr) sh += h[i]; }
                q.nAll = all; q.nSh = sh;
            }
            long tAll = 0, tSh = 0;
            for (ZCtx q : ctx) if (q.w > 0 && !q.bg && !q.darkZone && q.hist != null) {
                // (de la zona sola, para no contar el grupo varias veces)
                int ink = Math.max(40, Math.min(115, q.paper - 95)), thr = Math.round(q.refL * 0.86f);
                for (int i = ink; i < 256; i++) { tAll += q.hist[i]; if (i < thr) tSh += q.hist[i]; }
            }
            float whole = tAll > 0 ? smooth(0.06f, 0.16f, tSh / (float) tAll) : 0f;
            for (ZCtx q : ctx) {
                if (q.w == 0) continue;
                float own = q.nAll > 0 ? smooth(0.05f, 0.14f, q.nSh / (float) q.nAll) : 0f;
                q.follow = q.darkZone || colored ? 0f : Math.max(own, whole);
                q.uLut = new float[256];
                float rl = Math.max(1f, q.refL);
                for (int v = 0; v < 256; v++) q.uLut[v] = 1f - (float) Math.pow(Math.min(1f, v / rl), 0.8);
                q.hist = null;
            }
        }

        // ------------------------------------------------------------ personaje (silueta) y exterior
        private void buildCharacter(Cancel c) {
            // union de zonas que NO son fondo, cerrada (tapa las lineas entre zonas)
            boolean[] u = new boolean[uw * uh];
            long sx = 0, sy = 0, n = 0;
            for (int i = 0; i < u.length; i++) {
                int ow = owner[i];
                if (ow > 0 && !ctx[ow - 1].bg) { u[i] = true; sx += i % uw; sy += i / uw; n++; }
            }
            charCx = n > 0 ? ux0 + sx / (float) n : W * 0.5f;
            charCy = n > 0 ? uy0 + sy / (float) n : H * 0.5f;
            int r = Math.max(2, Math.round(D * 0.0025f));
            boolean[] closed = close(u, uw, uh, r);
            // exterior: lo que no es personaje y toca el borde de la caja
            boolean[] ext = new boolean[u.length];
            int[] q = new int[u.length];
            int qh = 0, qt = 0;
            for (int x = 0; x < uw; x++) { qt = seed(ext, closed, q, qt, x); qt = seed(ext, closed, q, qt, (uh - 1) * uw + x); }
            for (int y = 0; y < uh; y++) { qt = seed(ext, closed, q, qt, y * uw); qt = seed(ext, closed, q, qt, y * uw + uw - 1); }
            while (qh < qt) {
                int i = q[qh++], x = i % uw, y = i / uw;
                if (x > 0) qt = seed(ext, closed, q, qt, i - 1);
                if (x < uw - 1) qt = seed(ext, closed, q, qt, i + 1);
                if (y > 0) qt = seed(ext, closed, q, qt, i - uw);
                if (y < uh - 1) qt = seed(ext, closed, q, qt, i + uw);
            }
            dExt = edt(ext, uw, uh);
            if (c.cancelled()) throw new Cancelled();
            // normales del personaje (grilla)
            cgf = Math.max(1, (int) Math.ceil(Math.max(uw, uh) / 200f));
            cgw = (uw + cgf - 1) / cgf + 2; cgh = (uh + cgf - 1) / cgf + 2;
            cgx0 = ux0; cgy0 = uy0;
            boolean[] cin = new boolean[cgw * cgh];
            for (int gy = 1; gy < cgh - 1; gy++)
                for (int gx = 1; gx < cgw - 1; gx++) {
                    int cntIn = 0, cntAll = 0;
                    for (int yy = (gy - 1) * cgf; yy < Math.min(uh, gy * cgf); yy++)
                        for (int xx = (gx - 1) * cgf; xx < Math.min(uw, gx * cgf); xx++) {
                            cntAll++;
                            if (!ext[yy * uw + xx]) cntIn++;
                        }
                    cin[gy * cgw + gx] = cntAll > 0 && cntIn * 2 >= cntAll;
                }
            float[] f = poisson(cin, cgw, cgh, c);
            float[][] nn = normals(f, cin, cgw, cgh);
            cnx = nn[0]; cny = nn[1];
            cnz = nn[2];
        }

        float[] cnz;

        private int seed(boolean[] ext, boolean[] wall, int[] q, int qt, int i) {
            if (ext[i] || wall[i]) return qt;
            ext[i] = true;
            q[qt++] = i;
            return qt;
        }

        /** Normal del personaje en un pixel de la imagen (bilineal). */
        void charNormal(float px, float py, float[] out) {
            float gx = (px - cgx0 + 0.5f) / cgf - 0.5f + 1f, gy = (py - cgy0 + 0.5f) / cgf - 0.5f + 1f;
            out[0] = bil(cnx, cgw, cgh, gx, gy);
            out[1] = bil(cny, cgw, cgh, gx, gy);
            out[2] = bil(cnz, cgw, cgh, gx, gy);
        }

        // ------------------------------------------------------------ volumen de una zona
        // ------------------------------------------------------------ v8.83: grupos del mismo color
        private void buildGroups(Cancel c) {
            int n = ctx.length;
            if (n < 2) return;
            int[] par = new int[n];
            for (int i = 0; i < n; i++) par[i] = i;
            int r = Math.max(4, Math.round(D * 0.006f));
            for (int i = 0; i < n; i++) {
                ZCtx a = ctx[i];
                if (a.w == 0 || a.bg) continue;
                for (int j = i + 1; j < n; j++) {
                    ZCtx b = ctx[j];
                    if (b.w == 0 || b.bg) continue;
                    if ((a.z.s.base & 0xFFFFFF) != (b.z.s.base & 0xFFFFFF) || a.z.s.finish != b.z.s.finish) continue;
                    int ra = find(par, i), rb = find(par, j);
                    if (ra == rb) continue;
                    if (touches(a, b, r) || touches(b, a, r)) par[ra] = rb;
                }
                if (c.cancelled()) throw new Cancelled();
            }
            java.util.HashMap<Integer, ArrayList<ZCtx>> groups = new java.util.HashMap<Integer, ArrayList<ZCtx>>();
            for (int i = 0; i < n; i++) {
                if (ctx[i].w == 0 || ctx[i].bg) continue;
                int root = find(par, i);
                ArrayList<ZCtx> l = groups.get(root);
                if (l == null) { l = new ArrayList<ZCtx>(); groups.put(root, l); }
                l.add(ctx[i]);
            }
            for (ArrayList<ZCtx> l : groups.values()) {
                if (l.size() < 2) continue;
                int x0 = W, y0 = H, x1 = 0, y1 = 0;
                ZCtx big = l.get(0);
                int area = 0;
                for (ZCtx q : l) {
                    x0 = Math.min(x0, q.x0); y0 = Math.min(y0, q.y0);
                    x1 = Math.max(x1, q.x0 + q.w); y1 = Math.max(y1, q.y0 + q.h);
                    if (q.area > big.area) big = q;
                    area += q.area;
                }
                int gw = x1 - x0, gh = y1 - y0;
                if (gw <= 0 || gh <= 0) continue;
                byte[] m = new byte[gw * gh];
                for (ZCtx q : l) {
                    ZoneTone.Zone z = q.z;
                    for (int y = q.y0; y < q.y0 + q.h; y++)
                        for (int x = q.x0; x < q.x0 + q.w; x++) {
                            byte v = z.m[(y - z.y) * z.w + x - z.x];
                            int o = (y - y0) * gw + x - x0;
                            if ((v & 0xFF) > (m[o] & 0xFF)) m[o] = v;
                        }
                }
                ZCtx g = new ZCtx();
                g.idx = -1;
                g.isGroup = true;
                g.z = new ZoneTone.Zone(x0, y0, gw, gh, m, big.z.s);
                g.x0 = x0; g.y0 = y0; g.w = gw; g.h = gh;
                g.area = area;
                g.skin = big.skin;
                g.paper = big.paper; g.p50 = big.p50; g.darkZone = big.darkZone; g.author = big.author;
                buildZone(g, c);
                for (ZCtx q : l) {
                    q.grp = g;
                    // el papel y los grises son los de la parte entera (un pedazo chico solo no alcanza)
                    q.paper = big.paper; q.p50 = big.p50; q.darkZone = big.darkZone; q.author = big.author;
                }
                if (c.cancelled()) throw new Cancelled();
            }
        }

        private static int find(int[] par, int i) {
            while (par[i] != i) { par[i] = par[par[i]]; i = par[i]; }
            return i;
        }

        private void buildZone(ZCtx q, Cancel c) {
            ZoneTone.Zone z = q.z;
            int side = Math.max(q.w, q.h);
            q.f = Math.max(1, (int) Math.ceil(side / 160f));
            int f = q.f;
            q.gw = (q.w + f - 1) / f + 2;
            q.gh = (q.h + f - 1) / f + 2;
            int gn = q.gw * q.gh;
            q.in = new boolean[gn];
            int cells = 0;
            for (int gy = 1; gy < q.gh - 1; gy++)
                for (int gx = 1; gx < q.gw - 1; gx++) {
                    int cntIn = 0, cntAll = 0;
                    for (int yy = (gy - 1) * f; yy < Math.min(q.h, gy * f); yy++)
                        for (int xx = (gx - 1) * f; xx < Math.min(q.w, gx * f); xx++) {
                            cntAll++;
                            int mx = xx + q.x0 - z.x, my = yy + q.y0 - z.y;
                            if ((z.m[my * z.w + mx] & 0xFF) >= 128) cntIn++;
                        }
                    boolean in = cntAll > 0 && cntIn * 2 >= cntAll;
                    q.in[gy * q.gw + gx] = in;
                    if (in) cells++;
                }
            q.edit = new float[gn];
            if (q.grp != null) {
                // v8.83: el volumen es el del grupo (misma parte, pintada en pedazos)
                ZCtx g = q.grp;
                q.nx = new float[gn]; q.ny = new float[gn]; q.nz = new float[gn];
                for (int gy = 0; gy < q.gh; gy++)
                    for (int gx = 0; gx < q.gw; gx++) {
                        int i = gy * q.gw + gx;
                        float px = q.x0 + (gx - 1 + 0.5f) * f - 0.5f, py = q.y0 + (gy - 1 + 0.5f) * f - 0.5f;
                        float ux = (px + 0.5f - g.x0) / g.f + 0.5f, uy = (py + 0.5f - g.y0) / g.f + 0.5f;
                        float ax = bil(g.nx, g.gw, g.gh, ux, uy), ay = bil(g.ny, g.gw, g.gh, ux, uy), az = bil(g.nz, g.gw, g.gh, ux, uy);
                        float mm = (float) Math.sqrt(ax * ax + ay * ay + az * az);
                        if (mm < 1e-6f) { ax = 0; ay = 0; az = 1; mm = 1; }
                        q.nx[i] = ax / mm; q.ny[i] = ay / mm; q.nz[i] = az / mm;
                    }
                q.rpx = g.rpx;
                q.thin = g.thin;
                return;
            }
            // v8.83: en el grupo se tapan las rendijas de las lineas entre pedazos
            if (q.isGroup) q.in = close(q.in, q.gw, q.gh, 1);
            // para el VOLUMEN se tapan los huecos chicos (ojos, boca, lineas sueltas): si no, cada
            // hueco hace un "crater" y salen manchas alrededor de los ojos
            boolean[] vin = fillHoles(q.in, q.gw, q.gh, Math.max(4, Math.round(cells * 0.12f)));
            for (boolean b : vin) if (b) cells++;
            cells = 0;
            for (boolean b : vin) if (b) cells++;
            float[] f0 = cells > 0 ? poisson(vin, q.gw, q.gh, c) : new float[gn];
            float fm = 0f;
            for (int i = 0; i < gn; i++) if (vin[i] && f0[i] > fm) fm = f0[i];
            q.rpx = 2f * (float) Math.sqrt(Math.max(0f, fm)) * f;
            q.thin = cells < 10 || q.rpx < Math.max(4f, 0.006f * D);
            float[][] nn = normals(f0, vin, q.gw, q.gh);
            q.nx = nn[0]; q.ny = nn[1]; q.nz = nn[2];
            // combinar con la forma del personaje (las zonas finas usan solo la del personaje)
            float wc = q.thin ? 1f : 0.45f, wz = q.thin ? 0f : 1f;
            float[] cn = new float[3];
            for (int gy = 0; gy < q.gh; gy++)
                for (int gx = 0; gx < q.gw; gx++) {
                    int i = gy * q.gw + gx;
                    float px = q.x0 + (gx - 1 + 0.5f) * f - 0.5f, py = q.y0 + (gy - 1 + 0.5f) * f - 0.5f;
                    if (q.bg) { q.nx[i] = 0; q.ny[i] = 0; q.nz[i] = 1; continue; }
                    charNormal(px, py, cn);
                    float ax = q.nx[i] * wz + cn[0] * wc, ay = q.ny[i] * wz + cn[1] * wc, az = q.nz[i] * wz + cn[2] * wc;
                    float m = (float) Math.sqrt(ax * ax + ay * ay + az * az);
                    if (m < 1e-6f) { ax = 0; ay = 0; az = 1; m = 1; }
                    q.nx[i] = ax / m; q.ny[i] = ay / m; q.nz[i] = az / m;
                }
        }

        // ------------------------------------------------------------ pelo, cara, ojos (reglas simples)
        private void findRoles() {
            int cy0 = H, cy1 = 0;
            long charArea = 0;
            for (ZCtx q : ctx) if (q.w > 0 && !q.bg) { cy0 = Math.min(cy0, q.y0); cy1 = Math.max(cy1, q.y0 + q.h); charArea += q.area; }
            if (charArea == 0) return;
            int chH = Math.max(1, cy1 - cy0);
            // cara: la zona de piel mas grande en la mitad de arriba del personaje
            int face = -1;
            for (ZCtx q : ctx) {
                if (q.w == 0 || q.bg || !q.skin) continue;
                skinZones++;
                float cyz = q.y0 + q.h * 0.5f;
                if (cyz > cy0 + chH * 0.6f && chH > 0.5f * H) continue;
                if (face < 0 || q.area > ctx[face].area) face = q.idx;
            }
            // pelo: zonas no-piel cuyo tope esta entre lo mas alto del personaje y tocan la cara por arriba
            if (face >= 0) {
                ZCtx fz = ctx[face];
                fz.face = true;
                faceIdx = face;
                int best = -1;
                for (ZCtx q : ctx) {
                    if (q.w == 0 || q.bg || q.skin || q.idx == face) continue;
                    if (q.y0 > cy0 + chH * 0.18f + 2) continue;           // empieza arriba de todo
                    if (q.y0 >= fz.y0) continue;                          // empieza mas arriba que la cara
                    if (q.area < charArea * 0.02f && q.area < fz.area * 0.25f) continue;
                    if (!touches(q, fz, Math.max(4, Math.round(D * 0.004f)))) continue;
                    if (best < 0 || q.area > ctx[best].area) best = q.idx;
                }
                if (best >= 0) {
                    int hb = ctx[best].z.s.base;
                    for (ZCtx q : ctx)
                        if (q.w > 0 && !q.bg && !q.skin && (q.idx == best || (q.z.s.base == hb && touchesAny(q, best))))
                            { q.hair = true; hairZones++; }
                }
                // ojos: zonas chicas, casi elipticas, dentro de la cara (franja media)
                for (ZCtx q : ctx) {
                    if (q.w == 0 || q.bg || q.skin || q.hair || q.idx == face) continue;
                    if (q.area < Math.max(30, fz.area * 0.0015f) || q.area > fz.area * 0.06f) continue;
                    float cx = q.x0 + q.w * 0.5f, cyq = q.y0 + q.h * 0.5f;
                    if (cx < fz.x0 || cx > fz.x0 + fz.w) continue;
                    if (cyq < fz.y0 + fz.h * 0.15f || cyq > fz.y0 + fz.h * 0.78f) continue;
                    float asp = q.w / (float) q.h;
                    if (asp < 0.35f || asp > 2.4f) continue;
                    float fill = q.area / (float) (q.w * q.h);
                    if (fill < 0.45f) continue;
                    if (!touches(q, fz, Math.max(4, Math.round(D * 0.004f)))) continue;
                    eyes.add(q.idx);
                }
                if (eyes.size() > 2) {
                    // las dos mas grandes
                    java.util.Collections.sort(eyes, new java.util.Comparator<Integer>() {
                        public int compare(Integer a, Integer b) { return ctx[b].area - ctx[a].area; }
                    });
                    while (eyes.size() > 2) eyes.remove(eyes.size() - 1);
                }
                for (int e : eyes) ctx[e].eye = true;
            }
        }

        /** Las mascaras de a y b estan a menos de r pixeles en algun lugar (mira las mascaras, no el dueno). */
        private boolean touches(ZCtx a, ZCtx b, int r) {
            if (a.w == 0 || b.w == 0) return false;
            if (a.x0 > b.x0 + b.w + r || b.x0 > a.x0 + a.w + r || a.y0 > b.y0 + b.h + r || b.y0 > a.y0 + a.h + r) return false;
            ZoneTone.Zone za = a.z, zb = b.z;
            int step = Math.max(1, r / 2);
            for (int y = 0; y < za.h; y++)
                for (int x = 0; x < za.w; x++) {
                    if ((za.m[y * za.w + x] & 0xFF) < 128) continue;
                    boolean edge = x == 0 || y == 0 || x == za.w - 1 || y == za.h - 1
                            || (za.m[y * za.w + x - 1] & 0xFF) < 128 || (za.m[y * za.w + x + 1] & 0xFF) < 128
                            || (za.m[(y - 1) * za.w + x] & 0xFF) < 128 || (za.m[(y + 1) * za.w + x] & 0xFF) < 128;
                    if (!edge) continue;
                    int gx = x + za.x, gy = y + za.y;
                    for (int dy = -r; dy <= r; dy += step)
                        for (int dx = -r; dx <= r; dx += step) {
                            int bx = gx + dx - zb.x, by = gy + dy - zb.y;
                            if (bx < 0 || by < 0 || bx >= zb.w || by >= zb.h) continue;
                            if ((zb.m[by * zb.w + bx] & 0xFF) >= 128) return true;
                        }
                }
            return false;
        }

        private boolean touchesAny(ZCtx q, int other) { return touches(q, ctx[other], Math.max(4, Math.round(D * 0.004f))); }

        // ------------------------------------------------------------ oclusion por densidad de lineas
        private void buildDensity(Cancel c) {
            int fo = Math.max(1, (int) Math.ceil(Math.max(uw, uh) / 256f));
            int dw = (uw + fo - 1) / fo, dh = (uh + fo - 1) / fo;
            float[] d = new float[dw * dh];
            for (int y = 0; y < uh; y++)
                for (int x = 0; x < uw; x++) d[(y / fo) * dw + x / fo] += (lineA[y * uw + x] & 0xFF) / 255f;
            float inv = 1f / (fo * fo);
            for (int i = 0; i < d.length; i++) d[i] *= inv;
            blur(d, dw, dh, 0.01f * D / fo);
            if (c.cancelled()) throw new Cancelled();
            for (ZCtx q : ctx) {
                if (q.w == 0 || q.bg || q.thin) continue;
                q.dens = new float[q.gw * q.gh];
                int[] hist = new int[256];
                int n = 0;
                float mx = 1e-6f;
                for (int i = 0; i < d.length; i++) mx = Math.max(mx, d[i]);
                for (int gy = 0; gy < q.gh; gy++)
                    for (int gx = 0; gx < q.gw; gx++) {
                        int i = gy * q.gw + gx;
                        float px = q.x0 + (gx - 1 + 0.5f) * q.f - 0.5f - ux0, py = q.y0 + (gy - 1 + 0.5f) * q.f - 0.5f - uy0;
                        float v = bil(d, dw, dh, (px + 0.5f) / fo - 0.5f, (py + 0.5f) / fo - 0.5f);
                        q.dens[i] = v;
                        if (q.in[i]) { hist[Math.min(255, (int) (v / mx * 255f))]++; n++; }
                    }
                if (n == 0) { q.dens = null; continue; }
                float med = pct(hist, n, 0.5f) / 255f * mx, hi = pct(hist, n, 0.97f) / 255f * mx;
                if (hi - med < 0.02f) { q.dens = null; continue; }
                for (int i = 0; i < q.dens.length; i++) q.dens[i] = clamp01((q.dens[i] - med) / (hi - med));
            }
        }

        // ------------------------------------------------------------ sombra que echa el pelo (y la cara sobre el cuello)
        private void buildCast(ZCtx q, Cancel c) {
            // quien tapa: pelo; para el cuello, la cara
            boolean[] occ = new boolean[ctx.length];
            boolean any = false;
            for (ZCtx o : ctx) {
                if (o.w == 0 || o.idx == q.idx) continue;
                boolean use = o.hair || (o.face && !q.face && q.y0 + q.h * 0.5f > o.y0 + o.h * 0.5f && q.y0 > o.y0 + o.h * 0.4f);
                if (!use) continue;
                if (!touches(q, o, Math.max(4, Math.round(D * 0.004f)))) continue;
                occ[o.idx] = true;
                any = true;
            }
            if (!any) return;
            int len = Math.max(3, Math.round(0.03f * D));
            int x0 = Math.max(ux0, q.x0 - len - 4), y0 = Math.max(uy0, q.y0 - len - 4);
            int x1 = Math.min(ux1, q.x0 + q.w + len + 4), y1 = Math.min(uy1, q.y0 + q.h + len + 4);
            int w = x1 - x0, h = y1 - y0;
            if (w <= 2 || h <= 2) return;
            boolean[] in = new boolean[w * h];
            boolean[] out = new boolean[w * h];
            int grow = Math.max(1, Math.round(D * 0.0015f));
            for (ZCtx o : ctx) {
                if (!occ[o.idx]) continue;
                ZoneTone.Zone zo = o.z;
                for (int y = Math.max(y0, zo.y); y < Math.min(y1, zo.y + zo.h); y++)
                    for (int x = Math.max(x0, zo.x); x < Math.min(x1, zo.x + zo.w); x++)
                        if ((zo.m[(y - zo.y) * zo.w + x - zo.x] & 0xFF) >= 128) in[(y - y0) * w + x - x0] = true;
            }
            // la propia piel nunca tapa (si una zona de pelo se encima sobre la piel)
            ZoneTone.Zone zq = q.z;
            in = dilate(in, w, h, grow);   // cubre la linea del borde del pelo
            for (int i = 0; i < in.length; i++) out[i] = !in[i];
            float[] dOut = edt(in, w, h);     // distancia al pelo (afuera)
            float[] dIn = edt(out, w, h);     // distancia a lo que no es pelo (adentro)
            float[] s = new float[w * h];
            for (int i = 0; i < s.length; i++) {
                float a = dOut[i] >= INF ? 1e4f : dOut[i], b = dIn[i] >= INF ? 1e4f : dIn[i];
                s[i] = in[i] ? -(b - 0.5f) : (a - 0.5f);
            }
            q.sdf = s; q.sx0 = x0; q.sy0 = y0; q.sw = w; q.sh = h;
        }

        // ------------------------------------------------------------ pelo: tope por columna, cara, brillo en mechones
        /** Fondo de cada columna (promediado con las vecinas): para las puntas de color. */
        private void hairBottoms(ZCtx q) {
            ZoneTone.Zone z = q.z;
            int[] cb = new int[q.w];
            for (int x = 0; x < q.w; x++) {
                cb[x] = -1;
                for (int y = q.h - 1; y >= 0; y--)
                    if ((z.m[(y + q.y0 - z.y) * z.w + x + q.x0 - z.x] & 0xFF) >= 128) { cb[x] = y; break; }
            }
            // promedio por columnas vecinas: las puntas siguen la forma general, sin rayas verticales
            int rad = Math.max(3, Math.round(0.03f * D));
            q.colBot = new int[q.w];
            for (int x = 0; x < q.w; x++) {
                if (cb[x] < 0) { q.colBot[x] = -1; continue; }
                long sum = 0; int n = 0;
                for (int k = Math.max(0, x - rad); k <= Math.min(q.w - 1, x + rad); k++) if (cb[k] >= 0) { sum += cb[k]; n++; }
                q.colBot[x] = (int) (sum / n);
            }
        }

        private void buildHair(ZCtx q, Cancel c) {
            ZoneTone.Zone z = q.z;
            q.colTop = new int[q.w];
            int minTop = q.h;
            for (int x = 0; x < q.w; x++) {
                q.colTop[x] = -1;
                for (int y = 0; y < q.h; y++)
                    if ((z.m[(y + q.y0 - z.y) * z.w + x + q.x0 - z.x] & 0xFF) >= 128) { q.colTop[x] = y; break; }
                if (q.colTop[x] >= 0) minTop = Math.min(minTop, q.colTop[x]);
            }
            q.hairTop0 = minTop;
            hairBottoms(q);
            q.tipZone = true;
            if (faceIdx < 0) return;
            ZCtx fz = ctx[faceIdx];
            q.faceTop = fz.y0 - q.y0;
            if (q.faceTop <= minTop + 6) return;
            // campo de direccion de los mechones (tensor de estructura) a media resolucion
            int hf = 2;
            int bw = (q.w + hf - 1) / hf, bh = (q.h + hf - 1) / hf;
            if (bw < 8 || bh < 8) return;
            float[] g = new float[bw * bh];
            boolean[] hin = new boolean[bw * bh];
            for (int y = 0; y < bh; y++)
                for (int x = 0; x < bw; x++) {
                    float s = 0; int n = 0; int inside = 0;
                    for (int yy = y * hf; yy < Math.min(q.h, y * hf + hf); yy++)
                        for (int xx = x * hf; xx < Math.min(q.w, x * hf + hf); xx++) {
                            int gi = (yy + q.y0 - uy0) * uw + xx + q.x0 - ux0;
                            s += lum[gi] & 0xFF; n++;
                            if ((z.m[(yy + q.y0 - z.y) * z.w + xx + q.x0 - z.x] & 0xFF) >= 128) inside++;
                        }
                    g[y * bw + x] = n > 0 ? s / n / 255f : 1f;
                    hin[y * bw + x] = inside * 2 >= n;
                }
            blur(g, bw, bh, 0.8f);
            float[] jxx = new float[g.length], jxy = new float[g.length], jyy = new float[g.length];
            for (int y = 1; y < bh - 1; y++)
                for (int x = 1; x < bw - 1; x++) {
                    int i = y * bw + x;
                    float gx = (g[i - bw + 1] + 2 * g[i + 1] + g[i + bw + 1]) - (g[i - bw - 1] + 2 * g[i - 1] + g[i + bw - 1]);
                    float gy = (g[i + bw - 1] + 2 * g[i + bw] + g[i + bw + 1]) - (g[i - bw - 1] + 2 * g[i - bw] + g[i - bw + 1]);
                    jxx[i] = gx * gx; jxy[i] = gx * gy; jyy[i] = gy * gy;
                }
            float sig = Math.max(1.5f, 0.006f * D / hf);
            blur(jxx, bw, bh, sig); blur(jxy, bw, bh, sig); blur(jyy, bw, bh, sig);
            if (c.cancelled()) throw new Cancelled();
            float[] tx = new float[g.length], ty = new float[g.length], coh = new float[g.length];
            double cohSum = 0; int cohN = 0;
            float bandC = minTop + 0.42f * (q.faceTop - minTop), bandH = Math.max(3f, 0.16f * (q.faceTop - minTop));
            for (int i = 0; i < g.length; i++) {
                float a = jxx[i], b = jxy[i], d = jyy[i];
                float tr = a + d, det = (float) Math.sqrt((a - d) * (a - d) + 4 * b * b);
                float l1 = (tr + det) * 0.5f, l2 = (tr - det) * 0.5f;
                // direccion del mechon = autovector del valor propio menor (perpendicular al gradiente)
                float vx = b, vy = l2 - a;
                if (Math.abs(vx) + Math.abs(vy) < 1e-9f) { vx = l2 - d; vy = b; }
                float m = (float) Math.hypot(vx, vy);
                if (m < 1e-9f) { vx = 0; vy = 1; m = 1; }
                tx[i] = vx / m; ty[i] = vy / m;
                coh[i] = tr > 1e-6f ? ((l1 - l2) / (l1 + l2)) * ((l1 - l2) / (l1 + l2)) : 0f;
                int y = i / bw;
                float yy = y * hf;
                if (hin[i] && Math.abs(yy - bandC) < bandH * 1.5f) { cohSum += coh[i]; cohN++; }
            }
            // sin lineas que digan la direccion: no se inventan rayas
            if (cohN < 20 || cohSum / cohN < 0.18) return;
            // LIC: ruido estirado a lo largo de los mechones
            java.util.Random rnd = new java.util.Random(12345L + q.idx);
            float[] noise = new float[g.length];
            for (int i = 0; i < noise.length; i++) noise[i] = rnd.nextFloat();
            blur(noise, bw, bh, 0.6f);
            float[] lic = new float[g.length];
            int steps = 18;
            int[] hhist = new int[256];
            int hn = 0;
            for (int y = 0; y < bh; y++) {
                float yy = y * hf;
                if (Math.abs(yy - bandC) > bandH * 2.2f) continue;
                for (int x = 0; x < bw; x++) {
                    int i = y * bw + x;
                    if (!hin[i]) continue;
                    float acc = noise[i];
                    int n = 1;
                    for (int dir = -1; dir <= 1; dir += 2) {
                        float px = x, py = y, lx = tx[i] * dir, ly = ty[i] * dir;
                        for (int k = 0; k < steps; k++) {
                            int ix = Math.round(px), iy = Math.round(py);
                            if (ix < 0 || iy < 0 || ix >= bw || iy >= bh) break;
                            int j = iy * bw + ix;
                            float ux = tx[j], uy = ty[j];
                            if (ux * lx + uy * ly < 0) { ux = -ux; uy = -uy; }
                            lx = ux; ly = uy;
                            px += lx; py += ly;
                            int jx = Math.round(px), jy = Math.round(py);
                            if (jx < 0 || jy < 0 || jx >= bw || jy >= bh || !hin[jy * bw + jx]) break;
                            acc += noise[jy * bw + jx];
                            n++;
                        }
                    }
                    float v = acc / n;
                    lic[i] = v;
                    hhist[Math.min(255, Math.max(0, (int) (v * 255f)))]++;
                    hn++;
                }
            }
            if (hn < 20) return;
            float lo = pct(hhist, hn, 0.45f) / 255f, hi = pct(hhist, hn, 0.92f) / 255f;
            if (hi - lo < 0.01f) return;
            q.licN = new float[q.w * q.h];
            for (int y = 0; y < q.h; y++)
                for (int x = 0; x < q.w; x++) {
                    float v = bil(lic, bw, bh, (x + 0.5f) / hf - 0.5f, (y + 0.5f) / hf - 0.5f);
                    q.licN[y * q.w + x] = clamp01((v - lo) / (hi - lo));
                }
            q.ring = true;
        }

        private void buildEye(ZCtx q) {
            q.eyeCx = q.x0 + q.w * 0.5f; q.eyeCy = q.y0 + q.h * 0.5f;
            q.eyeRx = q.w * 0.5f; q.eyeRy = q.h * 0.5f;
            // brillo propio del dibujo: blancos dentro del centro del ojo que no son de la zona
            int bx0 = q.x0 + q.w / 4, by0 = q.y0 + q.h / 4, bx1 = q.x0 + q.w * 3 / 4, by1 = q.y0 + q.h * 3 / 4;
            int bright = 0, tot = 0;
            for (int y = by0; y < by1; y++)
                for (int x = bx0; x < bx1; x++) {
                    tot++;
                    int mx = x - q.z.x, my = y - q.z.y;
                    boolean in = mx >= 0 && my >= 0 && mx < q.z.w && my < q.z.h && (q.z.m[my * q.z.w + mx] & 0xFF) >= 128;
                    if (in) continue;
                    int v = lum[(y - uy0) * uw + x - ux0] & 0xFF;
                    if (v > q.paper - 14) bright++;
                }
            q.eyeOwnHL = tot > 0 && bright > tot * 0.015f;
        }

        /**
         * Cara y cuello en una sola zona: el cuello es la parte de abajo angosta; el menton es la linea
         * dibujada justo arriba del cuello (por columna). Abajo de esa linea va la sombra del menton.
         */
        private void buildChin(ZCtx q) {
            ZoneTone.Zone z = q.z;
            int[] rw = new int[q.h], rc = new int[q.h];
            for (int y = 0; y < q.h; y++) {
                int a = -1, b = -1;
                for (int x = 0; x < q.w; x++)
                    if ((z.m[(y + q.y0 - z.y) * z.w + x + q.x0 - z.x] & 0xFF) >= 128) { if (a < 0) a = x; b = x; }
                rw[y] = a < 0 ? 0 : b - a + 1;
                rc[y] = a < 0 ? 0 : (a + b) / 2;
            }
            int maxW = 0, maxY = 0;
            for (int y = 0; y < q.h * 7 / 10; y++) if (rw[y] > maxW) { maxW = rw[y]; maxY = y; }
            if (maxW < 16) return;
            // ancho del cuello: mediana de la cuarta parte de abajo
            int n = 0;
            int[] tmp = new int[q.h];
            for (int y = q.h * 3 / 4; y < q.h; y++) if (rw[y] > 0) tmp[n++] = rw[y];
            if (n < 4) return;
            Arrays.sort(tmp, 0, n);
            int nw = tmp[n / 2];
            if (nw > maxW * 0.72f || nw < 6) return;          // no hay cuello angosto: no es cara+cuello
            int neckTop = -1;
            for (int y = maxY + 1; y < q.h; y++) if (rw[y] > 0 && rw[y] <= nw * 1.2f) { neckTop = y; break; }
            if (neckTop < 0 || neckTop > q.h - 8) return;
            int cx = rc[Math.min(q.h - 1, neckTop + 4)];
            int[] chin = new int[q.w];
            Arrays.fill(chin, -1);
            int y0 = Math.max(0, neckTop - Math.round(nw * 0.2f)), y1 = Math.min(q.h - 1, neckTop + Math.round(nw * 0.6f));
            int found = 0;
            for (int x = Math.max(0, cx - nw / 2); x <= Math.min(q.w - 1, cx + nw / 2); x++) {
                int run = -1;
                for (int y = y0; y <= y1; y++) {
                    int gx = x + q.x0, gy = y + q.y0;
                    boolean ln = (lineA[(gy - uy0) * uw + gx - ux0] & 0xFF) >= 115
                            && (z.m[(gy - z.y) * z.w + gx - z.x] & 0xFF) >= 128;
                    if (ln) run = y;
                    else if (run >= 0) break;          // fin de la primera linea encontrada
                }
                chin[x] = run >= 0 ? run + 1 : neckTop;
                if (run >= 0) found++;
            }
            // suavizar (mediana de 5) para que no salgan dientes
            int[] sm = chin.clone();
            int[] w5 = new int[5];
            for (int x = 2; x < q.w - 2; x++) {
                if (chin[x] < 0) continue;
                int c = 0;
                for (int k = -2; k <= 2; k++) if (chin[x + k] >= 0) w5[c++] = chin[x + k];
                Arrays.sort(w5, 0, c);
                sm[x] = w5[c / 2];
            }
            q.chinCol = sm;
            q.chinY = neckTop + q.y0;
            q.neckCx = cx + q.x0;
            q.neckHalfW = Math.max(4f, nw * 0.5f);
            q.chinDepth = Math.max(3f, nw * 0.32f);
        }

        // ------------------------------------------------------------ v8.63: material y estampado (con deshacer)
        public synchronized int material(int zi) { return zi < 0 || zi >= ctx.length ? 0 : ctx[zi].material; }

        public synchronized void setMaterial(int zi, int m) { if (zi >= 0 && zi < ctx.length) { ctx[zi].material = m; extrasVer++; } }

        /** Toma material y estampado del estilo actual de cada zona (por si cambio). */
        synchronized void syncExtras() {
            for (ZCtx q : ctx) {
                ZoneTone.Style st = q.z.s;
                if (q.material != st.material || q.pattern != st.pattern || q.patColor != st.patColor) {
                    q.material = st.material; q.pattern = st.pattern; q.patColor = st.patColor;
                    extrasVer++;
                }
            }
        }

        public synchronized void setPattern(int zi, int type, int color) {
            if (zi < 0 || zi >= ctx.length) return;
            ctx[zi].pattern = type;
            ctx[zi].patColor = color;
            extrasVer++;
        }

        /** Para guardar en el estilo de cada zona al Aceptar: {material, estampado, color}. */
        public synchronized int[] zoneExtras(ZoneTone.Zone z) {
            int i = zones.indexOf(z);
            if (i < 0) return null;
            return new int[]{ctx[i].material, ctx[i].pattern, ctx[i].patColor};
        }

        public boolean isHair(int zi) { return zi >= 0 && zi < ctx.length && ctx[zi].hair; }

        // ============================================================ ediciones de la usuaria

        public int zoneAt(int x, int y) {
            if (x < ux0 || y < uy0 || x >= ux1 || y >= uy1) return -1;
            int ow = owner[(y - uy0) * uw + x - ux0];
            if (ow > 0) return ow - 1;
            // un poco al lado (por si toca justo la linea)
            for (int r = 1; r <= 4; r++)
                for (int dy = -r; dy <= r; dy++)
                    for (int dx = -r; dx <= r; dx++) {
                        int xx = x + dx - ux0, yy = y + dy - uy0;
                        if (xx < 0 || yy < 0 || xx >= uw || yy >= uh) continue;
                        int o = owner[yy * uw + xx];
                        if (o > 0) return o - 1;
                    }
            return -1;
        }

        /** Antes de un trazo o de Quitar mancha: guarda las ediciones para poder deshacer. */
        public synchronized void pushUndo() {
            float[][] snap = new float[ctx.length + 1][];
            for (int i = 0; i < ctx.length; i++) if (ctx[i].edit != null) snap[i] = ctx[i].edit.clone();
            float[] ex = new float[ctx.length * 3];
            for (int i = 0; i < ctx.length; i++) { ex[i * 3] = ctx[i].material; ex[i * 3 + 1] = ctx[i].pattern; ex[i * 3 + 2] = Float.intBitsToFloat(ctx[i].patColor); }
            snap[ctx.length] = ex;
            undoEdits.add(snap);
            if (undoEdits.size() > 30) undoEdits.remove(0);
        }

        public synchronized boolean canUndo() { return !undoEdits.isEmpty(); }

        public synchronized boolean undo() {
            if (undoEdits.isEmpty()) return false;
            float[][] snap = undoEdits.remove(undoEdits.size() - 1);
            for (int i = 0; i < ctx.length; i++) if (snap[i] != null && ctx[i].edit != null) System.arraycopy(snap[i], 0, ctx[i].edit, 0, snap[i].length);
            float[] ex = snap.length > ctx.length ? snap[ctx.length] : null;
            if (ex != null) for (int i = 0; i < ctx.length; i++) {
                ctx[i].material = (int) ex[i * 3]; ctx[i].pattern = (int) ex[i * 3 + 1]; ctx[i].patColor = Float.floatToRawIntBits(ex[i * 3 + 2]);
            }
            extrasVer++;
            return true;
        }

        /**
         * Mas luz (amount > 0) o Mas sombra (amount < 0) en la zona 'zi': sube o baja el mapa de
         * luz con una joroba suave. No pinta pixeles: el corte suave se vuelve a hacer y nunca sale
         * de la zona.
         */
        public synchronized void brush(int zi, float x, float y, float radius, float amount) {
            if (zi < 0 || zi >= ctx.length) return;
            ZCtx q = ctx[zi];
            if (q.edit == null) return;
            float gx = (x - q.x0 + 0.5f) / q.f - 0.5f + 1f, gy = (y - q.y0 + 0.5f) / q.f - 0.5f + 1f;
            float gr = Math.max(1.2f, radius / q.f), s2 = 2f * (gr * 0.5f) * (gr * 0.5f);
            int r = (int) Math.ceil(gr * 1.6f);
            for (int yy = (int) gy - r; yy <= (int) gy + r + 1; yy++)
                for (int xx = (int) gx - r; xx <= (int) gx + r + 1; xx++) {
                    if (xx < 0 || yy < 0 || xx >= q.gw || yy >= q.gh) continue;
                    float d2 = (xx - gx) * (xx - gx) + (yy - gy) * (yy - gy);
                    float wv = (float) Math.exp(-d2 / s2);
                    if (wv < 0.01f) continue;
                    int i = yy * q.gw + xx;
                    q.edit[i] = Math.max(-1.6f, Math.min(1.6f, q.edit[i] + amount * wv));
                }
        }

        /**
         * Quitar mancha: el pedazo de sombra (o de luz) tocado pasa a ser como lo de alrededor.
         * @return false si ahi no hay nada que quitar
         */
        public synchronized boolean removeSpot(int x, int y, Params p) {
            int zi = zoneAt(x, y);
            if (zi < 0) return false;
            ZCtx q = ctx[zi];
            if (q.edit == null || q.in == null) return false;
            Light L = light(p);
            float[] s = shadeField(q, L, p, false);
            float t = threshold(p);
            int gx = clampi(Math.round((x - q.x0 + 0.5f) / q.f - 0.5f + 1f), 0, q.gw - 1);
            int gy = clampi(Math.round((y - q.y0 + 0.5f) / q.f - 0.5f + 1f), 0, q.gh - 1);
            int start = gy * q.gw + gx;
            if (!q.in[start]) {
                // la celda mas cercana adentro
                int best = -1; float bd = 1e9f;
                for (int i = 0; i < q.in.length; i++) if (q.in[i]) {
                    float d = (i % q.gw - gx) * (i % q.gw - gx) + (i / q.gw - gy) * (i / q.gw - gy);
                    if (d < bd) { bd = d; best = i; }
                }
                if (best < 0 || bd > 9) return false;
                start = best;
            }
            boolean shadow = s[start] < t;
            // el pedazo conectado de la misma clase
            boolean[] seen = new boolean[q.in.length];
            int[] st = new int[q.in.length];
            int sp = 0, cnt = 0;
            st[sp++] = start; seen[start] = true;
            ArrayList<Integer> comp = new ArrayList<Integer>();
            while (sp > 0) {
                int i = st[--sp];
                comp.add(i);
                cnt++;
                int cx = i % q.gw, cy = i / q.gw;
                int[] nb = {cx > 0 ? i - 1 : -1, cx < q.gw - 1 ? i + 1 : -1, cy > 0 ? i - q.gw : -1, cy < q.gh - 1 ? i + q.gw : -1};
                for (int j : nb) {
                    if (j < 0 || seen[j] || !q.in[j] || (s[j] < t) != shadow) continue;
                    seen[j] = true;
                    st[sp++] = j;
                }
            }
            int inCells = 0;
            for (boolean b : q.in) if (b) inCells++;
            if (cnt * 100 > inCells * 12) {
                // no es una manchita (es una sombra grande): se quita el RETOQUE hecho ahi, si hay
                float rr = Math.max(2f, 0.04f * D / q.f);
                float found = 0f;
                for (int i = 0; i < q.edit.length; i++) {
                    float dx = i % q.gw - gx, dy = i / q.gw - gy;
                    if (dx * dx + dy * dy <= rr * rr * 4f) found = Math.max(found, Math.abs(q.edit[i]));
                }
                if (found < 0.05f) return false;
                for (int i = 0; i < q.edit.length; i++) {
                    float dx = i % q.gw - gx, dy = i / q.gw - gy;
                    float wv = (float) Math.exp(-(dx * dx + dy * dy) / (2f * rr * rr));
                    q.edit[i] *= 1f - wv;
                    if (Math.abs(q.edit[i]) < 0.02f) q.edit[i] = 0f;
                }
                return true;
            }
            float[] add = new float[q.in.length];
            boolean[] m = new boolean[q.in.length];
            for (int i : comp) {
                m[i] = true;
                add[i] = shadow ? (t - s[i] + 0.25f) : (t - s[i] - 0.25f);
            }
            // un poco mas grande y suave, para que no quede un borde
            boolean[] grown = dilate(m, q.gw, q.gh, 1);
            for (int i = 0; i < add.length; i++) if (grown[i] && !m[i]) add[i] = shadow ? 0.25f : -0.25f;
            float[] wt = new float[add.length];
            for (int i = 0; i < wt.length; i++) wt[i] = grown[i] ? 1f : 0f;
            for (int i = 0; i < add.length; i++) {
                if (!grown[i]) continue;
                q.edit[i] = Math.max(-1.6f, Math.min(1.6f, q.edit[i] + add[i]));
            }
            return true;
        }

        // ============================================================ render

        static final class Light {
            float lx, ly, lz;      // hacia el sol (3D)
            float dx, dy;          // hacia el sol en 2D (unitario)
            float sinT;
        }

        Light light(Params p) {
            Light L = new Light();
            float sx = p.sunX * W, sy = p.sunY * H;
            float ddx = sx - charCx, ddy = sy - charCy;
            float dist = (float) Math.hypot(ddx, ddy);
            float rel = clamp01(dist / (0.5f * D));
            float theta = (float) Math.toRadians(14 + 64 * rel);   // lejos = luz de costado = sombra ancha
            if (dist < 1e-3f) { ddx = 0; ddy = -1; dist = 1; }
            L.dx = ddx / dist; L.dy = ddy / dist;
            L.sinT = (float) Math.sin(theta);
            L.lx = L.dx * L.sinT; L.ly = L.dy * L.sinT; L.lz = (float) Math.cos(theta);
            return L;
        }

        static float threshold(Params p) {
            float k = p.strength / 100f;
            return -0.10f + 0.40f * k;
        }

        /** s = n.L + retoques, sin islitas (grilla de la zona). */
        float[] shadeField(ZCtx q, Light L, Params p, boolean clean) {
            int n = q.gw * q.gh;
            float[] s = new float[n];
            for (int i = 0; i < n; i++) s[i] = q.nx[i] * L.lx + q.ny[i] * L.ly + q.nz[i] * L.lz + q.edit[i];
            if (!clean || q.thin) return s;
            float t = threshold(p);
            // islitas: pedazos chicos de sombra o de luz se pasan a la clase de alrededor
            int minCells = Math.max(2, Math.round(Math.max(40f, 0.005f * q.area) / (q.f * q.f)));
            boolean[] seen = new boolean[n];
            int[] st = new int[n];
            int[] comp = new int[n];
            for (int s0 = 0; s0 < n; s0++) {
                if (seen[s0] || !q.in[s0]) continue;
                boolean cls = s[s0] < t;
                int sp = 0, cn = 0;
                st[sp++] = s0; seen[s0] = true;
                while (sp > 0) {
                    int i = st[--sp];
                    comp[cn++] = i;
                    int cx = i % q.gw, cy = i / q.gw;
                    if (cx > 0) sp = push(s, q.in, seen, st, sp, i - 1, cls, t);
                    if (cx < q.gw - 1) sp = push(s, q.in, seen, st, sp, i + 1, cls, t);
                    if (cy > 0) sp = push(s, q.in, seen, st, sp, i - q.gw, cls, t);
                    if (cy < q.gh - 1) sp = push(s, q.in, seen, st, sp, i + q.gw, cls, t);
                }
                if (cn < minCells) for (int k = 0; k < cn; k++) s[comp[k]] = cls ? t + 0.08f : t - 0.08f;
            }
            return s;
        }

        private static int push(float[] s, boolean[] in, boolean[] seen, int[] st, int sp, int j, boolean cls, float t) {
            if (seen[j] || !in[j] || (s[j] < t) != cls) return sp;
            seen[j] = true;
            st[sp++] = j;
            return sp;
        }

        /**
         * Hace el acabado en 'dst' (un recuadro de la imagen: dx0,dy0,dw,dh), que ya trae lo que habia
         * en la capa. Los pixeles de las zonas se reemplazan (con el alfa de la mascara).
         */
        public void render(Params p, int[] dst, int dx0, int dy0, int dw, int dh, Cancel c) {
            renderImpl(p, dst, dx0, dy0, dw, dh, c, -1);
        }

        private String fullKey;
        private int extrasVer;
        private int[] fullBuf;

        /** Acabado completo en la caja de union, sobre transparente (cache por parametros). */
        synchronized int[] fullFor(Params p) {
            String key = p.sunX + "|" + p.sunY + "|" + p.strength + "|" + p.colorLines + "|" + p.lightType + "|" + p.anime + "|" + p.hairTip + "|" + p.extrasKey() + "|" + extrasVer;
            if (fullBuf != null && key.equals(fullKey)) return fullBuf;
            int[] b = new int[uw * uh];
            renderImpl(p, b, ux0, uy0, uw, uh, NEVER, -1);
            fullBuf = b;
            fullKey = key;
            return b;
        }

        private void renderImpl(Params p, int[] dst, int dx0, int dy0, int dw, int dh, Cancel c, final int only) {
            if (c == null) c = NEVER;
            long T0 = System.nanoTime();
            final Params P = p.copy();
            final Light L = light(P);
            final float k = P.strength / 100f;
            final float t = threshold(P);
            final LK lk = lightKind(P.lightType);
            // v8.63: luces extra (no echan sombra nueva: iluminan el lado que miran, en su color)
            final int xn = Math.max(0, Math.min(MAX_EXTRA, P.extraN));
            final Light[] XL = new Light[xn];
            final LK[] XK = new LK[xn];
            for (int j = 0; j < xn; j++) {
                Params pj = P.copy(); pj.sunX = P.exX[j]; pj.sunY = P.exY[j];
                XL[j] = light(pj);
                XK[j] = lightKind(P.exType[j]);
            }
            final float[][][] EX = new float[ctx.length][][];
            final float op1 = Math.min(1f, k * 1.6f * lk.shadowMul);
            final float opL = Math.min(1f, k * 1.4f);
            final boolean draft = P.draft;
            // por zona: campos del sol
            final float[][] S = new float[ctx.length][];
            final Pal tipPal = P.hairTip != 0 ? palette(P.hairTip | 0xFF000000) : null;
            final Pal[][] tipLut = new Pal[ctx.length][];   // v8.63: paletas mezcladas ya listas (sin crear nada por pixel)
            final Pal[][] patLut = new Pal[ctx.length][];
            final float[][] Wd = new float[ctx.length][];
            final Pal[] pal = new Pal[ctx.length];
            for (ZCtx q : ctx) {
                if (q.w == 0) continue;
                pal[q.idx] = palette(q.z.s.base);
                if (only >= 0 && q.idx != only) continue;
                float[] s;
                synchronized (this) { s = shadeField(q, L, P, true); }
                // suavizado leve (redondea dientes) y ancho del antialias (en pixeles finales)
                blurMasked(s, q.in, q.gw, q.gh, 0.7f);
                if (!draft) foldSnap(q, s, t);   // al arrastrar el sol no (llega en la pintada final)
                float[] wv = new float[s.length];
                for (int gy = 0; gy < q.gh; gy++)
                    for (int gx = 0; gx < q.gw; gx++) {
                        int i = gy * q.gw + gx;
                        float a = s[Math.max(0, gx - 1) + gy * q.gw], b = s[Math.min(q.gw - 1, gx + 1) + gy * q.gw];
                        float u = s[gx + Math.max(0, gy - 1) * q.gw], d = s[gx + Math.min(q.gh - 1, gy + 1) * q.gw];
                        float g = (float) Math.hypot((b - a) * 0.5f, (d - u) * 0.5f) / q.f;
                        wv[i] = Math.max(0.0035f, 0.9f * g);
                    }
                S[q.idx] = s;
                if (xn > 0 && !q.eye) {
                    float[][] e = new float[xn][];
                    for (int j = 0; j < xn; j++) {
                        float[] f2 = new float[s.length];
                        for (int i = 0; i < f2.length; i++) f2[i] = q.nx[i] * XL[j].lx + q.ny[i] * XL[j].ly + q.nz[i] * XL[j].lz;
                        if (!draft) blurMasked(f2, q.in, q.gw, q.gh, 0.7f);
                        e[j] = f2;
                    }
                    EX[q.idx] = e;
                }
                if (q.pattern > 0) patLut[q.idx] = palLut(pal[q.idx], palette(q.patColor | 0xFF000000), 4);
                if (tipPal != null && q.tipZone) tipLut[q.idx] = palLut(pal[q.idx], tipPal, 32);
                Wd[q.idx] = wv;
                if (c.cancelled()) throw new Cancelled();
            }
            long T1 = System.nanoTime();
            // limpiar las zonas en el destino y pintar en orden (como "Color zonas")
            for (final ZCtx q : ctx) {
                if (q.w == 0 || (only >= 0 && q.idx != only)) continue;
                if (c.cancelled()) throw new Cancelled();
                final ZoneTone.Zone z = q.z;
                final Pal pz = pal[q.idx];
                final float[] s = S[q.idx], wv = Wd[q.idx];
                final boolean improve = z.s.finish == ZoneTone.IMPROVE || colored;
                final int ox = Math.max(q.x0, dx0), oy = Math.max(q.y0, dy0);
                final int ex = Math.min(q.x0 + q.w, dx0 + dw), ey = Math.min(q.y0 + q.h, dy0 + dh);
                if (ex <= ox || ey <= oy) continue;
                final Cancel cc = c;
                if (draft) {
                    // v8.61 borrador (mientras se arrastra el sol): un calculo por cada 2x2 pixeles
                    final int rows = (ey - oy + 1) / 2;
                    parallel(rows, new Rows() {
                        public void run(int r0, int r1) {
                            float[] col = new float[3];
                            for (int by = r0; by < r1; by++) {
                                if ((by & 15) == 0 && cc.cancelled()) throw new Cancelled();
                                int y0b = oy + by * 2;
                                for (int x0b = ox; x0b < ex; x0b += 2) {
                                    int c2 = 0; boolean have = false;
                                    for (int yy = y0b; yy < Math.min(ey, y0b + 2); yy++)
                                        for (int xx = x0b; xx < Math.min(ex, x0b + 2); xx++) {
                                            int a = z.m[(yy - z.y) * z.w + xx - z.x] & 0xFF;
                                            if (a == 0) continue;
                                            if (!have) { c2 = shadePixel(q, pz, s, wv, L, P, t, k, op1, opL, improve, xx, yy, col, lk, tipLut[q.idx], patLut[q.idx], XL, XK, EX[q.idx]); have = true; }
                                            int di = (yy - dy0) * dw + xx - dx0;
                                            int src = (a << 24) | (c2 & 0x00FFFFFF);
                                            dst[di] = a >= 255 ? src : ZoneTone.over(dst[di], src, a);
                                        }
                                }
                            }
                        }
                    });
                    continue;
                }
                parallel(ey - oy, new Rows() {
                    public void run(int r0, int r1) {
                        float[] col = new float[3];
                        for (int y = oy + r0; y < oy + r1; y++) {
                            if ((y & 31) == 0 && cc.cancelled()) throw new Cancelled();
                            int my = y - z.y;
                            for (int x = ox; x < ex; x++) {
                                int a = z.m[my * z.w + x - z.x] & 0xFF;
                                if (a == 0) continue;
                                int c2 = shadePixel(q, pz, s, wv, L, P, t, k, op1, opL, improve, x, y, col, lk, tipLut[q.idx], patLut[q.idx], XL, XK, EX[q.idx]);
                                int di = (y - dy0) * dw + x - dx0;
                                int src = (a << 24) | (c2 & 0x00FFFFFF);
                                dst[di] = a >= 255 ? src : ZoneTone.over(dst[di], src, a);
                            }
                        }
                    }
                });
            }
            long T2 = System.nanoTime();
            if (P.colorLines && only < 0) colorGapLines(pal, dst, dx0, dy0, dw, dh);
            long T3 = System.nanoTime();
            if (!draft) glowAndTint(dst, dx0, dy0, dw, dh, k, c, lk, false);   // al arrastrar: sin resplandor ni tinte
            long T4 = System.nanoTime();
            if (DBG) System.out.printf("  campos %d ms, pixeles %d ms, lineas %d ms, resplandor %d ms%n", (T1 - T0) / 1000000, (T2 - T1) / 1000000, (T3 - T2) / 1000000, (T4 - T3) / 1000000);
        }

        /**
         * v8.63: en la ropa, el borde de la sombra se acerca a la linea de pliegue mas cercana (como lo hace un
         * dibujante). Se calcula en la grilla chica (barato) y se suaviza a lo largo del borde, sin escalones.
         */
        private void foldSnap(final ZCtx q, final float[] s, final float t) {
            final boolean[] fg = q.foldG;
            if (fg == null) return;
            final int gw = q.gw, gh = q.gh;
            final float f = q.f;
            // en celdas de la grilla
            final float R = Math.max(4f, Math.min(Math.min(40f, 0.022f * D), 0.22f * Math.min(q.w, q.h))) / f;
            final float[] off = new float[gw * gh], band = new float[gw * gh], gmA = new float[gw * gh];
            final boolean[] any = new boolean[1];
            parallel(gh - 2, new Rows() {
                public void run(int r0, int r1) {
                    boolean hit = false;
                    for (int gy = 1 + r0; gy < 1 + r1; gy++)
                        for (int gx = 1; gx < gw - 1; gx++) {
                            int i = gy * gw + gx;
                            if (!q.in[i]) continue;
                            float dsx = (s[i + 1] - s[i - 1]) * 0.5f, dsy = (s[i + gw] - s[i - gw]) * 0.5f;
                            float gm = (float) Math.sqrt(dsx * dsx + dsy * dsy);
                            gmA[i] = gm;
                            if (gm < 1e-6f) continue;
                            float up = (s[i] - t) / gm;          // celdas hasta el borde de la sombra
                            if (up >= R || up <= -R) continue;
                            band[i] = 1f;
                            float ux = dsx / gm, uy = dsy / gm;
                            float tx = gx - up * ux, ty = gy - up * uy;
                            search:
                            for (float u = 0f; u <= R; u += 0.75f)
                                for (int sg = 0; sg < 2; sg++) {
                                    if (sg == 1 && u == 0f) continue;
                                    float uu = sg == 0 ? u : -u;
                                    int cx = Math.round(tx + uu * ux), cy = Math.round(ty + uu * uy);
                                    if (cx < 0 || cy < 0 || cx >= gw || cy >= gh || !fg[cy * gw + cx]) continue;
                                    off[i] = uu;
                                    hit = true;
                                    break search;
                                }
                        }
                    if (hit) any[0] = true;
                }
            });
            if (!any[0]) return;
            float sig = Math.max(1f, R * 0.45f);
            blur(off, gw, gh, sig);
            blur(band, gw, gh, sig);
            for (int i = 0; i < s.length; i++) {
                if (!q.in[i] || band[i] < 1e-3f || gmA[i] < 1e-6f) continue;
                float u = off[i] / band[i];
                float up = Math.abs((s[i] - t) / gmA[i]);
                float fade = 1f - smooth(R, 1.6f * R, up);
                s[i] -= u * gmA[i] * fade;
            }
        }

        /** Celdas con una linea que tiene zona a los dos lados (pliegue, no contorno). Solo ropa. */
        private void buildFoldGrid(ZCtx q) {
            if (q.bg || q.eye || q.thin || q.hair || q.skin || q.face) return;
            // del mismo color que el pelo = es pelo (mechones que no se reconocieron): no
            for (ZCtx o : ctx) if (o != null && o.hair && o.z.s.base == q.z.s.base) return;
            if (q.darkZone) return;
            if (Math.min(q.w, q.h) < 0.08f * D) return;      // piezas chicas (lazo, cuello de camisa): no
            ZoneTone.Zone z = q.z;
            int f = q.f, sd = Math.max(4, Math.round(0.004f * D));
            boolean[] g = new boolean[q.gw * q.gh];
            boolean any = false;
            for (int y = 0; y < q.h; y++) {
                int gy = y / f + 1, py = y + q.y0;
                for (int x = 0; x < q.w; x++) {
                    int px = x + q.x0;
                    if ((lineA[(py - uy0) * uw + px - ux0] & 0xFF) < 115) continue;
                    int gi = gy * q.gw + x / f + 1;
                    if (g[gi]) continue;
                    if (!inZone(z, px, py)) continue;
                    boolean inner = (inZone(z, px - sd, py) && inZone(z, px + sd, py)) || (inZone(z, px, py - sd) && inZone(z, px, py + sd));
                    if (inner) { g[gi] = true; any = true; }
                }
            }
            if (any) q.foldG = g;
        }

        private static boolean inZone(ZoneTone.Zone z, int x, int y) {
            int mx = x - z.x, my = y - z.y;
            return mx >= 0 && my >= 0 && mx < z.w && my < z.h && (z.m[my * z.w + mx] & 0xFF) >= 128;
        }

        /** El color de un pixel de la zona. */
        private int shadePixel(ZCtx q, Pal pz, float[] s, float[] wv, Light L, Params P, float t, float k,
                               float op1, float opL, boolean improve, int x, int y, float[] col, LK lk,
                               Pal[] tipL, Pal[] patL, Light[] XL, LK[] XK, float[][] ex) {
            int ui = (y - uy0) * uw + x - ux0;
            int v = lum[ui] & 0xFF;
            float lA = (lineA[ui] & 0xFF) / 255f;
            float gx = (x - q.x0 + 0.5f) / q.f - 0.5f + 1f, gy = (y - q.y0 + 0.5f) / q.f - 0.5f + 1f;
            float sv = bil(s, q.gw, q.gh, gx, gy), w = bil(wv, q.gw, q.gh, gx, gy);
            final boolean anime = P.anime;
            if (anime) w = Math.max(0.0025f, w * 0.6f);   // anime: borde de sombra mas nitido
            // v8.63: puntas del pelo de otro color y estampados: se mezcla la paleta (las sombras siguen al color)
            if (tipL != null && q.colBot != null && q.colTop != null) {
                int lx = Math.min(q.w - 1, Math.max(0, x - q.x0));
                int top = q.colTop[lx], bot = q.colBot[lx];
                if (top >= 0 && bot > top + 4) {
                    float vt = (y - q.y0 - top) / (float) (bot - top);
                    float tt = smooth(0.55f, 1.0f, vt) * 0.85f;
                    if (tt > 0.003f) pz = tipL[Math.round(tt * 32f)];
                }
            }
            if (patL != null && q.pattern > 0) {
                float cell = Math.max(6f, 0.014f * D);
                float pc = patternAt(q.pattern, x, y, cell);
                if (pc > 0.003f) pz = patL[Math.round(pc * 4f)];
            }
            // el iris no lleva volumen (solo su degradado): si no, salen medias lunas
            final float fol = q.follow, nof = 1f - fol;
            float sh1 = q.bg || q.eye ? 0f : 1f - smooth(t - w, t + w, sv);
            // sombra que echa el pelo (borde con signo, bilineal)
            float cast = 0f, contact = 0f;
            if (q.sdf != null) {
                float len = (0.012f + 0.016f * L.sinT) * D;
                float px = x + L.dx * len - q.sx0, py = y + L.dy * len - q.sy0;
                float sd = bil(q.sdf, q.sw, q.sh, px, py);
                float wc = Math.max(1.2f, Math.min(3f, 0.0012f * D));
                cast = clamp01(0.5f - sd / wc);
                float d0 = bil(q.sdf, q.sw, q.sh, x - q.sx0, y - q.sy0);
                contact = 1f - smooth(0f, 0.008f * D, Math.max(0f, d0));
                sh1 = Math.max(sh1, cast);
            }
            // v8.63: sombra del menton sobre el cuello (cara y cuello en la misma zona), salvo luz de abajo
            if (q.chinCol != null && L.dy < 0.35f) {
                int lx = x - q.x0;
                int cy = lx >= 0 && lx < q.w ? q.chinCol[lx] : -1;
                if (cy >= 0 && y - q.y0 >= cy - 1) {
                    float rel = (x - q.neckCx) / Math.max(1f, q.neckHalfW);
                    float depth = q.chinDepth * Math.max(0.3f, 1f - 0.6f * rel * rel) * (0.8f + 0.4f * L.sinT);
                    float dd = (cy + q.y0 + depth) - y;
                    float ca = clamp01(0.5f + dd / 1.5f);
                    sh1 = Math.max(sh1, ca);
                }
            }
            // v8.85: si el dibujo ya trae sus sombras no se inventa otra encima
            sh1 *= nof;
            // oclusion (2a sombra): lineas que se juntan y contacto con el pelo, solo dentro de la sombra 1
            float occ = 0f;
            if (q.dens != null) occ = 0.75f * bil(q.dens, q.gw, q.gh, gx, gy);
            occ = clamp01(occ + 0.8f * contact * cast);
            float sh2 = smooth(0.42f, 0.62f, occ) * sh1;
            if (dbgShadow != null) dbgShadow[ui] = sh1;
            // base
            float r, g, b;
            if (improve) {
                int src = ref[y * W + x];
                r = ((src >> 16) & 255) / 255f; g = ((src >> 8) & 255) / 255f; b = (src & 255) / 255f;
            } else if (q.darkZone) {
                // zona casi negra (pelo negro de manga): de negro a la sombra, de gris a la base
                float tt = smooth(0.08f, 0.85f, v / (float) q.paper);
                r = pz.s2[0] + (pz.base[0] - pz.s2[0]) * tt;
                g = pz.s2[1] + (pz.base[1] - pz.s2[1]) * tt;
                b = pz.s2[2] + (pz.base[2] - pz.s2[2]) * tt;
                lA = 0f;
            } else {
                r = pz.base[0]; g = pz.base[1]; b = pz.base[2];
            }
            // sombras 1 y 2 de la paleta; el tipo de luz las tine (tarde, luna...)
            float s1r = pz.s1[0], s1g = pz.s1[1], s1b = pz.s1[2], s2r = pz.s2[0], s2g = pz.s2[1], s2b = pz.s2[2];
            if (lk.shAmt > 0f) {
                float am = lk.shAmt;
                s1r += (s1r * lk.shTint[0] - s1r) * am; s1g += (s1g * lk.shTint[1] - s1g) * am; s1b += (s1b * lk.shTint[2] - s1b) * am;
                s2r += (s2r * lk.shTint[0] - s2r) * am; s2g += (s2g * lk.shTint[1] - s2g) * am; s2b += (s2b * lk.shTint[2] - s2b) * am;
            }
            // v8.85: las sombras que YA trae el dibujo toman color (base -> sombra 1 -> sombra 2),
            // enteras y parejas en toda la parte. Antes solo oscurecian a medias (quedaba palido).
            float u = 0f;
            if (!improve && !q.darkZone) {
                u = q.uLut[v];
                if (anime && u > 0f) {
                    // anime: los mismos grises, en escalones mas marcados
                    float st = 0.16f * smooth(0.05f, 0.10f, u) + 0.26f * smooth(0.20f, 0.27f, u)+ 0.08f * smooth(0.36f, 0.44f, u) + 0.50f * smooth(0.55f, 0.95f, u);
                    u = 0.4f * u + 0.6f * st;
                }
                if (u > 0.004f) {
                    if (u < 0.14f) {
                        float a = u / 0.14f;
                        r += (s1r - r) * a; g += (s1g - g) * a; b += (s1b - b) * a;
                    } else if (u < 0.40f) {
                        float a = (u - 0.14f) / 0.26f;
                        r = s1r + (s2r - s1r) * a; g = s1g + (s2g - s1g) * a; b = s1b + (s2b - s1b) * a;
                    } else {
                        float a = 1f - 0.6f * (u - 0.40f) / 0.60f;
                        r = s2r * a; g = s2g * a; b = s2b * a;
                    }
                }
            }
            // pelo: degradado raiz-punta (mas oscuro arriba) y puntas tibias
            if (q.hair && q.colTop != null) {
                int lx = x - q.x0;
                int top = q.colTop[Math.min(q.w - 1, Math.max(0, lx))];
                float vv = clamp01((y - q.y0 - Math.max(0, top)) / Math.max(8f, q.h * 0.5f));
                float dk = 0.30f * op1 * (1f - smooth(0f, 0.55f, vv));
                r += (pz.s1[0] - r) * dk; g += (pz.s1[1] - g) * dk; b += (pz.s1[2] - b) * dk;
            }
            // ojos: iris mas oscuro arriba (parpado) y mas claro abajo
            if (q.eye) {
                float vy = clamp01((y - q.y0) / (float) Math.max(1, q.h));
                float top = 0.55f * op1 * (1f - smooth(0f, 0.45f, vy));
                r += (pz.s2[0] - r) * top; g += (pz.s2[1] - g) * top; b += (pz.s2[2] - b) * top;
                float bot = 0.30f * opL * smooth(0.55f, 0.95f, vy);
                r += (pz.light[0] - r) * bot; g += (pz.light[1] - g) * bot; b += (pz.light[2] - b) * bot;
            }
            // v8.61 (manhwa): degradado suave hacia la sombra dentro de la luz (aerografo), mas en la piel
            if (!anime && !q.bg && !q.eye && op1 > 0f) {
                float soft = (1f - smooth(t, t + 0.55f, sv)) * (1f - sh1) * (pz.skin ? 0.32f : 0.20f) * op1 * nof;
                if (soft > 0f) {
                    r += (pz.s1[0] - r) * soft; g += (pz.s1[1] - g) * soft; b += (pz.s1[2] - b) * soft;
                }
            }
            // sombra 1 y 2 (colores de sombra, no gris); el tipo de luz las tine (tarde, luna...)
            float a1 = sh1 * op1 * (anime ? 1.12f : 1f), a2 = sh2 * op1;
            if (a1 > 1f) a1 = 1f;
            r += (s1r - r) * a1; g += (s1g - g) * a1; b += (s1b - b) * a1;
            r += (s2r - r) * a2; g += (s2g - g) * a2; b += (s2b - b) * a2;
            // v8.61 (manhwa): en la piel, un borde calido y saturado justo donde la luz pasa a sombra
            if (pz.skin && !q.bg && op1 > 0f && !anime) {
                float edge = Math.max(0f, 1f - Math.abs(sv - t) / Math.max(0.06f, w * 6f)) * (1f - sh1 * 0.7f);
                float warm = edge * 0.24f * op1 * nof;
                if (warm > 0f) {
                    r += (pz.s2[0] * 1.05f - r) * warm; g += (pz.s2[1] * 0.92f - g) * warm; b += (pz.s2[2] * 0.95f - b) * warm;
                }
            }
            // v8.63: luces extra. Del lado que mira cada luz: la sombra se aclara hacia el color de esa luz
            // (ej: sol que sale arriba y luna abajo), un toque en la luz y su propio borde de luz.
            if (ex != null && !q.eye) {
                for (int j = 0; j < ex.length; j++) {
                    float s2 = bil(ex[j], q.gw, q.gh, gx, gy);
                    float l2 = anime ? smooth(0.10f, 0.16f, s2) : smooth(-0.05f, 0.40f, s2);
                    if (l2 <= 0f) continue;
                    LK xk = XK[j];
                    float lift = l2 * Math.max(sh1, fol * Math.min(1f, u * 2.5f)) * 0.45f * opL;   // dentro de la sombra
                    float touch = l2 * (1f - sh1) * 0.10f * opL;    // en la luz, apenas
                    // un poco mas oscuro que la luz principal: se nota como "otra" luz, con su color
                    float tr = pz.base[0] * xk.light[0] * 0.93f, tg = pz.base[1] * xk.light[1] * 0.93f, tb = pz.base[2] * xk.light[2] * 0.93f;
                    float am = lift + touch;
                    r += (tr - r) * am; g += (tg - g) * am; b += (tb - b) * am;
                }
            }
            // noche: todo un poco mas oscuro (sin cambiar el tono de la piel)
            if (lk.dim < 1f && !q.bg) { r *= lk.dim; g *= lk.dim; b *= lk.dim; }
            else if (lk.dim < 1f) { float dd = 0.5f + 0.5f * lk.dim; r *= dd; g *= dd; b *= dd; }
            // luz suave del lado del sol (Trama)
            if (!q.bg && !q.eye) {
                // anime: dos tonos limpios (sin luz suave); manhwa: luz suave del lado del sol
                float lit = anime ? 0f : smooth(t + 0.38f, t + 0.68f, sv) * (1f - sh1) * 0.38f * opL * nof;
                // v8.85: con sombras propias del dibujo, el sol es un degradado ANCHO y suave que cruza
                // toda la figura: luz del lado del sol, un poco mas de sombra del otro. Sin bordes duros.
                if (fol > 0f) {
                    charNormal(x, y, col);
                    float face = col[0] * L.dx + col[1] * L.dy;
                    float pos = ((x - charCx) * L.dx + (y - charCy) * L.dy) / Math.max(1f, 0.30f * (float) Math.hypot(uw, uh));
                    float g2 = 0.75f * face + 0.55f * Math.max(-1f, Math.min(1f, pos));
                    float far = smooth(0.0f, 0.9f, -g2) * (anime ? 0.50f : 0.55f) * op1 * fol * (1f - 0.6f * Math.min(1f, u * 2f));
                    if (far > 0f) { r += (s1r - r) * far; g += (s1g - g) * far; b += (s1b - b) * far; }
                    // retoques con el dedo (Sombra + / Luz +): tambien suaves, donde se paso el dedo
                    float ed = bil(q.edit, q.gw, q.gh, gx, gy);
                    if (ed < -0.04f) {
                        float es = smooth(0.04f, 0.7f, -ed) * 0.85f * Math.min(1f, op1 * 1.3f) * fol;
                        r += (s1r - r) * es; g += (s1g - g) * es; b += (s1b - b) * es;
                    } else if (ed > 0.04f) lit += smooth(0.04f, 0.7f, ed) * 0.45f * opL * fol;
                    float du = 1f - Math.min(1f, u * 2.2f);
                    lit += smooth(0.0f, 0.9f, g2) * (anime ? 0.26f : 0.32f) * opL * fol * du;
                }
                if (lit > 0f) {
                    r = 1f - (1f - r) * (1f - pz.light[0] * lk.light[0] * lit);
                    g = 1f - (1f - g) * (1f - pz.light[1] * lk.light[1] * lit);
                    b = 1f - (1f - b) * (1f - pz.light[2] * lk.light[2] * lit);
                }
            }
            // v8.63: material brillante (metal, cuero, tela satinada): brillo especular nitido
            if (q.material == 1 && !q.bg) {
                float nx = bil(q.nx, q.gw, q.gh, gx, gy), ny = bil(q.ny, q.gw, q.gh, gx, gy), nz = bil(q.nz, q.gw, q.gh, gx, gy);
                float hx = L.lx, hy = L.ly, hz = L.lz + 1f;
                float hm = (float) Math.sqrt(hx * hx + hy * hy + hz * hz);
                float nh = Math.max(0f, (nx * hx + ny * hy + nz * hz) / hm);
                float sp = (float) Math.pow(nh, 28);
                float hl = smooth(anime ? 0.62f : 0.50f, anime ? 0.68f : 0.80f, sp) * (1f - sh1 * 0.6f) * 0.85f * opL;
                if (hl > 0f) {
                    r = 1f - (1f - r) * (1f - 0.97f * lk.light[0] * hl);
                    g = 1f - (1f - g) * (1f - 0.97f * lk.light[1] * hl);
                    b = 1f - (1f - b) * (1f - 0.95f * lk.light[2] * hl);
                }
                float deep = sh1 * 0.18f * op1;   // brillante: la sombra es mas profunda
                r *= 1f - deep; g *= 1f - deep; b *= 1f - deep;
            }
            // pelo: anillo de brillo roto en mechones (Anadir), solo en la luz
            if (q.ring && q.licN != null) {
                int lx = x - q.x0, ly = y - q.y0;
                int top = q.colTop[Math.min(q.w - 1, Math.max(0, lx))];
                if (top >= 0) {
                    float bandC = top + 0.42f * (q.faceTop - q.hairTop0);
                    float bandH = Math.max(3f, 0.13f * (q.faceTop - q.hairTop0));
                    float band = 1f - smooth(bandH * 0.45f, bandH, Math.abs(ly - bandC));
                    if (band > 0f) {
                        float lic = q.licN[ly * q.w + lx];
                        float side = 0.45f + 0.55f * clamp01(0.5f + 0.5f * sv);
                        float ra = (anime ? smooth(0.55f, 0.66f, lic) : smooth(0.42f, 0.78f, lic)) * band * side * (1f - sh1) * 0.62f * opL;
                        r = Math.min(1f, r + pz.ring[0] * lk.light[0] * ra * 0.8f);
                        g = Math.min(1f, g + pz.ring[1] * lk.light[1] * ra * 0.8f);
                        b = Math.min(1f, b + pz.ring[2] * lk.light[2] * ra * 0.8f);
                    }
                }
            }
            // rubor (solo si hay cara y dos ojos)
            if (q.face && eyes.size() == 2) {
                float bl = 0f;
                for (int e : eyes) {
                    ZCtx ez = ctx[e];
                    float cxp = ez.eyeCx, cyp = ez.eyeCy + ez.eyeRy * 2.1f;
                    float rx = ez.eyeRx * 1.25f, ry = ez.eyeRy * 0.75f;
                    float dxe = (x - cxp) / Math.max(1f, rx), dye = (y - cyp) / Math.max(1f, ry);
                    bl = Math.max(bl, (float) Math.exp(-(dxe * dxe + dye * dye) * 1.4f));
                }
                bl *= 0.16f * opL;
                r += (0.98f - r) * bl; g += (0.55f - g) * bl; b += (0.60f - b) * bl;
                // v8.61 (manhwa): brillo chico en la punta de la nariz, del lado del sol
                ZCtx e0 = ctx[eyes.get(0)], e1 = ctx[eyes.get(1)];
                float ed = Math.abs(e1.eyeCx - e0.eyeCx);
                if (ed > 4f) {
                    float nx = (e0.eyeCx + e1.eyeCx) * 0.5f + L.dx * ed * 0.08f;
                    float ny = (e0.eyeCy + e1.eyeCy) * 0.5f + ed * 0.62f + L.dy * ed * 0.04f;
                    float nr = ed * 0.07f;
                    float dxn = (x - nx) / nr, dyn = (y - ny) / (nr * 1.3f);
                    float hl = (float) Math.exp(-(dxn * dxn + dyn * dyn) * 1.6f) * 0.42f * opL * (1f - sh1);
                    if (hl > 0.003f) {
                        r = 1f - (1f - r) * (1f - 0.98f * lk.light[0] * hl);
                        g = 1f - (1f - g) * (1f - 0.96f * lk.light[1] * hl);
                        b = 1f - (1f - b) * (1f - 0.92f * lk.light[2] * hl);
                    }
                }
            }
            // grises y tramas del autor: se multiplican (sombra del dibujante, textura visible)
            if (!improve && !q.darkZone) {
                float P0 = q.paper;
                // blancos del autor (brillo de ojos y pelo) en zonas con grises: siguen claros
                if (q.author && v > P0 - 14) {
                    float wk = smooth(P0 - 14, P0 - 4, v) * 0.85f;
                    r += (pz.light[0] - r) * wk; g += (pz.light[1] - g) * wk; b += (pz.light[2] - b) * wk;
                }
            }
            // luz de borde: contorno EXTERIOR del lado del sol
            if (!q.bg) {
                int di = ui;
                float de = dExt[di];
                float rw = Math.max(2f, 0.003f * D);
                float rwh = rw * 3f;
                if (de < rwh) {
                    float band = 1f - smooth(rw * 0.55f, rw * 1.15f, de);
                    // v8.63: halo de contraluz: la luz "sangra" un poco hacia adentro de la silueta
                    float halo = (1f - smooth(rw * 0.8f, rwh, de)) * (0.06f + 0.10f * L.sinT);
                    band = Math.max(band, halo);
                    charNormal(x, y, col);          // se usa 'col' como espacio temporal (sin crear arreglos)
                    float m = (float) Math.hypot(col[0], col[1]);
                    float face = m > 1e-4f ? (col[0] * L.dx + col[1] * L.dy) / m : 0f;
                    float ra = band * smooth(0.25f, 0.65f, face) * 0.55f * opL * lk.rimMul * (anime ? 1.3f : 1f);
                    if (ra > 0f) {
                        r = Math.min(1f, r + pz.rim[0] * lk.rim[0] * ra);
                        g = Math.min(1f, g + pz.rim[1] * lk.rim[1] * ra);
                        b = Math.min(1f, b + pz.rim[2] * lk.rim[2] * ra);
                    }
                }
            }
            if (ex != null && !q.bg && !q.eye) {
                float de = dExt[ui];
                float rw = Math.max(2f, 0.003f * D);
                if (de < rw * 1.2f) {
                    float band = 1f - smooth(rw * 0.55f, rw * 1.15f, de);
                    charNormal(x, y, col);
                    float m = (float) Math.hypot(col[0], col[1]);
                    for (int j = 0; j < ex.length && m > 1e-4f; j++) {
                        float face = (col[0] * XL[j].dx + col[1] * XL[j].dy) / m;
                        float ra = band * smooth(0.25f, 0.65f, face) * 0.45f * opL * XK[j].rimMul;
                        if (ra > 0f) {
                            r = Math.min(1f, r + pz.rim[0] * XK[j].rim[0] * ra);
                            g = Math.min(1f, g + pz.rim[1] * XK[j].rim[1] * ra);
                            b = Math.min(1f, b + pz.rim[2] * XK[j].rim[2] * ra);
                        }
                    }
                }
            }
            // lineas de color (marron en piel, oscuro del pelo en el pelo) con su antialias.
            // En el iris la tinta es la pupila: queda casi negra (se conserva)
            if (lA > 0f) {
                if (q.eye) {
                    float ink = v / 255f * 0.5f;
                    float pr = pz.line[0] * 0.35f + ink, pg = pz.line[1] * 0.35f + ink, pb = pz.line[2] * 0.35f + ink;
                    r += (pr - r) * lA; g += (pg - g) * lA; b += (pb - b) * lA;
                } else if (P.colorLines && !improve) {
                    r += (pz.line[0] - r) * lA; g += (pz.line[1] - g) * lA; b += (pz.line[2] - b) * lA;
                } else {
                    float ink = v / 255f;
                    r += (ink - r) * lA; g += (ink - g) * lA; b += (ink - b) * lA;
                }
            }
            // v8.63: brillo de anime en los ojos (uno grande del lado de la luz y uno chico), si el dibujo no trae
            if (q.eye && !q.eyeOwnHL && opL > 0f) {
                float rx = Math.max(2f, q.eyeRx), ry = Math.max(2f, q.eyeRy);
                float h1 = ellipse(x, y, q.eyeCx + L.dx * rx * 0.30f, q.eyeCy - ry * 0.30f + L.dy * ry * 0.10f, rx * 0.24f, ry * 0.22f);
                float h2 = ellipse(x, y, q.eyeCx - L.dx * rx * 0.32f, q.eyeCy + ry * 0.36f, rx * 0.11f, ry * 0.10f);
                float hl = Math.max(h1, h2 * 0.85f) * Math.min(1f, opL * 1.2f);
                if (hl > 0f) {
                    r += (0.99f * lk.light[0] - r) * hl; g += (0.99f * lk.light[1] - g) * hl; b += (0.98f * lk.light[2] - b) * hl;
                }
            }
            col[0] = r; col[1] = g; col[2] = b;

            return 0xFF000000 | (to8(r) << 16) | (to8(g) << 8) | to8(b);
        }

        /** Lineas que quedaron entre zonas (fuera de toda mascara): del color de la zona vecina. */
        private void colorGapLines(Pal[] pal, int[] dst, int dx0, int dy0, int dw, int dh) {
            int x0 = Math.max(ux0, dx0), y0 = Math.max(uy0, dy0), x1 = Math.min(ux1, dx0 + dw), y1 = Math.min(uy1, dy0 + dh);
            int R = 3;
            for (int y = y0; y < y1; y++)
                for (int x = x0; x < x1; x++) {
                    int ui = (y - uy0) * uw + x - ux0;
                    if (owner[ui] != 0) continue;
                    float lA = (lineA[ui] & 0xFF) / 255f;
                    if (lA <= 0.02f) continue;
                    // zona mas cercana (la de color mas oscuro si empatan)
                    int best = -1; int bd = 99; float bL = 9f;
                    for (int dy = -R; dy <= R; dy++)
                        for (int dx = -R; dx <= R; dx++) {
                            int xx = x + dx - ux0, yy = y + dy - uy0;
                            if (xx < 0 || yy < 0 || xx >= uw || yy >= uh) continue;
                            int o = owner[yy * uw + xx];
                            if (o == 0) continue;
                            ZCtx q = ctx[o - 1];
                            if (q.bg || pal[o - 1] == null) continue;
                            int d = dx * dx + dy * dy;
                            float Lz = pal[o - 1].base[0] + pal[o - 1].base[1] + pal[o - 1].base[2];
                            if (d < bd || (d == bd && Lz < bL)) { bd = d; best = o - 1; bL = Lz; }
                        }
                    if (best < 0) continue;
                    float[] lc = pal[best].line;
                    int a = Math.round(lA * 255f);
                    int src = (a << 24) | (to8(lc[0]) << 16) | (to8(lc[1]) << 8) | to8(lc[2]);
                    int di = (y - dy0) * dw + x - dx0;
                    dst[di] = src;   // reemplaza: repetir el acabado no acumula
                }
        }

        /** Resplandor suave (Trama) y tinte ambiente (Luz suave), solo sobre lo pintado. */
        private void glowAndTint(int[] dst, int dx0, int dy0, int dw, int dh, float k, Cancel c, final LK lk, final boolean draft) {
            int x0 = Math.max(ux0, dx0), y0 = Math.max(uy0, dy0), x1 = Math.min(ux1, dx0 + dw), y1 = Math.min(uy1, dy0 + dh);
            if (x1 <= x0 || y1 <= y0 || k <= 0f) return;
            int w = x1 - x0, h = y1 - y0;
            int f = Math.max(2, (int) Math.ceil(Math.max(w, h) / 360f));
            int bw = (w + f - 1) / f, bh = (h + f - 1) / f;
            float[] L = new float[bw * bh], A = new float[bw * bh];
            final float invC = 1f / (f * f);
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int c2 = dst[(y + y0 - dy0) * dw + x + x0 - dx0];
                    int a = c2 >>> 24;
                    if (a == 0) continue;
                    float l = (((c2 >> 16) & 255) * 0.3f + ((c2 >> 8) & 255) * 0.59f + (c2 & 255) * 0.11f) / 255f;
                    int i = (y / f) * bw + x / f;
                    float wa = a / 255f;
                    // solo lo claro brilla (promedio de la celda)
                    L[i] += smooth(0.55f, 0.95f, l) * wa * invC;
                    A[i] += wa * invC;
                }
            float sig = Math.max(1f, 0.012f * D / f);
            if (!draft) {
                blur(L, bw, bh, sig);
                blur(A, bw, bh, sig);
            }
            if (c.cancelled()) throw new Cancelled();
            final float gop = draft ? 0f : 0.25f * lk.glowMul * Math.min(1f, k / 0.6f), top = lk.tintOp * Math.min(1f, k / 0.6f);
            final int fx0 = x0, fy0 = y0, fw = w, fbw = bw, fbh = bh, ff = f;
            final float[] fL = L;
            parallel(h, new Rows() {
                public void run(int r0, int r1) {
                    for (int y = r0; y < r1; y++) {
                        float ty = (y + fy0 - uy0) / (float) Math.max(1, uh - 1);
                        // calido arriba, frio abajo
                        float tr = lk.tintTop[0] + (lk.tintBot[0] - lk.tintTop[0]) * ty;
                        float tg = lk.tintTop[1] + (lk.tintBot[1] - lk.tintTop[1]) * ty;
                        float tb = lk.tintTop[2] + (lk.tintBot[2] - lk.tintTop[2]) * ty;
                        for (int x = 0; x < fw; x++) {
                            int di = (y + fy0 - dy0) * dw + x + fx0 - dx0;
                            int c2 = dst[di];
                            int a = c2 >>> 24;
                            if (a == 0) continue;
                            int ui = (y + fy0 - uy0) * uw + x + fx0 - ux0;
                            if (owner[ui] == 0) continue;
                            float gl = gop > 0f ? bil(fL, fbw, fbh, (x + 0.5f) / ff - 0.5f, (y + 0.5f) / ff - 0.5f) * gop : 0f;
                            float r = ((c2 >> 16) & 255) / 255f, g = ((c2 >> 8) & 255) / 255f, b = (c2 & 255) / 255f;
                            r = 1f - (1f - r) * (1f - gl); g = 1f - (1f - g) * (1f - gl); b = 1f - (1f - b) * (1f - gl);
                            r = soft(r, tr, top); g = soft(g, tg, top); b = soft(b, tb, top);
                            dst[di] = (a << 24) | (to8(r) << 16) | (to8(g) << 8) | to8(b);
                        }
                    }
                }
            });
        }
    }

    /** Elipse con borde de ~1 px (antialias). */
    static float ellipse(float x, float y, float cx, float cy, float rx, float ry) {
        float dx = (x - cx) / rx, dy = (y - cy) / ry;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        return clamp01((1f - d) * Math.min(rx, ry) + 0.5f);
    }

    /** n+1 paletas de a hacia b (se arma una vez por pintada). */
    static Pal[] palLut(Pal a, Pal b, int n) {
        Pal[] o = new Pal[n + 1];
        for (int i = 0; i <= n; i++) o[i] = blendPal(a, b, i / (float) n);
        return o;
    }

    /** Mezcla dos paletas (para puntas del pelo y estampados). */
    static Pal blendPal(Pal a, Pal b, float t) {
        Pal o = new Pal();
        o.skin = a.skin; o.dark = a.dark; o.neutral = a.neutral;
        o.base = lerp3(a.base, b.base, t); o.s1 = lerp3(a.s1, b.s1, t); o.s2 = lerp3(a.s2, b.s2, t);
        o.light = lerp3(a.light, b.light, t); o.rim = lerp3(a.rim, b.rim, t); o.line = lerp3(a.line, b.line, t);
        o.ring = lerp3(a.ring, b.ring, t);
        return o;
    }

    static float[] lerp3(float[] a, float[] b, float t) {
        return new float[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t};
    }

    /** Luz suave (W3C) con opacidad. */
    static float soft(float cb, float cs, float op) {
        float r;
        if (cs <= 0.5f) r = cb - (1f - 2f * cs) * cb * (1f - cb);
        else {
            float d = cb <= 0.25f ? ((16f * cb - 12f) * cb + 4f) * cb : (float) Math.sqrt(cb);
            r = cb + (2f * cs - 1f) * (d - cb);
        }
        return cb + (r - cb) * op;
    }

    static int to8(float v) { int i = Math.round(v * 255f); return i < 0 ? 0 : i > 255 ? 255 : i; }

    static float bil(float[] a, int w, int h, float x, float y) {
        if (x < 0) x = 0; if (y < 0) y = 0;
        if (x > w - 1) x = w - 1; if (y > h - 1) y = h - 1;
        int x0 = (int) x, y0 = (int) y;
        int x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
        float fx = x - x0, fy = y - y0;
        float a0 = a[y0 * w + x0] + (a[y0 * w + x1] - a[y0 * w + x0]) * fx;
        float a1 = a[y1 * w + x0] + (a[y1 * w + x1] - a[y1 * w + x0]) * fx;
        return a0 + (a1 - a0) * fy;
    }

    /** Parte del borde de la imagen que toca la zona (0..1). */
    static float edgeShare(ZoneTone.Zone z, int W, int H) {
        int touch = 0;
        for (int x = 0; x < z.w; x++) {
            if (z.y == 0 && (z.m[x] & 0xFF) >= 128) touch++;
            if (z.y + z.h == H && (z.m[(z.h - 1) * z.w + x] & 0xFF) >= 128) touch++;
        }
        for (int y = 0; y < z.h; y++) {
            if (z.x == 0 && (z.m[y * z.w] & 0xFF) >= 128) touch++;
            if (z.x + z.w == W && (z.m[y * z.w + z.w - 1] & 0xFF) >= 128) touch++;
        }
        return touch / (float) (2 * (W + H));
    }

    /** Tapa los huecos (zonas de afuera encerradas, que no tocan el borde) de hasta maxCells celdas. */
    static boolean[] fillHoles(boolean[] in, int w, int h, int maxCells) {
        boolean[] o = in.clone();
        boolean[] seen = new boolean[in.length];
        int[] st = new int[in.length], comp = new int[in.length];
        for (int s0 = 0; s0 < in.length; s0++) {
            if (in[s0] || seen[s0]) continue;
            int sp = 0, cn = 0;
            boolean border = false;
            st[sp++] = s0; seen[s0] = true;
            while (sp > 0) {
                int i = st[--sp];
                comp[cn++] = i;
                int x = i % w, y = i / w;
                if (x == 0 || y == 0 || x == w - 1 || y == h - 1) border = true;
                if (x > 0 && !in[i - 1] && !seen[i - 1]) { seen[i - 1] = true; st[sp++] = i - 1; }
                if (x < w - 1 && !in[i + 1] && !seen[i + 1]) { seen[i + 1] = true; st[sp++] = i + 1; }
                if (y > 0 && !in[i - w] && !seen[i - w]) { seen[i - w] = true; st[sp++] = i - w; }
                if (y < h - 1 && !in[i + w] && !seen[i + w]) { seen[i + w] = true; st[sp++] = i + w; }
            }
            if (!border && cn <= maxCells) for (int k = 0; k < cn; k++) o[comp[k]] = true;
        }
        return o;
    }

    static boolean[] dilate(boolean[] m, int w, int h, int r) {
        if (r <= 0) return m.clone();
        boolean[] seed = m;
        float[] d = edt(seed, w, h);
        boolean[] o = new boolean[m.length];
        for (int i = 0; i < o.length; i++) o[i] = d[i] <= r;
        return o;
    }

    /** Cierre (dilatar y luego erosionar) con radio r. */
    static boolean[] close(boolean[] m, int w, int h, int r) {
        boolean[] dl = dilate(m, w, h, r);
        boolean[] inv = new boolean[m.length];
        for (int i = 0; i < inv.length; i++) inv[i] = !dl[i];
        boolean anyOut = false;
        for (boolean b : inv) if (b) { anyOut = true; break; }
        if (!anyOut) return dl;
        float[] d = edt(inv, w, h);
        boolean[] o = new boolean[m.length];
        for (int i = 0; i < o.length; i++) o[i] = dl[i] && d[i] > r;
        for (int i = 0; i < o.length; i++) o[i] |= m[i];
        return o;
    }

    // ==================================================================================== una zona sola

    private static java.lang.ref.WeakReference<Object[]> lastSession;

    /**
     * Para volver a pintar UNA zona (cambiar su color, borrarla...) con el acabado guardado en su
     * estilo. Se hace el acabado completo (igual que en la pantalla de Acabado) y se toma la zona:
     * asi el resultado es identico. La sesion y el resultado quedan en cache mientras el dibujo y
     * la lista de zonas sean los mismos (las demas zonas de la misma vuelta salen al instante).
     */
    public static int[] renderZoneLocal(int[] src, int W, int H, ZoneTone.Zone z, List<ZoneTone.Zone> all) {
        List<ZoneTone.Zone> list = all;
        if (list == null || !list.contains(z)) { list = new ArrayList<ZoneTone.Zone>(); list.add(z); }
        Session s = null;
        synchronized (Acabado.class) {
            Object[] o = lastSession == null ? null : lastSession.get();
            if (o != null && o[0] == src && o[1] == list && o[2] instanceof Session) s = (Session) o[2];
        }
        if (s == null) {
            s = new Session(src, W, H, list, NEVER);
            synchronized (Acabado.class) { lastSession = new java.lang.ref.WeakReference<Object[]>(new Object[]{src, list, s}); }
        }
        int zi = s.zones.indexOf(z);
        if (zi < 0) return null;
        ZCtx q = s.ctx[zi];
        if (q.w == 0) return null;
        Params p = new Params();
        p.sunX = z.s.sunX / 1000f; p.sunY = z.s.sunY / 1000f; p.strength = z.s.strength; p.colorLines = z.s.colorLines;
        p.lightType = z.s.lightType;
        p.anime = z.s.anime;
        p.hairTip = z.s.hairTip;
        p.extraN = Math.min(MAX_EXTRA, z.s.extraN);
        for (int j = 0; j < p.extraN; j++) {
            p.exX[j] = z.s.exX[j] / 1000f; p.exY[j] = z.s.exY[j] / 1000f; p.exType[j] = z.s.exType[j];
        }
        s.syncExtras();
        int[] full = s.fullFor(p);
        int[] out = new int[z.w * z.h];
        for (int ly = 0; ly < z.h; ly++)
            for (int lx = 0; lx < z.w; lx++) {
                int a = z.m[ly * z.w + lx] & 0xFF;
                if (a == 0) continue;
                int gx = lx + z.x - s.ux0, gy = ly + z.y - s.uy0;
                if (gx < 0 || gy < 0 || gx >= s.uw || gy >= s.uh) continue;
                out[ly * z.w + lx] = (full[gy * s.uw + gx] & 0x00FFFFFF) | (a << 24);
            }
        return out;
    }
}
