package com.pacco.animecut;

import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * v8.73 "Acerca de y licencias" (como en WhatsApp: Ajustes > Ayuda > Licencias).
 *
 * Las licencias de las piezas de otros autores piden que su aviso de autor y el texto de su
 * licencia vayan DENTRO de la app y se puedan leer sin internet. Aqui hay una lista; al tocar
 * una pieza se abre su licencia completa. El texto se acomoda al ancho de la pantalla (antes las
 * lineas salian cortadas a la mitad).
 *
 * Se abre desde la galeria (boton i), desde Mas opciones > Acerca de, y desde la ventana de
 * descarga de la IA (Licencias).
 */
public class AboutActivity extends AppCompatActivity {

    // v8.86: la letra de la app crece con la del telefono solo hasta 115% (botones sin cortes)
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(PzSystem.fontCap(base));
    }

    /** Una pieza de otro autor que va dentro de la app. */
    private static final class Piece {
        final String name, what, author, license, file, url, note;
        Piece(String name, String what, String author, String license, String file, String url, String note) {
            this.name = name; this.what = what; this.author = author; this.license = license;
            this.file = file; this.url = url; this.note = note;
        }
    }

    private static final String APACHE = "licencias/apache-2.0.txt";
    /** Lo agrega la compilacion (lo baja de la pagina de ONNX Runtime). Puede faltar. */
    static final String ORT_NOTICES = "licencias/onnxruntime_avisos_terceros.txt";
    static final String ORT_NOTICES_URL = "https://github.com/microsoft/onnxruntime/blob/main/ThirdPartyNotices.txt";

    private static final Piece[] PIECES = {
            new Piece("ONNX Runtime",
                    "Hace funcionar la IA (Recortar con IA y Mejorar imagen) dentro del teléfono.",
                    "Copyright (c) Microsoft Corporation",
                    "Licencia MIT",
                    "licencias/mit-onnxruntime.txt",
                    "https://github.com/microsoft/onnxruntime",
                    "ONNX Runtime trae adentro piezas de otros autores. Sus avisos van completos al final de esta licencia."),
            new Piece("ISNet-Anime (anime-segmentation)",
                    "El modelo que reconoce al personaje en Recortar con IA. Se descarga una sola vez y se usa tal cual, sin cambios.",
                    "SkyTNT",
                    "Licencia Apache 2.0",
                    APACHE,
                    "https://github.com/SkyTNT/anime-segmentation",
                    "Pesos publicados en huggingface.co/skytnt/anime-seg, también con licencia Apache 2.0 según su autor. "
                            + "Basado en la red IS-Net (DIS) de Xuebin Qin y otros."),
            new Piece("Real-ESRGAN (modelo anime x4)",
                    "El modelo de Mejorar imagen: limpia los cuadritos del JPEG y afina las líneas.",
                    "Copyright (c) 2021, Xintao Wang",
                    "Licencia BSD 3-Clause",
                    "licencias/bsd3-realesrgan.txt",
                    "https://github.com/xinntao/Real-ESRGAN",
                    "Modelo realesr-animevideov3, convertido a ONNX en media precisión por Paint Zeta "
                            + "(la misma red y los mismos pesos)."),
            new Piece("AndroidX (AppCompat y sus piezas)",
                    "La base de las pantallas, botones y ventanas de la app.",
                    "Copyright (C) The Android Open Source Project",
                    "Licencia Apache 2.0",
                    APACHE,
                    "https://developer.android.com/jetpack/androidx",
                    "Incluye también Guava ListenableFuture (Copyright (C) The Guava Authors), con licencia Apache 2.0."),
            new Piece("Kotlin y JetBrains Annotations",
                    "Piezas pequeñas que AndroidX necesita para funcionar.",
                    "Copyright JetBrains s.r.o. y colaboradores de Kotlin",
                    "Licencia Apache 2.0",
                    APACHE,
                    "https://kotlinlang.org",
                    null),
    };

    private LinearLayout root;
    private TextView title;
    private View listView;
    private ListView textView;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        PzSystem.init(this);
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF101010);
        root.addView(header());
        setContentView(root);
        PzSystem.edgeToEdge(this);
        showList();
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { goBack(); }
        });
    }

    /** Atras: desde una licencia vuelve a la lista; desde la lista cierra. */
    private void goBack() {
        if (textView != null) showList();
        else finish();
    }

    // ------------------------------------------------------------------ partes de la pantalla

    private View header() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF1A1A1E);
        bar.setPadding(dp(4), dp(4), dp(12), dp(4));
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setBackgroundColor(0x00000000);
        back.setContentDescription("Volver");
        back.setPadding(dp(12), dp(12), dp(12), dp(12));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goBack(); }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        title = new TextView(this);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(dp(4), 0, 0, 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    private void setBody(View v) {
        while (root.getChildCount() > 1) root.removeViewAt(1);
        root.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void showList() {
        textView = null;
        title.setText("Acerca de");
        if (listView == null) listView = buildList();
        setBody(listView);
    }

    private View buildList() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(24));
        sv.addView(box);

        String version = "";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        TextView app = text("Paint Zeta", 22f, 0xFFFFFFFF, true);
        box.addView(app);
        box.addView(text("Versión " + version + "  ·  gratis y sin anuncios", 13f, 0xFF9A9AA2, false));

        box.addView(sectionTitle("Privacidad"));
        box.addView(text("Paint Zeta no recoge datos personales y no envía tus imágenes a ningún lado: "
                + "todo se hace dentro del teléfono. Solo usa internet una vez, si tú lo pides, para "
                + "descargar el modelo de Recortar con IA.", 14f, 0xFFDADADF, false));
        // v8.75: la politica completa (Google Play pide que tambien este dentro de la app)
        TextView pol = text("Leer la política de privacidad completa  ›", 14f, 0xFF7FD6FF, true);
        pol.setPadding(0, dp(10), 0, dp(4));
        pol.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showPrivacy(); }
        });
        box.addView(pol);

        box.addView(sectionTitle("Licencias de código abierto"));
        box.addView(text("Paint Zeta usa estas piezas de otros autores, con permiso de sus licencias. "
                + "Toca una para leer su licencia completa.", 14f, 0xFFDADADF, false));
        for (final Piece p : PIECES) box.addView(card(p));
        return sv;
    }

    private View card(final Piece p) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF1E1E24);
        bg.setCornerRadius(dp(12));
        c.setBackground(bg);
        c.addView(text(p.name, 16f, 0xFFFFFFFF, true));
        c.addView(text(p.what, 13f, 0xFFC8C8CE, false));
        TextView a = text(p.author, 12f, 0xFF9A9AA2, false);
        a.setPadding(0, dp(6), 0, 0);
        c.addView(a);
        TextView l = text(p.license + "  ›", 13f, 0xFF7FD6FF, true);
        l.setPadding(0, dp(4), 0, 0);
        c.addView(l);
        c.setClickable(true);
        c.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showLicense(p); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(10), 0, 0);
        c.setLayoutParams(lp);
        return c;
    }

    /** La licencia completa de una pieza, en parrafos (una lista: rapido aunque el texto sea largo). */
    private void showLicense(final Piece p) {
        title.setText(p.name);
        final List<String> paras = new ArrayList<String>();
        StringBuilder head = new StringBuilder();
        head.append(p.what).append("\n\n").append(p.author).append("\n").append(p.license);
        if (p.note != null) head.append("\n\n").append(p.note);
        head.append("\n\n").append(p.url);
        paras.add(head.toString());
        paras.addAll(reflow(readAsset(p.file, p.license + ": texto no disponible.")));
        if (p.file.endsWith("mit-onnxruntime.txt")) {
            String notices = readAsset(ORT_NOTICES, null);
            paras.add("——  Avisos de las piezas de otros autores que trae ONNX Runtime  ——");
            if (notices != null) paras.addAll(reflow(notices));
            else paras.add("El archivo completo de avisos de terceros de ONNX Runtime está en:\n" + ORT_NOTICES_URL);
        }
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setPadding(dp(16), dp(8), dp(16), dp(24));
        lv.setClipToPadding(false);
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return paras.size(); }
            @Override public Object getItem(int i) { return paras.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convert, ViewGroup parent) {
                TextView t = convert instanceof TextView ? (TextView) convert : text("", 13f, 0xFFDADADF, false);
                t.setText(paras.get(i));
                t.setTextColor(i == 0 ? 0xFFFFFFFF : 0xFFDADADF);
                t.setTextIsSelectable(false);
                t.setPadding(0, dp(i == 0 ? 4 : 6), 0, dp(i == 0 ? 10 : 6));
                return t;
            }
        });
        lv.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> parent, View v, int i, long id) {
                // tocar el primer parrafo (o el aviso de ONNX) abre su pagina
                String s = paras.get(i);
                String url = i == 0 ? p.url : (s.contains(ORT_NOTICES_URL) ? ORT_NOTICES_URL : null);
                if (url != null) openUrl(url);
            }
        });
        textView = lv;
        setBody(lv);
    }

    /** v8.75: la politica de privacidad completa, sin internet. */
    private void showPrivacy() {
        title.setText("Política de privacidad");
        final List<String> paras = reflow(readAsset("privacidad.txt",
                "Paint Zeta no recoge datos personales y no envía tus imágenes a ningún lado."));
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setPadding(dp(16), dp(8), dp(16), dp(24));
        lv.setClipToPadding(false);
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return paras.size(); }
            @Override public Object getItem(int i) { return paras.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convert, ViewGroup parent) {
                TextView t = convert instanceof TextView ? (TextView) convert : text("", 14f, 0xFFDADADF, false);
                t.setText(paras.get(i));
                boolean head = i == 0 || paras.get(i).matches("^\\d+\\. .*") && paras.get(i).length() < 60;
                t.setTextColor(head ? 0xFFFFFFFF : 0xFFDADADF);
                t.setTypeface(Typeface.DEFAULT, head ? Typeface.BOLD : Typeface.NORMAL);
                t.setPadding(0, dp(6), 0, dp(6));
                return t;
            }
        });
        textView = lv;
        setBody(lv);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, url, android.widget.Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------ texto

    private String readAsset(String name, String fallback) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            return fallback;
        }
    }

    /**
     * Los textos de licencia vienen cortados a ~75 letras por linea. Se unen las lineas de cada
     * parrafo para que el telefono acomode el texto a su ancho (sin cortes a la mitad). Las lineas
     * cortas (titulos, listas, nombres) quedan en su propia linea.
     */
    static List<String> reflow(String raw) {
        List<String> out = new ArrayList<String>();
        if (raw == null) return out;
        String[] lines = raw.replace("\r", "").split("\n", -1);
        StringBuilder para = new StringBuilder();
        int prevLen = 0;
        for (String line : lines) {
            String t = line.trim();
            if (t.isEmpty()) {
                if (para.length() > 0) { out.add(para.toString()); para.setLength(0); }
                prevLen = 0;
                continue;
            }
            String ex = line.replace("\t", "    ");
            int indent = ex.length() - ex.replaceAll("^\\s+", "").length();
            boolean centered = indent >= 12;          // titulo centrado ("Version 2.0, January 2004")
            if (para.length() > 0) {
                boolean join = prevLen >= 50 && !centered && !startsItem(t) && !isRule(t);
                para.append(join ? " " : "\n");
            }
            para.append(t);
            prevLen = centered ? 0 : ex.length();
            // un parrafo muy largo se parte (la lista sigue fluida)
            if (para.length() > 3000) { out.add(para.toString()); para.setLength(0); prevLen = 0; }
        }
        if (para.length() > 0) out.add(para.toString());
        return out;
    }

    private static boolean startsItem(String t) {
        if (t.startsWith("-") || t.startsWith("*") || t.startsWith("•")) return true;
        if (t.matches("^\\(?[a-zA-Z0-9]{1,3}[.)].*")) return true;
        return false;
    }

    private static boolean isRule(String t) {
        return t.length() >= 3 && t.replaceAll("[-_=*#~]", "").isEmpty();
    }

    // ------------------------------------------------------------------ ayudas

    private TextView sectionTitle(String s) {
        TextView t = text(s.toUpperCase(java.util.Locale.ROOT), 12f, 0xFF8A8A92, true);
        t.setPadding(0, dp(22), 0, dp(4));
        t.setLetterSpacing(0.06f);
        return t;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setLineSpacing(0f, 1.15f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
