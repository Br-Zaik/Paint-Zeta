package com.pacco.animecut.core;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Corre lo pesado en segundo plano para que la app no se congele. */
public final class Task {

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** Para avisar en pantalla si algo de fondo fallo (por ejemplo, sin memoria). */
    public interface ErrorListener {
        void onError(Throwable t);
    }

    private static volatile ErrorListener listener;

    private Task() {
    }

    public static void setErrorListener(ErrorListener l) {
        listener = l;
    }

    /**
     * v8.87: carril aparte para trabajos que NO tocan la obra (leer una imagen del telefono antes de
     * agregarla). Asi no esperan detras de un guardado largo. Lo que cambia la obra sigue en run().
     */
    private static final ExecutorService SIDE = Executors.newSingleThreadExecutor();

    public static void runSide(final Runnable background, final Runnable afterOnUi) {
        exec(SIDE, background, afterOnUi);
    }

    public static void run(final Runnable background, final Runnable afterOnUi) {
        exec(POOL, background, afterOnUi);
    }

    private static void exec(ExecutorService ex, final Runnable background, final Runnable afterOnUi) {
        ex.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    background.run();
                } catch (final Throwable t) {
                    t.printStackTrace();
                    final ErrorListener l = listener;
                    if (l != null) {
                        MAIN.post(new Runnable() {
                            @Override
                            public void run() {
                                l.onError(t);
                            }
                        });
                    }
                }
                MAIN.post(afterOnUi);
            }
        });
    }
}
