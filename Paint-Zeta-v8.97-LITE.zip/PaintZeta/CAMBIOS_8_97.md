# Paint Zeta v8.97 — Vuelven los atajos

Incluye todo lo de la 8.96 (ventanas abajo, imagen siempre visible, avisos en varias lineas, tema
oscuro fijo).

## Atajos que vuelven (para trabajar rapido)
- Menu de tres puntos: "Filtros" y "Estabilizador" otra vez.
- Costado de Capas: "Girar 90" otra vez (gira toda la imagen).
- "Girar imagen" del menu sigue abriendo Recortar en la pestana Girar (sin ventana en el medio).

## Revision
- Revisado con el compilador de Java sobre todo el codigo; solo faltan las piezas de Android, como
  siempre. No probado en un telefono.
