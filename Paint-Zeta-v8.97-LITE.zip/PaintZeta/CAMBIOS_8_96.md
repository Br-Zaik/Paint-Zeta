# Paint Zeta v8.96 — Revision de todas las herramientas: nada en el medio, sin repetidos, mas ligera

## Ventanas: ya no salen en el medio
- Las 117 ventanas de opciones de toda la app (pincel, balde, capas, filtros, colores, exportar,
  manga, zonas, borrar fondo, galeria, comprimir, IA...) ahora salen ABAJO, a lo ancho, como una
  hoja que sube desde abajo, con esquinas redondeadas y la misma tarjeta oscura.
- La sombra detras es suave: la imagen se sigue viendo arriba mientras cambias algo.
- Si la ventana pide escribir, sube encima del teclado.
- Los paneles que salian en el medio sin boton de referencia (por ejemplo Guardar imagen) ahora
  salen abajo, encima de las barras.

## Marcar, Recortar y texto
- La imagen se acomoda arriba del panel de abajo: el panel ya no tapa la parte de abajo de la
  imagen.
- En Marcar no se pierde el zoom que tenias. En Recortar la imagen se reacomoda con lugar
  alrededor.
- Nombres de las opciones que no entraban: ahora terminan en "..." (no se cortan feo).

## Opciones repetidas: quitadas
- Menu de tres puntos:
  - "Filtros": ya esta al costado de Capas.
  - "Estabilizador": ya tiene su boton arriba.
  - "Girar imagen" ya no abre otra ventana: abre Recortar en la pestana Girar.
- Costado de Capas: se quito "Girar 90" (giraba toda la imagen, no la capa). Girar la imagen esta
  en Recortar > Girar. En Capas queda solo lo de la capa (voltear la capa, etc.).

## Avisos de arriba
- Un aviso largo baja de linea (hasta 3) en vez de achicarse hasta no poder leerse.

## Siempre oscura
- La app usa siempre el tema oscuro: antes, con el telefono en modo claro, algunas ventanas salian
  blancas y otras oscuras.

## Mas ligera
- Las lineas punteadas de las cajas y de Tapar se arman una vez, no en cada cuadro de la pantalla.

## Revision
- Revisado con el compilador de Java sobre todo el codigo; solo faltan las piezas de Android, como
  siempre. No probado en un telefono.
- Pendiente para mas adelante: los paneles de Figuras, Pincel y Colores siguen como tarjeta encima
  de la barra de abajo (no en el medio). Si quieres, se pasan al mismo estilo de pestanas que
  Marcar.
