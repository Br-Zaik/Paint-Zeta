# Paint Zeta v8.90 — Guardar imagen: PNG, JPG o WebP, peso maximo y compartir

Incluye 8.88 (Marcar) y 8.89 (Recortar).

Donde: boton Guardar (abajo a la derecha) > "Imagen completa".
- Medida: Original, 75 %, 50 % o lado de 1080.
- Formato: PNG (con transparencia), JPG (liviano, lo transparente queda blanco) o WebP (liviano).
- Calidad (JPG y WebP).
- Peso maximo: sin limite, 300 kB, 500 kB, 1 MB o 2 MB. La app busca la mejor calidad que entra
  en ese peso; si ni asi entra, achica un poco la imagen. Al terminar dice la medida, el peso y la
  calidad que quedo.
- Nombre del archivo (se puede cambiar). Se guarda en Imagenes > Paint Zeta.
- "Guardar y compartir": al terminar abre el menu de Android para mandarla (WhatsApp, Telegram...).
- "Guardar directo la proxima vez": desde ahi no sale la ventana. Para cambiar los ajustes queda
  la opcion "Imagen completa: cambiar formato, calidad, peso..." en el mismo menu.
- El ZIP para animar y las capas sueltas no cambian.

## Comprobacion
- Revisado con el compilador de Java contra 8.88 (solo avisos de piezas de Android).
- No se compilo el APK ni se probo en telefono.
