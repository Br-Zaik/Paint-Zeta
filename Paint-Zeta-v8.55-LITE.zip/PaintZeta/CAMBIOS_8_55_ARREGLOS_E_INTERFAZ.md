# Paint Zeta v8.55: arreglos de tus capturas e interfaz más simple (sobre la v8.54)

La v8.54 sigue igual en lo que estaba bien: el pincel rápido, el Relleno normal y el B/N limpio.

## 1. Pincel de Borrar fondo: tiras blancas pegadas a la línea (capturas 1, 2 y 3)

- **Causa:** fue un error de mi pincel nuevo de la 8.54, no de las pruebas.
  - Para llegar pegado a la línea, el pincel avanzaba unos píxeles más desde el fondo.
  - Solo avanzaba en 4 direcciones (arriba, abajo, izquierda y derecha).
  - En líneas rectas (captura 4) alcanzaba. En líneas inclinadas (capturas 1 a 3) se quedaba corto y dejaba una tira o puntitos blancos.
- **Ahora:**
  - avanza en 8 direcciones (también en diagonal);
  - solo avanza mientras se acerca a la línea; así llega pegado al borde en cualquier ángulo;
  - por un corte de la línea no se pasa, porque al otro lado tendría que alejarse.
  - tampoco atraviesa una línea fina gris que el B/N dejó casi blanca: esa línea se respeta y el pincel no entra al pelo de al lado (eso apareció en la prueba con tu imagen y quedó corregido).
- **Medido en la PC:**
  - Línea inclinada a 35° y 45°: antes quedaban 141 a 154 píxeles blancos junto a la línea. Ahora, 0.
  - Sigue sin cruzar al otro lado: 0 píxeles borrados del otro lado.
  - Ahora frena cortes más grandes que antes, con el mismo ajuste.
  - Sigue igual de rápido: unos 1–2 ms por toque.

## 2. Pantalla negra y congelado (captura 5)

- **Pantalla negra:**
  - El botón redondo de girar, arriba, dejaba el lienzo marcado como "sin acomodar". Desde ahí el dibujo ya no se pintaba: quedaba negro hasta volver a abrir la obra.
  - Ahora girar solo gira la vista.
- **Deshacer tocando rápido:**
  - Cada toque rehacía toda la pantalla y además mandaba a medir la imagen en otro hilo. Con varios toques seguidos el teléfono se trababa.
  - Ahora los toques seguidos se juntan: se deshacen todos de una vez, con una sola actualización de la pantalla.
  - La medida de la imagen espera a que dejes de tocar, y nunca hay dos a la vez.
- **Dos dedos muy sensible:**
  - Al mover o hacer zoom rápido con dos dedos, la app lo tomaba como "toque de dos dedos" y deshacía.
  - Ahora solo deshace un toque de verdad: corto y sin mover los dedos.

## 3. Colorear (captura 6)

- **Al cambiar de color se cambiaba todo, y a veces se despintaba:**
  - Las zonas que tocabas quedaban "en vista previa" con el color del momento. Al elegir otro color, todas las pendientes tomaban el nuevo.
  - Tocar otra vez una zona pendiente la quitaba: eso era el "despintar".
  - Ahora, en 1 Colorear, cada toque pinta al momento con el color elegido. Eliges otro color y tocas otra parte de la ropa: solo esa cambia. Deshacer quita el último toque.
- **Las tarjetas tapaban el dibujo:**
  - Las tarjetas de Colorear, Toques y Luz/Estilo estaban arriba, encima del dibujo.
  - Ahora van abajo, encima de las herramientas, y un poco transparentes. Arriba y al centro se ve si el ajuste se aplica.

## 4. Interfaz como Ibis (capturas 12 a 19)

- **Capas:**
  - El panel es más angosto, va al costado derecho y es semitransparente: se ve el dibujo de atrás.
  - Las filas son más chicas. Los botones de la capa elegida (Flecha, Colorear B/N, Opciones) pasaron a la barra del costado.
  - Arriba siguen los cuadritos de fondo: cuadros claros, cuadros oscuros, blanco, negro, verde y gris.
- **Opacidad:** la barra va de cuadritos (transparente) a oscuro (100 %), como en Ibis. Al lado dice el número.
- **Modo de mezcla:** es una lista como la de Ibis, por grupos (Normal, Oscurecer, Aclarar, Contraste, Diferencia, Color).
  - Tocar un modo lo aplica al momento, y la lista sigue abierta para probar otro.
  - Tocar fuera la cierra. Mantener pulsado un modo dice para qué sirve.
- **Colores:** la rueda tiene al costado tus colores guardados.
  - "+" guarda el color actual.
  - Mantener pulsado un color lo quita.
- **Gotero:** al tocar y mover el dedo aparece una burbuja: arriba el color nuevo y abajo el que tienes ahora. Al soltar queda el nuevo. Lo mismo al mantener pulsado con otras herramientas.
- **Lápiz (nuevo, en Pintar y retocar):** dibuja a mano libre con borde definido, para formas rápidas.
  - Recuerda su propio tamaño.
  - Al volver a la Brocha, ella recupera su pincel y su tamaño.

## Qué falta probar en tu teléfono

- El pincel junto a líneas inclinadas, con tu B/N.
- El botón de girar.
- Deshacer tocando muy rápido.
- Mover y hacer zoom con dos dedos sin que deshaga.
- 1 Colorear con varios colores.
- El panel de capas nuevo, la lista de modos, la paleta al costado, el gotero y el Lápiz.

Lo del pincel se midió en la PC con tus imágenes y con dibujos de prueba. Lo de la pantalla y los botones se revisó en el código, pero no se pudo armar el APK aquí: lo compila GitHub Actions como siempre.
