# Paint Zeta v8.81 — Contorno, resplandor de silueta, lineas radiales y de velocidad (parte 4 de 5)

Incluye todo lo de la 8.73 a la 8.80.

## Arreglo pendiente de la parte 3
- Rayos de luz ahora dice que capa lee: "Lee: «nombre de la capa»" y la casilla
  "Fuente: la capa de abajo («nombre»)".

## 4 filtros nuevos (en Filtros, fila de miniaturas)
Los cuatro van en una CAPA NUEVA aparte: tu dibujo no cambia y el efecto se puede ocultar,
borrar a mano o bajar de opacidad. Un solo paso en Deshacer. La pantalla dice si la capa nueva
queda ENCIMA o DEBAJO de la tuya, y la vista previa ya la muestra asi.

### Contorno
- Exterior, Interior o Ambos. Grosor (0 a 100), color, opacidad y suavidad.
- Sigue la forma por su transparencia: huecos (la A, un aro) y piezas sueltas tienen su propio
  borde. Un hueco mas angosto que dos veces el grosor se llena (como en cualquier contorno).
- Exterior va DEBAJO de tu capa (el borde suave del dibujo cae encima, sin rendija blanca).
  Interior y Ambos van ENCIMA.
- Grosor 0 o capa vacia: no crea nada.
- Si la capa no tiene partes transparentes (una foto entera) avisa: no hay silueta que seguir,
  primero hay que recortar el personaje. No inventa un borde.

### Resplandor de silueta
- Exterior, Interior o Ambos. Radio, intensidad (hasta 200 %), suavidad y color (neon).
- Sale de la FORMA, no de lo claro: una figura negra tambien brilla.
- Casilla "Como luz (modo Anadir)" para neon sobre fondos oscuros.
- Es distinto del "Resplandor" de siempre (ese hace brillar lo claro de la imagen) y no se toco.

### Lineas radiales (concentracion de manga)
- Centro: tocar o arrastrar. Cantidad, grosor, zona libre del centro; en Mas ajustes: largo,
  variacion y opacidad. Color (negro por defecto).
- Lineas en cuna: gruesas afuera y en punta hacia el centro. Negras y nitidas.
- Van DETRAS de tu capa (casilla "Encima de la capa" para ponerlas delante).
- "↻ Otra distribucion": cambia el reparto de las lineas. Mover las barras NO lo cambia.

### Lineas de velocidad
- Angulo, cantidad, grosor; en Mas ajustes: largo, variacion y opacidad. Finas en las puntas.
- Mismo comportamiento: detras por defecto, "Otra distribucion", color.

## Seleccion
- Contorno y resplandor: solo lo seleccionado lleva el efecto.
- Lineas: solo se dibujan dentro de lo seleccionado.
- Rayos de luz: solo lo seleccionado da luz (como en la 8.80).

## Pruebas en PC (motores, no el telefono)
- 18 pruebas OK: distancia exacta; grosor 0 = nada; capa vacia = nada; capa opaca no inventa
  borde; respeta el agujero de un aro; no cierra un hueco de 11 px entre dedos con grosor 3;
  por franjas = entero (contorno, resplandor y las dos lineas: sin cortes); misma semilla =
  mismas lineas; "Otra distribucion" cambia; zona libre vacia; opacidad e intensidad 0 = nada;
  vista previa parecida al final; una figura negra tambien brilla.
- Tiempos en PC con 1800 x 1800: contorno 0,24 s, lineas 0,2 s, resplandor 0,12 s.
- Imagenes: prueba_8_81_contorno_y_resplandor.png y prueba_8_81_lineas_manga.png.

## Limites
- La pantalla de Filtros no se pudo probar en PC (necesita Android).
- Las categorias (Estilo, Luz, Manga, Desenfoque) en la fila de filtros quedan para la parte 5.
