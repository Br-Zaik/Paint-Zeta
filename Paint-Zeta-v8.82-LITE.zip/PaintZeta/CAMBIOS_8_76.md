# Paint Zeta v8.76 — Fluidez parte 1: lapiz y trazo al instante

Primera parte del punto 20 (fluidez y lapiz). Incluye todo lo de la 8.73 a la 8.75.

## Lapiz (S Pen, lapices de tablet)
- Con lapiz el trazo empieza AL INSTANTE (antes esperaba un momento por si era zoom con dos
  dedos; un lapiz no hace zoom).
- "Solo el lapiz pinta": la primera vez que usas un lapiz se activa solo y sale un aviso. Desde
  ahi la palma apoyada no marca nada y el dedo solo mueve y hace zoom. Funciona aunque la palma
  toque antes que el lapiz, o el lapiz se levante antes que la palma.
- Se cambia en Mas opciones > Vista > "Solo lapiz".

## Dedo
- El trazo con el dedo espera menos al empezar (90 -> 60 milesimas). Si llega un segundo dedo
  igual se cancela, como antes.
- El trazo pide los toques sin esperar al siguiente cuadro de pantalla: la linea va mas pegada
  al dedo o al lapiz.

## Memoria
- Cuando Android pide memoria (la app se fue al fondo o el telefono anda justo), se suelta la
  imagen nitida del zoom (se vuelve a armar sola) y, si es grave, parte del Deshacer mas antiguo.
  Asi Android cierra menos la app en segundo plano.

## Lo que NO se toco (a proposito)
- El guardado automatico sigue en la misma fila que filtros y exportar: separarlo podria guardar
  una obra a medio cambiar. Es mas seguro asi.
- La presion del lapiz (grosor segun cuanto aprietas) y el envio de la imagen a la pantalla por
  pedazos van en la parte 2.
