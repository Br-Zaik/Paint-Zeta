# Paint Zeta v8.75 — Lo que pide Google Play

Puntos 16 al 19 del analisis de la 8.72. Incluye todo lo de la 8.73 y la 8.74.

## 16. Libreria de la IA al dia
- ONNX Runtime 1.20.0 -> 1.27.0. La 1.20 no estaba preparada para los celulares nuevos con
  memoria de "paginas de 16 KB", que Google Play exige. La app usa las mismas funciones de
  siempre, asi que Recortar con IA y Mejorar imagen deben funcionar igual (probarlas).

## 17. Version para Google Play (AAB) con llave secreta
- GitHub ahora puede compilar, ademas del APK de prueba, la version para Play (.aab) firmada con
  la LLAVE DE SUBIDA. La llave no va en el ZIP: va en los "secretos" de GitHub
  (PZ_UPLOAD_KEYSTORE_B64 y PZ_UPLOAD_PASSWORD).
- Sin esos secretos todo sigue igual que antes (solo el APK de prueba, con la firma de prueba de
  siempre: se instala encima sin perder obras).
- El flujo de GitHub cambio: hay que reemplazar el archivo .github/workflows/build.yml del
  repositorio por el nuevo (va dentro del ZIP).

## 18. Nombre interno
- Se mantiene "com.pacco.animecut" (asi no hay que desinstalar). Se puede cambiar antes de
  publicar; despues de publicar ya no.

## 19. Politica de privacidad
- Dentro de la app: Acerca de > "Leer la politica de privacidad completa" (sin internet).
- Pagina web lista para publicar (index.html) y tener el enlace que pide Play.
- Dice la verdad de la app: no recoge datos, no hay cuentas ni anuncios, las imagenes no salen
  del telefono, internet solo para bajar el modelo de la IA, registro de errores solo local.
- Contacto: el correo que aparece en la ficha de Google Play.
