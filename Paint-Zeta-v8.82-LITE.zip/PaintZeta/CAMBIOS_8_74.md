# Paint Zeta v8.74 — La obra no se recarga, giro, aviso de guardado y abrir sin congelar

Puntos 12 al 15 del analisis de la 8.72. Incluye todo lo de la 8.73.

## 12. La obra ya no se recarga sola
- Antes: activar el modo oscuro, partir la pantalla, abrir un plegable, conectar un teclado o
  un lapiz, o cambiar el tamano de letra hacia que la pantalla se volviera a crear: la obra se
  recargaba y se perdia el Deshacer. Ahora la obra sigue tal cual.
- Si Android cierra la app por falta de memoria (pasa mucho al elegir una imagen en celulares
  con poca memoria), al volver se abre LA MISMA obra. Antes pedia elegir otra imagen.
- Si estabas eligiendo una imagen para agregar como capa en ese momento, se agrega apenas la
  obra termina de abrir. Antes se perdia.

## 13. Girar el celular
- Si la imagen estaba encuadrada, se vuelve a encuadrar en la nueva forma de la pantalla.
- Si tenias zoom, se mantiene el zoom y lo que mirabas queda en el centro.
- Las barras de arriba y abajo se vuelven a medir.

## 14. Aviso si el guardado falla
- Antes el guardado automatico podia fallar en silencio (por ejemplo, telefono sin espacio).
- Ahora, si falla dos veces seguidas, sale un aviso con "Guardar copia". La app lo sigue
  intentando sola cada 30 segundos y avisa cuando se vuelve a guardar bien.

## 15. Abrir imagenes sin congelar y derechas
- Abrir una imagen (y agregar una imagen como capa) se hace en segundo plano con el aviso
  "Abriendo imagen...". Antes la pantalla se congelaba y en telefonos lentos podia salir
  "la app no responde".
- Las fotos de camara entran derechas (se respeta su orientacion). Antes podian entrar
  acostadas o de cabeza. Probado en PC: las 8 orientaciones dan lo mismo que la referencia.

## Lo que NO cambia
- Herramientas, pincel, IA y formato de las obras siguen igual.
