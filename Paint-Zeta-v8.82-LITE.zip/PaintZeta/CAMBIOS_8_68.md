# Paint Zeta v8.68

## 1. Sombras gris oscuro del dibujo (lazo, pliegues del saco)
- **Causa**: la app las tomaba como LÍNEAS negras: no se pintaban (quedaban grises), al tocarlas
  decía que era línea, y en el Acabado salían como manchones del color de línea.
- **Ahora**: una mancha gris oscuro GRUESA (no fina como una línea, y no negra como una pupila)
  es sombra del dibujo: se pinta con la parte y queda como su sombra (más oscura). Las líneas
  que pasan por encima siguen siendo líneas (el lazo y la corbata no se juntan).
- Va en el relleno, en el color del paso 1 y en el Acabado.

## 2. "Tinta B/N" ya no se bloquea sola
- Antes, al entrar a Colorear la tinta quedaba con "Bloqueo total". Ahora no.
- Al pintar la primera parte, la capa de trabajo pasa a ser "Color zonas": el pincel ya no cae
  en la tinta. Las líneas se guardan con una huella del dibujo: no se recalculan en cada toque.

## 3. Acabado: el sol ya no salta al hacer zoom
- El toque se manda recién cuando el dedo se mueve o se levanta. Si pones el 2do dedo (zoom),
  no pasa nada; y si ya habías movido el sol, vuelve a donde estaba.

## 4. Marioneta sin topes
- "Evitar pliegues" viene APAGADO: el punto sigue al dedo hasta donde quieras, también fuera del
  lienzo, suave. Los triángulos doblados se ven en rojo en la malla. (Se puede prender en las
  opciones de Marioneta.)

## 5. Ya no pregunta "Borrar fondo del dibujo pintado"
- Al elegir Quitar fondo se trabaja directo en la capa que elegiste.

Incluye todo lo de 8.63 a 8.67.
