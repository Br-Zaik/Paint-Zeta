# Paint Zeta v8.79 — Figuras (parte 2 de 5 del encargo)

Incluye todo lo de la 8.73 a la 8.78.

## Boton nuevo arriba
- Icono de figuras (cuadrado, circulo, triangulo) al lado del estabilizador. Se pone VERDE
  mientras usas Figuras, Curva o Polilinea.
- Tocar = abre la lista. Mantener = dice que es. Atras cierra la lista.
- Lista: Libre (vuelve a la Brocha), Linea, Rectangulo, Circulo, Elipse, Poligono,
  Rect. redondeado, Flecha, Bocadillo, Curva y Polilinea (las dos ultimas son las de siempre).
- Figuras tambien esta en la caja de herramientas (PINTAR Y RETOCAR), con su ficha de ayuda.
- Los botones de arriba quedaron un poco mas chicos (42) para que entren los 7; en pantallas
  angostas se achican solos un poco mas.

## Como se usa
- Arrastra en la imagen: la figura se crea de punta a punta. Un toque en vacio pone una figura
  de tamano comodo en ese lugar.
- Antes de pintarla (borrador):
  - Puntos azules de las esquinas: agrandar (la esquina de enfrente queda quieta).
  - Puntos azules chicos de los lados: solo ancho o solo alto.
  - Punto verde de arriba: girar. Se engancha derecho cada 45 grados.
  - Arrastrar adentro: mover.
  - Bocadillo: punto naranja = la cola.
  - Linea y flecha: sus dos extremos; se enganchan horizontal, vertical y 45 grados.
- Check: se pinta en la capa elegida. Tocar afuera o empezar otra figura tambien la pinta.
- X o Deshacer: quita la figura sin pintar. Despues de pintada, Deshacer la quita en un paso.
- Dos dedos (zoom) en medio de un gesto: todo queda como estaba.
- Cambiar de figura en la lista con una figura puesta: cambia de tipo en el mismo lugar.
- Cambiar de herramienta o Atras con una figura puesta: se pinta (Deshacer la quita).

## Ajustes de figura (boton de ajustes de la barra de abajo)
- Contorno: si/no, color propio o "Color actual", opacidad, "Con el pincel actual"
  (el borde usa la textura y dureza del pincel). El grosor es la barra de tamano de abajo.
- Relleno: si/no, color propio o "Color actual", opacidad. Contorno y relleno con colores y
  opacidades separados.
- Rectangulo: Cuadrado (1:1). Poligono: lados 3 a 32. Redondeado: esquinas en %.
- Flecha: gruesa (se puede rellenar) o fina; puntas al final, al inicio o las dos; ancho.
- Bordes suaves (sin dientes) o en pixel duro.
- Todo se guarda solo.

## Detalles
- La figura vive en coordenadas de la imagen: el zoom o girar la vista no la deforman.
- Respeta la seleccion azul (solo pinta dentro) y "Bloquear transparencia" de la capa.
- No toca Especial, Malla, Marioneta ni los otros pinceles.

## Pruebas en PC (la forma de las figuras, no en telefono)
- 16 pruebas de la forma: crear, agrandar girado (la esquina de enfrente no se mueve), lados,
  circulo siempre redondo, giro que se engancha, elipse grande lisa (error menor a 0,6 px),
  bocadillo sin cola cuando la punta queda adentro, flecha corta de dos puntas, mover, cambiar
  de tipo. Todas OK.
- Imagenes: prueba_8_79_figuras_antes_despues.png y prueba_8_79_lista_y_puntos.png
  (la lista es una maqueta en PC con los iconos reales).

## Limites
- Sin texto dentro del bocadillo (eso seria otra herramienta).
- No se puede volver a editar una figura despues de pintarla (se deshace y se hace otra).
