# Paint Zeta v8.73 — Guardado seguro, Atras ordenado, exportar reducido y licencias

Primeros arreglos para la Play Store (puntos 6 al 11 del analisis de la 8.72).

## 6. Ya no se pierde trabajo al salir con una imagen en movimiento
- Antes: si agregabas una imagen (o usabas Transformar) y salias sin tocar "Listo", no se
  guardaba nada de lo ultimo.
- Ahora: al salir de la app (Inicio, Atras, una llamada) la transformacion se aplica sola,
  igual que tocar "Listo", y la obra se guarda enseguida. Deshacer la quita si no la querias.
- Si la app esta en segundo plano, el guardado ya no espera 5 segundos.

## 7. Boton Atras ordenado
- Primero cierra lo que este abierto: la barra de la imagen, Herramientas, Capas, Luz,
  Toques, Colorear, los menus flotantes.
- Con Transformar abierto, Atras lo aplica (como "Listo").
- Para salir de la obra hay que tocar Atras DOS veces seguidas: un roce del borde de la
  pantalla mientras pintas ya no cierra la obra.
- Sale cuando la obra ya quedo guardada (la galeria muestra lo ultimo). Si no se pudo guardar
  (por ejemplo, telefono sin espacio), pregunta antes de salir.

## 8. Exportar en tamano reducido funciona
- "Mitad", "Lado largo 1920" y "1280" fallaban: la imagen se dibujaba de una forma que
  Android no permite. Ahora la app la reduce con su propio codigo: cada pixel es el promedio
  del area que cubre (las lineas finas no se cortan) y el borde transparente queda limpio,
  sin manchas negras.
- Si exportar falla, ya no queda un archivo vacio o roto en Imagenes / Descargas.
- Los errores se explican mejor (antes podia salir "Error: null").
- Prueba en PC: 2400x3200 -> 1200x1600 en 0,06 s, borde sin manchas.

## 9. Acerca de y licencias (como en WhatsApp)
- Nuevo boton (i) en la galeria y "Acerca de" en Mas opciones > Ayuda y ajustes.
  El boton "Licencias" de la descarga de la IA abre la misma pantalla.
- Muestra version, privacidad (la app no recoge datos) y la lista de piezas de otros autores:
  ONNX Runtime (MIT), ISNet-Anime (Apache 2.0), Real-ESRGAN (BSD-3), AndroidX (Apache 2.0),
  Kotlin y JetBrains Annotations (Apache 2.0). Al tocar una se abre su licencia completa.
- El texto se acomoda al ancho de la pantalla (antes salia cortado a la mitad).
- Al compilar se agregan los avisos de terceros de ONNX Runtime. Si no se pueden bajar,
  la app muestra el enlace a ese archivo.

## 10. Se quito "Copiar zona"
- No estaba en el menu, pero su codigo seguia dentro. Su metodo tiene patentes, asi que se
  borro por completo.

## 11. Sin nombres de otras apps
- Se cambiaron los textos que nombraban otras apps (goma, Marioneta, Sacar lineas,
  Difuminar, modos de mezcla y exportar). Ahora describen lo que hace cada herramienta.

## Lo que NO cambia
- Las herramientas, el pincel, la IA y el formato de las obras siguen igual.
- Las obras guardadas se abren igual.
