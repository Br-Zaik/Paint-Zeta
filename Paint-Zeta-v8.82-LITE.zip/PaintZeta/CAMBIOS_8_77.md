# Paint Zeta v8.77 — Arreglos pequenos

Incluye todo lo de la 8.73 a la 8.76.

- Borrador del lapiz: en los lapices que tienen un extremo de goma, al voltearlo y pintar se
  BORRA aunque la herramienta elegida sea Pintar (y en Seleccion quita lo azul). Al voltearlo
  otra vez vuelve a pintar. No hay que cambiar de herramienta.
- Ventanas de la IA: si sales de la obra mientras la IA trabaja o se baja el modelo, al terminar
  ya no intenta abrir una ventana en una pantalla cerrada (eso podia cerrar la app).
- Texto de inicio corregido: ya no dice "se carga a su resolucion original" (en celulares con poca
  memoria la imagen se achica). Ahora dice que se abre con la mayor calidad que permite la memoria.
