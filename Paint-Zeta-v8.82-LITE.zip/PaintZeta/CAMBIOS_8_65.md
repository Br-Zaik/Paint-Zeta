# Paint Zeta v8.65 (junta 8.63 + 8.64 + 8.65)

- 8.63: acabado anime / manhwa completo (puntos 1 a 8)
- 8.64: varias luces (punto 9)
- 8.65: el relleno del paso 1 ya no se escapa en dibujos en grises (punto 10)

# Detalle

Todo dentro del paso **2 Acabado** de Colorear. No se tocó la IA (Recortar con IA, Mejorar imagen)
ni las otras herramientas. Las obras viejas se abren igual (lo nuevo queda apagado).

## 1. La sombra se pega a los pliegues de la ropa
- **Causa**: la sombra seguía solo el volumen y cruzaba las líneas de pliegue sin respetarlas.
- **Ahora**: en la ropa, el borde de la sombra se acerca a la línea de pliegue más cercana, suave,
  sin escalones. No se aplica en piel, pelo, ojos ni piezas chicas (lazo, cuello de camisa).
- Se calcula en la grilla chica: casi no cuesta. Mientras arrastras el sol no se calcula (llega al soltar).

## 2. Sombra del mentón cuando cara y cuello son una sola parte
- **Causa**: si pintabas cara y cuello de un solo toque, no salía la sombra que el mentón echa en el cuello.
- **Ahora**: se detecta el cuello (la parte angosta de abajo) y la línea del mentón dibujada; debajo
  va la sombra. Con luz de abajo no se pone.

## 3. Estilo: Manhwa / Anime
- **Manhwa** (como antes): sombras suaves con degradado y luz suave.
- **Anime**: dos tonos limpios (sombra de borde nítido), contraluz más fuerte, brillo del pelo más nítido.

## 4. Brillo de anime en los ojos
- Uno grande del lado de la luz y uno chico. **Si el dibujo ya trae brillo en el ojo, no se agrega otro.**

## 5. Puntas del pelo de otro color
- Botón **Puntas**: las puntas toman el color del pincel, en degradado (las sombras siguen al color).

## 6. Brillante (metal, cuero, seda)
- Herramienta **Brillante**: tocas una parte y gana un brillo nítido que se mueve con el sol.
  Tocar otra vez lo quita. ↶ lo deshace.

## 7. Contraluz con halo
- El borde de luz ahora "sangra" un poco hacia adentro de la silueta (más con sol de costado).

## 8. Estampados propios
- Herramienta **Estampado**: Cuadros, Rombos, Rayas, Lunares, Olas (y Quitar). Usa el color del pincel.
- El estampado se sombrea con la ropa (no queda plano). Dibujos genéricos, propios de la app.

## 9. Varias luces (hasta 3: sol + 2 más)
- **Causa**: solo había un sol.
- **Ahora**: botón **+ Luz** agrega otra luz (luna, otro sol, lámpara...). Cada luz se arrastra
  sola (se agarra la más cercana al dedo; la elegida tiene anillo blanco) y tiene su tipo
  (Día, Tarde, Atardecer, Luna llena, Media luna, Interior). **− Luz** quita la elegida.
- El sol principal hace la sombra; las luces extra aclaran la sombra del lado que miran, con su
  color, y ponen su propio borde de luz. Ej: sol que sale arriba y luna abajo en lo oscuro.
- Se guarda en la obra.

## 10. Paso 1 Color: el relleno ya no se escapa (dibujos en grises)
- **Causa**: en dibujos de grises las líneas se buscaban con una ventana fija de 7 píxeles. En
  imágenes grandes la línea es más gruesa que eso, no se veía y el color se escapaba: tocar el
  cuello pintaba la camisa; tocar la cara pintaba pelo y fondo. Además, cara clara y pelo gris
  muchas veces no tienen una línea negra completa entre ellos.
- **Ahora**: las líneas se buscan siempre a un tamaño fijo (no depende de lo grande de la foto) y
  un salto fuerte de tono (cara clara / pelo gris, pelo / fondo) también corta. Los brillos del pelo
  no cortan. Solo en dibujos de grises o a color; los de líneas limpias quedan igual.
- Prueba: misma imagen al doble de tamaño: antes la cara pintaba ~4 veces más (pelo y fondo);
  ahora solo la cara. Al triple: antes el cuello pintaba TODA la imagen; ahora solo el cuello.

## Optimización
- Paletas mezcladas preparadas una vez por pintada (nada se crea por píxel).
- Se quitó un arreglo que se creaba por cada píxel del borde de luz (menos basura en celulares bajos).
- Tiempos en PC (1100x1500): final 113 → ~120 ms; borrador igual (~40 ms).

## Cómo probarlo
1. Colorea un personaje (paso 1) y entra a **2 Acabado**.
2. Toca **Anime** y luego **Manhwa**: mira cómo cambian las sombras.
3. Mira la ropa con pliegues: la sombra termina en las líneas.
4. Toca **Brillante** y toca el lazo o un cinturón; mueve el sol.
5. Elige un color en el pincel, toca **Estampado**, elige **Cuadros** y toca la falda o la camisa.
6. Toca **Puntas** (con otro color en el pincel).
7. Toca **+ Luz**, elige **Luna llena** y arrástrala abajo; luego toca el sol y muévelo.
8. En el paso 1, con un dibujo en grises: toca el cuello, la cara y el pelo (cada uno queda en su parte).
9. Acepta ✓, cierra y vuelve a abrir la obra: todo queda guardado.
