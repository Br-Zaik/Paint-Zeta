# Paint Zeta v8.82 — Bisel, extrusion, destellos, giro, mosaico y grupos de filtros (parte 5 de 5)

Incluye todo lo de la 8.73 a la 8.81. Con esta version el encargo unificado queda completo:
estabilizador y puntas (8.78), figuras (8.79), rayos de luz y Dar luz (8.80), contorno,
resplandor de silueta y lineas de manga (8.81), y esta parte.

## Grupos en Filtros
- Arriba de la fila de miniaturas: Todos, Manga, Luz, Estilo, Desenfoque, Ajustes.
- Recuerda el ultimo grupo. Las miniaturas se hacen solo para el grupo que se ve (abre mas
  rapido); las de otro grupo se hacen al tocarlo.
- Manga: Extraer lineas, Pictorizar (3), Lineas radiales, Lineas de velocidad.
- Luz: Rayos de luz, Resplandor de silueta, Destellos en cruz, Resplandor.
- Estilo: Contorno, Bisel, Extrusion, Sombra, Inflar, Mosaico, Posterizar, Vintage,
  Aberracion, Ruido.
- Desenfoque: Gaussiano, Movimiento, Radial, Giro, Lente.
- Ajustes: Nitidez, Quitar ruido, Niveles.

## 5 filtros nuevos
### Bisel (capa nueva encima)
- Interior o Exterior. Ancho, profundidad, "Luz desde" (angulo) y suavidad.
- Luz de un lado y sombra del otro siguiendo el borde, tambien en huecos (la A, un aro).
- Distinto de Inflar: Inflar da volumen a toda la forma; el bisel solo trabaja el borde y deja
  la cara plana.
- Profundidad 0 = no crea nada.

### Extrusion (capa nueva DEBAJO)
- Largo, angulo, color, opacidad y sombreado (lo lejano mas oscuro).
- Volumen paralelo: la forma original queda delante y los huecos siguen el recorrido.
- Largo 0 = nada (ni desplazamiento ni sombra).
- (La extrusion con perspectiva no esta: era opcional en el encargo.)

### Destellos en cruz (capa nueva encima, modo Anadir)
- Umbral, intensidad, largo; en Mas ajustes: angulo, brazos (2 a 8), cantidad maxima y
  separacion minima. Color.
- Busca puntos de luz CHICOS y claros: el papel blanco o una zona clara grande no se llena de
  estrellas. Una estrella por punto (no una por pixel), siempre las mismas.
- Con seleccion, solo los puntos de lo seleccionado.

### Desenfoque de giro (cambia la capa, como los otros desenfoques)
- Centro (tocar o arrastrar) y angulo. Gira alrededor del centro (el Radial va hacia el centro).
- Respeta la transparencia (sin borde negro). Angulo 0 = exactamente igual.
- Se calcula por anillos: el angulo grande no lo hace mas lento.

### Mosaico (cambia la capa)
- Tamano del cuadro. Cuadros siempre alineados a la esquina de la imagen.
- Con seleccion, solo esa zona. Promedio correcto con transparencia (sin oscurecer).
- Tamano 1 = exactamente igual.

## Pruebas en PC (motores, no el telefono)
- 19 pruebas OK: los cinco con valor 0 no cambian nada; bisel sigue el agujero del aro y tiene
  luz y sombra; extrusion solo en su recorrido; por franjas = entero (bisel, extrusion,
  mosaico, destellos); mosaico con transparencia no oscurece; destellos: 0 en el papel blanco
  y 6 en 6 puntos, cantidad y separacion respetadas, siempre iguales; giro sin halo negro;
  vista previa parecida al final.
- Tiempos en PC con 1700 x 1700: giro 0,9 s; extrusion 0,13 s; bisel 0,12 s; destellos 0,07 s;
  mosaico 0,01 s. El giro es el mas lento (usa toda la imagen).
- Imagenes: prueba_8_82_bisel_extrusion.png y prueba_8_82_destellos_giro_mosaico.png.

## Limites
- La pantalla de Filtros (grupos, botones) no se pudo probar en PC (necesita Android).
