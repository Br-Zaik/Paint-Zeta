# Paint Zeta v8.67: colorear con fondo quitado / dibujo a color, y Marioneta

## 1. El color se pasaba (cara → pelo, cuello → camisa, pelo → cara)
- **Causa**: tu dibujo de "Tinta" es A COLOR (la app lo muestra en gris para pintar) y con el
  fondo quitado. En dibujos a color la app solo veía las líneas NEGRAS; las líneas de color
  (azul oscuro en el pelo azul, marrón en la piel) no contaban y el color se pasaba por ahí.
  Mis pruebas de antes eran con la imagen en gris: por eso salían bien y en tu APK no.
- **Ahora**: en dibujos a color también se buscan las líneas que son más oscuras que su
  alrededor, y un cambio de COLOR (piel / pelo azul) corta aunque el brillo sea parecido.
- Prueba con fondo quitado y a color, al doble de tamaño:
  - cara: antes 293 mil px (cara + pelo) → ahora 64 mil (solo cara)
  - cuello: antes 36 mil (se pasaba a la camisa) → ahora 24,6 mil (solo cuello)
  - pelo: antes 293 mil (pelo + cara) → ahora 204 mil (solo pelo)

## 2. Marioneta: con un dedo se trababa
- **Causa**: con UN solo punto, el resto del dibujo quedaba sujeto; al arrastrar, la malla se
  estiraba y el control de pliegues frenaba el punto ("Tope"): parecía congelado.
  Además, un solo triangulito doblado en el borde frenaba todo.
- **Ahora**: con un solo punto se mueve TODO el dibujo (como Photoshop). Para doblar un brazo,
  pon un punto fijo (azul) en el cuerpo. Unos pocos triangulitos del borde ya no frenan.
- Prueba (PC): 1 punto: antes se frenaba en el paso 8 de 30 y tardaba 4,4 ms por movimiento;
  ahora llega al final y tarda 0,2 ms. 3 puntos: antes 19 de 30 frenados; ahora 0, y ~1 ms.

Incluye todo lo de 8.63 a 8.66.
