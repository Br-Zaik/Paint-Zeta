# Paint Zeta v8.69

## 1. Mis obras: miniatura cortada a la mitad
- **Causa**: la miniatura se escribia encima de la vieja; si la galeria la leia justo en ese
  momento (o la app se cerraba), quedaba media imagen.
- **Ahora**: se guarda aparte y se cambia de golpe cuando esta completa.

## 2. Colorear: las sombras suaves del dibujo se respetan
- **Causa**: los grises muy claros (degradados, brillos) se tomaban como "nada" y quedaban lisos;
  solo las sombras fuertes pasaban.
- **Ahora**: funciona como el Multiplicar de verdad: cada gris oscurece el color en la misma
  medida. Brillos y degradados suaves se ven igual que en tu dibujo.
- Tocar una parte que ya tiene ESE color, o blanco sobre papel blanco: avisa
  "ya tiene ese color" y no crea otra zona.

## 3. 2 Toques: "Fundir" ya no congela
- El boton de la gota ahora dice **Fundir** (funde todos los toques de la capa).
- Se calcula por detras con el aviso "Fundiendo…". Si pintas mientras tanto, tus trazos se respetan.

## 4. Marioneta: calidad y papel
- Al aplicar, lo que se estira se calcula con bicubica (lineas mas nitidas, sin escalones).
- Mientras arrastras, la vista previa tiene mas detalle (0,30 -> 0,42).
- Nuevo **Solo el personaje** (prendido): en una hoja escaneada, el papel blanco que toca el
  borde no entra en la malla y se queda quieto; donde estaba el dibujo queda papel liso.
  Cancelar y Deshacer devuelven la hoja original exacta. Se apaga en Opciones de Marioneta.

## 5. Separar
- **Causa**: Separar usaba la forma vieja de ver las lineas y se escapaba por la linea del
  cuello que no esta cerrada (la cara y el cuello se llevaban la camisa).
- **Ahora**: usa las mismas paredes que Colorear (lineas grises o de color, saltos de tono).
  Con una sola parte, lo encerrado adentro (ojos, boca) tambien es de esa parte.
- **Tacho**: toca = borra solo los rayones del color elegido. Mantener = borra todos.

## 6. Animaciones de ayuda con Zeta Pintor
- El personaje de todas las animaciones es Zeta (zorrito pintor, cuerpo entero, por partes).
- Animaciones nuevas que hacen lo que dice la herramienta: Brocha (trazo real), Mover,
  Transformar (agranda y gira), Marioneta (pies fijos, sube el brazo), Separar (rayones ->
  capas), y las 5 de COLOREAR (mantener pulsado): 1 Colorear, 2 Toques, 3 Luz, 4 Estilo, Mejorar.

Incluye todo lo de 8.63 a 8.68. La IA no se toco.
