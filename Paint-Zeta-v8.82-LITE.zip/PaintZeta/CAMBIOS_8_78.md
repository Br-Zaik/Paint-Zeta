# Paint Zeta v8.78 — Estabilizador y puntas (parte 1 de 5 del encargo)

Incluye todo lo de la 8.73 a la 8.77.

## Boton nuevo arriba
- Icono de trazo suave al lado de Girar. Se pone VERDE cuando hay estabilizador o puntas.
- Tocar = abre el panel. Mantener = dice que es. Atras cierra el panel.
- Mas opciones > Estabilizador abre el mismo panel (ya no las 4 opciones viejas).

## Panel
- Estabilizador 0 a 10 (0 = apagado), con botones - y +.
- Metodo:
  - En vivo: corrige mientras dibujas.
  - Al soltar: mientras dibujas ves el trazo tal cual; al levantar el dedo se reemplaza UNA vez
    por el trazo suavizado completo (sin retraso, sin oscurecer, sin tocar otros trazos).
- Puntas finas (forzar): Inicio y Final en % del largo del trazo, forma Suave o Lineal.
  Si Inicio + Final pasan del 100 %, se reparten (nunca queda una parte de grosor cero).
  Los trazos cortos y los toques no desaparecen (la punta minima es mas gruesa).
- Muestra chica del trazo con los ajustes, Restablecer y Listo.
- Se guarda solo y se mantiene al cerrar y abrir la app.

## Como funciona (para la nota tecnica)
- El estabilizador toma un punto cada ~2 px de pantalla (no cada toque): la fuerza es la misma
  si el telefono da 60, 120 o 240 toques por segundo, y no cambia con el zoom.
- Al soltar: suavizado centrado con correccion de tamano: no se queda atras y los circulos casi
  no se encogen. El principio y el final tambien se alisan y la punta queda donde empezaste y
  donde soltaste.
- Las puntas forzadas reemplazan a las del pincel en ese trazo (no se aplican dos veces) y
  respetan el afinado por velocidad del pincel.
- Afecta a Pintar y Goma (las puntas solo a Pintar). No toca Balde, Gotero, Seleccion, Figuras,
  Especial, Malla ni Marioneta.

## Pruebas en PC (trazos de dedo tembloroso simulados, no en telefono)
- Temblor (quiebre medio, menos = mas liso): sin estabilizador 0,160; nivel 5 en vivo 0,098;
  nivel 10 en vivo 0,069; nivel 10 al soltar 0,062.
- Circulo de radio 110 px: nivel 10 en vivo 107,7 px; nivel 10 al soltar 109,6 px.
- Mismo trazo a 60 y a 240 toques por segundo: diferencia menor a 1 px en todos los niveles.

## Limites
- Ajuste "Este pincel / Todos": por ahora vale para todos los pinceles.
- En "Al soltar" las puntas aparecen al levantar el dedo (mientras dibujas se ve el grosor
  normal), como en el modo "mas tarde" de otras apps.
- No es igual al estabilizador de ibis Paint: es una version propia con su propia escala.
