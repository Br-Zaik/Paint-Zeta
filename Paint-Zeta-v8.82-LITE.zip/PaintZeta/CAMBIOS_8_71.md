# Paint Zeta v8.71 — Mezcla y opacidad (como Alight Motion)

- Menu nuevo "Mezcla y opacidad" (tocar el modo de la capa): grupos que se abren
  (Oscurecer, Aclarar, Contraste, Diferencia, Color, Enmascarar) con una MINIATURA por modo:
  Zeta con una luz de prueba mezclada con ese modo. Se ve que hace sin leer nombres.
  Al tocar, se ve al instante en el dibujo. Aceptar / Cancelar como antes.
- Las miniaturas se arman una sola vez y por detras (la pantalla no se traba).
- "Trama" ahora se llama "Pantalla" (el de las luces).
- Imagen como capa: si es una luz con fondo NEGRO, se pone sola en Pantalla.
- Enmascarar: Nada / Recorte (solo sobre la capa de abajo) / Excluir (NUEVO: todo menos la
  capa de abajo; la luz pasa por detras del personaje). Se guarda en la obra, se exporta
  igual y se deshace.
- Color de la luz: 8 colores (dorado, naranja, rojo, rosa, violeta, azul, celeste, verde).
  El centro de la luz sigue blanco. Por detras; Deshacer lo devuelve.
- Firma fija de 8.70 incluida: el APK sale firmado y se instala encima.
