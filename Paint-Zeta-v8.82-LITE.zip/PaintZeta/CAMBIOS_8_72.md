# Paint Zeta v8.72 — Imagenes como en Alight Motion

- La imagen agregada entra en modo NORMAL: la mezcla ya no cambia sola. Si parece una luz con
  fondo negro, solo sale un consejo ("elige Pantalla").
- Capas > Nueva: "Imagen encima" e "Imagen de fondo" (debajo de todo: un paisaje detras del
  personaje sin fondo).
- Al agregar una imagen queda elegida con sus cuadritos (Transformar) para moverla y agrandarla,
  y sale su BARRA PROPIA: Mover y transformar, Mezcla y opacidad, Al frente, Al fondo,
  Eliminar, Listo.
- Esa barra tambien sale para cualquier capa: tocar las rayitas > "Opciones de imagen".
- Incluye 8.71 (Mezcla y opacidad con miniaturas) y la firma fija de 8.70.
