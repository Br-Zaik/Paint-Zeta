# Paint Zeta v8.80 — Rayos de luz y "Dar luz" (parte 3 de 5 del encargo)

Incluye todo lo de la 8.73 a la 8.79.

## Rayos de luz (filtro nuevo)
- Esta en Filtros, en la fila de miniaturas (al lado de Resplandor).
- Lo dibujado en la capa da luz: un halo y haces que salen hacia afuera desde el punto de origen.
- La luz sale de la FORMA de lo dibujado: un circulo da un sol, unas letras dan haces con forma
  de letras, una ventana con el origen arriba da haces que bajan. No es un sol prefabricado.
- Controles:
  - Color (7 colores de luz y "Actual" = el color de la brocha).
  - Brillo 0 a 300 % (0 = nada de luz; pasado el 100 % la luz se aclara hacia blanco).
  - Fuerza 0 a 100 % (0 = sin haces, queda solo el halo).
  - Mas ajustes: Alcance (largo de los haces, en % del lado mayor), Halo, Umbral (para fotos).
  - Fuente: esta capa, o "la capa de abajo" (la capa visible justo debajo).
  - Origen: el punto con rayitos amarillos sobre la imagen. Al abrir queda en el centro de la
    figura; tocalo o arrastralo para moverlo. Puede quedar un poco fuera del lienzo (luz que
    entra de afuera). Ese punto solo se ve en esta pantalla, nunca en la obra.
- Resultado: una capa NUEVA "Rayos de luz" en modo Anadir, encima de la capa elegida (y de sus
  capas recortadas). Tu dibujo no cambia. La capa de luz se puede ocultar, mover, borrar a mano
  o bajar de opacidad. Un solo paso en Deshacer.
- La vista previa muestra el orden real de las capas (si hay capas opacas encima, tapan la luz
  igual que al aceptar).
- Si hay seleccion: solo lo seleccionado da luz.
- Si la capa es una foto o un dibujo opaco (sin transparencia), solo lo claro da luz (Umbral),
  para no encender toda la imagen.
- Capa vacia: avisa y no crea ninguna capa.

## Dar luz (atajo)
- En la barra de Figuras hay un boton de sol: pinta la figura (si falta) y abre el MISMO filtro
  Rayos de luz sobre esa capa.
- Para el flujo del video: capa nueva -> Figuras -> Circulo -> relleno amarillo sin contorno ->
  Dar luz -> mover el origen, Brillo y Fuerza -> Aceptar.

## Como funciona (para la nota tecnica)
- Aproximacion propia en 2D (no es el motor de otra app ni una simulacion 3D; no hay sombras
  fisicas de montanas o personajes).
- La fuente se lee en una copia de hasta 1024 px; los haces se calculan en una de hasta 512 px
  (son suaves) con coordenadas de toda la imagen: no hay franjas ni costuras. Despues se
  agranda al tamano real.
- Cada pixel mira hacia el origen y promedia la fuente en ese camino (hasta el Alcance), con
  menos peso lejos. Una variacion suave por angulo, siempre la misma, da textura a fuentes
  redondas; no cambia al mover barras.
- Brillo, fuerza y halo se calculan aparte: no se suma luz sobre luz al mover las barras.
- "Luz y ambiente" no se toco.

## Pruebas en PC (motor de la luz, no en telefono)
- 13 pruebas OK: origen al centro de la figura; hay luz; brillo 0 = sin luz; fuerza 0 conserva el halo;
  capa vacia = nada; los haces terminan en el alcance; vista previa y final casi iguales
  (diferencia media 0,16 de 255); mismo resultado cada vez; seleccion; foto opaca no enciende
  el cielo oscuro; sin costuras en 4096 x 4096 (filas 512, 1024, 2048).
- Tiempos en PC (no telefono): 900 x 1350 = 0,3 s; vista previa 0,3 s; vista rapida al
  arrastrar 0,08 s; 4096 x 4096 = 0,7 s. En un telefono modesto sera varias veces mas lento.
- Imagenes: prueba_8_80_rayos_antes_despues.png (circulo amarillo en capa nueva sobre un
  paisaje propio hecho por codigo) y prueba_8_80_rayos_otras_fuentes.png (texto, triangulo,
  bocadillo, linea, ventana con origen arriba y circulo con el origen movido).

## Limites
- Un circulo perfecto es simetrico: sus haces vienen de la variacion suave por angulo.
- No se pudo probar la pantalla de Filtros en PC (necesita Android): falta probarla en el telefono.
