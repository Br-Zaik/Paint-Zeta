package com.pacco.animecut.core;

import java.util.Arrays;

/**
 * v8.57: UN solo motor para todos los filtros de la pantalla "Filtros" (vista previa y
 * resultado final usan el mismo codigo). Java puro, sin Android: lo prueban las pruebas de PC.
 *
 *  - Los tamanos (radio, distancia...) se piden en pixeles de la imagen REAL. La vista previa
 *    pasa s = lado de la copia chica / lado real, y aqui se escalan: asi la copia chica y el
 *    resultado final se parecen.
 *  - Los desenfoques son O(n): tres pasadas de caja (no dependen del radio) o pasadas que se
 *    parten por la mitad (movimiento, radial, lente): log2(largo) pasadas.
 *  - A tamano real se trabaja por franjas con margen (la memoria no crece con la imagen).
 *  - Todo es cancelable: Job.cancelled() se mira cada pocas filas.
 *  - El ruido es determinista (depende de la posicion, no del azar): vista previa = exportado.
 *  - Colores sin premultiplicar en la entrada y en la salida; por dentro, los desenfoques
 *    trabajan premultiplicados para que lo transparente no deje bordes oscuros.
 */
public final class Fx {
    private Fx() { }

    public static final int EXTRACT = 0, PIC_LINES = 1, PIC_COLOR = 2, PIC_BOTH = 3, INFLATE = 4, SHADOW = 5,
            GLOW = 6, NOISE = 7, VINTAGE = 8, CHROMA = 9, GAUSS = 10, MOTION = 11, RADIAL = 12, LENS = 13,
            SHARPEN = 14, MEDIAN = 15, POSTER = 16, LEVELS = 17, RAYS = 18,
            OUTLINE = 19, SIL_GLOW = 20, FOCUS_LINES = 21, SPEED_LINES = 22,
            BEVEL = 23, EXTRUDE = 24, CROSS = 25, TWIRL = 26, MOSAIC = 27, COUNT = 28;

    public static final String[] NAMES = {
            "Extraer lineas", "Pictorizar lineas", "Pictorizar color", "Pictorizar color y lineas", "Inflar",
            "Sombra paralela", "Resplandor", "Ruido", "Pelicula vintage", "Aberracion cromatica",
            "Desenfoque gaussiano", "Desenfoque de movimiento", "Desenfoque radial", "Desenfoque de lente",
            "Nitidez", "Quitar ruido JPEG", "Posterizar", "Niveles", "Rayos de luz",
            "Contorno", "Resplandor de silueta", "Lineas radiales", "Lineas de velocidad",
            "Bisel", "Extrusion", "Destellos en cruz", "Desenfoque de giro", "Mosaico"};

    /** Nombre corto para la fila de miniaturas. */
    public static final String[] SHORT = {
            "Extraer\nlineas", "Pictorizar\nlineas", "Pictorizar\ncolor", "Color y\nlineas", "Inflar",
            "Sombra", "Resplandor", "Ruido", "Vintage", "Aberracion",
            "Gaussiano", "Movimiento", "Radial", "Lente", "Nitidez", "Quitar\nruido", "Posterizar", "Niveles",
            "Rayos\nde luz", "Contorno", "Aura", "Lineas\nradiales", "Lineas de\nvelocidad",
            "Bisel", "Extrusion", "Destellos", "Giro", "Mosaico"};

    public static final String[] HELP = {
            "El papel blanco se vuelve transparente y quedan solo las lineas, suaves.",
            "Convierte la imagen en un dibujo de trazos.",
            "Simplifica los colores como una ilustracion, sin borrar los bordes.",
            "Colores simplificados con lineas encima.",
            "Da volumen. Mueve el sol tocando la imagen.",
            "Sombra que sigue la forma del dibujo. Toca la imagen para moverla.",
            "Hace brillar las partes claras.",
            "Grano parejo, igual en la vista previa y al exportar.",
            "Tono de foto antigua: colores lavados, calidos y bordes oscuros.",
            "Separa un poco el rojo y el azul hacia los bordes.",
            "Desenfoque suave y parejo.",
            "Desenfoque en una direccion, como si se moviera rapido.",
            "Desenfoque que sale del centro (zoom). Toca para mover el centro.",
            "Desenfoque de camara: las luces se agrandan.",
            "Bordes mas definidos sin aumentar el ruido.",
            "Quita los puntitos y bloques del JPEG.",
            "Reduce la cantidad de tonos.",
            "Ajusta negro, blanco y medios.",
            "Lo dibujado en la capa da luz: halo y haces que salen del punto. Mejor si la figura esta en su propia capa.",
            "Borde alrededor del dibujo, siguiendo su forma (huecos y piezas sueltas). Necesita fondo transparente.",
            "Brillo que sale de la forma del dibujo (neon, aura). Tambien con figuras oscuras.",
            "Lineas de concentracion de manga hacia un centro. Toca para mover el centro.",
            "Lineas de movimiento paralelas, finas en las puntas.",
            "Relieve en el borde de la forma: luz de un lado y sombra del otro. Necesita fondo transparente.",
            "Volumen hacia un lado (texto o figura en 3D plano). La forma queda delante.",
            "Estrellas sobre los puntos de luz pequenos y claros (no sobre zonas blancas grandes).",
            "Gira la imagen alrededor de un centro. Toca para mover el centro.",
            "Pixelado en cuadros. Con seleccion, solo esa zona."};

    /** Orden en la fila de filtros. */
    public static final int[] ORDER = {
            // Manga
            EXTRACT, PIC_LINES, PIC_COLOR, PIC_BOTH, FOCUS_LINES, SPEED_LINES,
            // Luz
            RAYS, SIL_GLOW, CROSS, GLOW,
            // Estilo
            OUTLINE, BEVEL, EXTRUDE, SHADOW, INFLATE, MOSAIC, POSTER, VINTAGE, CHROMA, NOISE,
            // Desenfoque
            GAUSS, MOTION, RADIAL, TWIRL, LENS,
            // Ajustes
            SHARPEN, MEDIAN, LEVELS};

    /** v8.82: grupos de la fila de filtros (0 = todos). */
    public static final String[] CATS = {"Todos", "Manga", "Luz", "Estilo", "Desenfoque", "Ajustes"};

    public static int category(int id) {
        switch (id) {
            case EXTRACT: case PIC_LINES: case PIC_COLOR: case PIC_BOTH: case FOCUS_LINES: case SPEED_LINES: return 1;
            case RAYS: case SIL_GLOW: case CROSS: case GLOW: return 2;
            case GAUSS: case MOTION: case RADIAL: case TWIRL: case LENS: return 4;
            case SHARPEN: case MEDIAN: case LEVELS: return 5;
            default: return 3;
        }
    }

    // ------------------------------------------------------------------ controles

    public static final class Slider {
        public final String label, unit;
        public final int min, max, def;
        public final boolean advanced;

        Slider(String label, int min, int max, int def, String unit, boolean advanced) {
            this.label = label; this.min = min; this.max = max; this.def = def; this.unit = unit; this.advanced = advanced;
        }
    }

    public static final class Spec {
        public final Slider[] sliders;
        /** Casilla opcional (null = sin casilla). */
        public final String toggle;
        public final boolean toggleDef;
        /** Si se toca la imagen para elegir un punto: texto de ayuda (null = no). */
        public final String point;
        public final float pointX, pointY;
        /** v8.81: opciones de una sola eleccion (Exterior / Interior / Ambos...). null = no hay. */
        public String[] modes;
        public int modeDef;
        /** v8.81: muestra "Otra distribucion" (cambia la semilla de las lineas). */
        public boolean seed;

        Spec(Slider[] s, String toggle, boolean toggleDef, String point, float px, float py) {
            sliders = s; this.toggle = toggle; this.toggleDef = toggleDef; this.point = point; pointX = px; pointY = py;
        }

        Spec modes(int def, String... m) { modes = m; modeDef = def; return this; }

        Spec seeded() { seed = true; return this; }
    }

    private static Slider sl(String l, int mn, int mx, int d, String u) { return new Slider(l, mn, mx, d, u, false); }

    private static Slider adv(String l, int mn, int mx, int d, String u) { return new Slider(l, mn, mx, d, u, true); }

    public static Spec spec(int id) {
        switch (id) {
            case EXTRACT: return new Spec(new Slider[]{sl("Blanco", 100, 255, 228, ""), sl("Negro", 0, 200, 80, ""),
                    adv("Limpiar puntos", 0, 30, 0, "px")}, "Corregir papel amarillo y manchas", true, null, 0, 0);
            case PIC_LINES: return new Spec(new Slider[]{sl("Grosor", 1, 10, 2, ""), sl("Detalle", 0, 100, 55, ""),
                    adv("Limpiar puntos", 0, 30, 6, "px")}, "Papel blanco (no transparente)", false, null, 0, 0);
            case PIC_COLOR: return new Spec(new Slider[]{sl("Simplificar", 1, 10, 3, "px"), sl("Colores", 0, 16, 8, "")},
                    null, false, null, 0, 0);
            case PIC_BOTH: return new Spec(new Slider[]{sl("Simplificar", 1, 10, 3, "px"), sl("Grosor de linea", 1, 10, 2, ""),
                    adv("Detalle", 0, 100, 55, "")}, null, false, null, 0, 0);
            case INFLATE: return new Spec(new Slider[]{sl("Intensidad", 0, 100, 60, "%"), sl("Volumen", 1, 100, 40, ""),
                    adv("Brillo", 0, 100, 30, "%")}, null, false, "Toca o arrastra en la imagen para mover el sol", 0.25f, 0.2f);
            case SHADOW: return new Spec(new Slider[]{sl("Distancia", 0, 200, 20, "px"), sl("Desenfoque", 0, 100, 8, "px"),
                    sl("Opacidad", 0, 100, 60, "%")}, null, false, "Toca la imagen hacia donde cae la sombra", 0.75f, 0.8f);
            case GLOW: return new Spec(new Slider[]{sl("Intensidad", 0, 100, 50, "%"), sl("Radio", 1, 100, 20, "px"),
                    adv("Umbral", 0, 100, 55, "")}, "Brillar fuera del dibujo", false, null, 0, 0);
            case NOISE: return new Spec(new Slider[]{sl("Cantidad", 0, 100, 20, "")}, "Ruido de color", false, null, 0, 0);
            case VINTAGE: return new Spec(new Slider[]{sl("Intensidad", 0, 100, 70, "%"), sl("Vineta", 0, 100, 40, "%"),
                    adv("Grano", 0, 100, 15, "")}, null, false, null, 0, 0);
            case CHROMA: return new Spec(new Slider[]{sl("Desplazamiento", 0, 30, 6, "px")}, null, false,
                    "Toca la imagen para mover el centro", 0.5f, 0.5f);
            case GAUSS: return new Spec(new Slider[]{sl("Radio", 0, 100, 6, "px")}, null, false, null, 0, 0);
            case MOTION: return new Spec(new Slider[]{sl("Distancia", 1, 200, 30, "px"), sl("Angulo", 0, 180, 0, "°")},
                    null, false, null, 0, 0);
            case RADIAL: return new Spec(new Slider[]{sl("Intensidad", 0, 100, 25, "")}, null, false,
                    "Toca la imagen para mover el centro", 0.5f, 0.5f);
            case LENS: return new Spec(new Slider[]{sl("Radio", 1, 60, 10, "px"), adv("Brillo de luces", 0, 100, 50, "%")},
                    null, false, null, 0, 0);
            case SHARPEN: return new Spec(new Slider[]{sl("Cantidad", 0, 300, 100, "%"), sl("Radio", 1, 10, 2, "px"),
                    adv("Umbral", 0, 30, 4, "")}, null, false, null, 0, 0);
            case MEDIAN: return new Spec(new Slider[]{sl("Pasadas", 1, 3, 1, "")}, null, false, null, 0, 0);
            case POSTER: return new Spec(new Slider[]{sl("Tonos", 2, 32, 6, "")}, null, false, null, 0, 0);
            // v8.80: Brillo 0 = sin luz; Fuerza 0 = sin haces (queda el halo). Umbral solo para fotos opacas.
            case RAYS: return new Spec(new Slider[]{sl("Brillo", 0, 300, 100, "%"), sl("Fuerza", 0, 100, 70, "%"),
                    adv("Alcance", 5, 100, 45, "%"), adv("Halo", 0, 100, 40, ""), adv("Umbral (fotos)", 0, 100, 70, "")},
                    "Fuente: la capa de abajo", false, "Toca o arrastra para mover el origen de los rayos", 0.5f, 0.5f);
            // v8.81
            case OUTLINE: return new Spec(new Slider[]{sl("Grosor", 0, 100, 6, "px"), sl("Opacidad", 0, 100, 100, "%"),
                    adv("Suavidad", 0, 100, 0, "")}, null, false, null, 0, 0)
                    .modes(EdgeFx.OUTER, "Exterior", "Interior", "Ambos");
            case SIL_GLOW: return new Spec(new Slider[]{sl("Radio", 1, 100, 16, "px"), sl("Intensidad", 0, 200, 100, "%"),
                    adv("Suavidad", 0, 100, 50, "")}, "Como luz (modo Anadir)", false, null, 0, 0)
                    .modes(EdgeFx.OUTER, "Exterior", "Interior", "Ambos");
            case FOCUS_LINES: return new Spec(new Slider[]{sl("Cantidad", 20, 400, 140, ""), sl("Grosor", 1, 40, 6, "px"),
                    sl("Zona libre", 0, 90, 40, "%"), adv("Largo", 5, 100, 100, "%"), adv("Variacion", 0, 100, 50, ""),
                    adv("Opacidad", 0, 100, 100, "%")}, "Encima de la capa (si no, detras)", false,
                    "Toca o arrastra para mover el centro", 0.5f, 0.5f).seeded();
            case SPEED_LINES: return new Spec(new Slider[]{sl("Angulo", 0, 180, 0, "°"), sl("Cantidad", 10, 400, 90, ""),
                    sl("Grosor", 1, 40, 4, "px"), adv("Largo", 5, 100, 45, "%"), adv("Variacion", 0, 100, 60, ""),
                    adv("Opacidad", 0, 100, 100, "%")}, "Encima de la capa (si no, detras)", false, null, 0, 0).seeded();
            // v8.82
            case BEVEL: return new Spec(new Slider[]{sl("Ancho", 1, 60, 10, "px"), sl("Profundidad", 0, 100, 60, "%"),
                    sl("Luz desde", 0, 359, 315, "°"), adv("Suavidad", 0, 100, 30, "")}, null, false, null, 0, 0)
                    .modes(CraftFx.INNER, "Interior", "Exterior");
            case EXTRUDE: return new Spec(new Slider[]{sl("Largo", 0, 300, 30, "px"), sl("Angulo", 0, 359, 45, "°"),
                    sl("Opacidad", 0, 100, 100, "%"), adv("Sombreado", 0, 100, 50, "")}, null, false, null, 0, 0);
            case CROSS: return new Spec(new Slider[]{sl("Umbral", 0, 100, 70, ""), sl("Intensidad", 0, 200, 100, "%"),
                    sl("Largo", 5, 300, 50, "px"), adv("Angulo", 0, 90, 0, "°"), adv("Brazos", 2, 8, 4, ""),
                    adv("Cantidad max.", 1, 200, 30, ""), adv("Separacion", 5, 200, 30, "px")}, null, false, null, 0, 0);
            case TWIRL: return new Spec(new Slider[]{sl("Angulo", 0, 90, 15, "°")}, null, false,
                    "Toca o arrastra para mover el centro", 0.5f, 0.5f);
            case MOSAIC: return new Spec(new Slider[]{sl("Tamano", 1, 200, 12, "px")}, null, false, null, 0, 0);
            default: return new Spec(new Slider[]{sl("Negro", 0, 250, 25, ""), sl("Blanco", 5, 255, 230, ""),
                    sl("Medio", 10, 300, 100, "")}, null, false, null, 0, 0);
        }
    }

    /** Valores de un filtro. v[i] = barra i; opt = casilla; px,py = punto elegido (0..1). */
    public static final class P {
        /** v8.80: hasta 5 barras (antes 3); v8.81: 6; v8.82: 8. */
        public final int[] v = new int[8];
        public boolean opt;
        public float px = .5f, py = .5f;
        /** v8.80: color del efecto (luz, contorno, lineas). */
        public int color = RAYS_COLOR;
        /** v8.81: opcion elegida (Exterior/Interior/Ambos) y semilla de las lineas. */
        public int mode, seed;

        public P copy() {
            P c = new P();
            System.arraycopy(v, 0, c.v, 0, v.length);
            c.opt = opt; c.px = px; c.py = py; c.color = color; c.mode = mode; c.seed = seed;
            return c;
        }

        public boolean same(P o) {
            if (o == null || opt != o.opt || px != o.px || py != o.py || color != o.color
                    || mode != o.mode || seed != o.seed) return false;
            for (int i = 0; i < v.length; i++) if (v[i] != o.v[i]) return false;
            return true;
        }
    }

    /** Amarillo claro calido (como la luz del video de referencia). */
    public static final int RAYS_COLOR = 0xFFFFEBB0;

    /** v8.80: el resultado va en una capa NUEVA de efecto (no cambia la capa elegida). */
    public static boolean makesLayer(int id) {
        return id == RAYS || id == OUTLINE || id == SIL_GLOW || id == FOCUS_LINES || id == SPEED_LINES
                || id == BEVEL || id == EXTRUDE || id == CROSS;
    }

    /** Modo de la capa de efecto. */
    public static int layerMode(int id, P p) {
        if (id == RAYS || id == CROSS) return MODE_ADD;
        if (id == SIL_GLOW && p != null && p.opt) return MODE_ADD;
        return MODE_NORMAL;
    }

    /**
     * v8.81: la capa de efecto va DEBAJO de la capa elegida: contorno y resplandor exteriores
     * (el borde suave del dibujo cae encima sin rendija) y las lineas de manga (detras del personaje).
     */
    public static boolean effectBelow(int id, P p) {
        if (id == OUTLINE || id == SIL_GLOW) return p.mode == EdgeFx.OUTER;
        if (id == FOCUS_LINES || id == SPEED_LINES) return !p.opt;
        return id == EXTRUDE;
    }

    /** true: la seleccion limita la FUENTE (solo lo seleccionado da luz o contorno); false: el resultado. */
    public static boolean selLimitsSource(int id) { return id != FOCUS_LINES && id != SPEED_LINES; }

    /** Igual a Layer.MODE_ADD ("Anadir") y MODE_NORMAL; copiados para que Fx siga sin Android (pruebas de PC). */
    public static final int MODE_ADD = 3, MODE_NORMAL = 0;

    public static boolean usesColor(int id) { return makesLayer(id) && id != BEVEL; }

    /** Color inicial del efecto. */
    public static int defColor(int id) {
        switch (id) {
            case RAYS: return RAYS_COLOR;
            case SIL_GLOW: return 0xFF5FE3FF;
            case EXTRUDE: return 0xFF3A3A3A;
            case CROSS: return 0xFFFFFFFF;
            default: return 0xFF000000;
        }
    }

    public static P defaults(int id) {
        Spec s = spec(id);
        P p = new P();
        for (int i = 0; i < s.sliders.length; i++) p.v[i] = s.sliders[i].def;
        p.opt = s.toggleDef;
        if (s.point != null) { p.px = s.pointX; p.py = s.pointY; }
        p.color = defColor(id);
        if (s.modes != null) p.mode = s.modeDef;
        return p;
    }

    /** true si con estos valores el filtro no cambia nada (para no gastar tiempo). */
    public static boolean isIdentity(int id, P p) {
        switch (id) {
            case GAUSS: return p.v[0] <= 0;
            case NOISE: return p.v[0] <= 0;
            case CHROMA: return p.v[0] <= 0;
            case SHARPEN: return p.v[0] <= 0;
            case RADIAL: return p.v[0] <= 0;
            case INFLATE: return p.v[0] <= 0 && p.v[2] <= 0;
            case GLOW: return p.v[0] <= 0;
            case SHADOW: return p.v[2] <= 0;
            case VINTAGE: return p.v[0] <= 0 && p.v[1] <= 0 && p.v[2] <= 0;
            case OUTLINE: return p.v[0] <= 0 || p.v[1] <= 0;
            case SIL_GLOW: return p.v[1] <= 0;
            case FOCUS_LINES: case SPEED_LINES: return p.v[5] <= 0;
            case BEVEL: return p.v[1] <= 0;
            case EXTRUDE: return p.v[0] <= 0 || p.v[2] <= 0;
            case CROSS: return p.v[1] <= 0;
            case TWIRL: return p.v[0] <= 0;
            case MOSAIC: return p.v[0] <= 1;
            default: return false;
        }
    }

    // ------------------------------------------------------------------ trabajo

    public interface Job {
        boolean cancelled();

        void progress(int pct);
    }

    public static final class Cancelled extends RuntimeException {
        public Cancelled() { super("cancelado"); }
    }

    private static void chk(Job j) {
        if (j != null && j.cancelled()) throw new Cancelled();
    }

    /**
     * Guarda calculos caros para la vista previa (desenfoque de la sombra, volumen de Inflar,
     * papel de Extraer lineas): al mover solo la sombra o el sol no se recalculan.
     */
    public static final class Cache {
        private final String[] keys = new String[6];
        private final Object[] vals = new Object[6];
        private int next;

        synchronized Object get(String k) {
            for (int i = 0; i < keys.length; i++) if (k.equals(keys[i])) return vals[i];
            return null;
        }

        synchronized void put(String k, Object v) {
            for (int i = 0; i < keys.length; i++) if (k.equals(keys[i])) { vals[i] = v; return; }
            keys[next] = k; vals[next] = v;
            next = (next + 1) % keys.length;
        }

        public synchronized void clear() { Arrays.fill(keys, null); Arrays.fill(vals, null); }
    }

    /** Pixeles por franja a tamano real (memoria acotada). */
    private static long tileLimit(int id) {
        switch (id) {
            case PIC_COLOR: case PIC_BOTH: case LENS: case MOTION: return 700_000L;
            case RADIAL: case TWIRL: return Long.MAX_VALUE; // necesitan toda la imagen
            default: return 1_500_000L;
        }
    }

    /** Margen (filas) que necesita cada franja para que no se noten las uniones. */
    static int margin(int id, P p, float s) {
        switch (id) {
            case EXTRACT: return 8 + Math.round(p.v[2] * 2 * s);
            case PIC_LINES: return 4 + (int) Math.ceil(3 * 2.2f * xdogSigma(p.v[0]) * s) + Math.round(p.v[2] * 2 * s);
            case PIC_COLOR: return 10 + Math.round(p.v[0] * s) * 2;
            case PIC_BOTH: return 4 + Math.round(p.v[0] * s) * 2 + (int) Math.ceil(3 * 2.2f * xdogSigma(p.v[1]) * s);
            case SHADOW: return 3 + Math.round(p.v[0] * s) + (int) Math.ceil(3 * p.v[1] * .5f * s);
            case GLOW: return 3 + (int) Math.ceil(3 * p.v[1] * .5f * s);
            case CHROMA: return 3 + Math.round(p.v[0] * s);
            case GAUSS: return 3 + (int) Math.ceil(3 * p.v[0] * .5f * s);
            case MOTION: return 3 + Math.round(p.v[0] * s * .6f);
            case LENS: return 3 + Math.round(p.v[0] * s * .6f);
            case SHARPEN: return 3 + (int) Math.ceil(3 * p.v[1] * .5f * s);
            case MEDIAN: return 1 + p.v[0];
            case OUTLINE: return 4 + (int) Math.ceil(p.v[0] * s * (1f + p.v[2] / 100f * 1.5f));
            case SIL_GLOW: return 4 + (int) Math.ceil(3 * p.v[0] * .5f * s);
            case BEVEL: return 4 + (int) Math.ceil(p.v[0] * s * (1f + p.v[3] / 100f * 1.6f));
            case EXTRUDE: return 3 + (int) Math.ceil(p.v[0] * s);
            case MOSAIC: return 2 + (int) Math.ceil(p.v[0] * s);
            default: return 0;
        }
    }

    /**
     * Aplica el filtro. src no cambia. s = escala (1 = tamano real; copia chica &lt; 1).
     * cache puede ser null. @return pixeles nuevos (w*h). Lanza Cancelled si se cancela.
     */
    public static int[] apply(int id, int[] src, int w, int h, P p, float s, Job job, Cache cache) {
        // v8.80: Rayos de luz devuelve SOLO la luz (para una capa nueva), no la capa cambiada
        if (id == RAYS) return GodRays.render(src, w, h, null, p.v, p.color, p.px, p.py, w, h, job);
        // v8.81: los efectos de capa propia devuelven SOLO el efecto; "sin cambio" = capa vacia
        if (makesLayer(id) && isIdentity(id, p)) return new int[w * h];
        if (isIdentity(id, p)) return src.clone();
        Object ctx = prepare(id, src, w, h, p, s, job, cache);
        long lim = tileLimit(id);
        if ((long) w * h <= lim) {
            int[] r = run(id, src, w, h, 0, 0, w, h, p, s, ctx, job, cache, true);
            if (job != null) job.progress(100);
            return r;
        }
        int m = margin(id, p, s);
        int rows = (int) Math.max(32, lim / w - 2L * m);
        int[] out = new int[w * h];
        for (int y0 = 0; y0 < h; y0 += rows) {
            chk(job);
            int y1 = Math.min(h, y0 + rows), a0 = Math.max(0, y0 - m), a1 = Math.min(h, y1 + m);
            int[] tile = Arrays.copyOfRange(src, a0 * w, a1 * w);
            int[] r = run(id, tile, w, a1 - a0, 0, a0, w, h, p, s, ctx, job, null, false);
            System.arraycopy(r, (y0 - a0) * w, out, y0 * w, (y1 - y0) * w);
            if (job != null) job.progress((int) (100L * y1 / h));
        }
        return out;
    }

    /** "Lineas" (capas) usa este mismo motor: blanco/negro, corregir papel y limpiar puntos. */
    public static int[] extractLines(int[] src, int w, int h, int white, int black, boolean paper, int speck) {
        P p = new P();
        p.v[0] = Math.max(1, Math.min(255, white));
        p.v[1] = Math.max(0, Math.min(p.v[0] - 1, black));
        p.v[2] = speck;
        p.opt = paper;
        return apply(EXTRACT, src, w, h, p, 1f, null, null);
    }

    /** Calculo global previo (sobre toda la imagen, en chico). */
    private static Object prepare(int id, int[] src, int w, int h, P p, float s, Job job, Cache cache) {
        if (id == EXTRACT) {
            // v8.59: imagen a color -> solo lineas (lo oscuro y angosto); B/N -> papel a transparente
            if (isColored(src)) return Boolean.TRUE;
            if (!p.opt) return null;
            String k = "paper:" + w + "x" + h + ":" + System.identityHashCode(src);
            Object o = cache != null ? cache.get(k) : null;
            if (o == null) { o = paperMap(src, w, h, job); if (cache != null) cache.put(k, o); }
            return o;
        }
        if (id == CROSS) {
            // v8.82: las estrellas se buscan en toda la imagen (una sola vez por valores)
            String k = "cross:" + w + "x" + h + ":" + p.v[0] + ":" + p.v[5] + ":" + p.v[6] + ":" + s + ":"
                    + System.identityHashCode(src);
            Object o = cache != null ? cache.get(k) : null;
            if (o == null) { o = CraftFx.findStars(src, w, h, p, s); if (cache != null) cache.put(k, o); }
            return o;
        }
        if (id == INFLATE) {
            String k = "inflate:" + w + "x" + h + ":" + p.v[1] + ":" + System.identityHashCode(src);
            Object o = cache != null ? cache.get(k) : null;
            if (o == null) { o = normals(src, w, h, p.v[1], job); if (cache != null) cache.put(k, o); }
            return o;
        }
        return null;
    }

    private static int[] run(int id, int[] in, int w, int h, int ox, int oy, int fw, int fh, P p, float s,
                             Object ctx, Job job, Cache cache, boolean single) {
        switch (id) {
            case EXTRACT: return ctx == Boolean.TRUE ? extractColor(in, w, h, p, s, job)
                    : extract(in, w, h, ox, oy, fw, fh, p, s, (Paper) ctx, job);
            case PIC_LINES: return picLines(in, w, h, p, s, job);
            case PIC_COLOR: return withLines(in, picColor(in, w, h, p.v[0], p.v[1], s, job), w, h, s, job);
            case PIC_BOTH: return picBoth(in, w, h, p, s, job);
            case INFLATE: return inflate(in, w, h, ox, oy, fw, fh, p, (Normals) ctx, job);
            case SHADOW: return shadow(in, w, h, ox, oy, fw, fh, p, s, job, single ? cache : null);
            case GLOW: return glow(in, w, h, p, s, job);
            case OUTLINE: return EdgeFx.outline(in, w, h, p, s, job);
            case SIL_GLOW: return EdgeFx.silGlow(in, w, h, p, s, job);
            case FOCUS_LINES: return EdgeFx.focusLines(w, h, ox, oy, fw, fh, p, s);
            case SPEED_LINES: return EdgeFx.speedLines(w, h, ox, oy, fw, fh, p, s);
            case BEVEL: return CraftFx.bevel(in, w, h, p, s, job);
            case EXTRUDE: return CraftFx.extrude(in, w, h, p, s, job);
            case CROSS: return CraftFx.drawStars((CraftFx.Stars) ctx, w, h, ox, oy, p, s);
            case TWIRL: return CraftFx.twirl(in, w, h, p, job);
            case MOSAIC: return CraftFx.mosaic(in, w, h, oy, p, s);
            case NOISE: return noise(in, w, h, ox, oy, p.v[0], p.opt, s, 0x5EED);
            case VINTAGE: return vintage(in, w, h, ox, oy, fw, fh, p, s);
            case CHROMA: return chroma(in, w, h, ox, oy, fw, fh, p, s, job);
            case GAUSS: return gauss(in, w, h, p.v[0] * .5f * s, job);
            case MOTION: return motion(in, w, h, p.v[0] * s, p.v[1], job);
            case RADIAL: return radial(in, w, h, p, job);
            case LENS: return lens(in, w, h, p.v[0] * s, p.v[1], job);
            case SHARPEN: return sharpen(in, w, h, p.v[0], p.v[1] * .5f * s, p.v[2], job);
            case MEDIAN: {
                int[] o = in.clone();
                for (int i = 0; i < p.v[0]; i++) { chk(job); Filters.median3(o, w, h); }
                return o;
            }
            case POSTER: { int[] o = in.clone(); Filters.posterize(o, p.v[0]); return o; }
            default: {
                int[] o = in.clone();
                Filters.levels(o, p.v[0], Math.max(p.v[0] + 1, p.v[1]), 100f / Math.max(10, p.v[2]));
                return o;
            }
        }
    }

    // ------------------------------------------------------------------ ayudas

    static int lum(int c) { return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8; }

    static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    static int clampf(float v) { return v <= 0 ? 0 : v >= 255 ? 255 : (int) (v + .5f); }

    static float smooth(float e0, float e1, float x) {
        float t = (x - e0) / (e1 - e0);
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        return t * t * (3 - 2 * t);
    }

    /** Ruido determinista 0..1 por posicion. */
    static float hash(int x, int y, int seed) {
        int hh = x * 374761393 + y * 668265263 + seed * 1442695041;
        hh = (hh ^ (hh >>> 13)) * 1274126177;
        hh ^= hh >>> 16;
        return (hh & 0xFFFFFF) / 16777216f;
    }

    /** Anchos de las tres cajas que imitan una gaussiana de sigma (Kutskir / Wells). */
    static int[] boxes(float sigma, int n) {
        float wIdeal = (float) Math.sqrt(12 * sigma * sigma / n + 1);
        int wl = (int) Math.floor(wIdeal);
        if (wl % 2 == 0) wl--;
        int wu = wl + 2;
        float mIdeal = (12 * sigma * sigma - n * wl * wl - 4 * n * wl - 3 * n) / (-4f * wl - 4);
        int m = Math.round(mIdeal);
        int[] r = new int[n];
        for (int i = 0; i < n; i++) r[i] = ((i < m ? wl : wu) - 1) / 2;
        return r;
    }

    static void boxH(int[] s, int[] d, int w, int h, int r) {
        if (r <= 0) { System.arraycopy(s, 0, d, 0, w * h); return; }
        int div = 2 * r + 1, half = div / 2;
        for (int y = 0; y < h; y++) {
            int row = y * w, last = w - 1;
            int acc = 0;
            for (int k = -r; k <= r; k++) acc += s[row + (k < 0 ? 0 : k > last ? last : k)];
            for (int x = 0; x < w; x++) {
                d[row + x] = (acc + half) / div;
                int add = x + r + 1, sub = x - r;
                acc += s[row + (add > last ? last : add)] - s[row + (sub < 0 ? 0 : sub)];
            }
        }
    }

    static void boxV(int[] s, int[] d, int w, int h, int r) {
        if (r <= 0) { System.arraycopy(s, 0, d, 0, w * h); return; }
        int div = 2 * r + 1, half = div / 2, last = h - 1;
        int[] acc = new int[w];
        for (int k = -r; k <= r; k++) {
            int yy = k < 0 ? 0 : k > last ? last : k;
            for (int x = 0; x < w; x++) acc[x] += s[yy * w + x];
        }
        for (int y = 0; y < h; y++) {
            int add = y + r + 1, sub = y - r;
            int ra = (add > last ? last : add) * w, rs = (sub < 0 ? 0 : sub) * w, row = y * w;
            for (int x = 0; x < w; x++) {
                d[row + x] = (acc[x] + half) / div;
                acc[x] += s[ra + x] - s[rs + x];
            }
        }
    }

    /** Gaussiana aproximada (3 cajas) en un plano entero, en el lugar. */
    static void gaussPlane(int[] pl, int[] tmp, int w, int h, float sigma) {
        if (sigma < 0.35f) return;
        if (sigma < 2.5f) { exactI(pl, tmp, w, h, sigma); return; }
        for (int r : boxes(sigma, 3)) {
            boxH(pl, tmp, w, h, r);
            boxV(tmp, pl, w, h, r);
        }
    }

    /** Nucleo gaussiano exacto (radios chicos: las cajas redondean demasiado). */
    static float[] kernel(float sigma) {
        int r = Math.max(1, (int) Math.ceil(sigma * 3));
        float[] k = new float[2 * r + 1];
        float sum = 0;
        for (int i = -r; i <= r; i++) { k[i + r] = (float) Math.exp(-i * i / (2 * sigma * sigma)); sum += k[i + r]; }
        for (int i = 0; i < k.length; i++) k[i] /= sum;
        return k;
    }

    static void exactF(float[] pl, float[] tmp, int w, int h, float sigma) {
        float[] k = kernel(sigma);
        int r = k.length / 2;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                float a = 0;
                for (int j = -r; j <= r; j++) { int xx = x + j; xx = xx < 0 ? 0 : xx >= w ? w - 1 : xx; a += pl[row + xx] * k[j + r]; }
                tmp[row + x] = a;
            }
        }
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float a = 0;
                for (int j = -r; j <= r; j++) { int yy = y + j; yy = yy < 0 ? 0 : yy >= h ? h - 1 : yy; a += tmp[yy * w + x] * k[j + r]; }
                pl[y * w + x] = a;
            }
        }
    }

    static void exactI(int[] pl, int[] tmp, int w, int h, float sigma) {
        float[] k = kernel(sigma);
        int r = k.length / 2;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                float a = 0;
                for (int j = -r; j <= r; j++) { int xx = x + j; xx = xx < 0 ? 0 : xx >= w ? w - 1 : xx; a += pl[row + xx] * k[j + r]; }
                tmp[row + x] = Math.round(a);
            }
        }
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float a = 0;
                for (int j = -r; j <= r; j++) { int yy = y + j; yy = yy < 0 ? 0 : yy >= h ? h - 1 : yy; a += tmp[yy * w + x] * k[j + r]; }
                pl[y * w + x] = Math.round(a);
            }
        }
    }

    static void boxHf(float[] s, float[] d, int w, int h, int r) {
        if (r <= 0) { System.arraycopy(s, 0, d, 0, w * h); return; }
        float inv = 1f / (2 * r + 1);
        for (int y = 0; y < h; y++) {
            int row = y * w, last = w - 1;
            float acc = 0;
            for (int k = -r; k <= r; k++) acc += s[row + (k < 0 ? 0 : k > last ? last : k)];
            for (int x = 0; x < w; x++) {
                d[row + x] = acc * inv;
                int add = x + r + 1, sub = x - r;
                acc += s[row + (add > last ? last : add)] - s[row + (sub < 0 ? 0 : sub)];
            }
        }
    }

    static void boxVf(float[] s, float[] d, int w, int h, int r) {
        if (r <= 0) { System.arraycopy(s, 0, d, 0, w * h); return; }
        float inv = 1f / (2 * r + 1);
        int last = h - 1;
        float[] acc = new float[w];
        for (int k = -r; k <= r; k++) {
            int yy = k < 0 ? 0 : k > last ? last : k;
            for (int x = 0; x < w; x++) acc[x] += s[yy * w + x];
        }
        for (int y = 0; y < h; y++) {
            int add = y + r + 1, sub = y - r;
            int ra = (add > last ? last : add) * w, rs = (sub < 0 ? 0 : sub) * w, row = y * w;
            for (int x = 0; x < w; x++) {
                d[row + x] = acc[x] * inv;
                acc[x] += s[ra + x] - s[rs + x];
            }
        }
    }

    static void gaussPlaneF(float[] pl, float[] tmp, int w, int h, float sigma) {
        if (sigma < 0.35f) return;
        if (sigma < 2.5f) { exactF(pl, tmp, w, h, sigma); return; }
        for (int r : boxes(sigma, 3)) {
            boxHf(pl, tmp, w, h, r);
            boxVf(tmp, pl, w, h, r);
        }
    }

    /** Planos premultiplicados: A (0..255) y R,G,B (color*alfa, 0..65025). */
    static int[][] premulPlanes(int[] in) {
        int n = in.length;
        int[] a = new int[n], r = new int[n], g = new int[n], b = new int[n];
        for (int i = 0; i < n; i++) {
            int c = in[i], al = c >>> 24;
            a[i] = al;
            if (al == 0) continue;
            r[i] = ((c >> 16) & 255) * al;
            g[i] = ((c >> 8) & 255) * al;
            b[i] = (c & 255) * al;
        }
        return new int[][]{a, r, g, b};
    }

    static int[] fromPremul(int[][] pl) {
        int[] a = pl[0], r = pl[1], g = pl[2], b = pl[3];
        int n = a.length;
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int al = a[i];
            if (al <= 0) continue;
            int hal = al >> 1;
            out[i] = (Math.min(255, al) << 24) | (clamp((r[i] + hal) / al) << 16) | (clamp((g[i] + hal) / al) << 8)
                    | clamp((b[i] + hal) / al);
        }
        return out;
    }

    // ------------------------------------------------------------------ desenfoques

    public static int[] gauss(int[] in, int w, int h, float sigma, Job job) {
        if (sigma < 0.35f) return in.clone();
        int[][] pl = premulPlanes(in);
        int[] tmp = new int[in.length];
        for (int[] q : pl) { chk(job); gaussPlane(q, tmp, w, h, sigma); }
        return fromPremul(pl);
    }

    /** Planos float premultiplicados 0..1 (A, R, G, B). gamma &gt; 1 realza las luces (lente). */
    static float[][] floatPlanes(int[] in, float gamma) {
        int n = in.length;
        float[] a = new float[n], r = new float[n], g = new float[n], b = new float[n];
        float[] lut = new float[256];
        for (int i = 0; i < 256; i++) lut[i] = (float) Math.pow(i / 255f, gamma);
        for (int i = 0; i < n; i++) {
            int c = in[i], al = c >>> 24;
            if (al == 0) continue;
            float fa = al / 255f;
            a[i] = fa;
            r[i] = lut[(c >> 16) & 255] * fa;
            g[i] = lut[(c >> 8) & 255] * fa;
            b[i] = lut[c & 255] * fa;
        }
        return new float[][]{a, r, g, b};
    }

    static int[] fromFloat(float[][] pl, float gamma) {
        float[] a = pl[0], r = pl[1], g = pl[2], b = pl[3];
        int n = a.length;
        int[] out = new int[n];
        float ig = 1f / gamma;
        boolean lin = gamma == 1f;
        for (int i = 0; i < n; i++) {
            float al = a[i];
            if (al < 1f / 512) continue;
            float rr = r[i] / al, gg = g[i] / al, bb = b[i] / al;
            if (!lin) {
                rr = (float) Math.pow(Math.max(0, rr), ig);
                gg = (float) Math.pow(Math.max(0, gg), ig);
                bb = (float) Math.pow(Math.max(0, bb), ig);
            }
            out[i] = (clampf(al * 255) << 24) | (clampf(rr * 255) << 16) | (clampf(gg * 255) << 8) | clampf(bb * 255);
        }
        return out;
    }

    /**
     * Desenfoque en linea (largo L, direccion vx,vy unitaria) en log2(L) pasadas: en cada una el
     * pixel es el promedio de dos muestras a +-d/2 y d se parte por la mitad. Resulta una caja de
     * largo L (con interpolacion bilineal), sin importar lo largo que sea.
     */
    static void lineBlur(float[][] pl, int w, int h, float vx, float vy, float len, Job job) {
        int n = w * h;
        float[][] tmp = new float[pl.length][n];
        for (float d = len / 2f; d >= 0.6f; d /= 2f) {
            chk(job);
            float ox = vx * d / 2f, oy = vy * d / 2f;
            avgPass(pl, tmp, w, h, ox, oy, 0, 0, 0f);
            for (int c = 0; c < pl.length; c++) { float[] t = pl[c]; pl[c] = tmp[c]; tmp[c] = t; }
        }
    }

    /**
     * Una pasada: cada pixel = promedio de dos muestras bilineales en p - o y p + o, donde
     * o = (ox,oy) + k*(p - centro). Las posiciones y pesos se calculan una vez para los 4 planos.
     */
    static void avgPass(float[][] pl, float[][] out, int w, int h, float ox, float oy, float cx, float cy, float k) {
        int np = pl.length;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float dx = ox + k * (x - cx), dy = oy + k * (y - cy);
                float ax = x - dx, ay = y - dy, bx = x + dx, by = y + dy;
                if (ax < 0) ax = 0; else if (ax > w - 1) ax = w - 1;
                if (ay < 0) ay = 0; else if (ay > h - 1) ay = h - 1;
                if (bx < 0) bx = 0; else if (bx > w - 1) bx = w - 1;
                if (by < 0) by = 0; else if (by > h - 1) by = h - 1;
                int ax0 = (int) ax, ay0 = (int) ay, bx0 = (int) bx, by0 = (int) by;
                int ax1 = ax0 < w - 1 ? 1 : 0, ay1 = ay0 < h - 1 ? w : 0, bx1 = bx0 < w - 1 ? 1 : 0, by1 = by0 < h - 1 ? w : 0;
                float atx = ax - ax0, aty = ay - ay0, btx = bx - bx0, bty = by - by0;
                float a00 = (1 - atx) * (1 - aty) * .5f, a01 = atx * (1 - aty) * .5f, a10 = (1 - atx) * aty * .5f, a11 = atx * aty * .5f;
                float b00 = (1 - btx) * (1 - bty) * .5f, b01 = btx * (1 - bty) * .5f, b10 = (1 - btx) * bty * .5f, b11 = btx * bty * .5f;
                int ia = ay0 * w + ax0, ib = by0 * w + bx0, i = y * w + x;
                for (int c = 0; c < np; c++) {
                    float[] q = pl[c];
                    out[c][i] = q[ia] * a00 + q[ia + ax1] * a01 + q[ia + ay1] * a10 + q[ia + ay1 + ax1] * a11
                            + q[ib] * b00 + q[ib + bx1] * b01 + q[ib + by1] * b10 + q[ib + by1 + bx1] * b11;
                }
            }
        }
    }

    static float bil(float[] p, int w, int h, float x, float y) {
        if (x < 0) x = 0; else if (x > w - 1) x = w - 1;
        if (y < 0) y = 0; else if (y > h - 1) y = h - 1;
        int x0 = (int) x, y0 = (int) y;
        int x1 = x0 < w - 1 ? x0 + 1 : x0, y1 = y0 < h - 1 ? y0 + 1 : y0;
        float tx = x - x0, ty = y - y0;
        float a = p[y0 * w + x0], b = p[y0 * w + x1], c = p[y1 * w + x0], d = p[y1 * w + x1];
        return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
    }

    public static int[] motion(int[] in, int w, int h, float len, int angleDeg, Job job) {
        if (len < 1f) return in.clone();
        float[][] pl = floatPlanes(in, 1f);
        double an = Math.toRadians(angleDeg);
        lineBlur(pl, w, h, (float) Math.cos(an), (float) -Math.sin(an), len, job);
        return fromFloat(pl, 1f);
    }

    /** Lente: tres desenfoques en linea a 0, 60 y 120 grados = bokeh hexagonal; gamma agranda luces. */
    public static int[] lens(int[] in, int w, int h, float radius, int bright, Job job) {
        if (radius < 0.7f) return in.clone();
        float gamma = 1f + bright / 100f * 2.2f;
        float[][] pl = floatPlanes(in, gamma);
        float len = radius * 1.15f;
        for (int k = 0; k < 3; k++) {
            double an = Math.toRadians(90 + 60 * k);
            lineBlur(pl, w, h, (float) Math.cos(an), (float) Math.sin(an), len, job);
        }
        return fromFloat(pl, gamma);
    }

    /** Radial (zoom): el largo crece con la distancia al centro elegido. Toda la imagen junta. */
    public static int[] radial(int[] in, int w, int h, P p, Job job) {
        float k = p.v[0] / 100f * 0.25f;
        if (k <= 0) return in.clone();
        float cx = p.px * (w - 1), cy = p.py * (h - 1);
        float maxD = (float) Math.hypot(Math.max(cx, w - 1 - cx), Math.max(cy, h - 1 - cy));
        float[][] pl = floatPlanes(in, 1f);
        int n = w * h;
        float[][] tmp = new float[4][n];
        for (float f = k / 2f; f * maxD >= 0.6f; f /= 2f) {
            chk(job);
            avgPass(pl, tmp, w, h, 0, 0, cx, cy, f / 2f);
            for (int c = 0; c < 4; c++) { float[] t = pl[c]; pl[c] = tmp[c]; tmp[c] = t; }
        }
        return fromFloat(pl, 1f);
    }

    // ------------------------------------------------------------------ nitidez, ruido, tono

    public static int[] sharpen(int[] in, int w, int h, int amountPct, float sigma, int thr, Job job) {
        int n = w * h;
        int[] l = new int[n], bl = new int[n], tmp = new int[n];
        for (int i = 0; i < n; i++) { l[i] = lum(in[i]) << 4; bl[i] = l[i]; }
        gaussPlane(bl, tmp, w, h, Math.max(0.5f, sigma));
        chk(job);
        float amt = amountPct / 100f;
        int t16 = thr << 4;
        // v8.59 sin halos: el brillo nuevo no sale del rango de sus vecinos (3x3) mas un poquito
        int[] lo = new int[n], hi = new int[n];
        minMax(l, lo, w, h, 1, false);
        minMax(l, hi, w, h, 1, true);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int c = in[i];
            if ((c >>> 24) == 0) continue;
            int d = l[i] - bl[i];
            int ad = Math.abs(d) - t16;
            if (ad <= 0) { out[i] = c; continue; }
            float dd = Math.min(60f, ad / 16f * amt) * (d < 0 ? -1 : 1);
            int cur = l[i] >> 4, mn = (lo[i] >> 4) - 6, mxv = (hi[i] >> 4) + 6;
            if (cur + dd < mn) dd = mn - cur;
            if (cur + dd > mxv) dd = mxv - cur;
            int di = Math.round(dd);
            out[i] = (c & 0xFF000000) | (clamp(((c >> 16) & 255) + di) << 16) | (clamp(((c >> 8) & 255) + di) << 8)
                    | clamp((c & 255) + di);
        }
        return out;
    }

    /** Ruido determinista: cada pixel real tiene siempre el mismo grano (s convierte coordenadas). */
    static int[] noise(int[] in, int w, int h, int ox, int oy, int amount, boolean color, float s, int seed) {
        int[] out = new int[in.length];
        float k = amount * 1.1f;
        float inv = 1f / s;
        for (int y = 0; y < h; y++) {
            int gy = (int) ((oy + y) * inv);
            for (int x = 0; x < w; x++) {
                int i = y * w + x, c = in[i];
                if ((c >>> 24) == 0) continue;
                int gx = (int) ((ox + x) * inv);
                float n0 = hash(gx, gy, seed) + hash(gx, gy, seed + 7) - 1f;   // triangular -1..1
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                if (color) {
                    float n1 = hash(gx, gy, seed + 13) + hash(gx, gy, seed + 19) - 1f;
                    float n2 = hash(gx, gy, seed + 29) + hash(gx, gy, seed + 31) - 1f;
                    r = clampf(r + n0 * k); g = clampf(g + n1 * k); b = clampf(b + n2 * k);
                } else {
                    int d = Math.round(n0 * k);
                    r = clamp(r + d); g = clamp(g + d); b = clamp(b + d);
                }
                out[i] = (c & 0xFF000000) | (r << 16) | (g << 8) | b;
            }
        }
        return out;
    }

    static int[] vintage(int[] in, int w, int h, int ox, int oy, int fw, int fh, P p, float s) {
        float k = p.v[0] / 100f, vig = p.v[1] / 100f;
        int[][] lut = new int[3][256];
        for (int i = 0; i < 256; i++) {
            float v = i / 255f;
            float sc = v * v * (3 - 2 * v);                          // curva en S suave
            float base = v + (sc - v) * .35f;
            float r = 0.08f + base * 0.86f + 0.03f, g = 0.07f + base * 0.83f, b = 0.12f + base * 0.70f;  // negros lavados, calido
            lut[0][i] = clampf((v + (r - v) * k) * 255);
            lut[1][i] = clampf((v + (g - v) * k) * 255);
            lut[2][i] = clampf((v + (b - v) * k) * 255);
        }
        float cx = (fw - 1) / 2f, cy = (fh - 1) / 2f, rad = (float) Math.hypot(cx, cy);
        int[] out = new int[in.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x, c = in[i];
                if ((c >>> 24) == 0) continue;
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                int l = (r * 77 + g * 151 + b * 28) >> 8;
                float ds = .3f * k;                                    // menos saturacion
                r = Math.round(r + (l - r) * ds); g = Math.round(g + (l - g) * ds); b = Math.round(b + (l - b) * ds);
                r = lut[0][r]; g = lut[1][g]; b = lut[2][b];
                if (vig > 0) {
                    float d = (float) Math.hypot(ox + x - cx, oy + y - cy) / rad;
                    float f = 1f - vig * .75f * smooth(.45f, 1.05f, d);
                    r = Math.round(r * f); g = Math.round(g * f); b = Math.round(b * f);
                }
                out[i] = (c & 0xFF000000) | (r << 16) | (g << 8) | b;
            }
        }
        if (p.v[2] > 0) out = noise(out, w, h, ox, oy, p.v[2] / 2, false, s, 0xF11A);
        return out;
    }

    static int[] chroma(int[] in, int w, int h, int ox, int oy, int fw, int fh, P p, float s, Job job) {
        float k = p.v[0] * s;
        if (k < 0.2f) return in.clone();
        float[][] pl = floatPlanes(in, 1f);
        float cx = p.px * (fw - 1) - ox, cy = p.py * (fh - 1) - oy;
        float maxD = (float) Math.hypot(Math.max(p.px, 1 - p.px) * fw, Math.max(p.py, 1 - p.py) * fh);
        int[] out = new int[in.length];
        for (int y = 0; y < h; y++) {
            if ((y & 31) == 0) chk(job);
            for (int x = 0; x < w; x++) {
                float dx = x - cx, dy = y - cy;
                float f = k / maxD;                                   // desplazamiento crece hacia el borde
                float rx = x + dx * f, ry = y + dy * f, bx = x - dx * f, by = y - dy * f;
                float aR = bil(pl[0], w, h, rx, ry), aB = bil(pl[0], w, h, bx, by);
                int i = y * w + x;
                float aG = pl[0][i];
                float a = Math.max(aG, Math.max(aR, aB));
                if (a < 1f / 512) continue;
                float r = bil(pl[1], w, h, rx, ry), g = pl[2][i], b = bil(pl[3], w, h, bx, by);
                out[i] = (clampf(a * 255) << 24) | (clampf(r / a * 255) << 16) | (clampf(g / a * 255) << 8) | clampf(b / a * 255);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ resplandor y sombra

    static int[] glow(int[] in, int w, int h, P p, float s, Job job) {
        int n = w * h;
        float thr = 0.35f + p.v[2] / 100f * 0.6f;
        float k = p.v[0] / 100f * 1.6f;
        int[] a = new int[n], r = new int[n], g = new int[n], b = new int[n];
        for (int i = 0; i < n; i++) {
            int c = in[i], al = c >>> 24;
            if (al == 0) continue;
            float wgt = smooth(thr, Math.min(1f, thr + .25f), lum(c) / 255f);
            if (wgt <= 0) continue;
            int aa = Math.round(al * wgt);
            a[i] = aa;
            r[i] = ((c >> 16) & 255) * aa; g[i] = ((c >> 8) & 255) * aa; b[i] = (c & 255) * aa;
        }
        int[] tmp = new int[n];
        float sigma = Math.max(.5f, p.v[1] * .5f * s);
        gaussPlane(a, tmp, w, h, sigma); chk(job);
        gaussPlane(r, tmp, w, h, sigma); gaussPlane(g, tmp, w, h, sigma); chk(job);
        gaussPlane(b, tmp, w, h, sigma);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int c = in[i], al = c >>> 24;
            // luz (premultiplicada) 0..255
            float gr = Math.min(255f, r[i] / 255f * k), gg = Math.min(255f, g[i] / 255f * k), gb = Math.min(255f, b[i] / 255f * k);
            float ga = Math.min(255f, a[i] * k);
            if (al == 0) {
                if (!p.opt || ga < 1) continue;
                out[i] = (clampf(ga) << 24) | (clampf(gr / ga * 255) << 16) | (clampf(gg / ga * 255) << 8) | clampf(gb / ga * 255);
                continue;
            }
            int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
            cr = clampf(255 - (255 - cr) * (255 - gr) / 255f);
            cg = clampf(255 - (255 - cg) * (255 - gg) / 255f);
            cb = clampf(255 - (255 - cb) * (255 - gb) / 255f);
            int oa = al;
            if (p.opt && al < 255 && ga > 0) oa = clampf(al + ga * (255 - al) / 255f);
            out[i] = (oa << 24) | (cr << 16) | (cg << 8) | cb;
        }
        return out;
    }

    static int[] shadow(int[] in, int w, int h, int ox, int oy, int fw, int fh, P p, float s, Job job, Cache cache) {
        int n = w * h;
        float sigma = p.v[1] * .5f * s;
        String key = "shadowA:" + w + "x" + h + ":" + sigma + ":" + System.identityHashCode(in);
        int[] a = cache != null ? (int[]) cache.get(key) : null;
        if (a == null) {
            a = new int[n];
            for (int i = 0; i < n; i++) a[i] = (in[i] >>> 24) << 4;
            gaussPlane(a, new int[n], w, h, sigma);
            if (cache != null) cache.put(key, a);
        }
        chk(job);
        // direccion: del centro de la imagen al punto tocado
        float dx = p.px - .5f, dy = p.py - .5f;
        float dl = (float) Math.hypot(dx, dy);
        if (dl < 1e-4f) { dx = .7f; dy = .7f; dl = 1; }
        float dist = p.v[0] * s;
        float sx = dx / dl * dist, sy = dy / dl * dist;
        float op = p.v[2] / 100f;
        int[] out = new int[n];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x, c = in[i];
                float fx = x - sx, fy = y - sy;
                int sa = 0;
                if (fx > -1 && fy > -1 && fx < w && fy < h) sa = Math.round(bilI(a, w, h, fx, fy) / 16f * op);
                int ca = c >>> 24;
                if (sa <= 0) { out[i] = c; continue; }
                // dibujo encima de la sombra negra
                out[i] = ca == 0 ? (sa << 24) : over(sa << 24, c, ca);
            }
        }
        return out;
    }

    /** src encima de dst (sin premultiplicar), igual que Project.over. */
    static int over(int dst, int src, int sa) {
        if (sa >= 255) return (src & 0x00FFFFFF) | 0xFF000000;
        int da = dst >>> 24;
        if (da == 0) return (src & 0x00FFFFFF) | (sa << 24);
        int dw = (da * (255 - sa)) / 255, oa = sa + dw;
        if (oa == 0) return 0;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * dw) / oa;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * dw) / oa;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * dw) / oa;
        return (oa << 24) | (r << 16) | (g << 8) | b;
    }

    static float bilI(int[] p, int w, int h, float x, float y) {
        if (x < 0) x = 0; else if (x > w - 1) x = w - 1;
        if (y < 0) y = 0; else if (y > h - 1) y = h - 1;
        int x0 = (int) x, y0 = (int) y;
        int x1 = x0 < w - 1 ? x0 + 1 : x0, y1 = y0 < h - 1 ? y0 + 1 : y0;
        float tx = x - x0, ty = y - y0;
        float a = p[y0 * w + x0], b = p[y0 * w + x1], c = p[y1 * w + x0], d = p[y1 * w + x1];
        return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
    }

    // ------------------------------------------------------------------ extraer lineas

    /** Brillo del papel en chico (para quitar el amarillo y las manchas del escaneo). */
    static final class Paper {
        final float[] map;
        final int mw, mh, fw, fh;

        Paper(float[] m, int mw, int mh, int fw, int fh) { map = m; this.mw = mw; this.mh = mh; this.fw = fw; this.fh = fh; }

        /** Brillo del papel (0..255) en el pixel (x,y) de la imagen entera. */
        float at(int x, int y) {
            float u = (x + .5f) * mw / fw - .5f, v = (y + .5f) * mh / fh - .5f;
            return bil(map, mw, mh, u, v);
        }
    }

    /**
     * Papel = lo mas claro de cada zona (maximo en bloques, luego cierre y suavizado). Una linea
     * negra es angosta y no cuenta; el amarillo del papel o una sombra del escaneo si.
     */
    static Paper paperMap(int[] src, int w, int h, Job job) {
        int blk = Math.max(2, Math.max(w, h) / 256);
        int mw = (w + blk - 1) / blk, mh = (h + blk - 1) / blk;
        float[] m = new float[mw * mh];
        for (int by = 0; by < mh; by++) {
            chk(job);
            for (int bx = 0; bx < mw; bx++) {
                // segundo mas claro del bloque (no un pixel suelto)
                int best = 0, second = 0;
                for (int y = by * blk; y < Math.min(h, (by + 1) * blk); y++)
                    for (int x = bx * blk; x < Math.min(w, (bx + 1) * blk); x++) {
                        int c = src[y * w + x];
                        int l = (c >>> 24) < 128 ? 255 : lum(c);
                        if (l > best) { second = best; best = l; } else if (l > second) second = l;
                    }
                m[by * mw + bx] = second;
            }
        }
        // maximo en 2 bloques a la redonda (tapa lineas gruesas) y suavizado
        float[] t = new float[m.length];
        for (int pass = 0; pass < 2; pass++) {
            for (int y = 0; y < mh; y++)
                for (int x = 0; x < mw; x++) {
                    float mx = 0;
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = Math.min(mw - 1, Math.max(0, x + dx)), yy = Math.min(mh - 1, Math.max(0, y + dy));
                            mx = Math.max(mx, m[yy * mw + xx]);
                        }
                    t[y * mw + x] = mx;
                }
            System.arraycopy(t, 0, m, 0, m.length);
        }
        gaussPlaneF(m, t, mw, mh, 2f);
        for (int i = 0; i < m.length; i++) m[i] = Math.max(60f, Math.min(255f, m[i]));
        return new Paper(m, mw, mh, w, h);
    }

    /**
     * Brillo -&gt; transparencia: mas claro que Blanco = transparente; mas oscuro que Negro = linea
     * llena; en medio, antialias suave (smoothstep). El color se "desmezcla" del blanco, asi la
     * linea sobre otro fondo se ve igual que sobre el papel.
     */
    static int[] extract(int[] in, int w, int h, int ox, int oy, int fw, int fh, P p, float s, Paper paper, Job job) {
        int white = Math.max(p.v[1] + 1, p.v[0]), black = Math.min(p.v[1], white - 1);
        int n = w * h;
        int[] out = new int[n];
        for (int y = 0; y < h; y++) {
            if ((y & 63) == 0) chk(job);
            for (int x = 0; x < w; x++) {
                int i = y * w + x, c = in[i], sa = c >>> 24;
                if (sa == 0) continue;
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                float gain = 1f;
                if (paper != null) gain = 255f / paper.at(ox + x, oy + y);
                float l = lum(c) * gain;
                float a = 1f - smooth(black, white, l);
                if (a <= 0.004f) continue;
                float fr = Math.min(255f, r * gain), fg = Math.min(255f, g * gain), fb = Math.min(255f, b * gain);
                int cr = clampf((fr - 255f * (1f - a)) / a), cg = clampf((fg - 255f * (1f - a)) / a), cb = clampf((fb - 255f * (1f - a)) / a);
                int al = Math.round(a * sa);
                if (al > 0) out[i] = (al << 24) | (cr << 16) | (cg << 8) | cb;
            }
        }
        int area = Math.round(p.v[2] * p.v[2] * s * s);
        if (area > 0) removeSpecks(out, w, h, area, job);
        return out;
    }

    /**
     * Quita manchitas sueltas (componentes de menos de 'area' pixeles). Las que tocan el borde del
     * pedazo se dejan (pueden seguir en el pedazo de al lado). Las lineas largas no se tocan.
     */
    static void removeSpecks(int[] px, int w, int h, int area, Job job) {
        int n = w * h;
        int[] lab = new int[n];
        int[] stack = new int[Math.min(n, 1 << 16)];
        int[] comp = new int[Math.max(16, area + 1)];
        int id = 0;
        for (int i = 0; i < n; i++) {
            if (lab[i] != 0 || (px[i] >>> 24) < 40) continue;
            if ((i & 0xFFFF) == 0) chk(job);
            id++;
            int sp = 0, cnt = 0;
            boolean edge = false, big = false;
            stack[sp++] = i;
            lab[i] = id;
            while (sp > 0) {
                int k = stack[--sp];
                if (cnt < comp.length) comp[cnt] = k;
                cnt++;
                if (cnt > area) big = true;
                int x = k % w, y = k / w;
                if (x == 0 || y == 0 || x == w - 1 || y == h - 1) edge = true;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int q = yy * w + xx;
                        if (lab[q] != 0 || (px[q] >>> 24) < 40) continue;
                        lab[q] = id;
                        if (sp == stack.length) stack = Arrays.copyOf(stack, stack.length * 2);
                        stack[sp++] = q;
                    }
                }
            }
            if (!big && !edge) {
                for (int j = 0; j < cnt && j < comp.length; j++) {
                    int k = comp[j];
                    px[k] = 0;
                    // el antialias de alrededor (menos de 40 de alfa) tambien
                    int x = k % w, y = k / w;
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx, yy = y + dy;
                            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                            int q = yy * w + xx;
                            if ((px[q] >>> 24) < 40) px[q] = 0;
                        }
                }
            }
        }
    }

    // ------------------------------------------------------------------ pictorizar

    static float xdogSigma(int grosor) { return 0.35f + grosor * 0.28f; }

    /**
     * Diferencia de gaussianas (base de XDoG, Winnemoller 2012) usada solo para bordes: devuelve
     * la oscuridad de la linea 0..1 (1 = linea negra), con borde suave.
     */
    static float[] xdog(int[] in, int w, int h, int grosor, int detalle, float s, Job job) {
        int n = w * h;
        float[] g1 = new float[n], g2 = new float[n], tmp = new float[n];
        for (int i = 0; i < n; i++) {
            int c = in[i];
            int a = c >>> 24;
            float l = lum(c) / 255f;
            g1[i] = a == 255 ? l : 1f - (1f - l) * a / 255f;   // transparente = papel
        }
        System.arraycopy(g1, 0, g2, 0, n);
        float sg = Math.max(0.3f, xdogSigma(grosor) * s);
        gaussPlaneF(g1, tmp, w, h, sg);
        chk(job);
        gaussPlaneF(g2, tmp, w, h, sg * 2.2f);
        chk(job);
        // DoG de bordes: d = G(1.6s) - G(s) > 0 donde el pixel es mas oscuro que lo de alrededor
        // (una linea). Una zona oscura grande (pelo negro, ropa) solo marca su contorno.
        // umbral segun el contraste de ESTA imagen: el percentil de d (manga fuerte o color suave)
        int[] hist = new int[1024];
        int pos = 0;
        for (int i = 0; i < n; i++) {
            float d = g2[i] - g1[i];
            if (d <= 0.002f) continue;
            hist[Math.min(1023, (int) (d * 2048))]++;
            pos++;
        }
        float q = 0.86f - detalle / 100f * 0.36f;     // detalle 0: solo lo mas marcado
        int target = Math.round(pos * q), acc = 0, bin = 0;
        while (bin < 1023 && acc + hist[bin] < target) acc += hist[bin++];
        float eps = Math.max(0.006f, Math.min(0.08f, bin / 2048f));
        float lo = eps * 0.55f, hi = eps * 1.35f;
        for (int i = 0; i < n; i++) {
            float d = g2[i] - g1[i];
            float v = smooth(lo, hi, d);
            g1[i] = v < 0.03f ? 0f : v;
        }
        return g1;
    }

    static int[] picLines(int[] in, int w, int h, P p, float s, Job job) {
        float[] d = xdog(in, w, h, p.v[0], p.v[1], s, job);
        int n = w * h;
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int a = Math.round(d[i] * 255);
            if (a > 0) out[i] = a << 24;   // negro
        }
        int area = Math.round(p.v[2] * p.v[2] * s * s);
        if (area > 0) removeSpecks(out, w, h, area, job);
        if (p.opt) {
            for (int i = 0; i < n; i++) {
                int a = out[i] >>> 24, v = 255 - a;
                out[i] = 0xFF000000 | (v << 16) | (v << 8) | v;
            }
        }
        return out;
    }

    /**
     * Kuwahara con imagenes integrales (O(1) por pixel): de los cuatro cuadrados alrededor del
     * pixel se usa el promedio del mas parejo. Aplana colores y respeta los bordes (ojos, pelo).
     * Luego, si colores &gt; 0, se aplana el brillo en bandas suaves (tipo anime).
     */
    static int[] picColor(int[] in, int w, int h, int simplify, int levels, float s, Job job) {
        int r = Math.max(1, Math.round(simplify * s));
        int n = w * h, W = w + 1;
        int[] ia = new int[W * (h + 1)], ir = new int[ia.length], ig = new int[ia.length], ib = new int[ia.length];
        long[] il = new long[ia.length];
        for (int y = 0; y < h; y++) {
            int ra = 0, rr = 0, rg = 0, rb = 0;
            long rl = 0;
            for (int x = 0; x < w; x++) {
                int c = in[y * w + x], a = c >>> 24;
                int l = lum(c);
                ra += a; rr += ((c >> 16) & 255) * a >> 8; rg += ((c >> 8) & 255) * a >> 8; rb += (c & 255) * a >> 8;
                rl += (long) l * l * a;
                int k = (y + 1) * W + x + 1, u = y * W + x + 1;
                ia[k] = ia[u] + ra; ir[k] = ir[u] + rr; ig[k] = ig[u] + rg; ib[k] = ib[u] + rb; il[k] = il[u] + rl;
            }
            if ((y & 63) == 0) chk(job);
        }
        int[] out = new int[n];
        float[] band = null;
        if (levels > 1) band = new float[]{levels};
        for (int y = 0; y < h; y++) {
            if ((y & 31) == 0) chk(job);
            for (int x = 0; x < w; x++) {
                int c = in[y * w + x], al = c >>> 24;
                if (al == 0) continue;
                double bestVar = Double.MAX_VALUE;
                int br = 0, bg = 0, bb = 0;
                for (int q = 0; q < 4; q++) {
                    int x0 = q % 2 == 0 ? x - r : x, x1 = q % 2 == 0 ? x : x + r;
                    int y0 = q < 2 ? y - r : y, y1 = q < 2 ? y : y + r;
                    x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(w - 1, x1); y1 = Math.min(h - 1, y1);
                    int k11 = (y1 + 1) * W + x1 + 1, k01 = y0 * W + x1 + 1, k10 = (y1 + 1) * W + x0, k00 = y0 * W + x0;
                    int sa = ia[k11] - ia[k01] - ia[k10] + ia[k00];
                    if (sa <= 0) continue;
                    float sr = (ir[k11] - ir[k01] - ir[k10] + ir[k00]) * 256f / sa;
                    float sg2 = (ig[k11] - ig[k01] - ig[k10] + ig[k00]) * 256f / sa;
                    float sb = (ib[k11] - ib[k01] - ib[k10] + ib[k00]) * 256f / sa;
                    double ml = (sr * 77 + sg2 * 151 + sb * 28) / 256.0;
                    double m2 = (double) (il[k11] - il[k01] - il[k10] + il[k00]) / sa;
                    double var = m2 - ml * ml;
                    if (var < bestVar) { bestVar = var; br = clampf(sr); bg = clampf(sg2); bb = clampf(sb); }
                }
                if (band != null) {
                    int l = (br * 77 + bg * 151 + bb * 28) >> 8;
                    float q = quant(l / 255f, levels) * 255f;
                    int d = Math.round(q - l);
                    br = clamp(br + d); bg = clamp(bg + d); bb = clamp(bb + d);
                }
                out[y * w + x] = (al << 24) | (br << 16) | (bg << 8) | bb;
            }
        }
        return out;
    }

    /** Bandas de brillo con borde suave (sin escalones serruchados). */
    static float quant(float v, int levels) {
        float f = v * (levels - 1);
        float i = (float) Math.floor(f), t = f - i;
        t = smooth(0.35f, 0.65f, t);
        return Math.min(1f, (i + t) / (levels - 1));
    }

    static int[] picBoth(int[] in, int w, int h, P p, float s, Job job) {
        int[] col = picColor(in, w, h, p.v[0], 8, s, job);
        float[] d = xdog(in, w, h, p.v[1], p.v[2], s, job);
        for (int i = 0; i < col.length; i++) {
            int c = col[i];
            if (c == 0) continue;
            float k = 1f - d[i] * 0.92f;
            col[i] = (c & 0xFF000000) | (clampf(((c >> 16) & 255) * k) << 16) | (clampf(((c >> 8) & 255) * k) << 8)
                    | clampf((c & 255) * k);
        }
        return col;
    }

    // ------------------------------------------------------------------ inflar

    /** Normales del volumen en chico (lado &lt;= 768). */
    static final class Normals {
        final float[] nx, ny, nz;
        final int mw, mh, fw, fh;

        Normals(float[] x, float[] y, float[] z, int mw, int mh, int fw, int fh) {
            nx = x; ny = y; nz = z; this.mw = mw; this.mh = mh; this.fw = fw; this.fh = fh;
        }
    }

    static Normals normals(int[] src, int w, int h, int volume, Job job) {
        float sc = Math.min(1f, 768f / Math.max(w, h));
        int mw = Math.max(1, Math.round(w * sc)), mh = Math.max(1, Math.round(h * sc));
        int n = mw * mh;
        float[] hgt = new float[n], al = new float[n];
        int transp = 0, opaque = 0;
        for (int y = 0; y < mh; y++) {
            int sy = Math.min(h - 1, (int) ((y + .5f) / sc));
            for (int x = 0; x < mw; x++) {
                int c = src[sy * w + Math.min(w - 1, (int) ((x + .5f) / sc))];
                int a = c >>> 24;
                al[y * mw + x] = a / 255f;
                if (a < 128) transp++; else opaque++;
                hgt[y * mw + x] = lum(c) / 255f;
            }
        }
        chk(job);
        boolean shape = transp > n / 50 && opaque > n / 20;
        float[] tmp = new float[n];
        float dome = 2f + volume / 100f * Math.max(mw, mh) * 0.08f;
        if (shape) {
            // distancia al borde del dibujo (chaflan 3-4) -> cupula suave
            float[] d = new float[n];
            float big = 1e9f;
            for (int i = 0; i < n; i++) d[i] = al[i] >= .5f ? big : 0;
            for (int y = 0; y < mh; y++)
                for (int x = 0; x < mw; x++) {
                    int i = y * mw + x;
                    if (d[i] == 0) continue;
                    float v = d[i];
                    if (x > 0) v = Math.min(v, d[i - 1] + 3);
                    if (y > 0) v = Math.min(v, d[i - mw] + 3);
                    if (x > 0 && y > 0) v = Math.min(v, d[i - mw - 1] + 4);
                    if (x < mw - 1 && y > 0) v = Math.min(v, d[i - mw + 1] + 4);
                    if (x == 0 || y == 0 || x == mw - 1 || y == mh - 1) v = Math.min(v, 3);
                    d[i] = v;
                }
            for (int y = mh - 1; y >= 0; y--)
                for (int x = mw - 1; x >= 0; x--) {
                    int i = y * mw + x;
                    if (d[i] == 0) continue;
                    float v = d[i];
                    if (x < mw - 1) v = Math.min(v, d[i + 1] + 3);
                    if (y < mh - 1) v = Math.min(v, d[i + mw] + 3);
                    if (x < mw - 1 && y < mh - 1) v = Math.min(v, d[i + mw + 1] + 4);
                    if (x > 0 && y < mh - 1) v = Math.min(v, d[i + mw - 1] + 4);
                    d[i] = v;
                }
            for (int i = 0; i < n; i++) {
                float t = Math.min(1f, d[i] / 3f / dome);
                float dm = (float) Math.sqrt(Math.max(0, 1 - (1 - t) * (1 - t)));   // cupula
                hgt[i] = dm * dome * 0.9f + hgt[i] * 1.5f;                            // + algo de detalle
            }
        } else {
            for (int i = 0; i < n; i++) hgt[i] *= dome * 0.6f;
        }
        gaussPlaneF(hgt, tmp, mw, mh, 1f + dome * 0.15f);
        chk(job);
        float[] nx = new float[n], ny = new float[n], nz = new float[n];
        for (int y = 0; y < mh; y++)
            for (int x = 0; x < mw; x++) {
                int i = y * mw + x;
                float gx = hgt[y * mw + Math.min(mw - 1, x + 1)] - hgt[y * mw + Math.max(0, x - 1)];
                float gy = hgt[Math.min(mh - 1, y + 1) * mw + x] - hgt[Math.max(0, y - 1) * mw + x];
                float vx = -gx * .5f, vy = -gy * .5f, vz = 1f;
                float l = (float) Math.sqrt(vx * vx + vy * vy + vz * vz);
                nx[i] = vx / l; ny[i] = vy / l; nz[i] = vz / l;
            }
        return new Normals(nx, ny, nz, mw, mh, w, h);
    }

    /**
     * Luz: difusa (Lambert) + brillo (Blinn). Mover el sol solo recalcula esto (las normales
     * estan guardadas). Sombra = multiplicar; luz = aclarar (menos sobre negro: no lava la tinta).
     */
    static int[] inflate(int[] in, int w, int h, int ox, int oy, int fw, int fh, P p, Normals nm, Job job) {
        float k = p.v[0] / 100f, spec = p.v[2] / 100f;
        float lxs = p.px * fw, lys = p.py * fh, lz = Math.max(fw, fh) * 0.55f;
        float sx = (float) nm.mw / fw, sy = (float) nm.mh / fh;
        int[] out = new int[in.length];
        for (int y = 0; y < h; y++) {
            if ((y & 63) == 0) chk(job);
            int gy = oy + y;
            float v = (gy + .5f) * sy - .5f;
            for (int x = 0; x < w; x++) {
                int i = y * w + x, c = in[i];
                if ((c >>> 24) == 0) continue;
                int gx = ox + x;
                float u = (gx + .5f) * sx - .5f;
                float nx = bil(nm.nx, nm.mw, nm.mh, u, v), ny = bil(nm.ny, nm.mw, nm.mh, u, v), nz = bil(nm.nz, nm.mw, nm.mh, u, v);
                float Lx = lxs - gx, Ly = lys - gy, Lz = lz;
                float ll = (float) Math.sqrt(Lx * Lx + Ly * Ly + Lz * Lz);
                Lx /= ll; Ly /= ll; Lz /= ll;
                float nl = Math.max(0, nx * Lx + ny * Ly + nz * Lz);
                float rel = (nl - Lz) * 1.6f;                    // 0 donde es plano
                float hx = Lx, hy = Ly, hz = Lz + 1f;
                float hl = (float) Math.sqrt(hx * hx + hy * hy + hz * hz);
                float nh = Math.max(0, (nx * hx + ny * hy + nz * hz) / hl);
                float sp = (float) Math.pow(nh, 24) * spec;
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                float lf = (float) Math.sqrt(lum(c) / 255f);
                float fr, fg, fb;
                if (rel < 0) {
                    float m = 1f + rel * k;
                    if (m < 0.25f) m = 0.25f;
                    fr = r * m; fg = g * m; fb = b * m;
                } else {
                    float a = Math.min(1f, rel * k) * lf;
                    fr = r + (255 - r) * a; fg = g + (255 - g) * a; fb = b + (255 - b) * a;
                }
                float sa = Math.min(1f, sp) * lf;
                fr += (255 - fr) * sa; fg += (255 - fg) * sa; fb += (255 - fb) * sa;
                out[i] = (c & 0xFF000000) | (clampf(fr) << 16) | (clampf(fg) << 8) | clampf(fb);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ v8.59 lineas en imagenes a color

    /** true si la imagen tiene color de verdad (no solo grises). Muestra cada pocos pixeles. */
    static boolean isColored(int[] px) {
        // el tono del papel (amarillo de un escaneo) se descuenta: eso no es "color"
        int step = Math.max(1, px.length / 40000);
        long tr = 0, tg = 0, tn = 0;
        for (int i = 0; i < px.length; i += step) {
            int c = px[i];
            if ((c >>> 24) < 128) continue;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            if ((r * 77 + g * 151 + b * 28) >> 8 < 150) continue;
            tr += r - b; tg += g - b; tn++;
        }
        float kr = tn > 0 ? tr / (float) tn / 255f : 0, kg = tn > 0 ? tg / (float) tn / 255f : 0;
        int n = 0, col = 0;
        for (int i = 0; i < px.length; i += step) {
            int c = px[i];
            if ((c >>> 24) < 128) continue;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int l = (r * 77 + g * 151 + b * 28) >> 8;
            float dr = (r - b) - kr * l, dg = (g - b) - kg * l;
            n++;
            if (dr * dr + dg * dg > 30 * 30 || Math.abs(r - g) > 40 && Math.abs((r - g) - (kr - kg) * l) > 30) col++;
        }
        return n > 0 && col * 100 > n * 6;
    }

    /** Maximo (dil) o minimo (ero) en una ventana cuadrada de radio r, separable. */
    static void minMax(int[] src, int[] dst, int w, int h, int r, boolean max) {
        int[] t = new int[w * h];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int v = src[row + x];
                for (int k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) {
                    int q = src[row + k];
                    if (max ? q > v : q < v) v = q;
                }
                t[row + x] = v;
            }
        }
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int v = t[y * w + x];
                for (int k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) {
                    int q = t[k * w + x];
                    if (max ? q > v : q < v) v = q;
                }
                dst[y * w + x] = v;
            }
    }

    /**
     * Fuerza de LINEA 0..255 por pixel: cuanto mas oscuro es que el fondo cercano, contando como
     * fondo el "cierre" (maximo y luego minimo en radio r): todo lo oscuro mas angosto que 2r
     * desaparece en el cierre, asi que la diferencia es solo la linea. Las sombras y el color de
     * una zona grande no cuentan. bg recibe el brillo del fondo (para desmezclar el color).
     */
    static int[] lineStrength(int[] in, int w, int h, int r, int[] bg) {
        int n = w * h;
        int[] l = new int[n];
        for (int i = 0; i < n; i++) {
            int c = in[i];
            int a = c >>> 24;
            l[i] = a < 128 ? 255 : lum(c);
        }
        int[] mx = new int[n];
        minMax(l, mx, w, h, r, true);
        int[] cl = bg != null ? bg : new int[n];
        minMax(mx, cl, w, h, r, false);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int d = cl[i] - l[i];
            // lo muy negro (pelo negro, relleno de tinta) siempre es linea
            if (l[i] < 55) d = Math.max(d, 255 - l[i] * 2);
            out[i] = d < 0 ? 0 : d > 255 ? 255 : d;
        }
        return out;
    }

    static int lineRadius(float s) { return Math.max(1, Math.round(3f * Math.max(s, 0.34f))); }

    /** Extraer lineas en una imagen a color: queda solo la linea (con su color), lo demas transparente. */
    static int[] extractColor(int[] in, int w, int h, P p, float s, Job job) {
        int n = w * h;
        int[] bg = new int[n];
        int[] ls = lineStrength(in, w, h, lineRadius(s), bg);
        chk(job);
        // Blanco/Negro: misma idea que en B/N, sobre la fuerza de linea (255 - fuerza = "brillo")
        int white = Math.max(p.v[1] + 1, p.v[0]), black = Math.min(p.v[1], white - 1);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int c = in[i], sa = c >>> 24;
            if (sa == 0) continue;
            float a = 1f - smooth(black, white, 255 - ls[i] * 1.6f);
            if (a <= 0.02f) continue;
            out[i] = (Math.round(a * sa) << 24) | (c & 0xFFFFFF);
        }
        int area = Math.round(p.v[2] * p.v[2] * s * s);
        if (area > 0) removeSpecks(out, w, h, area, job);
        return out;
    }

    /** Pone las lineas del original encima de un resultado (Pictorizar color no las borra). */
    static int[] withLines(int[] orig, int[] col, int w, int h, float s, Job job) {
        int[] ls = lineStrength(orig, w, h, lineRadius(s), null);
        chk(job);
        for (int i = 0; i < col.length; i++) {
            int c = col[i];
            if (c == 0) continue;
            float a = smooth(40, 150, ls[i]);
            if (a <= 0) continue;
            int o = orig[i];
            float k = 1f - a;
            int r = clampf(((c >> 16) & 255) * k + ((o >> 16) & 255) * a);
            int g = clampf(((c >> 8) & 255) * k + ((o >> 8) & 255) * a);
            int b = clampf((c & 255) * k + (o & 255) * a);
            col[i] = (c & 0xFF000000) | (r << 16) | (g << 8) | b;
        }
        return col;
    }

    // ------------------------------------------------------------------ copia chica

    /**
     * Copia reducida (promedio de cajas premultiplicado: sin bordes oscuros) con lado mayor
     * &lt;= maxSide. @return {w, h} en dims; pixeles en el arreglo devuelto.
     */
    public static int[] downscale(int[] src, int w, int h, int maxSide, int[] dims) {
        float sc = Math.min(1f, maxSide / (float) Math.max(w, h));
        int ow = Math.max(1, Math.round(w * sc)), oh = Math.max(1, Math.round(h * sc));
        dims[0] = ow; dims[1] = oh;
        if (ow == w && oh == h) return src.clone();
        int[] out = new int[ow * oh];
        for (int y = 0; y < oh; y++) {
            int y0 = (int) ((long) y * h / oh), y1 = Math.max(y0 + 1, (int) ((long) (y + 1) * h / oh));
            for (int x = 0; x < ow; x++) {
                int x0 = (int) ((long) x * w / ow), x1 = Math.max(x0 + 1, (int) ((long) (x + 1) * w / ow));
                long sa = 0, sr = 0, sg = 0, sb = 0;
                int cnt = 0;
                for (int yy = y0; yy < y1; yy++)
                    for (int xx = x0; xx < x1; xx++) {
                        int c = src[yy * w + xx], a = c >>> 24;
                        cnt++;
                        if (a == 0) continue;
                        sa += a; sr += (long) ((c >> 16) & 255) * a; sg += (long) ((c >> 8) & 255) * a; sb += (long) (c & 255) * a;
                    }
                if (sa == 0) continue;
                out[y * ow + x] = ((int) (sa / cnt) << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
            }
        }
        return out;
    }
}
