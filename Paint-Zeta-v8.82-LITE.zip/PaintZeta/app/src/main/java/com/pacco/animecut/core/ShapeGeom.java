package com.pacco.animecut.core;

/**
 * v8.79 FIGURAS: la forma de cada figura en coordenadas de la IMAGEN (no de la pantalla), asi el
 * zoom o girar la vista nunca la deforman. Java puro: lo usan el lienzo y las pruebas de PC.
 *
 * Una figura "caja" (rectangulo, circulo, elipse, poligono, rectangulo redondeado, bocadillo)
 * tiene centro, medio ancho, medio alto y giro. Linea y flecha tienen dos extremos.
 * outline() devuelve el contorno como filas de puntos (x,y,x,y...), cerradas o abiertas.
 */
public final class ShapeGeom {
    private ShapeGeom() { }

    public static final int LINE = 0, RECT = 1, CIRCLE = 2, ELLIPSE = 3, POLYGON = 4, RRECT = 5,
            ARROW = 6, BUBBLE = 7, COUNT = 8;

    public static final String[] NAMES = {"Linea", "Rectangulo", "Circulo", "Elipse", "Poligono",
            "Rect. redondeado", "Flecha", "Bocadillo"};

    public static final String[] HELP = {
            "Arrastra de un punto a otro. Despues mueve sus dos extremos.",
            "Arrastra para hacer la caja. Esquinas: tamano; punto de arriba: girar. Cuadrado en Ajustes.",
            "Siempre redondo. Esquinas: tamano; arrastra adentro para moverlo.",
            "Ancho y alto por separado. Punto de arriba: girar.",
            "Triangulo, pentagono, hexagono... cambia los lados en Ajustes (3 a 32).",
            "Rectangulo con esquinas redondas. El radio se cambia en Ajustes.",
            "Gruesa (se puede rellenar) o fina, con punta al final, al inicio o en las dos.",
            "Globo de dialogo para manga. El punto naranja mueve la cola."};

    /** Estilo de las figuras (contorno y relleno por separado). */
    public static final class Style {
        public boolean strokeOn = true, strokeCurrent = true, strokeBrush = false;
        public int strokeColor = 0xFF000000;
        public float strokeW = 6f, strokeOp = 1f;
        public boolean fillOn = false, fillCurrent = false;
        public int fillColor = 0xFFFFFFFF;
        public float fillOp = 1f;
        public boolean smooth = true;
        /** Rectangulo: cuadrado 1:1. */
        public boolean square = false;
        public int sides = 6;
        /** Rectangulo redondeado: 0..100 % del lado corto. */
        public float corner = 30f;
        /** Flecha: fina (solo linea) o gruesa (rellenable); puntas 1 final, 2 inicio, 3 ambas. */
        public boolean thin = false;
        public int heads = 1;
        public float arrowW = 24f;

        public Style copy() {
            Style s = new Style();
            s.strokeOn = strokeOn; s.strokeCurrent = strokeCurrent; s.strokeBrush = strokeBrush;
            s.strokeColor = strokeColor; s.strokeW = strokeW; s.strokeOp = strokeOp;
            s.fillOn = fillOn; s.fillCurrent = fillCurrent; s.fillColor = fillColor; s.fillOp = fillOp;
            s.smooth = smooth; s.square = square; s.sides = sides; s.corner = corner;
            s.thin = thin; s.heads = heads; s.arrowW = arrowW;
            return s;
        }
    }

    /** Una figura editable (borrador). */
    public static final class Shape {
        public int type;
        public float cx, cy, hw, hh, rot;
        public float x0, y0, x1, y1;
        public float tx, ty;

        public Shape copy() {
            Shape s = new Shape();
            s.type = type; s.cx = cx; s.cy = cy; s.hw = hw; s.hh = hh; s.rot = rot;
            s.x0 = x0; s.y0 = y0; s.x1 = x1; s.y1 = y1; s.tx = tx; s.ty = ty;
            return s;
        }

        public boolean isSegment() { return type == LINE || type == ARROW; }
    }

    /** Contorno: filas de puntos; closed[i] = la fila i es cerrada. fillable = tiene interior. */
    public static final class Outline {
        public final float[][] polys;
        public final boolean[] closed;
        public final boolean fillable;

        Outline(float[][] p, boolean[] c, boolean f) { polys = p; closed = c; fillable = f; }
    }

    // ------------------------------------------------------------------ crear

    /** Figura nueva arrastrando de (ax,ay) a (bx,by). */
    public static Shape create(int type, float ax, float ay, float bx, float by, Style st) {
        Shape s = new Shape();
        s.type = type;
        if (type == LINE || type == ARROW) {
            s.x0 = ax; s.y0 = ay; s.x1 = bx; s.y1 = by;
            return s;
        }
        float dx = bx - ax, dy = by - ay;
        if (type == CIRCLE || (type == RECT && st != null && st.square)) {
            float m = Math.max(Math.abs(dx), Math.abs(dy));
            dx = Math.copySign(m, dx == 0 ? 1 : dx);
            dy = Math.copySign(m, dy == 0 ? 1 : dy);
        }
        s.cx = ax + dx / 2f;
        s.cy = ay + dy / 2f;
        s.hw = Math.max(1f, Math.abs(dx) / 2f);
        s.hh = Math.max(1f, Math.abs(dy) / 2f);
        s.rot = 0f;
        if (type == BUBBLE) {
            // cola hacia abajo a la izquierda, fuera del globo
            s.tx = s.cx - s.hw * 0.55f;
            s.ty = s.cy + s.hh * 1.6f;
        }
        return s;
    }

    // ------------------------------------------------------------------ coordenadas

    /** Local (respecto del centro, sin girar) a imagen. */
    public static void toWorld(Shape s, float lx, float ly, float[] out) {
        float c = (float) Math.cos(s.rot), n = (float) Math.sin(s.rot);
        out[0] = s.cx + lx * c - ly * n;
        out[1] = s.cy + lx * n + ly * c;
    }

    public static void toLocal(Shape s, float x, float y, float[] out) {
        float c = (float) Math.cos(s.rot), n = (float) Math.sin(s.rot);
        float dx = x - s.cx, dy = y - s.cy;
        out[0] = dx * c + dy * n;
        out[1] = -dx * n + dy * c;
    }

    /** Las 4 esquinas de la caja (imagen): 0 arriba-izq, 1 arriba-der, 2 abajo-der, 3 abajo-izq. */
    public static float[] corners(Shape s) {
        float[] r = new float[8], q = new float[2];
        float[][] l = {{-s.hw, -s.hh}, {s.hw, -s.hh}, {s.hw, s.hh}, {-s.hw, s.hh}};
        for (int i = 0; i < 4; i++) {
            toWorld(s, l[i][0], l[i][1], q);
            r[i * 2] = q[0];
            r[i * 2 + 1] = q[1];
        }
        return r;
    }

    // ------------------------------------------------------------------ editar

    /**
     * Arrastrar la esquina "idx" a (px,py): la esquina opuesta queda quieta. lock = mantener
     * cuadrado/redondo (circulo y rectangulo 1:1).
     */
    public static void resizeCorner(Shape s, int idx, float px, float py, boolean lock) {
        float[] cs = corners(s);
        int o = (idx + 2) % 4;
        float fx = cs[o * 2], fy = cs[o * 2 + 1];
        float c = (float) Math.cos(s.rot), n = (float) Math.sin(s.rot);
        float dx = px - fx, dy = py - fy;
        float lx = dx * c + dy * n, ly = -dx * n + dy * c;   // en el marco girado
        // la esquina que se arrastra queda del mismo lado que antes (no se da vuelta)
        float sx = (idx == 1 || idx == 2) ? 1f : -1f, sy = (idx == 2 || idx == 3) ? 1f : -1f;
        float ax = Math.max(2f, lx * sx), ay = Math.max(2f, ly * sy);
        if (lock) {
            float m = Math.max(ax, ay);
            ax = m;
            ay = m;
        }
        lx = ax * sx;
        ly = ay * sy;
        s.hw = ax / 2f;
        s.hh = ay / 2f;
        s.cx = fx + (lx / 2f) * c - (ly / 2f) * n;
        s.cy = fy + (lx / 2f) * n + (ly / 2f) * c;
    }

    /**
     * Arrastrar el punto del medio de un lado (0 arriba, 1 derecha, 2 abajo, 3 izquierda): solo
     * cambia ancho o alto, el lado de enfrente queda quieto.
     */
    public static void resizeSide(Shape s, int side, float px, float py) {
        float[] q = new float[2];
        toLocal(s, px, py, q);
        float l = -s.hw, r = s.hw, t = -s.hh, b = s.hh;
        if (side == 1) r = Math.max(l + 2f, q[0]);
        else if (side == 3) l = Math.min(r - 2f, q[0]);
        else if (side == 0) t = Math.min(b - 2f, q[1]);
        else b = Math.max(t + 2f, q[1]);
        float ox = (l + r) / 2f, oy = (t + b) / 2f;
        float c = (float) Math.cos(s.rot), n = (float) Math.sin(s.rot);
        s.cx += ox * c - oy * n;
        s.cy += ox * n + oy * c;
        s.hw = (r - l) / 2f;
        s.hh = (b - t) / 2f;
    }

    /**
     * Cambiar el tipo de una figura ya puesta sin perder su lugar ni su tamano
     * (por ejemplo de rectangulo a elipse, o de linea a flecha).
     */
    public static void convert(Shape s, int type, Style st) {
        if (s.type == type) return;
        boolean wasSeg = s.isSegment();
        boolean seg = type == LINE || type == ARROW;
        if (wasSeg && !seg) {
            s.cx = (s.x0 + s.x1) / 2f;
            s.cy = (s.y0 + s.y1) / 2f;
            s.hw = Math.max(8f, Math.abs(s.x1 - s.x0) / 2f);
            s.hh = Math.max(8f, Math.abs(s.y1 - s.y0) / 2f);
            s.rot = 0f;
        } else if (!wasSeg && seg) {
            float[] q = new float[2];
            toWorld(s, -s.hw, s.hh, q);
            s.x0 = q[0]; s.y0 = q[1];
            toWorld(s, s.hw, -s.hh, q);
            s.x1 = q[0]; s.y1 = q[1];
        }
        s.type = type;
        if (type == CIRCLE || (type == RECT && st != null && st.square)) {
            float m = Math.max(s.hw, s.hh);
            s.hw = m;
            s.hh = m;
        }
        if (type == BUBBLE) {
            float[] q = new float[2];
            toWorld(s, -s.hw * 0.55f, s.hh * 1.6f, q);
            s.tx = q[0];
            s.ty = q[1];
        }
    }

    /**
     * Girar con el punto de arriba: el angulo sigue al dedo. Cerca de 0/45/90... grados se
     * engancha (3 grados) para dejar la figura derecha facilmente.
     */
    public static void rotateTo(Shape s, float px, float py) {
        float a = (float) Math.atan2(py - s.cy, px - s.cx) + (float) (Math.PI / 2);
        float step = (float) (Math.PI / 4);
        float near = Math.round(a / step) * step;
        if (Math.abs(a - near) < Math.toRadians(3)) a = near;
        s.rot = a;
    }

    /** Mover: desde la copia "from" (al empezar el gesto) mas el desplazamiento. */
    public static void moveFrom(Shape s, Shape from, float dx, float dy) {
        s.cx = from.cx + dx; s.cy = from.cy + dy;
        s.x0 = from.x0 + dx; s.y0 = from.y0 + dy;
        s.x1 = from.x1 + dx; s.y1 = from.y1 + dy;
        s.tx = from.tx + dx; s.ty = from.ty + dy;
    }

    /** El punto (imagen) esta dentro de la figura o muy cerca (margen en px de imagen). */
    public static boolean hit(Shape s, float x, float y, float margin) {
        if (s.isSegment()) return distSeg(x, y, s.x0, s.y0, s.x1, s.y1) <= margin;
        float[] q = new float[2];
        toLocal(s, x, y, q);
        return Math.abs(q[0]) <= s.hw + margin && Math.abs(q[1]) <= s.hh + margin;
    }

    public static float distSeg(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay;
        float l2 = dx * dx + dy * dy;
        float t = l2 <= 0f ? 0f : Math.max(0f, Math.min(1f, ((px - ax) * dx + (py - ay) * dy) / l2));
        return (float) Math.hypot(px - (ax + dx * t), py - (ay + dy * t));
    }

    // ------------------------------------------------------------------ contorno

    public static Outline outline(Shape s, Style st) {
        switch (s.type) {
            case LINE:
                return new Outline(new float[][]{{s.x0, s.y0, s.x1, s.y1}}, new boolean[]{false}, false);
            case ARROW:
                return st != null && st.thin ? thinArrow(s, st) : thickArrow(s, st);
            case RECT: {
                return closed(world(s, new float[]{-s.hw, -s.hh, s.hw, -s.hh, s.hw, s.hh, -s.hw, s.hh}));
            }
            case CIRCLE:
            case ELLIPSE:
                return closed(world(s, ellipse(s.hw, s.hh, 0f, (float) (Math.PI * 2), true)));
            case POLYGON: {
                int n = Math.max(3, Math.min(32, st == null ? 6 : st.sides));
                float[] p = new float[n * 2];
                for (int i = 0; i < n; i++) {
                    double a = -Math.PI / 2 + Math.PI * 2 * i / n;
                    p[i * 2] = (float) (Math.cos(a) * s.hw);
                    p[i * 2 + 1] = (float) (Math.sin(a) * s.hh);
                }
                return closed(world(s, p));
            }
            case RRECT:
                return closed(world(s, roundRect(s.hw, s.hh, st == null ? 30f : st.corner)));
            case BUBBLE:
                return closed(world(s, bubble(s)));
            default:
                return new Outline(new float[0][], new boolean[0], false);
        }
    }

    private static Outline closed(float[] p) {
        return new Outline(new float[][]{p}, new boolean[]{true}, true);
    }

    private static float[] world(Shape s, float[] local) {
        float[] r = new float[local.length], q = new float[2];
        for (int i = 0; i + 1 < local.length; i += 2) {
            toWorld(s, local[i], local[i + 1], q);
            r[i] = q[0];
            r[i + 1] = q[1];
        }
        return r;
    }

    /** Puntos de una elipse (local) entre los angulos a0 y a1 (parametricos). */
    private static float[] ellipse(float rx, float ry, float a0, float a1, boolean full) {
        float per = (float) (Math.PI * (3 * (rx + ry) - Math.sqrt((3 * rx + ry) * (rx + 3 * ry))));
        float frac = Math.abs(a1 - a0) / (float) (Math.PI * 2);
        int n = Math.max(full ? 32 : 4, Math.min(1440, (int) Math.ceil(per * frac / 2.5f)));
        int cnt = full ? n : n + 1;
        float[] p = new float[cnt * 2];
        for (int i = 0; i < cnt; i++) {
            double a = a0 + (a1 - a0) * i / n;
            p[i * 2] = (float) (Math.cos(a) * rx);
            p[i * 2 + 1] = (float) (Math.sin(a) * ry);
        }
        return p;
    }

    private static float[] roundRect(float hw, float hh, float cornerPct) {
        float r = Math.max(0f, Math.min(1f, cornerPct / 100f)) * Math.min(hw, hh);
        if (r < 0.5f) return new float[]{-hw, -hh, hw, -hh, hw, hh, -hw, hh};
        int seg = Math.max(4, Math.min(90, (int) Math.ceil(r * Math.PI / 2 / 2.5f)));
        float[] p = new float[4 * (seg + 1) * 2];
        float[][] c = {{hw - r, -hh + r, -90}, {hw - r, hh - r, 0}, {-hw + r, hh - r, 90}, {-hw + r, -hh + r, 180}};
        int k = 0;
        for (float[] cc : c) {
            for (int i = 0; i <= seg; i++) {
                double a = Math.toRadians(cc[2] + 90.0 * i / seg);
                p[k++] = cc[0] + (float) Math.cos(a) * r;
                p[k++] = cc[1] + (float) Math.sin(a) * r;
            }
        }
        return p;
    }

    /** Globo: elipse con la cola hasta (tx,ty). Si la punta queda dentro, sin cola. */
    private static float[] bubble(Shape s) {
        float[] t = new float[2];
        toLocal(s, s.tx, s.ty, t);
        float ex = t[0] / Math.max(1f, s.hw), ey = t[1] / Math.max(1f, s.hh);
        if (ex * ex + ey * ey <= 1.02f) return ellipse(s.hw, s.hh, 0f, (float) (Math.PI * 2), true);
        float th = (float) Math.atan2(ey, ex);
        float d = 0.24f;
        float[] arc = ellipse(s.hw, s.hh, th + d, th + (float) (Math.PI * 2) - d, false);
        float[] p = new float[arc.length + 2];
        System.arraycopy(arc, 0, p, 0, arc.length);
        p[arc.length] = t[0];
        p[arc.length + 1] = t[1];
        return p;
    }

    private static Outline thickArrow(Shape s, Style st) {
        float ax = s.x0, ay = s.y0, bx = s.x1, by = s.y1;
        float L = (float) Math.hypot(bx - ax, by - ay);
        if (L < 1f) return new Outline(new float[0][], new boolean[0], false);
        float ux = (bx - ax) / L, uy = (by - ay) / L, nx = -uy, ny = ux;
        float w = Math.max(2f, st == null ? 24f : st.arrowW);
        int heads = st == null ? 1 : st.heads;
        boolean hEnd = (heads & 1) != 0, hStart = (heads & 2) != 0;
        int nh = (hEnd ? 1 : 0) + (hStart ? 1 : 0);
        float hl = Math.min(w * 2.2f, L * (nh == 2 ? 0.45f : 0.7f));
        float hw = w * 1.4f, bw = w / 2f;
        float sx = hStart ? ax + ux * hl : ax, sy = hStart ? ay + uy * hl : ay;
        float ex = hEnd ? bx - ux * hl : bx, ey = hEnd ? by - uy * hl : by;
        float[] p = new float[20];
        int k = 0;
        if (hStart) { p[k++] = ax; p[k++] = ay; p[k++] = sx + nx * hw; p[k++] = sy + ny * hw; }
        p[k++] = sx + nx * bw; p[k++] = sy + ny * bw;
        p[k++] = ex + nx * bw; p[k++] = ey + ny * bw;
        if (hEnd) { p[k++] = ex + nx * hw; p[k++] = ey + ny * hw; p[k++] = bx; p[k++] = by; p[k++] = ex - nx * hw; p[k++] = ey - ny * hw; }
        p[k++] = ex - nx * bw; p[k++] = ey - ny * bw;
        p[k++] = sx - nx * bw; p[k++] = sy - ny * bw;
        if (hStart) { p[k++] = sx - nx * hw; p[k++] = sy - ny * hw; }
        float[] r = new float[k];
        System.arraycopy(p, 0, r, 0, k);
        return closed(r);
    }

    private static Outline thinArrow(Shape s, Style st) {
        float ax = s.x0, ay = s.y0, bx = s.x1, by = s.y1;
        float L = (float) Math.hypot(bx - ax, by - ay);
        if (L < 1f) return new Outline(new float[][]{{ax, ay, bx, by}}, new boolean[]{false}, false);
        float ux = (bx - ax) / L, uy = (by - ay) / L, nx = -uy, ny = ux;
        float sw = st == null ? 6f : st.strokeW;
        float hl = Math.min(L * 0.45f, Math.max(sw * 4f, L * 0.14f));
        float hw = hl * 0.62f;
        int heads = st == null ? 1 : st.heads;
        java.util.ArrayList<float[]> polys = new java.util.ArrayList<float[]>();
        polys.add(new float[]{ax, ay, bx, by});
        if ((heads & 1) != 0) polys.add(new float[]{bx - ux * hl + nx * hw, by - uy * hl + ny * hw, bx, by,
                bx - ux * hl - nx * hw, by - uy * hl - ny * hw});
        if ((heads & 2) != 0) polys.add(new float[]{ax + ux * hl + nx * hw, ay + uy * hl + ny * hw, ax, ay,
                ax + ux * hl - nx * hw, ay + uy * hl - ny * hw});
        boolean[] c = new boolean[polys.size()];
        return new Outline(polys.toArray(new float[0][]), c, false);
    }

    /** Esquinas en punta (rectangulo, poligono, flecha gruesa); el resto con borde redondo. */
    public static boolean sharpCorners(Shape s, Style st) {
        return s.type == RECT || s.type == POLYGON || (s.type == ARROW && (st == null || !st.thin));
    }

    /** Caja que contiene todo el contorno: {izq, arriba, der, abajo}. */
    public static float[] bounds(Outline o) {
        float l = Float.MAX_VALUE, t = Float.MAX_VALUE, r = -Float.MAX_VALUE, b = -Float.MAX_VALUE;
        for (float[] p : o.polys) {
            for (int i = 0; i + 1 < p.length; i += 2) {
                l = Math.min(l, p[i]); r = Math.max(r, p[i]);
                t = Math.min(t, p[i + 1]); b = Math.max(b, p[i + 1]);
            }
        }
        return new float[]{l, t, r, b};
    }
}
