package com.pacco.animecut.core;

import java.util.ArrayList;
import java.util.List;

/**
 * v8.32: dibujo ORIGINAL estilo anime/manhwa para las animaciones de ayuda (personaje propio,
 * sin copiar a nadie). Java puro: una "lista de dibujo" en coordenadas 0..1 que la app pinta con
 * Canvas (ToolArt) y las pruebas con Java2D (para ver como queda sin telefono).
 *
 * v8.69 Personaje: Zeta Pintor, el zorrito pintor de la app (cuerpo entero, manos con dedos).
 */
public final class ChibiArt {

    /** Una operacion: camino (MOVE/LINE/CUBIC/CLOSE) relleno o con linea. */
    public static final class Op {
        public final float[] path;      // codigos y coordenadas
        public final int color;
        public final float stroke;      // 0 = relleno; > 0 = ancho de linea (fraccion de la altura)
        public final int part;          // PART_* (para recortar: pelo, cara, cuerpo)
        Op(float[] path, int color, float stroke, int part) { this.path = path; this.color = color; this.stroke = stroke; this.part = part; }
    }

    public static final float MOVE = 0, LINE = 1, CUBIC = 2, CLOSE = 3;
    public static final int PART_BODY = 1, PART_HEAD = 2, PART_HAIR = 3, PART_FX = 4, PART_ARM = 5, PART_TAIL = 6;

    static final int INK = 0xFF15131A, SKIN = 0xFFFBE0CF, SKIN_SH = 0xFFEDBFA8, BLUSH = 0x66FF8A8A,
            HAIR = 0xFF2A2F4A, HAIR_SH = 0xFF1B1E33, HAIR_HI = 0xFF5D6A9E, EYE_W = 0xFFFFFFFF,
            IRIS = 0xFF3D7BE0, IRIS_D = 0xFF1E3F8C, JACKET = 0xFF2E3A59, JACKET_SH = 0xFF222B44, MOUTH = 0xFF9E3B3B;

    private ChibiArt() { }

    private static final class B {
        final List<Float> f = new ArrayList<>();
        B m(float x, float y) { f.add(MOVE); f.add(x); f.add(y); return this; }
        B l(float x, float y) { f.add(LINE); f.add(x); f.add(y); return this; }
        B c(float x1, float y1, float x2, float y2, float x, float y) { f.add(CUBIC); f.add(x1); f.add(y1); f.add(x2); f.add(y2); f.add(x); f.add(y); return this; }
        B z() { f.add(CLOSE); return this; }
        float[] a() { float[] r = new float[f.size()]; for (int i = 0; i < r.length; i++) r[i] = f.get(i); return r; }
    }

    static B ellipse(float cx, float cy, float rx, float ry) {
        float k = 0.5523f;
        return new B().m(cx + rx, cy)
                .c(cx + rx, cy + ry * k, cx + rx * k, cy + ry, cx, cy + ry)
                .c(cx - rx * k, cy + ry, cx - rx, cy + ry * k, cx - rx, cy)
                .c(cx - rx, cy - ry * k, cx - rx * k, cy - ry, cx, cy - ry)
                .c(cx + rx * k, cy - ry, cx + rx, cy - ry * k, cx + rx, cy).z();
    }

    /**
     * v8.69: el personaje de las animaciones es ZETA PINTOR (el zorrito de la app): boina, bufanda,
     * mandil, paleta en una mano y pincel en la otra. Cuerpo entero y por partes, para poder
     * moverlo: cola, cuerpo, brazo del pincel, cabeza y boina. shirt = color del mandil.
     */
    public static List<Op> character(int shirt) {
        return zeta(shirt);
    }

    /** Orden de dibujo de las partes (de atras hacia adelante). */
    public static final int[] ORDER = {PART_TAIL, PART_BODY, PART_ARM, PART_HEAD, PART_HAIR};
    /** Hombro del brazo del pincel (para girarlo en la Marioneta), en 0..1. */
    public static final float SHOULDER_X = 0.5889f, SHOULDER_Y = 0.5689f;

    // Generado desde el diseno Zeta Pintor (formas propias, sin copiar a nadie).
    static List<Op> zeta(int apron) {
        List<Op> o = new ArrayList<>();
        o.add(new Op(new float[]{0, 0.5978f, 0.8000f, 2, 0.7756f, 0.8533f, 0.9000f, 0.7111f, 0.8556f, 0.5244f, 2, 0.8378f, 0.4356f, 0.7756f, 0.3911f, 0.7311f, 0.4267f, 2, 0.7844f, 0.5244f, 0.7578f, 0.6667f, 0.6067f, 0.7111f, 3}, 0xFFF28A3A, 0.00000f, PART_TAIL));
        o.add(new Op(new float[]{0, 0.5978f, 0.8000f, 2, 0.7756f, 0.8533f, 0.9000f, 0.7111f, 0.8556f, 0.5244f, 2, 0.8378f, 0.4356f, 0.7756f, 0.3911f, 0.7311f, 0.4267f, 2, 0.7844f, 0.5244f, 0.7578f, 0.6667f, 0.6067f, 0.7111f, 3}, 0xFF17151C, 0.00800f, PART_TAIL));
        o.add(new Op(new float[]{0, 0.8556f, 0.5244f, 2, 0.8378f, 0.4356f, 0.7756f, 0.3911f, 0.7311f, 0.4267f, 2, 0.7533f, 0.4622f, 0.7622f, 0.4933f, 0.7622f, 0.5289f, 1, 0.7933f, 0.5067f, 1, 0.8111f, 0.5378f, 3}, 0xFFFFF6EA, 0.00000f, PART_TAIL));
        o.add(new Op(new float[]{0, 0.8556f, 0.5244f, 2, 0.8378f, 0.4356f, 0.7756f, 0.3911f, 0.7311f, 0.4267f, 2, 0.7533f, 0.4622f, 0.7622f, 0.4933f, 0.7622f, 0.5289f, 1, 0.7933f, 0.5067f, 1, 0.8111f, 0.5378f, 3}, 0xFF17151C, 0.00711f, PART_TAIL));
        o.add(new Op(new float[]{0, 0.7222f, 0.7289f, 2, 0.7667f, 0.7022f, 0.8022f, 0.6578f, 0.8200f, 0.6044f}, 0x5917151C, 0.00578f, PART_TAIL));
        o.add(new Op(new float[]{0, 0.4200f, 0.8000f, 1, 0.4156f, 0.8978f, 1, 0.4822f, 0.8978f, 1, 0.4867f, 0.8000f, 3}, 0xFFF28A3A, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4200f, 0.8000f, 1, 0.4156f, 0.8978f, 1, 0.4822f, 0.8978f, 1, 0.4867f, 0.8000f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5133f, 0.8000f, 1, 0.5178f, 0.8978f, 1, 0.5844f, 0.8978f, 1, 0.5800f, 0.8000f, 3}, 0xFFF28A3A, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5133f, 0.8000f, 1, 0.5178f, 0.8978f, 1, 0.5844f, 0.8978f, 1, 0.5800f, 0.8000f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3933f, 0.9467f, 2, 0.3933f, 0.8978f, 0.4200f, 0.8800f, 0.4467f, 0.8800f, 2, 0.4778f, 0.8800f, 0.5000f, 0.9022f, 0.5000f, 0.9467f, 2, 0.4644f, 0.9600f, 0.4289f, 0.9600f, 0.3933f, 0.9467f, 3}, 0xFF3A2626, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3933f, 0.9467f, 2, 0.3933f, 0.8978f, 0.4200f, 0.8800f, 0.4467f, 0.8800f, 2, 0.4778f, 0.8800f, 0.5000f, 0.9022f, 0.5000f, 0.9467f, 2, 0.4644f, 0.9600f, 0.4289f, 0.9600f, 0.3933f, 0.9467f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4333f, 0.9244f, 1, 0.4333f, 0.9511f, 0, 0.4644f, 0.9244f, 1, 0.4644f, 0.9511f}, 0xFF7A5A50, 0.00489f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5000f, 0.9467f, 2, 0.5000f, 0.8978f, 0.5267f, 0.8800f, 0.5533f, 0.8800f, 2, 0.5844f, 0.8800f, 0.6067f, 0.9022f, 0.6067f, 0.9467f, 2, 0.5711f, 0.9600f, 0.5356f, 0.9600f, 0.5000f, 0.9467f, 3}, 0xFF3A2626, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5000f, 0.9467f, 2, 0.5000f, 0.8978f, 0.5267f, 0.8800f, 0.5533f, 0.8800f, 2, 0.5844f, 0.8800f, 0.6067f, 0.9022f, 0.6067f, 0.9467f, 2, 0.5711f, 0.9600f, 0.5356f, 0.9600f, 0.5000f, 0.9467f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5400f, 0.9244f, 1, 0.5400f, 0.9511f, 0, 0.5711f, 0.9244f, 1, 0.5711f, 0.9511f}, 0xFF7A5A50, 0.00489f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3756f, 0.8178f, 2, 0.3400f, 0.6933f, 0.3844f, 0.5156f, 0.5000f, 0.5067f, 2, 0.6156f, 0.5156f, 0.6600f, 0.6933f, 0.6244f, 0.8178f, 2, 0.5711f, 0.8444f, 0.4289f, 0.8444f, 0.3756f, 0.8178f, 3}, 0xFFF28A3A, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3756f, 0.8178f, 2, 0.3400f, 0.6933f, 0.3844f, 0.5156f, 0.5000f, 0.5067f, 2, 0.6156f, 0.5156f, 0.6600f, 0.6933f, 0.6244f, 0.8178f, 2, 0.5711f, 0.8444f, 0.4289f, 0.8444f, 0.3756f, 0.8178f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4378f, 0.8089f, 2, 0.4200f, 0.7022f, 0.4556f, 0.5956f, 0.5000f, 0.5956f, 2, 0.5444f, 0.5956f, 0.5800f, 0.7022f, 0.5622f, 0.8089f, 2, 0.5356f, 0.8222f, 0.4644f, 0.8222f, 0.4378f, 0.8089f, 3}, 0xFFFFF6EA, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4378f, 0.8089f, 2, 0.4200f, 0.7022f, 0.4556f, 0.5956f, 0.5000f, 0.5956f, 2, 0.5444f, 0.5956f, 0.5800f, 0.7022f, 0.5622f, 0.8089f, 2, 0.5356f, 0.8222f, 0.4644f, 0.8222f, 0.4378f, 0.8089f, 3}, 0xFF17151C, 0.00622f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4111f, 0.6133f, 1, 0.5889f, 0.6133f, 1, 0.6067f, 0.8000f, 2, 0.5444f, 0.8267f, 0.4556f, 0.8267f, 0.3933f, 0.8000f, 3}, apron, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4111f, 0.6133f, 1, 0.5889f, 0.6133f, 1, 0.6067f, 0.8000f, 2, 0.5444f, 0.8267f, 0.4556f, 0.8267f, 0.3933f, 0.8000f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4467f, 0.6933f, 1, 0.5533f, 0.6933f, 1, 0.5489f, 0.7556f, 1, 0.4511f, 0.7556f, 3}, 0x22000000, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4467f, 0.6933f, 1, 0.5533f, 0.6933f, 1, 0.5489f, 0.7556f, 1, 0.4511f, 0.7556f, 3}, 0xFF17151C, 0.00622f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5000f, 0.6933f, 1, 0.5000f, 0.7556f}, 0xFF17151C, 0.00533f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4644f, 0.6933f, 1, 0.4556f, 0.6400f, 1, 0.4733f, 0.6356f, 1, 0.4778f, 0.6933f, 3}, 0xFF8A5A34, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4644f, 0.6933f, 1, 0.4556f, 0.6400f, 1, 0.4733f, 0.6356f, 1, 0.4778f, 0.6933f, 3}, 0xFF17151C, 0.00489f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5222f, 0.6933f, 1, 0.5311f, 0.6311f, 1, 0.5489f, 0.6356f, 1, 0.5356f, 0.6933f, 3}, 0xFFFFCF3F, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5222f, 0.6933f, 1, 0.5311f, 0.6311f, 1, 0.5489f, 0.6356f, 1, 0.5356f, 0.6933f, 3}, 0xFF17151C, 0.00489f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4200f, 0.6133f, 2, 0.4289f, 0.5689f, 0.4556f, 0.5422f, 0.4733f, 0.5333f, 0, 0.5800f, 0.6133f, 2, 0.5711f, 0.5689f, 0.5444f, 0.5422f, 0.5267f, 0.5333f}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4387f, 0.7733f, 2, 0.4387f, 0.7787f, 0.4343f, 0.7831f, 0.4289f, 0.7831f, 2, 0.4235f, 0.7831f, 0.4191f, 0.7787f, 0.4191f, 0.7733f, 2, 0.4191f, 0.7679f, 0.4235f, 0.7636f, 0.4289f, 0.7636f, 2, 0.4343f, 0.7636f, 0.4387f, 0.7679f, 0.4387f, 0.7733f, 3}, 0xFFFF5F84, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5791f, 0.6578f, 2, 0.5791f, 0.6622f, 0.5755f, 0.6658f, 0.5711f, 0.6658f, 2, 0.5667f, 0.6658f, 0.5631f, 0.6622f, 0.5631f, 0.6578f, 2, 0.5631f, 0.6534f, 0.5667f, 0.6498f, 0.5711f, 0.6498f, 2, 0.5755f, 0.6498f, 0.5791f, 0.6534f, 0.5791f, 0.6578f, 3}, 0xFFFFCF3F, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4111f, 0.5689f, 2, 0.3667f, 0.6133f, 0.3311f, 0.6400f, 0.2956f, 0.6578f}, 0xFF17151C, 0.06489f, PART_BODY));
        o.add(new Op(new float[]{0, 0.4111f, 0.5689f, 2, 0.3667f, 0.6133f, 0.3311f, 0.6400f, 0.2956f, 0.6578f}, 0xFFF28A3A, 0.04889f, PART_BODY));
        o.add(new Op(new float[]{0, 0.1178f, 0.6667f, 2, 0.1089f, 0.5778f, 0.2156f, 0.5333f, 0.3044f, 0.5600f, 2, 0.3667f, 0.5778f, 0.3756f, 0.6400f, 0.3311f, 0.6578f, 2, 0.3000f, 0.6711f, 0.3089f, 0.7067f, 0.3400f, 0.7200f, 2, 0.3311f, 0.7822f, 0.1622f, 0.7911f, 0.1178f, 0.6667f, 3}, 0xFFECC78D, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.1178f, 0.6667f, 2, 0.1089f, 0.5778f, 0.2156f, 0.5333f, 0.3044f, 0.5600f, 2, 0.3667f, 0.5778f, 0.3756f, 0.6400f, 0.3311f, 0.6578f, 2, 0.3000f, 0.6711f, 0.3089f, 0.7067f, 0.3400f, 0.7200f, 2, 0.3311f, 0.7822f, 0.1622f, 0.7911f, 0.1178f, 0.6667f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3044f, 0.6889f, 2, 0.3044f, 0.6967f, 0.2965f, 0.7031f, 0.2867f, 0.7031f, 2, 0.2768f, 0.7031f, 0.2689f, 0.6967f, 0.2689f, 0.6889f, 2, 0.2689f, 0.6810f, 0.2768f, 0.6747f, 0.2867f, 0.6747f, 2, 0.2965f, 0.6747f, 0.3044f, 0.6810f, 0.3044f, 0.6889f, 3}, 0xFFC99A5C, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3044f, 0.6889f, 2, 0.3044f, 0.6967f, 0.2965f, 0.7031f, 0.2867f, 0.7031f, 2, 0.2768f, 0.7031f, 0.2689f, 0.6967f, 0.2689f, 0.6889f, 2, 0.2689f, 0.6810f, 0.2768f, 0.6747f, 0.2867f, 0.6747f, 2, 0.2965f, 0.6747f, 0.3044f, 0.6810f, 0.3044f, 0.6889f, 3}, 0xFF17151C, 0.00533f, PART_BODY));
        o.add(new Op(new float[]{0, 0.1933f, 0.6133f, 2, 0.1933f, 0.6227f, 0.1834f, 0.6302f, 0.1711f, 0.6302f, 2, 0.1588f, 0.6302f, 0.1489f, 0.6227f, 0.1489f, 0.6133f, 2, 0.1489f, 0.6040f, 0.1588f, 0.5964f, 0.1711f, 0.5964f, 2, 0.1834f, 0.5964f, 0.1933f, 0.6040f, 0.1933f, 0.6133f, 3}, 0xFFFF5F84, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.1933f, 0.6133f, 2, 0.1933f, 0.6227f, 0.1834f, 0.6302f, 0.1711f, 0.6302f, 2, 0.1588f, 0.6302f, 0.1489f, 0.6227f, 0.1489f, 0.6133f, 2, 0.1489f, 0.6040f, 0.1588f, 0.5964f, 0.1711f, 0.5964f, 2, 0.1834f, 0.5964f, 0.1933f, 0.6040f, 0.1933f, 0.6133f, 3}, 0xFF17151C, 0.00533f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2467f, 0.5822f, 2, 0.2467f, 0.5915f, 0.2367f, 0.5991f, 0.2244f, 0.5991f, 2, 0.2122f, 0.5991f, 0.2022f, 0.5915f, 0.2022f, 0.5822f, 2, 0.2022f, 0.5729f, 0.2122f, 0.5653f, 0.2244f, 0.5653f, 2, 0.2367f, 0.5653f, 0.2467f, 0.5729f, 0.2467f, 0.5822f, 3}, 0xFFFFCF3F, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2467f, 0.5822f, 2, 0.2467f, 0.5915f, 0.2367f, 0.5991f, 0.2244f, 0.5991f, 2, 0.2122f, 0.5991f, 0.2022f, 0.5915f, 0.2022f, 0.5822f, 2, 0.2022f, 0.5729f, 0.2122f, 0.5653f, 0.2244f, 0.5653f, 2, 0.2367f, 0.5653f, 0.2467f, 0.5729f, 0.2467f, 0.5822f, 3}, 0xFF17151C, 0.00533f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3044f, 0.5911f, 2, 0.3044f, 0.6004f, 0.2945f, 0.6080f, 0.2822f, 0.6080f, 2, 0.2699f, 0.6080f, 0.2600f, 0.6004f, 0.2600f, 0.5911f, 2, 0.2600f, 0.5818f, 0.2699f, 0.5742f, 0.2822f, 0.5742f, 2, 0.2945f, 0.5742f, 0.3044f, 0.5818f, 0.3044f, 0.5911f, 3}, 0xFF3F9BFF, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3044f, 0.5911f, 2, 0.3044f, 0.6004f, 0.2945f, 0.6080f, 0.2822f, 0.6080f, 2, 0.2699f, 0.6080f, 0.2600f, 0.6004f, 0.2600f, 0.5911f, 2, 0.2600f, 0.5818f, 0.2699f, 0.5742f, 0.2822f, 0.5742f, 2, 0.2945f, 0.5742f, 0.3044f, 0.5818f, 0.3044f, 0.5911f, 3}, 0xFF17151C, 0.00533f, PART_BODY));
        o.add(new Op(new float[]{0, 0.1889f, 0.6844f, 2, 0.1889f, 0.6938f, 0.1789f, 0.7013f, 0.1667f, 0.7013f, 2, 0.1544f, 0.7013f, 0.1444f, 0.6938f, 0.1444f, 0.6844f, 2, 0.1444f, 0.6751f, 0.1544f, 0.6676f, 0.1667f, 0.6676f, 2, 0.1789f, 0.6676f, 0.1889f, 0.6751f, 0.1889f, 0.6844f, 3}, 0xFF4CC38A, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.1889f, 0.6844f, 2, 0.1889f, 0.6938f, 0.1789f, 0.7013f, 0.1667f, 0.7013f, 2, 0.1544f, 0.7013f, 0.1444f, 0.6938f, 0.1444f, 0.6844f, 2, 0.1444f, 0.6751f, 0.1544f, 0.6676f, 0.1667f, 0.6676f, 2, 0.1789f, 0.6676f, 0.1889f, 0.6751f, 0.1889f, 0.6844f, 3}, 0xFF17151C, 0.00533f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2378f, 0.7289f, 2, 0.2378f, 0.7382f, 0.2278f, 0.7458f, 0.2156f, 0.7458f, 2, 0.2033f, 0.7458f, 0.1933f, 0.7382f, 0.1933f, 0.7289f, 2, 0.1933f, 0.7196f, 0.2033f, 0.7120f, 0.2156f, 0.7120f, 2, 0.2278f, 0.7120f, 0.2378f, 0.7196f, 0.2378f, 0.7289f, 3}, 0xFF9A6CFF, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2378f, 0.7289f, 2, 0.2378f, 0.7382f, 0.2278f, 0.7458f, 0.2156f, 0.7458f, 2, 0.2033f, 0.7458f, 0.1933f, 0.7382f, 0.1933f, 0.7289f, 2, 0.1933f, 0.7196f, 0.2033f, 0.7120f, 0.2156f, 0.7120f, 2, 0.2278f, 0.7120f, 0.2378f, 0.7196f, 0.2378f, 0.7289f, 3}, 0xFF17151C, 0.00533f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2619f, 0.6360f, 2, 0.2543f, 0.6151f, 0.3211f, 0.5908f, 0.3344f, 0.6143f, 2, 0.3504f, 0.6322f, 0.3568f, 0.6629f, 0.3348f, 0.6804f, 2, 0.3128f, 0.6979f, 0.2790f, 0.6960f, 0.2699f, 0.6709f, 3}, 0xFF3A2626, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2619f, 0.6360f, 2, 0.2543f, 0.6151f, 0.3211f, 0.5908f, 0.3344f, 0.6143f, 2, 0.3504f, 0.6322f, 0.3568f, 0.6629f, 0.3348f, 0.6804f, 2, 0.3128f, 0.6979f, 0.2790f, 0.6960f, 0.2699f, 0.6709f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2782f, 0.6159f, 2, 0.2900f, 0.6352f, 0.2961f, 0.6519f, 0.2965f, 0.6660f, 0, 0.3012f, 0.6075f, 2, 0.3130f, 0.6269f, 0.3191f, 0.6436f, 0.3210f, 0.6618f}, 0xFF8A6A60, 0.00489f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2653f, 0.6584f, 2, 0.2429f, 0.6618f, 0.2479f, 0.6884f, 0.2718f, 0.6891f, 2, 0.2859f, 0.6888f, 0.2896f, 0.6732f, 0.2809f, 0.6622f, 3}, 0xFF3A2626, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.2653f, 0.6584f, 2, 0.2429f, 0.6618f, 0.2479f, 0.6884f, 0.2718f, 0.6891f, 2, 0.2859f, 0.6888f, 0.2896f, 0.6732f, 0.2809f, 0.6622f, 3}, 0xFF17151C, 0.00711f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3844f, 0.4978f, 2, 0.4378f, 0.5422f, 0.5622f, 0.5422f, 0.6156f, 0.4978f, 1, 0.6067f, 0.4667f, 2, 0.5533f, 0.4978f, 0.4467f, 0.4978f, 0.3933f, 0.4667f, 3}, 0xFF3F7FD9, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.3844f, 0.4978f, 2, 0.4378f, 0.5422f, 0.5622f, 0.5422f, 0.6156f, 0.4978f, 1, 0.6067f, 0.4667f, 2, 0.5533f, 0.4978f, 0.4467f, 0.4978f, 0.3933f, 0.4667f, 3}, 0xFF17151C, 0.00800f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5356f, 0.5156f, 1, 0.5889f, 0.6044f, 1, 0.5356f, 0.5956f, 3}, 0xFF3F7FD9, 0.00000f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5356f, 0.5156f, 1, 0.5889f, 0.6044f, 1, 0.5356f, 0.5956f, 3}, 0xFF17151C, 0.00711f, PART_BODY));
        o.add(new Op(new float[]{0, 0.5889f, 0.5689f, 2, 0.6511f, 0.5422f, 0.6867f, 0.4978f, 0.7133f, 0.4356f}, 0xFF17151C, 0.06489f, PART_ARM));
        o.add(new Op(new float[]{0, 0.5889f, 0.5689f, 2, 0.6511f, 0.5422f, 0.6867f, 0.4978f, 0.7133f, 0.4356f}, 0xFFF28A3A, 0.04889f, PART_ARM));
        o.add(new Op(new float[]{0, 0.6422f, 0.5511f, 1, 0.7933f, 0.2400f, 1, 0.8156f, 0.2533f, 1, 0.6689f, 0.5644f, 3}, 0xFF8A5A34, 0.00000f, PART_ARM));
        o.add(new Op(new float[]{0, 0.6422f, 0.5511f, 1, 0.7933f, 0.2400f, 1, 0.8156f, 0.2533f, 1, 0.6689f, 0.5644f, 3}, 0xFF17151C, 0.00622f, PART_ARM));
        o.add(new Op(new float[]{0, 0.7933f, 0.2400f, 1, 0.8111f, 0.2044f, 1, 0.8378f, 0.2178f, 1, 0.8156f, 0.2533f, 3}, 0xFFC8CCD6, 0.00000f, PART_ARM));
        o.add(new Op(new float[]{0, 0.7933f, 0.2400f, 1, 0.8111f, 0.2044f, 1, 0.8378f, 0.2178f, 1, 0.8156f, 0.2533f, 3}, 0xFF17151C, 0.00578f, PART_ARM));
        o.add(new Op(new float[]{0, 0.8111f, 0.2044f, 2, 0.8156f, 0.1600f, 0.8556f, 0.1333f, 0.8733f, 0.1511f, 2, 0.8822f, 0.1778f, 0.8644f, 0.2044f, 0.8378f, 0.2178f, 3}, 0xFFFF5F84, 0.00000f, PART_ARM));
        o.add(new Op(new float[]{0, 0.8111f, 0.2044f, 2, 0.8156f, 0.1600f, 0.8556f, 0.1333f, 0.8733f, 0.1511f, 2, 0.8822f, 0.1778f, 0.8644f, 0.2044f, 0.8378f, 0.2178f, 3}, 0xFF17151C, 0.00622f, PART_ARM));
        o.add(new Op(new float[]{0, 0.7013f, 0.3786f, 2, 0.7107f, 0.3584f, 0.7751f, 0.3885f, 0.7679f, 0.4145f, 2, 0.7665f, 0.4384f, 0.7494f, 0.4648f, 0.7214f, 0.4615f, 2, 0.6935f, 0.4583f, 0.6709f, 0.4331f, 0.6822f, 0.4089f, 3}, 0xFF3A2626, 0.00000f, PART_ARM));
        o.add(new Op(new float[]{0, 0.7013f, 0.3786f, 2, 0.7107f, 0.3584f, 0.7751f, 0.3885f, 0.7679f, 0.4145f, 2, 0.7665f, 0.4384f, 0.7494f, 0.4648f, 0.7214f, 0.4615f, 2, 0.6935f, 0.4583f, 0.6709f, 0.4331f, 0.6822f, 0.4089f, 3}, 0xFF17151C, 0.00800f, PART_ARM));
        o.add(new Op(new float[]{0, 0.7270f, 0.3759f, 2, 0.7217f, 0.3979f, 0.7142f, 0.4140f, 0.7045f, 0.4242f, 0, 0.7492f, 0.3862f, 2, 0.7438f, 0.4082f, 0.7363f, 0.4244f, 0.7248f, 0.4386f}, 0xFF8A6A60, 0.00489f, PART_ARM));
        o.add(new Op(new float[]{0, 0.6878f, 0.3968f, 2, 0.6696f, 0.3834f, 0.6543f, 0.4057f, 0.6707f, 0.4232f, 2, 0.6809f, 0.4328f, 0.6946f, 0.4245f, 0.6962f, 0.4105f, 3}, 0xFF3A2626, 0.00000f, PART_ARM));
        o.add(new Op(new float[]{0, 0.6878f, 0.3968f, 2, 0.6696f, 0.3834f, 0.6543f, 0.4057f, 0.6707f, 0.4232f, 2, 0.6809f, 0.4328f, 0.6946f, 0.4245f, 0.6962f, 0.4105f, 3}, 0xFF17151C, 0.00711f, PART_ARM));
        o.add(new Op(new float[]{0, 0.3489f, 0.2133f, 1, 0.2956f, 0.0089f, 1, 0.4733f, 0.1422f, 3}, 0xFFF28A3A, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3489f, 0.2133f, 1, 0.2956f, 0.0089f, 1, 0.4733f, 0.1422f, 3}, 0xFF17151C, 0.00800f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.6511f, 0.2133f, 1, 0.7044f, 0.0089f, 1, 0.5267f, 0.1422f, 3}, 0xFFF28A3A, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.6511f, 0.2133f, 1, 0.7044f, 0.0089f, 1, 0.5267f, 0.1422f, 3}, 0xFF17151C, 0.00800f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3578f, 0.1778f, 1, 0.3267f, 0.0622f, 1, 0.4289f, 0.1378f, 3}, 0xFFFFD7B5, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.6422f, 0.1778f, 1, 0.6733f, 0.0622f, 1, 0.5711f, 0.1378f, 3}, 0xFFFFD7B5, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3089f, 0.0578f, 1, 0.2956f, 0.0089f, 1, 0.3489f, 0.0444f, 3}, 0xFF3A2626, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3089f, 0.0578f, 1, 0.2956f, 0.0089f, 1, 0.3489f, 0.0444f, 3}, 0xFF17151C, 0.00622f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.6911f, 0.0578f, 1, 0.7044f, 0.0089f, 1, 0.6511f, 0.0444f, 3}, 0xFF3A2626, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.6911f, 0.0578f, 1, 0.7044f, 0.0089f, 1, 0.6511f, 0.0444f, 3}, 0xFF17151C, 0.00622f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3489f, 0.1244f, 1, 0.3667f, 0.1422f, 0, 0.3400f, 0.0978f, 1, 0.3622f, 0.1156f, 0, 0.6511f, 0.1244f, 1, 0.6333f, 0.1422f, 0, 0.6600f, 0.0978f, 1, 0.6378f, 0.1156f}, 0x7F17151C, 0.00533f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3133f, 0.3111f, 2, 0.3000f, 0.1867f, 0.3933f, 0.1067f, 0.5000f, 0.1067f, 2, 0.6067f, 0.1067f, 0.7000f, 0.1867f, 0.6867f, 0.3111f, 1, 0.7311f, 0.3556f, 1, 0.6822f, 0.3689f, 1, 0.7133f, 0.4178f, 1, 0.6422f, 0.4178f, 2, 0.6067f, 0.4711f, 0.5533f, 0.4889f, 0.5000f, 0.4889f, 2, 0.4467f, 0.4889f, 0.3933f, 0.4711f, 0.3578f, 0.4178f, 1, 0.2867f, 0.4178f, 1, 0.3178f, 0.3689f, 1, 0.2689f, 0.3556f, 3}, 0xFFF28A3A, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3133f, 0.3111f, 2, 0.3000f, 0.1867f, 0.3933f, 0.1067f, 0.5000f, 0.1067f, 2, 0.6067f, 0.1067f, 0.7000f, 0.1867f, 0.6867f, 0.3111f, 1, 0.7311f, 0.3556f, 1, 0.6822f, 0.3689f, 1, 0.7133f, 0.4178f, 1, 0.6422f, 0.4178f, 2, 0.6067f, 0.4711f, 0.5533f, 0.4889f, 0.5000f, 0.4889f, 2, 0.4467f, 0.4889f, 0.3933f, 0.4711f, 0.3578f, 0.4178f, 1, 0.2867f, 0.4178f, 1, 0.3178f, 0.3689f, 1, 0.2689f, 0.3556f, 3}, 0xFF17151C, 0.00800f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.2867f, 0.4178f, 1, 0.3178f, 0.3689f, 1, 0.3489f, 0.3733f, 2, 0.3844f, 0.3378f, 0.4556f, 0.3467f, 0.4822f, 0.3867f, 1, 0.5000f, 0.4089f, 1, 0.5178f, 0.3867f, 2, 0.5444f, 0.3467f, 0.6156f, 0.3378f, 0.6511f, 0.3733f, 1, 0.6822f, 0.3689f, 1, 0.7133f, 0.4178f, 1, 0.6422f, 0.4178f, 2, 0.6067f, 0.4711f, 0.5533f, 0.4889f, 0.5000f, 0.4889f, 2, 0.4467f, 0.4889f, 0.3933f, 0.4711f, 0.3578f, 0.4178f, 3}, 0xFFFFF6EA, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.2867f, 0.4178f, 1, 0.3178f, 0.3689f, 1, 0.2689f, 0.3556f, 0, 0.7133f, 0.4178f, 1, 0.6822f, 0.3689f, 1, 0.7311f, 0.3556f}, 0xFF17151C, 0.00800f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3489f, 0.3733f, 2, 0.3844f, 0.3378f, 0.4556f, 0.3467f, 0.4822f, 0.3867f, 0, 0.5178f, 0.3867f, 2, 0.5444f, 0.3467f, 0.6156f, 0.3378f, 0.6511f, 0.3733f}, 0x5917151C, 0.00533f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4822f, 0.1600f, 1, 0.5000f, 0.1956f, 1, 0.5178f, 0.1600f}, 0x7217151C, 0.00578f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4644f, 0.2978f, 2, 0.4644f, 0.3223f, 0.4485f, 0.3422f, 0.4289f, 0.3422f, 2, 0.4093f, 0.3422f, 0.3933f, 0.3223f, 0.3933f, 0.2978f, 2, 0.3933f, 0.2732f, 0.4093f, 0.2533f, 0.4289f, 0.2533f, 2, 0.4485f, 0.2533f, 0.4644f, 0.2732f, 0.4644f, 0.2978f, 3}, 0xFF17151C, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4004f, 0.3067f, 2, 0.4004f, 0.3238f, 0.4132f, 0.3378f, 0.4289f, 0.3378f, 2, 0.4446f, 0.3378f, 0.4573f, 0.3238f, 0.4573f, 0.3067f, 3}, 0xFF2D8BE0, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4084f, 0.3244f, 2, 0.4084f, 0.3318f, 0.4176f, 0.3378f, 0.4289f, 0.3378f, 2, 0.4402f, 0.3378f, 0.4493f, 0.3318f, 0.4493f, 0.3244f, 3}, 0xFF7CC6FF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4298f, 0.2778f, 2, 0.4298f, 0.2866f, 0.4234f, 0.2938f, 0.4156f, 0.2938f, 2, 0.4077f, 0.2938f, 0.4013f, 0.2866f, 0.4013f, 0.2778f, 2, 0.4013f, 0.2689f, 0.4077f, 0.2618f, 0.4156f, 0.2618f, 2, 0.4234f, 0.2618f, 0.4298f, 0.2689f, 0.4298f, 0.2778f, 3}, 0xFFFFFFFF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4502f, 0.3156f, 2, 0.4502f, 0.3190f, 0.4474f, 0.3218f, 0.4440f, 0.3218f, 2, 0.4406f, 0.3218f, 0.4378f, 0.3190f, 0.4378f, 0.3156f, 2, 0.4378f, 0.3121f, 0.4406f, 0.3093f, 0.4440f, 0.3093f, 2, 0.4474f, 0.3093f, 0.4502f, 0.3121f, 0.4502f, 0.3156f, 3}, 0xFFFFFFFF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.6067f, 0.2978f, 2, 0.6067f, 0.3223f, 0.5907f, 0.3422f, 0.5711f, 0.3422f, 2, 0.5515f, 0.3422f, 0.5356f, 0.3223f, 0.5356f, 0.2978f, 2, 0.5356f, 0.2732f, 0.5515f, 0.2533f, 0.5711f, 0.2533f, 2, 0.5907f, 0.2533f, 0.6067f, 0.2732f, 0.6067f, 0.2978f, 3}, 0xFF17151C, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.5427f, 0.3067f, 2, 0.5427f, 0.3238f, 0.5554f, 0.3378f, 0.5711f, 0.3378f, 2, 0.5868f, 0.3378f, 0.5996f, 0.3238f, 0.5996f, 0.3067f, 3}, 0xFF2D8BE0, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.5507f, 0.3244f, 2, 0.5507f, 0.3318f, 0.5598f, 0.3378f, 0.5711f, 0.3378f, 2, 0.5824f, 0.3378f, 0.5916f, 0.3318f, 0.5916f, 0.3244f, 3}, 0xFF7CC6FF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.5720f, 0.2778f, 2, 0.5720f, 0.2866f, 0.5656f, 0.2938f, 0.5578f, 0.2938f, 2, 0.5499f, 0.2938f, 0.5436f, 0.2866f, 0.5436f, 0.2778f, 2, 0.5436f, 0.2689f, 0.5499f, 0.2618f, 0.5578f, 0.2618f, 2, 0.5656f, 0.2618f, 0.5720f, 0.2689f, 0.5720f, 0.2778f, 3}, 0xFFFFFFFF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.5924f, 0.3156f, 2, 0.5924f, 0.3190f, 0.5897f, 0.3218f, 0.5862f, 0.3218f, 2, 0.5828f, 0.3218f, 0.5800f, 0.3190f, 0.5800f, 0.3156f, 2, 0.5800f, 0.3121f, 0.5828f, 0.3093f, 0.5862f, 0.3093f, 2, 0.5897f, 0.3093f, 0.5924f, 0.3121f, 0.5924f, 0.3156f, 3}, 0xFFFFFFFF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3933f, 0.2311f, 2, 0.4111f, 0.2178f, 0.4378f, 0.2178f, 0.4556f, 0.2267f, 0, 0.5444f, 0.2267f, 2, 0.5622f, 0.2178f, 0.5889f, 0.2178f, 0.6067f, 0.2311f}, 0xFF17151C, 0.00889f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4778f, 0.3867f, 2, 0.4778f, 0.3689f, 0.5222f, 0.3689f, 0.5222f, 0.3867f, 2, 0.5222f, 0.4044f, 0.5000f, 0.4133f, 0.5000f, 0.4133f, 2, 0.5000f, 0.4133f, 0.4778f, 0.4044f, 0.4778f, 0.3867f, 3}, 0xFF17151C, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4982f, 0.3804f, 2, 0.4982f, 0.3829f, 0.4950f, 0.3849f, 0.4911f, 0.3849f, 2, 0.4872f, 0.3849f, 0.4840f, 0.3829f, 0.4840f, 0.3804f, 2, 0.4840f, 0.3780f, 0.4872f, 0.3760f, 0.4911f, 0.3760f, 2, 0.4950f, 0.3760f, 0.4982f, 0.3780f, 0.4982f, 0.3804f, 3}, 0xCCFFFFFF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4556f, 0.4267f, 2, 0.4644f, 0.4667f, 0.5356f, 0.4667f, 0.5444f, 0.4267f, 2, 0.5267f, 0.4356f, 0.4733f, 0.4356f, 0.4556f, 0.4267f, 3}, 0xFF8A2232, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4556f, 0.4267f, 2, 0.4644f, 0.4667f, 0.5356f, 0.4667f, 0.5444f, 0.4267f, 2, 0.5267f, 0.4356f, 0.4733f, 0.4356f, 0.4556f, 0.4267f, 3}, 0xFF17151C, 0.00711f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4733f, 0.4467f, 2, 0.4867f, 0.4622f, 0.5133f, 0.4622f, 0.5267f, 0.4467f, 2, 0.5133f, 0.4400f, 0.4867f, 0.4400f, 0.4733f, 0.4467f, 3}, 0xFFFF7B8F, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4689f, 0.4293f, 1, 0.4778f, 0.4444f, 1, 0.4867f, 0.4329f, 3}, 0xFFFFFFFF, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4689f, 0.4293f, 1, 0.4778f, 0.4444f, 1, 0.4867f, 0.4329f, 3}, 0xFF17151C, 0.00356f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.5000f, 0.4133f, 1, 0.5000f, 0.4293f}, 0xFF17151C, 0.00622f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.4022f, 0.3911f, 2, 0.4022f, 0.3985f, 0.3903f, 0.4044f, 0.3756f, 0.4044f, 2, 0.3608f, 0.4044f, 0.3489f, 0.3985f, 0.3489f, 0.3911f, 2, 0.3489f, 0.3837f, 0.3608f, 0.3778f, 0.3756f, 0.3778f, 2, 0.3903f, 0.3778f, 0.4022f, 0.3837f, 0.4022f, 0.3911f, 3}, 0x66FF6F85, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.6511f, 0.3911f, 2, 0.6511f, 0.3985f, 0.6392f, 0.4044f, 0.6244f, 0.4044f, 2, 0.6097f, 0.4044f, 0.5978f, 0.3985f, 0.5978f, 0.3911f, 2, 0.5978f, 0.3837f, 0.6097f, 0.3778f, 0.6244f, 0.3778f, 2, 0.6392f, 0.3778f, 0.6511f, 0.3837f, 0.6511f, 0.3911f, 3}, 0x66FF6F85, 0.00000f, PART_HEAD));
        o.add(new Op(new float[]{0, 0.3844f, 0.1511f, 2, 0.3756f, 0.0933f, 0.4422f, 0.0533f, 0.5133f, 0.0533f, 2, 0.5889f, 0.0533f, 0.6378f, 0.0933f, 0.6289f, 0.1422f, 2, 0.5622f, 0.1200f, 0.4556f, 0.1200f, 0.3844f, 0.1511f, 3}, 0xFF3F7FD9, 0.00000f, PART_HAIR));
        o.add(new Op(new float[]{0, 0.3844f, 0.1511f, 2, 0.3756f, 0.0933f, 0.4422f, 0.0533f, 0.5133f, 0.0533f, 2, 0.5889f, 0.0533f, 0.6378f, 0.0933f, 0.6289f, 0.1422f, 2, 0.5622f, 0.1200f, 0.4556f, 0.1200f, 0.3844f, 0.1511f, 3}, 0xFF17151C, 0.00800f, PART_HAIR));
        o.add(new Op(new float[]{0, 0.3933f, 0.1422f, 2, 0.4644f, 0.1156f, 0.5533f, 0.1111f, 0.6244f, 0.1333f}, 0x6617151C, 0.00533f, PART_HAIR));
        o.add(new Op(new float[]{0, 0.5178f, 0.0533f, 2, 0.5133f, 0.0267f, 0.5400f, 0.0222f, 0.5444f, 0.0489f, 3}, 0xFF3F7FD9, 0.00000f, PART_HAIR));
        o.add(new Op(new float[]{0, 0.5178f, 0.0533f, 2, 0.5133f, 0.0267f, 0.5400f, 0.0222f, 0.5444f, 0.0489f, 3}, 0xFF17151C, 0.00622f, PART_HAIR));
        o.add(new Op(new float[]{0, 0.4396f, 0.1067f, 2, 0.4396f, 0.1126f, 0.4348f, 0.1173f, 0.4289f, 0.1173f, 2, 0.4230f, 0.1173f, 0.4182f, 0.1126f, 0.4182f, 0.1067f, 2, 0.4182f, 0.1008f, 0.4230f, 0.0960f, 0.4289f, 0.0960f, 2, 0.4348f, 0.0960f, 0.4396f, 0.1008f, 0.4396f, 0.1067f, 3}, 0xFFFF5F84, 0.00000f, PART_HAIR));
        o.add(new Op(new float[]{0, 0.4724f, 0.0844f, 2, 0.4724f, 0.0889f, 0.4689f, 0.0924f, 0.4644f, 0.0924f, 2, 0.4600f, 0.0924f, 0.4564f, 0.0889f, 0.4564f, 0.0844f, 2, 0.4564f, 0.0800f, 0.4600f, 0.0764f, 0.4644f, 0.0764f, 2, 0.4689f, 0.0764f, 0.4724f, 0.0800f, 0.4724f, 0.0844f, 3}, 0xFFFFCF3F, 0.00000f, PART_HAIR));
        return o;
    }

    /** Fondo de manhwa: cielo con degradado en bandas, sol y nubes, edificios a lo lejos. */
    public static List<Op> scenery() {
        List<Op> o = new ArrayList<>();
        int[] sky = {0xFF8EC5FF, 0xFFA3D0FF, 0xFFB9DCFF, 0xFFCFE8FF, 0xFFE3F1FF};
        for (int k = 0; k < sky.length; k++) {
            float y0 = k / (float) sky.length - 0.01f, y1 = (k + 1) / (float) sky.length + 0.01f;
            o.add(new Op(new B().m(-0.05f, y0).l(1.05f, y0).l(1.05f, y1).l(-0.05f, y1).z().a(), sky[k], 0, PART_FX));
        }
        o.add(new Op(ellipse(0.86f, 0.14f, 0.07f, 0.07f).a(), 0xFFFFF3B0, 0, PART_FX));
        float[][] clouds = {{0.14f, 0.18f}, {0.80f, 0.36f}};
        for (float[] cl : clouds) {
            o.add(new Op(ellipse(cl[0], cl[1], 0.09f, 0.035f).a(), 0xEEFFFFFF, 0, PART_FX));
            o.add(new Op(ellipse(cl[0] + 0.05f, cl[1] - 0.02f, 0.06f, 0.035f).a(), 0xEEFFFFFF, 0, PART_FX));
        }
        float[] bx = {0.00f, 0.10f, 0.18f, 0.80f, 0.88f, 0.95f};
        float[] bh = {0.55f, 0.62f, 0.50f, 0.58f, 0.48f, 0.60f};
        for (int k = 0; k < bx.length; k++)
            o.add(new Op(new B().m(bx[k], 1.02f).l(bx[k], bh[k]).l(bx[k] + 0.09f, bh[k]).l(bx[k] + 0.09f, 1.02f).z().a(), 0xFF9FB3CF, 0, PART_FX));
        return o;
    }
}
