package com.pacco.animecut.core;

/**
 * v8.80 RAYOS DE LUZ: la figura o el dibujo de una capa se vuelve una fuente de luz. Aproximacion
 * propia en 2D (no es el motor de otra app ni una simulacion 3D):
 *
 *  1) Fuente E (0..1) en una copia reducida: el alfa de la capa (una figura oscura tambien da luz,
 *     el color de la luz es aparte). Si la capa es una foto opaca, solo lo claro (umbral) para no
 *     encender toda la foto. Con seleccion, solo lo seleccionado da luz.
 *  2) Halo: E desenfocada en dos tamanos.
 *  3) Haces: cada pixel mira hacia el ORIGEN y promedia E a lo largo de ese camino (hasta el
 *     Alcance), con peso que baja con la distancia. Asi los haces salen de la forma de la fuente
 *     (letras, ventanas, triangulos...) y no de un sol prefabricado. Una variacion suave por angulo,
 *     fija (siempre la misma), da algo de textura a una fuente redonda.
 *  4) Luz = Brillo x (Fuerza x haces + Halo). Se entrega como capa para el modo Anadir: alfa =
 *     cuanta luz, color = el elegido (si pasa del 100 % se aclara hacia blanco).
 *
 * Todo se calcula sobre una copia de lado &lt;= WORK con coordenadas de toda la imagen (los haces leen
 * lejos: no hay franjas ni costuras) y se agranda al final. Java puro: lo prueban las pruebas de PC.
 */
public final class GodRays {
    private GodRays() { }

    /** Lado mayor de la copia de trabajo para el resultado final. */
    public static final int WORK = 1024;
    /** Los haces son suaves: se calculan en una copia de lado &lt;= RAY_SIDE (mucho mas rapido). */
    public static final int RAY_SIDE = 512;

    /** Brillo 0..300 %, Fuerza 0..100 %, Alcance 5..100 % del lado mayor, Halo 0..100, Umbral 0..100. */
    public static final int BRIGHT = 0, STRENGTH = 1, REACH = 2, HALO = 3, THRESH = 4;

    /**
     * @param src  capa fuente (sin premultiplicar), sw x sh
     * @param sel  seleccion sw x sh (null = toda)
     * @param ox   origen de los haces en 0..1 de la imagen (puede salir un poco del lienzo)
     * @return capa de luz outW x outH para el modo Anadir (sin premultiplicar)
     */
    public static int[] render(int[] src, int sw, int sh, byte[] sel, int[] v, int color, float ox, float oy,
                               int outW, int outH, Fx.Job job) {
        return render(src, sw, sh, sel, v, color, ox, oy, outW, outH, 0, job);
    }

    /** maxSamples &gt; 0 limita las muestras (vista rapida mientras se arrastra). */
    public static int[] render(int[] src, int sw, int sh, byte[] sel, int[] v, int color, float ox, float oy,
                               int outW, int outH, int maxSamples, Fx.Job job) {
        int[] out = new int[outW * outH];
        float bright = Math.max(0, v[BRIGHT]) / 100f;
        if (bright <= 0f) return out;                       // brillo cero = nada de luz
        // 1) copia de trabajo
        int ww = sw, wh = sh;
        int[] s = src;
        byte[] sl = sel;
        if (Math.max(sw, sh) > WORK) {
            int[] dims = new int[2];
            s = Fx.downscale(src, sw, sh, WORK, dims);
            ww = dims[0];
            wh = dims[1];
            if (sel != null) sl = shrinkSel(sel, sw, sh, ww, wh);
        }
        chk(job);
        float[] e = emission(s, ww, wh, sl, v[THRESH] / 100f);
        if (e == null) return out;                          // no hay nada que de luz
        chk(job);
        int n = ww * wh;
        float diag = Math.max(ww, wh);
        // 2) halo en dos tamanos
        float haloAmt = Math.max(0, Math.min(100, v[HALO])) / 100f;
        float[] halo = null;
        if (haloAmt > 0f) {
            float sig = diag * (0.006f + 0.022f * haloAmt);
            float[] a = e.clone(), b = e.clone(), tmp = new float[n];
            Fx.gaussPlaneF(a, tmp, ww, wh, sig);
            chk(job);
            Fx.gaussPlaneF(b, tmp, ww, wh, sig * 3.2f);
            halo = new float[n];
            for (int i = 0; i < n; i++) halo[i] = (0.65f * a[i] + 0.55f * b[i]) * haloAmt;
        }
        chk(job);
        // 3) haces
        float strength = Math.max(0, Math.min(100, v[STRENGTH])) / 100f;
        float[] rays = null;
        int rw = ww, rh = wh;
        if (strength > 0f) {
            // copia aun mas chica para los haces (son suaves); coordenadas de toda la imagen
            float[] er = e;
            if (Math.max(ww, wh) > RAY_SIDE) {
                float k = RAY_SIDE / (float) Math.max(ww, wh);
                rw = Math.max(1, Math.round(ww * k));
                rh = Math.max(1, Math.round(wh * k));
                er = shrinkF(e, ww, wh, rw, rh);
            }
            float reach = Math.max(1f, Math.max(rw, rh) * Math.max(5, Math.min(100, v[REACH])) / 100f);
            float rcx = ox * rw, rcy = oy * rh;
            rays = rays(er, rw, rh, rcx, rcy, reach, maxSamples, job);
            for (int y = 0; y < rh; y++)
                for (int x = 0; x < rw; x++) {
                    int i = y * rw + x;
                    if (rays[i] > 0f) rays[i] *= strength * 1.35f * angular((float) Math.atan2(y + .5f - rcy, x + .5f - rcx));
                }
        }
        chk(job);
        // 4) luz final en la copia de trabajo
        float[] lt = new float[n];
        boolean same = rw == ww && rh == wh;
        float kx = rw / (float) ww, ky = rh / (float) wh;
        for (int y = 0; y < wh; y++) {
            float ry = (y + .5f) * ky - .5f;
            for (int x = 0; x < ww; x++) {
                int i = y * ww + x;
                float l = 0f;
                if (rays != null) l += same ? rays[i] : Fx.bil(rays, rw, rh, (x + .5f) * kx - .5f, ry);
                if (halo != null) l += halo[i];
                lt[i] = l * bright;
            }
        }
        // 5) al tamano pedido (bilineal) y a pixeles de la capa
        float r0 = ((color >> 16) & 255), g0 = ((color >> 8) & 255), b0 = (color & 255);
        float fx = ww / (float) outW, fy = wh / (float) outH;
        for (int y = 0; y < outH; y++) {
            if ((y & 63) == 0) {
                chk(job);
                if (job != null) job.progress(60 + 40 * y / Math.max(1, outH));
            }
            float sy = (y + .5f) * fy - .5f;
            int row = y * outW;
            for (int x = 0; x < outW; x++) {
                float l = (ww == outW && wh == outH) ? lt[row + x] : Fx.bil(lt, ww, wh, (x + .5f) * fx - .5f, sy);
                out[row + x] = encode(l, r0, g0, b0);
            }
        }
        return out;
    }

    /** Pixel de la capa de luz: alfa = luz (hasta 1); pasado el 100 % el color se aclara a blanco. */
    static int encode(float l, float r0, float g0, float b0) {
        if (l <= 0.002f) return 0;
        int a = l >= 1f ? 255 : (int) (l * 255f + .5f);
        if (a <= 0) return 0;
        float k = l > 1f ? l : 1f;
        int r = Fx.clampf(r0 * k), g = Fx.clampf(g0 * k), b = Fx.clampf(b0 * k);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Variacion suave por angulo (0,55..1): fija, no cambia al mover barras ni el origen. Es
     * secundaria: la forma de los haces la da la fuente.
     */
    static float angular(float a) {
        double t = a;
        double n = 0.5 * Math.sin(t * 7 + 0.7) + 0.33 * Math.sin(t * 13 + 2.1) + 0.24 * Math.sin(t * 23 + 4.0)
                + 0.16 * Math.sin(t * 37 + 1.3);
        double u = 0.5 + 0.5 * n / 1.23;                  // 0..1
        u = u * u * (3 - 2 * u);
        return (float) (0.55 + 0.45 * u);
    }

    /** Fuente E (0..1). null si no hay nada que de luz. */
    static float[] emission(int[] s, int w, int h, byte[] sel, float thr) {
        int n = w * h;
        // foto opaca: casi todo con alfa lleno -> solo lo claro da luz
        int opaque = 0;
        for (int i = 0; i < n; i++) if ((s[i] >>> 24) >= 250) opaque++;
        boolean photo = opaque >= n * 0.97f;
        float lo = Math.max(0f, thr - 0.08f), hi = Math.min(1.0001f, thr + 0.08f);
        float[] e = new float[n];
        boolean any = false;
        for (int i = 0; i < n; i++) {
            int c = s[i], a = c >>> 24;
            if (a == 0) continue;
            float v = a / 255f;
            if (photo) v *= Fx.smooth(lo, hi, Fx.lum(c) / 255f);
            if (sel != null) v *= (sel[i] & 0xFF) / 255f;
            if (v > 0.002f) { e[i] = v; any = true; }
        }
        return any ? e : null;
    }

    /** true si la capa es casi toda opaca (se usa solo lo claro como fuente). */
    public static boolean isPhoto(int[] s) {
        int opaque = 0;
        for (int c : s) if ((c >>> 24) >= 250) opaque++;
        return opaque >= s.length * 0.97f;
    }

    /**
     * Haces: promedio de E desde cada pixel hacia el origen (cx,cy), hasta 'reach' px, con peso
     * (1-u)^1.5. Se normaliza con la suma de pesos del tramo recorrido: junto a la fuente vale ~1 y
     * se apaga suave al llegar al Alcance. Un pequeno corrimiento fijo por pixel evita escalones.
     */
    static float[] rays(float[] e, int w, int h, float cx, float cy, float reach, int maxSamples, Fx.Job job) {
        int n = w * h;
        float[] out = new float[n];
        int cap = maxSamples > 0 ? maxSamples : 64;
        for (int y = 0; y < h; y++) {
            if ((y & 15) == 0) {
                chk(job);
                if (job != null) job.progress(55 * y / Math.max(1, h));
            }
            float py = y + .5f;
            for (int x = 0; x < w; x++) {
                float px = x + .5f;
                float dx = cx - px, dy = cy - py;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                int i = y * w + x;
                if (d < 0.75f) { out[i] = e[i]; continue; }
                float len = Math.min(d, reach);
                int ns = Math.max(4, Math.min(cap, (int) Math.ceil(len / 2f)));
                float ux = dx / d, uy = dy / d;
                float step = len / ns;
                float jit = Fx.hash(x, y, 0x6A75) ;           // 0..1, fijo por pixel
                float acc = 0f, wsum = 0f;
                for (int k = 0; k < ns; k++) {
                    float t = (k + jit) * step;
                    float u = t / reach;
                    float om = 1f - u;
                    float wt = om * om;
                    wsum += wt;
                    float qx = px + ux * t - .5f, qy = py + uy * t - .5f;
                    if (qx < -1f || qy < -1f || qx > w || qy > h) continue;
                    acc += wt * Fx.bil(e, w, h, qx, qy);
                }
                out[i] = wsum > 0f ? acc / wsum : 0f;
            }
        }
        // suavizado minimo (quita el grano del corrimiento sin borrar el detalle de los haces)
        float[] tmp = new float[n];
        Fx.boxHf(out, tmp, w, h, 1);
        Fx.boxVf(tmp, out, w, h, 1);
        return out;
    }

    /**
     * Centro de la fuente (0..1) para poner ahi el origen la primera vez; null si la capa no tiene
     * nada que de luz.
     */
    public static float[] centroid(int[] s, int w, int h, int thrPct) {
        float[] e = emission(s, w, h, null, thrPct / 100f);
        if (e == null) return null;
        double sx = 0, sy = 0, sw = 0;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                float v = e[y * w + x];
                if (v <= 0f) continue;
                sx += v * (x + .5);
                sy += v * (y + .5);
                sw += v;
            }
        if (sw <= 0) return null;
        return new float[]{(float) (sx / sw / w), (float) (sy / sw / h)};
    }

    /** true si la capa de luz quedo vacia. */
    public static boolean isEmpty(int[] light) {
        if (light == null) return true;
        for (int c : light) if ((c >>> 24) > 2) return false;
        return true;
    }

    /** Promedio por cajas de un plano (para la copia de los haces). */
    static float[] shrinkF(float[] p, int w, int h, int ow, int oh) {
        float[] o = new float[ow * oh];
        for (int y = 0; y < oh; y++) {
            int y0 = (int) ((long) y * h / oh), y1 = Math.max(y0 + 1, (int) ((long) (y + 1) * h / oh));
            for (int x = 0; x < ow; x++) {
                int x0 = (int) ((long) x * w / ow), x1 = Math.max(x0 + 1, (int) ((long) (x + 1) * w / ow));
                float s = 0f;
                for (int yy = y0; yy < y1; yy++)
                    for (int xx = x0; xx < x1; xx++) s += p[yy * w + xx];
                o[y * ow + x] = s / ((x1 - x0) * (y1 - y0));
            }
        }
        return o;
    }

    static byte[] shrinkSel(byte[] sel, int w, int h, int ow, int oh) {
        byte[] o = new byte[ow * oh];
        for (int y = 0; y < oh; y++) {
            int sy = Math.min(h - 1, (int) ((y + .5f) * h / oh));
            for (int x = 0; x < ow; x++) o[y * ow + x] = sel[sy * w + Math.min(w - 1, (int) ((x + .5f) * w / ow))];
        }
        return o;
    }

    private static void chk(Fx.Job j) {
        if (j != null && j.cancelled()) throw new Fx.Cancelled();
    }
}
