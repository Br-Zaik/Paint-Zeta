package com.pacco.animecut.core;

/**
 * v8.78 Puntas forzadas (atenuacion): el trazo se afina al empezar y al terminar segun un
 * PORCENTAJE de su largo total (no del grosor del pincel). Java puro: lo usa la app y las
 * pruebas de PC.
 *
 *  - Inicio y Final van de 0 a 100 % del largo. Si juntos pasan del largo disponible, se
 *    reparten en proporcion (nunca queda una zona de grosor cero en el medio).
 *  - Forma "Suave": se afina despacio y termina en punta redondeada.
 *    Forma "Lineal": el grosor baja en linea recta (punta de cuna).
 *  - La punta nunca llega a cero (minimo 12 % del grosor) para que se vea. En trazos muy cortos
 *    el minimo sube, asi un toque o un trazo corto no desaparece.
 */
public final class StrokeTaper {
    private StrokeTaper() { }

    public static final int SOFT = 0, LINEAR = 1;

    /**
     * Factor de grosor (0..1) en el punto "arc" de un trazo de largo "total".
     *
     * @param startPct  largo de la punta inicial, 0..100 % del trazo
     * @param endPct    largo de la punta final, 0..100 % del trazo
     * @param radius    radio del pincel (px): decide que es un trazo "corto"
     */
    public static float factor(float arc, float total, float startPct, float endPct, int shape, float radius) {
        if (total <= 0f || (startPct <= 0f && endPct <= 0f)) return 1f;
        float ls = total * Math.max(0f, startPct) / 100f;
        float le = total * Math.max(0f, endPct) / 100f;
        float lim = total * 0.98f;
        if (ls + le > lim && ls + le > 0f) {
            float k = lim / (ls + le);
            ls *= k;
            le *= k;
        }
        float min = 0.12f;
        float shortLen = Math.max(1f, radius) * 6f;
        if (total < shortLen) min = 0.12f + 0.5f * (1f - total / shortLen);  // corto: punta mas gruesa
        float w = 1f;
        if (ls > 0f && arc < ls) w = Math.min(w, profile(Math.max(0f, arc) / ls, shape, min));
        float tail = total - arc;
        if (le > 0f && tail < le) w = Math.min(w, profile(Math.max(0f, tail) / le, shape, min));
        return w;
    }

    private static float profile(float u, int shape, float min) {
        u = Math.max(0f, Math.min(1f, u));
        float s = shape == LINEAR ? u : 1f - (1f - u) * (1f - u);
        return min + (1f - min) * s;
    }
}
