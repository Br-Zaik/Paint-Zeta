package com.pacco.animecut.core;

/**
 * Separar partes con rayones, como la Colorize Mask de Krita.
 *
 * Pintas un rayon de color en cada parte. Se inunda la imagen desde esos
 * rayones empezando por lo claro, y las lineas negras del dibujo quedan
 * para el final: por eso el limite entre partes cae justo sobre la linea.
 *
 * Es inundacion con marcadores (watershed) con una cola por cubos de 256
 * niveles: coste lineal, sin resolver ecuaciones.
 */
public final class Watershed {

    private Watershed() {
    }

    /**
     * @param labels   rayones del usuario: 0 sin marcar, 1..254 cada parte
     * @param gapClose cuanto se desenfoca la linea para tapar sus cortes
     * @param bgLabel  etiqueta del fondo; si no hay rayones de fondo, el borde
     *                 de la imagen se usa como fondo
     * @return una etiqueta por pixel
     */
    private static int diff(int a, int b) {
        int dr = Math.abs(((a >> 16) & 0xFF) - ((b >> 16) & 0xFF));
        int dg = Math.abs(((a >> 8) & 0xFF) - ((b >> 8) & 0xFF));
        int db = Math.abs((a & 0xFF) - (b & 0xFF));
        return Math.max(dr, Math.max(dg, db));
    }

    public static byte[] run(int[] px, int w, int h, byte[] labels, int gapClose, int bgLabel) {
        return run(px, w, h, labels, gapClose, bgLabel, null);
    }

    /** v8.33: etiqueta "el resto" (no se toca): lo que una parte no alcanza sin cruzar la linea. */
    public static final int REST = 253;
    /** Relieve desde el que se considera linea (pared alta) para el modo "solo lo encerrado". */
    static final int LINE_LEVEL = 215;

    /** @param lineIn linea ya calculada (del mismo tamano), o null para calcularla */
    public static byte[] run(int[] px, int w, int h, byte[] labels, int gapClose, int bgLabel, byte[] lineIn) {
        return run(px, w, h, labels, gapClose, bgLabel, lineIn, false);
    }

    /**
     * @param restMode v8.33: con UNA sola parte rayada, esa parte toma solo lo que alcanza SIN
     *                 cruzar la linea negra (el ojo, no media cara); lo demas queda como REST
     *                 ("el resto", no se separa ni se borra). Los limites siguen cayendo sobre
     *                 la linea.
     */
    public static byte[] run(int[] px, int w, int h, byte[] labels, int gapClose, int bgLabel, byte[] lineIn, boolean restMode) {
        int n = w * h;

        // relieve (como LazyBrush): la linea negra es una pared alta, los cambios
        // fuertes de color son paredes medianas, y cerca de las puntas de linea
        // tambien sube, asi el limite cruza los cortes de la linea y no se escapa.
        byte[] line = lineIn != null ? lineIn : AutoLines.build(px, w, h);
        byte[] relief = new byte[n];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int c = px[i];
                int g = 0;
                if (x + 1 < w) g = Math.max(g, diff(c, px[i + 1]));
                if (y + 1 < h) g = Math.max(g, diff(c, px[i + w]));
                if (x > 0) g = Math.max(g, diff(c, px[i - 1]));
                if (y > 0) g = Math.max(g, diff(c, px[i - w]));
                int v = Math.min(200, g * 2);
                if (line[i] != 0) v = 255;
                relief[i] = (byte) v;
            }
        }
        int gc = Math.max(2, gapClose);
        byte[] ridge = line.clone();
        MaskOps.feather(ridge, w, h, gc * 2);
        for (int i = 0; i < n; i++) {
            int a = relief[i] & 0xFF, r = ((ridge[i] & 0xFF) * 230) / 255;
            if (r > a) relief[i] = (byte) r;
        }
        ridge = null;

        byte[] out = labels.clone();
        // rayas sin cuidado: lo que cae encima de la linea negra no cuenta,
        // salvo que ese color no tenga nada fuera de la linea
        int[] kept = new int[256], total = new int[256];
        for (int i = 0; i < n; i++) {
            int v = out[i] & 0xFF;
            if (v == 0) continue;
            total[v]++;
            if (line[i] != 0) out[i] = 0;
            else kept[v]++;
        }
        for (int v = 1; v < 256; v++) {
            if (total[v] > 0 && kept[v] == 0) {
                for (int i = 0; i < n; i++) if ((labels[i] & 0xFF) == v) out[i] = (byte) v;
            }
        }
        line = null;
        boolean hasBg = false;
        for (int i = 0; i < n; i++) {
            if ((out[i] & 0xFF) == bgLabel) {
                hasBg = true;
                break;
            }
        }
        if (!hasBg) {
            for (int x = 0; x < w; x++) {
                if (out[x] == 0) out[x] = (byte) bgLabel;
                int b = (h - 1) * w + x;
                if (out[b] == 0) out[b] = (byte) bgLabel;
            }
            for (int y = 0; y < h; y++) {
                if (out[y * w] == 0) out[y * w] = (byte) bgLabel;
                int r = y * w + w - 1;
                if (out[r] == 0) out[r] = (byte) bgLabel;
            }
        }

        Buckets q = new Buckets();
        for (int i = 0; i < n; i++) {
            if (out[i] != 0) q.push(relief[i] & 0xFF, i);
        }
        if (restMode) {
            // fase 0: lejos de la raya (mas de 1,5 veces su tamano, minimo 32 px) empieza "el
            // resto": compite con la parte y el limite cae en el borde mas fuerte entre ambos
            int minX = w, minY = h, maxX = -1, maxY = -1;
            for (int i = 0; i < n; i++) {
                int v = out[i] & 0xFF;
                if (v == 0 || v == bgLabel) continue;
                int x = i % w, y = i / w;
                if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
            }
            if (maxX >= 0) {
                int diag = (int) Math.hypot(maxX - minX + 1, maxY - minY + 1);
                int D = Math.max(32, diag * 3 / 2);
                int[] dist = new int[n];
                java.util.Arrays.fill(dist, Integer.MAX_VALUE);
                int[] qq = new int[n];
                int qh = 0, qt = 0;
                for (int i = 0; i < n; i++) {
                    int v = out[i] & 0xFF;
                    if (v != 0 && v != bgLabel) { dist[i] = 0; qq[qt++] = i; }
                }
                while (qh < qt) {
                    int i = qq[qh++];
                    int d = dist[i];
                    if (d > D) continue;
                    int x = i % w, y = i / w;
                    if (x > 0 && dist[i - 1] > d + 1) { dist[i - 1] = d + 1; qq[qt++] = i - 1; }
                    if (x < w - 1 && dist[i + 1] > d + 1) { dist[i + 1] = d + 1; qq[qt++] = i + 1; }
                    if (y > 0 && dist[i - w] > d + 1) { dist[i - w] = d + 1; qq[qt++] = i - w; }
                    if (y < h - 1 && dist[i + w] > d + 1) { dist[i + w] = d + 1; qq[qt++] = i + w; }
                }
                for (int i = 0; i < n; i++) {
                    if (out[i] == 0 && dist[i] > D && (relief[i] & 0xFF) < LINE_LEVEL) {
                        out[i] = (byte) REST;
                        q.push(relief[i] & 0xFF, i);
                    }
                }
            }
            // fase 1: cada raya llena lo suyo sin subir a la linea
            flood(q, out, relief, w, h, LINE_LEVEL);
            // fase 2: lo que nadie alcanzo (y no es linea) es "el resto"
            for (int i = 0; i < n; i++) if (out[i] == 0 && (relief[i] & 0xFF) < LINE_LEVEL) out[i] = (byte) REST;
            q = new Buckets();
            for (int i = 0; i < n; i++) if (out[i] != 0) q.push(relief[i] & 0xFF, i);
        }
        flood(q, out, relief, w, h, 256);
        if (restMode) fillHoles(out, w, h, bgLabel);
        return out;
    }

    /**
     * v8.69: con una sola parte, lo que queda ENCERRADO dentro de ella (ojos, boca dentro de la
     * cara) es de esa parte: antes la cara salia sin ojos. Lo que llega al borde o tiene fondo
     * marcado no se toca (la camisa sigue siendo "el resto").
     */
    static void fillHoles(byte[] out, int w, int h, int bgLabel) {
        int n = w * h;
        int[] area = new int[256];
        for (int i = 0; i < n; i++) area[out[i] & 0xFF]++;
        int[] stack = new int[4096];
        for (int v = 1; v < 256; v++) {
            if (v == bgLabel || v == REST || area[v] == 0) continue;
            byte[] seen = new byte[n];          // 1 = afuera (llega al borde), 2 = hueco revisado
            int sp = 0;
            for (int x = 0; x < w; x++) { stack = push(stack, sp++, x); stack = push(stack, sp++, (h - 1) * w + x); }
            for (int y = 0; y < h; y++) { stack = push(stack, sp++, y * w); stack = push(stack, sp++, y * w + w - 1); }
            while (sp > 0) {
                int i = stack[--sp];
                if (seen[i] != 0 || (out[i] & 0xFF) == v) continue;
                seen[i] = 1;
                int x = i % w, y = i / w;
                if (x > 0) stack = push(stack, sp++, i - 1);
                if (x < w - 1) stack = push(stack, sp++, i + 1);
                if (y > 0) stack = push(stack, sp++, i - w);
                if (y < h - 1) stack = push(stack, sp++, i + w);
            }
            int maxHole = Math.max(16, area[v] * 3 / 10);
            int[] comp = new int[1024];
            for (int s0 = 0; s0 < n; s0++) {
                if (seen[s0] != 0 || (out[s0] & 0xFF) == v) continue;
                int cn = 0;
                boolean hasBg = false;
                sp = 0;
                stack = push(stack, sp++, s0);
                seen[s0] = 2;
                while (sp > 0) {
                    int i = stack[--sp];
                    if (cn == comp.length) comp = java.util.Arrays.copyOf(comp, cn * 2);
                    comp[cn++] = i;
                    if ((out[i] & 0xFF) == bgLabel) hasBg = true;
                    int x = i % w, y = i / w;
                    int[] nb = {x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1};
                    for (int j : nb) {
                        if (j < 0 || seen[j] != 0 || (out[j] & 0xFF) == v) continue;
                        seen[j] = 2;
                        stack = push(stack, sp++, j);
                    }
                }
                if (!hasBg && cn <= maxHole) for (int k = 0; k < cn; k++) out[comp[k]] = (byte) v;
            }
        }
    }

    private static int[] push(int[] st, int at, int v) {
        if (at >= st.length) st = java.util.Arrays.copyOf(st, st.length * 2);
        st[at] = v;
        return st;
    }

    /** Inundacion por niveles; con limit < 256 no entra en pixeles de relieve >= limit. */
    private static void flood(Buckets q, byte[] out, byte[] relief, int w, int h, int limit) {
        while (true) {
            int lvl = q.level();
            if (lvl < 0) break;
            int p = q.pop();
            int lab = out[p];
            int y = p / w;
            int x = p - y * w;
            if (x > 0) visit(p - 1, lab, lvl, out, relief, q, limit);
            if (x < w - 1) visit(p + 1, lab, lvl, out, relief, q, limit);
            if (y > 0) visit(p - w, lab, lvl, out, relief, q, limit);
            if (y < h - 1) visit(p + w, lab, lvl, out, relief, q, limit);
        }
    }

    private static void visit(int q, int lab, int lvl, byte[] out, byte[] relief, Buckets b, int limit) {
        if (out[q] != 0) return;
        if ((relief[q] & 0xFF) >= limit) return;
        out[q] = (byte) lab;
        int r = relief[q] & 0xFF;
        b.push(r > lvl ? r : lvl, q);
    }

    /** Cola por niveles: sacar siempre del nivel mas bajo con algo. */
    private static final class Buckets {
        private final int[][] a = new int[256][];
        private final int[] n = new int[256];
        private int cur = 0;

        void push(int level, int v) {
            int[] arr = a[level];
            if (arr == null) {
                arr = new int[1024];
                a[level] = arr;
            } else if (n[level] == arr.length) {
                int[] b = new int[arr.length * 2];
                System.arraycopy(arr, 0, b, 0, arr.length);
                a[level] = b;
                arr = b;
            }
            arr[n[level]++] = v;
            if (level < cur) cur = level;
        }

        int level() {
            while (cur < 256 && n[cur] == 0) cur++;
            return cur < 256 ? cur : -1;
        }

        int pop() {
            return a[cur][--n[cur]];
        }
    }
}
