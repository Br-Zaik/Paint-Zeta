package com.pacco.animecut.view;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;

/**
 * v8.71: miniaturas del menu "Mezcla y opacidad". En cada una, Zeta (el zorrito) con una luz de
 * prueba encima mezclada con ESE modo: se ve de un vistazo que hace cada uno, sin leer nombres.
 * La luz de prueba tiene de todo (centro blanco, rosa, violeta y borde oscuro) para que los modos
 * se distingan. Se arman una sola vez (unos milisegundos) y quedan guardadas.
 */
public final class BlendThumbs {
    private BlendThumbs() { }

    /** Enmascarar: 0 = nada, 1 = Recorte (Mascara), 2 = Excluir. */
    public static final int MASK_NONE = 0, MASK_CLIP = 1, MASK_OUT = 2;

    private static int cachedSize = -1;
    private static int[] base, light, zetaA;
    private static final Bitmap[] modeCache = new Bitmap[32];
    private static final Bitmap[] maskCache = new Bitmap[3];

    private static synchronized void prepare(int s) {
        if (cachedSize == s && base != null) return;
        for (int i = 0; i < modeCache.length; i++) modeCache[i] = null;
        for (int i = 0; i < maskCache.length; i++) maskCache[i] = null;
        for (Bitmap[] a : framedMode) java.util.Arrays.fill(a, null);
        for (Bitmap[] a : framedMask) java.util.Arrays.fill(a, null);
        int n = s * s;
        // abajo: el fondo de dia y Zeta
        Bitmap bg = ToolArt.backgroundOnly(1, s, s);
        Bitmap ch = ToolArt.characterOnly(s, s);
        Bitmap all = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(all);
        c.drawBitmap(bg, 0, 0, null);
        c.drawBitmap(ch, 0, 0, null);
        base = new int[n];
        all.getPixels(base, 0, s, 0, 0, s, s);
        zetaA = new int[n];
        int[] tmp = new int[n];
        ch.getPixels(tmp, 0, s, 0, 0, s, s);
        for (int i = 0; i < n; i++) zetaA[i] = tmp[i] >>> 24;
        bg.recycle();
        ch.recycle();
        all.recycle();
        // arriba: la luz de prueba (circulo con degradado de colores)
        light = new int[n];
        float cx = s * 0.56f, cy = s * 0.42f, rad = s * 0.40f;
        int[] stops = {0xFFFFFFFF, 0xFFFF9BD0, 0xFFB45CFF, 0xFF3A1F7A, 0xFF120A2A};
        for (int y = 0; y < s; y++)
            for (int x = 0; x < s; x++) {
                float d = (float) Math.hypot(x + .5f - cx, y + .5f - cy) / rad;
                if (d >= 1f) { light[y * s + x] = 0; continue; }
                float t = d * (stops.length - 1);
                int k = Math.min(stops.length - 2, (int) t);
                float f = t - k;
                int a = stops[k], b = stops[k + 1];
                int r = Math.round(((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
                int g = Math.round(((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
                int bl = Math.round((a & 255) * (1 - f) + (b & 255) * f);
                int al = d > 0.94f ? Math.round(255 * (1f - d) / 0.06f) : 255;   // borde suave
                light[y * s + x] = (al << 24) | (r << 16) | (g << 8) | bl;
            }
        cachedSize = s;
    }

    /** Miniatura de un modo de mezcla (Layer.MODE_*), de s x s pixeles. */
    public static synchronized Bitmap mode(int mode, int s) {
        prepare(s);
        if (mode >= 0 && mode < modeCache.length && modeCache[mode] != null) return modeCache[mode];
        int n = s * s;
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int c = light[i], a = c >>> 24;
            out[i] = a == 0 ? base[i] : (Project.blend(base[i], c, mode, a) | 0xFF000000);
        }
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        b.setPixels(out, 0, s, 0, 0, s, s);
        if (mode >= 0 && mode < modeCache.length) modeCache[mode] = b;
        return b;
    }

    /** Miniatura de Enmascarar: la luz (en Pantalla) sobre todo, solo sobre Zeta, o todo menos Zeta. */
    public static synchronized Bitmap mask(int kind, int s) {
        prepare(s);
        if (maskCache[kind] != null) return maskCache[kind];
        int n = s * s;
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            // luz que cubre TODO (rosa arriba, violeta abajo): asi se ve claro donde queda
            int y = i / s;
            float f = y / (float) Math.max(1, s - 1);
            int c = 0xFF000000 | (Math.round(255 - 75 * f) << 16) | (Math.round(80 - 30 * f) << 8) | Math.round(190 + 50 * f);
            int a = 235;
            if (kind != MASK_NONE) a = Layer.clipA(a, zetaA[i], kind == MASK_OUT);
            out[i] = a == 0 ? base[i] : (Project.blend(base[i], c, Layer.MODE_SCREEN, a) | 0xFF000000);
        }
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        b.setPixels(out, 0, s, 0, 0, s, s);
        maskCache[kind] = b;
        return b;
    }

    private static final Bitmap[][] framedMode = new Bitmap[2][32];
    private static final Bitmap[][] framedMask = new Bitmap[2][3];
    private static float framedRad = -1f;

    /** Miniatura ya enmarcada y guardada (no se vuelve a armar al tocar). */
    public static synchronized Bitmap modeTile(int mode, int s, boolean sel, float rad) {
        prepare(s);
        checkRad(rad);
        int k = sel ? 1 : 0;
        if (framedMode[k][mode] == null) framedMode[k][mode] = framed(mode(mode, s), sel, rad);
        return framedMode[k][mode];
    }

    public static synchronized Bitmap maskTile(int kind, int s, boolean sel, float rad) {
        prepare(s);
        checkRad(rad);
        int k = sel ? 1 : 0;
        if (framedMask[k][kind] == null) framedMask[k][kind] = framed(mask(kind, s), sel, rad);
        return framedMask[k][kind];
    }

    /** Arma todas por detras (la primera vez que se abre el menu). */
    public static void warm(int s, float rad) {
        for (int m = 0; m < 28; m++) { modeTile(m, s, false, rad); modeTile(m, s, true, rad); }
        for (int k = 0; k < 3; k++) { maskTile(k, s, false, rad); maskTile(k, s, true, rad); }
    }

    public static synchronized boolean ready(int s) {
        if (cachedSize != s) return false;
        for (int m = 0; m < 28; m++) if (framedMode[0][m] == null || framedMode[1][m] == null) return false;
        return framedMask[0][2] != null && framedMask[1][2] != null;
    }

    private static void checkRad(float rad) {
        if (rad == framedRad) return;
        framedRad = rad;
        for (Bitmap[] a : framedMode) java.util.Arrays.fill(a, null);
        for (Bitmap[] a : framedMask) java.util.Arrays.fill(a, null);
    }

    /** Dibuja la miniatura con esquinas redondeadas y marco (verde si esta elegida). */
    public static Bitmap framed(Bitmap src, boolean selected, float radius) {
        int s = src.getWidth();
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        android.graphics.Path clip = new android.graphics.Path();
        clip.addRoundRect(new android.graphics.RectF(0, 0, s, s), radius, radius, android.graphics.Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.drawBitmap(src, 0, 0, p);
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(selected ? Math.max(3f, s * 0.06f) : Math.max(1f, s * 0.02f));
        p.setColor(selected ? 0xFF2EE6A6 : 0x55FFFFFF);
        float inset = p.getStrokeWidth() / 2f;
        c.drawRoundRect(new android.graphics.RectF(inset, inset, s - inset, s - inset), radius, radius, p);
        if (selected) {
            float r = s * 0.16f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF2EE6A6);
            c.drawCircle(s / 2f, s / 2f, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, s * 0.04f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0xFFFFFFFF);
            android.graphics.Path ck = new android.graphics.Path();
            ck.moveTo(s / 2f - r * .5f, s / 2f);
            ck.lineTo(s / 2f - r * .1f, s / 2f + r * .4f);
            ck.lineTo(s / 2f + r * .55f, s / 2f - r * .4f);
            c.drawPath(ck, p);
        }
        return b;
    }
}
