package com.pacco.animecut.core;

/**
 * v8.73 Cambiar el tamano de una imagen con transparencia, en Java puro (sin Canvas).
 *
 * Antes, exportar a "Mitad", "Lado largo 1920" o "1280" dibujaba con Canvas sobre una imagen
 * "sin premultiplicar", y Android no lo permite: la exportacion fallaba y dejaba un archivo roto.
 *
 *  - Reducir: cada pixel nuevo es el PROMEDIO del area que cubre en la imagen original (no se
 *    saltan pixeles: las lineas finas no se cortan ni salen dientes).
 *  - Agrandar: mezcla suave entre los 4 vecinos (bilineal).
 *  - El color se promedia segun cuanto se ve cada pixel (alfa): el color escondido de lo
 *    transparente no ensucia el borde (sin halo negro ni blanco alrededor del personaje).
 *  - Trabaja fila por fila: usa muy poca memoria aunque la imagen sea enorme.
 *
 * Lo usan la app (Exporter) y las pruebas de PC.
 */
public final class Resample {
    private Resample() { }

    /** Recibe cada fila terminada (colores ARGB sin premultiplicar). */
    public interface RowSink {
        void row(int[] line, int x, int y, int len);
    }

    /** Para cada pixel de salida: que pixeles de la region original usa y con que peso. */
    private static final class Taps {
        final int[] start, count, idx;
        final float[] w;
        Taps(int[] start, int[] count, int[] idx, float[] w) {
            this.start = start; this.count = count; this.idx = idx; this.w = w;
        }
    }

    /**
     * @param src    tamano completo original (ancho o alto)
     * @param dst    tamano completo de salida
     * @param regLo  la region con contenido empieza aqui (coordenada original)
     * @param regHi  y termina aqui (sin incluir)
     * @param o0     primer pixel de salida a calcular
     * @param o1     ultimo pixel de salida (sin incluir)
     */
    private static Taps taps(int src, int dst, int regLo, int regHi, int o0, int o1) {
        int n = Math.max(0, o1 - o0);
        int[] start = new int[n], count = new int[n];
        int[] idx = new int[Math.max(16, n * 4)];
        float[] w = new float[idx.length];
        int k = 0;
        double scale = (double) dst / src;
        for (int i = 0; i < n; i++) {
            int o = o0 + i;
            start[i] = k;
            if (scale < 1.0) {
                // reducir: area que cubre el pixel de salida en el original
                double a = o / scale, b = (o + 1) / scale;
                int s0 = (int) Math.floor(a), s1 = (int) Math.ceil(b);
                for (int s = s0; s < s1; s++) {
                    if (s < regLo || s >= regHi || s < 0 || s >= src) continue;
                    double ov = Math.min(b, s + 1) - Math.max(a, s);
                    if (ov <= 0) continue;
                    if (k >= idx.length) { idx = grow(idx); w = grow(w); }
                    idx[k] = s - regLo;
                    w[k] = (float) (ov * scale);
                    k++;
                }
            } else {
                // igual o agrandar: bilineal
                double c = (o + 0.5) / scale - 0.5;
                int s0 = (int) Math.floor(c);
                double f = c - s0;
                int sa = Math.max(0, Math.min(src - 1, s0)), sb = Math.max(0, Math.min(src - 1, s0 + 1));
                double wa = 1.0 - f, wb = f;
                if (sa >= regLo && sa < regHi && wa > 0) {
                    if (k >= idx.length) { idx = grow(idx); w = grow(w); }
                    idx[k] = sa - regLo; w[k] = (float) wa; k++;
                }
                if (sb >= regLo && sb < regHi && wb > 0) {
                    if (k >= idx.length) { idx = grow(idx); w = grow(w); }
                    idx[k] = sb - regLo; w[k] = (float) wb; k++;
                }
            }
            count[i] = k - start[i];
        }
        return new Taps(start, count, idx, w);
    }

    private static int[] grow(int[] a) {
        int[] b = new int[a.length * 2];
        System.arraycopy(a, 0, b, 0, a.length);
        return b;
    }

    private static float[] grow(float[] a) {
        float[] b = new float[a.length * 2];
        System.arraycopy(a, 0, b, 0, a.length);
        return b;
    }

    /**
     * Cambia el tamano de una region de la imagen.
     *
     * @param px          pixeles ARGB (sin premultiplicar) de la region, rw x rh
     * @param rx, ry      donde esta la region dentro de la imagen original
     * @param srcW, srcH  tamano completo original
     * @param outW, outH  tamano completo de salida
     * @param sink        recibe las filas de salida que tienen algo (lo demas queda transparente)
     */
    public static void resize(int[] px, int rx, int ry, int rw, int rh, int srcW, int srcH,
                              int outW, int outH, RowSink sink) {
        if (rw <= 0 || rh <= 0 || outW <= 0 || outH <= 0) return;
        double sx = (double) outW / srcW, sy = (double) outH / srcH;
        // region de salida que puede recibir color (+2 de margen por el bilineal)
        int ox0 = Math.max(0, (int) Math.floor(rx * sx) - 2);
        int ox1 = Math.min(outW, (int) Math.ceil((rx + rw) * sx) + 2);
        int oy0 = Math.max(0, (int) Math.floor(ry * sy) - 2);
        int oy1 = Math.min(outH, (int) Math.ceil((ry + rh) * sy) + 2);
        if (ox1 <= ox0 || oy1 <= oy0) return;
        Taps tx = taps(srcW, outW, rx, rx + rw, ox0, ox1);
        Taps ty = taps(srcH, outH, ry, ry + rh, oy0, oy1);
        int ow = ox1 - ox0;
        float[] acc = new float[ow * 4];
        float[] hrow = new float[ow * 4];
        int[] line = new int[ow];
        int cachedRow = -1;
        for (int j = 0; j < oy1 - oy0; j++) {
            java.util.Arrays.fill(acc, 0f);
            int ts = ty.start[j], tc = ty.count[j];
            for (int t = 0; t < tc; t++) {
                int sy0 = ty.idx[ts + t];
                float wy = ty.w[ts + t];
                if (sy0 != cachedRow) {
                    horizontal(px, sy0 * rw, tx, hrow);
                    cachedRow = sy0;
                }
                for (int i = 0; i < acc.length; i++) acc[i] += hrow[i] * wy;
            }
            boolean any = false;
            for (int i = 0; i < ow; i++) {
                float a = acc[i * 4 + 3];
                if (a < 0.5f) { line[i] = 0; continue; }
                int ai = Math.min(255, Math.round(a));
                float inv = 1f / a;
                int r = clamp(Math.round(acc[i * 4] * inv));
                int g = clamp(Math.round(acc[i * 4 + 1] * inv));
                int b = clamp(Math.round(acc[i * 4 + 2] * inv));
                line[i] = (ai << 24) | (r << 16) | (g << 8) | b;
                any = true;
            }
            if (any) sink.row(line, ox0, oy0 + j, ow);
        }
    }

    /** Una fila original -> fila de salida, con el color multiplicado por su alfa. */
    private static void horizontal(int[] px, int off, Taps tx, float[] out) {
        int n = tx.start.length;
        for (int i = 0; i < n; i++) {
            float r = 0, g = 0, b = 0, a = 0;
            int ts = tx.start[i], tc = tx.count[i];
            for (int t = 0; t < tc; t++) {
                int c = px[off + tx.idx[ts + t]];
                int ca = c >>> 24;
                if (ca == 0) continue;
                float wa = tx.w[ts + t] * ca;          // peso x cuanto se ve
                r += ((c >> 16) & 255) * wa;
                g += ((c >> 8) & 255) * wa;
                b += (c & 255) * wa;
                a += wa;
            }
            // r,g,b = color x alfa ; a = alfa 0..255
            out[i * 4] = r;
            out[i * 4 + 1] = g;
            out[i * 4 + 2] = b;
            out[i * 4 + 3] = a;
        }
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }
}
