package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.pacco.animecut.core.AutoLines;
import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Filters;
import com.pacco.animecut.core.FloodFill;
import com.pacco.animecut.core.GuidedFilter;
import com.pacco.animecut.core.HoleFill;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.LineArt;
import com.pacco.animecut.core.LineRepair;
import com.pacco.animecut.core.LiveWire;
import com.pacco.animecut.core.MaskOps;
import com.pacco.animecut.core.Membrane;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.PuppetSession;
import com.pacco.animecut.core.PuppetMesh;
import com.pacco.animecut.core.PixelTiles;
import com.pacco.animecut.core.ShapeGeom;
import com.pacco.animecut.core.TriWarp;
import com.pacco.animecut.core.ArapSolver;
import com.pacco.animecut.core.LatestWorker;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.ToneFill;
import com.pacco.animecut.core.UndoManager;
import com.pacco.animecut.core.Watershed;
import com.pacco.animecut.core.ZoneFill;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * El lienzo, trabajando igual que Ibis: capas de verdad con transparencia,
 * una capa de seleccion (lo azul), y dos dedos que solo mueven y hacen zoom.
 */
public class CanvasView extends View {

    public static final int MODE_PAN = 0;
    public static final int MODE_WAND = 1;
    public static final int MODE_BRUSH = 2;
    public static final int MODE_ERASER = 3;
    public static final int MODE_LASSO = 4;
    public static final int MODE_CLONE = 5;
    public static final int MODE_PAINT = 6;
    public static final int MODE_BUCKET = 7;
    public static final int MODE_PICKER = 8;
    public static final int MODE_SCISSORS = 9;
    public static final int MODE_MOVE = 10;
    public static final int MODE_BGERASE = 11;
    public static final int MODE_MARKER = 12;
    public static final int MODE_MAGNET = 13;
    public static final int MODE_LINE = 14;
    public static final int MODE_ZONE = 15;
    /** v8.73: "Copiar zona" se quito (su metodo tiene patentes). El numero queda reservado. */
    public static final int MODE_PATCH = 16;
    public static final int MODE_HEAL = 17;
    public static final int MODE_TONE = 18;
    /** Curva Bezier: puntos que se unen con una curva suave. */
    public static final int MODE_CURVE = 19;
    /** Polilinea: puntos que se unen con lineas rectas. */
    public static final int MODE_POLY = 20;
    /** Difuminar: arrastra y mezcla pixeles siguiendo el dedo. */
    public static final int MODE_SMUDGE = 21;
    /** Borrosidad: desenfoque local solo bajo el pincel. */
    public static final int MODE_BLUR = 22;
    /** Especial: licuar con arrastrar/contraer/expandir/suavizar/restaurar. */
    public static final int MODE_LIQUIFY = 23;
    /** Transformar: mover/escala/giro, perspectiva, malla y puntos/anclajes. */
    public static final int MODE_TRANSFORM = 24;
    /**
     * Marioneta (v8.25): herramienta propia con su boton. Internamente usa la
     * misma sesion de Transformar con el tipo 4 (Transformar sigue con Mover,
     * Perspectiva, Malla y Puntos de anclaje). getMode() devuelve MODE_PUPPET.
     */
    public static final int MODE_PUPPET = 25;
    /** v8.79: Figuras (linea, rectangulo, circulo, elipse, poligono, flecha, bocadillo...). */
    public static final int MODE_SHAPE = 26;

    public static final String[] LABEL_NAMES = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "fondo"};
    public static final int[] LABEL_COLORS = {
            0xFFFF5A5F, 0xFFFFC94A, 0xFF1ED6A0, 0xFF1A9BFF, 0xFFFF4FA3, 0xFFB9794A,
            0xFF8B5CF6, 0xFF3B82F6, 0xFFFB7A1B, 0xFF84CC16, 0xFFF9A8D4, 0xFF8A8A8A
    };
    public static final int BG_LABEL = 12;

    /**
     * Fondos para MIRAR (no se exportan, no son pixeles del PNG): cuadros claros, cuadros
     * oscuros, blanco, negro, verde y (v8.27) gris neutro para revisar bordes y halos.
     */
    public static final int[][] VIEW_BG = {
            {0xFFFFFFFF, 0xFFD6D6D6}, {0xFF4A4A50, 0xFF33333A}, {0xFFFFFFFF, 0xFFFFFFFF},
            {0xFF1A1A1A, 0xFF000000}, {0xFF17C964, 0xFF0E9B4C}, {0xFF808080, 0xFF808080}
    };

    public interface Callback {
        void onBusy(boolean busy);

        void onChanged();

        void onMessage(String msg);

        void onColorPicked(int color);

        void onUndoGesture();

        void onRedoGesture();

        void onLassoCompleted();

        /** La barra de la herramienta debe refrescarse (punto elegido, fijo/suelto...). */
        default void onToolStateChanged() {}

        /** v8.76: se uso un lapiz (S Pen u otro) por primera vez. */
        default void onStylusDetected() {}

        /**
         * v8.28: se va a pintar color en una capa Normal vacia encima de un dibujo en blanco
         * y negro; en Normal el color TAPA las tramas y grises. La app pregunta (una vez por capa).
         */
        default void onSuggestMultiply(Layer l) {}
    }

    // ---- v8.28: colorear manga sin tapar tramas ni grises ----
    private final java.util.WeakHashMap<Layer, Boolean> multiplyAsked = new java.util.WeakHashMap<Layer, Boolean>();
    private boolean suggestMultiply = true;

    public void setSuggestMultiply(boolean on) { suggestMultiply = on; }
    public boolean isSuggestMultiply() { return suggestMultiply; }

    /**
     * Si conviene Multiplicar: capa Normal vacia (no Tinta/Referencia), color con matiz,
     * y debajo un dibujo visible casi todo gris con tinta oscura (manga B/N).
     */
    public boolean shouldSuggestMultiply(Layer l) {
        if (project == null || l == null || project.mangaMode || l.mode != Layer.MODE_NORMAL) return false;
        if (l.role == Layer.ROLE_INK || l.reference || l.alphaLock) return false;
        int pc = paintColor;
        int mx = Math.max((pc >> 16) & 255, Math.max((pc >> 8) & 255, pc & 255));
        int mn = Math.min((pc >> 16) & 255, Math.min((pc >> 8) & 255, pc & 255));
        if (mx - mn < 40) return false;                      // blanco, negro o gris: no es "color"
        int idx = project.layers.indexOf(l);
        if (idx <= 0) return false;
        int[] lp = l.px();
        for (int i = 0; i < lp.length; i += 7) if ((lp[i] >>> 24) != 0) return false;   // ya tiene pintura
        int gray = 0, opaque = 0, dark = 0;
        for (int k = 0; k < idx; k++) {
            Layer b = project.layers.get(k);
            if (!b.visible || b.opacity <= 0) continue;
            int[] bp = b.px();
            for (int i = 0; i < bp.length; i += 13) {
                int c = bp[i];
                if ((c >>> 24) < 200) continue;
                opaque++;
                int r = (c >> 16) & 255, g = (c >> 8) & 255, bb = c & 255;
                int sx = Math.max(r, Math.max(g, bb)) - Math.min(r, Math.min(g, bb));
                if (sx < 24) gray++;
                if ((r * 77 + g * 151 + bb * 28) >> 8 < 80) dark++;
            }
        }
        return opaque > 200 && gray * 100 >= opaque * 95 && dark * 100 >= opaque;
    }

    private int pendingFillX = -1, pendingFillY = -1;

    /** v8.28: despues de responder "Usar Multiplicar" o "Dejar Normal": hace el relleno pendiente. */
    public void resumeSuggestedFill() {
        final int x = pendingFillX, y = pendingFillY;
        pendingFillX = pendingFillY = -1;
        if (x < 0 || project == null || mode != MODE_BUCKET) return;
        post(new Runnable() {
            @Override public void run() {
                if (project != null && !busy) runBucket(x, y);
            }
        });
    }

    private void maybeSuggestMultiply(Layer l) {
        if (!needSuggestMultiply(l)) return;
        multiplyAsked.put(l, Boolean.TRUE);
        callback.onSuggestMultiply(l);
    }

    /**
     * Pregunta una sola vez por capa. Si con un color vivo la respuesta es "no hace falta"
     * (dibujo a color, o la capa ya tiene pintura) se recuerda tambien, para no volver a
     * revisar la imagen al empezar cada trazo.
     */
    private boolean needSuggestMultiply(Layer l) {
        if (!suggestMultiply || l == null || callback == null || multiplyAsked.containsKey(l)) return false;
        if (shouldSuggestMultiply(l)) return true;
        int pc = paintColor;
        int mx = Math.max((pc >> 16) & 255, Math.max((pc >> 8) & 255, pc & 255));
        int mn = Math.min((pc >> 16) & 255, Math.min((pc >> 8) & 255, pc & 255));
        if (mx - mn >= 40 && project != null && !project.mangaMode) multiplyAsked.put(l, Boolean.FALSE);
        return false;
    }

    private Project project;
    private UndoManager undo;
    private Callback callback;
    /** Ultima capa normal elegida; permite crear una parte aunque ahora este activa Seleccion. */
    private Layer lastNormalLayer;

    // pantalla
    private Bitmap display;
    private float dispScale = 1f;
    private Bitmap overlay, markersOverlay;
    private int ovScale = 1;
    private final Matrix view = new Matrix();
    private final Matrix inverse = new Matrix();
    private final Matrix transformMatrix = new Matrix();
    private final float[] point = new float[2];
    private ScaleGestureDetector scaleDetector;
    private int insetTop, insetBottom;
    private int viewBg = 0;

    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ovPaint = new Paint();
    private final Paint lassoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wirePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint aimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePreview = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghostPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint transformPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint transformGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint transformAnchorFixedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint transformAnchorMovePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint transformAnchorEdgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ajustes de herramienta
    private int mode = MODE_PAINT;
    private float brushRadius = 20f;
    /**
     * v8.27: borde DURO de fabrica (1 = antialias de ~1 px). Antes 0,7: con radio 20
     * el borde era una rampa de 6 px y el color plano salia borroso. La brocha suave
     * es un pincel aparte ("Brocha suave") que el usuario elige.
     */
    private float hardness = 1f;
    private float brushOpacity = 1f;
    private int paintColor = 0xFFE05A5A;
    private int tolerance = 28, softness = 24, colorMode = ColorDist.RGB;
    private float expansion = 1.5f;
    private boolean gapOn = false;
    private int gapRadius = 4;
    private boolean wandGlobal = false, useBarrier = false, subtract = false, smart = false;
    private float stabilizer = 0f;
    private boolean aimOn = false;
    private float aimDx = 0f, aimDy = -110f;
    private boolean bgOnce = true;
    private boolean bgBucket = true;
    private int bgLimit = 0;
    private int bgTolerance = 46, bgSoftness = 42;
    private boolean protectOn = false;
    private int protectColor = 0;
    private int markerLabel = 1, gapClose = 2;
    private boolean cloneMirror = false;
    private float cloneAngle = 0f;
    private boolean busy = false;

    // efectos de pincel: se procesan solo dentro del disco afectado
    private float effectStrength = 0.32f;
    /** Suavidad propia de Especial/Licuar. 0 = concentrado, 1 = transicion muy suave. */
    private float effectSoftness = 0.72f;
    /** 0 arrastrar, 1 contraer, 2 expandir, 3 suavizar, 4 restaurar. */
    private int liquifyType = 0;
    private int[] effectTmp;
    // Bloques de 64x64 del respaldo local de Difuminar/Borrosidad/Especial.
    private static final int LIQUIFY_TILE = 64;
    // Especial v8.22: motor propio en otro hilo (core/LiquifySession). Este View
    // solo envia el recorrido del dedo y copia a la capa los bloques terminados.
    // Campo inverso compuesto correctamente + B-spline + muestreo con antialiasing.
    private com.pacco.animecut.core.LiquifySession liquifySession;
    private Layer liquifySessionLayer;
    private int liquifySessionVersion;
    /** Ultimo id de trazo enviado al motor. */
    private int liquifyStrokeId;
    /** Trazo cuyos bloques se aplican a la capa (0 = ninguno). */
    private int liquifyApplyId;
    /** Trazo terminado que espera ser confirmado en el historial (0 = ninguno). */
    private int liquifyPendingCommit;
    /** Hora (uptimeMillis) del evento tactil que se esta procesando. */
    private long liquifyEventTime;
    private final Rect liquifyAppliedRect = new Rect();
    private boolean liquifyAppliedValid;
    private final Rect liquifyTmpRect = new Rect();
    private final int[] liquifyTileRect = new int[4];
    private boolean liquifyFrameScheduled;
    /** Secciones visibles en Perfetto/System Trace: campo, render y copia de bloques. */
    private static final com.pacco.animecut.core.LiquifySession.Tracer LIQUIFY_TRACER =
            new com.pacco.animecut.core.LiquifySession.Tracer() {
                @Override public void begin(String section) { android.os.Trace.beginSection(section); }
                @Override public void end() { android.os.Trace.endSection(); }
            };
    private final java.util.concurrent.atomic.AtomicBoolean liquifyWake =
            new java.util.concurrent.atomic.AtomicBoolean();
    private static final java.util.concurrent.ThreadFactory LIQUIFY_THREADS =
            new java.util.concurrent.ThreadFactory() {
                @Override public Thread newThread(final Runnable r) {
                    return new Thread(new Runnable() {
                        @Override public void run() {
                            // Prioridad de dibujo: el motor no compite con tareas de fondo.
                            try {
                                android.os.Process.setThreadPriority(
                                        android.os.Process.THREAD_PRIORITY_DISPLAY);
                            } catch (Throwable ignored) { }
                            r.run();
                        }
                    }, "PaintZeta-Especial");
                }
            };

    // Respaldo LOCAL del trazo para Difuminar/Borrosidad/Especial. Antes se copiaba
    // la capa completa al tocar el lienzo (varios MB en 2K/4K) y eso provocaba el
    // tiron inicial. Ahora solo se guardan los bloques que realmente toca el pincel.
    private final SparseArray<int[]> effectStrokeBackupTiles = new SparseArray<int[]>();
    private Layer effectStrokeBackupLayer;
    private boolean effectStrokeBackupFailed;

    // Seleccion: respaldo por bloques, igual que las capas. Antes cada trazo azul
    // copiaba w*h bytes aunque solo se tocara una zona pequena.
    private final SparseArray<byte[]> selectionStrokeBackupTiles = new SparseArray<byte[]>();
    private boolean selectionStrokeBackupFailed;

    // Buffers pequenos reutilizados por Borrosidad. Evitan crear arreglos y reducen
    // el desenfoque 3x3 de 9 lecturas por pixel a una suma vertical + horizontal.

    // buffers que se reutilizan
    private byte[] scratch, selBackup, gapBarrier, gradient, markers, repairLines;
    private int[] pxBackup;
    // Reutilizados por Borrar fondo para no crear arreglos en cada movimiento del dedo.
    private byte[] bgSeen, dilMask;
    private int[] bgStack;
    /** Cuanto se pinto ya cada pixel en este trazo, para que repasar no aclare. */
    private byte[] cov;

    // toque
    private final Handler handler = new Handler(Looper.getMainLooper());
    private float downX, downY, lastSX, lastSY;
    private long downTime, strokeStart;
    private boolean pendingStroke, pendingTap, multi, drawing, panning, midValid;
    private float tapX, tapY, lastMidX, lastMidY, lastAngle, lastPanX, lastPanY;
    private float lastPinchDistance;
    private int gestureMax;
    private float gestureMoved;
    /** v8.55: cuanto se movio el dedo que mas se movio en un gesto de varios dedos (px de pantalla). */
    private float multiMoved;
    private final float[] ptrStartX = new float[10], ptrStartY = new float[10];

    private void markPointerStart(MotionEvent e, int idx) {
        int id = e.getPointerId(idx);
        if (id >= 0 && id < 10) { ptrStartX[id] = e.getX(idx); ptrStartY[id] = e.getY(idx); }
    }

    private void trackMultiMove(MotionEvent e) {
        for (int i = 0; i < e.getPointerCount(); i++) {
            int id = e.getPointerId(i);
            if (id < 0 || id >= 10) continue;
            float d = (float) Math.hypot(e.getX(i) - ptrStartX[id], e.getY(i) - ptrStartY[id]);
            if (d > multiMoved) multiMoved = d;
        }
    }
    private float touchSlop;
    private final Runnable startPending = new Runnable() {
        @Override
        public void run() {
            if (pendingStroke && !multi) beginPending();
        }
    };

    // trazo
    private float lastX, lastY, smoothX, smoothY;
    private boolean smoothInit;
    private Rect strokeRect;
    private Layer strokeLayer;
    private boolean strokeOnSelection, strokeErase, selectionActive;
    private int painted, bgRef, refColor;
    private boolean showRing;
    private float ringX, ringY;

    // lazo, tijeras, magnetico, linea
    private final Path lasso = new Path();
    private LiveWire wire;
    private final Path wirePath = new Path();
    private int[] livePath;
    private int firstAnchor = -1;
    private boolean wireStarted;
    private final ArrayList<float[]> linePts = new ArrayList<float[]>();

    // clonar
    private boolean cloneSrcSet;
    private float cloneSrcX, cloneSrcY, cloneDestX, cloneDestY;

    // mover
    private int[] moveBackup;
    private byte[] moveSelBackup;
    private float moveFromX, moveFromY;
    private int moveDx, moveDy;
    private long lastMoveApply;

    // transformar: el original se aparta una sola vez y se dibuja como previsualizacion
    private boolean transformActive;
    private boolean transformApplying;
    /** Muestra la malla al instante mientras se prepara el bitmap pesado. */
    private boolean transformPreparing;
    /** 0 mover/escala/giro, 1 perspectiva (Transformar); 2 malla, 3 marioneta (Deformar). */
    private int transformType = 0;
    private int transformMeshX = 4, transformMeshY = 4;
    /** Puntos: [origenX, origenY, actualX, actualY, tipo(0=fijo,1=movil)]. */
    private final ArrayList<float[]> transformAnchors = new ArrayList<float[]>();
    private int transformAnchorNode = -1;
    private int transformAnchorAddMode = 1;
    private float transformAnchorRadius = 260f;
    private float transformAnchorStrength = 1f;
    // Historial interno de Puntos de anclaje (Deshacer dentro de la sesion)
    private final ArrayList<ArrayList<float[]>> anchorUndo = new ArrayList<ArrayList<float[]>>();
    private final ArrayList<ArrayList<float[]>> anchorRedo = new ArrayList<ArrayList<float[]>>();
    private boolean anchorDragStarted, anchorGesturePushed;
    private boolean transformNavMidValid;
    private float transformNavMidX, transformNavMidY;
    /** Suavidad real de la malla: 0 = lineal, 1 = Catmull-Rom muy suave. */
    private float transformMeshSmoothness = 0.72f;
    private int transformRenderMeshX, transformRenderMeshY;
    private float[] transformRenderVerts;
    private boolean transformRenderDirty = true;
    private Layer transformLayer;
    private int[] transformBackup;
    private byte[] transformSelectionBackup;
    private Bitmap transformBitmap, transformMaskBitmap;
    private Rect transformSrcRect;
    private float transformTx, transformTy, transformScale = 1f, transformRotation;
    private float[] transformVerts, transformVertsStart;
    // Reutilizados durante gestos/dibujo para no generar basura por frame.
    private final float[] transformPoint0 = new float[2];
    private final float[] transformPoint1 = new float[2];
    private final float[] transformAffineCorners = new float[8];
    private final float[] transformPerspectiveSrc = new float[8];
    private int transformNode = -1;
    private float transformDownX, transformDownY, transformStartTx, transformStartTy;
    private float transformGestureDist, transformGestureAngle, transformGestureMidX, transformGestureMidY;
    private float transformStartScale, transformStartRotation, transformGestureStartTx, transformGestureStartTy;

    // ---- Deformar (v8.25) ----
    /** true cuando el usuario eligio la herramienta Deformar (Malla / Marioneta). */
    private boolean puppetTool;
    /** Tipo a abrir cuando termine de aplicarse la deformacion actual. */
    private int pendingTypeAfterApply = -1;
    // Malla: historial interno y control de pliegues
    private final ArrayList<float[]> meshUndo = new ArrayList<float[]>();
    private final ArrayList<float[]> meshRedo = new ArrayList<float[]>();
    private boolean meshDragStarted;
    private int meshFoldBase;
    private float meshNodeStartX, meshNodeStartY;
    private boolean meshLimitedHud;
    // Marioneta: motor ARAP en core/PuppetSession
    private PuppetSession puppet;
    private boolean puppetBuilding;
    private int puppetSel = -1;
    /**
     * v8.27: la malla NO se dibuja de fabrica (la de v8.25-8.26 llenaba la pantalla de
     * lineas). El motor la sigue usando igual; "Ver malla" solo la muestra.
     */
    private boolean puppetAddMode = true, puppetShowMesh = true;   // v8.33: la malla se ve de fabrica
    private int puppetDrag = -1;
    private boolean puppetRotating, puppetGesture, puppetTap, puppetMoved;
    /** v8.59: distancia del anillo de giro al punto (dp). */
    private static final float PUPPET_RING_DP = 50f;
    private float puppetOffX, puppetOffY, puppetDownX, puppetDownY, puppetDownSX, puppetDownSY;
    private float puppetRot0, puppetAng0;
    private PuppetSession.Snap puppetGestureSnap;
    private int[] puppetEdges;
    private float[] puppetLineBuf;
    private Bitmap puppetPreview;
    private final RectF puppetPreviewRect = new RectF();
    private LatestWorker puppetWorker;
    private int puppetSeq, puppetShownSeq;
    private long puppetLimitedHudAt;
    private int puppetRigidity = ArapSolver.NORMAL, puppetDensity = 1, puppetExpansion = 2;
    private boolean puppetFoldGuard = false;   // v8.68: sin topes por defecto (se prende en Opciones)
    private float puppetStiffCells = 3f;
    private boolean puppetByParts = true;
    private float puppetReachCells = 12f;
    private final Paint puppetMeshPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint puppetMeshShadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint puppetBadPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint puppetRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint puppetZonePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Una pieza no solapada del estado anterior a Transformar. */
    private static final class TransformUndoPiece {
        final Rect r;
        final int[] layer;
        final Bitmap layerBitmap;
        final byte[] selection;
        TransformUndoPiece(Rect r, int[] layer, byte[] selection) {
            this.r = r;
            this.layer = layer;
            this.layerBitmap = null;
            this.selection = selection;
        }
        TransformUndoPiece(Rect r, Bitmap layerBitmap) {
            this.r = r;
            this.layer = null;
            this.layerBitmap = layerBitmap;
            this.selection = null;
        }
    }

    private static final class TransformApplyResult {
        final ArrayList<TransformUndoPiece> undoPieces = new ArrayList<TransformUndoPiece>();
        Throwable error;
    }

    // cuentagotas rapido
    private boolean quickPick, quickArmed;
    private float pickX, pickY;
    private int pickColor;
    private Runnable quickRunnable;

    // avisos
    private String hud;
    private long hudUntil;
    private boolean hintedHidden;
    private Rect lastFillRect;
    private byte[] previewBackup;

    public CanvasView(Context c) {
        super(c);
        init(c);
    }

    public CanvasView(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        float d = getResources().getDisplayMetrics().density;
        touchSlop = 7f * d;
        aimDy = -46f * d;
        ovPaint.setFilterBitmap(false);
        lassoPaint.setStyle(Paint.Style.STROKE);
        lassoPaint.setColor(0xFF3D7BFF);
        lassoPaint.setStrokeWidth(3f);
        markPaint.setStyle(Paint.Style.STROKE);
        markPaint.setColor(0xFFFF5252);
        markPaint.setStrokeWidth(3f);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(0xCC888888);
        ringPaint.setStrokeWidth(2f);
        hudBg.setColor(0xCC000000);
        hudText.setColor(Color.WHITE);
        hudText.setTextSize(d * 14f);
        hudText.setTextAlign(Paint.Align.CENTER);
        pinEdge.setColor(0xFFF0F0F0);
        wirePaint.setStyle(Paint.Style.STROKE);
        wirePaint.setColor(0xFF32D74B);
        wirePaint.setStrokeWidth(3f);
        loupeEdge.setStyle(Paint.Style.STROKE);
        loupeEdge.setColor(Color.WHITE);
        loupeEdge.setStrokeWidth(3f * d);
        aimPaint.setStyle(Paint.Style.STROKE);
        aimPaint.setColor(0xFFFF3B30);
        aimPaint.setStrokeWidth(2f * d);
        linePreview.setStyle(Paint.Style.STROKE);
        linePreview.setColor(0xFFFF9F0A);
        linePreview.setStrokeWidth(3f * d);
        linePreview.setStrokeCap(Paint.Cap.ROUND);
        ghostPaint.setAlpha(150);
        transformGridPaint.setStyle(Paint.Style.STROKE);
        transformGridPaint.setStrokeWidth(2f * d);
        transformGridPaint.setColor(0xFFEFEFEF);
        transformAnchorFixedPaint.setStyle(Paint.Style.FILL);
        transformAnchorFixedPaint.setColor(0xFF42A5F5);
        transformAnchorMovePaint.setStyle(Paint.Style.FILL);
        transformAnchorMovePaint.setColor(0xFFFFA726);
        transformAnchorEdgePaint.setStyle(Paint.Style.STROKE);
        transformAnchorEdgePaint.setStrokeWidth(2f * d);
        transformAnchorEdgePaint.setColor(0xFFFFFFFF);
        puppetMeshPaint.setStyle(Paint.Style.STROKE);
        // v8.34: malla celeste con sombra oscura: se ve sobre piel, pelo blanco y cuadros
        puppetMeshPaint.setColor(0xD93DD6FF);
        puppetMeshShadow.setStyle(Paint.Style.STROKE);
        puppetMeshShadow.setColor(0x73000000);
        puppetBadPaint.setStyle(Paint.Style.STROKE);
        puppetBadPaint.setColor(0xFFFF3B30);
        puppetRingPaint.setStyle(Paint.Style.STROKE);
        puppetRingPaint.setColor(0xCCFFFFFF);
        puppetZonePaint.setStyle(Paint.Style.FILL);
        puppetZonePaint.setColor(0x3366BB6A);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector det) {
                float f = det.getScaleFactor();
                float cur = currentScale();
                if (cur * f < 0.03f || cur * f > 60f) return true;
                view.postScale(f, f, det.getFocusX(), det.getFocusY());
                showHud(Math.round(currentScale() * dispScale * 100f) + "%");
                return true;
            }
        });
    }

    // ==================================================================
    // Proyecto
    // ==================================================================

    public void setCallback(Callback cb) {
        callback = cb;
    }

    public void setProject(Project p) {
        belowEpoch++;
        belowDisp.drop();
        belowDetail.drop();
        bgSnap = null;
        bgSnapLayer = null;
        bgNoSrcLayer = null;
        zoneKind = -1;            // v8.40: se vuelve a detectar el tipo de dibujo en la obra nueva
        hintedZoneKind = false;
        zoneSel = -1;
        invalidateBgAnalysis();
        releaseBgEngine();
        clearPreviewState();
        mangaLines = null;
        mangaLinesKey = null;
        fillPreviewRef = null;
        if (protectBmp != null && !protectBmp.isRecycled()) protectBmp.recycle();
        protectBmp = null;
        dropDetail();
        clearTransformState(true);
        if (undo != null) undo.clear();
        stopCompare();
        setPreviewOver(null);
        project = p;
        undo = p == null ? null : new UndoManager(p);
        // v8.39: abrir la obra con el fondo de vista con el que se dejo
        if (p != null) {
            if (p.viewBg >= 0 && p.viewBg < VIEW_BG.length) viewBg = p.viewBg;
            else p.viewBg = viewBg;
            com.pacco.animecut.core.Thumbs.checkA = VIEW_BG[viewBg][0];
            com.pacco.animecut.core.Thumbs.checkB = VIEW_BG[viewBg][1];
        }
        lastNormalLayer = p != null && p.active >= 0 && p.active < p.layers.size()
                ? p.layers.get(p.active) : (p != null && !p.layers.isEmpty() ? p.layers.get(0) : null);
        scratch = selBackup = gapBarrier = gradient = markers = repairLines = null;
        pxBackup = null;
        bgSeen = dilMask = null;
        bgStack = null;
        wire = null;
        cloneSrcSet = false;
        subtract = false;
        hintedHidden = false;
        mode = MODE_PAINT;
        lasso.reset();
        wirePath.reset();
        linePts.clear();
        if (markersOverlay != null) markersOverlay.recycle();
        markersOverlay = null;
        fitted = false;
        shapePts.clear();
        shapeSel = -1;
        shapeDrag = -1;
        geo = null;
        geoPrev = null;
        geoSnap = null;
        geoGrab = G_NONE;
        geoDownOn = false;
        dropLiquifySession();
        clearEffectStrokeBackup();
        clearSelectionStrokeBackup();
        effectTmp = null;
        blurSrc = blurOut = null;
        blurTmp = null;
        if (p != null) {
            buildDisplay();
            buildOverlay();
            // se ajusta antes del primer dibujo: asi no se ve un salto de zoom al abrir
            if (getWidth() > 0) fit();
            else post(new Runnable() {
                @Override
                public void run() {
                    fit();
                }
            });
        }
        invalidate();
    }

    /** true cuando la imagen ya quedo ajustada a la pantalla; antes no se dibuja. */
    private boolean fitted;

    /** v8.27: hay un calculo en curso (balde, borrar fondo, aplicar...). */
    public boolean isBusy() { return busy; }

    /** v8.27: punto del lienzo -> punto de pantalla (prueba de rendimiento en la app). */
    public float[] imageToScreen(float ix, float iy) {
        float[] p = {ix, iy};
        view.mapPoints(p);
        return p;
    }

    /** v8.27: elegir un punto de Marioneta (prueba de rendimiento en la app). */
    public void selectPuppetPinForBench(int i) {
        if (isPuppetReady() && i >= 0 && i < puppet.pinCount()) puppetSel = i;
    }

    public Project getProject() {
        // Quien lea el proyecto (guardar, exportar, capas) ve el ultimo trazo de
        // Especial ya confirmado, aunque el motor acabara de terminarlo.
        if (!drawing && liquifyPendingCommit != 0 && Looper.myLooper() == Looper.getMainLooper())
            finishLiquifyCommitNow();
        return project;
    }

    /** La capa donde se pinta, o null si esta activa la capa de seleccion. */
    private Layer target() {
        return project == null ? null : project.activeLayer();
    }

    private boolean paintsSelection() {
        return project != null && project.isSelectionLayerActive();
    }

    /** Revisa que haya una capa normal elegida y visible. */
    private Layer needLayer() {
        Layer t = target();
        if (t == null) {
            msg("Toca una capa en Capas: ahora esta elegida la capa de seleccion");
            return null;
        }
        if (refuseLocked(t)) return null;
        if (!t.visible && !hintedHidden) {
            hintedHidden = true;
            showHud("Esa capa esta oculta: prendele el ojo en Capas");
        }
        return t;
    }

    // ==================================================================
    // Pantalla
    // ==================================================================

    private void buildDisplay() {
        asyncGen++;
        spare = null;
        Bitmap old = display;
        float oldScale = dispScale;
        int max = Math.max(project.w, project.h);
        float s = max > 2048 ? max / 2048f : 1f;
        int dw = Math.max(1, Math.round(project.w / s)), dh = Math.max(1, Math.round(project.h / s));
        display = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        dispScale = (float) project.w / dw;
        composeRegion(0, 0, dw, dh);
        boolean sameSize = old != null && !old.isRecycled() && old.getWidth() == dw && old.getHeight() == dh
                && oldScale == dispScale && detailRect != null
                && detailRect.right <= project.w && detailRect.bottom <= project.h;
        if (old != null && !old.isRecycled()) old.recycle();
        if (sameSize) staleDetail();
        else invalidateDetail();
        scheduleDetail();
    }

    public void refreshDisplay() {
        if (project == null) return;
        belowEpoch++;
        buildDisplay();
        invalidate();
    }

    // ------------------------------------------------------------------
    // Vista armada en segundo plano: ojo, opacidad, orden de capas y fondo
    // ya no congelan la pantalla. Se arma en otro Bitmap y se cambia de golpe.
    // ------------------------------------------------------------------

    private static final java.util.concurrent.ExecutorService COMPOSE =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private int asyncGen;
    private boolean asyncRunning, asyncAgain;
    private Bitmap spare;

    public void refreshDisplayAsync() {
        if (project == null || display == null) return;
        belowEpoch++;
        if (asyncRunning) {
            asyncAgain = true;
            return;
        }
        startAsyncCompose();
    }

    private void startAsyncCompose() {
        final int dw = display.getWidth(), dh = display.getHeight();
        Bitmap t = spare;
        spare = null;
        if (t == null || t.isRecycled() || t.getWidth() != dw || t.getHeight() != dh) {
            try {
                t = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
            } catch (OutOfMemoryError e) {
                refreshDisplay();
                return;
            }
        }
        final Bitmap target = t;
        final LayerSrc[] src = layerSources();
        final int[] bg = VIEW_BG[viewBg];
        final float ds = dispScale;
        final int pw = project.w, ph = project.h;
        final Project owner = project;
        final int gen = ++asyncGen;
        final float[] bake = dispGrayQ == null ? null : dispGrayParams;
        asyncRunning = true;
        asyncAgain = false;
        COMPOSE.execute(new Runnable() {
            @Override
            public void run() {
                boolean ok = true;
                try {
                    composeInto(target, src, bg, ds, pw, ph, 0, 0, dw, dh);
                } catch (Throwable e) {
                    ok = false;
                }
                final boolean fine = ok;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        asyncRunning = false;
                        if (fine && owner == project && gen == asyncGen && display != null
                                && display.getWidth() == dw && display.getHeight() == dh) {
                            final Bitmap old = display;
                            display = target;
                            dispBake = bake;
                            staleDetail();
                            scheduleDetail();
                            invalidate();
                            // el viejo se reusa cuando ya salio de pantalla
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (old != display && !old.isRecycled()) spare = old;
                                }
                            }, 80);
                        } else if (target != display && !target.isRecycled()) {
                            spare = target;
                        }
                        if (asyncAgain && project != null && display != null) {
                            asyncAgain = false;
                            startAsyncCompose();
                        }
                    }
                });
            }
        });
    }

    /** Como layersChanged, pero sin congelar: para ojo, opacidad y orden. */
    public void layersChangedAsync() {
        if (project == null) return;
        project.markDirty();
        wire = null;
        refreshDisplayAsync();
        changed();
    }

    /** Pasa la capa de la posicion from a la posicion to (arrastrar en Capas). */
    public void moveLayer(int from, int to) {
        if (project == null) return;
        int n = project.layers.size();
        if (from < 0 || to < 0 || from >= n || to >= n || from == to) return;
        undo.setLabel("Ordenar capas");
        undo.recordStruct();
        Layer l = project.layers.remove(from);
        project.layers.add(to, l);
        project.active = to;
        layersChangedAsync();
    }

    /** Todas las capas visibles, una encima de otra, sobre el fondo de vista. */
    private void composeRegion(int x0, int y0, int x1, int y1) {
        if (display == null || project == null) return;
        if (asyncRunning) asyncAgain = true;
        long t0 = System.nanoTime();
        if (!drawing) belowEpoch++;
        if (!(drawing && composeWithBelow(x0, y0, x1, y1)))
        {
            composeInto(display, layerSources(), VIEW_BG[viewBg], dispScale, project.w, project.h, x0, y0, x1, y1);
            dispBake = dispGrayQ == null ? null : dispGrayParams;
        }
        com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.COMPOSE, System.nanoTime() - t0);
    }

    // ---------------- v8.53: cache de "lo de abajo" (como Krita / las apps de pintura) ----------------
    // Mientras pintas o borras en UNA capa, las capas de abajo no cambian: se mezclan una sola vez
    // (por bloques de 64 px, solo donde pasa el dedo) y cada toque mezcla nada mas la capa activa y
    // las de arriba. Antes cada toque volvia a mezclar TODAS las capas. Cualquier otro cambio
    // (otra capa, ojo, opacidad, modo, deshacer, fondo) sube belowEpoch y la cache se rehace.
    private long belowEpoch;
    private static final int BT = 64;

    private static final class BelowCache {
        int[] px;
        boolean[] valid;
        int ox, oy, cw, ch, tx;
        long key = Long.MIN_VALUE;

        boolean prepare(long k, int ox, int oy, int cw, int ch) {
            if (k == key && px != null && this.ox == ox && this.oy == oy && this.cw == cw && this.ch == ch) return true;
            try {
                if (px == null || px.length < cw * ch) px = new int[cw * ch];
            } catch (OutOfMemoryError e) {
                px = null;
                key = Long.MIN_VALUE;
                return false;
            }
            this.ox = ox; this.oy = oy; this.cw = cw; this.ch = ch;
            tx = (cw + BT - 1) / BT;
            int n = tx * ((ch + BT - 1) / BT);
            if (valid == null || valid.length < n) valid = new boolean[n];
            else java.util.Arrays.fill(valid, false);
            key = k;
            return true;
        }

        void drop() { px = null; valid = null; key = Long.MIN_VALUE; }
    }

    private final BelowCache belowDisp = new BelowCache(), belowDetail = new BelowCache();

    /** Indice de la capa del trazo si la cache sirve (capa sin flecha, con algo debajo); si no, -1. */
    private int belowSplit(Layer[] ls) {
        Layer t = strokeLayer;
        if (t == null || t.clip) return -1;
        for (int i = 1; i < ls.length; i++) if (ls[i] == t) return i;
        return -1;
    }

    private long belowKey(Layer[] ls, int a) {
        long k = belowEpoch;
        k = k * 31 + a;
        k = k * 31 + ls.length;
        k = k * 31 + viewBg;
        k = k * 31 + System.identityHashCode(dispGrayQ);
        k = k * 31 + Float.floatToIntBits(dispScale);
        for (int i = 0; i < a; i++) {
            Layer l = ls[i];
            k = k * 31 + System.identityHashCode(l);
            k = k * 31 + (l.visible ? 1 : 2);
            k = k * 31 + l.opacity;
            k = k * 31 + l.mode * 3 + (l.clip ? (l.clipOut ? 2 : 1) : 0);
            k = k * 31 + l.hue * 7 + l.sat * 13 + l.lit * 17;
            k = k * 31 + System.identityHashCode(l.denseOrNull());
            k = k * 31 + System.identityHashCode(l.packedOrNull());
        }
        return k;
    }

    private static LayerSrc[] sourcesOf(Layer[] ls, int from, int to, int w, int h) {
        int n = to - from;
        Layer[] sub = new Layer[n];
        int[] ops = new int[n], modes = new int[n];
        boolean[] vs = new boolean[n], clips = new boolean[n];
        for (int k = 0; k < n; k++) {
            Layer l = ls[from + k];
            sub[k] = l;
            ops[k] = l.opacity;
            vs[k] = l.visible;
            modes[k] = l.mode;
            clips[k] = l.clip;
        }
        return buildSources(sub, ops, vs, modes, clips, w, h, true);
    }

    /** La vista reducida usando la cache de abajo. false = no sirve (se hace lo de siempre). */
    private boolean composeWithBelow(int x0, int y0, int x1, int y1) {
        Layer[] ls = project.layers.toArray(new Layer[0]);
        int a = belowSplit(ls);
        if (a <= 0) return false;
        int dw = display.getWidth(), dh = display.getHeight();
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(dw, x1); y1 = Math.min(dh, y1);
        if (x0 >= x1 || y0 >= y1) return true;
        long key = belowKey(ls, a) * 31 + System.identityHashCode(display);
        if (!belowDisp.prepare(key, 0, 0, dw, dh)) return false;
        int w = project.w, h = project.h;
        int[] bg = VIEW_BG[viewBg];
        LayerSrc[] below = null;
        BelowCache bc = belowDisp;
        for (int ty = y0 / BT; ty <= (y1 - 1) / BT; ty++) {
            for (int tx = x0 / BT; tx <= (x1 - 1) / BT; tx++) {
                int ti = ty * bc.tx + tx;
                if (bc.valid[ti]) continue;
                if (below == null) below = sourcesOf(ls, 0, a, w, h);
                int bx1 = Math.min(dw, tx * BT + BT), by1 = Math.min(dh, ty * BT + BT);
                for (int y = ty * BT; y < by1; y++) {
                    int sy = Math.min(h - 1, (int) (y * dispScale));
                    int o = y * dw;
                    for (int x = tx * BT; x < bx1; x++) {
                        int sx = Math.min(w - 1, (int) (x * dispScale));
                        int c = (((x / 8) + (y / 8)) & 1) == 0 ? bg[0] : bg[1];
                        bc.px[o + x] = over(below, c, sx, sy, w);
                    }
                }
                bc.valid[ti] = true;
            }
        }
        LayerSrc[] top = sourcesOf(ls, a, ls.length, w, h);
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(h - 1, (int) (y * dispScale));
            int o = y * dw;
            for (int x = x0; x < x1; x++) {
                int sx = Math.min(w - 1, (int) (x * dispScale));
                row[x - x0] = over(top, bc.px[o + x], sx, sy, w);
            }
            display.setPixels(row, 0, rw, x0, y, rw, 1);
        }
        return true;
    }

    /** El detalle (zoom, resolucion real) con la cache de abajo. false = no sirve. */
    private boolean detailWithBelow(Rect r) {
        if (!drawing || detailRect == null) return false;
        if ((long) detailRect.width() * detailRect.height() > 3_000_000L) return false;
        Layer[] ls = project.layers.toArray(new Layer[0]);
        int a = belowSplit(ls);
        if (a <= 0) return false;
        long key = belowKey(ls, a) * 31 + System.identityHashCode(detail);
        BelowCache bc = belowDetail;
        if (!bc.prepare(key, detailRect.left, detailRect.top, detailRect.width(), detailRect.height())) return false;
        int w = project.w;
        int[] bg = VIEW_BG[viewBg];
        float cs = 8f * dispScale;
        LayerSrc[] below = null;
        int lx0 = r.left - bc.ox, ly0 = r.top - bc.oy, lx1 = r.right - bc.ox, ly1 = r.bottom - bc.oy;
        for (int ty = ly0 / BT; ty <= (ly1 - 1) / BT; ty++) {
            for (int tx = lx0 / BT; tx <= (lx1 - 1) / BT; tx++) {
                int ti = ty * bc.tx + tx;
                if (bc.valid[ti]) continue;
                if (below == null) below = sourcesOf(ls, 0, a, w, project.h);
                int bx1 = Math.min(bc.cw, tx * BT + BT), by1 = Math.min(bc.ch, ty * BT + BT);
                for (int y = ty * BT; y < by1; y++) {
                    int iy = y + bc.oy, o = y * bc.cw;
                    for (int x = tx * BT; x < bx1; x++) {
                        int ix = x + bc.ox;
                        int c = ((((int) (ix / cs)) + ((int) (iy / cs))) & 1) == 0 ? bg[0] : bg[1];
                        bc.px[o + x] = over(below, c, ix, iy, w);
                    }
                }
                bc.valid[ti] = true;
            }
        }
        LayerSrc[] top = sourcesOf(ls, a, ls.length, w, project.h);
        byte[] sel = project.selection;
        int[] row = new int[r.width()];
        for (int y = r.top; y < r.bottom; y++) {
            int o = (y - bc.oy) * bc.cw - bc.ox;
            for (int x = r.left; x < r.right; x++) {
                int c = over(top, bc.px[o + x], x, y, w);
                int sa = sel[y * w + x] & 0xFF;
                if (sa != 0) c = blendA(c, 0xFF3D7BFF, (sa * 140) / 255);
                row[x - r.left] = c;
            }
            detail.setPixels(row, 0, row.length, r.left - detailRect.left, y - detailRect.top, row.length, 1);
        }
        return true;
    }

    /** Arma la vista en el Bitmap que le des. No toca campos: sirve en segundo plano. */
    private static void composeInto(Bitmap display, LayerSrc[] src, int[] bg, float dispScale, int w, int h,
                                    int x0, int y0, int x1, int y1) {
        int dw = display.getWidth(), dh = display.getHeight();
        x0 = Math.max(0, x0);
        y0 = Math.max(0, y0);
        x1 = Math.min(dw, x1);
        y1 = Math.min(dh, y1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        int cs = 8;
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(h - 1, (int) (y * dispScale));
            for (int x = x0; x < x1; x++) {
                int sx = Math.min(w - 1, (int) (x * dispScale));
                int c = (((x / cs) + (y / cs)) & 1) == 0 ? bg[0] : bg[1];
                row[x - x0] = over(src, c, sx, sy, w);
            }
            display.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    /** Lo que se necesita para leer una capa rapido, dense o recortada. */
    private static final class LayerSrc {
        int[] dense;
        Layer.Packed packed;
        int op;
        int mode;
        boolean clip;
        /** v8.71: recorte invertido (Excluir). */
        boolean clipOut;
        /** v8.26 "Cambiar color" no destructivo (instancia propia por hilo). */
        com.pacco.animecut.core.ColorAdjust adj;
        /** v8.38: B/N de Borrar fondo, solo para la vista (null = color). */
        int[] gray;
        /** base vacia u oculta: siempre transparente. */
        boolean zero;
        int[] rowBuf;
        int rowY = Integer.MIN_VALUE;

        /** Pixel de una capa empacada: se lee de a una fila entera del Bitmap. */
        int get(int sx, int sy) {
            if (zero) return 0;
            Layer.Packed p = packed;
            if (sy < p.y || sy >= p.y + p.h || sx < p.x || sx >= p.x + p.w) return 0;
            if (sy != rowY) {
                if (rowBuf == null) rowBuf = new int[p.w];
                p.row(sy, rowBuf);
                rowY = sy;
            }
            return rowBuf[sx - p.x];
        }
    }

    private LayerSrc[] layerSources() {
        Layer[] ls = project.layers.toArray(new Layer[0]);
        int n = ls.length;
        int[] ops = new int[n], modes = new int[n];
        boolean[] vs = new boolean[n], clips = new boolean[n];
        for (int k = 0; k < n; k++) {
            ops[k] = ls[k].opacity;
            vs[k] = ls[k].visible;
            modes[k] = ls[k].mode;
            clips[k] = ls[k].clip;
        }
        return buildSources(ls, ops, vs, modes, clips, project.w, project.h, true);
    }

    private static int over(LayerSrc[] src, int c, int sx, int sy, int w) {
        int i = sy * w + sx;
        int baseA = -1;
        for (LayerSrc s : src) {
            int col = s.dense != null ? s.dense[i] : s.get(sx, sy);
            if (s.adj != null && col != 0) col = s.adj.apply(col);
            if (s.gray != null && col != 0) col = com.pacco.animecut.core.GrayView.map(col, s.gray);
            int ca = col >>> 24;
            if (s.clip && baseA >= 0) ca = Layer.clipA(ca, baseA, s.clipOut);
            else baseA = ca;
            int a = (ca * s.op) / 255;
            if (a > 0) c = s.mode == 0 ? blendA(c, col, a) : (Project.blend(c, col, s.mode, a) | 0xFF000000);
        }
        return c;
    }

    /**
     * Lista de capas para dibujar: con su modo y recorte. Una capa con recorte
     * sobre una base oculta tampoco se ve. La base oculta igual cuenta como
     * base (con alfa 0) para que sus capas recortadas no se peguen a otra.
     */
    private static LayerSrc[] buildSources(Layer[] ls, int[] ops, boolean[] vs, int[] modes, boolean[] clips,
                                           int w, int h) {
        return buildSources(ls, ops, vs, modes, clips, w, h, false);
    }

    /**
     * v8.38: el gris de B/N se aplica a las CAPAS antes de ponerlas sobre los cuadros del fondo:
     * los cuadros (verde, blanco, negro...) siguen de su color y se ve claro lo ya borrado.
     */
    private static volatile int[] dispGrayQ;
    /**
     * v8.59 B/N al instante: con que cuenta de gris se armo lo que hay en pantalla (null = color).
     * Si solo cambian el contraste o el brillo, la diferencia es una cuenta lineal que la tarjeta
     * grafica aplica AL MOMENTO al dibujar; mientras tanto se vuelve a armar la imagen exacta.
     */
    private static volatile float[] dispGrayParams;
    private float[] dispBake, detailBake, detailBakePending;
    private final android.graphics.ColorMatrix grayDeltaM = new android.graphics.ColorMatrix();

    /** Filtro de color para lo armado con 'bake' para que se vea como el ajuste de ahora (o null). */
    private android.graphics.ColorFilter grayDelta(float[] bake) {
        float[] now = dispGrayParams;
        if (bake == null || now == null || bake == now) return null;
        if (bake[2] != now[2] || bake[3] != now[3] || Math.abs(bake[0]) < 1e-3f) return null;
        float sc = now[0] / bake[0], off = now[1] - bake[1] * sc;
        if (Math.abs(sc - 1f) < 1e-4f && Math.abs(off) < 0.5f) return null;
        grayDeltaM.set(new float[]{sc, 0, 0, 0, off, 0, sc, 0, 0, off, 0, 0, sc, 0, off, 0, 0, 0, 1, 0});
        return new android.graphics.ColorMatrixColorFilter(grayDeltaM);
    }

    private static LayerSrc[] buildSources(Layer[] ls, int[] ops, boolean[] vs, int[] modes, boolean[] clips,
                                           int w, int h, boolean viewGray) {
        ArrayList<LayerSrc> out = new ArrayList<LayerSrc>();
        boolean baseSeen = false, baseHidden = false;
        for (int k = 0; k < ls.length; k++) {
            boolean clipped = clips[k] && baseSeen;
            if (!clipped) {
                baseSeen = true;
                baseHidden = !vs[k] || ops[k] <= 0;
            }
            if (clipped && baseHidden) continue;
            Layer l = ls[k];
            LayerSrc s = new LayerSrc();
            s.op = vs[k] ? ops[k] : 0;
            s.mode = modes[k];
            s.clip = clipped;
            s.clipOut = clipped && l.clipOut;
            s.adj = l.adjuster();
            s.gray = viewGray ? dispGrayQ : null;
            int[] d = l.denseOrNull();
            boolean empty = false;
            if (d != null && d.length == w * h) s.dense = d;
            else {
                s.packed = l.packedOrNull();
                if (s.packed == null) {
                    d = l.denseOrNull();
                    if (d == null || d.length != w * h) empty = true;
                    else s.dense = d;
                } else if (s.packed.empty()) empty = true;
            }
            if (empty || s.op <= 0) {
                // base vacia u oculta: igual marca la base para las recortadas
                if (!clipped) {
                    LayerSrc z = new LayerSrc();
                    z.op = 0;
                    z.dense = null;
                    z.packed = null;
                    z.zero = true;
                    out.add(z);
                }
                continue;
            }
            out.add(s);
        }
        return out.toArray(new LayerSrc[0]);
    }

    // ------------------------------------------------------------------
    // Zoom con la resolucion original: al acercarse se dibuja la zona que se
    // ve directo de las capas, pixel por pixel, en vez de la vista reducida.
    // ------------------------------------------------------------------

    /** Maximo de pixeles del detalle (unos 22 MB). */
    private static final int DETAIL_MAX_PX = 5_500_000;
    private Bitmap detail;
    private Rect detailRect;
    private boolean detailValid, detailBuilding, smoothZoom = true;
    private int detailGen;
    private final Paint detailPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Runnable detailRunnable = new Runnable() {
        @Override
        public void run() {
            buildDetail();
        }
    };

    public void setSmoothZoom(boolean on) {
        smoothZoom = on;
        invalidate();
    }

    public boolean isSmoothZoom() {
        return smoothZoom;
    }

    /** Zona de la imagen que conviene tener en alta: lo visible y un margen. */
    private Rect wantedDetail() {
        if (project == null || dispScale <= 1.01f || getWidth() == 0) return null;
        float sc = currentScale();
        if (sc * dispScale < 1.1f) return null;
        if (!view.invert(inverse)) return null;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        Rect vis = new Rect((int) Math.floor(v.left), (int) Math.floor(v.top),
                (int) Math.ceil(v.right), (int) Math.ceil(v.bottom));
        if (!vis.intersect(0, 0, project.w, project.h)) return null;
        if ((long) vis.width() * vis.height() > DETAIL_MAX_PX) return null;
        // margen grande cuando se puede: asi al moverte ya esta listo
        double area = (double) Math.max(1, v.width()) * Math.max(1, v.height());
        float f = (float) Math.min(2.2, Math.sqrt(DETAIL_MAX_PX / area));
        float mx = Math.max(0, v.width() * (f - 1) / 2f), my = Math.max(0, v.height() * (f - 1) / 2f);
        Rect r = new Rect((int) Math.floor(v.left - mx), (int) Math.floor(v.top - my),
                (int) Math.ceil(v.right + mx), (int) Math.ceil(v.bottom + my));
        if (!r.intersect(0, 0, project.w, project.h)) return null;
        return r;
    }

    /** Solo lo que se ve ahora en pantalla (sin margen). */
    private Rect visibleDetail() {
        if (!view.invert(inverse)) return null;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        Rect r = new Rect((int) Math.floor(v.left) - 2, (int) Math.floor(v.top) - 2,
                (int) Math.ceil(v.right) + 2, (int) Math.ceil(v.bottom) + 2);
        if (!r.intersect(0, 0, project.w, project.h)) return null;
        return r;
    }

    private boolean visibleInside(Rect d) {
        if (d == null || !view.invert(inverse)) return false;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        RectF img = new RectF(0, 0, project.w, project.h);
        if (!v.intersect(img)) return true;
        return v.left >= d.left - 0.5f && v.top >= d.top - 0.5f && v.right <= d.right + 0.5f && v.bottom <= d.bottom + 0.5f;
    }

    private void scheduleDetail() {
        handler.removeCallbacks(detailRunnable);
        handler.postDelayed(detailRunnable, 30);
    }

    /** Algo cambio en todo el dibujo: el detalle se vuelve a armar. */
    private void invalidateDetail() {
        detailGen++;
        detailValid = false;
        detailStale = false;
    }

    /**
     * Cambio el dibujo pero no el tamano: el detalle nitido viejo se queda
     * en pantalla hasta que llega el nuevo. Asi no se ve un instante borroso.
     */
    private boolean detailStale;

    private void staleDetail() {
        if (detail == null || !detailValid) {
            invalidateDetail();
            return;
        }
        detailGen++;
        detailStale = true;
    }

    private void dropDetail() {
        handler.removeCallbacks(detailRunnable);
        detailGen++;
        detailValid = false;
        if (detail != null && !detail.isRecycled()) detail.recycle();
        detail = null;
        detailRect = null;
    }

    private void buildDetail() {
        if (project == null || busy || drawing) {
            if (project != null) scheduleDetail();
            return;
        }
        if (detailBuilding) return;
        final Rect r = wantedDetail();
        if (r == null) {
            if (detail != null) dropDetail();
            return;
        }
        if (detailValid && !detailStale && detailRect != null && detailRect.contains(r)) return;
        detailBuilding = true;
        detailBakePending = dispGrayQ == null ? null : dispGrayParams;
        final int gen = detailGen;
        final Rect vis0 = visibleDetail();
        final Rect vis = vis0 != null && r.contains(vis0) ? vis0 : null;
        final Layer[] ls = project.layers.toArray(new Layer[0]);
        final int[] ops = new int[ls.length];
        final boolean[] vs = new boolean[ls.length];
        final int[] modes = new int[ls.length];
        final boolean[] clips = new boolean[ls.length];
        for (int k = 0; k < ls.length; k++) {
            ops[k] = ls[k].opacity;
            vs[k] = ls[k].visible;
            modes[k] = ls[k].mode;
            clips[k] = ls[k].clip;
        }
        final byte[] sel = project.selection;
        final int w = project.w;
        final int[] bg = VIEW_BG[viewBg];
        final float cs = 8f * dispScale;
        final Project owner = project;
        // hilo propio: no espera al guardado automatico ni a otras tareas
        DETAIL_BOSS.execute(new Runnable() {
            @Override
            public void run() {
                // 1) primero solo lo que se ve (rapido); 2) despues con margen
                if (vis != null && (vis.width() < r.width() || vis.height() < r.height())) {
                    final Bitmap first = renderDetail(vis, ls, ops, vs, modes, clips, sel, bg, cs, w, owner);
                    post(new Runnable() {
                        @Override
                        public void run() {
                            acceptDetail(first, vis, gen, owner, false);
                        }
                    });
                }
                final Bitmap full = renderDetail(r, ls, ops, vs, modes, clips, sel, bg, cs, w, owner);
                post(new Runnable() {
                    @Override
                    public void run() {
                        acceptDetail(full, r, gen, owner, true);
                    }
                });
            }
        });
    }

    /** v8.62: segun el nivel del celular (no se pelea con los hilos del Acabado). */
    private static final int DETAIL_THREADS = com.pacco.animecut.core.DeviceTier.detailThreads();
    private static final java.util.concurrent.ExecutorService DETAIL_BOSS =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private static final java.util.concurrent.ExecutorService DETAIL_WORKERS =
            java.util.concurrent.Executors.newFixedThreadPool(DETAIL_THREADS);

    private void acceptDetail(Bitmap b, Rect r, int gen, Project owner, boolean last) {
        if (last) detailBuilding = false;
        if (b == null) return;
        if (owner != project || gen != detailGen) {
            b.recycle();
            if (last) scheduleDetail();
            return;
        }
        // si ya hay uno mas grande y valido, no se reemplaza con el chico
        if (!last && !detailStale && detail != null && detailValid && detailRect != null && detailRect.contains(r)) {
            b.recycle();
            return;
        }
        if (detail != null && !detail.isRecycled()) detail.recycle();
        detail = b;
        detailBake = detailBakePending;
        detailRect = r;
        detailValid = true;
        if (last) detailStale = false;
        invalidate();
    }

    /** Arma el detalle repartido en varios hilos, por franjas de filas. */
    private static Bitmap renderDetail(final Rect r, Layer[] ls, int[] ops, boolean[] vs, final int[] modes,
                                       final boolean[] clips, final byte[] sel,
                                       final int[] bg, final float cs, final int w, Project owner) {
        try {
            final Bitmap b = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888);
            final int rows = r.height();
            int parts = Math.min(DETAIL_THREADS, Math.max(1, rows / 64));
            java.util.List<java.util.concurrent.Future<?>> fs = new java.util.ArrayList<java.util.concurrent.Future<?>>();
            for (int k = 0; k < parts; k++) {
                final int y0 = r.top + rows * k / parts, y1 = r.top + rows * (k + 1) / parts;
                final LayerSrc[] src = buildSources(ls, ops, vs, modes, clips, owner.w, owner.h, true);
                fs.add(DETAIL_WORKERS.submit(new Runnable() {
                    @Override
                    public void run() {
                        int[] row = new int[r.width()];
                        for (int y = y0; y < y1; y++) {
                            for (int x = r.left; x < r.right; x++) {
                                row[x - r.left] = detailPixel(src, sel, bg, cs, x, y, w);
                            }
                            synchronized (b) {
                                b.setPixels(row, 0, row.length, 0, y - r.top, row.length, 1);
                            }
                        }
                    }
                }));
            }
            for (java.util.concurrent.Future<?> f : fs) f.get();
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private static int detailPixel(LayerSrc[] src, byte[] sel, int[] bg, float cs, int x, int y, int w) {
        int c = ((((int) (x / cs)) + ((int) (y / cs))) & 1) == 0 ? bg[0] : bg[1];
        c = over(src, c, x, y, w);
        int a = sel[y * w + x] & 0xFF;
        if (a != 0) c = blendA(c, 0xFF3D7BFF, (a * 140) / 255);
        return c;
    }

    /** Actualiza al momento la parte del detalle que cambio (trazos, relleno chico). */
    private void updateDetail(Rect changed) {
        if (detail == null || detailRect == null || !detailValid || changed == null) return;
        Rect r = new Rect(changed);
        if (!r.intersect(detailRect)) return;
        // Reconstruir una imagen de muchas capas por cada movimiento bloquea
        // el hilo tactil. Para gestos grandes, mostrar la vista normal durante
        // el trazo y reconstruir el detalle nitido al levantar el dedo.
        long pixels = (long) r.width() * r.height();
        // v8.53: con la cache de abajo cada pixel cuesta solo la capa activa y las de arriba
        boolean cached = drawing && liquifyPendingCommit == 0 && mode != MODE_LIQUIFY
                && belowSplit(project.layers.toArray(new Layer[0])) > 0;
        if (pixels > (drawing || liquifyPendingCommit != 0
                ? (mode == MODE_LIQUIFY ? 260_000L : cached ? 90_000L : 20_000L) : 60_000L)) {
            invalidateDetail();
            if (!drawing) scheduleDetail();
            return;
        }
        detailGen++;
        if (cached && detailWithBelow(r)) return;
        LayerSrc[] src = layerSources();
        int[] bg = VIEW_BG[viewBg];
        float cs = 8f * dispScale;
        int[] row = new int[r.width()];
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                row[x - r.left] = detailPixel(src, project.selection, bg, cs, x, y, project.w);
            }
            detail.setPixels(row, 0, row.length, r.left - detailRect.left, y - detailRect.top, row.length, 1);
        }
    }

    private static int blendA(int dst, int src, int a) {
        if (a >= 255) return src | 0xFF000000;
        int r = (((src >> 16) & 0xFF) * a + ((dst >> 16) & 0xFF) * (255 - a)) / 255;
        int g = (((src >> 8) & 0xFF) * a + ((dst >> 8) & 0xFF) * (255 - a)) / 255;
        int b = ((src & 0xFF) * a + (dst & 0xFF) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Mientras se estampan muchos puntos seguidos, la pantalla se actualiza una sola vez. */
    private int batchDepth;
    private Rect batchRect;

    private void beginBatch() {
        batchDepth++;
    }

    private void endBatch() {
        if (batchDepth == 1 && bgSpeckRect != null) {
            // v8.28: las motas de Borrar fondo se limpian una vez por evento (no por estampa)
            Rect sr = bgSpeckRect;
            bgSpeckRect = null;
            if (strokeLayer != null && mode == MODE_BGERASE && drawing) {
                // v8.32: el pincel protegido ya deja el borde terminado (motor BgEngine); aqui
                // solo la Suavidad elegida en la barra de abajo
                if (bgSub == BG_SUB_BRUSH && bgFeather > 0.05f) {
                    sr.inset(-(int) Math.ceil(bgFeather) - 2, -(int) Math.ceil(bgFeather) - 2);
                    clamp(sr);
                    if (captureEffectStrokeBackup(sr)) featherBg(strokeLayer, sr);
                }
                grow(sr);
                updateDisplayRegion(sr);
            }
        }
        if (batchDepth > 0) batchDepth--;
        if (batchDepth == 0 && batchRect != null) {
            Rect r = batchRect;
            batchRect = null;
            updateDisplayRegion(r);
        }
    }

    private void updateDisplayRegion(Rect r) {
        if (display == null || r == null) return;
        if (batchDepth > 0) {
            if (batchRect == null) batchRect = new Rect(r);
            else batchRect.union(r);
            return;
        }
        composeRegion((int) (r.left / dispScale) - 1, (int) (r.top / dispScale) - 1,
                (int) Math.ceil(r.right / dispScale) + 1, (int) Math.ceil(r.bottom / dispScale) + 1);
        updateDetail(r);
        invalidate();
    }

    /** Despues de cambiar pixeles de una capa. */
    private void pixelsChanged(Rect r) {
        project.markDirty();
        wire = null;
        updateDisplayRegion(r);
        changed();
    }

    private void buildOverlay() {
        if (overlay != null) overlay.recycle();
        int max = Math.max(project.w, project.h);
        ovScale = max > 1440 ? (int) Math.ceil(max / 1440f) : 1;
        overlay = Bitmap.createBitmap(Math.max(1, project.w / ovScale), Math.max(1, project.h / ovScale),
                Bitmap.Config.ARGB_8888);
        paintOverlay(project.fullRect());
    }

    private void paintOverlay(Rect r) {
        if (overlay == null || project == null) return;
        int ow = overlay.getWidth(), oh = overlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int a = project.selection[sy * project.w + sx] & 0xFF;
                row[i] = a == 0 ? 0 : (((a * 140) / 255) << 24) | 0x3D7BFF;
            }
            overlay.setPixels(row, 0, rw, x0, y, rw, 1);
        }
        updateDetail(r);
    }

    public void refreshOverlay(Rect r) {
        if (project == null) return;
        paintOverlay(r == null ? project.fullRect() : r);
        invalidate();
    }

    public void setViewBg(int v) {
        int nv = Math.max(0, Math.min(VIEW_BG.length - 1, v));
        boolean changed = project != null && project.viewBg != nv;
        viewBg = nv;
        com.pacco.animecut.core.Thumbs.checkA = VIEW_BG[nv][0];   // v8.45: miniaturas con el mismo fondo
        com.pacco.animecut.core.Thumbs.checkB = VIEW_BG[nv][1];
        // v8.39: la obra recuerda su fondo de vista (miniatura de "Mis obras" y al reabrir)
        if (project != null) project.viewBg = nv;
        refreshDisplayAsync();
        if (changed && callback != null) callback.onChanged();
    }

    public int getViewBg() {
        return viewBg;
    }

    public void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
    }

    public void fit() {
        if (project == null || getWidth() == 0) return;
        int usable = getHeight() - insetTop - insetBottom;
        if (usable < 80) usable = getHeight();
        float s = Math.min((float) getWidth() / project.w, (float) usable / project.h) * 0.96f;
        view.reset();
        viewFlipped = false;
        view.postScale(s, s);
        view.postTranslate((getWidth() - project.w * s) / 2f, insetTop + (usable - project.h * s) / 2f);
        fitted = true;
        invalidate();
    }

    public boolean isFitted() {
        return fitted;
    }

    private final float[] viewMatrixValues = new float[9];
    private float currentScale() {
        // Durante el pinch se llama por cada evento; no crear 9 floats por frame.
        view.getValues(viewMatrixValues);
        return (float) Math.sqrt(viewMatrixValues[Matrix.MSCALE_X] * viewMatrixValues[Matrix.MSCALE_X]
                + viewMatrixValues[Matrix.MSKEW_X] * viewMatrixValues[Matrix.MSKEW_X]);
    }

    public void showHud(String text) { showHud(text, 1400); }

    public void showHud(String text, int ms) {
        hud = text;
        hudUntil = System.currentTimeMillis() + ms;
        invalidate();
        postInvalidateDelayed(ms + 50);
    }

    @Override
    protected void onDraw(Canvas c) {
        long t0 = System.nanoTime();
        try {
            onDrawInner(c);
        } finally {
            com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.FRAME, System.nanoTime() - t0);
        }
    }

    private void onDrawInner(Canvas c) {
        super.onDraw(c);
        drawAll(c);
        drawSizePreview(c);
        drawFinishOverlay(c);
    }

    // ---------------- v8.60: ACABADO (sol arrastrable, Mas sombra / Mas luz, Quitar mancha) ----------------
    /** Toques de un dedo para el Acabado, en pixeles de la imagen. action: 0 bajar, 1 mover, 2 soltar, 3 cancelar. */
    public interface FinishTouch { void onFinishTouch(int action, float x, float y); }

    private FinishTouch finishTouch;
    private boolean ftDown, ftMulti;
    private float sunMarkX = Float.NaN, sunMarkY;
    private float finRingX = Float.NaN, finRingY, finRingR;
    private Paint sunPaint, sunFill;

    /** Mientras esta puesto, un dedo mueve el sol o pinta retoques; dos dedos siguen moviendo y ampliando. */
    public void setFinishTouch(FinishTouch t) {
        finishTouch = t;
        ftDown = false;
        ftMulti = false;
        if (t == null) { finRingX = Float.NaN; invalidate(); }
    }

    public boolean hasFinishTouch() { return finishTouch != null; }

    /** El sol del Acabado (0..1 de la imagen; puede estar afuera). NaN = no dibujarlo. */
    public void setSunMarker(float fx, float fy) {
        sunMarkX = fx;
        sunMarkY = fy;
        invalidate();
    }

    /** v8.63: luces extra (0..1 de la imagen) con su tipo, y cual esta elegida (0 = el sol principal). */
    private float[] lightMarkX = new float[0], lightMarkY = new float[0];
    private int[] lightMarkType = new int[0];
    private int sunMainType = 0, lightMarkSel = 0;

    public void setLightMarkers(int mainType, float[] xs, float[] ys, int[] types, int n, int sel) {
        sunMainType = mainType;
        lightMarkX = new float[n]; lightMarkY = new float[n]; lightMarkType = new int[n];
        for (int i = 0; i < n; i++) { lightMarkX[i] = xs[i]; lightMarkY[i] = ys[i]; lightMarkType[i] = types[i]; }
        lightMarkSel = sel;
        invalidate();
    }

    /** Circulo del pincel de retoque (en pixeles de la imagen). NaN = quitarlo. */
    public void setFinishRing(float x, float y, float r) {
        finRingX = x; finRingY = y; finRingR = r;
        invalidate();
    }

    private void sendFinish(int action, float sx, float sy) {
        if (project == null || finishTouch == null) return;
        float[] pt = {sx, sy};
        Matrix inv = new Matrix();
        view.invert(inv);
        inv.mapPoints(pt);
        finishTouch.onFinishTouch(action, pt[0], pt[1]);
    }

    /** @return true si el toque ya quedo atendido (un dedo). Con dos dedos sigue el mover/ampliar normal. */
    /** v8.68: dedo abajo pero todavia sin mandar (puede ser el inicio de un zoom con 2 dedos). */
    private boolean ftPending;

    private boolean finishTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                ftDown = true;
                ftMulti = false;
                multi = false;
                midValid = false;
                navActive = false;
                lastPinchDistance = 0f;
                gestureMax = 1;
                gestureMoved = 0f;
                multiMoved = 0f;
                markPointerStart(e, 0);
                downTime = System.currentTimeMillis();
                downX = e.getX();
                downY = e.getY();
                panning = false;
                pendingTap = false;
                pendingStroke = false;
                // v8.68: el toque se manda recien cuando el dedo se mueve o se levanta. Si llega un
                // segundo dedo antes (zoom), no pasa nada: el sol ya no salta al hacer zoom.
                ftPending = true;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (ftDown && !ftMulti) {
                    ftMulti = true;
                    if (ftPending) ftPending = false;
                    else sendFinish(3, e.getX(0), e.getY(0));
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (!ftDown || ftMulti) return false;
                if (ftPending) {
                    float slop = 10f * getResources().getDisplayMetrics().density;
                    if (Math.hypot(e.getX() - downX, e.getY() - downY) < slop) return true;
                    ftPending = false;
                    sendFinish(0, downX, downY);
                }
                int hs = e.getHistorySize();
                for (int k = 0; k < hs; k++) sendFinish(1, e.getHistoricalX(0, k), e.getHistoricalY(0, k));
                sendFinish(1, e.getX(), e.getY());
                return true;
            case MotionEvent.ACTION_UP:
                if (ftDown && !ftMulti) {
                    if (ftPending) { ftPending = false; sendFinish(0, downX, downY); }
                    sendFinish(2, e.getX(), e.getY());
                }
                ftDown = false;
                return false;
            case MotionEvent.ACTION_CANCEL:
                if (ftDown && !ftMulti && !ftPending) sendFinish(3, e.getX(), e.getY());
                ftPending = false;
                ftDown = false;
                return false;
            default:
                return false;
        }
    }

    private void drawFinishOverlay(Canvas c) {
        if (project == null) return;
        float dn = getResources().getDisplayMetrics().density;
        if (sunPaint == null) {
            sunPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            sunPaint.setStyle(Paint.Style.STROKE);
            sunPaint.setStrokeCap(Paint.Cap.ROUND);
            sunFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            sunFill.setStyle(Paint.Style.FILL);
        }
        if (!Float.isNaN(finRingX)) {
            float[] p = {finRingX, finRingY, finRingX + finRingR, finRingY};
            view.mapPoints(p);
            float r = (float) Math.hypot(p[2] - p[0], p[3] - p[1]);
            sunPaint.setStrokeWidth(2f * dn);
            sunPaint.setColor(0xCCFFFFFF);
            c.drawCircle(p[0], p[1], r, sunPaint);
            sunPaint.setStrokeWidth(1f * dn);
            sunPaint.setColor(0xCC000000);
            c.drawCircle(p[0], p[1], r + 2f * dn, sunPaint);
        }
        if (Float.isNaN(sunMarkX)) return;
        for (int i = 0; i < lightMarkX.length; i++)
            drawLightIcon(c, lightMarkX[i], lightMarkY[i], lightMarkType[i], lightMarkSel == i + 1 && lightMarkX.length > 0, dn);
        drawLightIcon(c, sunMarkX, sunMarkY, sunMainType, lightMarkSel == 0 && lightMarkX.length > 0, dn);
    }

    /** Un sol, una luna o una lampara (segun el tipo de luz). 'sel' = anillo blanco (es la que se mueve). */
    private void drawLightIcon(Canvas c, float fx, float fy, int type, boolean sel, float dn) {
        float[] p = {fx * project.w, fy * project.h};
        view.mapPoints(p);
        // si queda fuera de la pantalla, se dibuja en el borde (para poder agarrarlo)
        float m = 26f * dn;
        float x = Math.max(m, Math.min(getWidth() - m, p[0])), y = Math.max(m, Math.min(getHeight() - m, p[1]));
        float r = 13f * dn;
        sunFill.setColor(0x66000000);
        c.drawCircle(x, y, r + 11f * dn, sunFill);
        if (sel) {
            sunPaint.setColor(0xFFFFFFFF);
            sunPaint.setStrokeWidth(2.5f * dn);
            c.drawCircle(x, y, r + 12f * dn, sunPaint);
        }
        if (type == 3 || type == 4) {
            // luna (llena o media)
            sunFill.setColor(0xFFE6ECFF);
            c.drawCircle(x, y, r, sunFill);
            if (type == 4) {
                sunFill.setColor(0xFF2A3050);
                c.drawCircle(x + r * 0.55f, y - r * 0.25f, r * 0.85f, sunFill);
            }
            return;
        }
        if (type == 5) {
            // lampara (interior)
            sunFill.setColor(0xFFFFF1C8);
            c.drawCircle(x, y, r * 0.85f, sunFill);
            sunPaint.setColor(0xFFFFF1C8);
            sunPaint.setStrokeWidth(2f * dn);
            c.drawCircle(x, y, r + 4f * dn, sunPaint);
            return;
        }
        int fill = type == 2 ? 0xFFFF8A5C : type == 1 ? 0xFFFFB347 : 0xFFFFC83D;
        sunFill.setColor(fill);
        c.drawCircle(x, y, r, sunFill);
        sunPaint.setColor(0xFFFFE08A);
        sunPaint.setStrokeWidth(2.5f * dn);
        for (int k = 0; k < 8; k++) {
            double a = Math.PI * k / 4;
            float cx = (float) Math.cos(a), sy = (float) Math.sin(a);
            c.drawLine(x + cx * (r + 3f * dn), y + sy * (r + 3f * dn), x + cx * (r + 8f * dn), y + sy * (r + 8f * dn), sunPaint);
        }
    }

    /** La capa "Color zonas" (donde va el acabado) o null. */
    public Layer finishToneLayer() { return roleLayer(Layer.ROLE_TONE); }

    /** El dibujo (tinta) que se usa para el acabado: lo mismo que usa Colorear. */
    public int[] finishRef() { return project == null ? null : mangaRef(zoneRefTarget()); }

    /** Copia de la capa "Color zonas" en el recuadro (o null). */
    public int[] finishCopy(Rect box) {
        Layer t = roleLayer(Layer.ROLE_TONE);
        if (t == null || project == null) return null;
        int[] px = t.px();
        int bw = box.width(), bh = box.height();
        int[] out = new int[bw * bh];
        for (int y = 0; y < bh; y++) System.arraycopy(px, (y + box.top) * project.w + box.left, out, y * bw, bw);
        return out;
    }

    /** Pone el recuadro en la capa "Color zonas" y actualiza la pantalla (vista previa, sin Deshacer). */
    public void finishPut(int[] buf, Rect box) {
        Layer t = roleLayer(Layer.ROLE_TONE);
        if (t == null || project == null || buf == null) return;
        int[] px = t.px();
        int bw = box.width(), bh = box.height();
        if (buf.length != bw * bh) return;
        for (int y = 0; y < bh; y++) System.arraycopy(buf, y * bw, px, (y + box.top) * project.w + box.left, bw);
        pixelsChanged(new Rect(box));
    }

    /**
     * Aceptar el acabado: queda en la capa con UN paso de Deshacer (vuelve a como estaba antes de
     * abrir el Acabado) y las zonas guardan el acabado en su estilo.
     */
    public void finishCommit(int[] original, int[] result, Rect box, java.util.List<com.pacco.animecut.core.ZoneTone.Zone> zones) {
        Layer t = roleLayer(Layer.ROLE_TONE);
        if (t == null || project == null || original == null || result == null) return;
        undo.setLabel("Acabado");
        undo.begin();
        undo.recordZones();
        undo.recordLayerRegionBackup(t, new Rect(box), original);
        undo.end();
        int[] px = t.px();
        int bw = box.width(), bh = box.height();
        for (int y = 0; y < bh; y++) System.arraycopy(result, y * bw, px, (y + box.top) * project.w + box.left, bw);
        if (zones != null) project.zones = new java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone>(zones);
        project.markDirty();
        pixelsChanged(new Rect(box));
        if (callback != null) callback.onToolStateChanged();
    }

    // ---------------- v8.46: tocar el lienzo para elegir un punto (el sol de Luz y ambiente) ----------------
    public interface TapPick { void onPick(float fx, float fy); }

    private TapPick tapPick;
    private float tpX, tpY;
    private long tpT;
    private boolean tpMulti;

    /** Mientras esta puesto, un toque corto (sin arrastrar) devuelve el punto (0..1 de la imagen). */
    public void setTapPick(TapPick t) { tapPick = t; }

    private void tapPickTouch(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                tpX = e.getX(); tpY = e.getY(); tpT = System.currentTimeMillis(); tpMulti = false;
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                tpMulti = true;
                break;
            case MotionEvent.ACTION_UP:
                float slop = 12 * getResources().getDisplayMetrics().density;
                if (!tpMulti && Math.abs(e.getX() - tpX) < slop && Math.abs(e.getY() - tpY) < slop
                        && System.currentTimeMillis() - tpT < 450 && project != null) {
                    float[] pt = {e.getX(), e.getY()};
                    Matrix inv = new Matrix();
                    view.invert(inv);
                    inv.mapPoints(pt);
                    final float fx = pt[0] / project.w, fy = pt[1] / project.h;
                    final TapPick t = tapPick;
                    if (t != null) post(new Runnable() { public void run() { t.onPick(fx, fy); } });
                }
                break;
        }
    }

    /** v8.46: guarda la lista de capas para Deshacer (antes de agregar o quitar capas desde afuera). */
    public void recordStructUndo(String label) {
        if (undo == null) return;
        undo.setLabel(label);
        undo.recordStruct();
    }

    // ---------------- v8.51: vista previa encima (Luz y ambiente, Estilo) sin tocar las capas ----------------
    private Bitmap previewOver;
    private final Paint previewOverPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    /** Muestra una imagen (a cualquier escala) encima de toda la obra. null = quitar. */
    public void setPreviewOver(Bitmap b) {
        if (previewOver != null && previewOver != b && !previewOver.isRecycled()) previewOver.recycle();
        previewOver = b;
        invalidate();
    }

    /** v8.59: efectos de Luz encima del dibujo nitido, cada uno con su modo (Android 10+). */
    private Bitmap[] previewFx;
    private int[] previewFxModes;
    private final Paint previewFxPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    public void setPreviewEffects(Bitmap[] bms, int[] modes) {
        if (previewFx != null && previewFx != bms)
            for (Bitmap b : previewFx) if (b != null && !b.isRecycled()) b.recycle();
        previewFx = bms;
        previewFxModes = modes;
        invalidate();
    }

    private void drawPreviewFx(Canvas c) {
        if (previewFx == null || project == null || android.os.Build.VERSION.SDK_INT < 29) return;
        c.save();
        c.concat(view);
        for (int k = 0; k < previewFx.length; k++) {
            Bitmap b = previewFx[k];
            if (b == null || b.isRecycled()) continue;
            int m = previewFxModes[k];
            previewFxPaint.setBlendMode(m == 1 ? android.graphics.BlendMode.MULTIPLY
                    : m == 2 ? android.graphics.BlendMode.SCREEN
                    : m == 4 ? android.graphics.BlendMode.OVERLAY : android.graphics.BlendMode.SRC_OVER);
            c.save();
            c.scale(project.w / (float) b.getWidth(), project.h / (float) b.getHeight());
            c.drawBitmap(b, 0, 0, previewFxPaint);
            c.restore();
        }
        c.restore();
    }

    private void drawPreviewOver(Canvas c) {
        drawPreviewFx(c);
        if (previewOver == null || previewOver.isRecycled() || project == null) return;
        c.save();
        c.concat(view);
        c.scale(project.w / (float) previewOver.getWidth(), project.h / (float) previewOver.getHeight());
        c.drawBitmap(previewOver, 0, 0, previewOverPaint);
        c.restore();
    }

    // ---------------- v8.45: Antes / Despues en el mismo lienzo ----------------
    private Bitmap compareBefore;
    private float compareSplit = 0.5f;      // lugar de la linea en la imagen (0..1): se queda donde la dejas
    private boolean compareDrag;
    private final Paint compareLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint compareText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint compareChip = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Muestra la linea Antes/Despues sobre el lienzo (before = como era, a cualquier escala). */
    public void startCompare(Bitmap before) {
        stopCompare();
        compareBefore = before;
        compareSplit = 0.5f;
        invalidate();
    }

    public void stopCompare() {
        if (compareBefore != null && !compareBefore.isRecycled()) compareBefore.recycle();
        compareBefore = null;
        compareDrag = false;
        invalidate();
    }

    public boolean isComparing() { return compareBefore != null; }

    private float compareLineX() {
        float[] pt = {compareSplit * project.w, 0f};
        view.mapPoints(pt);
        return pt[0];
    }

    private void drawCompare(Canvas c) {
        if (compareBefore == null || compareBefore.isRecycled() || project == null) return;
        float lx = compareLineX();
        float d = getResources().getDisplayMetrics().density;
        c.save();
        c.clipRect(0, 0, Math.max(0, lx), getHeight());
        c.concat(view);
        c.scale(project.w / (float) compareBefore.getWidth(), project.h / (float) compareBefore.getHeight());
        c.drawBitmap(compareBefore, 0, 0, bmpPaint);
        c.restore();
        compareLine.setColor(0xFFFFFFFF);
        compareLine.setStrokeWidth(2.5f * d);
        compareLine.setShadowLayer(3 * d, 0, 0, 0x99000000);
        c.drawLine(lx, 0, lx, getHeight(), compareLine);
        compareChip.setColor(0xCC1E1E24);
        float cy = getHeight() * 0.5f;
        c.drawCircle(lx, cy, 15 * d, compareChip);
        c.drawCircle(lx, cy, 15 * d, compareLine);
        compareText.setColor(0xFFFFFFFF);
        compareText.setTextSize(13 * d);
        String a = "Antes", b = "Despues";
        float ty = getHeight() * 0.5f + 38 * d;
        float wa = compareText.measureText(a);
        c.drawRoundRect(lx - wa - 22 * d, ty - 18 * d, lx - 6 * d, ty + 7 * d, 8 * d, 8 * d, compareChip);
        c.drawText(a, lx - wa - 14 * d, ty, compareText);
        float wb = compareText.measureText(b);
        c.drawRoundRect(lx + 6 * d, ty - 18 * d, lx + wb + 22 * d, ty + 7 * d, 8 * d, 8 * d, compareChip);
        c.drawText(b, lx + 14 * d, ty, compareText);
    }

    /** Un dedo cerca de la linea la mueve; lo demas (zoom, mover) sigue igual. */
    private boolean compareTouch(MotionEvent e) {
        if (compareBefore == null) return false;
        float d = getResources().getDisplayMetrics().density;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                compareDrag = Math.abs(e.getX() - compareLineX()) < 36 * d;
                if (!compareDrag) return false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!compareDrag) return false;
                if (e.getPointerCount() > 1) { compareDrag = false; return false; }
                float[] pt = {e.getX(), e.getY()};
                Matrix inv = new Matrix();
                view.invert(inv);
                inv.mapPoints(pt);
                compareSplit = Math.max(0f, Math.min(1f, pt[0] / project.w));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (compareDrag) { compareDrag = false; return true; }
                return false;
            default:
                return compareDrag;
        }
    }

    private void drawAll(Canvas c) {
        c.drawColor(0xFF121214);
        if (project == null || display == null || !fitted) return;
        bmpPaint.setFilterBitmap(smoothZoom || currentScale() * dispScale < 1f);
        detailPaint.setFilterBitmap(smoothZoom || currentScale() < 1f);
        bmpPaint.setColorFilter(grayDelta(dispBake));
        detailPaint.setColorFilter(grayDelta(detailBake));

        c.save();
        c.concat(view);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, bmpPaint);
        c.restore();

        boolean useDetail = detail != null && !detail.isRecycled() && detailValid && detailRect != null;
        if (useDetail) {
            c.save();
            c.concat(view);
            c.drawBitmap(detail, detailRect.left, detailRect.top, detailPaint);
            c.restore();
        }
        drawPreviewOver(c);
        drawCompare(c);

        Rect want = wantedDetail();
        if (want == null) {
            if (detail != null) handler.post(new Runnable() {
                @Override
                public void run() {
                    if (wantedDetail() == null) dropDetail();
                }
            });
        } else if (!drawing && (!useDetail || !visibleInside(detailRect))) {
            scheduleDetail();
        }

        if (overlay != null) {
            if (useDetail) {
                c.save();
                Path clip = new Path();
                clip.addRect(new RectF(detailRect), Path.Direction.CW);
                Path sp = new Path();
                clip.transform(view, sp);
                c.clipOutPath(sp);
                drawOv(c, overlay);
                c.restore();
            } else {
                drawOv(c, overlay);
            }
        }
        if (moveGhost != null && moveGhostRect != null && !moveGhost.isRecycled()) {
            c.save();
            c.concat(view);
            c.drawBitmap(moveGhost, moveGhostRect.left + moveDx, moveGhostRect.top + moveDy, ghostMovePaint);
            c.restore();
        }
        if (mode == MODE_TRANSFORM && transformPreparing && !transformActive) drawTransformPreparing(c);
        if (mode == MODE_TRANSFORM && transformActive) drawTransformPreview(c);
        if (redLines != null && !redLines.isRecycled()) {
            c.save();
            c.concat(view);
            c.scale(dispScale, dispScale);
            c.drawBitmap(redLines, 0, 0, previewPaint);
            c.restore();
        }
        if (mode == MODE_MARKER && sepPreview != null && !sepPreview.isRecycled() && sepPreviewRect != null) {
            c.save();
            c.concat(view);
            c.drawBitmap(sepPreview, null, new RectF(sepPreviewRect), previewPaint);
            c.restore();
        }
        if (markersOverlay != null && mode == MODE_MARKER) drawOv(c, markersOverlay);
        drawMangaOverlays(c);
        if (aiMark && mode == MODE_BGERASE) drawAiMark(c);

        if (mode == MODE_LASSO && !lasso.isEmpty()) {
            Path sp = new Path();
            lasso.transform(view, sp);
            c.drawPath(sp, lassoPaint);
        }
        if (mode == MODE_SCISSORS || mode == MODE_MAGNET) drawWire(c);
        if (mode == MODE_LINE && linePts.size() > 1) {
            Path lp = new Path();
            for (int i = 0; i < linePts.size(); i++) {
                point[0] = linePts.get(i)[0];
                point[1] = linePts.get(i)[1];
                view.mapPoints(point);
                if (i == 0) lp.moveTo(point[0], point[1]);
                else lp.lineTo(point[0], point[1]);
            }
            c.drawPath(lp, linePreview);
        }
        if (mode == MODE_SHAPE) {
            if (geo != null || geoPrev != null) drawGeo(c);
        } else if (isShapeTool() && !shapePts.isEmpty()) drawShape(c);
        if ((mode == MODE_CLONE || mode == MODE_HEAL) && cloneSrcSet) {
            point[0] = cloneSrcX;
            point[1] = cloneSrcY;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 22f, markPaint);
            c.drawLine(point[0] - 30, point[1], point[0] + 30, point[1], markPaint);
            c.drawLine(point[0], point[1] - 30, point[0], point[1] + 30, markPaint);
        }

        float rx = ringX + (usesAim() ? aimDx : 0f), ry = ringY + (usesAim() ? aimDy : 0f);
        if (showRing && usesBrush() && !quickPick) c.drawCircle(rx, ry, brushRadius * currentScale(), ringPaint);
        if ((mode == MODE_CLONE || mode == MODE_HEAL) && cloneSrcSet && drawing) drawCloneGhost(c, rx, ry);
        if (usesAim() && showRing && !quickPick) {
            float d = getResources().getDisplayMetrics().density;
            c.drawLine(rx - 10 * d, ry, rx + 10 * d, ry, aimPaint);
            c.drawLine(rx, ry - 10 * d, rx, ry + 10 * d, aimPaint);
            drawLoupe(c, rx, ry);
        }
        if (quickPick) drawPin(c);
        if (hud != null && System.currentTimeMillis() < hudUntil) {
            float dd = getResources().getDisplayMetrics().density;
            float pad = 14f * dd;
            // v8.36: un aviso largo se achica para entrar en pantallas angostas (no se corta)
            float base = dd * 14f;
            hudText.setTextSize(base);
            float tw = hudText.measureText(hud), avail = getWidth() - 3f * pad;
            if (tw > avail && avail > 0) {
                hudText.setTextSize(Math.max(dd * 9f, base * avail / tw));
                tw = hudText.measureText(hud);
            }
            float cx = getWidth() / 2f, top = insetTop + pad;
            c.drawRoundRect(new RectF(cx - tw / 2 - pad, top, cx + tw / 2 + pad, top + pad * 2.6f), 12f, 12f, hudBg);
            c.drawText(hud, cx, top + pad * 1.8f, hudText);
            hudText.setTextSize(base);
        }
    }

    private void drawOv(Canvas c, Bitmap b) {
        c.save();
        c.concat(view);
        c.scale(ovScale, ovScale);
        c.drawBitmap(b, 0, 0, ovPaint);
        c.restore();
    }

    private void drawWire(Canvas c) {
        Path sp = new Path();
        wirePath.transform(view, sp);
        c.drawPath(sp, wirePaint);
        if (livePath != null && livePath.length > 1) {
            Path p = new Path();
            for (int i = 0; i < livePath.length; i += 2) {
                int y = livePath[i] / project.w, x = livePath[i] - y * project.w;
                if (i == 0) p.moveTo(x, y);
                else p.lineTo(x, y);
            }
            Path q = new Path();
            p.transform(view, q);
            c.drawPath(q, wirePaint);
        }
        if (firstAnchor >= 0) {
            point[0] = firstAnchor % project.w;
            point[1] = firstAnchor / project.w;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 16f, wirePaint);
        }
    }

    private void drawLoupe(Canvas c, float sx, float sy) {
        if (display == null) return;
        float d = getResources().getDisplayMetrics().density;
        float r = 62f * d, margin = 12f * d;
        float cx = sx < getWidth() / 2f ? getWidth() - r - margin : r + margin;
        float cy = insetTop + r + margin;
        imagePoint(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float ix = point[0] / dispScale, iy = point[1] / dispScale;
        float zoom = Math.max(2.5f, currentScale() * dispScale * 3f);
        Path clip = new Path();
        clip.addCircle(cx, cy, r, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.drawColor(0xFF202024);
        c.translate(cx, cy);
        c.scale(zoom, zoom);
        c.translate(-ix, -iy);
        c.drawBitmap(display, 0, 0, ovPaint);
        if (overlay != null) {
            c.save();
            c.scale(ovScale / dispScale, ovScale / dispScale);
            c.drawBitmap(overlay, 0, 0, ovPaint);
            c.restore();
        }
        c.restore();
        c.drawCircle(cx, cy, r, loupeEdge);
        c.drawLine(cx - 9 * d, cy, cx + 9 * d, cy, aimPaint);
        c.drawLine(cx, cy - 9 * d, cx, cy + 9 * d, aimPaint);
    }

    private void drawPin(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float r = 34f * d, cx = pickX, cy = pickY - r * 1.8f;
        pinFill.setColor(pickColor);
        pinEdge.setStyle(Paint.Style.FILL);
        Path tip = new Path();
        tip.moveTo(cx - r * 0.42f, cy + r * 0.86f);
        tip.lineTo(cx, cy + r * 1.9f);
        tip.lineTo(cx + r * 0.42f, cy + r * 0.86f);
        tip.close();
        c.drawPath(tip, pinEdge);
        c.drawCircle(cx, cy, r, pinEdge);
        // v8.55: como el gotero de Ibis: arriba el color nuevo, abajo el que tienes ahora
        float ri = r - 4f * d;
        RectF ov = new RectF(cx - ri, cy - ri, cx + ri, cy + ri);
        pinFill.setColor(pickColor | 0xFF000000);
        c.drawArc(ov, 180f, 180f, true, pinFill);
        pinFill.setColor(paintColor | 0xFF000000);
        c.drawArc(ov, 0f, 180f, true, pinFill);
    }

    private void drawCloneGhost(Canvas c, float sx, float sy) {
        imagePoint(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float dxi = point[0], dyi = point[1];
        float ddx = dxi - cloneDestX, ddy = dyi - cloneDestY;
        if (cloneMirror) ddx = -ddx;
        double a = Math.toRadians(cloneAngle);
        float srcX = cloneSrcX + (float) (ddx * Math.cos(a) - ddy * Math.sin(a));
        float srcY = cloneSrcY + (float) (ddx * Math.sin(a) + ddy * Math.cos(a));
        Matrix m = new Matrix();
        m.setTranslate(-srcX, -srcY);
        m.postRotate(-cloneAngle);
        if (cloneMirror) m.postScale(-1f, 1f);
        m.postTranslate(dxi, dyi);
        m.postConcat(view);
        Path clip = new Path();
        clip.addCircle(sx, sy, Math.max(12f, brushRadius * currentScale()), Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.concat(m);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, ghostPaint);
        c.restore();
    }

    // ==================================================================
    // Toque: un dedo trabaja, dos dedos mueven y hacen zoom. Como Ibis.
    // ==================================================================

    private boolean usesBrush() {
        return mode == MODE_BRUSH || mode == MODE_ERASER || mode == MODE_CLONE || mode == MODE_PAINT
                || mode == MODE_SMUDGE || mode == MODE_BLUR || mode == MODE_LIQUIFY
                || (mode == MODE_BGERASE && !bgBucket) || mode == MODE_MARKER
                || mode == MODE_HEAL;
    }

    private boolean isTapTool() {
        return mode == MODE_WAND || mode == MODE_BUCKET || mode == MODE_PICKER || mode == MODE_ZONE
                || mode == MODE_TONE || (mode == MODE_BGERASE && bgBucket);
    }

    private boolean usesAim() {
        return aimOn && mode != MODE_PAN && mode != MODE_MOVE && mode != MODE_TRANSFORM;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        long t0 = System.nanoTime();
        try {
            return onTouchEventInner(e);
        } finally {
            com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.TOUCH, System.nanoTime() - t0);
        }
    }

    /** v8.49: ultimo toque en el lienzo (el guardado automatico espera a que sueltes). */
    public volatile long lastTouchMs;

    // ---- v8.76 LAPIZ: empieza al instante, y con "Solo el lapiz pinta" la palma y el dedo no pintan
    private boolean stylusOnly, stylusSeen, penStroke;
    /** v8.77: el lapiz se uso del lado del borrador (los lapices que lo tienen): Pintar borra. */
    private boolean penEraser;
    private int penId = -1;

    public void setStylusOnly(boolean on) { stylusOnly = on; }
    public boolean isStylusOnly() { return stylusOnly; }

    private static boolean isPen(MotionEvent e, int index) {
        int t = e.getToolType(index);
        return t == MotionEvent.TOOL_TYPE_STYLUS || t == MotionEvent.TOOL_TYPE_ERASER;
    }

    /**
     * v8.76: el sistema pide memoria (la app se fue al fondo o el telefono anda justo). Se suelta
     * lo que se puede volver a armar solo: la imagen nitida del zoom y, si es grave, parte del
     * Deshacer mas antiguo.
     */
    public void trimMemory(boolean hard) {
        if (project == null || drawing || busy || transformActive || transformApplying) return;
        dropDetail();
        if (hard && undo != null) undo.trimTo(0.5f);
        invalidate();
    }

    private boolean onTouchEventInner(MotionEvent e) {
        lastTouchMs = android.os.SystemClock.uptimeMillis();
        if (project == null || busy) return true;
        if (compareTouch(e)) return true;
        if (tapPick != null) tapPickTouch(e);
        if (finishTouch != null && finishTouchEvent(e)) return true;
        if (aiMark && mode == MODE_BGERASE) return onAiMarkTouch(e);
        int action = e.getActionMasked();
        int pc = e.getPointerCount();
        if (mode == MODE_TRANSFORM) return onTransformTouch(e);
        // En herramientas normales, pan y zoom se procesan juntos en twoFingers().
        long now = System.currentTimeMillis();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                multi = false;
                midValid = false;
                navActive = false;
                lastPinchDistance = 0f;
                gestureMax = 1;
                gestureMoved = 0f;
                multiMoved = 0f;
                markPointerStart(e, 0);
                downTime = now;
                downX = e.getX();
                downY = e.getY();
                lastSX = downX;
                lastSY = downY;
                ringX = downX;
                ringY = downY;
                pickX = downX;
                pickY = downY;
                showRing = usesBrush();
                boolean pen = isPen(e, 0);
                penStroke = pen;
                penEraser = e.getToolType(0) == MotionEvent.TOOL_TYPE_ERASER;
                penId = e.getPointerId(0);
                if (pen && !stylusSeen) {
                    stylusSeen = true;
                    if (callback != null) callback.onStylusDetected();
                }
                if (stylusOnly && !pen && mode != MODE_PAN) {
                    // v8.76: "Solo el lapiz pinta": el dedo (o la palma) solo mueve el lienzo
                    panning = true;
                    lastPanX = downX;
                    lastPanY = downY;
                    showRing = false;
                    invalidate();
                    return true;
                }
                // v8.76: el trazo sigue al dedo/lapiz sin esperar al siguiente cuadro de pantalla
                if (mode != MODE_PAN) {
                    try { requestUnbufferedDispatch(e); } catch (Throwable ignored) { }
                }
                // Especial necesita soportar presion fija (Contraer/Expandir)
                // sin que el temporizador cambie de herramienta al gotero.
                if (!isShapeTool() && mode != MODE_LIQUIFY && mode != MODE_PICKER) armQuickPick();
                if (mode == MODE_PICKER) {
                    // v8.55: el Gotero muestra la burbuja con el color mientras mueves el dedo; al
                    // soltar queda ese color (antes tomaba el color al tocar, sin poder verlo)
                    cancelQuickTimer();
                    quickPick = true;
                    updateQuickPick(downX, downY);
                    invalidate();
                    return true;
                }
                if (isShapeTool()) {
                    shapeDown(downX, downY);
                } else if (mode == MODE_PAN) {
                    panning = true;
                    lastPanX = downX;
                    lastPanY = downY;
                } else if (isTapTool()) {
                    pendingTap = true;
                    tapX = downX;
                    tapY = downY;
                    if (usesAim()) showRing = true;
                } else {
                    // el trazo no empieza todavia: si llega un segundo dedo, no se pinta nada.
                    // v8.76: con lapiz empieza al instante (un lapiz no hace zoom); con el dedo
                    // la espera bajo de 90 a 60 ms (si llega un segundo dedo igual se cancela)
                    pendingStroke = true;
                    if (pen) beginPending();
                    else handler.postDelayed(startPending, 60);
                }
                invalidate();
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (stylusOnly) {
                    int ni = e.getActionIndex();
                    if (penStroke && !isPen(e, ni)) return true;     // la palma apoyada no cuenta
                    boolean canPaint = !(isTapTool() || isShapeTool() || mode == MODE_PICKER || mode == MODE_PAN);
                    if (!penStroke && !multi && isPen(e, ni) && !drawing && canPaint) {
                        // la palma toco primero y despues llega el lapiz: pinta el lapiz
                        cancelQuickTimer();
                        panning = false;
                        penStroke = true;
                        penEraser = e.getToolType(ni) == MotionEvent.TOOL_TYPE_ERASER;
                        penId = e.getPointerId(ni);
                        downX = e.getX(ni);
                        downY = e.getY(ni);
                        lastSX = downX;
                        lastSY = downY;
                        ringX = downX;
                        ringY = downY;
                        showRing = usesBrush();
                        try { requestUnbufferedDispatch(e); } catch (Throwable ignored) { }
                        pendingStroke = true;
                        beginPending();
                        invalidate();
                        return true;
                    }
                }
                multi = true;
                gestureMax = Math.max(gestureMax, pc);
                markPointerStart(e, e.getActionIndex());
                cancelQuickTimer();
                if (quickPick) endQuickPick(false);
                handler.removeCallbacks(startPending);
                pendingStroke = false;
                pendingTap = false;
                shapeCancelTouch();
                if (drawing) {
                    // Abrir dos dedos durante un lazo es navegación, NO confirmar un recorte.
                    if (mode == MODE_LASSO || now - strokeStart < 400) cancelStroke();
                    else endStroke();
                }
                panning = false;
                showRing = false;
                if (pc >= 2) navBegin(e, -1);
                invalidate();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (multi) {
                    trackMultiMove(e);
                    if (pc >= 2) twoFingers(e);
                    return true;
                }
                // v8.76: con la palma apoyada, el que pinta es el lapiz (no siempre el primer dedo)
                int pi = penStroke ? e.findPointerIndex(penId) : 0;
                if (pi < 0) pi = 0;
                float mx = e.getX(pi), my = e.getY(pi);
                gestureMoved += Math.abs(mx - lastSX) + Math.abs(my - lastSY);
                lastSX = mx;
                lastSY = my;
                ringX = mx;
                ringY = my;
                float moved = (float) Math.hypot(mx - downX, my - downY);
                if (quickPick) {
                    updateQuickPick(mx, my);
                    return true;
                }
                if (moved > touchSlop) cancelQuickTimer();
                if (isShapeTool()) {
                    shapeMove(mx, my, moved);
                    return true;
                }
                if (panning) {
                    float panDx = mx - lastPanX, panDy = my - lastPanY;
                    if (Math.abs(panDx) + Math.abs(panDy) >= .30f) {
                        // Acumular micro-movimientos; ignorarlos y reiniciar
                        // la referencia en cada evento haria perder pan lento.
                        view.postTranslate(panDx, panDy);
                        lastPanX = mx;
                        lastPanY = my;
                    }
                    invalidate();
                    return true;
                }
                if (pendingTap) {
                    if (moved > touchSlop) {
                        if (usesAim()) {
                            tapX = mx;
                            tapY = my;
                        } else {
                            pendingTap = false;
                        }
                    }
                    invalidate();
                    return true;
                }
                if (pendingStroke && moved > touchSlop) beginPending();
                if (drawing) {
                    // el celular junta varios puntos por evento: se usan todos,
                    // asi las curvas rapidas no salen en pedazos rectos
                    beginBatch();
                    try {
                        // Borrar fondo ya interpola los puntos entre eventos: repetir
                        // TODO el historial hacia su motor multiplicaria el trabajo.
                        // Especial (v8.22) SI usa todo el historial: el motor
                        // reparte las estampas por distancia, no por evento, asi que
                        // mas puntos no significan mas trabajo, solo un camino exacto.
                        boolean processHistory = mode == MODE_LASSO || mode == MODE_PAINT
                                || mode == MODE_ERASER || mode == MODE_BRUSH || mode == MODE_LIQUIFY;
                        if (processHistory && (e.getPointerCount() == 1 || penStroke)) {
                            int hs = e.getHistorySize();
                            for (int hk = 0; hk < hs; hk++) {
                                if (mode == MODE_LIQUIFY) liquifyEventTime = e.getHistoricalEventTime(hk);
                                moveStroke(e.getHistoricalX(pi, hk), e.getHistoricalY(pi, hk));
                            }
                        }
                        if (mode == MODE_LIQUIFY) liquifyEventTime = e.getEventTime();
                        moveStroke(mx, my);
                    } finally {
                        endBatch();
                    }
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                if (penStroke && !multi) {
                    if (e.getPointerId(e.getActionIndex()) != penId) return true;   // se fue la palma
                    // v8.76: el lapiz se levanto y la palma sigue apoyada: el trazo termina aqui
                    cancelQuickTimer();
                    handler.removeCallbacks(startPending);
                    if (pendingStroke) {
                        beginPending();
                        if (drawing) endStroke();
                    } else if (drawing) {
                        endStroke();
                    }
                    pendingStroke = false;
                    pendingTap = false;
                    penStroke = false;
                    showRing = false;
                    invalidate();
                    return true;
                }
                // v8.23: si quedan dos o mas dedos, la navegacion se reancla con
                // ellos (sin salto). Si queda uno, ese dedo no pinta ni mueve.
                if (pc - 1 >= 2) navBegin(e, e.getActionIndex());
                else navActive = false;
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cancelQuickTimer();
                handler.removeCallbacks(startPending);
                boolean up = action == MotionEvent.ACTION_UP;
                if (quickPick) {
                    endQuickPick(up);
                } else if (!multi && isShapeTool()) {
                    if (up) shapeUp();
                    else shapeCancelTouch();
                } else if (!up) {
                    // ACTION_CANCEL (el sistema se quedo con el gesto): nada a medias.
                    if (drawing) cancelStroke();
                } else if (!multi) {
                    if (pendingTap) {
                        runTapTool(tapX, tapY);
                    } else if (pendingStroke) {
                        beginPending();
                        if (drawing) endStroke();
                    } else if (drawing) {
                        endStroke();
                    }
                } else if (drawing) {
                    endStroke();
                }
                navActive = false;
                if (multi && up) checkTapGesture(now);
                pendingStroke = false;
                pendingTap = false;
                panning = false;
                multi = false;
                showRing = false;
                penStroke = false;
                penEraser = false;
                invalidate();
                return true;
        }
        return true;
    }

    private void beginPending() {
        pendingStroke = false;
        handler.removeCallbacks(startPending);
        strokeStart = System.currentTimeMillis();
        startStroke(downX, downY);
        if (drawing && (lastSX != downX || lastSY != downY)) moveStroke(lastSX, lastSY);
    }

    /** Dos dedos: tocar deshace, tres rehace. */
    private void checkTapGesture(long now) {
        if (callback == null) return;
        // v8.55: antes no se media cuanto se movian los dedos al mover o hacer zoom con dos dedos:
        // un gesto rapido de mover contaba como "toque" y deshacia. Ahora tiene que ser un toque de
        // verdad: corto y casi sin mover ningun dedo.
        if (now - downTime > 250 || gestureMoved > touchSlop || multiMoved > touchSlop * 1.5f) return;
        if (gestureMax == 2) callback.onUndoGesture();
        else if (gestureMax >= 3) callback.onRedoGesture();
    }

    // ==================================================================
    // Navegacion con dos dedos (v8.23): mover + zoom + giro, como Ibis.
    // La transformacion se calcula SIEMPRE desde el inicio del gesto
    // (matriz inicial + posicion inicial de los dedos), no sumando pequenos
    // cambios por evento: no se acumulan errores ni temblores.
    // ==================================================================

    /** Grados que hay que girar los dedos antes de que el lienzo empiece a girar. */
    private static final float NAV_ROT_START = 10f;
    /** Si el gesto empezo claramente como zoom, girar exige mas intencion. */
    private static final float NAV_ROT_START_AFTER_ZOOM = 18f;
    /** Cambio de distancia entre dedos (fraccion) antes de empezar a hacer zoom. */
    private static final float NAV_SCALE_START = .035f;
    /** Iman a 0, 90, 180 y 270 grados. */
    private static final float NAV_SNAP = 5f;

    private boolean navActive, navRotating, navScaling, navZoomFirst;
    private int navId1 = -1, navId2 = -1;
    private float navP1x, navP1y, navP2x, navP2y, navStartDist, navStartAng;
    private float navRotOffset, navScaleRef = 1f, navStartViewAngle;
    private final Matrix navStart = new Matrix();
    private boolean rotateEnabled = true, snapEnabled = true, viewFlipped;

    /** Empieza (o reancla) la navegacion con dos dedos; skipIndex = dedo que se levanta. */
    private void navBegin(MotionEvent e, int skipIndex) {
        int a = -1, b = -1;
        for (int i = 0; i < e.getPointerCount(); i++) {
            if (i == skipIndex) continue;
            if (a < 0) a = i;
            else if (b < 0) { b = i; break; }
        }
        if (a < 0 || b < 0) { navActive = false; return; }
        navId1 = e.getPointerId(a);
        navId2 = e.getPointerId(b);
        navP1x = e.getX(a); navP1y = e.getY(a);
        navP2x = e.getX(b); navP2y = e.getY(b);
        navStartDist = (float) Math.hypot(navP2x - navP1x, navP2y - navP1y);
        navStartAng = (float) Math.atan2(navP2y - navP1y, navP2x - navP1x);
        navStart.set(view);
        navStartViewAngle = viewAngle(view);
        // Al reanclar se conserva si ya estaba girando/ampliando (sin cambios de modo bruscos).
        if (skipIndex < 0) {
            navRotating = false;
            navScaling = false;
            navZoomFirst = false;
        }
        navRotOffset = 0f;
        navScaleRef = 1f;
        navActive = navStartDist > 8f;
    }

    private void twoFingers(MotionEvent e) {
        if (e.getPointerCount() < 2) return;
        if (!navActive) { navBegin(e, -1); return; }
        int ia = e.findPointerIndex(navId1), ib = e.findPointerIndex(navId2);
        if (ia < 0 || ib < 0) { navBegin(e, -1); return; }
        float ax = e.getX(ia), ay = e.getY(ia), bx = e.getX(ib), by = e.getY(ib);
        float dist = (float) Math.hypot(bx - ax, by - ay);
        if (dist < 8f || navStartDist < 8f) return;

        // Escala desde el inicio, con zona muerta para que mover no haga zoom tembloroso.
        float rawScale = dist / navStartDist;
        if (!navScaling && Math.abs(rawScale - 1f) > NAV_SCALE_START) {
            navScaling = true;
            navScaleRef = rawScale > 1f ? 1f + NAV_SCALE_START : 1f - NAV_SCALE_START;
            if (!navRotating) navZoomFirst = true;
        }
        float scale = navScaling ? rawScale / navScaleRef : 1f;

        // Giro desde el inicio, con umbral y sin salto al superarlo.
        float deg = 0f;
        if (rotateEnabled) {
            float raw = (float) Math.toDegrees(Math.atan2(by - ay, bx - ax) - navStartAng);
            while (raw > 180f) raw -= 360f;
            while (raw < -180f) raw += 360f;
            float start = navZoomFirst ? NAV_ROT_START_AFTER_ZOOM : NAV_ROT_START;
            if (!navRotating && Math.abs(raw) > start) {
                navRotating = true;
                navRotOffset = raw > 0 ? start : -start;
            }
            if (navRotating) {
                deg = raw - navRotOffset;
                if (snapEnabled) {
                    float total = navStartViewAngle + deg;
                    float snapped = Math.round(total / 90f) * 90f;
                    if (Math.abs(total - snapped) < NAV_SNAP) deg = snapped - navStartViewAngle;
                }
            }
        }

        // Limites de zoom (los mismos de antes: 3 % a 6000 %).
        float startScale = matrixScale(navStart);
        float target = startScale * scale;
        if (target < .03f) scale = .03f / startScale;
        else if (target > 60f) scale = 60f / startScale;

        float pmx = (navP1x + navP2x) * .5f, pmy = (navP1y + navP2y) * .5f;
        float qmx = (ax + bx) * .5f, qmy = (ay + by) * .5f;
        // M = T(qm) . R(deg) . S(scale) . T(-pm) . M0 : el punto de la imagen que
        // estaba bajo el centro de los dedos sigue bajo el centro de los dedos.
        view.set(navStart);
        view.postTranslate(-pmx, -pmy);
        if (scale != 1f) view.postScale(scale, scale);
        if (deg != 0f) view.postRotate(deg);
        view.postTranslate(qmx, qmy);

        gestureMoved = Math.max(gestureMoved, Math.abs(qmx - pmx) + Math.abs(qmy - pmy)
                + 80f * Math.abs(scale - 1f) + Math.abs(deg) * 2f);
        lastMidX = qmx;
        lastMidY = qmy;
        postInvalidateOnAnimation();
    }

    private final float[] navVals = new float[9];

    /** Angulo (grados) del eje X de la imagen en pantalla. */
    private float viewAngle(Matrix m) {
        m.getValues(navVals);
        return (float) Math.toDegrees(Math.atan2(navVals[Matrix.MSKEW_Y], navVals[Matrix.MSCALE_X]));
    }

    private float matrixScale(Matrix m) {
        m.getValues(navVals);
        return (float) Math.sqrt(navVals[Matrix.MSCALE_X] * navVals[Matrix.MSCALE_X]
                + navVals[Matrix.MSKEW_X] * navVals[Matrix.MSKEW_X]);
    }

    /** Girar con dos dedos: SI/NO (como "View Rotation" de Ibis). */
    public void setRotateEnabled(boolean on) { rotateEnabled = on; }
    public boolean isRotateEnabled() { return rotateEnabled; }

    /** Iman a 0/90/180/270 grados al girar. */
    public void setRotateSnap(boolean on) { snapEnabled = on; }
    public boolean isRotateSnap() { return snapEnabled; }

    /** Angulo actual del lienzo en grados (-180..180). */
    public float getViewRotation() { return viewAngle(view); }

    /** Restablecer vista: sin giro, sin volteo y encuadrada. */
    public void resetView() {
        viewFlipped = false;
        fit();
        showHud("Vista restablecida");
    }

    /**
     * Voltear la VISTA horizontalmente (solo para revisar proporciones). No toca
     * los pixeles: es un espejo en la matriz de vista alrededor del centro de la pantalla.
     */
    public void toggleViewFlip() {
        viewFlipped = !viewFlipped;
        view.postScale(-1f, 1f, getWidth() * .5f, getHeight() * .5f);
        showHud(viewFlipped ? "Vista volteada (el dibujo no cambia)" : "Vista normal");
        invalidate();
    }

    public boolean isViewFlipped() { return viewFlipped; }

    /** v8.53: gira la VISTA 90 grados (como girar la hoja en la mesa; el dibujo no cambia). */
    public void rotateView90() {
        if (project == null || getWidth() == 0) return;
        float cur = viewAngle(view);
        float target = Math.round(cur / 90f) * 90f + 90f;
        view.postRotate(target - cur, getWidth() * .5f, getHeight() * .5f);
        // v8.55: antes ponia fitted = false y el lienzo quedaba NEGRO (no se volvia a dibujar)
        int d = Math.round(((target % 360f) + 360f) % 360f);
        showHud(d == 0 ? "Lienzo derecho" : "Lienzo girado " + d + "°  (mantener pulsado: derecho)");
        invalidateDetail();
        scheduleDetail();
        invalidate();
    }

    private void armQuickPick() {
        cancelQuickTimer();
        quickArmed = true;
        quickRunnable = new Runnable() {
            @Override
            public void run() {
                if (!quickArmed || project == null || multi) return;
                if (drawing) cancelStroke();
                pendingStroke = false;
                pendingTap = false;
                panning = false;
                quickPick = true;
                updateQuickPick(pickX, pickY);
            }
        };
        handler.postDelayed(quickRunnable, 600);
    }

    private void cancelQuickTimer() {
        quickArmed = false;
        if (quickRunnable != null) handler.removeCallbacks(quickRunnable);
    }

    private void updateQuickPick(float sx, float sy) {
        pickX = sx;
        pickY = sy;
        imagePoint(sx, sy);
        int x = (int) point[0], y = (int) point[1];
        if (x >= 0 && y >= 0 && x < project.w && y < project.h) {
            pickColor = pickColorAt(x, y);
        }
        invalidate();
    }

    private void endQuickPick(boolean apply) {
        quickPick = false;
        if (apply) {
            paintColor = pickColor;
            if (callback != null) callback.onColorPicked(paintColor);
        }
        invalidate();
    }

    /** Pantalla a imagen, sin el desplazamiento del cursor. */
    private void imagePoint(float x, float y) {
        view.invert(inverse);
        point[0] = x;
        point[1] = y;
        inverse.mapPoints(point);
    }

    /** Pantalla a imagen, contando el cursor desplazado si esta activo. */
    private void toImage(float x, float y) {
        if (usesAim() && !quickPick) {
            x += aimDx;
            y += aimDy;
        }
        imagePoint(x, y);
    }

    // ==================================================================
    // Herramientas de un toque
    // ==================================================================

    private void runTapTool(float sx, float sy) {
        toImage(sx, sy);
        int px = (int) point[0], py = (int) point[1];
        if (px < 0 || py < 0 || px >= project.w || py >= project.h) return;
        switch (mode) {
            case MODE_WAND:
                runWand(px, py);
                break;
            case MODE_BUCKET:
                if (paintsSelection()) runWand(px, py);
                else runBucket(px, py);
                break;
            case MODE_PICKER:
                paintColor = pickColorAt(px, py);
                if (callback != null) callback.onColorPicked(paintColor);
                break;
            case MODE_ZONE:
                runZoneFill(px, py);
                break;
            case MODE_TONE:
                runToneFill(px, py);
                break;
            case MODE_BGERASE:
                runBgBucket(px, py);
                break;
        }
    }

    // ==================================================================
    // Trazos
    // ==================================================================

    private void startStroke(float sx, float sy) {
        long t0 = System.nanoTime();
        try {
            startStrokeInner(sx, sy);
        } finally {
            com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.STROKE_BEGIN, System.nanoTime() - t0);
        }
    }

    private void startStrokeInner(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0], iy = point[1];
        int px = (int) ix, py = (int) iy;
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;
        strokeRect = null;
        smoothInit = false;
        lastX = ix;
        lastY = iy;
        strokePath.cancel();
        beginStrokePath(ix, iy);

        switch (mode) {
            case MODE_BRUSH:
                beginSelectionStroke(subtract || penEraser, inside ? project.ref()[py * project.w + px] : 0);
                stamp(ix, iy);
                return;
            case MODE_PAINT:
            case MODE_ERASER:
                dynOn = false;
                // v8.77: el borrador del lapiz borra aunque la herramienta sea Pintar
                boolean eraseNow = mode == MODE_ERASER || penEraser;
                if (paintsSelection()) {
                    beginSelectionStroke(eraseNow, 0);
                } else {
                    // v8.28: antes de tocar la capa (se mira si estaba vacia)
                    if (mode == MODE_PAINT && !penEraser) maybeSuggestMultiply(needLayer());
                    if (!beginLayerStroke()) return;
                    strokeErase = eraseNow;
                    painted = 0;
                    dynOn = true;
                }
                beginLineStop();
                strokeArc = 0f;
                speedScale = 1f;
                dynCount = 0;
                lastScreenX = sx;
                lastScreenY = sy;
                lastMoveMs = System.currentTimeMillis();
                configureStabStroke(ix, iy);
                if (dynOn) dynStamp(ix, iy, 0f);
                else stamp(ix, iy);
                effR = -1f;
                return;
            case MODE_LIQUIFY:
                startLiquifyStroke(ix, iy);
                return;
            case MODE_SMUDGE:
            case MODE_BLUR:
                if (!beginLayerStroke()) return;
                painted = 0;
                blurCov.clear();
                blurTiles.clear();
                if (mode == MODE_BLUR) stampEffect(ix, iy, 0f, 0f);
                return;
            case MODE_BGERASE:
                if (!beginLayerStroke()) return;
                // si empiezas sobre lo ya borrado, no pasa nada: toma el color
                // del fondo apenas el pincel llegue a algo que queda
                if (bgSub != BG_SUB_RESTORE) takeBgSnapshot(strokeLayer);
                bgRestoreWarned = false;
                bgStroke.end();
                bgSegFresh = true;
                bgFast.end();
                // v8.54: Pincel rapido (solo mira el circulo del dedo; nada pesado al poner el dedo)
                if (bgSub == BG_SUB_BRUSH && inside) beginBgFastStroke(px, py);
                stamp(ix, iy);
                return;
            case MODE_MARKER:
                ensureMarkers();
                drawing = true;
                stamp(ix, iy);
                return;
            case MODE_CLONE:
            case MODE_HEAL:
                if (needLayer() == null) return;
                if (!cloneSrcSet) {
                    cloneSrcX = ix;
                    cloneSrcY = iy;
                    cloneSrcSet = true;
                    msg("Origen marcado con la cruz roja. Ahora pinta donde quieres copiar");
                    invalidate();
                    return;
                }
                if (!beginLayerStroke()) return;
                cloneDestX = ix;
                cloneDestY = iy;
                stamp(ix, iy);
                return;
            case MODE_LINE:
                linePts.clear();
                linePts.add(new float[]{ix, iy});
                drawing = true;
                invalidate();
                return;
            case MODE_LASSO:
                lasso.reset();
                lasso.moveTo(ix, iy);
                drawing = true;
                invalidate();
                return;
            case MODE_SCISSORS:
                if (!inside) return;
                drawing = true;
                if (!wireStarted) {
                    wireStarted = true;
                    firstAnchor = py * project.w + px;
                    wirePath.reset();
                    wirePath.moveTo(px, py);
                    setAnchorAsync(px, py);
                }
                return;
            case MODE_MAGNET:
                if (!inside) return;
                if (wire == null) wire = new LiveWire(project.ref(), project.w, project.h);
                wirePath.reset();
                wirePath.moveTo(px, py);
                firstAnchor = py * project.w + px;
                wireStarted = true;
                wire.setAnchor(px, py, 120);
                livePath = null;
                drawing = true;
                return;
            case MODE_MOVE:
                startMove(ix, iy);
                return;
        }
    }

    private void beginSelectionStroke(boolean erase, int ref) {
        clearSelectionStrokeBackup();
        strokeOnSelection = true;
        strokeErase = erase;
        refColor = ref;
        drawing = true;
    }

    /** Copia de la capa antes de pintar (para deshacer). Si no alcanza la memoria, avisa. */
    private boolean fillBackup(Layer t) {
        int n = project.w * project.h;
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                if (pxBackup == null || pxBackup.length != n) {
                    pxBackup = null;
                    pxBackup = new int[n];
                }
                System.arraycopy(t.px(), 0, pxBackup, 0, n);
                return true;
            } catch (OutOfMemoryError e) {
                pxBackup = null;
                handler.removeCallbacks(compactRunnable);
                try {
                    project.packInactive();
                } catch (OutOfMemoryError ignored) {
                }
                if (undo != null) undo.trimTo(0.3f);
                System.gc();
            }
        }
        msg("Ya no alcanza la memoria del telefono. Combina o borra alguna capa.");
        return false;
    }

    /**
     * Pintar "plano" (como Saturacion de opacidad de Ibis): repasar no
     * oscurece aunque sueltes y vuelvas a pintar. Viene prendido.
     */
    private boolean flatPaint = true;
    private boolean strokeLock;

    public void setFlatPaint(boolean b) {
        flatPaint = b;
    }

    public boolean isFlatPaint() {
        return flatPaint;
    }

    private int paintOver(int dst, int sa) {
        if (strokeLock) return Project.lockOver(dst, paintColor, sa);
        if (flatPaint) return Project.flatOver(dst, paintColor, sa);
        return Project.over(dst, paintColor, sa);
    }

    private boolean needsStrokeCoverage() {
        // cov solo sirve para herramientas que deben recordar cuanto cubrio cada
        // pixel durante EL MISMO trazo. Goma, Borrar fondo, Difuminar,
        // Borrosidad y Licuar no lo leen: reservar w*h para ellas era memoria
        // desperdiciada (varios MB en 2K/4K).
        // MODE_PAINT lee cov[i] en stampPaint y stampParticles. Si se omite,
        // el primer toque de Brocha provoca NullPointerException y vuelve a Mis obras.
        // MODE_BRUSH solo marca la seleccion; su motor no usa cov.
        return mode == MODE_PAINT || mode == MODE_CLONE || mode == MODE_HEAL || isShapeTool();
    }

    private boolean beginLayerStroke() {
        Layer t = needLayer();
        if (t == null) return false;
        strokeLock = t.alphaLock;
        int n = project.w * project.h;
        clearEffectStrokeBackup();
        effectStrokeBackupLayer = t;
        // El Corrector necesita una imagen completa como referencia para su solver.
        // El resto de pinceles usa respaldo regional por bloques.
        if (mode == MODE_HEAL && !fillBackup(t)) return false;
        if (needsStrokeCoverage()) {
            try {
                if (cov == null || cov.length != n) {
                    cov = new byte[n];
                } else if (covDirty != null) {
                    // v8.27: se limpia solo lo que toco el trazo anterior (antes se
                    // llenaban w*h bytes en cada trazo: 8 MB por toque en 4K).
                    int w = project.w;
                    for (int y = Math.max(0, covDirty.top); y < Math.min(project.h, covDirty.bottom); y++)
                        Arrays.fill(cov, y * w + Math.max(0, covDirty.left), y * w + Math.min(w, covDirty.right), (byte) 0);
                }
                covDirty = null;
            } catch (OutOfMemoryError e) {
                msg("No alcanzo la memoria para iniciar este trazo. Se libero lo temporal; prueba otra vez.");
                cov = null;
                return false;
            }
        } else {
            cov = null;
            covDirty = null;
        }
        strokeLayer = t;
        strokeOnSelection = false;
        selectionActive = project.hasSelection();
        drawing = true;
        return true;
    }

    private void moveStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0], iy = point[1];
        switch (mode) {
            case MODE_LASSO:
                lasso.lineTo(ix, iy);
                invalidate();
                return;
            case MODE_LINE:
                float[] last = linePts.get(linePts.size() - 1);
                if (Math.hypot(ix - last[0], iy - last[1]) > 2f) linePts.add(new float[]{ix, iy});
                invalidate();
                return;
            case MODE_SCISSORS:
                if (wire != null && wire.hasAnchor()) {
                    livePath = wire.pathTo((int) ix, (int) iy);
                    invalidate();
                }
                return;
            case MODE_MAGNET:
                if (wire == null || !wire.hasAnchor()) return;
                livePath = wire.pathTo((int) ix, (int) iy);
                if (Math.hypot(ix - lastX, iy - lastY) > 36f && livePath != null && livePath.length > 1) {
                    appendLive();
                    wire.setAnchor((int) ix, (int) iy, 120);
                    lastX = ix;
                    lastY = iy;
                }
                invalidate();
                return;
            case MODE_MOVE:
                moveDx = Math.round(ix - moveFromX);
                moveDy = Math.round(iy - moveFromY);
                if (moveGhost != null) {
                    // la capa entera se mueve como imagen: fluido, sin recalcular nada
                    invalidate();
                    return;
                }
                long now = System.currentTimeMillis();
                if (now - lastMoveApply > 45) {
                    lastMoveApply = now;
                    applyMove(false);
                }
                return;
        }
        if (mode == MODE_LIQUIFY) {
            moveLiquifyStroke(ix, iy);
            return;
        }
        if (mode == MODE_SMUDGE) {
            moveEffectStroke(ix, iy);
            invalidate();
            return;
        }
        boolean dyn = dynOn && (mode == MODE_PAINT || mode == MODE_ERASER);
        if (dyn && dynSpeed > 0f) {
            long now = System.currentTimeMillis();
            float dts = Math.max(1f, now - lastMoveMs);
            float v = (float) Math.hypot(sx - lastScreenX, sy - lastScreenY) / dts; // px de pantalla por ms
            float target = 1f - dynSpeed * 0.7f * Math.max(0f, Math.min(1f, (v - 0.3f) / 2.5f));
            speedScale = speedScale * 0.7f + target * 0.3f;
            lastMoveMs = now;
            lastScreenX = sx;
            lastScreenY = sy;
        }
        // v8.23: estabilizador + curva + espaciado continuo (core/StrokeEngine).
        if (!strokePath.isActive()) beginStrokePath(lastX, lastY);
        stampsThisEvent = 0;
        long bt0 = System.nanoTime();
        beginBatch();
        try {
            strokePath.add(ix, iy, strokeSink);
            if (laterStroke) rawAdd(ix, iy);
        } finally {
            endBatch();
            effR = -1f;
            com.pacco.animecut.core.PerfStats.add(mode == MODE_BGERASE ? com.pacco.animecut.core.PerfStats.BGERASE
                    : com.pacco.animecut.core.PerfStats.BRUSH, System.nanoTime() - bt0);
        }
        lastX = ix;
        lastY = iy;
        invalidate();
    }

    // ---- recorrido de los pinceles (v8.23) ----
    private final com.pacco.animecut.core.StrokeEngine strokePath = new com.pacco.animecut.core.StrokeEngine();
    private int stampsThisEvent;

    private final com.pacco.animecut.core.StrokeEngine.Sink strokeSink = new com.pacco.animecut.core.StrokeEngine.Sink() {
        @Override public float spacing(float arc) {
            boolean dyn = dynOn && (mode == MODE_PAINT || mode == MODE_ERASER);
            float stepR = dyn ? brushRadius * dynScale(arc) : brushRadius;
            // Borrar fondo visita el disco entero por estampa: 0,48 radios conserva
            // solapamiento sin repetir casi la misma busqueda tres veces.
            // v8.49b: el Pincel de Borrar fondo pinta TRAMOS (capsulas) unidos: paso mas largo, sin huecos
            // v8.54: Pincel rapido: capsulas unidas cada 0,8 radios (cada una cuesta ~1 ms)
            float spacing = mode == MODE_BGERASE ? (bgSub == BG_SUB_BRUSH ? .8f : .48f) : (dyn ? dynSpacing : .3f);
            // Borrosidad usa la cobertura maxima: basta con no dejar huecos.
            if (mode == MODE_BLUR) return Math.max(1f, rad() * .25f);
            float step = Math.max(0.5f, stepR * spacing);
            // Proteccion ante un evento enorme (tiron del sistema) en Borrar fondo.
            if (mode == MODE_BGERASE && stampsThisEvent > 48) step *= 2f;
            // v8.49: se quito el "salto por tiempo" de la v8.45: separaba las estampas y el borrado
            // salia a pedazos (tosco). Vuelve el paso de la v8.38.
            return step;
        }

        @Override public void stamp(float x, float y, float arc) {
            stampsThisEvent++;
            boolean dyn = dynOn && (mode == MODE_PAINT || mode == MODE_ERASER);
            if (dyn) {
                strokeArc = arc;
                dynStamp(x, y, arc);
            } else {
                CanvasView.this.stamp(x, y);
            }
        }
    };

    private void beginStrokePath(float ix, float iy) {
        laterStroke = false;
        forceStroke = false;
        strokePath.begin(ix, iy, com.pacco.animecut.core.StrokeEngine.windowForLevel(stabLevel), stabStep());
    }

    /** v8.78: 2 px de pantalla medidos en px de la imagen (el estabilizador no cambia con el zoom). */
    private float stabStep() {
        return 2f / Math.max(1e-3f, currentScale());
    }

    // ==================================================================
    // v8.78 ESTABILIZADOR 0..10 (En vivo / Al soltar) y PUNTAS forzadas por porcentaje
    // ==================================================================
    private int stabLevel = 0;
    private boolean stabLater;
    private boolean taperForce;
    private float taperStartPct = 30f, taperEndPct = 30f;
    private int taperShape = com.pacco.animecut.core.StrokeTaper.SOFT;
    /** El trazo actual: se corrige al soltar / lleva puntas forzadas. */
    private boolean laterStroke, forceStroke;
    private float[] rawPts = new float[512];
    private int rawN;

    public void setStabilizerLevel(int level, boolean later) {
        stabLevel = Math.max(0, Math.min(10, level));
        stabLater = later;
        stabilizer = stabLevel * 0.092f;
    }

    public int getStabilizerLevel() { return stabLevel; }
    public boolean isStabilizerLater() { return stabLater; }

    public void setForcedTaper(boolean on, float startPct, float endPct, int shape) {
        taperForce = on;
        taperStartPct = Math.max(0f, Math.min(100f, startPct));
        taperEndPct = Math.max(0f, Math.min(100f, endPct));
        taperShape = shape;
    }

    public boolean isForcedTaper() { return taperForce; }

    /** Pintar o borrar en una capa: se decide como va este trazo. */
    private void configureStabStroke(float ix, float iy) {
        boolean layerPaint = dynOn && !strokeOnSelection && (mode == MODE_PAINT || mode == MODE_ERASER);
        laterStroke = layerPaint && stabLater && stabLevel > 0;
        // las puntas forzadas son para pintar (no para la goma)
        forceStroke = layerPaint && taperForce && mode == MODE_PAINT && !strokeErase
                && (taperStartPct > 0f || taperEndPct > 0f);
        rawN = 0;
        if (laterStroke) {
            // en vivo se ve el trazo tal cual; al soltar se reemplaza por el suavizado (una sola vez)
            strokePath.begin(ix, iy, 1, 0f);
            rawAdd(ix, iy);
        } else {
            strokePath.begin(ix, iy, com.pacco.animecut.core.StrokeEngine.windowForLevel(stabLevel), stabStep());
        }
    }

    private void rawAdd(float x, float y) {
        if (rawN * 2 + 2 > rawPts.length) {
            float[] n = new float[rawPts.length * 2];
            System.arraycopy(rawPts, 0, n, 0, rawN * 2);
            rawPts = n;
        }
        rawPts[rawN * 2] = x;
        rawPts[rawN * 2 + 1] = y;
        rawN++;
    }

    /** El trazo necesita volver a dibujarse al soltar (puntas, suavizado al soltar o punta del pincel). */
    private boolean needsRerender() {
        return dynTaperEnd > 0f || forceStroke || laterStroke;
    }

    /** Al soltar: el estabilizador alcanza al dedo y se dibuja el ultimo tramo. */
    private void finishStrokePath() {
        if (!strokePath.isActive()) return;
        stampsThisEvent = 0;
        beginBatch();
        try {
            strokePath.finish(strokeSink);
        } finally {
            endBatch();
            effR = -1f;
        }
    }

    private void stamp(float x, float y) {
        if (!drawing) return;
        switch (mode) {
            case MODE_BRUSH:
                stampSelection(x, y);
                break;
            case MODE_PAINT:
            case MODE_ERASER:
                if (strokeOnSelection) stampSelection(x, y);
                else if (strokeErase) stampErase(x, y);
                else stampPaint(x, y);
                break;
            case MODE_BGERASE:
                stampBgErase(x, y);
                break;
            case MODE_BLUR:
                stampEffect(x, y, 0f, 0f);
                break;
            case MODE_MARKER:
                stampMarker(x, y);
                break;
            case MODE_CLONE:
            case MODE_HEAL:
                stampClone(x, y);
                break;
        }
    }

    private void endStroke() {
        if (!drawing) return;
        if (mode != MODE_LIQUIFY) finishStrokePath();
        drawing = false;
        smoothInit = false;
        if (mode == MODE_LIQUIFY) {
            endLiquifyStroke();
            return;
        }
        switch (mode) {
            case MODE_LASSO: {
                Path closed = new Path(lasso);
                closed.close();
                lasso.reset();
                fillPathIntoSelection(closed, "Lazo");
                if (callback != null && project != null && project.hasSelection())
                    callback.onLassoCompleted();
                return;
            }
            case MODE_SCISSORS:
                commitWire();
                return;
            case MODE_MAGNET: {
                appendLive();
                Path closed = new Path(wirePath);
                closed.close();
                scissorsReset();
                fillPathIntoSelection(closed, "Magnetico");
                return;
            }
            case MODE_LINE:
                finishLine();
                return;
            case MODE_MOVE:
                finishMove();
                return;
            case MODE_MARKER:
                schedulePreview();
                return;
            case MODE_HEAL:
                if (strokeRect != null) finishHeal(strokeRect);
                strokeRect = null;
                clearEffectStrokeBackup();
                return;
        }
        // Borrar fondo con pincel: al soltar no se toca nada mas.
        // Lo que se ve con el dedo abajo es exactamente lo que queda.
        if (dynOn && needsRerender() && !strokeOnSelection && (mode == MODE_PAINT || mode == MODE_ERASER)) {
            drawing = true;
            applyTaperEnd();
            drawing = false;
        }
        dynOn = false;
        effR = -1f;
        stopActive = false;
        inkTiles.clear();
        bgStroke.end();
        bgFast.end();
        bgSegFresh = true;
        inkBelow = inkAbove = null;
        if (strokeRect == null) {
            clearEffectStrokeBackup();
            clearSelectionStrokeBackup();
            return;
        }
        if (strokeOnSelection) {
            recordSelectionStrokeUndo(strokeErase ? "Borrar azul" : "Marcar azul");
            changed();
        } else if (strokeLayer != null) {
            if (mode == MODE_PAINT && painted == 0 && selectionActive) {
                msg("Hay algo seleccionado: solo se pinta dentro de lo azul. Quita la seleccion para pintar libre");
            }
            // v8.52 Toques suaves: lo que se acaba de pintar se funde solo (como el desenfoque de Procreate)
            if ((mode == MODE_PAINT || mode == MODE_ERASER) && strokeLayer.role == Layer.ROLE_SOFT && softBlendPct > 0)
                softBlendStroke();
            String undoLabel = mode == MODE_PAINT ? "Pincelada" : mode == MODE_ERASER ? "Goma"
                    : mode == MODE_SMUDGE ? "Difuminar" : mode == MODE_BLUR ? "Borrosidad"
                    : mode == MODE_LIQUIFY ? "Especial" : mode == MODE_BGERASE ? "Borrar fondo" : "Clonar";
            recordEffectStrokeUndo(undoLabel);
            project.markDirty();
            if (mode == MODE_BGERASE) {
                // v8.53: la Suavidad toca el borde despues del analisis: la copia gris se entera aqui
                if (bgGrayCur != null && bgGrayFor == strokeLayer && strokeRect != null)
                    com.pacco.animecut.core.GrayView.syncAlpha(strokeLayer.px(), bgGrayCur, project.w,
                            strokeRect.left, strokeRect.top, strokeRect.right, strokeRect.bottom);
                bgCleanLayer = strokeLayer;
                bgCleanVer = project.version;
            }
            wire = null;
            changed();
        }
        strokeRect = null;
        if (!detailValid && !busy) scheduleDetail();
    }

    /** Deshace el trazo en curso sin tocar el historial (llego un segundo dedo). */
    private void cancelStroke() {
        strokePath.cancel();
        if (!drawing) return;
        if (mode == MODE_LIQUIFY) {
            drawing = false;
            cancelLiquifyStroke();
            return;
        }
        drawing = false;
        dynOn = false;
        effR = -1f;
        stopActive = false;
        inkTiles.clear();
        bgStroke.end();
        bgFast.end();
        bgSegFresh = true;
        inkBelow = inkAbove = null;
        Rect r = strokeRect;
        strokeRect = null;
        lasso.reset();
        linePts.clear();
        if (mode == MODE_SCISSORS || mode == MODE_MAGNET) {
            livePath = null;
            if (mode == MODE_MAGNET) scissorsReset();
        }
        if (mode == MODE_MOVE && moveBackup != null) {
            Layer t = target();
            if (t != null) System.arraycopy(moveBackup, 0, t.px(), 0, moveBackup.length);
            if (moveSelBackup != null) System.arraycopy(moveSelBackup, 0, project.selection, 0, moveSelBackup.length);
            moveBackup = null;
            project.markDirty();
            refreshDisplay();
            refreshOverlay(null);
            return;
        }
        if (effectStrokeBackupLayer != null && mode != MODE_HEAL) {
            restoreEffectStrokeBackup();
            if (r != null) updateDisplayRegion(r);
            invalidate();
            return;
        }
        if (r == null) {
            invalidate();
            return;
        }
        int rw = r.width();
        if (strokeOnSelection && selectionStrokeBackupTiles.size() > 0) {
            restoreSelectionStrokeBackup();
            paintOverlay(r);
        } else if (strokeLayer != null && pxBackup != null) {
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(pxBackup, y * project.w + r.left, strokeLayer.px(), y * project.w + r.left, rw);
            }
            project.markDirty();
            updateDisplayRegion(r);
        }
        invalidate();
    }

    private void grow(Rect r) {
        if (r == null) return;
        if (strokeRect == null) strokeRect = new Rect(r);
        else strokeRect.union(r);
        if (cov != null) {
            if (covDirty == null) covDirty = new Rect(r);
            else covDirty.union(r);
        }
    }

    /** v8.27: zona de cov usada desde la ultima limpieza (se limpia solo eso). */
    private Rect covDirty;

    private Rect disk(float cx, float cy) {
        float br = rad();
        int x0 = Math.max(0, (int) Math.floor(cx - br) - 1);
        int y0 = Math.max(0, (int) Math.floor(cy - br) - 1);
        int x1 = Math.min(project.w, (int) Math.ceil(cx + br) + 2);
        int y1 = Math.min(project.h, (int) Math.ceil(cy + br) + 2);
        if (x0 >= x1 || y0 >= y1) return null;
        return new Rect(x0, y0, x1, y1);
    }

    private float falloff(int x, int y, float cx, float cy) {
        float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        float br = rad();
        if (d > br + 0.75f) return 0f;
        // v8.23: pinceles de 1 a 5 px. La cobertura depende SOLO de la distancia
        // al centro (rampa de 1 px centrada en el borde). Con estampas cada 0,5 px y
        // mezcla por maximo, eso equivale a la distancia al recorrido: el grosor de
        // la linea fina queda parejo (antes variaba ~25 % por el espaciado irregular).
        if (br < 2.5f) {
            float a = Math.max(0f, Math.min(1f, br + 0.5f - d));
            if (br < .5f) a *= br * 2f;
            if (a <= 0f) return 0f;
            if (dynGrain > 0f && dynOn) a *= 1f - dynGrain * com.pacco.animecut.core.BrushPreset.noise(x, y);
            return a;
        }
        if (d > br + 0.5f) return 0f;
        float inner = br * hardness;
        float a = d <= inner ? 1f : 1f - (d - inner) / Math.max(1f, br - inner);
        // borde suave de 1 pixel: el pincel duro ya no sale dentado
        float edge = br + 0.5f - d;
        if (edge < 1f) a = Math.min(a < 0f ? 0f : a, Math.max(0f, edge));
        if (a <= 0f) return 0f;
        if (dynGrain > 0f && dynOn) a *= 1f - dynGrain * com.pacco.animecut.core.BrushPreset.noise(x, y);
        return a;
    }

    // ------------------------------------------------------------------
    // Pinceles con vida (como Ibis): punta fina al empezar y al terminar,
    // grosor por velocidad, particulas, grano y acumulacion de aerografo.
    // Solo para Brocha y Goma sobre la capa.
    // ------------------------------------------------------------------

    private float dynTaperStart, dynTaperEnd, dynSpeed, dynGrain, dynSpacing = 0.3f, dynFlow;
    private int dynParticles;
    private boolean dynOn;
    private float effR = -1f;
    private float strokeArc, speedScale = 1f, lastScreenX, lastScreenY;
    private long lastMoveMs;
    private float[] dynPts = new float[0];
    private int dynCount;

    public void setBrushDynamics(float taperStart, float taperEnd, float speedThin, int particles,
                                 float grain, float spacing, float flow) {
        dynTaperStart = taperStart;
        dynTaperEnd = taperEnd;
        dynSpeed = speedThin;
        dynParticles = particles;
        dynGrain = grain;
        dynSpacing = spacing <= 0f ? 0.3f : spacing;
        dynFlow = flow;
    }

    private float rad() {
        return effR > 0f ? effR : brushRadius;
    }

    private float taperLen(float amount) {
        return amount * brushRadius * 6f;
    }

    /** Escala del grosor en ese punto del trazo (sin la punta final). */
    private float dynScale(float arc) {
        if (forceStroke) return speedScale;
        return com.pacco.animecut.core.BrushPreset.taper(arc, taperLen(dynTaperStart)) * speedScale;
    }

    /** v8.78: x, y, escala, largo y velocidad de cada estampa (para rehacer el trazo al soltar). */
    private void dynRecord(float x, float y, float scale, float arc) {
        if (!needsRerender()) return;
        if (dynCount * 5 + 5 > dynPts.length) {
            float[] n = new float[Math.max(320, dynPts.length * 2)];
            System.arraycopy(dynPts, 0, n, 0, dynCount * 5);
            dynPts = n;
        }
        int k = dynCount * 5;
        dynPts[k] = x;
        dynPts[k + 1] = y;
        dynPts[k + 2] = scale;
        dynPts[k + 3] = arc;
        dynPts[k + 4] = speedScale;
        dynCount++;
    }

    private void dynStamp(float x, float y, float arc) {
        float sc = dynScale(arc);
        effR = Math.max(0.5f, brushRadius * sc);
        stamp(x, y);
        dynRecord(x, y, sc, arc);
    }

    /**
     * Al soltar ya se sabe el largo total del trazo, asi que se vuelve a dibujar UNA vez (se
     * restaura lo que habia debajo y se pinta de nuevo, sin oscurecer ni tocar otros trazos):
     *  - punta final del pincel (como antes),
     *  - v8.78 puntas forzadas por porcentaje (Suave / Lineal),
     *  - v8.78 estabilizador "Al soltar": el recorrido completo suavizado reemplaza al de la vista previa.
     */
    private void applyTaperEnd() {
        if (dynCount < 1 || strokeRect == null || strokeLayer == null) return;
        float liveTotal = dynPts[(dynCount - 1) * 5 + 3];
        if (liveTotal <= 1f) return;      // un toque: queda el punto tal cual
        // 1) el recorrido final: el mismo de la vista previa, o el suavizado
        float[] src;
        int srcN;
        if (laterStroke && rawN >= 2) {
            src = com.pacco.animecut.core.StrokeEngine.smoothPath(rawPts, rawN, stabStep(),
                    com.pacco.animecut.core.StrokeEngine.windowForLevel(stabLevel));
            srcN = src.length / 2;
        } else {
            srcN = dynCount;
            src = new float[srcN * 2];
            for (int i = 0; i < srcN; i++) { src[i * 2] = dynPts[i * 5]; src[i * 2 + 1] = dynPts[i * 5 + 1]; }
        }
        if (srcN < 2) return;
        // 2) puntos muy juntos sobre la curva (las puntas finas necesitan estampas cercanas)
        final float dense = Math.max(0.35f, Math.min(1f, brushRadius * 0.05f));
        final float[][] acc = {new float[1536]};
        final int[] cnt = {0};
        com.pacco.animecut.core.StrokeEngine eng = new com.pacco.animecut.core.StrokeEngine();
        com.pacco.animecut.core.StrokeEngine.Sink col = new com.pacco.animecut.core.StrokeEngine.Sink() {
            @Override public float spacing(float arc) { return dense; }
            @Override public void stamp(float x, float y, float arc) {
                if (cnt[0] * 3 + 3 > acc[0].length) {
                    float[] n = new float[acc[0].length * 2];
                    System.arraycopy(acc[0], 0, n, 0, cnt[0] * 3);
                    acc[0] = n;
                }
                int k = cnt[0] * 3;
                acc[0][k] = x; acc[0][k + 1] = y; acc[0][k + 2] = arc;
                cnt[0]++;
            }
        };
        eng.begin(src[0], src[1], 1, 0f);
        col.stamp(src[0], src[1], 0f);
        for (int i = 1; i < srcN; i++) eng.add(src[i * 2], src[i * 2 + 1], col);
        eng.finish(col);
        int n = cnt[0];
        float[] d = acc[0];
        if (n < 2) return;
        float total = d[(n - 1) * 3 + 2];
        if (total <= 1f) return;
        // 3) restaurar lo de debajo y pintar otra vez con el grosor final
        int w = project.w;
        Rect r = new Rect(strokeRect);
        restoreLayerBackupRegion(r);
        if (cov != null) {
            for (int y = r.top; y < r.bottom; y++) {
                int off = y * w;
                Arrays.fill(cov, off + r.left, off + r.right, (byte) 0);
            }
        }
        painted = 0;
        float lenS = taperLen(dynTaperStart), lenE = taperLen(dynTaperEnd);
        int rec = 0;
        float next = 0f;
        beginBatch();
        try {
            for (int i = 0; i < n; i++) {
                float arc = d[i * 3 + 2];
                boolean last = i == n - 1;
                if (arc < next && !last) continue;
                // velocidad (si el pincel afina al ir rapido) en el mismo punto relativo del trazo
                float target = arc / total * liveTotal;
                while (rec < dynCount - 1 && dynPts[(rec + 1) * 5 + 3] <= target) rec++;
                float speed = dynPts[rec * 5 + 4];
                float shape = forceStroke
                        ? com.pacco.animecut.core.StrokeTaper.factor(arc, total, taperStartPct, taperEndPct, taperShape, brushRadius)
                        : com.pacco.animecut.core.BrushPreset.taper(arc, lenS)
                          * (lenE > 0f ? com.pacco.animecut.core.BrushPreset.taper(total - arc, lenE) : 1f);
                float sc = Math.max(0.02f, speed * shape);
                effR = Math.max(0.5f, brushRadius * sc);
                stamp(d[i * 3], d[i * 3 + 1]);
                next = arc + Math.max(0.35f, effR * dynSpacing);
            }
        } finally {
            endBatch();
        }
        effR = -1f;
    }

    /** Pincel sobre lo azul. Con "fino" solo agarra el color donde empezaste. */
    private void stampSelection(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureSelectionStrokeBackup(r)) return;
        int[] ref = smart ? project.ref() : null;
        int limit = tolerance + softness;
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                if (a <= 0f) continue;
                int i = row + x;
                int cap = 255;
                if (smart && !strokeErase) {
                    if (useBarrier && project.barrier != null && project.barrier[i] != 0) continue;
                    int d = ColorDist.dist(ref[i], refColor, colorMode);
                    if (d > limit) continue;
                    if (d > tolerance && softness > 0) cap = 255 - ((d - tolerance) * 255) / softness;
                }
                int cur = project.selection[i] & 0xFF;
                if (strokeErase) {
                    int v = cur - (int) (a * 255f);
                    project.selection[i] = (byte) (v < 0 ? 0 : v);
                } else {
                    int v = (int) (a * cap);
                    if (v > cur) project.selection[i] = (byte) v;
                }
            }
        }
        grow(r);
        paintOverlay(r);
        invalidate();
    }

    /** Brocha: pinta el color encima de la capa. Pinta tambien en lo transparente. */
    private final java.util.Random particleRnd = new java.util.Random();

    // ------------------------------------------------------------------
    // v8.27 "Proteger contornos" (antes "No pasar la linea negra"): la brocha pinta
    // solo la zona donde empezaste y no tapa la tinta.
    //
    // Fallos confirmados en v8.26 (manga real, capa_1 encima del dibujo):
    //  1. La linea salia de AutoLines sobre TODO el dibujo: los puntitos de la trama
    //     contaban como linea -> manchitas blancas ("nubecitas") dentro del trazo.
    //  2. La referencia incluia la capa donde se pinta: un brochazo rojo anterior
    //     contaba como linea y cortaba el siguiente.
    //  3. Cada pixel cuyo papel no era igual al de la zona (trama) se mezclaba con la
    //     "tinta": color sucio en toda la trama.
    //  4. La primera vez se buscaban las lineas de TODA la imagen en el hilo de la
    //     pantalla (en 4K, una pausa larga al primer toque).
    //
    // Ahora la tinta se calcula POR BLOQUES de 64x64 (con 8 px de margen) solo donde
    // pasa el pincel, desde las capas de referencia (Tinta B/N) o, si no hay, desde las
    // capas visibles que no son de color, usando la capa del trazo tal como estaba
    // ANTES del trazo. Tinta = oscuro y poco saturado; la trama no es tinta
    // (core/InkGuard). La mezcla con la tinta solo se hace a 2 px o menos de una linea
    // de verdad y solo en capas que tapan (Normal). En Multiplicar el color va plano.
    // ------------------------------------------------------------------
    private boolean lineStop;
    private byte[] allowMask;
    private Rect allowDirty;
    private boolean stopActive, stopSeeded, stopMultiply;
    private int[] stopQueue = new int[0];
    private int stopSeedColor;

    public void setLineStop(boolean on) {
        lineStop = on;
    }

    public boolean isLineStop() {
        return lineStop;
    }

    /** Cuantos pixeles se mete el color debajo de la linea (sin cruzarla). */
    private static final int UNDER_LINE = 2;

    private static final int INK_T = 64, INK_M = 8;

    private static final class InkTile {
        int x0, y0, w, h;
        int[] ref;
        byte[] line;
    }

    private final SparseArray<InkTile> inkTiles = new SparseArray<InkTile>();
    private LayerSrc[] inkBelow, inkAbove;
    private boolean inkUseStroke;
    private int inkStrokeOp, inkStrokeMode;
    /** Referencia y tinta de la zona de la estampa actual (reutilizados). */
    private int[] stopLocalRef = new int[0];
    private byte[] stopLocalLine = new byte[0];
    private int slx0, sly0, slw, slh;

    private static boolean isColorRole(Layer l) {
        return l.role == Layer.ROLE_COLOR || l.role == Layer.ROLE_BASE || l.role == Layer.ROLE_SHADOW
                || l.role == Layer.ROLE_LIGHT || l.role == Layer.ROLE_SHINE
                || l.role == Layer.ROLE_TONE || l.role == Layer.ROLE_RIM || l.role == Layer.ROLE_GRAD
                || l.role == Layer.ROLE_SOFT;
    }

    private LayerSrc[] inkSources(Layer[] ls, int from, int to, boolean refs) {
        int n = Math.max(0, to - from);
        if (n == 0) return new LayerSrc[0];
        Layer[] sub = new Layer[n];
        int[] ops = new int[n], modes = new int[n];
        boolean[] vs = new boolean[n], clips = new boolean[n];
        for (int k = 0; k < n; k++) {
            Layer l = ls[from + k];
            sub[k] = l;
            ops[k] = l.opacity;
            modes[k] = l.mode;
            clips[k] = l.clip;
            vs[k] = l.visible && (refs ? l.reference : !isColorRole(l));
        }
        return buildSources(sub, ops, vs, modes, clips, project.w, project.h);
    }

    private void beginLineStop() {
        stopActive = lineStop && mode == MODE_PAINT && !strokeOnSelection && strokeLayer != null
                && strokeLayer.role != Layer.ROLE_SOFT;   // v8.52: los toques cruzan las lineas (luego se funden)
        stopSeeded = false;
        inkTiles.clear();
        inkBelow = inkAbove = null;
        if (!stopActive) return;
        int n = project.w * project.h;
        try {
            if (allowMask == null || allowMask.length != n) {
                allowMask = new byte[n];
                allowDirty = null;
            }
        } catch (OutOfMemoryError e) {
            stopActive = false;
            return;
        }
        if (allowDirty != null) {
            for (int y = allowDirty.top; y < allowDirty.bottom; y++) {
                Arrays.fill(allowMask, y * project.w + allowDirty.left, y * project.w + allowDirty.right, (byte) 0);
            }
            allowDirty = null;
        }
        stopMultiply = strokeLayer.mode == Layer.MODE_MULTIPLY;
        Layer[] ls = project.layers.toArray(new Layer[0]);
        boolean refs = hasReferenceLayers();
        int k = project.layers.indexOf(strokeLayer);
        if (k < 0) k = ls.length;
        inkBelow = inkSources(ls, 0, k, refs);
        inkAbove = inkSources(ls, Math.min(ls.length, k + 1), ls.length, refs);
        inkUseStroke = strokeLayer.visible && (refs ? strokeLayer.reference : !isColorRole(strokeLayer));
        inkStrokeOp = strokeLayer.opacity;
        inkStrokeMode = strokeLayer.mode;
    }

    /** Pixel de la referencia de tinta (sobre papel blanco); la capa del trazo como estaba antes. */
    private int inkPixel(int i, int x, int y) {
        int w = project.w;
        int c = 0xFFFFFFFF;
        if (inkBelow != null && inkBelow.length > 0) c = over(inkBelow, c, x, y, w);
        if (inkUseStroke) {
            int col = strokeOriginalAt(i);
            int a = ((col >>> 24) * inkStrokeOp) / 255;
            if (a > 0) c = inkStrokeMode == Layer.MODE_NORMAL ? blendA(c, col, a) : (Project.blend(c, col, inkStrokeMode, a) | 0xFF000000);
        }
        if (inkAbove != null && inkAbove.length > 0) c = over(inkAbove, c, x, y, w);
        if (useBarrier && project.barrier != null && project.barrier[i] != 0) c = 0xFF000000; // linea marcada a mano
        return c;
    }

    private InkTile inkTile(int tx, int ty) {
        int w = project.w, h = project.h, cols = (w + INK_T - 1) / INK_T;
        int key = ty * cols + tx;
        InkTile t = inkTiles.get(key);
        if (t != null) return t;
        t = new InkTile();
        t.x0 = Math.max(0, tx * INK_T - INK_M);
        t.y0 = Math.max(0, ty * INK_T - INK_M);
        int x1 = Math.min(w, (tx + 1) * INK_T + INK_M), y1 = Math.min(h, (ty + 1) * INK_T + INK_M);
        t.w = x1 - t.x0;
        t.h = y1 - t.y0;
        t.ref = new int[t.w * t.h];
        for (int y = 0; y < t.h; y++) {
            int gy = t.y0 + y;
            for (int x = 0; x < t.w; x++) {
                int gx = t.x0 + x;
                t.ref[y * t.w + x] = inkPixel(gy * w + gx, gx, gy);
            }
        }
        t.line = com.pacco.animecut.core.InkGuard.inkMap(t.ref, t.w, t.h, mangaPrm.darkThr);
        inkTiles.put(key, t);
        return t;
    }

    /** Copia referencia y tinta de la zona r (+2 px) desde los bloques a los arreglos locales. */
    private void prepareStopLocal(Rect r) {
        int w = project.w, h = project.h;
        slx0 = Math.max(0, r.left - 2);
        sly0 = Math.max(0, r.top - 2);
        int x1 = Math.min(w, r.right + 2), y1 = Math.min(h, r.bottom + 2);
        slw = x1 - slx0;
        slh = y1 - sly0;
        int n = slw * slh;
        if (stopLocalRef.length < n) {
            stopLocalRef = new int[n];
            stopLocalLine = new byte[n];
        }
        for (int ty = sly0 / INK_T; ty <= (y1 - 1) / INK_T; ty++) {
            for (int tx = slx0 / INK_T; tx <= (x1 - 1) / INK_T; tx++) {
                InkTile t = inkTile(tx, ty);
                int cx0 = Math.max(slx0, tx * INK_T), cx1 = Math.min(x1, (tx + 1) * INK_T);
                int cy0 = Math.max(sly0, ty * INK_T), cy1 = Math.min(y1, (ty + 1) * INK_T);
                for (int y = cy0; y < cy1; y++) {
                    int so = (y - t.y0) * t.w + (cx0 - t.x0), dof = (y - sly0) * slw + (cx0 - slx0);
                    System.arraycopy(t.ref, so, stopLocalRef, dof, cx1 - cx0);
                    System.arraycopy(t.line, so, stopLocalLine, dof, cx1 - cx0);
                }
            }
        }
    }

    /** Hay tinta a 2 px o menos (en los arreglos locales). */
    private boolean nearInkLocal(int x, int y) {
        int lx = x - slx0, ly = y - sly0;
        for (int dy = -2; dy <= 2; dy++) {
            int yy = ly + dy;
            if (yy < 0 || yy >= slh) continue;
            int row = yy * slw;
            for (int dx = -2; dx <= 2; dx++) {
                int xx = lx + dx;
                if (xx < 0 || xx >= slw) continue;
                if (stopLocalLine[row + xx] != 0) return true;
            }
        }
        return false;
    }

    private int[] stopQ2 = new int[0];
    private byte[] stopD = new byte[0];

    private int[] stopQueue2(int n) {
        if (stopQ2.length < n) stopQ2 = new int[n];
        return stopQ2;
    }

    private byte[] stopDepth(int n) {
        if (stopD.length < n) stopD = new byte[n];
        return stopD;
    }

    /** Agranda la zona permitida dentro de este toque, sin cruzar la tinta. */
    private void growAllowed(Rect r, float cx, float cy) {
        int w = project.w;
        byte[] al = allowMask, ln = stopLocalLine;
        int lw = slw, ox = slx0, oy = sly0;
        int rw = r.width(), rh = r.height();
        if (stopQueue.length < rw * rh) stopQueue = new int[rw * rh];
        int[] q = stopQueue;
        int head = 0, tail = 0;
        float lim = rad() + 0.5f;
        float lim2 = lim * lim;
        if (!stopSeeded) {
            // primer toque: empieza en el pixel bajo el dedo (o el mas cercano sin tinta)
            int sx = Math.max(r.left, Math.min(r.right - 1, (int) cx));
            int sy = Math.max(r.top, Math.min(r.bottom - 1, (int) cy));
            int best = -1;
            float bd = Float.MAX_VALUE;
            for (int y = r.top; y < r.bottom; y++) {
                for (int x = r.left; x < r.right; x++) {
                    if (ln[(y - oy) * lw + x - ox] != 0) continue;
                    float d = (x - sx) * (x - sx) + (y - sy) * (y - sy);
                    if (d < bd) {
                        bd = d;
                        best = y * w + x;
                    }
                }
            }
            if (best < 0) return;
            al[best] = 1;
            q[tail++] = best;
            stopSeeded = true;
            int by = best / w, bx = best - by * w;
            stopSeedColor = stopLocalRef[(by - oy) * lw + bx - ox];
        } else {
            for (int y = r.top; y < r.bottom; y++) {
                for (int x = r.left; x < r.right; x++) {
                    int i = y * w + x;
                    if (al[i] == 1) q[tail++] = i;
                }
            }
        }
        while (head < tail) {
            int i = q[head++];
            int y = i / w, x = i - y * w;
            for (int k = 0; k < 4; k++) {
                int nx = k == 0 ? x - 1 : k == 1 ? x + 1 : x;
                int ny = k == 2 ? y - 1 : k == 3 ? y + 1 : y;
                if (nx < r.left || ny < r.top || nx >= r.right || ny >= r.bottom) continue;
                int j = ny * w + nx;
                if (al[j] != 0 || ln[(ny - oy) * lw + nx - ox] != 0) continue;
                float dx = nx + 0.5f - cx, dy = ny + 0.5f - cy;
                if (dx * dx + dy * dy > lim2) continue;
                al[j] = 1;
                if (tail < q.length) q[tail++] = j;
            }
        }
        int zoneEnd = tail;
        // debajo de la linea: el color entra hasta UNDER_LINE pixeles en la tinta,
        // asi no queda filo blanco entre el color y lo negro
        int[] dq = stopQueue2(rw * rh);
        int dh = 0, dt = 0;
        for (int k = 0; k < zoneEnd; k++) dq[dt++] = q[k];
        byte[] depth = stopDepth(rw * rh);
        java.util.Arrays.fill(depth, 0, rw * rh, (byte) 0);
        while (dh < dt) {
            int i = dq[dh++];
            int y = i / w, x = i - y * w;
            int dd = al[i] == 2 ? depth[(y - r.top) * rw + (x - r.left)] : 0;
            if (dd >= UNDER_LINE) continue;
            for (int k = 0; k < 4; k++) {
                int nx = k == 0 ? x - 1 : k == 1 ? x + 1 : x;
                int ny = k == 2 ? y - 1 : k == 3 ? y + 1 : y;
                if (nx < r.left || ny < r.top || nx >= r.right || ny >= r.bottom) continue;
                int j = ny * w + nx;
                if (al[j] != 0 || ln[(ny - oy) * lw + nx - ox] == 0) continue;
                float dx = nx + 0.5f - cx, dy = ny + 0.5f - cy;
                if (dx * dx + dy * dy > lim2) continue;
                al[j] = 2;
                depth[(ny - r.top) * rw + (nx - r.left)] = (byte) (dd + 1);
                if (dt < dq.length) dq[dt++] = j;
            }
        }
        if (allowDirty == null) allowDirty = new Rect(r);
        else allowDirty.union(r);
    }

    private void stampPaint(float cx, float cy) {
        // No se debe acceder a cov si el trazo no pudo reservar su memoria.
        if (cov == null || strokeLayer == null) return;
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureEffectStrokeBackup(r)) return;
        int[] px = strokeLayer.px();
        int alphaColor = paintColor >>> 24;
        boolean stop = stopActive && allowMask != null;
        if (stop) {
            prepareStopLocal(r);
            growAllowed(r, cx, cy);
        }
        if (dynOn && dynParticles > 0) {
            stampParticles(cx, cy, r, px, alphaColor);
            return;
        }
        boolean build = dynOn && dynFlow > 0f;
        // v8.27: lo que ya tiene toda la cobertura posible en este trazo no se recalcula
        // (con estampas cada 0,1 radio, la mayor parte del disco ya esta cubierta).
        int maxSa = (int) (brushOpacity * alphaColor);
        boolean mix = stop && !stopMultiply;
        float br = rad();
        boolean grain = dynGrain > 0f && dynOn;
        origReset();
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            float dy = y + 0.5f - cy;
            float reach = com.pacco.animecut.core.StampSpan.reach(br, dy);
            if (reach < 0f) continue;
            float solid = grain ? -1f : com.pacco.animecut.core.StampSpan.solid(br, hardness, dy);
            int xa = Math.max(r.left, (int) Math.floor(cx - reach - 0.5f)), xb = Math.min(r.right, (int) Math.ceil(cx + reach + 0.5f));
            for (int x = xa; x < xb; x++) {
                int i = row + x;
                int old = cov[i] & 0xFF;
                if (!build && old >= maxSa) continue;
                if (stop && allowMask[i] == 0) continue;
                if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                float dx = x + 0.5f - cx;
                float a = ((dx <= solid && -dx <= solid) ? 1f : falloff(x, y, cx, cy)) * brushOpacity;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (a <= 0f) continue;
                int sa = (int) (a * alphaColor);
                if (build) {
                    // aerografo: cada pasada suma un poco
                    int add = (int) (sa * dynFlow * (1f - old / 255f)) + 1;
                    sa = Math.min(alphaColor, old + add);
                }
                if (sa <= old) continue;
                cov[i] = (byte) sa;
                if (mix && nearInkLocal(x, y)) {
                    // Junto a la tinta (2 px): el color se mezcla con la linea como el balde:
                    // la linea conserva su forma y su antialias, sin filo blanco.
                    int li = (y - sly0) * slw + (x - slx0);
                    float pf = com.pacco.animecut.core.BucketFill.paperFraction(stopLocalRef, slw, slh, li, stopSeedColor);
                    int c = pf >= .92f ? paintColor : com.pacco.animecut.core.BucketFill.colorFor(stopLocalRef, slw, slh, li,
                            com.pacco.animecut.core.BucketFill.encode(pf), paintColor, stopSeedColor, false);
                    int dst = origAt(x, y, i);
                    px[i] = strokeLock ? Project.lockOver(dst, c, sa) : flatPaint ? Project.flatOver(dst, c, sa) : Project.over(dst, c, sa);
                    painted++;
                    continue;
                }
                // se mezcla contra como estaba antes del trazo: repasar no oscurece de mas
                px[i] = paintOver(origAt(x, y, i), sa);
                painted++;
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Aerografo de particulas: puntitos sueltos dentro del circulo. */
    private void stampParticles(float cx, float cy, Rect r, int[] px, int alphaColor) {
        float br = rad();
        int cnt = Math.max(4, (int) (dynParticles * Math.min(4f, br / 30f)));
        float dr = Math.max(0.7f, br * 0.05f);
        particleRnd.setSeed(((long) Float.floatToIntBits(cx) << 32) ^ Float.floatToIntBits(cy));
        int w = project.w, h = project.h;
        for (int k = 0; k < cnt; k++) {
            double ang = particleRnd.nextDouble() * Math.PI * 2, rr = Math.sqrt(particleRnd.nextDouble()) * br;
            float px0 = cx + (float) (Math.cos(ang) * rr), py0 = cy + (float) (Math.sin(ang) * rr);
            int x0 = Math.max(0, (int) (px0 - dr)), x1 = Math.min(w, (int) (px0 + dr) + 2);
            int y0 = Math.max(0, (int) (py0 - dr)), y1 = Math.min(h, (int) (py0 + dr) + 2);
            for (int y = y0; y < y1; y++) {
                for (int x = x0; x < x1; x++) {
                    float dx = x + 0.5f - px0, dy = y + 0.5f - py0;
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d > dr) continue;
                    float a = Math.min(1f, (dr - d) + 0.3f) * brushOpacity;
                    int i = y * w + x;
                    if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                    if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                    if (stopActive && allowMask != null && allowMask[i] == 0) continue;
                    int sa = (int) (a * alphaColor);
                    if (sa <= (cov[i] & 0xFF)) continue;
                    cov[i] = (byte) sa;
                    px[i] = paintOver(strokeOriginalAt(i), sa);
                    painted++;
                }
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Goma: baja la transparencia de la capa. Con seleccion, solo dentro de lo azul. */
    private void stampErase(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureEffectStrokeBackup(r)) return;
        int[] px = strokeLayer.px();
        // v8.33: sin raiz por pixel en el interior duro (una por fila), lo ya transparente se salta
        // y el original se lee por bloque (no un mapa por pixel). Mismo resultado que antes.
        float br = rad();
        boolean grain = dynGrain > 0f && dynOn;
        origReset();
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            float dy = y + 0.5f - cy;
            float reach = com.pacco.animecut.core.StampSpan.reach(br, dy);
            if (reach < 0f) continue;
            float solid = grain ? -1f : com.pacco.animecut.core.StampSpan.solid(br, hardness, dy);
            int xa = Math.max(r.left, (int) Math.floor(cx - reach - 0.5f)), xb = Math.min(r.right, (int) Math.ceil(cx + reach + 0.5f));
            for (int x = xa; x < xb; x++) {
                int i = row + x;
                int cur = px[i] >>> 24;
                if (cur == 0) continue;
                float dx = x + 0.5f - cx;
                float a = (dx <= solid && -dx <= solid) ? brushOpacity : falloff(x, y, cx, cy) * brushOpacity;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (a <= 0f) continue;
                int orig = origAt(x, y, i) >>> 24;
                int want = (int) (orig * (1f - a));
                if (want < cur) px[i] = (want << 24) | (px[i] & 0x00FFFFFF);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    // ---- v8.33: lectura del original del trazo por bloques (cache del ultimo bloque) ----
    private int oKey = -1, oLeft, oTop, oTw;
    private int[] oTile;

    private void origReset() { oKey = -1; oTile = null; }

    /** Igual que strokeOriginalAt(i) pero sin division ni busqueda por pixel. */
    private int origAt(int x, int y, int i) {
        if (mode == MODE_HEAL) return strokeOriginalAt(i);
        int tx = x / LIQUIFY_TILE, ty = y / LIQUIFY_TILE;
        int key = ty * ((project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE) + tx;
        if (key != oKey) {
            oKey = key;
            oTile = effectStrokeBackupTiles.get(key);
            oLeft = tx * LIQUIFY_TILE;
            oTop = ty * LIQUIFY_TILE;
            oTw = Math.min(LIQUIFY_TILE, project.w - oLeft);
        }
        int[] t = oTile;
        if (t == null) return strokeLayer.px()[i];
        return t[(y - oTop) * oTw + (x - oLeft)];
    }

    // ---- borrar fondo por color ----
    // v8.32: las reglas de tamano fijo de v8.28-v8.31 (barrera por bloques de 64 px, cierres de
    // 1/7/10 px, distancia de chaflan con BG_NEAR = 4, rincones de 300 px) se quitaron: el Balde y
    // el Pincel protegido usan ahora el motor compartido core/BgEngine (ver ahi).

    /** Borde duro con antialias de 1 px (Restaurar). */
    private float bgFalloff(int x, int y, float cx, float cy) {
        float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        return Math.max(0f, Math.min(1f, rad() + 0.5f - d));
    }

    /**
     * v8.30: Borrar fondo compara colores con el TONO tambien (ColorDist.HUE) cuando el modo
     * elegido es el normal (RGB). La sombra oscura del personaje y un fondo oscuro de otro tono
     * dejan de verse "parecidos" (la cueva azulada y la sombra verde del duende).
     */
    private int bgMode() {
        return colorMode == ColorDist.RGB ? ColorDist.HUE : colorMode;
    }

    // ---- v8.29: Borrar fondo simple: Toque / Pincel / Goma / Restaurar ----
    public static final int BG_SUB_TAP = 0, BG_SUB_BRUSH = 1, BG_SUB_ERASER = 2, BG_SUB_RESTORE = 3;
    private int bgSub = BG_SUB_TAP;

    public void setBgSub(int s) {
        if (aiMark) cancelAiMark();      // v8.36: elegir una herramienta manual deja la marca de la IA
        bgSub = Math.max(0, Math.min(3, s));
        bgBucket = bgSub == BG_SUB_TAP;
    }

    public int getBgSub() { return bgSub; }

    /**
     * Copia de la capa ANTES de borrar el fondo (para Restaurar y para rellenar agujeros con
     * Limpiar). Una sola capa a la vez; si no hay memoria, Restaurar avisa y no hace nada.
     */
    private Layer bgSnapLayer;
    private int[] bgSnap;

    private int bgSnapGeom = -1;

    private void takeBgSnapshot(Layer l) {
        if (l == null) return;
        int[] sn = bgSnapFor(l);
        // v8.53: si desde el ultimo trazo de Borrar fondo en esta capa no hubo otro cambio, la copia
        // ya esta al dia: no se recorre la imagen entera al poner el dedo (eso daba el retraso)
        if (sn != null && bgCleanLayer == l && project != null && bgCleanVer == project.version) return;
        if (sn != null) {
            // v8.32: lo que se pinto despues con otras herramientas entra a la copia (Restaurar no
            // lo pisa y el analisis ve el dibujo de ahora); lo borrado conserva su color de antes
            int[] px = l.px();
            int changed = 0;
            for (int i = 0; i < px.length; i++) {
                int c = px[i];
                if (c != sn[i] && (c >>> 24) >= (sn[i] >>> 24)) { sn[i] = c; changed++; }
            }
            // v8.49: antes la copia se marcaba "cambiada" en CADA trazo aunque no cambiara nada, y el
            // guardado automatico (cada 4 s) volvia a comprimir una imagen PNG completa una y otra
            // vez mientras borrabas: el telefono se trababa y el borrado salia con retraso.
            if (changed > 0) snapChanged();
            return;
        }
        try {
            setBgSnap(l, l.px().clone());
        } catch (OutOfMemoryError oom) {
            setBgSnap(null, null);
        }
    }

    /** v8.45: true si la capa elegida es la tinta bloqueada de Colorear manga (y hay color encima). */
    public boolean needsMergeForBg() {
        if (project == null || !project.mangaMode) return false;
        Layer a = project.activeLayer();
        if (a == null) return false;
        if (a.locked) return true;
        return a.role == Layer.ROLE_TONE || a.mode == Layer.MODE_MULTIPLY;
    }

    /**
     * v8.45: Borrar fondo despues de colorear: lo visible (tinta + colores) se junta en una capa
     * nueva "personaje coloreado" arriba de todo; las demas se ocultan (no se borran). Asi el
     * borrado y Restaurar trabajan sobre el dibujo ya pintado. Deshacer lo devuelve.
     */
    public boolean mergeForBgErase() {
        if (project == null) return false;
        int[] px;
        try {
            px = com.pacco.animecut.core.Compositor.flatten(project);
        } catch (OutOfMemoryError e) {
            msg("Falta memoria para juntar las capas");
            return false;
        }
        undo.setLabel("Juntar para borrar fondo");
        undo.begin();
        undo.recordProps();
        undo.recordStruct();
        undo.end();
        for (Layer l : project.layers) l.visible = false;
        Layer nl = new Layer(uniqueName("personaje coloreado"), px);
        project.layers.add(nl);
        project.active = project.layers.size() - 1;
        setBgSnap(nl, px.clone());
        layersChanged();
        invalidateBgAnalysis();
        return true;
    }

    private void setBgSnap(Layer l, int[] snap) {
        bgSnapLayer = snap == null ? null : l;
        bgSnap = snap;
        bgSnapGeom = project == null ? -1 : project.geomVersion;
        if (project != null) {
            project.restoreLayer = bgSnapLayer;
            project.restorePx = snap;
            if (snap == null) project.restorePng = null;
        }
        snapChanged();
    }

    private void snapChanged() {
        if (project != null) project.restoreVer++;
    }

    /**
     * Copia para Restaurar de esta capa. v8.39: ya no hace falta haber usado Borrar fondo en
     * esta sesion. En orden: (1) la copia de esta sesion; (2) la copia guardada con la obra
     * (al cerrar y volver a abrir); (3) la capa OCULTA de abajo con dibujo (la imagen original
     * que quedo escondida al recortar o duplicar). Si no hay ninguna, no hay nada que devolver.
     */
    private int[] bgSnapFor(Layer l) {
        if (l == null || project == null) return null;
        int n;
        try { n = l.px().length; } catch (OutOfMemoryError e) { return null; }
        if (bgSnapLayer == l && bgSnap != null && bgSnap.length == n && bgSnapGeom == project.geomVersion) return bgSnap;
        // (2) guardada con la obra
        if (project.restoreLayer == l && project.restorePx == null && project.restorePng != null) {
            int[] d = com.pacco.animecut.core.ProjectIO.decodeFull(project.restorePng, project.w, project.h);
            if (d != null && d.length == n) {
                int ver = project.restoreVer, pv = project.restorePngVer;
                bgSnapLayer = l;
                bgSnap = d;
                bgSnapGeom = project.geomVersion;
                project.restorePx = d;
                // es la misma copia que ya esta comprimida: no hace falta volver a comprimirla
                if (pv == ver) project.restorePngVer = project.restoreVer;
                return d;
            }
        }
        // (3) la imagen original oculta debajo
        int idx = project.layers.indexOf(l);
        int sig = 17;
        for (int k = idx - 1; k >= 0; k--) {
            Layer o = project.layers.get(k);
            sig = sig * 31 + System.identityHashCode(o) * (o.visible ? 3 : 7);
        }
        if (bgNoSrcLayer == l && bgNoSrcSig == sig) return null;    // ya se busco y no hay
        for (int k = idx - 1; k >= 0; k--) {
            Layer o = project.layers.get(k);
            if (o.visible || o.reference) continue;
            Layer.Packed pk = o.packedOrNull();
            if (pk != null && pk.empty()) continue;
            try {
                int[] op = new int[n];
                o.copyTo(op, project.w, project.h);
                if (!hasInk(op)) continue;
                setBgSnap(l, op);
                bgNoSrcLayer = null;
                return bgSnap;
            } catch (OutOfMemoryError e) {
                return null;
            }
        }
        bgNoSrcLayer = l;
        bgNoSrcSig = sig;
        return null;
    }

    private Layer bgNoSrcLayer;
    private int bgNoSrcSig;

    private static boolean hasInk(int[] px) {
        int step = Math.max(1, px.length / 4096);
        for (int i = 0; i < px.length; i += step) if ((px[i] >>> 24) > 8) return true;
        return false;
    }

    public boolean canRestoreBg() {
        return project != null && bgSnapFor(project.activeLayer()) != null;
    }

    /** Disco del pincel con borde de 1 px (para Goma y Restaurar). */
    private void stampBgManual(float cx, float cy) {
        Layer t = strokeLayer;
        if (t == null) return;
        Rect r = disk(cx, cy);
        if (r == null) return;
        int[] snap = bgSub == BG_SUB_RESTORE ? bgSnapFor(t) : null;
        if (bgSub == BG_SUB_RESTORE && snap == null) {
            if (!bgRestoreWarned) {
                bgRestoreWarned = true;
                msg("Nada que restaurar: esta capa no tiene una copia de antes ni una imagen original oculta debajo");
            }
            return;
        }
        if (!captureEffectStrokeBackup(r)) return;
        int w = project.w;
        int[] px = t.px();
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                float f = bgFalloff(x, y, cx, cy);
                if (f <= 0f) continue;
                int i = y * w + x;
                if (selectionActive) f *= (project.selection[i] & 0xFF) / 255f;
                if (f <= 0f) continue;
                int c = px[i];
                if (snap == null) {
                    int a = c >>> 24;
                    int na = Math.round(a * (1f - f));
                    if (na < a) px[i] = (na << 24) | (c & 0x00FFFFFF);
                } else {
                    int o = snap[i];
                    int a = c >>> 24, oa = o >>> 24;
                    if (c == o) continue;
                    int na = Math.round(a + (oa - a) * f);
                    // el color vuelve al original (no al color "limpio" del borde)
                    px[i] = (na << 24) | ((f >= 0.5f || a == 0) ? (o & 0x00FFFFFF) : (c & 0x00FFFFFF));
                }
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /**
     * v8.29: boton Limpiar restos (escoba): pedazos sueltos, filo semitransparente, papel suelto
     * pegado a lo borrado y agujeritos (con la copia de antes). Un solo Deshacer.
     */
    public void cleanBackgroundRemnants() {
        if (project == null || busy) return;
        final Layer t = needLayer();
        if (t == null || refuseLocked(t)) return;
        final int[] snap = bgSnapFor(t);
        final byte[] sel = project.hasSelection() ? project.selection : null;
        final int W = project.w, H = project.h;
        final int[] src = t.px();
        final com.pacco.animecut.core.BgCleanup.Result[] out = new com.pacco.animecut.core.BgCleanup.Result[1];
        setBusy(true);
        showHud("Limpiando restos...");
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    out[0] = com.pacco.animecut.core.BgCleanup.run(src, W, H, snap, sel, bgWidthFor(t).hGlobal);
                } catch (OutOfMemoryError oom) {
                    out[0] = null;
                }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                com.pacco.animecut.core.BgCleanup.Result r = out[0];
                if (r == null) { msg("Limpiar necesita mas memoria; cierra otras aplicaciones"); return; }
                lastBgCleanup = r;
                if (r.pairs.length == 0) { showHud("No quedaron restos"); return; }
                Rect box = new Rect(r.x0, r.y0, r.x1, r.y1);
                undo.setLabel("Limpiar restos");
                undo.recordLayer(t, box);
                int[] px = t.px();
                for (int q = 0; q + 1 < r.pairs.length; q += 2) px[r.pairs[q]] = r.pairs[q + 1];
                featherBg(t, box);
                project.markDirty();
                refreshDisplay();
                changed();
                showHud("Limpio: " + (r.islands + r.bits) + " restos, " + r.fringe + " px de borde"
                        + (r.holes > 0 ? ", " + r.holes + " px de agujeros" : ""));
            }
        });
    }

    /** Ultimo resultado de Limpiar (pruebas). */
    public com.pacco.animecut.core.BgCleanup.Result lastBgCleanup;

    private boolean bgRestoreWarned;

    /** Tinta: oscura y casi sin color (o muy oscura), sin depender del fondo. */
    private static boolean inkAbs(int c) {
        int l = com.pacco.animecut.core.BgGuard.luma(c | 0xFF000000);
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        int sat = Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
        return l < 45 || (l < 70 && sat < 60);
    }


    /**
     * v8.29: Pincel inteligente de Borrar fondo.
     *  1) ALCANCE: lo unido (sin cruzar la linea negra) a lo ya transparente o al punto anterior
     *     del dedo. Si el dedo esta sobre el personaje encerrado por su linea, no se borra nada.
     *  2) COLOR: con "siempre" se toma el color bajo el dedo (si no es tinta), sin limites: asi
     *     sigue los cambios del fondo (cueva oscura, luz celeste). Antes solo aceptaba colores
     *     parecidos al del comienzo y quedaban zonas que no se podian borrar.
     *  3) BORRADO: dentro del circulo, todo lo parecido al fondo y unido al alcance se borra
     *     ENTERO (sin restos a medias que se vean como halo). Junto a la linea: si es mas oscuro
     *     que el fondo conserva su parte de tinta; si es claro (brillo del JPEG) se borra.
     *  Lo ya borrado sirve de puente: repasar sobre las sobras siempre las alcanza.
     */
    /** v8.49b: punto de la estampa anterior del Pincel de Borrar fondo (fresh = empieza trazo). */
    private float bgSegX, bgSegY;
    private boolean bgSegFresh = true;

    private void stampBgErase(float cx, float cy) {
        Layer t = strokeLayer;
        if (t == null) return;
        if (bgSub == BG_SUB_ERASER) {
            stampBgEraser(cx, cy);
            return;
        }
        if (bgSub == BG_SUB_RESTORE) {
            stampBgManual(cx, cy);
            return;
        }
        // v8.54: PINCEL RAPIDO (core/BgBrushFast). Antes (v8.32-v8.53) cada toque analizaba una
        // ventana grande con el motor del Balde y cada trazo calculaba el fondo de TODA la imagen:
        // el borrado iba detras del dedo. Ahora solo se mira el circulo del dedo y unos px mas.
        if (!bgFast.isStarted()) {
            // el dedo empezo FUERA de la imagen (para llegar a la tira del borde): el trazo empieza
            // donde el circulo toca la imagen
            float rr = rad();
            if (cx + rr < 0 || cy + rr < 0 || cx - rr >= project.w || cy - rr >= project.h) return;
            int ix = Math.max(0, Math.min(project.w - 1, (int) cx)), iy = Math.max(0, Math.min(project.h - 1, (int) cy));
            beginBgFastStroke(ix, iy);
            if (!bgFast.isStarted()) return;
        }
        // tramo desde la estampa anterior de este trazo (capsula: sin huecos entre estampas)
        float ax = bgSegFresh ? cx : bgSegX, ay = bgSegFresh ? cy : bgSegY;
        bgSegFresh = false;
        bgSegX = cx;
        bgSegY = cy;
        Rect r = disk(cx, cy);
        if (r == null) return;
        Rect ra = disk(ax, ay);
        if (ra != null) r.union(ra);
        if (!captureEffectStrokeBackup(r)) return;
        if (!bgFast.dab(t.px(), ax, ay, cx, cy, rad())) return;
        Rect ch = new Rect(bgFast.rx0, bgFast.ry0, bgFast.rx1, bgFast.ry1);
        if (bgFeather > 0.05f) {
            if (bgSpeckRect == null) bgSpeckRect = new Rect(ch);
            else bgSpeckRect.union(ch);
        }
        grow(ch);
        updateDisplayRegion(ch);
    }

    // ---- v8.54: Pincel rapido ----
    private final com.pacco.animecut.core.BgBrushFast bgFast = new com.pacco.animecut.core.BgBrushFast();

    /** Empieza un trazo del pincel rapido: solo toma el color del fondo (nada de la imagen entera). */
    private void beginBgFastStroke(int px0, int py0) {
        bgSegFresh = true;
        Layer t = strokeLayer;
        if (t == null || project == null) return;
        com.pacco.animecut.core.BgBrushFast f = bgFast;
        f.tol = bgTolerance;
        f.mode = bgMode();
        f.follow = !bgOnce;
        f.protect = protectOn;
        f.protectColor = protectColor;
        f.protectTol = Math.max(6, tolerance / 2);
        f.gray = grayActive() ? grayView.matrix() : null;
        int sx = Math.max(0, Math.min(project.w - 1, px0)), sy = Math.max(0, Math.min(project.h - 1, py0));
        f.gap = bgFastGap(t, sx, sy);
        boolean ok;
        try {
            ok = f.begin(t.px(), bgSnapFor(t), project.w, project.h, selectionActive ? project.selection : null,
                    sx, sy, (int) Math.max(2, brushRadius));
        } catch (OutOfMemoryError oom) {
            ok = false;
            msg("Borrar fondo necesita mas memoria; cierra otras aplicaciones");
        }
        if (!ok) return;
        bgRef = f.refReal;
        bgRefValid = true;
    }

    /**
     * Cortes de la linea que el pincel no cruza: segun el grosor de linea medido en otro hilo al
     * abrir Borrar fondo. Si todavia no esta medido NO se espera (antes el dedo esperaba la medida
     * de la imagen entera): se usa un valor normal.
     */
    private int bgFastGap(Layer t, int x, int y) {
        com.pacco.animecut.core.BgEngine.Width wd = bgWidth;
        float hh = wd != null && bgWidthLayer == t ? wd.hAt(x, y) : 1.5f;
        int g = Math.round((2f * hh + 1.5f) * bgGapScale * 0.7f);
        return Math.max(2, Math.min(8, g));
    }

    /**
     * v8.32: BORRADOR MANUAL de Borrar fondo: borra exactamente donde pasa el dedo (tambien los
     * restos que el pincel protegido no toca). Dureza y fuerza propias (no cambian la Goma
     * normal). Repasar en el mismo trazo no acumula mas que la fuerza elegida.
     */
    private float bgEraserHard = 0.85f, bgEraserStrength = 1f;

    public void setBgEraserHard(float v) { bgEraserHard = Math.max(0f, Math.min(1f, v)); }
    public float getBgEraserHard() { return bgEraserHard; }
    public void setBgEraserStrength(float v) { bgEraserStrength = Math.max(0.02f, Math.min(1f, v)); }
    public float getBgEraserStrength() { return bgEraserStrength; }

    private void stampBgEraser(float cx, float cy) {
        Layer t = strokeLayer;
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureEffectStrokeBackup(r)) return;
        int w = project.w;
        int[] px = t.px();
        float br = rad();
        float inner = br * bgEraserHard;
        origReset();
        for (int y = r.top; y < r.bottom; y++) {
            float dyr = y + 0.5f - cy;
            float in2 = inner * inner - dyr * dyr;
            float solid = in2 >= 0f ? (float) Math.sqrt(in2) : -1f;   // una raiz por fila
            for (int x = r.left; x < r.right; x++) {
                if ((px[y * w + x] >>> 24) == 0) continue;
                float dx = x + 0.5f - cx, dy = dyr;
                float f;
                float d = (dx <= solid && -dx <= solid) ? 0f : (float) Math.sqrt(dx * dx + dy * dy);
                if (d <= inner) f = 1f;
                else if (d >= br + 0.5f) continue;
                else if (br + 0.5f - inner <= 1f) f = Math.max(0f, Math.min(1f, br + 0.5f - d));
                else { float u = (d - inner) / (br + 0.5f - inner); f = 1f - u * u * (3f - 2f * u); }
                f *= bgEraserStrength;
                int i = y * w + x;
                if (selectionActive) f *= (project.selection[i] & 0xFF) / 255f;
                if (f <= 0f) continue;
                int orig = origAt(x, y, i) >>> 24;
                int want = (int) (orig * (1f - f));
                int cur = px[i] >>> 24;
                if (want < cur) px[i] = (want << 24) | (px[i] & 0x00FFFFFF);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    // ---- v8.32: motor compartido ----
    private final com.pacco.animecut.core.BgStroke bgStroke = new com.pacco.animecut.core.BgStroke();
    private com.pacco.animecut.core.BgEngine bgTapEng;
    private com.pacco.animecut.core.BgEngine.Width bgWidth;
    private Object bgWidthLayer;
    private int[] bgWidthSnap, bgWidthPx;
    private float bgGapScale = 1f;

    /** "Cerrar huecos": 0,5 a 3 veces el radio medido (1 = normal). */
    public void setBgGapScale(float v) { bgGapScale = Math.max(0.5f, Math.min(3f, v)); }
    public float getBgGapScale() { return bgGapScale; }

    /** Grosor de linea medido para la capa (se repite solo si cambia la capa o la copia). */
    /** v8.45: candado propio (antes era el de toda la vista: otras tareas esperaban a la medicion). */
    private final Object bgWidthLock = new Object();

    private com.pacco.animecut.core.BgEngine.Width bgWidthFor(Layer t) {
        synchronized (bgWidthLock) { return bgWidthForLocked(t); }
    }

    private com.pacco.animecut.core.BgEngine.Width bgWidthForLocked(Layer t) {
        int[] snap = bgSnapFor(t);
        // la copia de Restaurar nace igual a la capa: no hace falta volver a medir por ella
        if (bgWidth != null && bgWidthLayer == t && bgWidthPx == t.px()) return bgWidth;
        com.pacco.animecut.core.BgEngine.Width wd;
        try {
            wd = com.pacco.animecut.core.BgEngine.measure(t.px(), snap, project.w, project.h);
        } catch (OutOfMemoryError oom) {
            wd = new com.pacco.animecut.core.BgEngine.Width();
        }
        bgWidth = wd;
        bgWidthLayer = t;
        bgWidthSnap = snap;
        bgWidthPx = t.px();
        return wd;
    }

    /** Vuelve a medir la proxima vez (deshacer, rehacer, otra imagen). */
    public void invalidateBgAnalysis() {
        synchronized (bgWidthLock) {
            bgWidth = null;
            bgWidthLayer = null;
            bgWidthSnap = null;
            bgWidthPx = null;
        }
        // v8.55: se mide un momento despues (deshacer muchas veces seguidas lanzaba un hilo por toque)
        handler.removeCallbacks(prefetchBgRun);
        if (mode == MODE_BGERASE) handler.postDelayed(prefetchBgRun, 700);
    }

    private final Runnable prefetchBgRun = new Runnable() {
        @Override public void run() { if (mode == MODE_BGERASE && !drawing) prefetchBgWidth(); }
    };
    private volatile boolean bgWidthBusy;

    /** Mide el grosor de linea en otro hilo (el primer trazo no espera). */
    private void prefetchBgWidth() {
        if (project == null || project.activeLayer() == null) return;
        if (bgWidthBusy) return;      // v8.55: un solo hilo midiendo a la vez
        bgWidthBusy = true;
        final Layer pre = project.activeLayer();
        Thread th = new Thread(new Runnable() {
            @Override public void run() {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                try { bgWidthFor(pre); } catch (Throwable ignored) { } finally { bgWidthBusy = false; }
            }
        }, "bg-width");
        th.setPriority(Thread.NORM_PRIORITY - 1);
        th.start();
    }

    /** Libera los mapas de Borrar fondo (al salir de la herramienta o con poca memoria). */
    public void releaseBgEngine() {
        belowDisp.drop();
        belowDetail.drop();
        bgGrayCur = null;      // v8.37: la copia B/N se vuelve a hacer al usarla
        bgGraySnap = null;
        bgStroke.release();
        bgFast.release();
        if (bgTapEng != null) bgTapEng.release();
        bgTapEng = null;
    }

    /** Empieza un trazo del pincel protegido; la region global se calcula en otro hilo. */
    private void beginBgBrushStroke(int px0, int py0) {
        bgSegFresh = true;
        Layer t = strokeLayer;
        if (t == null) return;
        bgStroke.once = bgOnce;
        int sx = Math.max(0, Math.min(project.w - 1, px0)), sy = Math.max(0, Math.min(project.h - 1, py0));
        boolean ok;
        int[] snap0 = bgSnapFor(t);
        int[][] ga = grayActive() ? grayAnalysis(t, snap0) : null;
        bgStrokeGray = ga != null;
        bgStrokeRealSnap = snap0;
        bgStrokeRealRef = ga != null ? com.pacco.animecut.core.BgEngine.tapColor(t.px(), snap0, project.w, project.h, sx, sy) : 0;
        try {
            ok = bgStroke.begin(ga != null ? ga[0] : t.px(), ga != null ? ga[1] : snap0, project.w, project.h, bgWidthFor(t),
                    selectionActive ? project.selection : null, sx, sy, bgTolerance, bgMode(), bgGapScale, (int) Math.max(2, brushRadius));
        } catch (OutOfMemoryError oom) {
            ok = false;
            msg("Borrar fondo necesita mas memoria; cierra otras aplicaciones");
        }
        if (!ok) return;
        bgStroke.eng.protect = protectOn;
        bgStroke.eng.protectColor = protectColor;
        bgStroke.eng.protectTol = Math.max(6, tolerance / 2);
        bgRef = bgStrokeGray ? bgStrokeRealRef : bgStroke.ref();
        bgRefValid = true;
        final int gen = bgStroke.generation();
        final com.pacco.animecut.core.BgStroke st = bgStroke;
        // v8.53: la region del fondo de un trazo anterior sirve si solo se borro desde entonces
        long key = bgGlobalKey(t);
        if (st.reuseGlobal(key)) return;
        final long fkey = key;
        Thread th = new Thread(new Runnable() {
            @Override public void run() {
                // prioridad baja: el dedo y la pantalla van primero
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                try { st.computeGlobal(gen, fkey); } catch (Throwable ignored) { }
            }
        }, "bg-region");
        th.setPriority(Thread.NORM_PRIORITY - 1);
        th.start();
    }

    /** v8.53: lo que tiene que ser igual para volver a usar la region del fondo de otro trazo. */
    private long bgGlobalKey(Layer t) {
        if (project == null || bgCleanLayer != t || bgCleanVer != project.version) return Long.MIN_VALUE;
        long k = System.identityHashCode(t);
        k = k * 31 + bgCleanVer;
        k = k * 31 + bgTolerance;
        k = k * 31 + bgMode();
        k = k * 31 + Float.floatToIntBits(bgGapScale);
        k = k * 31 + (protectOn ? 1 : 0) + protectColor * 7L;
        k = k * 31 + (bgStrokeGray ? 1 : 0);
        k = k * 31 + (selectionActive ? 1 : 0);
        return k == Long.MIN_VALUE ? 1 : k;
    }

    /** v8.32: zona del trazo del pincel protegido a la que falta aplicar la Suavidad. */
    private Rect bgSpeckRect;

    /**
     * Busca el color del fondo cerca de donde tocaste, saltando lo que ya
     * esta borrado. Sin esto, al pasar de nuevo por una zona ya borrada la
     * herramienta tomaba lo transparente como referencia y no borraba nada.
     */
    private boolean bgRefValid;

    private boolean sampleBgRef(int cx, int cy) {
        // v8.29: si empiezas sobre lo ya borrado, el color mas cercano puede ser la linea negra;
        // se busca primero un color que no sea tinta.
        if (sampleBgRef(cx, cy, true)) return true;
        return sampleBgRef(cx, cy, false);
    }

    private boolean sampleBgRef(int cx, int cy, boolean skipInk) {
        int w = project.w, h = project.h;
        int r = (int) Math.max(2, brushRadius);
        // El bucle anterior examinaba TODO el cuadrado para cada radio (O(r^3)).
        // Recorrer solo el PERIMETRO de cada anillo es O(r^2) y conserva la
        // busqueda desde el punto mas cercano, incluso sobre huecos transparentes.
        for (int rad = 0; rad <= r; rad++) {
            for (int dy = -rad; dy <= rad; dy++) {
                int y = cy + dy;
                if (y < 0 || y >= h) continue;
                if (dy == -rad || dy == rad) {
                    // Parte superior/inferior del anillo; conserva el orden
                    // exacto de busqueda anterior, sin recorrer el interior.
                    for (int dx = -rad; dx <= rad; dx++) {
                        int x = cx + dx;
                        if (x < 0 || x >= w) continue;
                        int c = strokeOriginalAt(y * w + x);
                        if ((c >>> 24) > 32 && (!skipInk || !inkAbs(c))) { bgRef = c; return true; }
                    }
                } else {
                    int xl = cx - rad, xr = cx + rad;
                    if (xl >= 0 && xl < w) {
                        int c = strokeOriginalAt(y * w + xl);
                        if ((c >>> 24) > 32 && (!skipInk || !inkAbs(c))) { bgRef = c; return true; }
                    }
                    if (xr >= 0 && xr < w) {
                        int c = strokeOriginalAt(y * w + xr);
                        if ((c >>> 24) > 32 && (!skipInk || !inkAbs(c))) { bgRef = c; return true; }
                    }
                }
            }
        }
        return false;
    }

    /** v8.23: quitar el color del fondo que queda en el borde al borrarlo. */
    private boolean bgDecontam = true;

    public void setBgDecontam(boolean on) { bgDecontam = on; }
    public boolean isBgDecontam() { return bgDecontam; }

    // ---- dilatacion propia de Borrar fondo ----

    /** Pixeles de dilatacion de Borrar fondo: + se come el borde, - lo devuelve. */
    private float bgExpansion = 0f;

    public void setBgExpansion(float e) {
        bgExpansion = e;
    }

    public float getBgExpansion() {
        return bgExpansion;
    }


    private static int luma(int c) {
        return (((c >> 16) & 0xFF) * 299 + ((c >> 8) & 0xFF) * 587 + (c & 0xFF) * 114) / 1000;
    }

    // ==================================================================
    // v8.37: B/N de Borrar fondo. El Balde y el Pincel protegido miran una COPIA en blanco y negro
    // (canal, saturacion, contraste y brillo ajustables); lo borrado se aplica a la capa real con
    // sus colores. Apagar B/N = volver a ver el color (que nunca se toco).
    // ==================================================================

    private boolean bgGray;
    private final com.pacco.animecut.core.GrayView grayView = new com.pacco.animecut.core.GrayView();
    private int[] bgGrayCur, bgGraySnap;
    /** v8.53: la copia gris es de esta capa, de esta copia de antes y con estos tonos. */
    private Layer bgGrayFor;
    private int[] bgGraySnapSrc, bgGrayQ;
    /**
     * v8.53: version de la obra justo al terminar el ultimo trazo de Borrar fondo (y su capa).
     * Si al empezar el siguiente la obra sigue en esa version, nada mas cambio la capa: la copia de
     * antes, la copia gris y la region del fondo siguen sirviendo.
     */
    private long bgCleanVer = Long.MIN_VALUE;
    private Layer bgCleanLayer;

    public boolean isBgGray() { return bgGray; }

    public void setBgGray(boolean on) {
        bgGray = on;
        bgGrayPeek = false;
        if (!on) { bgGrayCur = null; bgGraySnap = null; }
        updateGrayFilter();
        invalidate();
    }

    public com.pacco.animecut.core.GrayView getBgGrayView() { return grayView.copy(); }

    public void setBgGrayView(com.pacco.animecut.core.GrayView g) {
        if (g == null) return;
        grayView.channel = g.channel;
        grayView.saturation = g.saturation;
        grayView.contrast = g.contrast;
        grayView.brightness = g.brightness;
        updateGrayFilter();
        invalidate();
    }

    /** Vista gris (solo en Borrar fondo, solo las capas) y se vuelve a armar la pantalla. */
    private void updateGrayFilter() {
        // v8.54: en pantalla, gris limpio (sin contraste ni brillo: no se queman los bordes de la
        // linea). Solo mientras esta abierta la barra de ajustes de B/N se ve el ajuste completo.
        // v8.55c: se ve SIEMPRE con tu ajuste (contraste y brillo), como antes de la 8.54: en la 8.54
        // al cerrar la barra se veia el gris "limpio" y con imagenes oscuras parecia que se oscurecia
        // solo.
        int[] q = bgGray && mode == MODE_BGERASE && !bgGrayPeek ? grayView.quantized() : null;
        int[] old = dispGrayQ;
        dispGrayQ = q;
        dispGrayParams = q == null ? null : grayView.params();
        boolean changed = (old == null) != (q == null) || (q != null && !Arrays.equals(old, q));
        if (changed && project != null && display != null) {
            refreshDisplayAsync();
            // v8.54: el detalle nitido se queda en pantalla hasta que llega el nuevo (antes se
            // quitaba y por un momento se veia la vista chica, borrosa)
            staleDetail();
            scheduleDetail();
        }
    }

    /** v8.54: true mientras la barra de ajustes de B/N esta abierta (se ve el ajuste completo). */
    private boolean bgGrayTuning;

    public void setBgGrayTuning(boolean on) {
        if (bgGrayTuning == on) return;
        bgGrayTuning = on;
        updateGrayFilter();
        invalidate();
    }

    /** v8.38: ver en color un momento sin apagar B/N (el ajuste queda igual). */
    private boolean bgGrayPeek;

    public void setBgGrayPeek(boolean on) {
        bgGrayPeek = on;
        updateGrayFilter();
        invalidate();
    }

    public boolean isBgGrayPeek() { return bgGrayPeek; }

    private boolean grayActive() { return bgGray && mode == MODE_BGERASE; }

    /** Copia B/N de la capa (y de su copia de antes) para el analisis; null si falta memoria. */
    private int[][] grayAnalysis(Layer t, int[] snap) {
        try {
            // v8.53: la copia gris se hace UNA vez; despues cada trazo la mantiene al dia en su zona
            boolean clean = bgGrayCur != null && bgGrayCur.length == t.px().length && bgCleanLayer == t
                    && project != null && bgCleanVer == project.version && bgGrayFor == t && bgGraySnapSrc == snap
                    && java.util.Arrays.equals(bgGrayQ, grayView.quantized());
            if (!clean) {
                bgGrayCur = grayView.apply(t.px(), bgGrayCur);
                bgGraySnap = snap == null ? null : grayView.apply(snap, bgGraySnap);
                bgGrayFor = t;
                bgGraySnapSrc = snap;
                bgGrayQ = grayView.quantized();
            }
            return new int[][]{bgGrayCur, bgGraySnap};
        } catch (OutOfMemoryError oom) {
            bgGrayCur = bgGraySnap = null;
            msg("B/N necesita mas memoria: se usa el color");
            return null;
        }
    }

    /** Trazo del pincel protegido en B/N: copia de antes y fondo REALES para aplicar. */
    private boolean bgStrokeGray;
    private int[] bgStrokeRealSnap;
    private int bgStrokeRealRef;

    /**
     * v8.32: un toque borra el fondo unido al punto con el motor compartido (BgEngine): no cruza
     * lineas ni huecos menores que 2R (R segun el grosor real de las lineas), el borde queda
     * desmezclado (sin halo ni dientes) y el papel pegado al limite del lienzo tambien se va.
     * Tocar dentro de un rincon angosto (entre mechones) borra ese rincon. Todo en otro hilo.
     */
    private void runBgBucket(final int sx, final int sy) {
        final Layer t = needLayer();
        if (t == null) return;
        strokeLayer = t;
        takeBgSnapshot(t);
        final int[] snap = bgSnapFor(t);
        // color de antes en el punto (aunque ya este borrado)
        // v8.33: tocar una zona negra ANCHA toma el negro (antes saltaba al papel de al lado y decia
        // "no encontre fondo"). Sobre una linea fina sigue tomando el fondo de al lado.
        // v8.37: con B/N el analisis mira la copia gris; se aplica a la capa real
        int[][] ga = grayActive() ? grayAnalysis(t, snap) : null;
        final int[] aCur = ga != null ? ga[0] : t.px(), aSnap = ga != null ? ga[1] : snap;
        int c0 = com.pacco.animecut.core.BgEngine.tapColor(aCur, aSnap, project.w, project.h, sx, sy);
        if (c0 == 0) { showHud("Ya esta borrado"); return; }
        final int realRef = ga != null ? com.pacco.animecut.core.BgEngine.tapColor(t.px(), snap, project.w, project.h, sx, sy) : c0;
        final boolean grayTap = ga != null;
        bgRef = realRef;
        bgRefValid = true;
        final boolean useSel = project.hasSelection();
        final Project owner = project;
        final long bgT0 = System.nanoTime();
        final int tTol = bgTolerance;
        final int mode0 = bgMode();
        final float gap = bgGapScale;
        final boolean prot = protectOn;
        final int protC = protectColor, protT = Math.max(6, tolerance / 2);
        final boolean[] ok = new boolean[1];
        final String[] err = new String[1];
        if (bgTapEng == null) bgTapEng = new com.pacco.animecut.core.BgEngine();
        final com.pacco.animecut.core.BgEngine e = bgTapEng;
        setBusy(true);
        showHud("Borrando fondo...");
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    com.pacco.animecut.core.BgEngine.Width wd = bgWidthFor(t);
                    e.setImage(aCur, aSnap, owner.w, owner.h, wd, useSel ? owner.selection : null);
                    e.ref = c0 | 0xFF000000;
                    e.tol = tTol;
                    e.mode = mode0;
                    e.gapScale = gap;
                    e.protect = prot;
                    e.protectColor = protC;
                    e.protectTol = protT;
                    ok[0] = e.tap(sx, sy);
                } catch (OutOfMemoryError oom) {
                    ok[0] = false;
                    err[0] = "Borrar fondo necesita mas memoria; cierra otras aplicaciones";
                    e.release();
                }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project) return;
                if (!ok[0]) {
                    if (err[0] != null) msg(err[0]); else showHud("Nada que borrar aqui");
                    return;
                }
                Rect r = new Rect(e.rx0, e.ry0, e.rx1, e.ry1);
                int pad = (int) Math.ceil(bgFeather) + 2;
                Rect ur = new Rect(r);
                ur.inset(-pad, -pad);
                ur.intersect(0, 0, owner.w, owner.h);
                undo.setLabel("Borrar fondo");
                undo.recordLayer(t, ur);
                if (grayTap) e.applyTo(t.px(), useSel ? owner.selection : null, snap, realRef);
                else e.applyTo(t.px(), useSel ? owner.selection : null);
                // imagen grande: los mapas del toque se sueltan (vuelven a pedirse en el proximo)
                if ((long) owner.w * owner.h > 6_000_000L) e.release();
                featherBg(t, ur);
                strokeLayer = t;
                pixelsChanged(ur);
                com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.BGERASE, System.nanoTime() - bgT0);
                showHud(e.seedKind == 2 ? "Rincon borrado" : "Fondo borrado");
            }
        });
    }

    // ==================================================================
    // v8.27 REFINAR BORDE (Borrar fondo): vista previa exacta + Aceptar / Cancelar.
    // El calculo va en otro hilo sobre una COPIA de la zona; lo que se ve en el lienzo
    // es exactamente lo que queda al aceptar. Cancelar devuelve la capa intacta.
    // ==================================================================
    private Layer edgeLayer;
    private Rect edgeRect;
    private int[] edgeBackup;
    private int edgeSeq, edgeShownSeq;
    private LatestWorker edgeWorker;
    /** Ultimo resultado mostrado (pruebas y diagnostico). */
    public com.pacco.animecut.core.EdgeRefine.Result lastEdgeRefine;

    public boolean isEdgeRefineActive() { return edgeLayer != null; }

    /** Color de fondo tomado por el ultimo Borrar fondo (blanco si no hubo). */
    public int getBgRefColor() { return bgRefValid || bgRef != 0 ? (bgRef | 0xFF000000) : 0xFFFFFFFF; }

    /** Aparta la zona visible de la capa elegida. false si no se puede. */
    public boolean beginEdgeRefine() {
        if (project == null || busy || edgeLayer != null) return false;
        if (mode == MODE_TRANSFORM && transformActive) {
            msg("Termina o cancela Transformar primero");
            return false;
        }
        Layer t = needLayer();
        if (t == null) return false;
        Rect r = com.pacco.animecut.core.EdgeRefine.visibleBounds(t.px(), project.w, project.h, 4);
        if (r == null) {
            msg("La capa esta vacia");
            return false;
        }
        boolean anyClear = false;
        int[] px = t.px();
        int w = project.w;
        for (int y = r.top; y < r.bottom && !anyClear; y++)
            for (int x = r.left; x < r.right; x++) if ((px[y * w + x] >>> 24) < 8) { anyClear = true; break; }
        if (!anyClear) {
            msg("Esta capa no tiene partes transparentes: primero borra el fondo (Borrar fondo o Lazo)");
            return false;
        }
        int rw = r.width(), rh = r.height();
        try {
            edgeBackup = new int[rw * rh];
        } catch (OutOfMemoryError e) {
            msg("No alcanza la memoria para Refinar borde en esta capa");
            return false;
        }
        for (int y = 0; y < rh; y++) System.arraycopy(px, (r.top + y) * w + r.left, edgeBackup, y * rw, rw);
        edgeLayer = t;
        edgeRect = r;
        edgeShownSeq = 0;
        if (edgeWorker == null) edgeWorker = new LatestWorker("pz-refinar-borde");
        return true;
    }

    /** Calcula y muestra la vista previa con estos ajustes (solo el ultimo pedido cuenta). */
    public void previewEdgeRefine(final com.pacco.animecut.core.EdgeRefine.Params p) {
        if (edgeLayer == null || edgeWorker == null) return;
        final int[] src = edgeBackup;
        final Rect r = new Rect(edgeRect);
        final Layer t = edgeLayer;
        final int seq = ++edgeSeq;
        edgeWorker.submit(new Runnable() {
            @Override public void run() {
                long t0 = System.nanoTime();
                final com.pacco.animecut.core.EdgeRefine.Result res = com.pacco.animecut.core.EdgeRefine.run(
                        src, r.width(), r.height(), new Rect(0, 0, r.width(), r.height()), p);
                com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.EDGE_REFINE, System.nanoTime() - t0);
                post(new Runnable() {
                    @Override public void run() {
                        if (edgeLayer != t || seq < edgeShownSeq || edgeBackup != src) return;
                        edgeShownSeq = seq;
                        writeEdgeRegion(res.px);
                        res.r = new Rect(r);
                        lastEdgeRefine = res;
                        if (callback != null) callback.onToolStateChanged();
                    }
                });
            }
        });
    }

    /** Version sincronica (pruebas): calcula, muestra y devuelve el resultado. */
    public com.pacco.animecut.core.EdgeRefine.Result previewEdgeRefineNow(com.pacco.animecut.core.EdgeRefine.Params p) {
        if (edgeLayer == null) return null;
        com.pacco.animecut.core.EdgeRefine.Result res = com.pacco.animecut.core.EdgeRefine.run(
                edgeBackup, edgeRect.width(), edgeRect.height(), new Rect(0, 0, edgeRect.width(), edgeRect.height()), p);
        writeEdgeRegion(res.px);
        res.r = new Rect(edgeRect);
        lastEdgeRefine = res;
        edgeShownSeq = ++edgeSeq;
        return res;
    }

    private void writeEdgeRegion(int[] region) {
        if (edgeLayer == null || region == null) return;
        int[] px = edgeLayer.px();
        int w = project.w, rw = edgeRect.width();
        for (int y = 0; y < edgeRect.height(); y++)
            System.arraycopy(region, y * rw, px, (edgeRect.top + y) * w + edgeRect.left, rw);
        project.markDirty();
        updateDisplayRegion(edgeRect);
    }

    /** Deja lo que se ve (un solo Deshacer devuelve el borde de antes). */
    public void acceptEdgeRefine() {
        if (edgeLayer == null) return;
        if (edgeWorker != null) edgeWorker.cancelAndWait(3000);
        Layer t = edgeLayer;
        Rect r = edgeRect;
        int[] backup = edgeBackup;
        edgeLayer = null;
        edgeRect = null;
        edgeBackup = null;
        undo.setLabel("Refinar borde");
        undo.recordLayerRegionBackup(t, r, backup);
        pixelsChanged(r);
        showHud("Borde refinado. Deshacer lo devuelve como estaba");
    }

    /** Devuelve la capa exactamente como estaba. */
    public void cancelEdgeRefine() {
        if (edgeLayer == null) return;
        if (edgeWorker != null) edgeWorker.cancelAndWait(3000);
        writeEdgeRegion(edgeBackup);
        edgeLayer = null;
        edgeRect = null;
        edgeBackup = null;
        invalidate();
    }

    // ---- clonar y corrector ----

    private int cloneSource(int x, int y) {
        float dx = x - cloneDestX, dy = y - cloneDestY;
        if (cloneMirror) dx = -dx;
        if (cloneAngle != 0f) {
            double a = Math.toRadians(cloneAngle);
            float c = (float) Math.cos(a), s = (float) Math.sin(a);
            float rx = dx * c - dy * s, ry = dx * s + dy * c;
            dx = rx;
            dy = ry;
        }
        int sx = Math.round(cloneSrcX + dx), sy = Math.round(cloneSrcY + dy);
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return -1;
        return sy * project.w + sx;
    }

    private void stampClone(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (mode != MODE_HEAL) {
            if (!captureEffectStrokeBackup(r)) return;
            captureCloneSourceBackup(r);
        }
        int[] px = strokeLayer.px();
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                if (a <= 0f) continue;
                int src = cloneSource(x, y);
                if (src < 0) continue;
                int i = y * project.w + x;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                int ca = (int) (a * 255f);
                if (ca <= (cov[i] & 0xFF)) continue;
                cov[i] = (byte) ca;
                px[i] = mix(strokeOriginalAt(i), strokeOriginalAt(src), a);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Mezcla dos pixeles con alfa incluido. */
    private static int mix(int a, int b, float t) {
        int it = (int) (t * 256f);
        if (it <= 0) return a;
        if (it >= 256) return b;
        int aa = (((b >>> 24) * it) + ((a >>> 24) * (256 - it))) >> 8;
        int r = ((((b >> 16) & 0xFF) * it) + (((a >> 16) & 0xFF) * (256 - it))) >> 8;
        int g = ((((b >> 8) & 0xFF) * it) + (((a >> 8) & 0xFF) * (256 - it))) >> 8;
        int bl = (((b & 0xFF) * it) + ((a & 0xFF) * (256 - it))) >> 8;
        return (aa << 24) | (r << 16) | (g << 8) | bl;
    }

    private void finishHeal(final Rect r) {
        final Layer t = strokeLayer;
        final int left = r.left, top = r.top, right = r.right, bottom = r.bottom;
        final int rw = right - left, rh = bottom - top;
        final boolean[] region = new boolean[rw * rh];
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                int i = (top + y) * project.w + left + x;
                region[y * rw + x] = t.px()[i] != pxBackup[i];
            }
        }
        undo.setLabel("Corrector");
        undo.recordLayerFromBackup(t, r, pxBackup);
        final int[] orig = pxBackup;
        pxBackup = null;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                Membrane.heal(t.px(), orig, orig, project.w, project.h, region, left, top, right, bottom,
                        new Membrane.SourceMap() {
                            @Override
                            public int map(int x, int y) {
                                return cloneSource(x, y);
                            }
                        });
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                pixelsChanged(r);
            }
        });
    }

    public void resetCloneSource() {
        cloneSrcSet = false;
        invalidate();
        msg("Toca de donde quieres copiar");
    }

    // ---- lazo, tijeras, magnetico ----

    private void fillPathIntoSelection(Path closed, String label) {
        RectF b = new RectF();
        closed.computeBounds(b, true);
        Rect region = new Rect((int) Math.floor(b.left), (int) Math.floor(b.top),
                (int) Math.ceil(b.right) + 1, (int) Math.ceil(b.bottom) + 1);
        clamp(region);
        if (region.isEmpty()) {
            invalidate();
            return;
        }
        int rw = region.width(), rh = region.height();
        Bitmap tmp;
        int[] row;
        try {
            tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
            row = new int[rw];
        } catch (OutOfMemoryError oom) {
            msg("No alcanza memoria para este lazo. Acerca la imagen o extrae una parte menor.");
            return;
        }
        undo.setLabel(label);
        undo.recordSelection(region);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        c.translate(-region.left, -region.top);
        c.drawPath(closed, pt);
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (region.top + y) * project.w + region.left;
            for (int x = 0; x < rw; x++) {
                int a = row[x] >>> 24;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        paintOverlay(region);
        invalidate();
        changed();
    }

    private void setAnchorAsync(final int x, final int y) {
        setBusy(true);
        final int[] ref = project.ref();
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (wire == null) wire = new LiveWire(ref, project.w, project.h);
                wire.setAnchor(x, y, 320);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                invalidate();
            }
        });
    }

    private void appendLive() {
        if (livePath == null || livePath.length < 2) return;
        for (int i = livePath.length - 1; i >= 0; i -= 2) {
            int y = livePath[i] / project.w, x = livePath[i] - y * project.w;
            wirePath.lineTo(x, y);
        }
        livePath = null;
    }

    private void commitWire() {
        if (livePath == null || livePath.length < 2) return;
        int last = livePath[0];
        appendLive();
        int ly = last / project.w, lx = last - ly * project.w;
        if (firstAnchor >= 0) {
            int fy = firstAnchor / project.w, fx = firstAnchor - fy * project.w;
            if (Math.hypot(lx - fx, ly - fy) < 24f) {
                scissorsClose();
                return;
            }
        }
        setAnchorAsync(lx, ly);
        invalidate();
    }

    public void scissorsClose() {
        if (project == null || !wireStarted) {
            msg("Primero traza el contorno con las tijeras");
            return;
        }
        Path closed = new Path(wirePath);
        closed.close();
        scissorsReset();
        fillPathIntoSelection(closed, "Tijeras");
    }

    public void scissorsReset() {
        wirePath.reset();
        livePath = null;
        firstAnchor = -1;
        wireStarted = false;
        invalidate();
    }

    // ---- mover capa o lo seleccionado ----

    private void startMove(float ix, float iy) {
        Layer t = needLayer();
        if (t == null) return;
        try {
            moveBackup = t.px().clone();
        } catch (OutOfMemoryError e) {
            moveBackup = null;
            if (undo != null) undo.trimTo(0.3f);
            System.gc();
            try {
                moveBackup = t.px().clone();
            } catch (OutOfMemoryError e2) {
                msg("Ya no alcanza la memoria para mover. Combina o borra alguna capa.");
                return;
            }
        }
        selectionActive = project.hasSelection();
        moveSelBackup = selectionActive ? project.selection.clone() : null;
        moveFromX = ix;
        moveFromY = iy;
        moveDx = moveDy = 0;
        drawing = true;
        lastMoveApply = 0;
        if (!selectionActive) startGhost(t);
    }

    // Mover fluido: mientras arrastras, la capa se dibuja como una imagen
    // encima (rapido, en la tarjeta de video) y se aplica al soltar.
    private Bitmap moveGhost;
    private Rect moveGhostRect;
    private Layer moveGhostLayer;
    private final Paint ghostMovePaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    private void startGhost(Layer t) {
        try {
            Layer.Packed pk = t.snapshot(project.w, project.h);
            if (pk.empty()) return;
            int[] px = new int[pk.w * pk.h];
            pk.bmp.getPixels(px, 0, pk.w, 0, 0, pk.w, pk.h);
            moveGhost = Bitmap.createBitmap(px, pk.w, pk.h, Bitmap.Config.ARGB_8888);
            moveGhostRect = new Rect(pk.x, pk.y, pk.x + pk.w, pk.y + pk.h);
            moveGhostLayer = t;
            ghostMovePaint.setAlpha(t.opacity);
            t.visible = false;
            refreshDisplay();
        } catch (OutOfMemoryError e) {
            moveGhost = null;
        }
    }

    private void endGhost() {
        if (moveGhostLayer != null) moveGhostLayer.visible = true;
        if (moveGhost != null && !moveGhost.isRecycled()) moveGhost.recycle();
        moveGhost = null;
        moveGhostRect = null;
        moveGhostLayer = null;
    }

    /** Mueve la capa entera, o solo lo seleccionado si hay algo azul. */
    private void applyMove(boolean fin) {
        Layer t = target();
        if (t == null || moveBackup == null) return;
        int w = project.w, h = project.h;
        int[] px = t.px();
        int dx = moveDx, dy = moveDy;
        if (moveSelBackup == null) {
            Arrays.fill(px, 0);
            for (int y = 0; y < h; y++) {
                int ty = y + dy;
                if (ty < 0 || ty >= h) continue;
                int x0 = Math.max(0, -dx), x1 = Math.min(w, w - dx);
                if (x0 >= x1) continue;
                System.arraycopy(moveBackup, y * w + x0, px, ty * w + x0 + dx, x1 - x0);
            }
        } else {
            // lo de afuera queda; lo seleccionado se levanta y se pone en su nuevo lugar
            for (int i = 0; i < px.length; i++) {
                int s = moveSelBackup[i] & 0xFF;
                int c = moveBackup[i];
                int a = ((c >>> 24) * (255 - s)) / 255;
                px[i] = (a << 24) | (c & 0x00FFFFFF);
            }
            Arrays.fill(project.selection, (byte) 0);
            for (int y = 0; y < h; y++) {
                int ty = y + dy;
                if (ty < 0 || ty >= h) continue;
                for (int x = 0; x < w; x++) {
                    int tx = x + dx;
                    if (tx < 0 || tx >= w) continue;
                    int i = y * w + x;
                    int s = moveSelBackup[i] & 0xFF;
                    if (s == 0) continue;
                    int c = moveBackup[i];
                    int a = ((c >>> 24) * s) / 255;
                    int j = ty * w + tx;
                    if (a > 0) px[j] = Project.over(px[j], c, a);
                    project.selection[j] = (byte) s;
                }
            }
            paintOverlay(project.fullRect());
        }
        project.markDirty();
        buildDisplay();
        invalidate();
    }

    private void finishMove() {
        if (moveBackup == null) return;
        boolean hadGhost = moveGhost != null;
        endGhost();
        applyMove(true);
        if (hadGhost) refreshDisplay();
        Layer t = target();
        if ((moveDx != 0 || moveDy != 0) && t != null) {
            undo.setLabel("Mover");
            undo.begin();
            undo.recordLayerFromBackup(t, project.fullRect(), moveBackup);
            if (moveSelBackup != null) undo.recordSelectionFromBackup(project.fullRect(), moveSelBackup);
            undo.end();
            changed();
        }
        moveBackup = null;
        moveSelBackup = null;
    }

    // ==================================================================
    // Varita, balde, gama de colores
    // ==================================================================

    private void runWand(final int sx, final int sy) {
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int[] ref = project.ref();
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = wandGlobal
                        ? FloodFill.global(ref, project.w, project.h, scratch, sx, sy, tolerance, softness, colorMode)
                        : fillWithGaps(ref, sx, sy);
                if (lastFillRect != null && expansion != 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(Math.abs(expansion)) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
                if (lastFillRect != null && toLine) {
                    byte[] line = useBarrier && project.barrier != null ? project.barrier : autoBarrier(ref);
                    growToLine(line, lastFillRect, 6);
                }
                if (lastFillRect != null && fillUnpainted) {
                    MaskOps.fillEnclosed(scratch, project.w, project.h, 6000);
                    lastFillRect = project.fullRect();
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Varita");
                    undo.recordSelection(r);
                    mergeScratch(r);
                    paintOverlay(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    // ------------------------------------------------------------------
    // Ver la linea: por unos segundos se pinta en rojo lo que cuenta como
    // linea, asi sabes si el ajuste sirve para tu dibujo.
    // ------------------------------------------------------------------

    private Bitmap redLines;
    private final Runnable hideRedLines = new Runnable() {
        @Override
        public void run() {
            if (redLines != null && !redLines.isRecycled()) redLines.recycle();
            redLines = null;
            invalidate();
        }
    };

    private void showRedLines(byte[] mask) {
        if (mask == null || display == null || project == null) return;
        int dw = display.getWidth(), dh = display.getHeight();
        Bitmap b = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        int[] row = new int[dw];
        for (int y = 0; y < dh; y++) {
            int sy = Math.min(project.h - 1, (int) (y * dispScale));
            for (int x = 0; x < dw; x++) {
                int sx = Math.min(project.w - 1, (int) (x * dispScale));
                row[x] = mask[sy * project.w + sx] != 0 ? 0xDDFF2020 : 0;
            }
            b.setPixels(row, 0, dw, 0, y, dw, 1);
        }
        handler.removeCallbacks(hideRedLines);
        if (redLines != null && !redLines.isRecycled()) redLines.recycle();
        redLines = b;
        handler.postDelayed(hideRedLines, 4500);
        invalidate();
    }

    /** Muestra en rojo la linea que usa la varita automatica. */
    public void previewAutoLines() {
        if (project == null) return;
        final int[] ref = project.ref();
        final byte[][] out = new byte[1][];
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                out[0] = autoBarrier(ref);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                showHud("En rojo: lo que la varita toma como linea");
                showRedLines(out[0]);
            }
        });
    }

    /** Varita que no se escapa por los cortes de la linea (encendida por defecto). */
    private boolean autoLines = true;
    private byte[] autoBarrier;
    private int autoBarrierVer = Integer.MIN_VALUE;
    private Project autoBarrierOwner;

    public void setAutoLines(boolean on) {
        autoLines = on;
    }

    public boolean isAutoLines() {
        return autoLines;
    }

    private byte[] sepBarrier;
    private int sepBarrierVer = Integer.MIN_VALUE;
    private Project sepBarrierOwner;

    /**
     * v8.69 Separar: la linea de antes + las mismas paredes que ya usa Colorear (lineas de color o
     * gris, saltos fuertes de tono, sin contar las sombras como linea). Antes la cara / el cuello se
     * pasaban a la camisa por donde la linea del cuello no estaba cerrada.
     */
    private synchronized byte[] sepBarrier(int[] ref) {
        Project p = project;
        if (sepBarrier != null && sepBarrierOwner == p && sepBarrierVer == p.version && sepBarrier.length == p.w * p.h)
            return sepBarrier;
        int ver = p.version;
        byte[] a = autoBarrier(ref);
        byte[] out = a.clone();
        try {
            com.pacco.animecut.core.MangaFill.Params prm = new com.pacco.animecut.core.MangaFill.Params();
            prm.darkThr = mangaPrm.darkThr;
            prm.tone = mangaPrm.tone;
            prm.maxDot = mangaPrm.maxDot;
            prm.maxDotSide = mangaPrm.maxDotSide;
            boolean hinted = hintedZoneKind;
            hintedZoneKind = true;                       // sin el aviso de Colorear aqui
            byte[] z = zoneLines(ref, p.w, p.h, prm);
            hintedZoneKind = hinted;
            for (int i = 0; i < out.length; i++) if (z[i] != 0) out[i] = 1;
        } catch (OutOfMemoryError e) {
            out = a;
        }
        sepBarrier = out;
        sepBarrierVer = ver;
        sepBarrierOwner = p;
        return out;
    }

    private byte[] autoBarrier(int[] ref) {
        Project p = project;
        if (autoBarrier == null || autoBarrierOwner != p || autoBarrierVer != p.version
                || autoBarrier.length != p.w * p.h) {
            int ver = p.version;
            autoBarrier = null;
            autoBarrier = AutoLines.build(ref, p.w, p.h);
            autoBarrierVer = ver;
            autoBarrierOwner = p;
        }
        return autoBarrier;
    }

    /**
     * Relleno con "bola atrapada": la linea se engorda para tapar sus cortes,
     * se rellena, y despues lo relleno vuelve a crecer hasta tocar la linea.
     */
    private Rect fillWithGaps(int[] ref, int sx, int sy) {
        return fillWithGaps(ref, sx, sy, tolerance);
    }

    private Rect fillWithGaps(int[] ref, int sx, int sy, int tolerance) {
        byte[] barrier = useBarrier ? project.barrier : null;
        boolean gaps = gapOn;
        int rad = gapRadius;
        if (barrier == null && autoLines) {
            barrier = autoBarrier(ref);
            gaps = true;
            rad = Math.max(3, gapRadius);
            // si tocaste justo sobre la linea, se usa la varita normal
            if (barrier[sy * project.w + sx] != 0) barrier = null;
        }
        if (!gaps || barrier == null) {
            return FloodFill.contiguous(ref, project.w, project.h, scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        if (gapBarrier == null || gapBarrier.length != barrier.length) gapBarrier = new byte[barrier.length];
        MaskOps.closeGapsBarrier(barrier, project.w, project.h, rad, gapBarrier);
        if (gapBarrier[sy * project.w + sx] != 0) {
            return FloodFill.contiguous(ref, project.w, project.h, scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        Rect r = FloodFill.contiguous(ref, project.w, project.h, scratch, gapBarrier, sx, sy, tolerance, softness, colorMode);
        if (r == null) return null;
        // vuelve a crecer solo hacia pixeles de color parecido al tocado
        int seed = ref[sy * project.w + sx];
        r.inset(-rad - 1, -rad - 1);
        clamp(r);
        growBack(ref, seed, barrier, r, rad);
        return r;
    }

    /** Hasta la linea: quita el borde blanco que queda entre lo elegido y la linea negra. */
    private boolean toLine = true, fillUnpainted = false;

    public void setToLine(boolean b) {
        toLine = b;
    }

    public boolean isToLine() {
        return toLine;
    }

    public void setFillUnpainted(boolean b) {
        fillUnpainted = b;
    }

    public boolean isFillUnpainted() {
        return fillUnpainted;
    }

    /** Hace crecer lo elegido hasta rad pixeles, parando en la linea negra. */
    private void growToLine(byte[] line, Rect r, int rad) {
        int w = project.w, h = project.h;
        r.inset(-rad - 1, -rad - 1);
        clamp(r);
        // solo crece cerca de la linea: asi no se come sombras o colores vecinos
        int rw = r.width(), rh = r.height();
        byte[] near = new byte[rw * rh];
        for (int y = 0; y < rh; y++) System.arraycopy(line, (r.top + y) * w + r.left, near, y * rw, rw);
        MaskOps.dilate(near, rw, rh, rad);
        for (int pass = 0; pass < rad; pass++) {
            for (int y = Math.max(1, r.top); y < Math.min(h - 1, r.bottom); y++) {
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++) {
                    int i = y * w + x;
                    if (scratch[i] != 0 || line[i] != 0) continue;
                    if (near[(y - r.top) * rw + (x - r.left)] == 0) continue;
                    int a;
                    if (((a = scratch[i - 1] & 0xFF) >= 200 && a != 253) || ((a = scratch[i + 1] & 0xFF) >= 200 && a != 253)
                            || ((a = scratch[i - w] & 0xFF) >= 200 && a != 253) || ((a = scratch[i + w] & 0xFF) >= 200 && a != 253)) {
                        scratch[i] = (byte) 253;
                    }
                }
            }
            for (int y = r.top; y < r.bottom; y++)
                for (int x = r.left; x < r.right; x++)
                    if (scratch[y * w + x] == (byte) 253) scratch[y * w + x] = (byte) 255;
        }
    }

    /** Crece lo relleno rad pixeles sin pasar la linea ni colores muy distintos. */
    private void growBack(int[] ref, int seed, byte[] barrier, Rect r, int rad) {
        int w = project.w;
        int lim = Math.max(tolerance * 2, 60);
        for (int pass = 0; pass < rad; pass++) {
            for (int y = Math.max(1, r.top); y < Math.min(project.h - 1, r.bottom); y++) {
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++) {
                    int i = y * w + x;
                    if (scratch[i] != 0 || barrier[i] != 0) continue;
                    int best = 0;
                    int a;
                    if ((a = scratch[i - 1] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i + 1] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i - w] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i + w] & 0xFF) > best && a != 253) best = a;
                    if (best < 200) continue;
                    if (ColorDist.dist(ref[i] | 0xFF000000, seed | 0xFF000000, colorMode) > lim) continue;
                    scratch[i] = (byte) 253;
                }
            }
            for (int y = Math.max(1, r.top); y < Math.min(project.h - 1, r.bottom); y++)
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++)
                    if (scratch[y * w + x] == (byte) 253) scratch[y * w + x] = (byte) 254;
        }
        for (int i = 0; i < scratch.length; i++) if (scratch[i] == (byte) 254) scratch[i] = (byte) 255;
    }

    private void mergeScratch(Rect r) {
        for (int y = r.top; y < r.bottom; y++) {
            int off = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                int a = scratch[off + x] & 0xFF;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
    }

    /** Relleno: pinta la zona tocada con el color, en la capa elegida. */
    // ---- opciones propias del Relleno (ya no usa las de la varita) ----
    private int fillTolerance = 20;
    private float fillExpansion = 2f;
    private boolean fillAllLayers = true, fillToLine = true;

    public void setFillTolerance(int t) {
        fillTolerance = Math.max(0, Math.min(160, t));
    }

    public int getFillTolerance() {
        return fillTolerance;
    }

    public void setFillExpansion(float e) {
        fillExpansion = e;
    }

    public void setFillAllLayers(boolean b) {
        fillAllLayers = b;
    }

    public boolean isFillAllLayers() {
        return fillAllLayers;
    }

    public void setFillToLine(boolean b) {
        fillToLine = b;
    }

    public boolean isFillToLine() {
        return fillToLine;
    }

    /**
     * Relleno: mira todas las capas, solo la elegida o las marcadas como
     * referencia, con su propia tolerancia (motor en core/BucketFill).
     */
    /**
     * v8.27 DESTINO DEL BALDE (antes "Colorear en capa aparte", prendido de fabrica).
     *
     * Fallo confirmado en v8.24-8.26: con la opcion prendida, si la capa elegida no se
     * llamaba "Color"/"Color_N" ni tenia una asi JUSTO encima, el balde creaba otra capa
     * ("Color_1") y ademas la dejaba elegida: la capa_1 que el usuario habia creado quedaba
     * de lado y los siguientes brochazos iban a Color_1.
     *
     * Ahora el usuario elige y se respeta:
     *  - FILL_TARGET_CURRENT "Pintar en capa actual" (de fabrica): EXACTAMENTE la capa elegida.
     *    Nunca se crea otra capa.
     *  - FILL_TARGET_AUTO "Capa de color automatica": UNA sola capa con el papel
     *    Layer.ROLE_COLOR, creada la primera vez y reutilizada siempre, este donde este.
     *    La capa elegida NO cambia (los brochazos siguen donde el usuario los puso).
     *  - "Colorear manga" (project.mangaMode) tiene su propio destino (Color base).
     */
    public static final int FILL_TARGET_CURRENT = 0, FILL_TARGET_AUTO = 1;
    private int fillTarget = FILL_TARGET_CURRENT;

    public void setFillTarget(int t) {
        fillTarget = t == FILL_TARGET_AUTO ? FILL_TARGET_AUTO : FILL_TARGET_CURRENT;
        if (hasFillPreview()) cancelFillPreview();
    }

    public int getFillTarget() { return fillTarget; }

    /** Compatibilidad (v8.24-8.26): true = capa de color automatica. */
    public void setFillColorLayer(boolean on) { setFillTarget(on ? FILL_TARGET_AUTO : FILL_TARGET_CURRENT); }
    public boolean isFillColorLayer() { return fillTarget == FILL_TARGET_AUTO; }

    /** Nombre de la capa que se crea la primera vez en "Capa de color automatica". */
    public static final String COLOR_LAYER_NAME = "Color";

    /** La capa de color automatica (papel ROLE_COLOR) o null si todavia no existe. */
    public Layer autoColorLayer() {
        if (project == null) return null;
        for (Layer l : project.layers) if (l.role == Layer.ROLE_COLOR) return l;
        return null;
    }

    /**
     * Migracion UNA sola vez de obras de v8.24-8.26: la capa que el balde viejo creo
     * ("Color"/"Color_N" en Normal, o "Color (sin tapar..." de v8.23 en Multiplicar) pasa
     * a tener el papel ROLE_COLOR la primera vez que se rellena en modo automatico, asi
     * no se crea una capa repetida. Desde ese momento se reconoce por el papel.
     */
    private Layer legacyColorLayer() {
        if (project == null) return null;
        for (Layer l : project.layers) {
            if (l.role != Layer.ROLE_NONE || l.name == null) continue;
            if (l.mode == Layer.MODE_MULTIPLY && l.name.startsWith("Color (sin tapar")) return l;
            if (l.mode == Layer.MODE_NORMAL && (l.name.equals(COLOR_LAYER_NAME) || l.name.matches("Color_[0-9]+"))) return l;
        }
        return null;
    }

    /** Destino del modo manga SIN cambiar nada (para mostrarlo en la barra). */
    private Layer mangaTargetPeek() {
        Layer a = target();
        if (a != null && !a.locked && a.role != Layer.ROLE_INK) return a;
        Layer b = mangaBase();
        return b != null && !b.locked ? b : null;
    }

    /** Capa donde pintaria el balde ahora mismo (null si se creara una o no hay). Sin efectos. */
    public Layer fillDestinationLayer() {
        if (project == null) return null;
        if (project.mangaMode && colorBucket) return mangaTargetPeek();
        if (fillTarget == FILL_TARGET_AUTO) {
            Layer c = autoColorLayer();
            return c != null ? c : legacyColorLayer();
        }
        return target();
    }

    /** Texto corto para la barra: "Destino: capa_1 · Normal". */
    public String fillDestinationText() {
        if (project == null) return "";
        Layer t = fillDestinationLayer();
        if (t == null) {
            if (project.mangaMode && colorBucket) return "Destino: ninguna (capa bloqueada)";
            if (fillTarget == FILL_TARGET_AUTO) return "Destino: capa \"" + COLOR_LAYER_NAME + "\" (se creara una sola vez)";
            return "Destino: elige una capa";
        }
        return "Destino: " + t.name + " · " + Layer.MODE_NAMES[Math.max(0, Math.min(Layer.MODE_NAMES.length - 1, t.mode))];
    }

    /** v8.27: destino de la brocha y referencia de limites, para la barra. */
    public String paintDestinationText() {
        if (project == null) return "";
        Layer t = target();
        if (t == null) return "Destino: elige una capa";
        StringBuilder sb = new StringBuilder("Destino: ").append(t.name).append(" · ")
                .append(Layer.MODE_NAMES[Math.max(0, Math.min(Layer.MODE_NAMES.length - 1, t.mode))]);
        if (t.locked) sb.append(" (bloqueada)");
        if (lineStop) {
            StringBuilder refs = new StringBuilder();
            for (Layer l : project.layers) if (l.reference && l.visible) refs.append(refs.length() > 0 ? ", " : "").append(l.name);
            sb.append(" · Limites: ").append(refs.length() > 0 ? refs : "dibujo visible");
        }
        return sb.toString();
    }

    /** v8.27: "Por lineas (manga B/N)": la zona llega hasta la tinta; trama, grises y ruido no la cortan. */
    private boolean fillByLines = false;
    public void setFillByLines(boolean on) { fillByLines = on; }
    public boolean isFillByLines() { return fillByLines; }

    /** v8.27: vista previa con Aceptar/Cancelar tambien en el balde normal (apagada de fabrica). */
    private boolean bucketPreviewOn = false;
    public void setBucketPreview(boolean on) {
        bucketPreviewOn = on;
        if (!on && hasFillPreview() && !isMangaMode()) cancelFillPreview();
    }
    public boolean isBucketPreview() { return bucketPreviewOn; }

    /** Composicion (normal) de las capas visibles por debajo de 'idx'. Es el dibujo cuyos limites se usan. */
    private int[] compositeBelow(int idx) {
        return compositeExcept(idx, null);
    }

    /**
     * Composicion de las capas visibles por debajo de 'upTo' (exclusivo; -1 = todas) sin
     * la capa 'skip'. Para la capa de color automatica: sus limites salen del dibujo, no
     * del color ya puesto, asi rellenar otra vez la misma zona cambia el color de verdad.
     */
    private int[] compositeExcept(int upTo, Layer skip) {
        int n = project.w * project.h;
        int[] out = new int[n];
        int lim = upTo < 0 ? project.layers.size() : Math.min(upTo, project.layers.size());
        for (int k = 0; k < lim; k++) {
            Layer l = project.layers.get(k);
            if (!l.visible || l == skip) continue;
            int[] px = l.px();
            int op = l.opacity;
            for (int i = 0; i < n; i++) {
                int c = px[i];
                int sa = ((c >>> 24) * op) / 255;
                if (sa == 0) continue;
                out[i] = Project.blend(out[i], c, l.mode, sa);
            }
        }
        return out;
    }

    /** v8.24: conservar las sombras del dibujo al rellenar (si no, color plano). */
    private boolean fillShade = false;

    public void setFillShade(boolean on) { fillShade = on; }
    public boolean isFillShade() { return fillShade; }

    /** Lineas detectadas para el balde, guardadas por version del proyecto y tipo de referencia. */
    private byte[] bucketLines;
    private int bucketLinesVer = Integer.MIN_VALUE, bucketLinesKind = -1;
    private Project bucketLinesOwner;

    /** Ultimo resultado del balde (diagnostico y pruebas). */
    public com.pacco.animecut.core.BucketFill.Result lastBucket;
    /** v8.27: capa donde pinto el ultimo balde (pruebas). */
    public Layer lastBucketTarget;

    /**
     * Balde (core/BucketFill o, "Por lineas", core/MangaFill): zona, cierre de cortes,
     * motas, filo hasta la linea con antialias. Destino segun fillTarget (arriba).
     */
    private void runBucket(final int sx, final int sy) {
        // v8.54: el balde de Colorear (zonas / manga) solo cuando se entra por "1 Colorear" o
        // "Manga". El Relleno de la caja de herramientas es SIEMPRE el balde normal.
        if (project.mangaMode && colorBucket) {
            // v8.26: balde por lineas para manga (con vista previa)
            runMangaBucket(sx, sy);
            return;
        }
        if (busy) return;
        // v8.27: tocar una zona de la vista previa la quita
        for (int k = fillPreview.size() - 1; k >= 0; k--) {
            if (fillPreview.get(k).has(sx, sy)) {
                fillPreview.remove(k);
                rebuildPreviewBitmap();
                showHud(fillPreview.isEmpty() ? "Vista previa vacia" : "Zona quitada de la vista previa");
                if (callback != null) callback.onToolStateChanged();
                return;
            }
        }
        // ---- destino ----
        Layer dest;
        boolean create = false, adopt = false;
        if (fillTarget == FILL_TARGET_AUTO) {
            dest = autoColorLayer();
            if (dest == null) {
                dest = legacyColorLayer();
                adopt = dest != null;
            }
            if (dest == null) create = true;
            else if (refuseLocked(dest)) return;
        } else {
            dest = needLayer();
            if (dest == null) return;
            if (project.layers.size() == 1 && !hintedFillOriginal) {
                // aviso una vez: se pinta EXACTAMENTE en la capa elegida, que aqui es la imagen
                hintedFillOriginal = true;
                showHud("Destino: " + dest.name + " (tu imagen). Para no tocarla crea una capa o elige "
                        + "\"Capa de color automatica\" en el balde. Deshacer lo quita");
            }
        }
        if (!fillPreview.isEmpty() && (fillPreviewTarget != dest || fillPreviewCreate != create)) {
            // la vista previa pendiente iba a otra capa: se cancela, nunca se mezcla
            cancelFillPreview();
        }
        // v8.28: si conviene Multiplicar (manga B/N y capa Normal vacia) se pregunta ANTES de
        // pintar: el relleno espera la respuesta (asi no queda pintado en Normal con la linea
        // copiada, que luego en Multiplicar se oscurece dos veces).
        if (!create && needSuggestMultiply(dest)) {
            multiplyAsked.put(dest, Boolean.TRUE);
            pendingFillX = sx;
            pendingFillY = sy;
            callback.onSuggestMultiply(dest);
            return;
        }
        setBusy(true);
        ensureScratch();
        final Layer target0 = dest;
        final boolean createLayer = create, adoptLegacy = adopt;
        final boolean auto = fillTarget == FILL_TARGET_AUTO;
        // Multiplicar no tapa la tinta: color plano y puede entrar bajo la linea.
        final boolean multiplyTarget = target0 != null && target0.mode == Layer.MODE_MULTIPLY;
        final boolean useSel = project.hasSelection();
        final boolean refLayers = hasReferenceLayers();
        final boolean all = fillAllLayers;
        final boolean byLines = fillByLines;
        final int refKind = (byLines ? 100 : 0) + (refLayers ? 2 : auto ? (createLayer ? 1 : 3) : all ? 1 : 0);
        final int[] layerPx = !refLayers && !auto && !all ? target0.px() : null;
        final com.pacco.animecut.core.BucketFill.Params prm = new com.pacco.animecut.core.BucketFill.Params();
        prm.tolerance = fillTolerance;
        prm.gap = gapRadius;
        prm.toLine = fillToLine;
        // Conservar sombras: la zona se busca por TONO (el brillo pesa un cuarto), asi la
        // sombra del mismo color entra y se recolorea mas oscura. Plano: color exacto.
        prm.colorMode = fillShade ? ColorDist.COLOR : colorMode;
        final com.pacco.animecut.core.MangaFill.Params mprm = new com.pacco.animecut.core.MangaFill.Params();
        mprm.darkThr = mangaPrm.darkThr;
        mprm.tone = true;
        mprm.gap = Math.min(6, Math.max(0, gapRadius));
        mprm.expand = 0;
        mprm.holeMax = 64;
        final float exp = fillExpansion;
        final boolean shade = fillShade;
        final int[][] refOut = new int[1][];
        final com.pacco.animecut.core.BucketFill.Result[] resOut = new com.pacco.animecut.core.BucketFill.Result[1];
        final Project owner = project;
        final long t0 = System.nanoTime();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int[] ref = refLayers ? compositeReference()
                        : auto ? (createLayer ? owner.ref() : compositeExcept(-1, target0))
                        : all ? owner.ref() : layerPx;
                refOut[0] = ref;
                com.pacco.animecut.core.BucketFill.Result res;
                if (byLines) {
                    // Por lineas: mapa de tinta sin trama (puntitos sueltos no cortan la zona)
                    if (bucketLines == null || bucketLinesOwner != owner || bucketLinesVer != owner.version
                            || bucketLinesKind != refKind || bucketLines.length != ref.length) {
                        bucketLines = null;
                        bucketLines = com.pacco.animecut.core.MangaFill.lineMap(ref, owner.w, owner.h, mprm);
                        bucketLinesVer = owner.version;
                        bucketLinesKind = refKind;
                        bucketLinesOwner = owner;
                    }
                    Arrays.fill(scratch, (byte) 0);
                    com.pacco.animecut.core.MangaFill.Result mr = com.pacco.animecut.core.MangaFill.compute(
                            ref, bucketLines, owner.w, owner.h, sx, sy, mprm, scratch);
                    if (mr == null) {
                        res = null;
                    } else {
                        res = new com.pacco.animecut.core.BucketFill.Result();
                        res.seedColor = com.pacco.animecut.core.BucketFill.paper(ref[sy * owner.w + sx]);
                        res.seedLum = com.pacco.animecut.core.BucketFill.lum(res.seedColor);
                        res.gapUsed = mr.gapUsed;
                        res.holes = mr.holes;
                        Rect r = new Rect(mr.bounds);
                        r.inset(-5, -5);
                        r.intersect(0, 0, owner.w, owner.h);
                        // En una capa que TAPA (Normal): el filo junto a la tinta lleva su
                        // antialias (mezcla color/tinta), sin franja blanca ni dientes.
                        if (!multiplyTarget)
                            res.band = com.pacco.animecut.core.BucketFill.edgeBand(ref, owner.w, owner.h, scratch, r,
                                    res.seedColor, fillToLine, prm.tolerance, prm.colorMode);
                        res.bounds = r;
                        res.area = mr.area;
                    }
                } else {
                    // lineas: las marcadas a mano, o las detectadas (cacheadas por version y referencia)
                    byte[] lines = useBarrier && owner.barrier != null ? owner.barrier : null;
                    if (lines == null && autoLines) {
                        if (bucketLines == null || bucketLinesOwner != owner || bucketLinesVer != owner.version
                                || bucketLinesKind != refKind || bucketLines.length != ref.length) {
                            bucketLines = null;
                            bucketLines = AutoLines.build(ref, owner.w, owner.h);
                            bucketLinesVer = owner.version;
                            bucketLinesKind = refKind;
                            bucketLinesOwner = owner;
                        }
                        lines = bucketLines;
                    }
                    prm.barrier = lines;
                    Arrays.fill(scratch, (byte) 0);
                    res = com.pacco.animecut.core.BucketFill.compute(ref, owner.w, owner.h, sx, sy, prm, scratch);
                }
                resOut[0] = res;
                if (res != null && multiplyTarget && exp > 0f) {
                    // Capa en Multiplicar: el color puede meterse debajo de la linea
                    // (la linea de abajo lo oscurece igual), nunca sobre el papel de al lado.
                    Rect r = new Rect(res.bounds);
                    int mm = (int) Math.ceil(exp) + 1;
                    r.inset(-mm, -mm);
                    r.intersect(0, 0, owner.w, owner.h);
                    int limit = res.seedLum - 30;
                    for (int pass = 0; pass < Math.ceil(exp); pass++) {
                        for (int y = Math.max(1, r.top); y < Math.min(owner.h - 1, r.bottom); y++) {
                            for (int x = Math.max(1, r.left); x < Math.min(owner.w - 1, r.right); x++) {
                                int i = y * owner.w + x;
                                if (scratch[i] != 0) continue;
                                if (com.pacco.animecut.core.BucketFill.lum(com.pacco.animecut.core.BucketFill.paper(ref[i])) > limit) continue;
                                if (scratch[i - 1] == (byte) 255 || scratch[i + 1] == (byte) 255
                                        || scratch[i - owner.w] == (byte) 255 || scratch[i + owner.w] == (byte) 255)
                                    scratch[i] = (byte) 253;
                            }
                        }
                        for (int y = r.top; y < r.bottom; y++)
                            for (int x = r.left; x < r.right; x++)
                                if (scratch[y * owner.w + x] == (byte) 253) scratch[y * owner.w + x] = (byte) 255;
                    }
                    res.bounds = r;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                com.pacco.animecut.core.BucketFill.Result res = resOut[0];
                lastBucket = res;
                com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.BUCKET, System.nanoTime() - t0);
                if (owner != project) { setBusy(false); return; }
                if (res == null) {
                    setBusy(false);
                    msg("Ahi no hay nada que rellenar");
                    return;
                }
                PreviewZone z = new PreviewZone();
                z.r = new Rect(res.bounds);
                int rw = z.r.width(), rh = z.r.height();
                z.m = new byte[rw * rh];
                for (int y = 0; y < rh; y++) System.arraycopy(scratch, (y + z.r.top) * owner.w + z.r.left, z.m, y * rw, rw);
                z.area = res.area;
                z.seedLum = res.seedLum;
                z.bucket = true;
                z.ref = refOut[0];
                z.seedColor = res.seedColor;
                z.shade = shade;
                z.flat = multiplyTarget;
                if (bucketPreviewOn) {
                    fillPreviewTarget = target0;
                    fillPreviewCreate = createLayer;
                    fillPreviewAdopt = adoptLegacy;
                    fillPreview.add(z);
                    rebuildPreviewBitmap();
                    setBusy(false);
                    showHud(fillDestinationText() + " · ✓ para pintar, ✕ para cancelar");
                    if (callback != null) callback.onToolStateChanged();
                    return;
                }
                java.util.ArrayList<PreviewZone> one = new java.util.ArrayList<PreviewZone>();
                one.add(z);
                applyBucketZones(one, target0, createLayer, adoptLegacy);
                if (res.gapUsed > 0 && res.gapUsed < gapRadius)
                    showHud("Zona angosta: cierre de cortes reducido a " + res.gapUsed);
                setBusy(false);
            }
        });
    }

    private boolean hintedFillOriginal;

    /** true si la vista previa pendiente creara la capa de color automatica al aceptar. */
    private boolean fillPreviewCreate, fillPreviewAdopt;

    /**
     * Pinta zonas del balde normal en su destino, con un solo deshacer. Crea la capa de
     * color automatica SOLO si hace falta (una vez) y NO cambia la capa elegida.
     */
    private void applyBucketZones(java.util.List<PreviewZone> zs, Layer dest, boolean create, boolean adopt) {
        if (zs.isEmpty() || project == null) return;
        Rect r = null;
        for (PreviewZone z : zs) {
            if (r == null) r = new Rect(z.r);
            else r.union(z.r);
        }
        if (r == null) return;
        Layer t = dest;
        undo.setLabel(create || adopt || fillTarget == FILL_TARGET_AUTO ? "Relleno en capa Color" : "Relleno");
        undo.begin();
        if (create) {
            // una sola capa de color, encima de la capa elegida; la elegida no cambia
            Layer existing = autoColorLayer();
            if (existing != null) {
                t = existing;
                create = false;
            } else {
                undo.recordStruct();
                undo.recordProps();
                Layer active = target();
                // "Color" a secas (como la llama la barra); "Color_N" solo si ya hay una "Color"
                boolean taken = false;
                for (Layer l : project.layers) if (COLOR_LAYER_NAME.equals(l.name)) taken = true;
                Layer cl = new Layer(taken ? uniqueName(COLOR_LAYER_NAME) : COLOR_LAYER_NAME, project.w, project.h);
                cl.role = Layer.ROLE_COLOR;
                int at = active != null ? project.layers.indexOf(active) + 1 : project.layers.size();
                project.layers.add(Math.max(0, Math.min(at, project.layers.size())), cl);
                // la capa elegida sigue siendo la misma (su indice puede correrse uno)
                if (active != null) project.active = project.layers.indexOf(active);
                t = cl;
            }
        } else if (adopt && t != null && t.role == Layer.ROLE_NONE) {
            undo.recordProps();
            t.role = Layer.ROLE_COLOR;
        }
        if (t == null || refuseLocked(t)) { undo.end(); return; }
        undo.recordLayer(t, r);
        undo.end();
        int ca = paintColor >>> 24;
        int[] px = t.px();
        int w = project.w, h = project.h;
        boolean useSel = project.hasSelection();
        for (PreviewZone z : zs) {
            int zw = z.r.width();
            for (int y = z.r.top; y < z.r.bottom; y++) {
                for (int x = z.r.left; x < z.r.right; x++) {
                    int m = z.m[(y - z.r.top) * zw + x - z.r.left] & 0xFF;
                    if (m == 0) continue;
                    int i = y * w + x;
                    float f = brushOpacity;
                    if (useSel) f *= (project.selection[i] & 0xFF) / 255f;
                    int sa = Math.round(f * ca);
                    if (sa <= 0) continue;
                    int c;
                    if (z.flat || t.mode == Layer.MODE_MULTIPLY) {
                        // Multiplicar: color plano; la tinta, grises y trama de abajo lo
                        // oscurecen solos (mezclarlos aqui los oscureceria dos veces).
                        c = paintColor;
                    } else {
                        c = com.pacco.animecut.core.BucketFill.colorFor(z.ref, w, h, i, m, paintColor, z.seedColor, z.shade);
                    }
                    px[i] = t.alphaLock ? Project.lockOver(px[i], c, sa) : Project.over(px[i], c, sa);
                }
            }
        }
        lastBucketTarget = t;
        if (create) {
            layersChanged();
            showHud("Capa \"" + t.name + "\" creada para el color. Tu capa elegida no cambia");
        } else if (adopt) {
            layersChanged();
            showHud("\"" + t.name + "\" queda como capa de color automatica");
        } else {
            pixelsChanged(r);
        }
    }

    /** v8.24: alguna capa visible marcada como "Referencia del balde". */
    private boolean hasReferenceLayers() {
        for (Layer l : project.layers) if (l.reference && l.visible) return true;
        return false;
    }

    /** Composicion de las capas marcadas como referencia (los contornos salen de ahi). */
    private int[] compositeReference() {
        int n = project.w * project.h;
        int[] out = new int[n];
        for (Layer l : project.layers) {
            if (!l.visible || !l.reference) continue;
            int[] px = l.px();
            int op = l.opacity;
            for (int i = 0; i < n; i++) {
                int c = px[i];
                int sa = ((c >>> 24) * op) / 255;
                if (sa == 0) continue;
                out[i] = Project.blend(out[i], c, l.mode, sa);
            }
        }
        return out;
    }

    // ==================================================================
    // Curva Bezier y Polilinea, como en Ibis: tocas para poner puntos,
    // arrastras un punto para moverlo y el check lo dibuja en la capa.
    // ==================================================================

    private final java.util.ArrayList<float[]> shapePts = new java.util.ArrayList<float[]>();
    private int shapeSel = -1, shapeDrag = -1;
    private boolean shapeDownOn, shapeFill;
    private float shapeGrabDx, shapeGrabDy;
    private final Paint shapeStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeDotEdge = new Paint(Paint.ANTI_ALIAS_FLAG);

    {
        shapeStroke.setStyle(Paint.Style.STROKE);
        shapeStroke.setStrokeCap(Paint.Cap.ROUND);
        shapeStroke.setStrokeJoin(Paint.Join.ROUND);
        shapeFillPaint.setStyle(Paint.Style.FILL);
        shapeDot.setStyle(Paint.Style.FILL);
        shapeDotEdge.setStyle(Paint.Style.STROKE);
        shapeDotEdge.setColor(0xFFFFFFFF);
    }

    public boolean isShapeTool() {
        return mode == MODE_CURVE || mode == MODE_POLY || mode == MODE_SHAPE;
    }

    /** Hay una figura, curva o polilinea a medio hacer (Deshacer la quita primero). */
    private boolean hasShapeWork() {
        return mode == MODE_SHAPE ? geo != null : isShapeTool() && !shapePts.isEmpty();
    }

    public int shapeCount() {
        return shapePts.size();
    }

    public void setShapeFill(boolean b) {
        shapeFill = b;
        invalidate();
    }

    public boolean isShapeFill() {
        return shapeFill;
    }

    public void shapeClear() {
        shapePts.clear();
        shapeSel = -1;
        shapeDrag = -1;
        invalidate();
    }

    /** Quita el punto rojo (el elegido). */
    public void shapeDeleteSelected() {
        if (shapePts.isEmpty()) return;
        int k = shapeSel >= 0 && shapeSel < shapePts.size() ? shapeSel : shapePts.size() - 1;
        shapePts.remove(k);
        shapeSel = shapePts.isEmpty() ? -1 : Math.min(k, shapePts.size() - 1);
        invalidate();
    }

    private float dpx(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private int hitShapePoint(float sx, float sy) {
        float best = dpx(26f);
        int hit = -1;
        float[] q = new float[2];
        for (int i = shapePts.size() - 1; i >= 0; i--) {
            q[0] = shapePts.get(i)[0];
            q[1] = shapePts.get(i)[1];
            view.mapPoints(q);
            float d = (float) Math.hypot(q[0] - sx, q[1] - sy);
            if (d < best) {
                best = d;
                hit = i;
            }
        }
        return hit;
    }

    private float[] imgPoint(float sx, float sy) {
        toImage(sx, sy);
        float x = Math.max(0f, Math.min(project.w - 1, point[0]));
        float y = Math.max(0f, Math.min(project.h - 1, point[1]));
        return new float[]{x, y};
    }

    /** v8.23: deshacer lo que el primer dedo hizo si resulta ser un gesto de dos dedos. */
    private boolean shapeAddedThisTouch;
    private float shapeOrigX, shapeOrigY;
    private int shapeOrigSel = -1;

    private void shapeDown(float sx, float sy) {
        if (mode == MODE_SHAPE) {
            geoDown(sx, sy);
            return;
        }
        shapeDownOn = true;
        shapeAddedThisTouch = false;
        shapeOrigSel = shapeSel;
        int k = hitShapePoint(sx, sy);
        shapeDrag = k;
        if (k >= 0) {
            shapeOrigX = shapePts.get(k)[0];
            shapeOrigY = shapePts.get(k)[1];
            shapeSel = k;
            float[] q = {shapePts.get(k)[0], shapePts.get(k)[1]};
            view.mapPoints(q);
            shapeGrabDx = q[0] - sx;
            shapeGrabDy = q[1] - sy;
        }
        invalidate();
    }

    private void shapeMove(float sx, float sy, float moved) {
        if (mode == MODE_SHAPE) {
            geoMove(sx, sy, moved);
            return;
        }
        if (!shapeDownOn) return;
        if (shapeDrag < 0) {
            if (moved <= touchSlop) return;
            // arrastrar en vacio: pone un punto nuevo y lo lleva con el dedo
            shapePts.add(imgPoint(downX, downY));
            shapeAddedThisTouch = true;
            shapeDrag = shapeSel = shapePts.size() - 1;
            shapeGrabDx = 0f;
            shapeGrabDy = 0f;
        }
        float[] p = imgPoint(sx + shapeGrabDx, sy + shapeGrabDy);
        float[] t = shapePts.get(shapeDrag);
        t[0] = p[0];
        t[1] = p[1];
        invalidate();
    }

    private void shapeUp() {
        if (mode == MODE_SHAPE) {
            geoUp();
            return;
        }
        if (!shapeDownOn) return;
        shapeDownOn = false;
        if (shapeDrag < 0) {
            shapePts.add(imgPoint(downX, downY));
            shapeSel = shapePts.size() - 1;
            if (shapePts.size() == 1) msg("Toca para poner puntos. Arrastra un punto para moverlo. Check para dibujar");
        }
        shapeDrag = -1;
        invalidate();
    }

    private void shapeCancelTouch() {
        if (mode == MODE_SHAPE) {
            geoCancelTouch();
            return;
        }
        // Llego un segundo dedo (zoom/giro) o el sistema cancelo: no debe quedar
        // un punto nuevo ni un punto movido por accidente.
        if (shapeDownOn && shapeDrag >= 0 && shapeDrag < shapePts.size()) {
            if (shapeAddedThisTouch && shapeDrag == shapePts.size() - 1) {
                shapePts.remove(shapeDrag);
                shapeSel = Math.min(shapeOrigSel, shapePts.size() - 1);
            } else if (!shapeAddedThisTouch) {
                float[] t = shapePts.get(shapeDrag);
                t[0] = shapeOrigX;
                t[1] = shapeOrigY;
            }
        }
        shapeAddedThisTouch = false;
        shapeDownOn = false;
        shapeDrag = -1;
        invalidate();
    }

    /** La forma como una fila de puntos en la imagen (x0,y0,x1,y1,...). */
    private float[] shapeFlat(boolean closed) {
        int n = shapePts.size();
        java.util.ArrayList<Float> out = new java.util.ArrayList<Float>();
        if (n == 0) return new float[0];
        if (mode == MODE_POLY || n < 3) {
            for (float[] p : shapePts) {
                out.add(p[0]);
                out.add(p[1]);
            }
            if (closed) {
                out.add(shapePts.get(0)[0]);
                out.add(shapePts.get(0)[1]);
            }
        } else {
            // Curva que pasa por todos los puntos. v8.23: Catmull-Rom CENTRIPETA
            // (la uniforme hacia ganchos de ~10 px con puntos a distancias desparejas).
            int segs = closed ? n : n - 1;
            out.add(shapePts.get(0)[0]);
            out.add(shapePts.get(0)[1]);
            float[] c = new float[2];
            for (int i = 0; i < segs; i++) {
                float[] p0 = shapePts.get(closed ? (i - 1 + n) % n : Math.max(0, i - 1));
                float[] p1 = shapePts.get(i);
                float[] p2 = shapePts.get((i + 1) % n);
                float[] p3 = shapePts.get(closed ? (i + 2) % n : Math.min(n - 1, i + 2));
                float len = (float) Math.hypot(p2[0] - p1[0], p2[1] - p1[1]);
                int steps = Math.max(8, Math.min(400, (int) (len / 2f)));
                for (int k = 1; k <= steps; k++) {
                    com.pacco.animecut.core.StrokeEngine.centripetal(p0[0], p0[1], p1[0], p1[1], p2[0], p2[1],
                            p3[0], p3[1], k / (float) steps, c);
                    out.add(c[0]);
                    out.add(c[1]);
                }
            }
        }
        float[] a = new float[out.size()];
        for (int i = 0; i < a.length; i++) a[i] = out.get(i);
        return a;
    }

    private void drawShape(Canvas c) {
        int n = shapePts.size();
        boolean closed = shapeFill && n >= 3;
        float sc = currentScale();
        if (n >= 2) {
            float[] f = shapeFlat(closed);
            view.mapPoints(f);
            Path p = new Path();
            p.moveTo(f[0], f[1]);
            for (int i = 2; i + 1 < f.length; i += 2) p.lineTo(f[i], f[i + 1]);
            int col = (paintColor & 0x00FFFFFF) | (Math.round((paintColor >>> 24) * brushOpacity) << 24);
            if (closed) {
                Path fp = new Path(p);
                fp.close();
                shapeFillPaint.setColor(col);
                c.drawPath(fp, shapeFillPaint);
            }
            shapeStroke.setColor(col);
            shapeStroke.setStrokeWidth(Math.max(1f, brushRadius * 2f * sc));
            c.drawPath(p, shapeStroke);
            // v8.24: sin la linea punteada entre los puntos (molestaba al ver la curva)
        }
        float r = dpx(9f);
        shapeDotEdge.setStrokeWidth(dpx(2f));
        float[] q = new float[2];
        for (int i = 0; i < n; i++) {
            q[0] = shapePts.get(i)[0];
            q[1] = shapePts.get(i)[1];
            view.mapPoints(q);
            shapeDot.setColor(i == shapeSel ? 0xFFE53935 : 0xFF1E6FE0);
            c.drawCircle(q[0], q[1], r, shapeDot);
            c.drawCircle(q[0], q[1], r, shapeDotEdge);
        }
    }

    /** Check: dibuja la forma en la capa elegida con el color y el grosor de abajo. */
    public void commitShape() {
        if (project == null) return;
        if (shapePts.size() < 2) {
            msg("Pon al menos 2 puntos");
            return;
        }
        boolean closed = shapeFill && shapePts.size() >= 3;
        float[] f = shapeFlat(closed);
        if (!beginLayerStroke()) return;
        strokeErase = false;
        painted = 0;
        strokeRect = null;
        beginBatch();
        try {
            if (closed) fillShape(f);
            float step = Math.max(0.5f, brushRadius * 0.25f);
            stampPaint(f[0], f[1]);
            for (int i = 2; i + 1 < f.length; i += 2) {
                float ax = f[i - 2], ay = f[i - 1], bx = f[i], by = f[i + 1];
                float d = (float) Math.hypot(bx - ax, by - ay);
                int m = Math.max(1, (int) Math.ceil(d / step));
                for (int k = 1; k <= m; k++) {
                    float t = k / (float) m;
                    stampPaint(ax + (bx - ax) * t, ay + (by - ay) * t);
                }
            }
        } finally {
            batchDepth = Math.max(0, batchDepth - 1);
            batchRect = null;
        }
        drawing = false;
        if (strokeRect != null) {
            recordEffectStrokeUndo(mode == MODE_CURVE ? "Curva" : "Polilinea");
            project.markDirty();
            wire = null;
            updateDisplayRegion(strokeRect);
            changed();
        }
        strokeRect = null;
        shapePts.clear();
        shapeSel = -1;
        invalidate();
    }

    /** Llenar: pinta por dentro la forma cerrada. */
    private void fillShape(float[] f) {
        if (f.length < 6) return;
        Path p = new Path();
        p.moveTo(f[0], f[1]);
        for (int i = 2; i + 1 < f.length; i += 2) p.lineTo(f[i], f[i + 1]);
        p.close();
        RectF b = new RectF();
        p.computeBounds(b, true);
        Rect r = new Rect((int) Math.floor(b.left) - 1, (int) Math.floor(b.top) - 1,
                (int) Math.ceil(b.right) + 1, (int) Math.ceil(b.bottom) + 1);
        clamp(r);
        if (r.width() <= 0 || r.height() <= 0) return;
        if (!captureEffectStrokeBackup(r)) return;
        Bitmap m;
        try {
            m = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ALPHA_8);
        } catch (OutOfMemoryError e) {
            msg("La forma es muy grande para rellenar");
            return;
        }
        Canvas cv = new Canvas(m);
        cv.translate(-r.left, -r.top);
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setStyle(Paint.Style.FILL);
        pp.setColor(0xFF000000);
        cv.drawPath(p, pp);
        int rb = m.getRowBytes();
        byte[] a = new byte[rb * r.height()];
        m.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(a));
        m.recycle();
        int[] px = strokeLayer.px();
        int ac = paintColor >>> 24;
        int w = project.w;
        for (int y = 0; y < r.height(); y++) {
            int off = (r.top + y) * w + r.left, lo = y * rb;
            for (int x = 0; x < r.width(); x++) {
                int av = a[lo + x] & 0xFF;
                if (av == 0) continue;
                int i = off + x;
                float fa = av / 255f * brushOpacity;
                if (selectionActive) fa *= (project.selection[i] & 0xFF) / 255f;
                int sa = (int) (fa * ac);
                if (sa <= (cov[i] & 0xFF)) continue;
                cov[i] = (byte) sa;
                px[i] = paintOver(strokeOriginalAt(i), sa);
            }
        }
        grow(r);
    }

    // ==================================================================
    // v8.79 FIGURAS: linea, rectangulo, circulo, elipse, poligono, rectangulo
    // redondeado, flecha y bocadillo. La figura queda como borrador: se mueve,
    // se agranda y se gira; recien con el check (o tocando afuera) se pinta.
    // ==================================================================

    private static final int G_NONE = -1, G_ROT = 8, G_TAIL = 9, G_P0 = 10, G_P1 = 11, G_MOVE = 12, G_CREATE = 13;
    private ShapeGeom.Shape geo, geoSnap, geoPrev;
    private final ShapeGeom.Style geoStyle = new ShapeGeom.Style();
    private int geoType = ShapeGeom.RECT;
    private int geoGrab = G_NONE;
    private boolean geoDownOn, geoMoved;
    private float geoDownIx, geoDownIy, geoGrabDx, geoGrabDy;
    private final Paint geoFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint geoLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint geoGuidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    {
        geoFillPaint.setStyle(Paint.Style.FILL);
        geoLinePaint.setStyle(Paint.Style.STROKE);
        geoGuidePaint.setStyle(Paint.Style.STROKE);
        geoGuidePaint.setColor(0xCC1E6FE0);
    }

    public void setShapeType(int t) {
        geoType = Math.max(0, Math.min(ShapeGeom.COUNT - 1, t));
        // la figura que ya esta puesta cambia de tipo sin moverse
        if (geo != null && !geoDownOn) ShapeGeom.convert(geo, geoType, geoStyle);
        invalidate();
    }

    public int getShapeType() {
        return geoType;
    }

    /** El estilo vive aqui; el panel lo cambia y llama a shapeStyleChanged(). */
    public ShapeGeom.Style getShapeStyle() {
        return geoStyle;
    }

    public void shapeStyleChanged() {
        if (geo != null && geoLocked(geo)) {
            float m = Math.max(geo.hw, geo.hh);
            geo.hw = m;
            geo.hh = m;
        }
        invalidate();
    }

    public boolean hasShapeDraft() {
        return geo != null;
    }

    public void discardShapeDraft() {
        geo = null;
        geoPrev = null;
        geoSnap = null;
        geoGrab = G_NONE;
        geoDownOn = false;
        invalidate();
    }

    /** Check: pinta la figura en la capa elegida. */
    public boolean applyShapeDraft() {
        if (geo == null) {
            showHud("Arrastra en la imagen para hacer una figura");
            return false;
        }
        if (geoDownOn) return false;
        boolean ok = commitGeo(geo);
        if (ok) geo = null;
        invalidate();
        return ok;
    }

    /** El grosor del contorno es el tamano de la barra de abajo (como en Ibis). */
    private void geoSyncWidth() {
        geoStyle.strokeW = Math.max(1f, brushRadius * 2f);
    }

    private boolean geoLocked(ShapeGeom.Shape s) {
        return s.type == ShapeGeom.CIRCLE || (s.type == ShapeGeom.RECT && geoStyle.square);
    }

    private float geoInvScale() {
        return 1f / Math.max(1e-4f, currentScale());
    }

    /**
     * Puntos para tocar, en la imagen: 0..3 esquinas, 4..7 lados, 8 girar, 9 cola,
     * 10 y 11 extremos. NaN = ese punto no se usa en esta figura.
     */
    private float[] geoHandles(ShapeGeom.Shape s) {
        float[] h = new float[24];
        Arrays.fill(h, Float.NaN);
        if (s.isSegment()) {
            h[20] = s.x0;
            h[21] = s.y0;
            h[22] = s.x1;
            h[23] = s.y1;
            return h;
        }
        float[] cs = ShapeGeom.corners(s);
        System.arraycopy(cs, 0, h, 0, 8);
        float[] q = new float[2];
        float sc = currentScale();
        // puntos de los lados (solo ancho o solo alto): no en el circulo ni con 1:1,
        // y no si la figura se ve chica (se juntarian con las esquinas)
        if (!geoLocked(s) && s.hw * sc > dpx(34f) && s.hh * sc > dpx(34f)) {
            ShapeGeom.toWorld(s, 0f, -s.hh, q); h[8] = q[0]; h[9] = q[1];
            ShapeGeom.toWorld(s, s.hw, 0f, q); h[10] = q[0]; h[11] = q[1];
            ShapeGeom.toWorld(s, 0f, s.hh, q); h[12] = q[0]; h[13] = q[1];
            ShapeGeom.toWorld(s, -s.hw, 0f, q); h[14] = q[0]; h[15] = q[1];
        }
        if (s.type != ShapeGeom.CIRCLE) {
            ShapeGeom.toWorld(s, 0f, -s.hh - dpx(34f) * geoInvScale(), q);
            h[16] = q[0];
            h[17] = q[1];
        }
        if (s.type == ShapeGeom.BUBBLE) {
            h[18] = s.tx;
            h[19] = s.ty;
        }
        return h;
    }

    private int geoHitHandle(ShapeGeom.Shape s, float sx, float sy) {
        float[] h = geoHandles(s);
        float best = dpx(24f);
        int hit = G_NONE;
        float[] q = new float[2];
        // la cola, los extremos y girar se prueban primero (ganan si estan igual de cerca)
        int[] order = {9, 10, 11, 8, 0, 1, 2, 3, 4, 5, 6, 7};
        for (int k : order) {
            if (Float.isNaN(h[k * 2])) continue;
            q[0] = h[k * 2];
            q[1] = h[k * 2 + 1];
            view.mapPoints(q);
            float d = (float) Math.hypot(q[0] - sx, q[1] - sy);
            if (d < best - 0.5f) {
                best = d;
                hit = k;
            }
        }
        return hit;
    }

    private void geoDown(float sx, float sy) {
        geoSyncWidth();
        geoDownOn = true;
        geoMoved = false;
        toImage(sx, sy);
        geoDownIx = point[0];
        geoDownIy = point[1];
        geoGrabDx = 0f;
        geoGrabDy = 0f;
        geoPrev = null;
        geoSnap = null;
        if (geo != null) {
            int k = geoHitHandle(geo, sx, sy);
            if (k >= 0) {
                geoGrab = k;
                geoSnap = geo.copy();
                float[] h = geoHandles(geo);
                float[] q = {h[k * 2], h[k * 2 + 1]};
                view.mapPoints(q);
                geoGrabDx = q[0] - sx;
                geoGrabDy = q[1] - sy;
                invalidate();
                return;
            }
            float m = dpx(14f) * geoInvScale();
            if (geo.isSegment()) m = Math.max(m, geoStyle.strokeW / 2f + m * 0.5f);
            if (ShapeGeom.hit(geo, geoDownIx, geoDownIy, m)) {
                geoGrab = G_MOVE;
                geoSnap = geo.copy();
                invalidate();
                return;
            }
            // afuera: la figura actual se pinta al soltar (un segundo dedo la deja como estaba)
            geoPrev = geo;
        }
        geoGrab = G_CREATE;
        invalidate();
    }

    private void geoMove(float sx, float sy, float moved) {
        if (!geoDownOn || geoGrab == G_NONE) return;
        if (!geoMoved) {
            if (moved <= touchSlop) return;
            geoMoved = true;
        }
        toImage(sx + geoGrabDx, sy + geoGrabDy);
        float ix = point[0], iy = point[1];
        if (geoGrab == G_CREATE) {
            float[] b = {ix, iy};
            if (geoType == ShapeGeom.LINE || geoType == ShapeGeom.ARROW) geoSnapEnd(geoDownIx, geoDownIy, b);
            geo = ShapeGeom.create(geoType, geoDownIx, geoDownIy, b[0], b[1], geoStyle);
        } else if (geo != null) {
            switch (geoGrab) {
                case G_MOVE:
                    ShapeGeom.moveFrom(geo, geoSnap, ix - geoDownIx, iy - geoDownIy);
                    break;
                case G_ROT:
                    ShapeGeom.rotateTo(geo, ix, iy);
                    break;
                case G_TAIL:
                    geo.tx = ix;
                    geo.ty = iy;
                    break;
                case G_P0: {
                    float[] b = {ix, iy};
                    geoSnapEnd(geo.x1, geo.y1, b);
                    geo.x0 = b[0];
                    geo.y0 = b[1];
                    break;
                }
                case G_P1: {
                    float[] b = {ix, iy};
                    geoSnapEnd(geo.x0, geo.y0, b);
                    geo.x1 = b[0];
                    geo.y1 = b[1];
                    break;
                }
                default:
                    if (geoGrab < 4) ShapeGeom.resizeCorner(geo, geoGrab, ix, iy, geoLocked(geo));
                    else if (geoGrab < 8) ShapeGeom.resizeSide(geo, geoGrab - 4, ix, iy);
                    break;
            }
        }
        invalidate();
    }

    /** Linea y flecha: cerca de horizontal, vertical o 45 grados se enganchan (3 grados). */
    private static void geoSnapEnd(float ax, float ay, float[] b) {
        float dx = b[0] - ax, dy = b[1] - ay;
        float len = (float) Math.hypot(dx, dy);
        if (len < 1f) return;
        double a = Math.atan2(dy, dx), st = Math.PI / 4, n = Math.round(a / st) * st;
        if (Math.abs(a - n) < Math.toRadians(3)) {
            b[0] = ax + (float) Math.cos(n) * len;
            b[1] = ay + (float) Math.sin(n) * len;
        }
    }

    private void geoUp() {
        if (!geoDownOn) return;
        geoDownOn = false;
        int g = geoGrab;
        geoGrab = G_NONE;
        geoSnap = null;
        if (g != G_CREATE) {
            invalidate();
            return;
        }
        ShapeGeom.Shape prev = geoPrev;
        geoPrev = null;
        if (prev != null) {
            // tocar o dibujar afuera pinta la figura anterior
            if (!commitGeo(prev)) {
                geo = prev;
                invalidate();
                return;
            }
            if (!geoMoved) {
                geo = null;
                showHud("Figura lista. Deshacer la quita");
                invalidate();
                return;
            }
        }
        float sc = currentScale();
        boolean tiny = geo == null || (geo.isSegment()
                ? Math.hypot(geo.x1 - geo.x0, geo.y1 - geo.y0) * sc < dpx(10f)
                : Math.max(geo.hw, geo.hh) * sc < dpx(5f));
        if (tiny) {
            // un toque en vacio: figura de tamano comodo en ese lugar
            float half = Math.min(getWidth(), getHeight()) * 0.18f * geoInvScale();
            float hy = geoType == ShapeGeom.CIRCLE || geoType == ShapeGeom.POLYGON ? half : half * 0.7f;
            if (geoType == ShapeGeom.LINE || geoType == ShapeGeom.ARROW) hy = 0f;
            geo = ShapeGeom.create(geoType, geoDownIx - half, geoDownIy - hy, geoDownIx + half, geoDownIy + hy, geoStyle);
            if (geoType == ShapeGeom.LINE || geoType == ShapeGeom.ARROW) {
                geo.y0 = geoDownIy;
                geo.y1 = geoDownIy;
            }
        }
        invalidate();
    }

    private void geoCancelTouch() {
        // Llego un segundo dedo o el sistema cancelo: todo queda como antes del toque
        if (!geoDownOn) return;
        geoDownOn = false;
        if (geoGrab == G_CREATE) geo = geoPrev;
        else if (geoSnap != null && geo != null) geo = geoSnap;
        geoPrev = null;
        geoSnap = null;
        geoGrab = G_NONE;
        invalidate();
    }

    private int geoStrokeColor() {
        return geoStyle.strokeCurrent ? paintColor : geoStyle.strokeColor;
    }

    private int geoFillColor() {
        return geoStyle.fillCurrent ? paintColor : geoStyle.fillColor;
    }

    private static int withOp(int c, float op) {
        int a = Math.round((c >>> 24) * Math.max(0f, Math.min(1f, op)));
        return (c & 0x00FFFFFF) | (a << 24);
    }

    /** El contorno como Path. m != null: pasado a la pantalla. closedOnly: solo lo rellenable. */
    private static Path geoPathOf(ShapeGeom.Outline o, boolean closedOnly, Matrix m) {
        Path p = new Path();
        p.setFillType(Path.FillType.WINDING);
        for (int k = 0; k < o.polys.length; k++) {
            if (closedOnly && !o.closed[k]) continue;
            float[] a = o.polys[k];
            if (a.length < 4) continue;
            if (m != null) {
                a = a.clone();
                m.mapPoints(a);
            }
            p.moveTo(a[0], a[1]);
            for (int i = 2; i + 1 < a.length; i += 2) p.lineTo(a[i], a[i + 1]);
            if (o.closed[k]) p.close();
        }
        return p;
    }

    private void geoStrokeStyle(Paint p, ShapeGeom.Shape s, float width) {
        boolean sharp = ShapeGeom.sharpCorners(s, geoStyle);
        p.setStrokeWidth(Math.max(1f, width));
        p.setStrokeJoin(sharp ? Paint.Join.MITER : Paint.Join.ROUND);
        p.setStrokeMiter(4f);
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    private void drawGeoBody(Canvas c, ShapeGeom.Shape s, float sc) {
        ShapeGeom.Outline o = ShapeGeom.outline(s, geoStyle);
        if (o.polys.length == 0) return;
        boolean fill = geoStyle.fillOn && o.fillable;
        geoFillPaint.setAntiAlias(geoStyle.smooth);
        geoLinePaint.setAntiAlias(geoStyle.smooth);
        if (fill) {
            geoFillPaint.setColor(withOp(geoFillColor(), geoStyle.fillOp));
            c.drawPath(geoPathOf(o, true, view), geoFillPaint);
        }
        if (geoStyle.strokeOn) {
            geoLinePaint.setColor(withOp(geoStrokeColor(), geoStyle.strokeOp));
            geoStrokeStyle(geoLinePaint, s, geoStyle.strokeW * sc);
            c.drawPath(geoPathOf(o, false, view), geoLinePaint);
        } else if (!fill) {
            // sin contorno ni relleno: una guia fina para no perderla de vista
            geoGuidePaint.setPathEffect(null);
            geoGuidePaint.setStrokeWidth(dpx(1.5f));
            c.drawPath(geoPathOf(o, false, view), geoGuidePaint);
        }
    }

    private void drawGeo(Canvas c) {
        geoSyncWidth();
        float sc = currentScale();
        if (geoPrev != null && geoPrev != geo) drawGeoBody(c, geoPrev, sc);
        if (geo == null) return;
        drawGeoBody(c, geo, sc);
        if (geoDownOn && geoGrab == G_CREATE) return;      // mientras la creas, sin puntos
        float[] h = geoHandles(geo);
        float[] sh = h.clone();
        view.mapPoints(sh);
        geoGuidePaint.setStrokeWidth(dpx(1.5f));
        if (!geo.isSegment()) {
            // caja punteada y la varita de girar
            geoGuidePaint.setPathEffect(new android.graphics.DashPathEffect(new float[]{dpx(6f), dpx(5f)}, 0f));
            Path bx = new Path();
            bx.moveTo(sh[0], sh[1]);
            for (int i = 1; i < 4; i++) bx.lineTo(sh[i * 2], sh[i * 2 + 1]);
            bx.close();
            c.drawPath(bx, geoGuidePaint);
            geoGuidePaint.setPathEffect(null);
            if (!Float.isNaN(sh[16])) {
                float[] top = new float[2];
                ShapeGeom.toWorld(geo, 0f, -geo.hh, top);
                view.mapPoints(top);
                c.drawLine(top[0], top[1], sh[16], sh[17], geoGuidePaint);
            }
        }
        float r = dpx(9f), rs = dpx(7f);
        shapeDotEdge.setStrokeWidth(dpx(2f));
        for (int k = 0; k < 12; k++) {
            float x = sh[k * 2], y = sh[k * 2 + 1];
            if (Float.isNaN(x) || Float.isNaN(y)) continue;
            int col = k == G_ROT ? 0xFF43A047 : k == G_TAIL ? 0xFFFF9800 : 0xFF1E6FE0;
            float rr = k >= 4 && k < 8 ? rs : r;
            boolean active = geoDownOn && geoGrab == k;
            shapeDot.setColor(active ? 0xFFE53935 : col);
            c.drawCircle(x, y, rr, shapeDot);
            c.drawCircle(x, y, rr, shapeDotEdge);
        }
    }

    private int geoOver(int dst, int src, int sa) {
        if (sa <= 0) return dst;
        if (sa > 255) sa = 255;
        return strokeLock ? Project.lockOver(dst, src, sa) : Project.over(dst, src, sa);
    }

    /**
     * Pinta la figura en la capa elegida: primero el relleno y encima el contorno, cada uno con
     * su color y opacidad. Con seleccion, solo dentro de lo azul. Un solo paso en Deshacer.
     */
    private boolean commitGeo(ShapeGeom.Shape s) {
        if (project == null || s == null) return false;
        geoSyncWidth();
        ShapeGeom.Style st = geoStyle;
        ShapeGeom.Outline o = ShapeGeom.outline(s, st);
        boolean doFill = st.fillOn && o.fillable && st.fillOp > 0f;
        boolean doStroke = st.strokeOn && st.strokeOp > 0f;
        if (o.polys.length == 0) return true;
        if (!doFill && !doStroke) {
            showHud("Prende Contorno o Relleno en los ajustes de figura", 2200);
            return false;
        }
        float sw = Math.max(1f, st.strokeW);
        float[] b = ShapeGeom.bounds(o);
        float pad = (doStroke ? sw * 2f : 0f) + 3f;
        Rect r = new Rect((int) Math.floor(b[0] - pad), (int) Math.floor(b[1] - pad),
                (int) Math.ceil(b[2] + pad), (int) Math.ceil(b[3] + pad));
        clamp(r);
        if (r.width() <= 0 || r.height() <= 0) {
            showHud("La figura quedo fuera de la imagen");
            return true;
        }
        if (!beginLayerStroke()) return false;
        strokeErase = false;
        painted = 0;
        strokeRect = null;
        boolean brush = doStroke && st.strokeBrush;
        int fCol = geoFillColor(), sCol = geoStrokeColor();
        int oldColor = paintColor;
        float oldOp = brushOpacity, oldRad = brushRadius, oldEff = effR;
        boolean oldStop = stopActive;
        boolean ok = false;
        beginBatch();
        try {
            if (captureEffectStrokeBackup(r)) {
                int rw = r.width(), rh = r.height();
                byte[] fm = null, sm = null;
                int rb = 0;
                if (doFill || (doStroke && !brush)) {
                    Bitmap m = Bitmap.createBitmap(rw, rh, Bitmap.Config.ALPHA_8);
                    Canvas cv = new Canvas(m);
                    cv.translate(-r.left, -r.top);
                    Paint mp = new Paint();
                    mp.setAntiAlias(st.smooth);
                    mp.setColor(0xFF000000);
                    rb = m.getRowBytes();
                    if (doFill) {
                        mp.setStyle(Paint.Style.FILL);
                        cv.drawPath(geoPathOf(o, true, null), mp);
                        fm = new byte[rb * rh];
                        m.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(fm));
                        m.eraseColor(0);
                    }
                    if (doStroke && !brush) {
                        mp.setStyle(Paint.Style.STROKE);
                        geoStrokeStyle(mp, s, sw);
                        cv.drawPath(geoPathOf(o, false, null), mp);
                        sm = new byte[rb * rh];
                        m.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(sm));
                    }
                    m.recycle();
                }
                if (brush) {
                    // contorno con el pincel actual (su textura y dureza), en el color del contorno
                    paintColor = sCol;
                    brushOpacity = st.strokeOp;
                    brushRadius = Math.max(0.5f, sw / 2f);
                    effR = -1f;
                    stopActive = false;
                    float step = Math.max(0.5f, brushRadius * 0.25f);
                    for (int k = 0; k < o.polys.length; k++) {
                        float[] a = o.polys[k];
                        int n = a.length / 2;
                        if (n < 1) continue;
                        stampPaint(a[0], a[1]);
                        int segs = o.closed[k] ? n : n - 1;
                        for (int j = 0; j < segs; j++) {
                            int j1 = (j + 1) % n;
                            float ax = a[j * 2], ay = a[j * 2 + 1], bx = a[j1 * 2], by = a[j1 * 2 + 1];
                            int steps = Math.max(1, (int) Math.ceil(Math.hypot(bx - ax, by - ay) / step));
                            for (int q = 1; q <= steps; q++) {
                                float t = q / (float) steps;
                                stampPaint(ax + (bx - ax) * t, ay + (by - ay) * t);
                            }
                        }
                    }
                }
                if (fm != null || sm != null) {
                    int[] px = strokeLayer.px();
                    int w = project.w;
                    float fk = st.fillOp * (fCol >>> 24) / 255f, sk = st.strokeOp * (sCol >>> 24) / 255f;
                    origReset();
                    for (int y = 0; y < rh; y++) {
                        int row = (r.top + y) * w + r.left, mo = y * rb;
                        for (int x = 0; x < rw; x++) {
                            int af = fm != null ? fm[mo + x] & 0xFF : 0;
                            int as = sm != null ? sm[mo + x] & 0xFF : 0;
                            if (af == 0 && as == 0) continue;      // lo del pincel ya quedo pintado
                            int i = row + x;
                            float sel = selectionActive ? (project.selection[i] & 0xFF) / 255f : 1f;
                            if (sel <= 0f) continue;
                            int c = origAt(r.left + x, r.top + y, i);
                            c = geoOver(c, fCol, (int) (af * fk * sel + 0.5f));
                            c = geoOver(c, sCol, (int) (as * sk * sel + 0.5f));
                            if (brush && cov != null) c = geoOver(c, sCol, cov[i] & 0xFF);
                            px[i] = c;
                        }
                    }
                }
                ok = true;
            }
        } catch (OutOfMemoryError e) {
            msg("La figura es muy grande para la memoria. Prueba una mas chica");
        } finally {
            paintColor = oldColor;
            brushOpacity = oldOp;
            brushRadius = oldRad;
            effR = oldEff;
            stopActive = oldStop;
            batchDepth = Math.max(0, batchDepth - 1);
            batchRect = null;
        }
        drawing = false;
        if (!ok) {
            restoreEffectStrokeBackup();
            updateDisplayRegion(r);
            strokeRect = null;
            return false;
        }
        grow(r);
        recordEffectStrokeUndo("Figura");
        project.markDirty();
        wire = null;
        updateDisplayRegion(strokeRect);
        changed();
        strokeRect = null;
        return true;
    }

    public void beginPreview() {
        if (project == null) return;
        previewBackup = project.selection.clone();
    }

    public void previewColorRange(final int color, final int tol, final boolean replace) {
        if (project == null || previewBackup == null || busy) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.globalColor(project.ref(), project.w, project.h, scratch, color, tol,
                        softness, colorMode);
            }
        }, new Runnable() {
            @Override
            public void run() {
                System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
                if (replace) project.clearSelection();
                if (lastFillRect != null) mergeScratch(lastFillRect);
                refreshOverlay(null);
                setBusy(false);
            }
        });
    }

    public void endPreview(boolean keep) {
        if (project == null || previewBackup == null) return;
        if (keep) {
            undo.setLabel("Gama de colores");
            undo.recordSelectionFromBackup(project.fullRect(), previewBackup);
        } else {
            System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
        }
        previewBackup = null;
        refreshOverlay(null);
        changed();
    }

    // ==================================================================
    // Separar partes con rayones
    // ==================================================================

    private void ensureMarkers() {
        int n = project.w * project.h;
        if (markers == null || markers.length != n) markers = new byte[n];
        if (markersOverlay == null && overlay != null) {
            markersOverlay = Bitmap.createBitmap(overlay.getWidth(), overlay.getHeight(), Bitmap.Config.ARGB_8888);
        }
    }

    private void stampMarker(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        float r2 = brushRadius * brushRadius;
        byte v = (byte) (subtract ? 0 : markerLabel);
        for (int y = r.top; y < r.bottom; y++) {
            float dy = y + 0.5f - cy;
            for (int x = r.left; x < r.right; x++) {
                float dx = x + 0.5f - cx;
                if (dx * dx + dy * dy <= r2) markers[y * project.w + x] = v;
            }
        }
        paintLabelOverlay(markersOverlay, markers, r, true);
        invalidate();
    }

    private void paintLabelOverlay(Bitmap ov, byte[] data, Rect r, boolean labels) {
        if (ov == null || data == null) return;
        int ow = ov.getWidth(), oh = ov.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int v = data[sy * project.w + sx] & 0xFF;
                if (labels) row[i] = v == 0 ? 0 : (0xB0000000 | (labelColor(v) & 0xFFFFFF));
                else row[i] = v == 0 ? 0 : (((v * 120) / 255) << 24) | 0x34C759;
            }
            ov.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    // ---------------- v8.44 Colorear facil: Rayar partes ----------------
    /** Rayar partes: los rayones de Separar, cada uno con el color que elegiste (no la paleta fija). */
    private boolean rayMode;
    private final int[] rayColors = new int[LABEL_COLORS.length + 1];

    private int labelColor(int v) {
        if (rayMode && v > 0 && v < rayColors.length && rayColors[v] != 0) return rayColors[v];
        return LABEL_COLORS[Math.max(1, Math.min(LABEL_COLORS.length, v)) - 1];
    }

    public boolean isRayMode() { return rayMode && mode == MODE_MARKER; }

    /** true si hay rayones de partes (no de "no pintar"). */
    public boolean hasRayMarks() { return hasLabel(false); }

    public void setRayMode(boolean on) {
        if (rayMode == on) return;
        rayMode = on;
        java.util.Arrays.fill(rayColors, 0);
        clearMarkers();
    }

    /** Elige el color para los proximos rayones (cada color usa una etiqueta; hasta 11 colores). */
    public void setRayColor(int color) {
        color |= 0xFF000000;
        int free = -1;
        for (int k = 1; k < BG_LABEL; k++) {
            if (rayColors[k] == color) { markerLabel = k; return; }
            if (free < 0 && rayColors[k] == 0) free = k;
        }
        if (free < 0) { free = BG_LABEL - 1; msg("Maximo 11 colores: el ultimo se reemplaza"); }
        rayColors[free] = color;
        markerLabel = free;
    }

    public int getRayColor() {
        int l = markerLabel;
        if (l == BG_LABEL) return 0;
        return l > 0 && l < rayColors.length ? rayColors[l] : 0;
    }

    /** Rayar "no pintar": lo rayado queda en B/N (fondo, ojos...). */
    public void setRayNoPaint() { markerLabel = BG_LABEL; }

    public boolean isRayNoPaint() { return markerLabel == BG_LABEL; }

    /**
     * Toda la imagen se reparte entre los rayones (como Separar: el limite cae sobre la linea) y
     * cada parte se pinta como una zona de Color por zonas (con sombra y luz). Con Deshacer.
     */
    public void rayToZones(final int finish) {
        if (project == null || busy) return;
        if (markers == null || !hasLabel(false)) { msg("Raya cada parte con su color (pelo, piel, ropa...)"); return; }
        final int W = project.w, H = project.h;
        final byte[] seeds = markers.clone();
        final int[] ref = mangaRef(zoneRefTarget());
        final int[] cols = rayColors.clone();
        final int gap = gapClose;
        final byte[] prot = project.protect != null && project.protect.length == W * H ? project.protect.clone() : null;
        final Project owner = project;
        final java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone> zs = new java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone>();
        final java.util.ArrayList<int[]> locs = new java.util.ArrayList<int[]>();
        setBusy(true);
        showHud("Pintando las partes...");
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    byte[] lineAll = autoBarrier(ref);
                    byte[] lab = Watershed.run(ref, W, H, seeds, gap, BG_LABEL, lineAll, false);
                    for (int L = 1; L < BG_LABEL; L++) {
                        if (cols[L] == 0) continue;
                        byte[] m = new byte[W * H];
                        int n = 0;
                        for (int i = 0; i < m.length; i++)
                            if ((lab[i] & 0xFF) == L && (prot == null || prot[i] == 0)) { m[i] = (byte) 255; n++; }
                        if (n == 0) continue;
                        com.pacco.animecut.core.ZoneTone.feather(m, W, H);
                        com.pacco.animecut.core.ZoneTone.Style st = com.pacco.animecut.core.ZoneTone.easyStyle(cols[L], finish, null);
                        com.pacco.animecut.core.ZoneTone.Zone z = com.pacco.animecut.core.ZoneTone.fromMask(m, W, H, st);
                        if (z == null) continue;
                        int[] loc = com.pacco.animecut.core.ZoneTone.renderLocal(ref, W, H, z);
                        if (loc == null) continue;
                        zs.add(z);
                        locs.add(loc);
                    }
                } catch (OutOfMemoryError e) {
                    zs.clear();
                    locs.clear();
                }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project) return;
                if (zs.isEmpty()) { msg("No se pudo pintar (falta memoria o no hay partes)"); return; }
                boolean[] created = {false};
                undo.setLabel("Rayar partes");
                undo.begin();
                Layer t = ensureToneLayer(created);
                undo.recordZones();
                undo.recordLayer(t, project.fullRect());
                undo.end();
                int[] px = t.px();
                for (int k = 0; k < zs.size(); k++) com.pacco.animecut.core.ZoneTone.paste(locs.get(k), zs.get(k), W, H, px, null);
                project.zones.addAll(zs);
                zoneSel = project.zones.size() - 1;
                project.markDirty();
                clearMarkers();
                if (created[0]) layersChanged();
                pixelsChanged(project.fullRect());
                showHud(zs.size() + " partes pintadas. Deshacer lo quita", 2200);
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    public void setMarkerLabel(int l) {
        markerLabel = Math.max(1, Math.min(LABEL_NAMES.length, l));
    }

    public int getMarkerLabel() {
        return markerLabel;
    }

    public void setGapClose(int g) {
        gapClose = Math.max(0, g);
    }

    public int getGapClose() {
        return gapClose;
    }

    /**
     * v8.69: el tacho borra solo los rayones del color elegido (la cara, el cuello...). Devuelve
     * cuantos pixeles quito. Si de ese color no hay nada, no hace nada (0).
     */
    public int clearMarkersOfCurrent() {
        if (markers == null || project == null) return 0;
        byte v = (byte) markerLabel;
        int W = project.w, n = markers.length, cnt = 0;
        int x0 = W, y0 = project.h, x1 = -1, y1 = -1;
        for (int i = 0; i < n; i++) {
            if (markers[i] != v) continue;
            markers[i] = 0;
            cnt++;
            int x = i % W, y = i / W;
            if (x < x0) x0 = x;
            if (x > x1) x1 = x;
            if (y < y0) y0 = y;
            if (y > y1) y1 = y;
        }
        if (cnt == 0) return 0;
        paintLabelOverlay(markersOverlay, markers, new Rect(x0, y0, x1 + 1, y1 + 1), true);
        dropPreview();
        schedulePreview();
        invalidate();
        return cnt;
    }

    public void clearMarkers() {
        if (markers != null) Arrays.fill(markers, (byte) 0);
        if (markersOverlay != null) markersOverlay.eraseColor(0);
        dropPreview();
        invalidate();
    }

    // ------------------------------------------------------------------
    // Vista previa en vivo de Separar / Quitar fondo: al soltar el dedo se
    // ve cada parte pintada de su color. Se calcula a la mitad del tamano.
    // ------------------------------------------------------------------

    private Bitmap sepPreview;
    private Rect sepPreviewRect;
    private int previewGen;
    private boolean previewBusy, previewAgain;
    private final Paint previewPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    private void dropPreview() {
        previewGen++;
        if (sepPreview != null && !sepPreview.isRecycled()) sepPreview.recycle();
        sepPreview = null;
        sepPreviewRect = null;
    }

    private boolean hasLabel(boolean bg) {
        if (markers == null) return false;
        for (byte b : markers) {
            int v = b & 0xFF;
            if (v == 0) continue;
            if (bg == (v == BG_LABEL)) return true;
        }
        return false;
    }

    /** v8.33: true si se rayo UNA sola parte (sin contar el fondo): esa parte toma solo lo encerrado. */
    private boolean singlePart() {
        if (markers == null) return false;
        int first = 0;
        for (byte b : markers) {
            int v = b & 0xFF;
            if (v == 0 || v == BG_LABEL) continue;
            if (first == 0) first = v;
            else if (v != first) return false;
        }
        return first != 0;
    }

    /** v8.33: lo transparente de la capa es fondo (no se vuelve a "meter" ni une partes). */
    private static void transparentAsBg(byte[] seeds, int[] layerPx, int W, Rect cr, int step, int sw, int sh) {
        for (int y = 0; y < sh; y++)
            for (int x = 0; x < sw; x++) {
                int k = y * sw + x;
                if (seeds[k] != 0) continue;
                int sx = Math.min(cr.right - 1, cr.left + x * step), sy = Math.min(cr.bottom - 1, cr.top + y * step);
                if ((layerPx[sy * W + sx] >>> 24) < 8) seeds[k] = (byte) BG_LABEL;
            }
    }

    /** Zona de trabajo: alrededor de las rayas, o todo si hay fondo marcado. */
    private Rect markerRegion(boolean whole) {
        int w = project.w, h = project.h;
        if (whole) return new Rect(0, 0, w, h);
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (markers[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        if (maxX < 0) return null;
        // Una raya pequena puede representar una pieza larga (brazo, cabello, pierna).
        // Damos bastante aire para que Watershed encuentre los limites reales en vez
        // de cortar la pieza alrededor de la marca.
        int spanX = Math.max(1, maxX - minX + 1), spanY = Math.max(1, maxY - minY + 1);
        int mx = Math.min(Math.max(128, w / 3), Math.max(Math.max(96, w / 6), spanX * 3));
        int my = Math.min(Math.max(128, h / 3), Math.max(Math.max(96, h / 6), spanY * 3));
        return new Rect(Math.max(0, minX - mx), Math.max(0, minY - my),
                Math.min(w, maxX + 1 + mx), Math.min(h, maxY + 1 + my));
    }

    private void schedulePreview() {
        if (project == null || markers == null) return;
        if (!hasLabel(false) && !hasLabel(true)) {
            dropPreview();
            invalidate();
            return;
        }
        if (previewBusy) {
            previewAgain = true;
            return;
        }
        final Rect cr = markerRegion(hasLabel(true));
        if (cr == null) return;
        final int W = project.w;
        final int cw = cr.width(), ch = cr.height();
        // paso: hasta ~1,5 millones de pixeles para que sea rapido
        int st = 1;
        while ((long) (cw / st) * (ch / st) > 1_500_000L) st++;
        final int step = st;
        final int sw = Math.max(1, cw / step), sh = Math.max(1, ch / step);
        final byte[] seeds = new byte[sw * sh];
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int v = 0;
                for (int dy = 0; dy < step && v == 0; dy++)
                    for (int dx = 0; dx < step; dx++) {
                        int sx = cr.left + x * step + dx, sy = cr.top + y * step + dy;
                        if (sx >= cr.right || sy >= cr.bottom) continue;
                        int m = markers[sy * W + sx] & 0xFF;
                        if (m != 0) {
                            v = m;
                            break;
                        }
                    }
                seeds[y * sw + x] = (byte) v;
            }
        }
        final boolean autoBorderBg = !hasLabel(true);
        if (autoBorderBg) {
            for (int x = 0; x < sw; x++) { seeds[x] = (byte) BG_LABEL; seeds[(sh - 1) * sw + x] = (byte) BG_LABEL; }
            for (int y = 0; y < sh; y++) { seeds[y * sw] = (byte) BG_LABEL; seeds[y * sw + sw - 1] = (byte) BG_LABEL; }
        }
        final int[] refAll = project.ref();
        Layer pl = project.activeLayer();
        if (pl != null) {
            try { transparentAsBg(seeds, pl.px(), W, cr, step, sw, sh); } catch (OutOfMemoryError ignored) { }
        }
        final boolean rest = singlePart();
        final int gap = gapClose;
        final int gen = ++previewGen;
        final Bitmap[] out = new Bitmap[1];
        previewBusy = true;
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] lineAll = sepBarrier(refAll);
                int[] small = new int[sw * sh];
                byte[] lc = new byte[sw * sh];
                for (int y = 0; y < sh; y++) {
                    for (int x = 0; x < sw; x++) {
                        int sx = cr.left + x * step, sy = cr.top + y * step;
                        small[y * sw + x] = refAll[sy * W + sx];
                        byte l = 0;
                        for (int dy = 0; dy < step && l == 0; dy++)
                            for (int dx = 0; dx < step; dx++) {
                                int xx = sx + dx, yy = sy + dy;
                                if (xx >= cr.right || yy >= cr.bottom) continue;
                                if (lineAll[yy * W + xx] != 0) {
                                    l = (byte) 255;
                                    break;
                                }
                            }
                        lc[y * sw + x] = l;
                    }
                }
                byte[] lab = Watershed.run(small, sw, sh, seeds, Math.max(1, gap / step), BG_LABEL, lc, rest);
                int[] col = new int[sw * sh];
                for (int i = 0; i < col.length; i++) {
                    int v = lab[i] & 0xFF;
                    // el resto (no se toca) y lo transparente no se tinen: es solo una VISTA PREVIA
                    if (v == 0 || v == Watershed.REST) continue;
                    if ((small[i] >>> 24) < 8 && v == BG_LABEL) continue;
                    int c = labelColor(Math.min(LABEL_COLORS.length, v));
                    int a = v == BG_LABEL ? 0x70 : 0x66;
                    if (v == BG_LABEL) c = 0xFF202020;
                    col[i] = (a << 24) | (c & 0x00FFFFFF);
                }
                Bitmap b = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
                b.setPixels(col, 0, sw, 0, 0, sw, sh);
                out[0] = b;
            }
        }, new Runnable() {
            @Override
            public void run() {
                previewBusy = false;
                if (out[0] != null) {
                    if (gen == previewGen && mode == MODE_MARKER) {
                        if (sepPreview == null) showHud("Vista previa: cada color es una parte (no pinta la imagen)");
                        if (sepPreview != null && !sepPreview.isRecycled()) sepPreview.recycle();
                        sepPreview = out[0];
                        sepPreviewRect = cr;
                        invalidate();
                    } else {
                        out[0].recycle();
                    }
                }
                if (previewAgain) {
                    previewAgain = false;
                    schedulePreview();
                }
            }
        });
    }

    /**
     * Quitar fondo con toques, como en ibis: lo marcado con color se queda,
     * lo marcado en gris (fondo) se borra de la capa. Todo lo que no toca
     * ninguna raya de color cuenta como fondo.
     */
    public void removeBackgroundByMarks() {
        final Layer src = needLayer();
        if (src == null) return;
        if (!hasLabel(false)) {
            msg("Toca o raya el personaje con un color, y el fondo en gris");
            return;
        }
        final int W = project.w, H = project.h;
        final byte[] seeds = markers.clone();
        final int[] refAll = project.ref();
        transparentAsBg(seeds, src.px(), W, project.fullRect(), 1, W, H);
        final boolean rest = singlePart();
        final int gap = gapClose;
        final byte[] keep = new byte[W * H];
        final int[][] edge = new int[1][];
        setBusy(true);
        showHud("Quitando fondo...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] lineAll = sepBarrier(refAll);
                byte[] lab = Watershed.run(refAll, W, H, seeds, gap, BG_LABEL, lineAll, rest);
                for (int i = 0; i < keep.length; i++) {
                    int v = lab[i] & 0xFF;
                    if (v != 0 && v != BG_LABEL) keep[i] = (byte) 255;
                }
                // v8.28: la linea pegada al personaje es del personaje, y el filo sale sin
                // el color del fondo (antes: suavizado de 1 px a ciegas -> media linea y halo)
                try {
                    edge[0] = com.pacco.animecut.core.EdgeMatte.refine(src.px(), W, H, keep, lineAll, 4);
                } catch (OutOfMemoryError oom) {
                    edge[0] = null;
                    MaskOps.feather(keep, W, H, 1);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                undo.setLabel("Quitar fondo");
                undo.recordLayer(src, project.fullRect());
                int[] dp = src.px();
                int[] e = edge[0];
                int[] ea = null;
                if (e != null) {
                    ea = new int[e.length / 2];
                    for (int q = 0; q + 1 < e.length; q += 2) ea[q / 2] = dp[e[q]] >>> 24;
                }
                for (int i = 0; i < dp.length; i++) {
                    int k = keep[i] & 0xFF;
                    if (k == 255) continue;
                    int c = dp[i];
                    int a = ((c >>> 24) * k) / 255;
                    dp[i] = (a << 24) | (c & 0x00FFFFFF);
                }
                if (e != null) {
                    for (int q = 0; q + 1 < e.length; q += 2) {
                        int i = e[q], v = e[q + 1];
                        int na = (ea[q / 2] * (v >>> 24)) / 255;
                        dp[i] = na == 0 ? (dp[i] & 0x00FFFFFF) : (na << 24) | (v & 0x00FFFFFF);
                    }
                }
                clearMarkers();
                project.markDirty();
                refreshDisplay();
                changed();
                showHud("Fondo quitado");
            }
        });
    }

    private byte[] lastLabels;

    /** Cada parte rayada sale en su propia capa, cortada de la capa elegida. */
    public void separateParts() {
        final Layer src = needLayer();
        if (src == null) return;
        boolean any = false;
        if (markers != null) {
            for (byte b : markers) {
                int v = b & 0xFF;
                if (v != 0 && v != BG_LABEL) {
                    any = true;
                    break;
                }
            }
        }
        if (!any) {
            msg("Raya al menos una parte con color, y el fondo en gris");
            return;
        }
        // Region amplia alrededor de las marcas. Si el usuario marco fondo en gris
        // se usa todo el lienzo; si no, el borde del recorte se toma como fondo
        // automatico para que una marca pequena no se convierta en media imagen.
        final boolean hasBg = hasLabel(true);
        final Rect cr = markerRegion(hasBg);
        if (cr == null || cr.isEmpty()) {
            msg("No encontre una zona para separar");
            return;
        }
        int w = project.w, h = project.h;
        setBusy(true);
        showHud("Separando...");
        final int cw = cr.width(), ch = cr.height();
        final byte[] seeds = new byte[cw * ch];
        for (int y = 0; y < ch; y++) System.arraycopy(markers, (cr.top + y) * w + cr.left, seeds, y * cw, cw);
        if (!hasBg) {
            for (int x = 0; x < cw; x++) { seeds[x] = (byte) BG_LABEL; seeds[(ch - 1) * cw + x] = (byte) BG_LABEL; }
            for (int y = 0; y < ch; y++) { seeds[y * cw] = (byte) BG_LABEL; seeds[y * cw + cw - 1] = (byte) BG_LABEL; }
        }
        transparentAsBg(seeds, src.px(), w, cr, 1, cw, ch);
        final boolean rest = singlePart();
        final int gap = gapClose;
        final ArrayList<Layer> made = new ArrayList<Layer>();
        final byte[] cutMask = new byte[cw * ch];
        final int[] refAll = project.ref();
        final int[] sp = src.px();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int W = project.w;
                int[] crop = new int[cw * ch];
                for (int y = 0; y < ch; y++) System.arraycopy(refAll, (cr.top + y) * W + cr.left, crop, y * cw, cw);
                byte[] lineAll = sepBarrier(refAll);
                byte[] lc = new byte[cw * ch];
                for (int y = 0; y < ch; y++) System.arraycopy(lineAll, (cr.top + y) * W + cr.left, lc, y * cw, cw);
                byte[] out = Watershed.run(crop, cw, ch, seeds, gap, BG_LABEL, lc, rest);
                crop = null;
                boolean[] used = new boolean[256];
                for (byte b : seeds) used[b & 0xFF] = true;
                int n = cw * ch;
                for (int lab = 1; lab < BG_LABEL; lab++) {
                    if (!used[lab]) continue;
                    byte[] m = new byte[n];
                    boolean hit = false;
                    for (int i = 0; i < n; i++) {
                        if ((out[i] & 0xFF) == lab) {
                            m[i] = (byte) 255;
                            hit = true;
                        }
                    }
                    if (!hit) continue;
                    MaskOps.feather(m, cw, ch, 1);
                    int[] px = new int[n];
                    for (int y = 0; y < ch; y++) {
                        for (int x = 0; x < cw; x++) {
                            int i = y * cw + x;
                            int mv = m[i] & 0xFF;
                            if (mv == 0) continue;
                            int c = sp[(cr.top + y) * W + cr.left + x];
                            int a = ((c >>> 24) * mv) / 255;
                            if (a != 0) px[i] = (a << 24) | (c & 0x00FFFFFF);
                            if (mv > (cutMask[i] & 0xFF)) cutMask[i] = (byte) mv;
                        }
                    }
                    String nm = lab - 1 < LABEL_NAMES.length ? LABEL_NAMES[lab - 1] : "parte_" + lab;
                    made.add(Layer.fromCrop(nm, cr.left, cr.top, cw, ch, project.w, project.h, px));
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (made.isEmpty()) {
                    msg("No salio ninguna parte. Raya dentro de cada parte y el fondo en gris");
                    return;
                }
                // las partes se sacan de la capa original, que sigue visible con el resto
                undo.setLabel("Separar");
                undo.begin();
                undo.recordStruct();
                undo.recordLayer(src, cr);
                undo.end();
                int[] dp = src.px();
                int W = project.w;
                for (int y = 0; y < ch; y++) {
                    for (int x = 0; x < cw; x++) {
                        int mv = cutMask[y * cw + x] & 0xFF;
                        if (mv == 0) continue;
                        int i = (cr.top + y) * W + cr.left + x;
                        int c = dp[i];
                        int a = ((c >>> 24) * (255 - mv)) / 255;
                        dp[i] = (a << 24) | (c & 0x00FFFFFF);
                    }
                }
                int at = project.layers.indexOf(src) + 1;
                for (Layer l : made) project.layers.add(at++, l);
                project.active = at - 1;
                if (markers != null) java.util.Arrays.fill(markers, (byte) 0);
                if (markersOverlay != null) markersOverlay.eraseColor(0);
                dropPreview();
                project.markDirty();
                layersChanged();
                showHud(made.size() + (made.size() == 1 ? " parte separada" : " partes separadas")
                        + ". El resto sigue en la capa original");
            }
        });
    }

    // ==================================================================
    // Rehacer lo que queda detras (dentro de la seleccion)
    // ==================================================================

    /** Lo que hay que rehacer es lo azul, un poco agrandado. */
    private byte[] holeMask() {
        if (project == null || !project.hasSelection()) return null;
        byte[] m = new byte[project.w * project.h];
        for (int i = 0; i < m.length; i++) m[i] = (byte) ((project.selection[i] & 0xFF) > 64 ? 255 : 0);
        MaskOps.dilate(m, project.w, project.h, 2);
        return m;
    }

    private boolean needHole() {
        if (project.hasSelection()) return true;
        msg("Primero marca en azul lo que hay que rehacer (con la varita o el pincel)");
        return false;
    }

    /** Tapar hueco rapido: lo azul toma el color de alrededor. */
    public void fillHoleInSelection() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final Rect b = project.selectionBounds();
        final Rect area = new Rect(b);
        area.inset(-27, -27);
        clamp(area);
        undo.setLabel("Tapar hueco");
        undo.recordLayer(t, area);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                HoleFill.fill(t.px(), project.w, project.h, project.selection, 3);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                pixelsChanged(area);
                showHud("Hueco tapado");
            }
        });
    }

    private void runZoneFill(final int x, final int y) {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        undo.setLabel("Zona");
        undo.recordLayer(t, hb);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = ZoneFill.fill(t.px(), project.w, project.h, hole, repairLines, x, y);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect == null) msg("Toca dentro de lo azul");
                else pixelsChanged(lastFillRect);
            }
        });
    }

    private void runToneFill(final int x, final int y) {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        undo.setLabel("Trama");
        undo.recordLayer(t, hb);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = ToneFill.fill(t.px(), project.w, project.h, hole, x, y);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect == null) msg("Toca afuera de lo azul, sobre la trama que quieres seguir");
                else {
                    pixelsChanged(lastFillRect);
                    showHud("Trama continuada");
                }
            }
        });
    }

    private void ensureRepairLines() {
        int n = project.w * project.h;
        if (repairLines == null || repairLines.length != n) repairLines = new byte[n];
    }

    private void finishLine() {
        Layer t = needLayer();
        if (t == null || linePts.size() < 2) {
            linePts.clear();
            invalidate();
            return;
        }
        byte[] hole = holeMask();
        float[] a = linePts.get(0), b = linePts.get(linePts.size() - 1);
        float[] a2 = linePts.get(Math.min(linePts.size() - 1, 3)), b2 = linePts.get(Math.max(0, linePts.size() - 4));
        LineRepair.End ea = LineRepair.snap(t.px(), project.w, project.h, hole, a[0], a[1], a2[0] - a[0], a2[1] - a[1], 28);
        LineRepair.End eb = LineRepair.snap(t.px(), project.w, project.h, hole, b[0], b[1], b[0] - b2[0], b[1] - b2[1], 28);
        float[] xy = new float[linePts.size() * 2];
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -1, maxY = -1;
        for (int i = 0; i < linePts.size(); i++) {
            float[] q = linePts.get(i);
            xy[i * 2] = q[0];
            xy[i * 2 + 1] = q[1];
            minX = Math.min(minX, q[0]);
            minY = Math.min(minY, q[1]);
            maxX = Math.max(maxX, q[0]);
            maxY = Math.max(maxY, q[1]);
        }
        Rect guard = new Rect((int) Math.min(minX, Math.min(ea.x, eb.x)) - 40, (int) Math.min(minY, Math.min(ea.y, eb.y)) - 40,
                (int) Math.max(maxX, Math.max(ea.x, eb.x)) + 40, (int) Math.max(maxY, Math.max(ea.y, eb.y)) + 40);
        clamp(guard);
        linePts.clear();
        ensureRepairLines();
        undo.setLabel("Linea");
        undo.recordLayer(t, guard);
        Rect r = LineRepair.drawCurve(t.px(), project.w, project.h, repairLines, ea, eb, xy);
        if (r != null) pixelsChanged(r);
        showHud(ea.snapped && eb.snapped ? "Linea unida" : "Linea dibujada");
    }

    public void autoJoinLines() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        ensureRepairLines();
        final Rect guard = HoleFill.bounds(hole, project.w, project.h);
        if (guard == null) return;
        guard.inset(-12, -12);
        clamp(guard);
        undo.setLabel("Unir lineas");
        undo.recordLayer(t, guard);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = LineRepair.autoJoin(t.px(), project.w, project.h, hole, repairLines);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    pixelsChanged(lastFillRect);
                    showHud("Lineas unidas");
                } else {
                    showHud("No encontre lineas para unir: trazalas con el dedo");
                }
            }
        });
    }

    // ==================================================================
    // Transformar: previsualizacion ligera y aplicacion al confirmar.
    // ==================================================================

    private boolean onTransformTouch(MotionEvent e) {
        if (project == null || busy || transformPreparing) return true;
        int a = e.getActionMasked(), pc = e.getPointerCount();
        if (!transformActive && a == MotionEvent.ACTION_DOWN) {
            if (!startTransformSession()) return true;
        }
        if (!transformActive) return true;
        if (transformType == 4) return onPuppetTouch(e, a, pc);

        // Perspectiva y Malla: DOS dedos pertenecen siempre a la vista,
        // nunca a la deformacion. Zoom con ScaleGestureDetector + pan por el centro.
        if (transformType != 0 && pc >= 2) {
            // Si el primer dedo ya habia empezado a mover un nodo, se devuelve a
            // donde estaba: el zoom nunca deforma por accidente.
            if (transformNode >= 0 && transformVertsStart != null && transformVerts != null
                    && transformVertsStart.length == transformVerts.length) {
                System.arraycopy(transformVertsStart, 0, transformVerts, 0, transformVerts.length);
                transformRenderDirty = true;
                if (meshDragStarted && !meshUndo.isEmpty()) meshUndo.remove(meshUndo.size() - 1);
            }
            meshDragStarted = false;
            // Puntos de anclaje: lo que puso o movio el primer dedo se devuelve.
            if (transformType == 3 && anchorGesturePushed && !anchorUndo.isEmpty()) {
                ArrayList<float[]> st = anchorUndo.remove(anchorUndo.size() - 1);
                transformAnchors.clear();
                transformAnchors.addAll(st);
                transformAnchorNode = -1;
                transformRenderDirty = true;
            }
            anchorGesturePushed = false;
            transformNode = -1;
            // La seleccion de un anclaje persiste: asi el tacho funciona despues
            // de tocar el punto y luego levantar el dedo.
            transformTwoFingerNav(e, a);   // v8.61: tambien gira
            return true;
        }
        if (a == MotionEvent.ACTION_POINTER_UP && transformType != 0) {
            scaleDetector.onTouchEvent(e);
            transformNavMidValid = false;
            transformNode = -1;
            invalidate();
            return true;
        }

        if (a == MotionEvent.ACTION_DOWN) {
            transformNavMidValid = false;
            imagePoint(e.getX(), e.getY());
            transformDownX = point[0]; transformDownY = point[1];
            transformStartTx = transformTx; transformStartTy = transformTy;
            transformNode = -1;

            if (transformType == 3) {
                transformAnchorNode = -1;
                anchorDragStarted = false;
                int undoBefore = anchorUndo.size();
                int found = findTransformAnchor(transformDownX, transformDownY);
                if (found >= 0) {
                    transformAnchorNode = found;
                    showHud(transformAnchors.get(found)[4] < .5f ? "Punto fijo seleccionado" : "Arrastra el punto naranja");
                } else {
                    addTransformAnchor(transformDownX, transformDownY);
                }
                anchorGesturePushed = anchorUndo.size() > undoBefore;
                invalidate();
                return true;
            }

            if (transformType != 0 && transformVerts != null) {
                // Radio de toque en pixeles de pantalla (34 dp), no de imagen.
                float lim = 34f * getResources().getDisplayMetrics().density / Math.max(.05f, currentScale());
                float best = lim * lim;
                for (int i = 0; i < transformVerts.length / 2; i++) {
                    float dx = transformVerts[i * 2] - transformDownX;
                    float dy = transformVerts[i * 2 + 1] - transformDownY;
                    float dd = dx * dx + dy * dy;
                    if (dd <= best) { best = dd; transformNode = i; }
                }
                transformVertsStart = transformVerts.clone();
                meshDragStarted = false;
                meshLimitedHud = false;
                if (transformNode >= 0) {
                    meshNodeStartX = transformVerts[transformNode * 2];
                    meshNodeStartY = transformVerts[transformNode * 2 + 1];
                    if (transformType == 2) meshFoldBase = countMeshFolds();
                }
            }
            invalidate();
            return true;
        }

        if (a == MotionEvent.ACTION_POINTER_DOWN && transformType == 0 && pc >= 2) {
            screenToImage(e.getX(0), e.getY(0), transformPoint0);
            screenToImage(e.getX(1), e.getY(1), transformPoint1);
            transformGestureDist = Math.max(.001f, (float) Math.hypot(transformPoint1[0] - transformPoint0[0], transformPoint1[1] - transformPoint0[1]));
            transformGestureAngle = (float) Math.toDegrees(Math.atan2(transformPoint1[1] - transformPoint0[1], transformPoint1[0] - transformPoint0[0]));
            transformGestureMidX = (transformPoint0[0] + transformPoint1[0]) * .5f;
            transformGestureMidY = (transformPoint0[1] + transformPoint1[1]) * .5f;
            transformStartScale = transformScale;
            transformStartRotation = transformRotation;
            transformGestureStartTx = transformTx;
            transformGestureStartTy = transformTy;
            return true;
        }

        if (a == MotionEvent.ACTION_MOVE) {
            if (transformType == 0 && pc >= 2) {
                screenToImage(e.getX(0), e.getY(0), transformPoint0);
                screenToImage(e.getX(1), e.getY(1), transformPoint1);
                float dist = Math.max(.001f, (float) Math.hypot(transformPoint1[0] - transformPoint0[0], transformPoint1[1] - transformPoint0[1]));
                float ang = (float) Math.toDegrees(Math.atan2(transformPoint1[1] - transformPoint0[1], transformPoint1[0] - transformPoint0[0]));
                float midX = (transformPoint0[0] + transformPoint1[0]) * .5f, midY = (transformPoint0[1] + transformPoint1[1]) * .5f;
                transformScale = Math.max(.05f, Math.min(12f, transformStartScale * dist / transformGestureDist));
                float da = ang - transformGestureAngle;
                while (da > 180f) da -= 360f;
                while (da < -180f) da += 360f;
                transformRotation = transformStartRotation + da;
                transformTx = transformGestureStartTx + (midX - transformGestureMidX);
                transformTy = transformGestureStartTy + (midY - transformGestureMidY);
                invalidate();
                return true;
            }

            imagePoint(e.getX(), e.getY());
            float x = point[0], y = point[1];
            if (transformType == 0) {
                transformTx = transformStartTx + (x - transformDownX);
                transformTy = transformStartTy + (y - transformDownY);
            } else if (transformType == 3) {
                if (transformAnchorNode >= 0 && transformAnchorNode < transformAnchors.size()) {
                    float[] an = transformAnchors.get(transformAnchorNode);
                    if (an[4] >= .5f) {
                        if (!anchorDragStarted) { pushAnchorHistory(); anchorDragStarted = true; anchorGesturePushed = true; }
                        an[2] = x; an[3] = y;
                        transformRenderDirty = true;
                    }
                }
            } else if (transformVerts != null) {
                if (transformNode >= 0 && transformType == 2) {
                    moveMeshNode(x, y);
                } else if (transformNode >= 0) {
                    transformVerts[transformNode * 2] = x;
                    transformVerts[transformNode * 2 + 1] = y;
                    transformRenderDirty = true;
                }
            }
            invalidate();
            return true;
        }

        if (a == MotionEvent.ACTION_POINTER_UP) {
            transformNode = -1;
            transformStartTx = transformTx; transformStartTy = transformTy;
            int up = e.getActionIndex();
            int keep = up == 0 && pc > 1 ? 1 : 0;
            if (keep < pc) {
                screenToImage(e.getX(keep), e.getY(keep), transformPoint0);
                transformDownX = transformPoint0[0]; transformDownY = transformPoint0[1];
            }
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            transformNode = -1;
            meshDragStarted = false;
            transformVertsStart = null;
            transformNavMidValid = false;
            invalidate();
            return true;
        }
        return true;
    }

    private void screenToImage(float sx, float sy, float[] out) {
        imagePoint(sx, sy);
        out[0] = point[0];
        out[1] = point[1];
    }

    private int[] copyLayerRect(Layer layer, Rect r) {
        int rw = r.width(), rh = r.height();
        int[] out = new int[rw * rh];
        int[] src = layer.px();
        for (int y = 0; y < rh; y++)
            System.arraycopy(src, (r.top + y) * project.w + r.left, out, y * rw, rw);
        return out;
    }

    private byte[] copySelectionRect(Rect r) {
        int rw = r.width(), rh = r.height();
        byte[] out = new byte[rw * rh];
        for (int y = 0; y < rh; y++)
            System.arraycopy(project.selection, (r.top + y) * project.w + r.left, out, y * rw, rw);
        return out;
    }

    private void restoreLayerRect(Layer layer, Rect r, int[] src) {
        if (layer == null || r == null || src == null || src.length != r.width() * r.height()) return;
        int rw = r.width(), rh = r.height();
        int[] dst = layer.px();
        for (int y = 0; y < rh; y++)
            System.arraycopy(src, y * rw, dst, (r.top + y) * project.w + r.left, rw);
    }

    private void restoreSelectionRect(Rect r, byte[] src) {
        if (r == null || src == null || src.length != r.width() * r.height()) return;
        int rw = r.width(), rh = r.height();
        for (int y = 0; y < rh; y++)
            System.arraycopy(src, y * rw, project.selection, (r.top + y) * project.w + r.left, rw);
    }

    /** Devuelve exactamente el original que se aparto al iniciar Transformar. */
    private void restoreTransformSourceToProject() {
        if (transformLayer == null || transformSrcRect == null) return;
        if (transformBackup != null) {
            restoreLayerRect(transformLayer, transformSrcRect, transformBackup);
        } else if (transformBitmap != null && !transformBitmap.isRecycled()) {
            int[] lp = transformLayer.px();
            // getPixels puede escribir directo en el arreglo grande: no crea otra copia.
            transformBitmap.getPixels(lp, transformSrcRect.top * project.w + transformSrcRect.left,
                    project.w, 0, 0, transformSrcRect.width(), transformSrcRect.height());
        }
        if (transformSelectionBackup != null) restoreSelectionRect(transformSrcRect, transformSelectionBackup);
    }

    /** Libera buffers reutilizables que no hacen falta mientras se transforma. */
    private void releaseTransientMemoryForTransform() {
        pxBackup = null;
        cov = null;
        scratch = null;
        selBackup = null;
        gapBarrier = null;
        gradient = null;
        effectTmp = null;
        resetLiquifySession();
        bgSeen = null;
        bgStack = null;
        dilMask = null;
        try { project.packInactive(); } catch (OutOfMemoryError ignored) {}
    }

    private boolean startTransformSession() {
        if (transformApplying) return false;
        Layer t = needLayer();
        if (t == null) return false;
        Rect r = project.hasSelection() ? project.selectionBounds() : t.bounds(project.w, project.h);
        if (r == null || r.width() <= 0 || r.height() <= 0) {
            msg(project.hasSelection() ? "La seleccion esta vacia" : "La capa no tiene dibujo para transformar");
            return false;
        }

        releaseTransientMemoryForTransform();
        transformLayer = t;
        transformSrcRect = new Rect(r);
        boolean sel = project.hasSelection();
        try {
            int cw = r.width(), ch = r.height();
            int[] lp = t.px();

            // Solo guardamos el recorte original cuando hay seleccion. Sin seleccion,
            // el propio Bitmap de Transformar ES el respaldo original y evitamos otra
            // copia completa de la imagen.
            transformBackup = sel ? copyLayerRect(t, r) : null;
            transformSelectionBackup = sel ? copySelectionRect(r) : null;

            // Este Bitmap SI se dibuja con Canvas: debe quedar premultiplicado.
            // Usar Layer.newBitmap() aqui lo marcaba como no premultiplicado y en
            // algunos Android Canvas puede lanzar RuntimeException al dibujarlo.
            transformBitmap = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888);
            if (sel) {
                transformMaskBitmap = Bitmap.createBitmap(cw, ch, Bitmap.Config.ALPHA_8);
            } else {
                transformMaskBitmap = null;
            }

            // Construimos primero los Bitmaps. La capa real todavia no se toca: si
            // una asignacion falla, la obra permanece intacta.
            if (!sel) {
                // Copia nativa directa: es mucho mas rapida que recorrer millones
                // de pixeles Java uno por uno y reduce el tiempo bloqueado al tocar.
                transformBitmap.setPixels(lp, r.top * project.w + r.left, project.w,
                        0, 0, cw, ch);
            } else {
                int[] row = new int[cw];
                int[] maskRow = new int[cw];
                for (int y = 0; y < ch; y++) {
                    int src = (r.top + y) * project.w + r.left;
                    int bo = y * cw;
                    for (int x = 0; x < cw; x++) {
                        int c = lp[src + x];
                        int m = transformSelectionBackup[bo + x] & 255;
                        int a = (c >>> 24) * m / 255;
                        row[x] = (c & 0x00FFFFFF) | (a << 24);
                        maskRow[x] = m << 24;
                    }
                    transformBitmap.setPixels(row, 0, cw, 0, y, cw, 1);
                    transformMaskBitmap.setPixels(maskRow, 0, cw, 0, y, cw, 1);
                }
            }

            // Ahora si: apartamos del lienzo SOLO la parte transformada. El respaldo
            // es regional, no project.w*project.h.
            for (int y = 0; y < ch; y++) {
                int dst = (r.top + y) * project.w + r.left;
                int bo = y * cw;
                if (!sel) {
                    Arrays.fill(lp, dst, dst + cw, 0);
                } else {
                    for (int x = 0; x < cw; x++) {
                        int c = transformBackup[bo + x];
                        int m = transformSelectionBackup[bo + x] & 255;
                        int remainA = (c >>> 24) * (255 - m) / 255;
                        lp[dst + x] = (c & 0x00FFFFFF) | (remainA << 24);
                        project.selection[dst + x] = 0;
                    }
                }
            }

            transformTx = transformTy = transformRotation = 0f;
            transformScale = 1f;
            initTransformVerts();
            transformActive = true;
            transformPreparing = false;
            updateDisplayRegion(r);
            if (sel) paintOverlay(r);
            showHud(transformType == 0 ? "Arrastra. Dos dedos: escala y gira" :
                    transformType == 1 ? "Perspectiva: 1 dedo esquinas · 2 dedos mover/zoom" :
                    transformType == 2 ? "Malla: 1 dedo nodos · 2 dedos mover/zoom" :
                    transformType == 3 ? "Puntos: azul fija · naranja mueve · 2 dedos mover/zoom" :
                    "Marioneta: toca para poner puntos · 2 dedos mover/zoom");
            meshUndo.clear(); meshRedo.clear();
            if (transformType == 4) startPuppet();
            invalidate();
            return true;
        } catch (Throwable e) {
            // Cualquier fallo de Bitmap/Canvas/memoria debe cancelar la sesion, no
            // cerrar el editor ni mandar al usuario de vuelta a la galeria.
            try { restoreTransformSourceToProject(); } catch (Throwable ignored) {}
            transformPreparing = false;
            clearTransformState(true);
            try { project.packInactive(); } catch (Throwable ignored) {}
            if (undo != null) undo.trimTo(0.55f);
            if (e instanceof OutOfMemoryError) System.gc();
            refreshDisplay();
            refreshOverlay(null);
            msg(e instanceof OutOfMemoryError
                    ? "Transformar libero memoria y cancelo la operacion sin perder la imagen. Prueba otra vez."
                    : "Transformar encontro un fallo y se cancelo sin cerrar el editor ni perder la imagen.");
            return false;
        }
    }

    private void initTransformVerts() {
        if (transformSrcRect == null) { transformVerts = null; return; }
        if (transformType == 0 || transformType == 3 || transformType == 4) { transformVerts = null; transformRenderDirty = true; return; }
        int cols = transformType == 1 ? 1 : transformMeshX;
        int rows = transformType == 1 ? 1 : transformMeshY;
        transformVerts = new float[(cols + 1) * (rows + 1) * 2];
        int k = 0;
        for (int y = 0; y <= rows; y++) {
            float py = transformSrcRect.top + transformSrcRect.height() * (y / (float) rows);
            for (int x = 0; x <= cols; x++) {
                float px = transformSrcRect.left + transformSrcRect.width() * (x / (float) cols);
                transformVerts[k++] = px;
                transformVerts[k++] = py;
            }
        }
        transformRenderDirty = true;
    }

    private void drawTransformPreparing(Canvas c) {
        if (transformSrcRect == null || transformType != 2) return;
        int save = c.save();
        c.concat(view);
        if (transformVerts == null) initTransformVerts();
        if (transformVerts != null) drawMeshGrid(c, transformMeshX, transformMeshY);
        c.restoreToCount(save);
    }

    private float controlDispX(int gx, int gy) {
        gx = Math.max(0, Math.min(transformMeshX, gx)); gy = Math.max(0, Math.min(transformMeshY, gy));
        int i = (gy * (transformMeshX + 1) + gx) * 2;
        float ox = transformSrcRect.left + transformSrcRect.width() * (gx / (float) transformMeshX);
        return transformVerts[i] - ox;
    }

    private float controlDispY(int gx, int gy) {
        gx = Math.max(0, Math.min(transformMeshX, gx)); gy = Math.max(0, Math.min(transformMeshY, gy));
        int i = (gy * (transformMeshX + 1) + gx) * 2 + 1;
        float oy = transformSrcRect.top + transformSrcRect.height() * (gy / (float) transformMeshY);
        return transformVerts[i] - oy;
    }

    private static float catmull(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t, t3 = t2 * t;
        return .5f * ((2f * p1) + (-p0 + p2) * t +
                (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 +
                (-p0 + 3f * p1 - 3f * p2 + p3) * t3);
    }

    private void sampleTransformDisp(float u, float v, float[] out) {
        float x = Math.max(0f, Math.min(transformMeshX, u * transformMeshX));
        float y = Math.max(0f, Math.min(transformMeshY, v * transformMeshY));
        int ix = Math.min(transformMeshX - 1, (int)Math.floor(x));
        int iy = Math.min(transformMeshY - 1, (int)Math.floor(y));
        float fx = x - ix, fy = y - iy;

        float d00x = controlDispX(ix, iy), d10x = controlDispX(ix + 1, iy);
        float d01x = controlDispX(ix, iy + 1), d11x = controlDispX(ix + 1, iy + 1);
        float d00y = controlDispY(ix, iy), d10y = controlDispY(ix + 1, iy);
        float d01y = controlDispY(ix, iy + 1), d11y = controlDispY(ix + 1, iy + 1);
        float bilX = (d00x + (d10x - d00x) * fx) * (1f - fy) + (d01x + (d11x - d01x) * fx) * fy;
        float bilY = (d00y + (d10y - d00y) * fx) * (1f - fy) + (d01y + (d11y - d01y) * fx) * fy;

        float[] rx = transformCatX, ry = transformCatY;
        for (int yy = -1; yy <= 2; yy++) {
            float p0x = controlDispX(ix - 1, iy + yy), p1x = controlDispX(ix, iy + yy);
            float p2x = controlDispX(ix + 1, iy + yy), p3x = controlDispX(ix + 2, iy + yy);
            float p0y = controlDispY(ix - 1, iy + yy), p1y = controlDispY(ix, iy + yy);
            float p2y = controlDispY(ix + 1, iy + yy), p3y = controlDispY(ix + 2, iy + yy);
            rx[yy + 1] = catmull(p0x, p1x, p2x, p3x, fx);
            ry[yy + 1] = catmull(p0y, p1y, p2y, p3y, fx);
        }
        float bicX = catmull(rx[0], rx[1], rx[2], rx[3], fy);
        float bicY = catmull(ry[0], ry[1], ry[2], ry[3], fy);
        float sm = Math.max(0f, Math.min(1f, transformMeshSmoothness));
        float dx = bilX + (bicX - bilX) * sm;
        float dy = bilY + (bicY - bilY) * sm;
        // Catmull-Rom puede sobrepasar. Limitar respecto a los cuatro controles
        // vecinos evita celdas que se disparan y dobleces violentos.
        float minX = Math.min(Math.min(d00x, d10x), Math.min(d01x, d11x));
        float maxX = Math.max(Math.max(d00x, d10x), Math.max(d01x, d11x));
        float minY = Math.min(Math.min(d00y, d10y), Math.min(d01y, d11y));
        float maxY = Math.max(Math.max(d00y, d10y), Math.max(d01y, d11y));
        float pad = Math.max(2f, Math.max(transformSrcRect.width(), transformSrcRect.height()) * .01f * sm);
        out[0] = Math.max(minX - pad, Math.min(maxX + pad, dx));
        out[1] = Math.max(minY - pad, Math.min(maxY + pad, dy));
    }

    private final float[] transformDispSample = new float[2];
    private final float[] transformCatX = new float[4];
    private final float[] transformCatY = new float[4];

    /** Control visible poco denso + malla interna densa y suave. */
    private void ensureTransformRenderVerts() {
        if ((transformType != 2 && transformType != 3) || transformSrcRect == null) return;
        if (transformType == 2 && transformVerts == null) return;
        // Malla interna (la de la vista previa y la del resultado final).
        int rx = transformType == 3 ? Math.min(20, Math.max(8, transformMeshX * 2))
                : Math.min(48, Math.max(18, transformMeshX * 6));
        int ry = transformType == 3 ? Math.min(20, Math.max(8, transformMeshY * 2))
                : Math.min(48, Math.max(18, transformMeshY * 6));
        int need = (rx + 1) * (ry + 1) * 2;
        if (!transformRenderDirty && transformRenderVerts != null && transformRenderVerts.length == need &&
                transformRenderMeshX == rx && transformRenderMeshY == ry) return;
        if (transformRenderVerts == null || transformRenderVerts.length != need) transformRenderVerts = new float[need];
        transformRenderMeshX = rx; transformRenderMeshY = ry;
        int k = 0;
        for (int y = 0; y <= ry; y++) {
            float v = y / (float)ry;
            float oy = transformSrcRect.top + transformSrcRect.height() * v;
            for (int x = 0; x <= rx; x++) {
                float u = x / (float)rx;
                float ox = transformSrcRect.left + transformSrcRect.width() * u;
                if (transformType == 3) sampleAnchorDisp(ox, oy, transformDispSample);
                else sampleTransformDisp(u, v, transformDispSample);
                transformRenderVerts[k++] = ox + transformDispSample[0];
                transformRenderVerts[k++] = oy + transformDispSample[1];
            }
        }
        transformRenderDirty = false;
    }

    // ==================================================================
    // Puntos de anclaje (Transformar): igual que v8.24, restaurado en v8.25
    // ==================================================================

    private static ArrayList<float[]> copyAnchors(ArrayList<float[]> a) {
        ArrayList<float[]> c = new ArrayList<float[]>();
        for (float[] x : a) c.add(x.clone());
        return c;
    }

    private void pushAnchorHistory() {
        anchorUndo.add(copyAnchors(transformAnchors));
        if (anchorUndo.size() > 60) anchorUndo.remove(0);
        anchorRedo.clear();
    }

    private void sampleAnchorDisp(float x, float y, float[] out) {
        out[0] = out[1] = 0f;
        if (transformAnchors.isEmpty()) return;
        float numX = 0f, numY = 0f, den = 0f;
        float radius = Math.max(24f, transformAnchorRadius);
        float r2 = radius * radius;
        for (int i = 0; i < transformAnchors.size(); i++) {
            float[] a = transformAnchors.get(i);
            float dx = x - a[0], dy = y - a[1];
            float d2 = dx * dx + dy * dy;
            if (d2 > r2 * 4f) continue;
            float dist = (float)Math.sqrt(Math.max(.0001f, d2));
            float q = Math.max(0f, 1f - dist / (radius * 2f));
            float w = (q * q + .0005f) / (d2 + 36f);
            if (a[4] < .5f) w *= 5.5f; // fijo: fuerte peso con desplazamiento cero
            float ddx = a[4] >= .5f ? (a[2] - a[0]) * transformAnchorStrength : 0f;
            float ddy = a[4] >= .5f ? (a[3] - a[1]) * transformAnchorStrength : 0f;
            numX += ddx * w; numY += ddy * w; den += w;
        }
        if (den > .000001f) { out[0] = numX / den; out[1] = numY / den; }
    }

    private void drawTransformAnchors(Canvas c) {
        if (transformSrcRect == null) return;
        float sc = Math.max(.05f, currentScale());
        float rr = 7f / sc;
        float rrSel = 10f / sc;
        transformAnchorEdgePaint.setStrokeWidth(2f / sc);
        for (int i = 0; i < transformAnchors.size(); i++) {
            float[] a = transformAnchors.get(i);
            Paint fill = a[4] < .5f ? transformAnchorFixedPaint : transformAnchorMovePaint;
            c.drawCircle(a[2], a[3], i == transformAnchorNode ? rrSel : rr, fill);
            c.drawCircle(a[2], a[3], i == transformAnchorNode ? rrSel : rr, transformAnchorEdgePaint);
            if (i == transformAnchorNode && a[4] >= .5f
                    && (Math.abs(a[2]-a[0]) + Math.abs(a[3]-a[1]) > .1f)) {
                c.drawLine(a[0], a[1], a[2], a[3], transformAnchorEdgePaint);
            }
        }
    }

    private int findTransformAnchor(float x, float y) {
        float lim = 28f / Math.max(.05f, currentScale());
        float best = lim * lim; int idx = -1;
        for (int i = 0; i < transformAnchors.size(); i++) {
            float[] a = transformAnchors.get(i);
            float dx = a[2] - x, dy = a[3] - y, d = dx*dx + dy*dy;
            if (d <= best) { best = d; idx = i; }
        }
        return idx;
    }

    private void addTransformAnchor(float x, float y) {
        if (transformSrcRect == null || !transformSrcRect.contains((int)x, (int)y)) {
            showHud("Pon el punto dentro de la imagen"); return;
        }
        pushAnchorHistory();
        transformAnchors.add(new float[]{x, y, x, y, transformAnchorAddMode});
        transformAnchorNode = transformAnchors.size() - 1;
        transformRenderDirty = true;
        showHud(transformAnchorAddMode == 0 ? "Punto fijo azul" : "Punto movil naranja");
    }

    public void setTransformAnchorAddMode(int mode) {
        transformAnchorAddMode = mode <= 0 ? 0 : 1;
        showHud(transformAnchorAddMode == 0 ? "Toca para poner punto fijo" : "Toca para poner punto movil");
        invalidate();
    }
    public int getTransformAnchorAddMode() { return transformAnchorAddMode; }
    public int getTransformAnchorCount() { return transformAnchors.size(); }
    public void deleteSelectedTransformAnchor() {
        if (transformAnchorNode >= 0 && transformAnchorNode < transformAnchors.size()) {
            pushAnchorHistory();
            transformAnchors.remove(transformAnchorNode); transformAnchorNode = -1; transformRenderDirty = true; invalidate();
            showHud("Punto eliminado");
        } else showHud("Toca un punto primero");
    }
    public void clearTransformAnchors() { pushAnchorHistory(); transformAnchors.clear(); transformAnchorNode = -1; transformRenderDirty = true; invalidate(); showHud("Puntos borrados"); }
    public void setTransformAnchorRadius(float v) { transformAnchorRadius = Math.max(40f, Math.min(900f, v)); transformRenderDirty = true; invalidate(); }
    public float getTransformAnchorRadius() { return transformAnchorRadius; }

    // ==================================================================
    // Malla (v8.25): control real de pliegues en lugar del limite de vecinos
    // ==================================================================

    /** Triangulos invertidos o aplastados de la malla interna (la que se dibuja y se aplica). */
    private int countMeshFolds() {
        ensureTransformRenderVerts();
        float[] v = transformRenderVerts;
        if (v == null) return 0;
        int rx = transformRenderMeshX, ry = transformRenderMeshY, cols = rx + 1, n = 0;
        for (int y = 0; y < ry; y++) {
            for (int x = 0; x < rx; x++) {
                int tl = y * cols + x, tr = tl + 1, bl = tl + cols, br = bl + 1;
                if (triArea2(v, tl, tr, br) <= 0f) n++;
                if (triArea2(v, tl, br, bl) <= 0f) n++;
            }
        }
        return n;
    }

    private static float triArea2(float[] v, int a, int b, int c) {
        float bx = v[b * 2] - v[a * 2], by = v[b * 2 + 1] - v[a * 2 + 1];
        float cx = v[c * 2] - v[a * 2], cy = v[c * 2 + 1] - v[a * 2 + 1];
        return bx * cy - by * cx;
    }

    /**
     * Mueve el nodo de Malla elegido. El nodo sigue al dedo SIN saltar (se
     * conserva la distancia del toque) y puede ir tan lejos como quieras: solo
     * se detiene si la malla se doblaria sobre si misma (triangulo invertido).
     */
    private void moveMeshNode(float x, float y) {
        int i = transformNode;
        float tx = meshNodeStartX + (x - transformDownX), ty = meshNodeStartY + (y - transformDownY);
        if (!meshDragStarted) {
            if (Math.abs(tx - meshNodeStartX) + Math.abs(ty - meshNodeStartY) < .5f) return;
            meshUndo.add(transformVertsStart != null ? transformVertsStart.clone() : transformVerts.clone());
            if (meshUndo.size() > 60) meshUndo.remove(0);
            meshRedo.clear();
            meshDragStarted = true;
        }
        float px = transformVerts[i * 2], py = transformVerts[i * 2 + 1];
        transformVerts[i * 2] = tx;
        transformVerts[i * 2 + 1] = ty;
        transformRenderDirty = true;
        if (countMeshFolds() <= meshFoldBase) return;
        float lo = 0f, hi = 1f;
        for (int it = 0; it < 7; it++) {
            float mid = (lo + hi) * .5f;
            transformVerts[i * 2] = px + (tx - px) * mid;
            transformVerts[i * 2 + 1] = py + (ty - py) * mid;
            transformRenderDirty = true;
            if (countMeshFolds() <= meshFoldBase) lo = mid; else hi = mid;
        }
        transformVerts[i * 2] = px + (tx - px) * lo;
        transformVerts[i * 2 + 1] = py + (ty - py) * lo;
        transformRenderDirty = true;
        if (!meshLimitedHud) {
            meshLimitedHud = true;
            showHud("Tope: mas alla la malla se doblaria sobre si misma");
        }
    }

    /** Vuelve la cuadricula de Malla a su forma inicial (se puede deshacer). */
    public void resetMeshGrid() {
        if (!transformActive || transformType != 2 || transformVerts == null) return;
        meshUndo.add(transformVerts.clone());
        meshRedo.clear();
        initTransformVerts();
        invalidate();
        showHud("Malla restablecida");
    }

    // ==================================================================
    // Marioneta (v8.25): malla de silueta + ARAP en dos pasos (core/PuppetSession)
    // ==================================================================

    private static PixelTiles.Reader bitmapReader(final Bitmap b) {
        return new PixelTiles.Reader() {
            @Override public void read(int x, int y, int w, int h, int[] dst, int off, int stride) {
                b.getPixels(dst, off, stride, x, y, w, h);
            }
        };
    }

    // Solo los usa el hilo de la vista previa.
    private PixelTiles puppetTiles;
    private Bitmap puppetTilesSrc;
    private int[] puppetBuf;

    /** v8.27: la imagen de Marioneta no tiene transparencia (y no hay seleccion). */
    private boolean puppetOpaqueSource;
    /** v8.27: se ejecuta una vez cuando la malla queda lista (Ampliar lienzo y aplicar). */
    private Runnable puppetAfterBuild;
    /** v8.27: alfa util de la malla (8 de fabrica; 1 = como v8.26). */
    private int puppetMinAlpha = 8;

    /** Muestreo rapido: casi todo opaco = no hay fondo transparente. */
    private static boolean mostlyOpaque(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int step = Math.max(1, (int) Math.sqrt((double) w * h / 40000.0));
        int[] row = new int[w];
        long n = 0, opaque = 0;
        for (int y = 0; y < h; y += step) {
            b.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x += step) {
                n++;
                if ((row[x] >>> 24) >= 250) opaque++;
            }
        }
        return n > 0 && opaque >= n * 97 / 100;
    }

    /** v8.69: "Solo el personaje" (de fabrica): el papel blanco no entra en la malla y se queda quieto. */
    private boolean puppetCharOnly = true;
    private boolean transformPaperSplit;
    public boolean isPuppetCharOnly() { return puppetCharOnly; }
    public void setPuppetCharOnly(boolean on) { puppetCharOnly = on; }

    /**
     * v8.69: en una capa sin transparencia (dibujo escaneado sobre papel), el papel blanco que toca
     * el borde se separa: la capa queda con papel liso debajo y la malla solo agarra el dibujo.
     * Antes la hoja tambien se estiraba y se metia en el dibujo. Cancelar / Deshacer devuelven el
     * original exacto (se guarda una copia).
     */
    private boolean splitPaperForPuppet() {
        if (!puppetCharOnly || transformPaperSplit || transformSelectionBackup != null
                || transformBitmap == null || transformSrcRect == null || transformLayer == null) return false;
        final Bitmap bmp = transformBitmap;
        if (!mostlyOpaque(bmp)) return false;
        int w = bmp.getWidth(), h = bmp.getHeight(), n = w * h;
        int[] px;
        try { px = new int[n]; } catch (OutOfMemoryError e) { return false; }
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        // color del papel: lo mas claro y comun del borde
        int[] hist = new int[256];
        int bc = 0;
        for (int x = 0; x < w; x++) { hist[lumOf(px[x])]++; hist[lumOf(px[(h - 1) * w + x])]++; bc += 2; }
        for (int y = 0; y < h; y++) { hist[lumOf(px[y * w])]++; hist[lumOf(px[y * w + w - 1])]++; bc += 2; }
        int light = 0;
        for (int v = 200; v < 256; v++) light += hist[v];
        if (light * 10 < bc * 6) return false;            // el borde no es papel claro
        int acc = 0, paperL = 255;
        for (int v = 255; v >= 0; v--) { acc += hist[v]; if (acc * 2 >= light) { paperL = v; break; } }
        final int thr = Math.max(170, paperL - 22);
        byte[] paper = new byte[n];
        IntStack st = new IntStack();
        for (int x = 0; x < w; x++) { st.push(x); st.push((h - 1) * w + x); }
        for (int y = 0; y < h; y++) { st.push(y * w); st.push(y * w + w - 1); }
        long cnt = 0;
        // relleno por renglones (memoria acotada aun en hojas enormes)
        while (st.n > 0) {
            int i = st.a[--st.n];
            if (!isPaper(px, paper, thr, i)) continue;
            int y = i / w, row = y * w, x0 = i - row, x1 = x0;
            while (x0 > 0 && isPaper(px, paper, thr, row + x0 - 1)) x0--;
            while (x1 < w - 1 && isPaper(px, paper, thr, row + x1 + 1)) x1++;
            for (int x = x0; x <= x1; x++) paper[row + x] = 1;
            cnt += x1 - x0 + 1;
            for (int dy = -1; dy <= 1; dy += 2) {
                int yy = y + dy;
                if (yy < 0 || yy >= h) continue;
                int rr = yy * w;
                boolean run = false;
                for (int x = x0; x <= x1; x++) {
                    boolean p = isPaper(px, paper, thr, rr + x);
                    if (p && !run) st.push(rr + x);
                    run = p;
                }
            }
        }
        if (cnt < n / 20 || cnt > (long) n * 97 / 100) return false;   // casi nada de papel o casi todo
        // tono medio del papel (para rellenar el hueco que deja el dibujo al moverse)
        long sr = 0, sg = 0, sb = 0, k = 0;
        for (int i = 0; i < n; i += 7) if (paper[i] != 0) { int c = px[i]; sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255; k++; }
        int fill = k == 0 ? 0xFFFFFFFF : 0xFF000000 | (int) (sr / k) << 16 | (int) (sg / k) << 8 | (int) (sb / k);
        try {
            transformBackup = px.clone();                 // el original exacto (Cancelar / Deshacer)
        } catch (OutOfMemoryError e) { return false; }
        // el dibujo: papel fuera; el borde claro del dibujo (antialias) se vuelve semitransparente
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (paper[i] != 0) { px[i] = 0; continue; }
                boolean edge = (x > 0 && paper[i - 1] != 0) || (x < w - 1 && paper[i + 1] != 0)
                        || (y > 0 && paper[i - w] != 0) || (y < h - 1 && paper[i + w] != 0);
                if (!edge) continue;
                int c = px[i], l = lumOf(c);
                if (l > thr - 40) {
                    int a = Math.max(0, Math.min(255, (paperL - l) * 255 / Math.max(1, paperL - (thr - 40))));
                    px[i] = a == 0 ? 0 : (a << 24) | (c & 0xFFFFFF);
                }
            }
        bmp.setPixels(px, 0, w, 0, 0, w, h);
        int[] lp = transformLayer.px();
        Rect r = transformSrcRect;
        for (int y = 0; y < h; y++) Arrays.fill(lp, (r.top + y) * project.w + r.left, (r.top + y) * project.w + r.left + w, fill);
        transformPaperSplit = true;
        updateDisplayRegion(r);
        return true;
    }

    private static final class IntStack {
        int[] a = new int[4096];
        int n;
        void push(int v) {
            if (n == a.length) a = Arrays.copyOf(a, a.length * 2);
            a[n++] = v;
        }
    }

    private static boolean isPaper(int[] px, byte[] paper, int thr, int i) {
        if (paper[i] != 0) return false;
        int c = px[i];
        return (c >>> 24) >= 250 && lumOf(c) >= thr;
    }

    private static int lumOf(int c) {
        return (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
    }

    private void startPuppet() {
        if (transformBitmap == null || transformSrcRect == null) return;
        releasePuppet();
        splitPaperForPuppet();
        final Bitmap src = transformBitmap;
        puppetOpaqueSource = transformSelectionBackup == null && mostlyOpaque(src);
        final PuppetSession ps = new PuppetSession(bitmapReader(src), src.getWidth(), src.getHeight(),
                transformSrcRect.left, transformSrcRect.top);
        ps.setDensity(puppetDensity);
        ps.setExpansion(puppetExpansion);
        ps.setRigidity(puppetRigidity);
        ps.setFoldGuard(puppetFoldGuard);
        ps.setStiffRadiusCells(puppetStiffCells);
        ps.setByParts(puppetByParts);
        ps.setReachCells(puppetReachCells);
        ps.setMinAlpha(puppetMinAlpha);
        puppet = ps;
        puppetBuilding = true;
        puppetSel = -1;
        puppetEdges = null;
        puppetShownSeq = 0;
        if (puppetWorker == null) puppetWorker = new LatestWorker("pz-marioneta");
        showHud("Creando la malla del dibujo...");
        Task.run(new Runnable() {
            @Override public void run() {
                try { ps.buildMesh(); } catch (Throwable ignored) {}
            }
        }, new Runnable() {
            @Override public void run() {
                if (puppet != ps) return;
                puppetBuilding = false;
                if (!ps.hasMesh()) {
                    puppetAfterBuild = null;
                    puppetEnlarging = false;
                    msg("No se pudo crear la malla. Prueba con menos densidad.");
                    return;
                }
                puppetEdges = edgesOf(ps.mesh(), transformBitmap);
                if (callback != null) callback.onToolStateChanged();
                Runnable hook = puppetAfterBuild;
                puppetAfterBuild = null;
                if (hook != null) {
                    hook.run();
                    return;
                }
                if (transformPaperSplit) {
                    showHud("Solo el personaje: el papel blanco se queda quieto", 2600);
                } else if (puppetOpaqueSource) {
                    // v8.27: sin transparencia la malla cubre TODA la escena (fondo incluido)
                    // v8.36: aviso corto arriba (antes un mensaje largo abajo)
                    showHud("Capa sin fondo transparente: se mueve toda la escena", 2600);
                } else {
                    if (ps.pinCount() == 0) showHud("Toca el dibujo para poner puntos");
                }
                requestPuppetPreview(true);
                invalidate();
            }
        });
    }

    /** Rehace la malla con otra densidad o expansion sin perder los puntos. */
    private void rebuildPuppetMesh(final int density, final int expansion) {
        final PuppetSession ps = puppet;
        if (ps == null || puppetBuilding) return;
        puppetBuilding = true;
        showHud("Rehaciendo la malla...");
        Task.run(new Runnable() {
            @Override public void run() {
                try { ps.setDensity(density); ps.setExpansion(expansion); } catch (Throwable ignored) {}
            }
        }, new Runnable() {
            @Override public void run() {
                if (puppet != ps) return;
                puppetBuilding = false;
                if (!ps.hasMesh()) return;
                puppetEdges = edgesOf(ps.mesh(), transformBitmap);
                if (puppetSel >= ps.pinCount()) puppetSel = -1;
                requestPuppetPreview(true);
                invalidate();
            }
        });
    }

    /** Detiene la vista previa y suelta la sesion de Marioneta. */
    private void releasePuppet() {
        puppetDiscardSolver();
        puppetDrawPos = null;
        puppetDrawPins = null;
        puppetDrawBad = null;
        if (puppetWorker != null) puppetWorker.cancelAndWait(2000);
        puppetAfterBuild = null;
        synchronized (puppetPool) {
            for (Bitmap b : puppetPool) if (b != null && !b.isRecycled() && b != puppetPreview) b.recycle();
            puppetPool.clear();
        }
        puppet = null;
        puppetBuilding = false;
        puppetSel = -1;
        puppetDrag = -1;
        puppetGesture = false;
        puppetGestureSnap = null;
        puppetEdges = null;
        puppetTilesSrc = null;
        puppetTiles = null;
        if (puppetPreview != null && !puppetPreview.isRecycled()) puppetPreview.recycle();
        puppetPreview = null;
        puppetShownSeq = 0;
    }

    /**
     * Aristas que dibuja "Ver malla". v8.27: solo de triangulos que tienen dibujo
     * (alfa >= 8) dentro: la malla se ve recortada a la silueta. Los triangulos de
     * borde de celda sin dibujo existen para el motor (margen de seguridad) pero no se
     * dibujan como si fueran parte del personaje.
     */
    private static int[] edgesOf(PuppetMesh m, Bitmap src) {
        java.util.HashSet<Long> seen = new java.util.HashSet<Long>();
        int[] out = new int[m.triCount * 6];
        int n = 0;
        // Motas sueltas casi invisibles (brillos de alfa 1-8) tienen su propia
        // malla diminuta: siguen al dibujo, pero no se dibujan para no ensuciar.
        int[] compSize = new int[m.compCount];
        for (int v = 0; v < m.vertCount; v++) compSize[m.vertComp[v]]++;
        int sw = src == null || src.isRecycled() ? 0 : src.getWidth(), sh = sw == 0 ? 0 : src.getHeight();
        int[] row = sw > 0 ? new int[sw] : null;
        for (int t = 0; t < m.triCount; t++) {
            if (compSize[m.vertComp[m.tri[t * 3]]] < 30) continue;
            if (row != null && !triHasContent(m, t, src, sw, sh, row)) continue;
            for (int k = 0; k < 3; k++) {
                int a = m.tri[t * 3 + k], b = m.tri[t * 3 + (k + 1) % 3];
                long key = ((long) Math.min(a, b) << 32) | Math.max(a, b);
                if (seen.add(key)) { out[n++] = a; out[n++] = b; }
            }
        }
        return Arrays.copyOf(out, n);
    }

    /** Hay algun pixel con alfa >= 8 dentro del triangulo t (en reposo)? */
    private static boolean triHasContent(PuppetMesh m, int t, Bitmap src, int sw, int sh, int[] row) {
        float ax = m.rest[m.tri[t * 3] * 2], ay = m.rest[m.tri[t * 3] * 2 + 1];
        float bx = m.rest[m.tri[t * 3 + 1] * 2], by = m.rest[m.tri[t * 3 + 1] * 2 + 1];
        float cx = m.rest[m.tri[t * 3 + 2] * 2], cy = m.rest[m.tri[t * 3 + 2] * 2 + 1];
        int x0 = Math.max(0, (int) Math.floor(Math.min(ax, Math.min(bx, cx)))), x1 = Math.min(sw - 1, (int) Math.ceil(Math.max(ax, Math.max(bx, cx))));
        int y0 = Math.max(0, (int) Math.floor(Math.min(ay, Math.min(by, cy)))), y1 = Math.min(sh - 1, (int) Math.ceil(Math.max(ay, Math.max(by, cy))));
        if (x0 > x1 || y0 > y1) return false;
        float den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy);
        if (Math.abs(den) < 1e-6f) return false;
        for (int y = y0; y <= y1; y++) {
            src.getPixels(row, 0, sw, x0, y, x1 - x0 + 1, 1);
            float py = y + .5f;
            for (int x = x0; x <= x1; x++) {
                if ((row[x - x0] >>> 24) < 8) continue;
                float px = x + .5f;
                float l1 = ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / den;
                float l2 = ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / den;
                // un poco de margen: el pixel toca el triangulo
                if (l1 >= -.05f && l2 >= -.05f && 1f - l1 - l2 >= -.05f) return true;
            }
        }
        return false;
    }

    /** Pruebas: cuantas aristas dibujaria "Ver malla". */
    public int puppetDrawnEdgeCountForTest() { return puppetEdges == null ? 0 : puppetEdges.length / 2; }

    /**
     * Pide al hilo de vista previa que pinte la imagen deformada. Usa el MISMO
     * rasterizador que el resultado final (TriWarp).
     *
     * v8.27 (rendimiento): antes se pintaban hasta 0,7 millones de pixeles por
     * movimiento (3 millones al soltar) aunque la pantalla mostrara menos, y cada
     * resultado creaba un Bitmap nuevo. Ahora:
     *  - solo la parte VISIBLE en pantalla (con 25 % de margen para desplazar),
     *  - a la resolucion de la PANTALLA (si el zoom es 0,5 se pinta a 0,5; acercado,
     *    hasta el limite de 0,7 M / 3 M px),
     *  - en Bitmaps reutilizables: el que se muestra nunca se toca ni se recicla; el
     *    anterior vuelve a la reserva 100 ms despues de dejar de mostrarse,
     *  - el hilo hace solo el ultimo pedido (LatestWorker) y se mide el tiempo.
     * El resultado final (Aplicar) sigue siendo a resolucion completa.
     */
    private void requestPuppetPreview(boolean fine) {
        final PuppetSession ps = puppet;
        if (ps == null || puppetBuilding || !ps.hasMesh() || puppetWorker == null || project == null) return;
        final float[] pos = ps.positionsCopy();
        final PuppetMesh m = ps.mesh();
        final float[] bb = ps.deformedBounds();
        final Bitmap srcB = transformBitmap;
        if (pos == null || bb == null || srcB == null) return;
        int l0 = Math.max(0, (int) Math.floor(bb[0]) - 1), t0 = Math.max(0, (int) Math.floor(bb[1]) - 1);
        int r0 = Math.min(project.w, (int) Math.ceil(bb[2]) + 1), b0 = Math.min(project.h, (int) Math.ceil(bb[3]) + 1);
        RectF vis = visibleImageRect(0.25f);
        if (vis != null) {
            l0 = Math.max(l0, (int) Math.floor(vis.left));
            t0 = Math.max(t0, (int) Math.floor(vis.top));
            r0 = Math.min(r0, (int) Math.ceil(vis.right));
            b0 = Math.min(b0, (int) Math.ceil(vis.bottom));
        }
        final int l = l0, t = t0, r = r0, b = b0;
        if (r <= l || b <= t) return;
        double area = (double) (r - l) * (b - t);
        double budget = fine ? puppetFineBudget : puppetDragBudget;
        float zoom = currentScale();
        if (vis != null && zoom > 0f) budget = Math.min(budget, Math.max(20000.0, area * zoom * zoom));
        // mientras se arrastra, baja resolucion (fluido; v8.35: 0.45 -> 0.30); al soltar, completa
        if (!fine) budget = Math.max(20000.0, budget * 0.42);   // v8.69: 0.30 -> 0.42 (menos escalones al arrastrar)
        final float sc = (float) Math.min(1.0, Math.sqrt(budget / area));
        final int ow = Math.max(1, (int) Math.ceil((r - l) * sc)), oh = Math.max(1, (int) Math.ceil((b - t) * sc));
        final int seq = ++puppetSeq;
        puppetWorker.submit(new Runnable() {
            @Override public void run() {
                long tStart = System.nanoTime();
                if (puppetTiles == null || puppetTilesSrc != srcB) {
                    puppetTiles = new PixelTiles(bitmapReader(srcB), srcB.getWidth(), srcB.getHeight(), 192);
                    puppetTilesSrc = srcB;
                }
                int need = ow * oh;
                if (puppetBuf == null || puppetBuf.length < need) puppetBuf = new int[need];
                else Arrays.fill(puppetBuf, 0, need, 0);
                if (fine) PuppetSession.render(m, pos, puppetTiles, l, t, ow, oh, sc, puppetBuf);
                else PuppetSession.renderFast(m, pos, puppetTiles, l, t, ow, oh, sc, puppetBuf);
                Bitmap out = takePuppetBitmap(ow, oh);
                if (out == null) return;
                out.setPixels(puppetBuf, 0, ow, 0, 0, ow, oh);
                lastPuppetPreviewPixels = need;
                com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.PUPPET, System.nanoTime() - tStart);
                final Bitmap shown = out;
                post(new Runnable() {
                    @Override public void run() {
                        if (puppet != ps || seq < puppetShownSeq) { givePuppetBitmapBack(shown); return; }
                        puppetShownSeq = seq;
                        final Bitmap old = puppetPreview;
                        puppetPreview = shown;
                        puppetPreviewSrc.set(0, 0, ow, oh);
                        puppetPreviewRect.set(l, t, l + ow / sc, t + oh / sc);
                        invalidate();
                        if (old != null && old != shown) {
                            // el anterior pudo usarse en el ultimo cuadro: vuelve a la reserva despues
                            postDelayed(new Runnable() {
                                @Override public void run() {
                                    if (old != puppetPreview) givePuppetBitmapBack(old);
                                }
                            }, 100);
                        }
                    }
                });
            }
        });
    }

    /** Pixeles de lienzo por pixel de la vista previa, limites (pruebas y benchmark). */
    public double puppetDragBudget = 0.7e6, puppetFineBudget = 3.0e6;
    /** Pixeles que pinto la ultima vista previa (pruebas). */
    public volatile int lastPuppetPreviewPixels;
    private final Rect puppetPreviewSrc = new Rect();
    /** Bitmaps libres para la vista previa (hasta 2). Nunca contiene el que se muestra. */
    private final java.util.ArrayList<Bitmap> puppetPool = new java.util.ArrayList<Bitmap>();
    /** Pruebas: cuantos Bitmaps nuevos creo la vista previa. */
    public volatile int puppetBitmapsCreated;

    private Bitmap takePuppetBitmap(int w, int h) {
        synchronized (puppetPool) {
            for (int i = 0; i < puppetPool.size(); i++) {
                Bitmap b = puppetPool.get(i);
                if (b == null || b.isRecycled()) { puppetPool.remove(i--); continue; }
                if (b.getWidth() >= w && b.getHeight() >= h) {
                    puppetPool.remove(i);
                    return b;
                }
            }
        }
        try {
            // un poco mas grande: los siguientes cuadros (algo distintos) caben sin crear otro
            int bw = Math.min(Math.max(w, w + w / 8), 8192), bh = Math.min(Math.max(h, h + h / 8), 8192);
            puppetBitmapsCreated++;
            return Bitmap.createBitmap(Math.max(w, bw), Math.max(h, bh), Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    private void givePuppetBitmapBack(Bitmap b) {
        if (b == null || b.isRecycled() || b == puppetPreview) return;
        synchronized (puppetPool) {
            if (puppetPool.size() < 2 && puppet != null) {
                puppetPool.add(b);
                return;
            }
        }
        b.recycle();
    }

    /** Rectangulo del lienzo que se ve en pantalla (+ margen relativo). null si la vista no tiene tamano. */
    private RectF visibleImageRect(float margin) {
        int vw = getWidth(), vh = getHeight();
        if (vw <= 0 || vh <= 0) return null;
        Matrix inv = new Matrix();
        if (!view.invert(inv)) return null;
        float[] c = {0, 0, vw, 0, 0, vh, vw, vh};
        inv.mapPoints(c);
        float x0 = Math.min(Math.min(c[0], c[2]), Math.min(c[4], c[6])), x1 = Math.max(Math.max(c[0], c[2]), Math.max(c[4], c[6]));
        float y0 = Math.min(Math.min(c[1], c[3]), Math.min(c[5], c[7])), y1 = Math.max(Math.max(c[1], c[3]), Math.max(c[5], c[7]));
        float mx = (x1 - x0) * margin, my = (y1 - y0) * margin;
        return new RectF(x0 - mx, y0 - my, x1 + mx, y1 + my);
    }

    /** Ultima vista previa (pruebas): bitmap y su rectangulo en el lienzo. */
    public Bitmap getPuppetPreviewForTest(RectF outRect) {
        if (outRect != null) outRect.set(puppetPreviewRect);
        if (puppetPreview == null || puppetPreview.isRecycled()) return puppetPreview;
        // v8.27: el Bitmap reutilizable puede ser mas grande que lo pintado
        return Bitmap.createBitmap(puppetPreview, 0, 0, puppetPreviewSrc.width(), puppetPreviewSrc.height());
    }

    /**
     * v8.61: dos dedos en Marioneta / Transformar = mover, ampliar Y GIRAR, igual que en las demas
     * herramientas (antes solo movia y ampliaba: al girar los dedos la imagen parecia congelada).
     */
    private void transformTwoFingerNav(MotionEvent e, int a) {
        int pc = e.getPointerCount();
        if (a == MotionEvent.ACTION_POINTER_UP) {
            if (pc - 1 >= 2) navBegin(e, e.getActionIndex());
            else navActive = false;
            transformNavMidValid = false;
            // la vista previa de Marioneta se pinta para lo visible: al terminar se repinta fina
            if (transformType == 4) requestPuppetPreview(true);
        } else if (a == MotionEvent.ACTION_POINTER_DOWN || !navActive) {
            navBegin(e, -1);
        } else if (a == MotionEvent.ACTION_MOVE) {
            twoFingers(e);
            if (transformType == 4) requestPuppetPreview(false);
        }
        invalidate();
    }

    private boolean onPuppetTouch(MotionEvent e, int a, int pc) {
        final PuppetSession ps = puppet;
        final float dens = getResources().getDisplayMetrics().density;
        final float sc = Math.max(.05f, currentScale());
        if (pc >= 2) {
            // Dos dedos: solo zoom y desplazamiento. Lo que alcanzo a mover el
            // primer dedo se devuelve: los puntos no se mueven por accidente.
            cancelPuppetGesture();
            puppetTap = false;
            transformTwoFingerNav(e, a);
            return true;
        }
        if (a == MotionEvent.ACTION_POINTER_UP) {
            scaleDetector.onTouchEvent(e);
            transformNavMidValid = false;
            puppetTap = false;
            invalidate();
            return true;
        }
        if (ps == null || puppetBuilding || !ps.hasMesh()) {
            if (a == MotionEvent.ACTION_DOWN) showHud("Creando la malla del dibujo...");
            return true;
        }
        imagePoint(e.getX(), e.getY());
        float x = point[0], y = point[1];
        if (a == MotionEvent.ACTION_DOWN) {
            transformNavMidValid = false;
            puppetDownX = x; puppetDownY = y;
            puppetDownSX = e.getX(); puppetDownSY = e.getY();
            puppetDrag = -1;
            puppetRotating = false;
            puppetGesture = false;
            puppetMoved = false;
            puppetTap = true;
            int hit = ps.findPin(x, y, 22f * dens / sc);
            // Anillo de giro alrededor del punto elegido
            if ((hit < 0 || hit == puppetSel) && puppetSel >= 0 && puppetSel < ps.pinCount()) {
                PuppetSession.Pin p = ps.pin(puppetSel);
                // v8.59: el anillo de giro mas lejos del punto (antes casi pegado: al querer
                // arrastrar el punto se giraba sin querer). Entre el punto y el anillo, nada.
                float ring = PUPPET_RING_DP * dens / sc, d = (float) Math.hypot(x - p.x, y - p.y);
                if (!p.fixed && d >= ring - 8f * dens / sc && d <= ring + 12f * dens / sc) {
                    puppetRotating = true;
                    puppetDrag = puppetSel;
                    puppetRot0 = p.rot;
                    puppetRotCx = p.x; puppetRotCy = p.y;
                    puppetAng0 = (float) Math.atan2(y - p.y, x - p.x);
                    puppetTap = false;
                    invalidate();
                    return true;
                }
            }
            if (hit != puppetSel && callback != null) post(new Runnable() {
                @Override public void run() { if (callback != null) callback.onToolStateChanged(); }
            });
            if (hit >= 0) {
                puppetSel = hit;
                puppetTap = false;
                PuppetSession.Pin p = ps.pin(hit);
                if (p.fixed) {
                    showHud("Punto fijo");
                } else {
                    puppetDrag = hit;
                    puppetOffX = p.x - x;
                    puppetOffY = p.y - y;
                }
            }
            invalidate();
            return true;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            float moved = (float) Math.hypot(e.getX() - puppetDownSX, e.getY() - puppetDownSY);
            if (moved > 10f * dens) puppetTap = false;
            if (puppetDrag < 0 || puppetDrag >= ps.pinCount()) return true;
            if (!puppetGesture) {
                if (moved < 3f * dens) return true;
                puppetFlushSolver();
                puppetGestureSnap = ps.snapshot();
                ps.beginGesture();
                puppetPublish(ps);
                puppetGesture = true;
            }
            // v8.61: el calculo va en OTRO hilo (antes se hacia aqui y el dedo esperaba: con mallas
            // grandes se trababa y a veces no respondia). Solo cuenta el ultimo movimiento.
            if (puppetRotating) {
                float cx = puppetRotCx, cy = puppetRotCy;
                float ang = (float) Math.atan2(y - cy, x - cx);
                puppetTarget(ps, puppetDrag, true, 0f, 0f, puppetRot0 + (ang - puppetAng0), false);
            } else {
                puppetTarget(ps, puppetDrag, false, x + puppetOffX, y + puppetOffY, 0f, false);
            }
            puppetMoved = true;
            invalidate();
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            if (a == MotionEvent.ACTION_UP && puppetTap && puppetDrag < 0) {
                if (puppetAddMode) {
                    int idx = ps.addPin(x, y, false);
                    if (idx >= 0) {
                        puppetSel = idx;
                        showHud(ps.pinCount() == 1 ? "Punto puesto. Pon mas y fija los pies con Fijar"
                                : "Punto " + ps.pinCount());
                        requestPuppetPreview(true);
                    } else {
                        showHud("Toca sobre el dibujo para poner un punto");
                    }
                } else {
                    puppetSel = -1;
                }
            }
            if (a == MotionEvent.ACTION_CANCEL && puppetGesture) cancelPuppetGesture();
            boolean wasMoved = puppetMoved && puppetGesture;
            puppetDrag = -1;
            puppetRotating = false;
            puppetGesture = false;
            puppetGestureSnap = null;
            if (wasMoved) {
                // el ultimo movimiento termina en el otro hilo y despues se pinta fino
                puppetTarget(ps, -1, false, 0f, 0f, 0f, true);
            } else if (puppetMoved) {
                requestPuppetPreview(true);
                warnIfOutsideCanvas();
            }
            puppetMoved = false;
            if (callback != null) callback.onToolStateChanged();
            invalidate();
            return true;
        }
        return true;
    }

    // ==================================================================
    // v8.27 Marioneta FUERA DEL LIENZO: antes solo avisaba "Cancela y usa Menu >
    // Ampliar lienzo" (y al aplicar se cortaba lo que salia). Ahora, al pulsar
    // Aplicar, la interfaz ofrece con vista previa del lienzo nuevo:
    //  - Ampliar lienzo y aplicar: agrega justo el espacio que falta (+8 px) y aplica
    //    la MISMA postura (se puede deshacer en dos pasos: Marioneta y Ampliar).
    //  - Mover dentro del lienzo (si cabe): corre todo el resultado sin deformarlo.
    //  - Aplicar recortando / Seguir editando.
    // ==================================================================

    /** Limites reales del dibujo deformado (alfa >= 8) en el lienzo: {izq, arriba, der, abajo}. */
    public float[] puppetContentBounds() {
        if (!isPuppetReady() || transformBitmap == null) return null;
        PuppetSession ps = puppet;
        float[] pos = ps.positionsCopy();
        float[] bb = ps.deformedBounds();
        PuppetMesh m = ps.mesh();
        if (pos == null || bb == null) return null;
        int l = (int) Math.floor(bb[0]) - 1, t = (int) Math.floor(bb[1]) - 1;
        int r = (int) Math.ceil(bb[2]) + 1, b = (int) Math.ceil(bb[3]) + 1;
        if (r <= l || b <= t) return null;
        double area = (double) (r - l) * (b - t);
        float sc = (float) Math.min(1.0, Math.sqrt(250000.0 / area));
        int ow = Math.max(1, (int) Math.ceil((r - l) * sc)), oh = Math.max(1, (int) Math.ceil((b - t) * sc));
        int[] buf = new int[ow * oh];
        PixelTiles tiles = new PixelTiles(bitmapReader(transformBitmap), transformBitmap.getWidth(), transformBitmap.getHeight(), 48);
        PuppetSession.render(m, pos, tiles, l, t, ow, oh, sc, buf);
        int x0 = ow, y0 = oh, x1 = -1, y1 = -1;
        for (int y = 0; y < oh; y++)
            for (int x = 0; x < ow; x++)
                if ((buf[y * ow + x] >>> 24) >= 8) {
                    if (x < x0) x0 = x;
                    if (x > x1) x1 = x;
                    if (y < y0) y0 = y;
                    if (y > y1) y1 = y;
                }
        if (x1 < 0) return null;
        return new float[]{l + x0 / sc, t + y0 / sc, l + (x1 + 1) / sc, t + (y1 + 1) / sc};
    }

    /** Lo que falta de lienzo {izq, arriba, der, abajo} (con 8 px de aire) o null si todo cabe. */
    public int[] puppetOverflow() {
        if (project == null) return null;
        float[] cb = puppetContentBounds();
        if (cb == null) return null;
        int pad = 8;
        int L = cb[0] < -0.5f ? (int) Math.ceil(-cb[0]) + pad : 0;
        int T = cb[1] < -0.5f ? (int) Math.ceil(-cb[1]) + pad : 0;
        int R = cb[2] > project.w + 0.5f ? (int) Math.ceil(cb[2] - project.w) + pad : 0;
        int B = cb[3] > project.h + 0.5f ? (int) Math.ceil(cb[3] - project.h) + pad : 0;
        if (L + T + R + B == 0) return null;
        return new int[]{L, T, R, B};
    }

    /** true si el resultado cabe en el lienzo corriendolo (sin agrandar). */
    public boolean puppetCanMoveInside() {
        float[] cb = puppetContentBounds();
        return cb != null && project != null && cb[2] - cb[0] <= project.w - 2 && cb[3] - cb[1] <= project.h - 2;
    }

    /** Corre todo el resultado para que quede dentro del lienzo (se puede deshacer). */
    public boolean puppetMoveInside() {
        float[] cb = puppetContentBounds();
        if (cb == null || project == null || !isPuppetReady()) return false;
        float dx = 0f, dy = 0f;
        if (cb[2] - cb[0] > project.w - 2 || cb[3] - cb[1] > project.h - 2) {
            msg("El resultado es mas grande que el lienzo: usa Ampliar lienzo y aplicar");
            return false;
        }
        if (cb[0] < 1f) dx = 1f - cb[0];
        else if (cb[2] > project.w - 1f) dx = project.w - 1f - cb[2];
        if (cb[1] < 1f) dy = 1f - cb[1];
        else if (cb[3] > project.h - 1f) dy = project.h - 1f - cb[3];
        dx = Math.round(dx);
        dy = Math.round(dy);
        puppet.translateAll(dx, dy);
        requestPuppetPreview(true);
        if (callback != null) callback.onToolStateChanged();
        invalidate();
        showHud("Movido dentro del lienzo. Deshacer lo devuelve");
        return true;
    }

    /** Vista previa del lienzo ampliado (rectangulo punteado) mientras se decide. null = ninguna. */
    private int[] growPreview;
    private final Paint growPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public void setCanvasGrowPreview(int[] margins) {
        growPreview = margins == null ? null : margins.clone();
        invalidate();
    }

    private void drawGrowPreview(Canvas c) {
        if (growPreview == null || project == null) return;
        float dens = getResources().getDisplayMetrics().density, sc = Math.max(.05f, currentScale());
        float l = -growPreview[0], t = -growPreview[1], r = project.w + growPreview[2], b = project.h + growPreview[3];
        growPaint.setStyle(Paint.Style.FILL);
        growPaint.setColor(0x3322AAFF);
        c.drawRect(l, t, r, 0, growPaint);
        c.drawRect(l, project.h, r, b, growPaint);
        c.drawRect(l, 0, 0, project.h, growPaint);
        c.drawRect(project.w, 0, r, project.h, growPaint);
        growPaint.setStyle(Paint.Style.STROKE);
        growPaint.setStrokeWidth(2f * dens / sc);
        growPaint.setColor(0xFF22AAFF);
        c.drawRect(l, t, r, b, growPaint);
    }

    /** true mientras se amplia el lienzo y se vuelve a armar la malla para aplicar. */
    private boolean puppetEnlarging;

    public boolean isPuppetEnlarging() { return puppetEnlarging; }

    /**
     * Agranda el lienzo lo justo y aplica la MISMA postura. Paso a paso: guarda los
     * puntos, cancela (la capa vuelve exacta), amplia (se puede deshacer), rearma la
     * malla sobre la misma imagen (corrida) y repone los puntos corridos.
     */
    public void applyPuppetEnlarged(final int[] mg) {
        if (mg == null || !isPuppetReady() || busy || project == null) return;
        puppetFlushSolver();
        final PuppetSession.Snap snap = puppet.snapshot();
        final Layer layer = transformLayer;
        setCanvasGrowPreview(null);
        puppetEnlarging = true;
        cancelTransform(false);
        enlargeCanvas(mg[0], mg[1], mg[2], mg[3], new Runnable() {
            @Override public void run() {
                int li = project.layers.indexOf(layer);
                if (li >= 0) project.active = li;
                mode = MODE_TRANSFORM;
                puppetTool = true;
                transformType = 4;
                if (!startTransformSession()) {
                    puppetEnlarging = false;
                    msg("El lienzo se amplio, pero no se pudo rearmar Marioneta. Vuelve a abrirla");
                    return;
                }
                puppetAfterBuild = new Runnable() {
                    @Override public void run() {
                        puppet.restore(PuppetSession.shifted(snap, mg[0], mg[1]));
                        puppetEnlarging = false;
                        requestPuppetPreview(true);
                        applyTransform();
                    }
                };
            }
        });
    }

    private long outsideWarnAt;

    /** Avisa (sin bloquear) si una parte del dibujo deformado queda fuera del lienzo. */
    private void warnIfOutsideCanvas() {
        float[] bb = isPuppetReady() ? puppet.deformedBounds() : null;
        if (bb == null || project == null) return;
        // La malla cubre un poco mas que el dibujo: se tolera media celda.
        float tol = puppet.mesh().spacing * .5f;
        boolean out = bb[0] < -tol || bb[1] < -tol || bb[2] > project.w + tol || bb[3] > project.h + tol;
        long now = android.os.SystemClock.uptimeMillis();
        // v8.36: sin mensaje abajo (molestaba mientras mueves); al Aplicar se pregunta igual
        if (out) outsideWarnAt = now;
    }

    // ---------------- v8.61: calculo de Marioneta en otro hilo ----------------
    private com.pacco.animecut.core.LatestWorker puppetSolver;
    private final Object puppetTargetLock = new Object();
    private int puppetTPin = -1;
    private boolean puppetTRot, puppetTValid;
    private float puppetTX, puppetTY, puppetTAng;
    private float puppetRotCx, puppetRotCy;
    /** Lo que se dibuja mientras el calculo sigue: copia de la malla y de los puntos. */
    private volatile float[] puppetDrawPos;
    private volatile PuppetSession.Pin[] puppetDrawPins;
    private volatile int[] puppetDrawBad;

    private void puppetPublish(PuppetSession ps) {
        float[] pos = ps.positionsCopy();
        puppetDrawPins = ps.pinsCopy();
        PuppetMesh m = ps.mesh();
        int[] bad = null;
        if (pos != null && m != null) {
            int nb = 0;
            int[] tmp = new int[16];
            for (int t = 0; t < m.triCount; t++) {
                if (m.signedArea(pos, t) > 1e-4f) continue;
                if (nb == tmp.length) tmp = Arrays.copyOf(tmp, nb * 2);
                tmp[nb++] = t;
            }
            bad = Arrays.copyOf(tmp, nb);
        }
        puppetDrawBad = bad;
        puppetDrawPos = pos;
    }

    /** Termina YA lo pendiente (antes de empezar otro gesto o de Aplicar): el ultimo movimiento no se pierde. */
    private void puppetFlushSolver() {
        if (puppetSolver != null) puppetSolver.cancelAndWait(1500);
        int p; boolean r, valid; float x, y, a;
        synchronized (puppetTargetLock) {
            p = puppetTPin; r = puppetTRot; x = puppetTX; y = puppetTY; a = puppetTAng; valid = puppetTValid;
            puppetTValid = false;
        }
        PuppetSession ps = puppet;
        if (ps == null) return;
        if (valid && p >= 0 && p < ps.pinCount()) {
            if (r) ps.rotatePin(p, a); else ps.movePin(p, x, y);
        }
        puppetPublish(ps);
    }

    /** Descarta lo pendiente (el gesto se cancela y vuelve a como estaba). */
    private void puppetDiscardSolver() {
        synchronized (puppetTargetLock) { puppetTValid = false; }
        if (puppetSolver != null) puppetSolver.cancelAndWait(1500);
    }

    /**
     * Pide mover (o girar) el punto 'pin' hacia el objetivo. Solo se calcula el ultimo pedido.
     * pin < 0: no mueve nada, solo termina lo pendiente. fine: al terminar, vista previa fina.
     */
    private void puppetTarget(final PuppetSession ps, int pin, boolean rot, float tx, float ty, float ang, final boolean fine) {
        if (ps == null) return;
        if (puppetSolver == null) puppetSolver = new com.pacco.animecut.core.LatestWorker("pz-marioneta-calculo");
        synchronized (puppetTargetLock) {
            if (pin >= 0) {
                puppetTPin = pin; puppetTRot = rot; puppetTX = tx; puppetTY = ty; puppetTAng = ang;
                puppetTValid = true;
            }
        }
        puppetSolver.submit(new Runnable() {
            @Override public void run() {
                int p; boolean r; float x, y, a; boolean valid;
                synchronized (puppetTargetLock) {
                    p = puppetTPin; r = puppetTRot; x = puppetTX; y = puppetTY; a = puppetTAng; valid = puppetTValid;
                    puppetTValid = false;
                }
                boolean limited = false;
                if (valid && puppet == ps && p >= 0 && p < ps.pinCount()) {
                    long ts0 = System.nanoTime();
                    if (r) ps.rotatePin(p, a);
                    else { ps.movePin(p, x, y); limited = ps.lastMoveLimited; }
                    com.pacco.animecut.core.PerfStats.add(com.pacco.animecut.core.PerfStats.PUPPET_SOLVE, System.nanoTime() - ts0);
                }
                if (puppet != ps) return;
                puppetPublish(ps);
                final boolean lim = limited;
                post(new Runnable() {
                    @Override public void run() {
                        if (puppet != ps) return;
                        long now = android.os.SystemClock.uptimeMillis();
                        if (lim && now - puppetLimitedHudAt > 1500) {
                            puppetLimitedHudAt = now;
                            showHud("Hasta aqui se puede sin doblar el dibujo: pon un punto fijo (azul) o mueve otro punto");
                        }
                        requestPuppetPreview(fine);
                        if (fine) {
                            warnIfOutsideCanvas();
                            if (callback != null) callback.onToolStateChanged();
                        }
                        invalidate();
                    }
                });
            }
        });
    }

    private void cancelPuppetGesture() {
        if (puppetGesture) puppetDiscardSolver(); else puppetFlushSolver();
        if (puppet != null && puppetGesture && puppetGestureSnap != null) {
            puppet.restore(puppetGestureSnap);
            puppet.dropLastHistory();
            requestPuppetPreview(true);
        }
        puppetGesture = false;
        puppetDrag = -1;
        puppetRotating = false;
        puppetGestureSnap = null;
        puppetMoved = false;
    }

    private void drawPuppet(Canvas c) {
        if (puppetPreview != null && !puppetPreview.isRecycled() && puppetShownSeq > 0) {
            c.drawBitmap(puppetPreview, puppetPreviewSrc, puppetPreviewRect, transformPaint);
        } else if (transformBitmap != null && !transformBitmap.isRecycled() && transformSrcRect != null) {
            c.drawBitmap(transformBitmap, transformSrcRect.left, transformSrcRect.top, transformPaint);
        }
        final PuppetSession ps = puppet;
        if (ps == null || puppetBuilding || !ps.hasMesh()) return;
        final float dens = getResources().getDisplayMetrics().density;
        final float sc = Math.max(.05f, currentScale());
        // v8.61: mientras se mueve un punto se dibuja la ultima copia (no se espera al calculo)
        boolean useCopy = puppetGesture && puppetDrawPos != null && puppetDrawPins != null;
        float[] pos = useCopy ? puppetDrawPos : ps.positions();
        PuppetMesh m = ps.mesh();
        if (puppetShowMesh && puppetEdges != null && pos != null) {
            int ne = puppetEdges.length / 2;
            if (puppetLineBuf == null || puppetLineBuf.length < ne * 4) puppetLineBuf = new float[ne * 4];
            for (int i = 0; i < ne; i++) {
                int a = puppetEdges[i * 2], b = puppetEdges[i * 2 + 1];
                puppetLineBuf[i * 4] = pos[a * 2];
                puppetLineBuf[i * 4 + 1] = pos[a * 2 + 1];
                puppetLineBuf[i * 4 + 2] = pos[b * 2];
                puppetLineBuf[i * 4 + 3] = pos[b * 2 + 1];
            }
            // v8.36: quieta = malla tenue (se ve el dibujo y la pantalla se ve simple); mientras
            // mueves un punto = malla clara, para ver como se estira
            boolean live = puppetGesture;
            puppetMeshShadow.setAlpha(live ? 0x73 : 0x2E);
            puppetMeshPaint.setAlpha(live ? 0xD9 : 0x60);
            puppetMeshShadow.setStrokeWidth(1.7f * dens / sc);
            c.drawLines(puppetLineBuf, 0, ne * 4, puppetMeshShadow);
            puppetMeshPaint.setStrokeWidth(0.75f * dens / sc);
            c.drawLines(puppetLineBuf, 0, ne * 4, puppetMeshPaint);
        }
        if (pos != null) {
            // Triangulos invertidos (pliegue) en rojo: SIEMPRE, aunque la malla este oculta
            // (es un aviso; con "Evitar pliegues" normalmente no hay ninguno).
            // v8.36: mas fino y solo mientras mueves (quieto no hace falta el aviso)
            puppetBadPaint.setStrokeWidth(1.2f * dens / sc);
            int[] badList = puppetDrawBad;   // v8.61: los pliegues se buscan en el otro hilo
            if (puppetGesture && badList != null) for (int t : badList) {
                if (t >= m.triCount) continue;
                int a = m.tri[t * 3], b = m.tri[t * 3 + 1], q = m.tri[t * 3 + 2];
                c.drawLine(pos[a * 2], pos[a * 2 + 1], pos[b * 2], pos[b * 2 + 1], puppetBadPaint);
                c.drawLine(pos[b * 2], pos[b * 2 + 1], pos[q * 2], pos[q * 2 + 1], puppetBadPaint);
                c.drawLine(pos[q * 2], pos[q * 2 + 1], pos[a * 2], pos[a * 2 + 1], puppetBadPaint);
            }
        }
        float rr = 7f * dens / sc, rs = 10f * dens / sc;
        transformAnchorEdgePaint.setStrokeWidth(2f * dens / sc);
        PuppetSession.Pin[] pinCopy = useCopy ? puppetDrawPins : null;
        int n = pinCopy != null ? pinCopy.length : ps.pinCount();
        for (int i = 0; i < n; i++) {
            PuppetSession.Pin p = pinCopy != null ? pinCopy[i] : ps.pin(i);
            if (i == puppetSel && p.stiff)
                c.drawCircle(p.x, p.y, m.spacing * ps.getStiffRadiusCells(), puppetZonePaint);
            Paint fill = p.fixed ? transformAnchorFixedPaint : transformAnchorMovePaint;
            float r = i == puppetSel ? rs : rr;
            c.drawCircle(p.x, p.y, r, fill);
            c.drawCircle(p.x, p.y, r, transformAnchorEdgePaint);
        }
        if (puppetSel >= 0 && puppetSel < n) {
            PuppetSession.Pin p = pinCopy != null ? pinCopy[puppetSel] : ps.pin(puppetSel);
            if (!p.fixed) {
                float ring = PUPPET_RING_DP * dens / sc;
                puppetRingPaint.setStrokeWidth(2f * dens / sc);
                c.drawCircle(p.x, p.y, ring, puppetRingPaint);
                float ka = p.rot - (float) (Math.PI / 2);
                c.drawCircle(p.x + ring * (float) Math.cos(ka), p.y + ring * (float) Math.sin(ka), 4f * dens / sc, transformAnchorEdgePaint);
            }
        }
    }

    // ---- API para la barra de Deformar ----

    public boolean isDeformTool() { return puppetTool && mode == MODE_TRANSFORM; }
    public boolean isPuppetReady() { return puppet != null && !puppetBuilding && puppet.hasMesh(); }
    public boolean isPuppetAddMode() { return puppetAddMode; }
    public void setPuppetAddMode(boolean on) {
        puppetAddMode = on;
        showHud(on ? "Toca el dibujo para poner un punto" : "Agregar puntos: apagado");
    }
    public boolean isPuppetShowMesh() { return puppetShowMesh; }
    public void setPuppetShowMesh(boolean on) { puppetShowMesh = on; invalidate(); }
    public int getPuppetPinCount() { return isPuppetReady() ? puppet.pinCount() : 0; }
    public boolean hasPuppetSelection() { return isPuppetReady() && puppetSel >= 0 && puppetSel < puppet.pinCount(); }
    public boolean isPuppetSelectionFixed() { return hasPuppetSelection() && puppet.pin(puppetSel).fixed; }
    public boolean isPuppetSelectionStiff() { return hasPuppetSelection() && puppet.pin(puppetSel).stiff; }

    public void togglePuppetFixed() {
        if (!hasPuppetSelection()) { showHud("Toca un punto primero"); return; }
        boolean f = !puppet.pin(puppetSel).fixed;
        puppet.setFixed(puppetSel, f);
        showHud(f ? "Punto fijo (azul): esa zona no se mueve" : "Punto suelto (naranja): arrastralo");
        invalidate();
    }

    public void togglePuppetStiff() {
        if (!hasPuppetSelection()) { showHud("Toca un punto primero"); return; }
        boolean f = !puppet.pin(puppetSel).stiff;
        puppet.setStiff(puppetSel, f);
        showHud(f ? "Zona protegida: alrededor del punto casi no se deforma (cara, manos)" : "Zona normal");
        requestPuppetPreview(true);
        invalidate();
    }

    public void deletePuppetPin() {
        if (!hasPuppetSelection()) { showHud("Toca un punto primero"); return; }
        puppet.removePin(puppetSel);
        puppetSel = -1;
        showHud("Punto eliminado");
        requestPuppetPreview(true);
        invalidate();
    }

    public void resetPuppetPins() {
        if (!isPuppetReady()) return;
        puppet.clearPins();
        puppetSel = -1;
        showHud("Puntos quitados: el dibujo vuelve a su forma");
        requestPuppetPreview(true);
        invalidate();
    }

    public int getPuppetRigidity() { return puppetRigidity; }
    public void setPuppetRigidity(int r) {
        puppetRigidity = Math.max(0, Math.min(2, r));
        if (isPuppetReady()) { puppet.setRigidity(puppetRigidity); requestPuppetPreview(true); invalidate(); }
    }
    public int getPuppetDensity() { return puppetDensity; }
    public int getPuppetExpansion() { return puppetExpansion; }
    public void setPuppetMeshOptions(int density, int expansion) {
        density = Math.max(0, Math.min(2, density));
        expansion = Math.max(0, Math.min(20, expansion));
        boolean changed = density != puppetDensity || expansion != puppetExpansion;
        puppetDensity = density;
        puppetExpansion = expansion;
        if (changed && isPuppetReady()) rebuildPuppetMesh(density, expansion);
    }
    /** v8.27: alfa util de la malla: 8 (de fabrica) ignora restos invisibles; 1 = como v8.26. */
    public int getPuppetMinAlpha() { return puppetMinAlpha; }

    public void setPuppetMinAlpha(int a) {
        a = Math.max(1, Math.min(128, a));
        if (a == puppetMinAlpha) return;
        puppetMinAlpha = a;
        final PuppetSession ps = puppet;
        if (ps == null || puppetBuilding || !ps.hasMesh()) return;
        puppetBuilding = true;
        final int want = a;
        showHud("Rehaciendo la malla...");
        Task.run(new Runnable() {
            @Override public void run() {
                try { ps.setMinAlpha(want); } catch (Throwable ignored) {}
            }
        }, new Runnable() {
            @Override public void run() {
                if (puppet != ps) return;
                puppetBuilding = false;
                if (!ps.hasMesh()) return;
                puppetEdges = edgesOf(ps.mesh(), transformBitmap);
                if (puppetSel >= ps.pinCount()) puppetSel = -1;
                requestPuppetPreview(true);
                invalidate();
            }
        });
    }

    public boolean isPuppetFoldGuard() { return puppetFoldGuard; }
    public void setPuppetFoldGuard(boolean on) {
        puppetFoldGuard = on;
        if (puppet != null) puppet.setFoldGuard(on);
    }
    public float getPuppetStiffCells() { return puppetStiffCells; }
    public boolean isPuppetByParts() { return puppetByParts; }
    public void setPuppetByParts(boolean on) {
        puppetByParts = on;
        if (isPuppetReady()) { puppet.setByParts(on); requestPuppetPreview(true); invalidate(); }
    }
    public float getPuppetReachCells() { return puppetReachCells; }
    public void setPuppetReachCells(float c) {
        puppetReachCells = Math.max(2f, Math.min(30f, c));
        if (isPuppetReady()) { puppet.setReachCells(puppetReachCells); requestPuppetPreview(true); invalidate(); }
    }
    public void setPuppetStiffCells(float c) {
        puppetStiffCells = Math.max(1f, Math.min(8f, c));
        if (isPuppetReady()) { puppet.setStiffRadiusCells(puppetStiffCells); requestPuppetPreview(true); invalidate(); }
    }

    /** Hay cambios sin aplicar en el modo actual de Deformar. */
    public boolean hasDeformChanges() {
        if (!transformActive) return false;
        if (transformType == 4) return isPuppetReady() && puppet.canUndo();
        if (transformType == 2) return !meshUndo.isEmpty();
        if (transformType == 3) return !anchorUndo.isEmpty();
        return false;
    }

    /** Despues de aplicar, abrir este modo (cambio de pestana con "Aplicar y cambiar"). */
    public void setPendingTypeAfterApply(int t) { pendingTypeAfterApply = t; }

    /** Deshacer/Rehacer DENTRO de la sesion (puntos de Marioneta o nodos de Malla). */
    private void deformHistory(boolean back) {
        if (transformApplying) return;
        if (transformType == 4) {
            if (!isPuppetReady()) return;
            puppetFlushSolver();
            boolean ok = back ? puppet.undo() : puppet.redo();
            if (puppetSel >= puppet.pinCount()) puppetSel = -1;
            showHud(ok ? (back ? "Deshacer punto" : "Rehacer punto") : (back ? "Nada que deshacer" : "Nada que rehacer"));
            if (ok) requestPuppetPreview(true);
            if (callback != null) callback.onToolStateChanged();
            invalidate();
        } else if (transformType == 3) {
            ArrayList<ArrayList<float[]>> from = back ? anchorUndo : anchorRedo, to = back ? anchorRedo : anchorUndo;
            if (from.isEmpty()) { showHud(back ? "Nada que deshacer" : "Nada que rehacer"); return; }
            to.add(copyAnchors(transformAnchors));
            ArrayList<float[]> st = from.remove(from.size() - 1);
            transformAnchors.clear();
            transformAnchors.addAll(st);
            transformAnchorNode = -1;
            transformRenderDirty = true;
            showHud(back ? "Deshacer punto" : "Rehacer punto");
            invalidate();
        } else if (transformType == 2 && transformVerts != null) {
            ArrayList<float[]> from = back ? meshUndo : meshRedo, to = back ? meshRedo : meshUndo;
            if (from.isEmpty()) { showHud(back ? "Nada que deshacer" : "Nada que rehacer"); return; }
            float[] v = from.remove(from.size() - 1);
            if (v.length != transformVerts.length) return;
            to.add(transformVerts.clone());
            transformVerts = v;
            transformRenderDirty = true;
            showHud(back ? "Deshacer malla" : "Rehacer malla");
            invalidate();
        } else {
            showHud("Toca el check para aplicar o la X para cancelar");
        }
    }

    private void drawTransformPreview(Canvas c) {
        if (!transformActive || transformApplying || transformBitmap == null || transformBitmap.isRecycled()) return;
        int save = c.save();
        try {
            c.concat(view);
            if (transformType == 0) {
                drawAffine(c, transformBitmap);
                drawAffineGrid(c);
            } else if (transformType == 1 && transformVerts != null) {
                drawPerspective(c, transformBitmap);
                drawMeshGrid(c, 1, 1);
            } else if (transformType == 2 && transformVerts != null) {
                ensureTransformRenderVerts();
                if (transformRenderVerts != null)
                    c.drawBitmapMesh(transformBitmap, transformRenderMeshX, transformRenderMeshY, transformRenderVerts, 0, null, 0, transformPaint);
                drawMeshGrid(c, transformMeshX, transformMeshY);
            } else if (transformType == 3) {
                ensureTransformRenderVerts();
                if (transformRenderVerts != null)
                    c.drawBitmapMesh(transformBitmap, transformRenderMeshX, transformRenderMeshY, transformRenderVerts, 0, null, 0, transformPaint);
                drawTransformAnchors(c);
            } else if (transformType == 4) {
                drawPuppet(c);
                drawGrowPreview(c);
            }
        } catch (Throwable err) {
            // Evita que una excepcion grafica de un fabricante cierre MainActivity.
            // La restauracion se hace despues del onDraw para no mutar el lienzo a
            // mitad de una llamada nativa de Canvas.
            final Rect dirty = transformSrcRect == null ? null : new Rect(transformSrcRect);
            post(new Runnable() {
                @Override public void run() {
                    if (!transformActive || transformApplying) return;
                    try { restoreTransformSourceToProject(); } catch (Throwable ignored) {}
                    clearTransformState(true);
                    if (dirty != null) updateDisplayRegion(dirty); else refreshDisplay();
                    refreshOverlay(null);
                    msg("La previsualizacion de Transformar fallo y se cancelo de forma segura.");
                    invalidate();
                }
            });
        } finally {
            c.restoreToCount(save);
        }
    }

    private void drawAffine(Canvas c, Bitmap b) {
        float cx = transformSrcRect.exactCenterX() + transformTx;
        float cy = transformSrcRect.exactCenterY() + transformTy;
        c.save();
        c.translate(cx, cy);
        c.rotate(transformRotation);
        c.scale(transformScale, transformScale);
        c.translate(-b.getWidth() * .5f, -b.getHeight() * .5f);
        c.drawBitmap(b, 0, 0, transformPaint);
        c.restore();
    }

    private void drawPerspective(Canvas c, Bitmap b) {
        if (transformVerts == null || transformVerts.length < 8) return;
        transformPerspectiveSrc[0] = 0f; transformPerspectiveSrc[1] = 0f;
        transformPerspectiveSrc[2] = b.getWidth(); transformPerspectiveSrc[3] = 0f;
        transformPerspectiveSrc[4] = 0f; transformPerspectiveSrc[5] = b.getHeight();
        transformPerspectiveSrc[6] = b.getWidth(); transformPerspectiveSrc[7] = b.getHeight();
        transformMatrix.reset();
        if (transformMatrix.setPolyToPoly(transformPerspectiveSrc, 0, transformVerts, 0, 4))
            c.drawBitmap(b, transformMatrix, transformPaint);
    }

    private void fillAffineCorners(float[] out) {
        float hw = transformBitmap.getWidth() * .5f * transformScale;
        float hh = transformBitmap.getHeight() * .5f * transformScale;
        double a = Math.toRadians(transformRotation);
        float cos = (float) Math.cos(a), sin = (float) Math.sin(a);
        float cx = transformSrcRect.exactCenterX() + transformTx;
        float cy = transformSrcRect.exactCenterY() + transformTy;
        out[0] = cx - hw * cos + hh * sin; out[1] = cy - hw * sin - hh * cos;
        out[2] = cx + hw * cos + hh * sin; out[3] = cy + hw * sin - hh * cos;
        out[4] = cx + hw * cos - hh * sin; out[5] = cy + hw * sin + hh * cos;
        out[6] = cx - hw * cos - hh * sin; out[7] = cy - hw * sin + hh * cos;
    }

    private void drawAffineGrid(Canvas c) {
        fillAffineCorners(transformAffineCorners);
        transformGridPaint.setStrokeWidth(2f / Math.max(.05f, currentScale()));
        c.drawLine(transformAffineCorners[0], transformAffineCorners[1], transformAffineCorners[2], transformAffineCorners[3], transformGridPaint);
        c.drawLine(transformAffineCorners[2], transformAffineCorners[3], transformAffineCorners[4], transformAffineCorners[5], transformGridPaint);
        c.drawLine(transformAffineCorners[4], transformAffineCorners[5], transformAffineCorners[6], transformAffineCorners[7], transformGridPaint);
        c.drawLine(transformAffineCorners[6], transformAffineCorners[7], transformAffineCorners[0], transformAffineCorners[1], transformGridPaint);
    }

    private void drawMeshGrid(Canvas c, int cols, int rows) {
        if (transformVerts == null) return;
        transformGridPaint.setStrokeWidth(2f / Math.max(.05f, currentScale()));
        for (int y = 0; y <= rows; y++) {
            for (int x = 0; x < cols; x++) {
                int i = (y * (cols + 1) + x) * 2;
                c.drawLine(transformVerts[i], transformVerts[i + 1], transformVerts[i + 2], transformVerts[i + 3], transformGridPaint);
            }
        }
        for (int x = 0; x <= cols; x++) {
            for (int y = 0; y < rows; y++) {
                int i = (y * (cols + 1) + x) * 2;
                int j = ((y + 1) * (cols + 1) + x) * 2;
                c.drawLine(transformVerts[i], transformVerts[i + 1], transformVerts[j], transformVerts[j + 1], transformGridPaint);
            }
        }
        Paint node = transformGridPaint;
        node.setStyle(Paint.Style.FILL);
        float rr = 5f / Math.max(.05f, currentScale());
        for (int i = 0; i < transformVerts.length / 2; i++) c.drawCircle(transformVerts[i * 2], transformVerts[i * 2 + 1], rr, node);
        node.setStyle(Paint.Style.STROKE);
    }

    private Rect transformedBounds() {
        if (!transformActive || transformSrcRect == null) return null;
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        if (transformType == 0) {
            fillAffineCorners(transformAffineCorners);
            for (int i = 0; i < 4; i++) {
                float px = transformAffineCorners[i * 2], py = transformAffineCorners[i * 2 + 1];
                minX = Math.min(minX, px); minY = Math.min(minY, py);
                maxX = Math.max(maxX, px); maxY = Math.max(maxY, py);
            }
        } else if (transformType == 3) {
            ensureTransformRenderVerts();
            float[] bv = transformRenderVerts;
            if (bv == null) return new Rect(transformSrcRect);
            for (int i = 0; i < bv.length / 2; i++) {
                minX = Math.min(minX, bv[i * 2]); minY = Math.min(minY, bv[i * 2 + 1]);
                maxX = Math.max(maxX, bv[i * 2]); maxY = Math.max(maxY, bv[i * 2 + 1]);
            }
        } else if (transformType == 4) {
            float[] bb = isPuppetReady() ? puppet.deformedBounds() : null;
            if (bb == null) return new Rect(transformSrcRect);
            minX = bb[0]; minY = bb[1]; maxX = bb[2]; maxY = bb[3];
        } else if (transformVerts != null) {
            float[] bv = transformVerts;
            if (transformType == 2) { ensureTransformRenderVerts(); if (transformRenderVerts != null) bv = transformRenderVerts; }
            for (int i = 0; i < bv.length / 2; i++) {
                minX = Math.min(minX, bv[i * 2]); minY = Math.min(minY, bv[i * 2 + 1]);
                maxX = Math.max(maxX, bv[i * 2]); maxY = Math.max(maxY, bv[i * 2 + 1]);
            }
        }
        int l = Math.max(0, (int) Math.floor(minX) - 2), t = Math.max(0, (int) Math.floor(minY) - 2);
        int r = Math.min(project.w, (int) Math.ceil(maxX) + 2), b = Math.min(project.h, (int) Math.ceil(maxY) + 2);
        if (l >= r || t >= b) return null;
        return new Rect(l, t, r, b);
    }

    /** Rectangulos de a - b, sin solaparse. Ambos deben estar dentro del lienzo. */
    private ArrayList<Rect> rectMinus(Rect a, Rect b) {
        ArrayList<Rect> out = new ArrayList<Rect>();
        if (a == null || a.isEmpty()) return out;
        Rect inter = new Rect();
        if (b == null || !inter.setIntersect(a, b)) {
            out.add(new Rect(a));
            return out;
        }
        if (a.top < inter.top) out.add(new Rect(a.left, a.top, a.right, inter.top));
        if (inter.bottom < a.bottom) out.add(new Rect(a.left, inter.bottom, a.right, a.bottom));
        if (a.left < inter.left) out.add(new Rect(a.left, inter.top, inter.left, inter.bottom));
        if (inter.right < a.right) out.add(new Rect(inter.right, inter.top, a.right, inter.bottom));
        return out;
    }

    /**
     * Prepara el deshacer antes de tocar el destino. Guarda el origen una sola
     * vez y solo las partes del destino que caen fuera del origen. Cuando no
     * hay seleccion reutiliza el propio transformBitmap como respaldo: asi al
     * confirmar una imagen 4K NO nace otro int[] de ~33 MB.
     */
    private TransformApplyResult captureTransformUndo(Rect dst) {
        TransformApplyResult res = new TransformApplyResult();
        Rect src = new Rect(transformSrcRect);
        byte[] sourceSel = transformSelectionBackup;
        if (transformBackup != null) res.undoPieces.add(new TransformUndoPiece(src, transformBackup, sourceSel));
        else res.undoPieces.add(new TransformUndoPiece(src, transformBitmap));

        ArrayList<Rect> extra = rectMinus(dst, src);
        for (Rect r : extra) {
            if (r == null || r.isEmpty()) continue;
            int[] lp = copyLayerRect(transformLayer, r);
            byte[] sp = sourceSel != null ? copySelectionRect(r) : null;
            res.undoPieces.add(new TransformUndoPiece(r, lp, sp));
        }
        return res;
    }

    private void restoreTransformUndo(TransformApplyResult res) {
        if (res == null || transformLayer == null) return;
        for (TransformUndoPiece p : res.undoPieces) {
            if (p.layerBitmap != null && !p.layerBitmap.isRecycled()) {
                int[] lp = transformLayer.px();
                p.layerBitmap.getPixels(lp, p.r.top * project.w + p.r.left, project.w,
                        0, 0, p.r.width(), p.r.height());
            } else {
                restoreLayerRect(transformLayer, p.r, p.layer);
            }
            if (p.selection != null) restoreSelectionRect(p.r, p.selection);
        }
    }

    /** Devuelve true si el historial tomo propiedad de transformBitmap. */
    private boolean commitTransformUndo(TransformApplyResult res, Layer layer) {
        if (res == null || undo == null || layer == null) return false;
        boolean ownsTransformBitmap = false;
        undo.setLabel("Transformar");
        undo.begin();
        for (TransformUndoPiece p : res.undoPieces) {
            if (p.layerBitmap != null) {
                undo.recordLayerBitmapRegionBackup(layer, p.r, p.layerBitmap);
                if (p.layerBitmap == transformBitmap) ownsTransformBitmap = true;
            } else {
                undo.recordLayerRegionBackup(layer, p.r, p.layer);
            }
            if (p.selection != null) undo.recordSelectionRegionBackup(p.r, p.selection);
        }
        undo.end();
        return ownsTransformBitmap;
    }

    /** Dibuja solo la imagen, sin guias. Las coordenadas siguen siendo del lienzo. */
    private void drawTransformContent(Canvas c, Bitmap b) {
        if (transformType == 0) drawAffine(c, b);
        else if (transformType == 1) drawPerspective(c, b);
        else {
            ensureTransformRenderVerts();
            if (transformRenderVerts != null) c.drawBitmapMesh(b, transformRenderMeshX, transformRenderMeshY, transformRenderVerts, 0, null, 0, transformPaint);
        }
    }

    /**
     * Aplica por bloques de 512 px. Antes se creaba un Bitmap del destino entero
     * y otro int[] igual de grande; en 4K eso duplicaba decenas de MB y podia
     * congelar Android. Aqui el buffer temporal nunca pasa de unos pocos MB.
     */
    private void renderTransformTiled(Rect dst) {
        if (dst == null || dst.isEmpty()) return;
        if (transformType >= 2) { renderDeformTiled(dst); return; }
        final int TILE = 512;
        Bitmap tile = Bitmap.createBitmap(TILE, TILE, Bitmap.Config.ARGB_8888);
        Canvas tc = new Canvas(tile);
        int[] pix = new int[TILE * TILE];
        int[] lp = transformLayer.px();

        for (int top = dst.top; top < dst.bottom; top += TILE) {
            int th = Math.min(TILE, dst.bottom - top);
            for (int left = dst.left; left < dst.right; left += TILE) {
                int tw = Math.min(TILE, dst.right - left);
                tile.eraseColor(0);
                tc.save();
                tc.clipRect(0, 0, tw, th);
                tc.translate(-left, -top);
                drawTransformContent(tc, transformBitmap);
                tc.restore();
                tile.getPixels(pix, 0, TILE, 0, 0, tw, th);
                for (int y = 0; y < th; y++) {
                    int po = y * TILE;
                    int lo = (top + y) * project.w + left;
                    for (int x = 0; x < tw; x++) {
                        int src = pix[po + x], sa = src >>> 24;
                        if (sa != 0) lp[lo + x] = Project.over(lp[lo + x], src, sa);
                    }
                }
            }
        }

        if (transformMaskBitmap != null && transformSelectionBackup != null) {
            for (int top = dst.top; top < dst.bottom; top += TILE) {
                int th = Math.min(TILE, dst.bottom - top);
                for (int left = dst.left; left < dst.right; left += TILE) {
                    int tw = Math.min(TILE, dst.right - left);
                    tile.eraseColor(0);
                    tc.save();
                    tc.clipRect(0, 0, tw, th);
                    tc.translate(-left, -top);
                    drawTransformContent(tc, transformMaskBitmap);
                    tc.restore();
                    tile.getPixels(pix, 0, TILE, 0, 0, tw, th);
                    for (int y = 0; y < th; y++) {
                        int po = y * TILE;
                        int so = (top + y) * project.w + left;
                        for (int x = 0; x < tw; x++) {
                            int a = pix[po + x] >>> 24;
                            if (a > (project.selection[so + x] & 255)) project.selection[so + x] = (byte) a;
                        }
                    }
                }
            }
        }
        tile.recycle();
    }

    /**
     * Resultado final de Malla y Marioneta en la CPU, por bloques de 256 px,
     * con el mismo rasterizador inverso que la vista previa de Marioneta
     * (TriWarp: bilineal premultiplicada + supermuestreo al comprimir). La
     * imagen original se lee del Bitmap apartado por bloques de 64 px: no se
     * crea otra copia completa en memoria.
     */
    private void renderDeformTiled(Rect dst) {
        final float[] rest, def;
        final int[] tri, triPiece;
        final int nt;
        final PuppetMesh pm;
        final int bw = transformBitmap.getWidth(), bh = transformBitmap.getHeight();
        if (transformType == 4) {
            if (!isPuppetReady()) throw new IllegalStateException("Marioneta sin malla");
            pm = puppet.mesh();
            def = puppet.positionsCopy();
            rest = pm.rest;
            tri = pm.tri;
            nt = pm.triCount;
            triPiece = pm.triPiece;
        } else {
            ensureTransformRenderVerts();
            if (transformRenderVerts == null) return;
            int rx = transformRenderMeshX, ry = transformRenderMeshY, cols = rx + 1;
            def = transformRenderVerts.clone();
            rest = new float[cols * (ry + 1) * 2];
            int k = 0;
            for (int j = 0; j <= ry; j++)
                for (int i = 0; i <= rx; i++) {
                    rest[k++] = bw * (i / (float) rx);
                    rest[k++] = bh * (j / (float) ry);
                }
            tri = new int[rx * ry * 6];
            int q = 0;
            for (int j = 0; j < ry; j++)
                for (int i = 0; i < rx; i++) {
                    int tl = j * cols + i, tr = tl + 1, bl = tl + cols, br = bl + 1;
                    tri[q++] = tl; tri[q++] = tr; tri[q++] = br;
                    tri[q++] = tl; tri[q++] = br; tri[q++] = bl;
                }
            nt = rx * ry * 2;
            triPiece = null;
            pm = null;
        }
        PixelTiles src = new PixelTiles(bitmapReader(transformBitmap), bw, bh, 256);
        PixelTiles msk = transformMaskBitmap != null && transformSelectionBackup != null
                ? new PixelTiles(bitmapReader(transformMaskBitmap), bw, bh, 128) : null;
        final int T = 256;
        int[] buf = new int[T * T];
        int[] lp = transformLayer.px();
        for (int top = dst.top; top < dst.bottom; top += T) {
            int th = Math.min(T, dst.bottom - top);
            for (int left = dst.left; left < dst.right; left += T) {
                int tw = Math.min(T, dst.right - left);
                Arrays.fill(buf, 0, tw * th, 0);
                TriWarp.render(src, 0, 0, rest, def, tri, nt, triPiece, pm, left, top, tw, th, 1f, buf, false, true);
                for (int y = 0; y < th; y++) {
                    int po = y * tw, lo = (top + y) * project.w + left;
                    for (int x = 0; x < tw; x++) {
                        int c = buf[po + x], sa = c >>> 24;
                        if (sa != 0) lp[lo + x] = Project.over(lp[lo + x], c, sa);
                    }
                }
                if (msk != null) {
                    Arrays.fill(buf, 0, tw * th, 0);
                    TriWarp.render(msk, 0, 0, rest, def, tri, nt, triPiece, pm, left, top, tw, th, 1f, buf);
                    for (int y = 0; y < th; y++) {
                        int po = y * tw, so = (top + y) * project.w + left;
                        for (int x = 0; x < tw; x++) {
                            int a = buf[po + x] >>> 24;
                            if (a > (project.selection[so + x] & 255)) project.selection[so + x] = (byte) a;
                        }
                    }
                }
            }
        }
    }

    public void applyTransform() {
        if (!transformActive || transformApplying || transformLayer == null || transformBitmap == null) {
            if (mode == MODE_TRANSFORM && !transformApplying) showHud(puppetTool ? "Elige Malla o Marioneta para empezar" : "Elige Mover o Perspectiva para empezar");
            return;
        }
        if (transformType == 4 && !isPuppetReady()) {
            showHud("Espera: se esta creando la malla");
            return;
        }
        if (transformType == 4) {
            cancelPuppetGesture();
            if (puppetWorker != null) puppetWorker.cancelAndWait(2000);
        }
        final Rect dst = transformedBounds();
        final Rect dirty = new Rect(transformSrcRect);
        if (dst != null) dirty.union(dst);
        final Layer layer = transformLayer;
        final TransformApplyResult[] holder = new TransformApplyResult[1];

        transformApplying = true;
        setBusy(true);
        showHud("Aplicando transformacion...");
        invalidate();

        Task.run(new Runnable() {
            @Override public void run() {
                TransformApplyResult res = null;
                try {
                    res = captureTransformUndo(dst);
                    holder[0] = res;
                    renderTransformTiled(dst);
                } catch (Throwable t) {
                    if (res == null) res = new TransformApplyResult();
                    res.error = t;
                    holder[0] = res;
                    // Si ya se habia capturado todo, esto revierte tambien cualquier
                    // bloque del destino que alcanzara a modificarse.
                    if (!res.undoPieces.isEmpty()) restoreTransformUndo(res);
                    else restoreTransformSourceToProject();
                }
            }
        }, new Runnable() {
            @Override public void run() {
                TransformApplyResult res = holder[0];
                setBusy(false);
                transformApplying = false;
                if (res == null || res.error != null) {
                    // En caso de error la obra ya fue restaurada en el hilo de trabajo.
                    updateDisplayRegion(dirty);
                    if (transformSelectionBackup != null) paintOverlay(dirty);
                    clearTransformState(true);
                    msg("Transformar se cancelo sin perder la imagen. Se libero memoria para evitar que la app se cierre.");
                    invalidate();
                    return;
                }

                boolean bitmapMovedToUndo = commitTransformUndo(res, layer);
                // Las copias regionales ahora pertenecen al historial de Deshacer.
                // Si no habia seleccion, el mismo Bitmap origen pasa al historial y
                // no se duplica ni se recicla al cerrar la sesion.
                if (bitmapMovedToUndo) transformBitmap = null;
                transformBackup = null;
                transformSelectionBackup = null;
                project.markDirty();
                updateDisplayRegion(dirty);
                if (res.undoPieces.get(0).selection != null) paintOverlay(dirty);
                clearTransformState(true);
                changed();
                showHud("Transformacion aplicada");
                if (pendingTypeAfterApply >= 0) {
                    int nt = pendingTypeAfterApply;
                    pendingTypeAfterApply = -1;
                    setTransformType(nt);
                }
            }
        });
    }

    public void cancelTransform() { cancelTransform(true); }

    private void cancelTransform(boolean message) {
        if (!transformActive || transformApplying) return;
        Rect dirty = transformSrcRect == null ? project.fullRect() : new Rect(transformSrcRect);
        Rect dst = transformedBounds(); if (dst != null) dirty.union(dst);
        boolean hadSelection = transformSelectionBackup != null;
        releasePuppet();
        restoreTransformSourceToProject();
        // Transformar aun no era un cambio confirmado: volver atras no ensucia la obra
        // ni crea una entrada falsa de Deshacer.
        updateDisplayRegion(dirty);
        if (hadSelection) paintOverlay(dirty);
        clearTransformState(true);
        if (message) showHud("Transformacion cancelada");
        invalidate();
    }

    private void clearTransformState(boolean recycle) {
        transformPaperSplit = false;
        transformActive = false;
        transformApplying = false;
        transformPreparing = false;
        if (recycle) {
            if (transformBitmap != null && !transformBitmap.isRecycled()) transformBitmap.recycle();
            if (transformMaskBitmap != null && !transformMaskBitmap.isRecycled()) transformMaskBitmap.recycle();
        }
        transformBitmap = null; transformMaskBitmap = null; transformLayer = null;
        transformBackup = null; transformSelectionBackup = null; transformSrcRect = null;
        transformVerts = null; transformVertsStart = null; transformNode = -1;
        transformNavMidValid = false;
        transformAnchors.clear(); transformAnchorNode = -1;
        anchorUndo.clear(); anchorRedo.clear();
        releasePuppet();
        meshUndo.clear(); meshRedo.clear(); meshDragStarted = false;
        transformRenderVerts = null; transformRenderMeshX = transformRenderMeshY = 0; transformRenderDirty = true;
        transformTx = transformTy = transformRotation = 0f; transformScale = 1f;
    }

    public boolean isTransformActive() { return transformActive; }

    /**
     * v8.73: la app se va al fondo (Inicio, Atras, una llamada) con Transformar abierto. Mientras
     * Transformar esta abierto, la parte que se mueve NO esta en la capa (va aparte), por eso no
     * se podia guardar y se perdia lo hecho. Ahora se aplica sola (como tocar Listo; Deshacer la
     * quita). Si no se puede aplicar (Marioneta aun armando su malla), vuelve a como estaba.
     *
     * @return true si queda aplicandose en segundo plano (al terminar avisa con onChanged)
     */
    public boolean settleTransformForSave() {
        if (transformApplying) return true;
        if (!transformActive) return false;
        if (transformLayer != null && transformBitmap != null
                && (transformType != 4 || isPuppetReady())) {
            applyTransform();
            if (transformApplying) return true;
        }
        if (transformActive && !transformApplying) cancelTransform(false);
        return transformApplying;
    }

    public void setTransformType(int type) {
        type = Math.max(0, Math.min(4, type));
        if (transformApplying) return;
        // Marioneta es una herramienta aparte: no se mezcla con los tipos de Transformar.
        if (mode == MODE_TRANSFORM) type = puppetTool ? 4 : Math.min(3, type);
        boolean changedType = transformType != type;
        transformType = type;
        if (changedType) {
            transformTx = transformTy = transformRotation = 0f;
            transformScale = 1f;
            transformNavMidValid = false;
            meshUndo.clear(); meshRedo.clear();
            if (type != 4) releasePuppet();
            transformAnchorNode = -1;
            if (type == 3) transformAnchors.clear();
        }

        // Al pulsar Mover/Perspectiva/Malla la sesion nace en ese mismo toque.
        // Antes solo cambiaba el icono y habia que tocar otra vez el lienzo para
        // que aparecieran los puntos de la malla.
        if (!transformActive && !transformPreparing && mode == MODE_TRANSFORM) {
            Layer t = needLayer();
            Rect r = t == null ? null : (project.hasSelection() ? project.selectionBounds() : t.bounds(project.w, project.h));
            if (r != null && r.width() > 0 && r.height() > 0) {
                // En Malla dibuja la cuadricula en el mismo frame del toque. La copia
                // pesada del bitmap se hace despues de que Android tenga oportunidad
                // de pintar ese frame, eliminando la sensacion de boton congelado.
                transformSrcRect = new Rect(r);
                initTransformVerts();
                transformPreparing = true;
                invalidate();
                postDelayed(new Runnable() {
                    @Override public void run() {
                        if (mode != MODE_TRANSFORM || !transformPreparing) return;
                        startTransformSession();
                    }
                }, 24);
            }
        } else if (transformActive && changedType) {
            if (transformType == 4) {
                // La Malla anterior se descarta: se parte del original apartado.
                transformVerts = null;
                startPuppet();
            } else {
                initTransformVerts();
            }
        }
        invalidate();
    }

    public int getTransformType() { return transformType; }

    public void changeTransformGrid(int delta) {
        // Compatibilidad con llamadas antiguas: cambia filas y columnas a la vez.
        transformMeshX = Math.max(2, Math.min(12, transformMeshX + delta));
        transformMeshY = Math.max(2, Math.min(12, transformMeshY + delta));
        if (transformActive && transformType == 2) initTransformVerts();
        showHud("Malla " + transformMeshX + " x " + transformMeshY);
        invalidate();
    }

    public void changeTransformGridCols(int delta) {
        transformMeshX = Math.max(2, Math.min(12, transformMeshX + delta));
        if (transformActive && transformType == 2) initTransformVerts();
        showHud("Columnas " + transformMeshX + "  •  Filas " + transformMeshY);
        invalidate();
    }

    public void changeTransformGridRows(int delta) {
        transformMeshY = Math.max(2, Math.min(12, transformMeshY + delta));
        if (transformActive && transformType == 2) initTransformVerts();
        showHud("Columnas " + transformMeshX + "  •  Filas " + transformMeshY);
        invalidate();
    }

    public int getTransformGrid() { return transformMeshX; }
    public int getTransformGridCols() { return transformMeshX; }
    public int getTransformGridRows() { return transformMeshY; }

    public void setTransformMeshSmoothness(float v) {
        transformMeshSmoothness = Math.max(0f, Math.min(1f, v));
        transformRenderDirty = true;
        showHud("Suavidad malla " + Math.round(transformMeshSmoothness * 100f) + "%");
        invalidate();
    }

    public float getTransformMeshSmoothness() { return transformMeshSmoothness; }

    // ==================================================================
    // Difuminar, borrosidad y licuar. Todo trabaja por regiones pequenas.
    // ==================================================================

    private boolean isLocalEffectMode() {
        return mode == MODE_SMUDGE || mode == MODE_BLUR || mode == MODE_LIQUIFY;
    }

    private void clearEffectStrokeBackup() {
        blurCov.clear();
        blurTiles.clear();
        effectStrokeBackupTiles.clear();
        effectStrokeBackupLayer = null;
        effectStrokeBackupFailed = false;
    }

    /**
     * Guarda el estado anterior SOLO de los bloques que este stamp va a escribir.
     * Asi un pincel grande no necesita copiar toda la capa al empezar el trazo.
     */
    private boolean captureEffectStrokeBackup(Rect area) {
        if (strokeLayer == null || area == null || project == null) return false;
        if (effectStrokeBackupFailed) return false;
        if (effectStrokeBackupLayer != strokeLayer) {
            clearEffectStrokeBackup();
            effectStrokeBackupLayer = strokeLayer;
        }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx0 = Math.max(0, area.left / LIQUIFY_TILE);
        int ty0 = Math.max(0, area.top / LIQUIFY_TILE);
        int tx1 = Math.max(tx0, (Math.max(area.left, area.right - 1)) / LIQUIFY_TILE);
        int ty1 = Math.max(ty0, (Math.max(area.top, area.bottom - 1)) / LIQUIFY_TILE);
        int[] src = strokeLayer.px();
        try {
            for (int ty = ty0; ty <= ty1; ty++) {
                for (int tx = tx0; tx <= tx1; tx++) {
                    int key = ty * cols + tx;
                    if (effectStrokeBackupTiles.get(key) != null) continue;
                    int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
                    int tw = Math.min(LIQUIFY_TILE, project.w - left);
                    int th = Math.min(LIQUIFY_TILE, project.h - top);
                    int[] tile = new int[tw * th];
                    for (int yy = 0; yy < th; yy++)
                        System.arraycopy(src, (top + yy) * project.w + left, tile, yy * tw, tw);
                    effectStrokeBackupTiles.put(key, tile);
                }
            }
            return true;
        } catch (OutOfMemoryError e) {
            effectStrokeBackupFailed = true;
            msg("No alcanzo memoria para continuar este trazo. Suelta el dedo y prueba con un pincel menor");
            return false;
        }
    }

    /** Restaura el trazo local cuando entra un segundo dedo o se cancela. */
    private void restoreEffectStrokeBackup() {
        if (project == null || effectStrokeBackupLayer == null) {
            clearEffectStrokeBackup();
            return;
        }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int[] dst = effectStrokeBackupLayer.px();
        for (int i = 0; i < effectStrokeBackupTiles.size(); i++) {
            int key = effectStrokeBackupTiles.keyAt(i);
            int[] tile = effectStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            for (int yy = 0; yy < th; yy++)
                System.arraycopy(tile, yy * tw, dst, (top + yy) * project.w + left, tw);
        }
        project.markDirty();
        clearEffectStrokeBackup();
    }

    /**
     * Pasa los bloques originales directamente al historial. No se crea otra copia
     * gigante del rectangulo union del trazo, por lo que Deshacer tambien queda ligero.
     */
    private void recordEffectStrokeUndo(String label) {
        if (undo == null || project == null || effectStrokeBackupLayer == null
                || effectStrokeBackupTiles.size() == 0) {
            clearEffectStrokeBackup();
            return;
        }
        Layer layer = effectStrokeBackupLayer;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        undo.setLabel(label);
        undo.begin();
        for (int i = 0; i < effectStrokeBackupTiles.size(); i++) {
            int key = effectStrokeBackupTiles.keyAt(i);
            int[] tile = effectStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            Rect r = new Rect(left, top, left + tw, top + th);
            undo.recordLayerRegionBackup(layer, r, tile);
        }
        undo.end();
        // UndoManager es ahora dueno de los int[]; clear solo suelta nuestras referencias.
        blurCov.clear();
        blurTiles.clear();
        effectStrokeBackupTiles.clear();
        effectStrokeBackupLayer = null;
        effectStrokeBackupFailed = false;
    }

    /** Pixel de la capa tal como estaba al iniciar el trazo, sin una copia completa. */
    private int strokeOriginalAt(int index) {
        if (project == null || strokeLayer == null || index < 0 || index >= project.w * project.h) return 0;
        if (mode == MODE_HEAL && pxBackup != null && pxBackup.length == project.w * project.h) return pxBackup[index];
        int x = index % project.w, y = index / project.w;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx = x / LIQUIFY_TILE, ty = y / LIQUIFY_TILE;
        int[] tile = effectStrokeBackupTiles.get(ty * cols + tx);
        if (tile == null) return strokeLayer.px()[index];
        int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
        int tw = Math.min(LIQUIFY_TILE, project.w - left);
        return tile[(y - top) * tw + (x - left)];
    }

    /** Restaura solo una zona desde los bloques capturados, conservando el respaldo. */
    private void restoreLayerBackupRegion(Rect area) {
        if (project == null || effectStrokeBackupLayer == null || area == null) return;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int[] dst = effectStrokeBackupLayer.px();
        for (int i = 0; i < effectStrokeBackupTiles.size(); i++) {
            int key = effectStrokeBackupTiles.keyAt(i);
            int[] tile = effectStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            Rect tr = new Rect(left, top, left + tw, top + th);
            if (!tr.intersect(area)) continue;
            for (int y = tr.top; y < tr.bottom; y++) {
                int srcOff = (y - top) * tw + (tr.left - left);
                int dstOff = y * project.w + tr.left;
                System.arraycopy(tile, srcOff, dst, dstOff, tr.width());
            }
        }
        project.markDirty();
    }

    /** Captura tambien la zona origen de Clonar antes de que el propio trazo pueda tocarla. */
    private void captureCloneSourceBackup(Rect dest) {
        if (dest == null || project == null || mode == MODE_HEAL) return;
        int[] xs = {dest.left, Math.max(dest.left, dest.right - 1), dest.left, Math.max(dest.left, dest.right - 1)};
        int[] ys = {dest.top, dest.top, Math.max(dest.top, dest.bottom - 1), Math.max(dest.top, dest.bottom - 1)};
        int minX = project.w, minY = project.h, maxX = -1, maxY = -1;
        for (int k = 0; k < 4; k++) {
            int src = cloneSource(xs[k], ys[k]);
            if (src < 0) continue;
            int sy = src / project.w, sx = src - sy * project.w;
            minX = Math.min(minX, sx); minY = Math.min(minY, sy);
            maxX = Math.max(maxX, sx); maxY = Math.max(maxY, sy);
        }
        if (maxX < 0) return;
        Rect r = new Rect(Math.max(0, minX - 3), Math.max(0, minY - 3),
                Math.min(project.w, maxX + 4), Math.min(project.h, maxY + 4));
        captureEffectStrokeBackup(r);
    }

    private void clearSelectionStrokeBackup() {
        selectionStrokeBackupTiles.clear();
        selectionStrokeBackupFailed = false;
    }

    private boolean captureSelectionStrokeBackup(Rect area) {
        if (project == null || area == null || selectionStrokeBackupFailed) return false;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx0 = Math.max(0, area.left / LIQUIFY_TILE);
        int ty0 = Math.max(0, area.top / LIQUIFY_TILE);
        int tx1 = Math.max(tx0, Math.max(area.left, area.right - 1) / LIQUIFY_TILE);
        int ty1 = Math.max(ty0, Math.max(area.top, area.bottom - 1) / LIQUIFY_TILE);
        try {
            for (int ty = ty0; ty <= ty1; ty++) {
                for (int tx = tx0; tx <= tx1; tx++) {
                    int key = ty * cols + tx;
                    if (selectionStrokeBackupTiles.get(key) != null) continue;
                    int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
                    int tw = Math.min(LIQUIFY_TILE, project.w - left);
                    int th = Math.min(LIQUIFY_TILE, project.h - top);
                    byte[] tile = new byte[tw * th];
                    for (int yy = 0; yy < th; yy++)
                        System.arraycopy(project.selection, (top + yy) * project.w + left, tile, yy * tw, tw);
                    selectionStrokeBackupTiles.put(key, tile);
                }
            }
            return true;
        } catch (OutOfMemoryError e) {
            selectionStrokeBackupFailed = true;
            msg("No alcanzo memoria para continuar la seleccion. Prueba un pincel menor");
            return false;
        }
    }

    private void restoreSelectionStrokeBackup() {
        if (project == null) { clearSelectionStrokeBackup(); return; }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        for (int i = 0; i < selectionStrokeBackupTiles.size(); i++) {
            int key = selectionStrokeBackupTiles.keyAt(i);
            byte[] tile = selectionStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            for (int yy = 0; yy < th; yy++)
                System.arraycopy(tile, yy * tw, project.selection, (top + yy) * project.w + left, tw);
        }
        clearSelectionStrokeBackup();
    }

    private void recordSelectionStrokeUndo(String label) {
        if (undo == null || project == null || selectionStrokeBackupTiles.size() == 0) {
            clearSelectionStrokeBackup();
            return;
        }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        undo.setLabel(label);
        undo.begin();
        for (int i = 0; i < selectionStrokeBackupTiles.size(); i++) {
            int key = selectionStrokeBackupTiles.keyAt(i);
            byte[] tile = selectionStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            undo.recordSelectionRegionBackup(new Rect(left, top, left + tw, top + th), tile);
        }
        undo.end();
        selectionStrokeBackupTiles.clear();
        selectionStrokeBackupFailed = false;
    }

    // ==================================================================
    // Especial v8.22 (Licuar): integracion con el motor en segundo plano
    // ==================================================================
    //
    // Hilo principal: lee el dedo (con historial y hora de cada punto), lo envia
    // al motor y, una vez por fotograma (Choreographer), copia a la capa los
    // bloques de 64x64 que el motor ya termino. No calcula campo ni pixeles.
    // Al levantar el dedo NO se congela: el motor termina lo pendiente y avisa;
    // entonces se registra Deshacer con los bloques originales del trazo.

    private final com.pacco.animecut.core.LiquifySession.Listener liquifyListener =
            new com.pacco.animecut.core.LiquifySession.Listener() {
                @Override public void onTilesReady(com.pacco.animecut.core.LiquifySession s) {
                    requestLiquifyFrame();
                }

                @Override public void onStrokeFinished(final com.pacco.animecut.core.LiquifySession s,
                        final int id, final boolean cancelled) {
                    handler.post(new Runnable() {
                        @Override public void run() {
                            if (s == liquifySession) onLiquifyStrokeFinished(id);
                        }
                    });
                }
            };

    private final Runnable liquifyScheduleFrame = new Runnable() {
        @Override public void run() {
            liquifyWake.set(false);
            scheduleLiquifyFrame();
        }
    };

    private final android.view.Choreographer.FrameCallback liquifyFrame =
            new android.view.Choreographer.FrameCallback() {
                @Override public void doFrame(long frameTimeNanos) {
                    liquifyFrameScheduled = false;
                    com.pacco.animecut.core.LiquifySession s = liquifySession;
                    if (s == null) return;
                    if (s.isFailed()) {
                        failLiquify();
                        return;
                    }
                    boolean active = drawing && mode == MODE_LIQUIFY && liquifyApplyId != 0;
                    // Contraer/Expandir/Suavizar/Restaurar actuan con el dedo quieto:
                    // el tiempo avanza en cada fotograma (no cada 165 ms como antes).
                    if (active && !multi && liquifyType != 0)
                        s.tick(android.os.SystemClock.uptimeMillis());
                    if (active) updateLiquifyVisible();
                    android.os.Trace.beginSection("Especial:copiar-bloques");
                    try {
                        drainLiquifyTiles();
                    } finally {
                        android.os.Trace.endSection();
                    }
                    if (active || liquifyPendingCommit != 0) scheduleLiquifyFrame();
                }
            };

    /** Puede llamarse desde el hilo del motor. */
    private void requestLiquifyFrame() {
        if (liquifyWake.compareAndSet(false, true)) handler.post(liquifyScheduleFrame);
    }

    private void scheduleLiquifyFrame() {
        if (liquifyFrameScheduled) return;
        liquifyFrameScheduled = true;
        android.view.Choreographer.getInstance().postFrameCallback(liquifyFrame);
    }

    private void updateLiquifyVisible() {
        com.pacco.animecut.core.LiquifySession s = liquifySession;
        if (s == null || project == null) return;
        Rect v = visibleDetail();
        if (v != null) s.setVisible(v.left, v.top, v.right, v.bottom);
    }

    /**
     * Sesion de Especial para la capa. Se conserva entre trazos (Restaurar vuelve
     * al original de la sesion) mientras nadie mas haya cambiado los pixeles.
     */
    private boolean ensureLiquifySession(Layer l) {
        if (l == null || project == null) return false;
        int[] px = l.px();
        if (liquifySession != null && liquifySessionLayer == l
                && liquifySession.source.layerPixels() == px
                && liquifySessionVersion == project.version
                && !liquifySession.isFailed()) return true;
        dropLiquifySession();
        try {
            int step = com.pacco.animecut.core.LiquifyField.recommendedStep(project.w, project.h);
            if (com.pacco.animecut.core.LiquifySession.tracer == null)
                com.pacco.animecut.core.LiquifySession.tracer = LIQUIFY_TRACER;
            liquifySession = new com.pacco.animecut.core.LiquifySession(px, project.w, project.h,
                    step, liquifyListener, LIQUIFY_THREADS);
            liquifySessionLayer = l;
            liquifySessionVersion = project.version;
            return true;
        } catch (OutOfMemoryError e) {
            dropLiquifySession();
            msg("No alcanzo memoria para Especial. Usa un lienzo o pincel menor.");
            return false;
        }
    }

    /** Confirma un trazo pendiente (si lo hay) y cierra la sesion. */
    private void resetLiquifySession() {
        finishLiquifyCommitNow();
        dropLiquifySession();
    }

    /** Cierra la sesion SIN confirmar nada (cambio de proyecto, liberar memoria). */
    private void dropLiquifySession() {
        com.pacco.animecut.core.LiquifySession s = liquifySession;
        liquifySession = null;
        liquifySessionLayer = null;
        liquifyApplyId = 0;
        liquifyPendingCommit = 0;
        liquifyAppliedValid = false;
        if (s != null) s.close();
    }

    private void startLiquifyStroke(float ix, float iy) {
        // El trazo anterior debe quedar en el historial antes de abrir otro.
        finishLiquifyCommitNow();
        if (!beginLayerStroke()) return;
        if (!ensureLiquifySession(strokeLayer)) {
            drawing = false;
            clearEffectStrokeBackup();
            return;
        }
        painted = 0;
        liquifyStrokeId++;
        liquifyApplyId = liquifyStrokeId;
        liquifyAppliedValid = false;
        lastX = ix;
        lastY = iy;
        byte[] sel = selectionActive && project.selection != null ? project.selection : null;
        updateLiquifyVisible();
        long now = android.os.SystemClock.uptimeMillis();
        liquifySession.beginStroke(liquifyApplyId, liquifyType, brushRadius, effectStrength,
                effectSoftness, sel, ix, iy, now);
        scheduleLiquifyFrame();
    }

    private void moveLiquifyStroke(float ix, float iy) {
        if (!drawing || liquifySession == null || liquifyApplyId == 0) return;
        liquifySession.moveTo(ix, iy, liquifyEventTime);
        lastX = ix;
        lastY = iy;
        scheduleLiquifyFrame();
        invalidate();
    }

    private void endLiquifyStroke() {
        com.pacco.animecut.core.LiquifySession s = liquifySession;
        if (s == null || liquifyApplyId == 0) {
            liquifyApplyId = 0;
            clearEffectStrokeBackup();
            strokeRect = null;
            invalidate();
            return;
        }
        // El motor aplica el tramo final, renderiza lo pendiente y avisa.
        // La interfaz sigue libre mientras tanto.
        liquifyPendingCommit = liquifyApplyId;
        s.endStroke(liquifyApplyId);
        strokeRect = null;
        scheduleLiquifyFrame();
        invalidate();
    }

    /** Segundo dedo al comenzar: el trazo se deshace sin tocar el historial. */
    private void cancelLiquifyStroke() {
        int id = liquifyApplyId;
        liquifyApplyId = 0;
        if (liquifySession != null && id != 0) liquifySession.cancelStroke(id);
        Rect r = liquifyAppliedValid ? new Rect(liquifyAppliedRect) : null;
        liquifyAppliedValid = false;
        // La capa vuelve exactamente al estado previo; el motor restaura su campo.
        restoreEffectStrokeBackup();
        if (project != null) liquifySessionVersion = project.version;
        strokeRect = null;
        if (r != null) updateDisplayRegion(r);
        invalidate();
    }

    /** Copia a la capa los bloques terminados del trazo actual (siempre el contenido mas nuevo). */
    private void drainLiquifyTiles() {
        com.pacco.animecut.core.LiquifySession s = liquifySession;
        if (s == null) return;
        int apply = liquifyApplyId;
        int[] px = s.source.layerPixels();
        Rect union = null;
        beginBatch();
        try {
            int k;
            while ((k = s.pollReady()) >= 0) {
                if (apply == 0 || s.tileGeneration(k) != apply || strokeLayer == null
                        || strokeLayer.px() != px) continue;
                s.tileRect(k, liquifyTileRect);
                liquifyTmpRect.set(liquifyTileRect[0], liquifyTileRect[1],
                        liquifyTileRect[2], liquifyTileRect[3]);
                // Guardar el bloque ORIGINAL para Deshacer antes de sobrescribirlo.
                if (!captureEffectStrokeBackup(liquifyTmpRect)) continue;
                s.copyTile(k, px);
                if (union == null) union = new Rect(liquifyTmpRect);
                else union.union(liquifyTmpRect);
            }
            if (union != null) {
                if (liquifyAppliedValid) liquifyAppliedRect.union(union);
                else { liquifyAppliedRect.set(union); liquifyAppliedValid = true; }
                project.markDirty();
                updateDisplayRegion(union);
            }
        } finally {
            endBatch();
        }
        if (union != null && project != null && liquifyPendingCommit == 0)
            liquifySessionVersion = project.version;
    }

    /** El motor termino de renderizar el trazo: aplicar lo ultimo y registrar Deshacer. */
    private void onLiquifyStrokeFinished(int id) {
        if (id != liquifyPendingCommit || project == null) return;
        drainLiquifyTiles();
        liquifyPendingCommit = 0;
        liquifyApplyId = 0;
        liquifyAppliedValid = false;
        if (liquifySession != null && liquifySession.isFailed()) {
            failLiquify();
            return;
        }
        if (effectStrokeBackupTiles.size() > 0) {
            recordEffectStrokeUndo("Especial");
            project.markDirty();
            wire = null;
            changed();
        } else {
            clearEffectStrokeBackup();
        }
        liquifySessionVersion = project.version;
        if (!detailValid && !busy) scheduleDetail();
        invalidate();
    }

    /** Espera (normalmente unos ms) a que el motor termine y confirma el trazo. */
    private void finishLiquifyCommitNow() {
        int id = liquifyPendingCommit;
        if (id == 0) return;
        com.pacco.animecut.core.LiquifySession s = liquifySession;
        if (s != null) s.awaitStroke(id, 5000L);
        onLiquifyStrokeFinished(id);
    }

    /** Error grave del motor (p. ej. memoria): se conserva lo aplicado y se cierra. */
    private void failLiquify() {
        boolean wasDrawing = drawing && mode == MODE_LIQUIFY;
        if (wasDrawing) drawing = false;
        if (effectStrokeBackupTiles.size() > 0 && project != null) {
            recordEffectStrokeUndo("Especial");
            project.markDirty();
            changed();
        }
        dropLiquifySession();
        msg("Especial libero memoria; continua con una zona o pincel mas pequeno");
        invalidate();
    }

    private void moveEffectStroke(float x, float y) {
        float dx = x - lastX, dy = y - lastY;
        float dist = (float) Math.hypot(dx, dy);
        if (dist < 0.08f) return;

        // Solo Difuminar pasa por aqui (Borrosidad usa el recorrido comun desde v8.23).
        float step = Math.max(1f, brushRadius * 0.36f);
        int n = Math.max(1, (int) Math.ceil(dist / step));
        // Un limite de seguridad alto protege ante eventos anormalmente grandes.
        n = Math.min(n, 48);
        float px = lastX, py = lastY;
        beginBatch();
        try {
            for (int i = 1; i <= n; i++) {
                float t = i / (float) n;
                float nx = lastX + dx * t, ny = lastY + dy * t;
                stampEffect(nx, ny, nx - px, ny - py);
                px = nx; py = ny;
            }
        } finally {
            endBatch();
        }
        lastX = x; lastY = y;
    }

    private void stampEffect(float cx, float cy, float dx, float dy) {
        if (!drawing || strokeLayer == null) return;
        if (mode == MODE_SMUDGE && Math.abs(dx) + Math.abs(dy) < 0.02f) return;
        Rect out = disk(cx, cy);
        if (out == null) return;

        // Difuminar/Borrosidad conservan el motor local anterior.
        if (!captureEffectStrokeBackup(out)) return;
        if (mode == MODE_BLUR) effectBlur(cx, cy, out);
        else if (mode == MODE_SMUDGE) effectWarp(cx, cy, dx, dy, out, 0);
        grow(out);
        updateDisplayRegion(out);
        painted++;
    }

    /**
     * Borrosidad v8.23. Antes cada estampa volvia a desenfocar 3x3 lo ya
     * desenfocado: un trazo lento (mas eventos) desenfocaba mucho mas que uno
     * rapido. Ahora el resultado de cada pixel es
     *     mezcla(original del trazo, original desenfocado, cobertura maxima x Fuerza)
     * Igual sin importar la velocidad o cuantas veces pase el pincel en el mismo
     * trazo. Otro trazo encima desenfoca mas, como en otras apps de dibujo.
     * Desenfoque gaussiano aproximado en alfa premultiplicado (sin halo oscuro).
     */
    private final android.util.SparseArray<byte[]> blurCov = new android.util.SparseArray<byte[]>();
    /** Original desenfocado por bloques de 64x64, calculado una sola vez por trazo. */
    private final android.util.SparseArray<int[]> blurTiles = new android.util.SparseArray<int[]>();
    private int[] blurSrc, blurOut;
    private float[] blurTmp;

    private void effectBlur(float cx, float cy, Rect out) {
        int w = project.w, h = project.h;
        int T = LIQUIFY_TILE, cols = (w + T - 1) / T;
        float r = Math.max(1f, rad());
        int rb = Math.max(1, Math.min(24, Math.round(r * .15f)));
        if (blurTiles.size() > 0 && blurTileRadius != rb) blurTiles.clear();
        blurTileRadius = rb;
        // 1. Bloques que faltan: un solo desenfoque sobre su rectangulo comun.
        int tx0 = out.left / T, ty0 = out.top / T, tx1 = (out.right - 1) / T, ty1 = (out.bottom - 1) / T;
        int mx0 = Integer.MAX_VALUE, my0 = Integer.MAX_VALUE, mx1 = -1, my1 = -1;
        for (int ty = ty0; ty <= ty1; ty++) for (int tx = tx0; tx <= tx1; tx++) {
            if (blurTiles.get(ty * cols + tx) != null) continue;
            mx0 = Math.min(mx0, tx); my0 = Math.min(my0, ty); mx1 = Math.max(mx1, tx); my1 = Math.max(my1, ty);
        }
        if (mx1 >= 0 && !blurMissingTiles(mx0, my0, mx1, my1, rb)) return;
        // 2. Mezcla con la cobertura maxima del trazo.
        float str = Math.max(.05f, Math.min(1f, effectStrength));
        int[] px = strokeLayer.px();
        for (int y = out.top; y < out.bottom; y++) {
            int row = y * w, ty = y / T;
            for (int x = out.left; x < out.right; x++) {
                float f = fastBrushFalloff(x, y, cx, cy) * selectionFactor(row + x);
                if (f <= .001f) continue;
                int key = ty * cols + x / T;
                byte[] cv = blurCov.get(key);
                if (cv == null) { cv = new byte[T * T]; blurCov.put(key, cv); }
                int ci = (y - ty * T) * T + x % T;
                int nv = Math.round(f * 255f);
                if (nv <= (cv[ci] & 255)) continue;
                cv[ci] = (byte) nv;
                int[] bt = blurTiles.get(key);
                if (bt == null) continue;
                int tw = Math.min(T, w - (x / T) * T);
                int blurred = bt[(y - ty * T) * tw + x % T];
                px[row + x] = com.pacco.animecut.core.AlphaColors.mix(strokeOriginalAt(row + x), blurred, nv / 255f * str);
            }
        }
        project.markDirty();
    }

    private int blurTileRadius;

    private boolean blurMissingTiles(int tx0, int ty0, int tx1, int ty1, int rb) {
        int w = project.w, h = project.h, T = LIQUIFY_TILE, cols = (w + T - 1) / T;
        int m = 3 * rb + 1;
        int left = tx0 * T, top = ty0 * T, right = Math.min(w, (tx1 + 1) * T), bottom = Math.min(h, (ty1 + 1) * T);
        Rect sr = new Rect(Math.max(0, left - m), Math.max(0, top - m), Math.min(w, right + m), Math.min(h, bottom + m));
        int sw = sr.width(), sh = sr.height(), n = sw * sh;
        try {
            if (blurSrc == null || blurSrc.length < n) { blurSrc = null; blurOut = null; blurSrc = new int[n]; blurOut = new int[n]; }
            if (blurTmp == null || blurTmp.length < 4 * n) { blurTmp = null; blurTmp = new float[4 * n]; }
        } catch (OutOfMemoryError e) {
            blurSrc = blurOut = null;
            blurTmp = null;
            msg("No alcanzo memoria para este tamano de Borrosidad");
            return false;
        }
        for (int y = sr.top; y < sr.bottom; y++) {
            int j = (y - sr.top) * sw - sr.left, row = y * w;
            for (int x = sr.left; x < sr.right; x++) blurSrc[j + x] = strokeOriginalAt(row + x);
        }
        com.pacco.animecut.core.PremulColor.blur(blurSrc, sw, sh, rb, blurTmp, blurOut);
        try {
            for (int ty = ty0; ty <= ty1; ty++) for (int tx = tx0; tx <= tx1; tx++) {
                int key = ty * cols + tx;
                if (blurTiles.get(key) != null) continue;
                int l = tx * T, t = ty * T, tw = Math.min(T, w - l), th = Math.min(T, h - t);
                int[] tile = new int[tw * th];
                for (int yy = 0; yy < th; yy++)
                    System.arraycopy(blurOut, (t + yy - sr.top) * sw + (l - sr.left), tile, yy * tw, tw);
                blurTiles.put(key, tile);
            }
        } catch (OutOfMemoryError e) {
            blurTiles.clear();
            msg("No alcanzo memoria para este tamano de Borrosidad");
            return false;
        }
        return true;
    }

    /** Falloff del pincel sin sqrt por pixel: conserva centro firme y borde suave. */
    private float fastBrushFalloff(int x, int y, float cx, float cy) {
        float dx = x + .5f - cx, dy = y + .5f - cy;
        float r = Math.max(1f, rad());
        float outer = r + .5f;
        float d2 = dx * dx + dy * dy, o2 = outer * outer;
        if (d2 >= o2) return 0f;
        float inner = Math.max(0f, Math.min(r, r * hardness));
        float i2 = inner * inner;
        if (d2 <= i2) return 1f;
        float u = (o2 - d2) / Math.max(1f, o2 - i2);
        u = Math.max(0f, Math.min(1f, u));
        return u * u * (3f - 2f * u);
    }

    /** Motor antiguo usado solo por Difuminar. */
    private void effectWarp(float cx, float cy, float dragX, float dragY, Rect out, int type) {
        int w = project.w, h = project.h;
        float r = Math.max(1f, brushRadius), r2 = r * r;
        float base = Math.max(.03f, Math.min(1f, effectStrength));
        boolean special = false;

        // Limita saltos de eventos sin volver el efecto debil. En Arrastrar el
        // desplazamiento sigue el dedo, pero nunca estira una franja enorme de golpe.
        float drag = (float) Math.hypot(dragX, dragY);
        float maxDrag = Math.max(1f, r * (special ? .24f : .14f));
        if (drag > maxDrag && drag > .0001f) {
            float k = maxDrag / drag;
            dragX *= k;
            dragY *= k;
            drag = maxDrag;
        }

        float extra;
        if (type == 0) extra = drag * (special ? 1.05f : .90f) + 4f;
        else if (type == 1 || type == 2) extra = r * (.12f + .18f * base) + 4f;
        else extra = r * .08f + 4f;

        int pad = Math.max(4, (int) Math.ceil(extra));
        Rect srcR = new Rect(Math.max(0, out.left - pad), Math.max(0, out.top - pad),
                Math.min(w, out.right + pad), Math.min(h, out.bottom + pad));
        int rw = srcR.width(), rh = srcR.height(), need = rw * rh;
        if (!ensureEffectTmp(need)) return;
        int[] px = strokeLayer.px();
        for (int yy = 0; yy < rh; yy++)
            System.arraycopy(px, (srcR.top + yy) * w + srcR.left, effectTmp, yy * rw, rw);

        // Suavidad modifica la fuerza geometrica cerca del borde. No mezcla colores:
        // el pixel se mueve, no se difumina.
        float soft = Math.max(0f, Math.min(1f, effectSoftness));
        float innerFrac = .84f - .46f * soft;
        innerFrac = Math.max(.28f, Math.min(.88f, innerFrac));
        float inner2 = r2 * innerFrac * innerFrac;
        float denom = Math.max(1f, r2 - inner2);

        for (int y = out.top; y < out.bottom; y++) {
            int row = y * w;
            for (int x = out.left; x < out.right; x++) {
                float vx = x + .5f - cx, vy = y + .5f - cy;
                float d2 = vx * vx + vy * vy;
                if (d2 >= r2) continue;

                float fall;
                if (d2 <= inner2) fall = 1f;
                else {
                    float q = (r2 - d2) / denom;
                    q = Math.max(0f, Math.min(1f, q));
                    fall = q * q * (3f - 2f * q);
                }
                if (fall <= .001f) continue;

                float sel = selectionFactor(row + x);
                if (sel <= .001f) continue;
                float weight = fall * sel;
                float sx = x + .5f, sy = y + .5f;

                if (type == 0) {
                    if (special) {
                        // Arrastrar tipo Licuar: la geometria sigue el dedo. El falloff
                        // reduce el desplazamiento hacia el borde, no la nitidez.
                        float gain = (.72f + .24f * base) * weight;
                        sx -= dragX * gain;
                        sy -= dragY * gain;
                    } else {
                        float gain = (.35f + .65f * base) * weight;
                        sx -= dragX * gain;
                        sy -= dragY * gain;
                    }
                } else if (type == 1) {
                    // Contraer: trae la textura hacia el centro.
                    float k = 1f + (.045f + .115f * base) * weight;
                    sx = cx + vx * k;
                    sy = cy + vy * k;
                } else if (type == 2) {
                    // Expandir: empuja la textura hacia afuera.
                    float k = Math.max(.76f, 1f - (.045f + .115f * base) * weight);
                    sx = cx + vx * k;
                    sy = cy + vy * k;
                } else {
                    // Remolino local. El angulo cae suavemente hasta cero en el borde.
                    float a = (.045f + .16f * base) * weight;
                    float a2 = a * a;
                    float sn = a * (1f - a2 / 6f);
                    float cs = 1f - a2 * .5f;
                    sx = cx + vx * cs + vy * sn;
                    sy = cy - vx * sn + vy * cs;
                }

                // v8.23: sx/sy estan en coordenadas continuas (centro = x + .5);
                // el buffer usa indices de pixel. Antes faltaba restar .5: cada
                // estampa desplazaba medio pixel y emborronaba aunque no hubiera arrastre.
                int sample = sampleTmpBilinear(sx - .5f - srcR.left, sy - .5f - srcR.top, rw, rh);
                float blend = Math.min(1f, weight * (.34f + .46f * base));
                // Mezcla en alfa premultiplicado: lo transparente no aporta negro.
                if (blend > .001f) px[row + x] = com.pacco.animecut.core.AlphaColors.mix(px[row + x], sample, blend);
            }
        }
        project.markDirty();
    }

    private float selectionFactor(int i) {
        if (!selectionActive || project == null || project.selection == null) return 1f;
        return (project.selection[i] & 255) / 255f;
    }

    private boolean ensureEffectTmp(int n) {
        try {
            if (effectTmp == null || effectTmp.length < n) effectTmp = new int[Math.max(n, n + n / 4)];
            return true;
        } catch (OutOfMemoryError e) {
            effectTmp = null;
            msg("No alcanzo la memoria para este pincel");
            return false;
        }
    }

    private int sampleTmpNearest(float x, float y, int w, int h) {
        if (w <= 0 || h <= 0) return 0;
        int ix = Math.max(0, Math.min(w - 1, Math.round(x)));
        int iy = Math.max(0, Math.min(h - 1, Math.round(y)));
        return effectTmp[iy * w + ix];
    }

    /** Bilineal del buffer temporal en alfa PREMULTIPLICADO (v8.23, sin halos oscuros). */
    private int sampleTmpBilinear(float x, float y, int w, int h) {
        return com.pacco.animecut.core.PremulColor.bilinear(effectTmp, w, h, x, y);
    }

    // ==================================================================
    // Capas
    // ==================================================================

    public void layersChanged() {
        belowEpoch++;
        project.markDirty();
        if (undo != null) undo.rebalance();
        wire = null;
        refreshDisplay();
        changed();
    }

    public void setActive(int i) {
        if (project == null) return;
        if (i >= project.layers.size()) return;
        if (i < Project.SEL) return;
        if (i >= 0) lastNormalLayer = project.layers.get(i);
        if (project.active == i) return;
        project.active = i;
        // antes se empacaba aqui mismo y el toque se trababa; ahora va despues,
        // y si falta memoria al pintar, ensureMemory empaca en ese momento
        changed();
    }

    // ==================================================================
    // v8.33: Recortar con IA. La IA trabaja sobre una COPIA de lectura de la capa (el editor de
    // AiCutView); aqui solo se pide la capa y se aplica el resultado con UN Deshacer.
    // ==================================================================

    // ==================================================================
    // v8.36: "pinta encima del personaje que quieres" (marca para la IA). Celeste, gruesa,
    // en coordenadas de la imagen. Un dedo pinta; dos dedos mueven y hacen zoom; un toque con
    // dos dedos borra el ultimo trazo. Al soltar, si no pintas mas en un momento, corre la IA.
    // ==================================================================

    public interface AiMarkListener { void onAiMarkReady(float[] hint); }

    private static final class MarkStroke {
        float r;
        float[] p = new float[64];
        int n;
        void add(float x, float y) {
            if (n + 2 > p.length) p = Arrays.copyOf(p, p.length * 2);
            p[n++] = x; p[n++] = y;
        }
    }

    private boolean aiMark, aiMarkDrawing;
    private final ArrayList<MarkStroke> aiStrokes = new ArrayList<>();
    private AiMarkListener aiMarkListener;
    private Paint aiMarkPaint;
    private long aiMarkDown;
    private float aiMarkMoved;
    private int aiMarkMaxPtr;
    /** Espera despues de soltar el dedo antes de correr la IA (para seguir pintando). */
    public static final int AI_MARK_WAIT_MS = 1100;
    private final Runnable aiMarkFire = new Runnable() {
        @Override public void run() { fireAiMarkNow(); }
    };

    public void startAiMark(AiMarkListener l) {
        aiMark = true;
        aiMarkDrawing = false;
        aiStrokes.clear();
        aiMarkListener = l;
        handler.removeCallbacks(aiMarkFire);
        showHud("Pinta encima del personaje (las veces que quieras) y toca Quitar fondo", 3200);
        invalidate();
    }

    /** v8.39: borra el ultimo trazo de la marca. false si no habia. */
    public boolean undoAiMarkStroke() {
        if (!aiMark || aiStrokes.isEmpty()) return false;
        aiStrokes.remove(aiStrokes.size() - 1);
        invalidate();
        if (callback != null) callback.onToolStateChanged();
        return true;
    }

    public boolean isAiMarking() { return aiMark; }

    public boolean aiMarkHasStrokes() { return !aiStrokes.isEmpty(); }

    public void cancelAiMark() {
        aiMark = false;
        aiMarkDrawing = false;
        aiStrokes.clear();
        aiMarkListener = null;
        handler.removeCallbacks(aiMarkFire);
        invalidate();
        if (callback != null) callback.onToolStateChanged();   // v8.39: esconde la barra de la marca
    }

    /** Corre la IA con lo pintado (si hay algo). */
    public void fireAiMarkNow() {
        handler.removeCallbacks(aiMarkFire);
        if (!aiMark || aiStrokes.isEmpty()) return;
        float[] h = aiMarkHint();
        AiMarkListener l = aiMarkListener;
        cancelAiMark();
        if (l != null && h != null) l.onAiMarkReady(h);
    }

    /** (x, y, radio) por punto; (0, 0, -1) separa trazos. */
    public float[] aiMarkHint() {
        int n = 0;
        for (MarkStroke m : aiStrokes) n += m.n / 2 * 3 + 3;
        if (n == 0) return null;
        float[] h = new float[n];
        int k = 0;
        for (MarkStroke m : aiStrokes) {
            for (int i = 0; i + 1 < m.n; i += 2) { h[k++] = m.p[i]; h[k++] = m.p[i + 1]; h[k++] = m.r; }
            h[k++] = 0f; h[k++] = 0f; h[k++] = -1f;
        }
        return h;
    }

    private void aiMarkPoint(MarkStroke m, float sx, float sy) {
        imagePoint(sx, sy);
        float x = point[0], y = point[1];
        if (m.n >= 2) {
            float dx = x - m.p[m.n - 2], dy = y - m.p[m.n - 1];
            if (dx * dx + dy * dy < (m.r * 0.25f) * (m.r * 0.25f)) return;
        }
        m.add(x, y);
    }

    private boolean onAiMarkTouch(MotionEvent e) {
        int action = e.getActionMasked();
        int pc = e.getPointerCount();
        long now = System.currentTimeMillis();
        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                handler.removeCallbacks(aiMarkFire);
                multi = false;
                navActive = false;
                lastPinchDistance = 0f;
                aiMarkDown = now;
                aiMarkMoved = 0f;
                aiMarkMaxPtr = 1;
                lastSX = e.getX();
                lastSY = e.getY();
                MarkStroke m = new MarkStroke();
                float d = getResources().getDisplayMetrics().density;
                m.r = Math.max(2f, 26f * d / Math.max(.05f, currentScale()));
                aiMarkPoint(m, e.getX(), e.getY());
                aiStrokes.add(m);
                aiMarkDrawing = true;
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                multi = true;
                aiMarkMaxPtr = Math.max(aiMarkMaxPtr, pc);
                // el trazo recien empezado era el primer dedo de un gesto de dos: no cuenta
                if (aiMarkDrawing && !aiStrokes.isEmpty()) aiStrokes.remove(aiStrokes.size() - 1);
                aiMarkDrawing = false;
                if (pc >= 2) navBegin(e, -1);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (multi) {
                    if (pc >= 2) twoFingers(e);
                    aiMarkMoved += Math.abs(e.getX() - lastSX) + Math.abs(e.getY() - lastSY);
                    lastSX = e.getX();
                    lastSY = e.getY();
                    return true;
                }
                if (aiMarkDrawing && !aiStrokes.isEmpty()) {
                    MarkStroke m = aiStrokes.get(aiStrokes.size() - 1);
                    int hs = e.getHistorySize();
                    for (int k = 0; k < hs; k++) aiMarkPoint(m, e.getHistoricalX(0, k), e.getHistoricalY(0, k));
                    aiMarkPoint(m, e.getX(), e.getY());
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                if (pc - 1 >= 2) navBegin(e, e.getActionIndex());
                else navActive = false;
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                boolean up = action == MotionEvent.ACTION_UP;
                if (multi) {
                    // toque corto con dos dedos: borra el ultimo trazo
                    if (up && now - aiMarkDown < 280 && aiMarkMoved < 40f && aiMarkMaxPtr == 2 && !aiStrokes.isEmpty()) {
                        aiStrokes.remove(aiStrokes.size() - 1);
                        showHud(aiStrokes.isEmpty() ? "Sin marca" : "Ultimo trazo borrado");
                    }
                } else if (aiMarkDrawing && !up && !aiStrokes.isEmpty()) {
                    aiStrokes.remove(aiStrokes.size() - 1);
                }
                aiMarkDrawing = false;
                multi = false;
                navActive = false;
                // v8.39: ya NO corre sola al soltar el dedo: pintas lo que quieras y luego tocas
                // "Quitar fondo" (o "Toda la imagen" sin pintar)
                if (callback != null) callback.onToolStateChanged();
                invalidate();
                return true;
            }
        }
        return true;
    }

    private void drawAiMark(Canvas c) {
        if (aiStrokes.isEmpty()) return;
        if (aiMarkPaint == null) {
            aiMarkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            aiMarkPaint.setStyle(Paint.Style.STROKE);
            aiMarkPaint.setStrokeCap(Paint.Cap.ROUND);
            aiMarkPaint.setStrokeJoin(Paint.Join.ROUND);
            aiMarkPaint.setColor(0xFF22C8FF);
        }
        // una capa con transparencia: donde los trazos se cruzan no se oscurece
        int sc = c.saveLayerAlpha(0, 0, getWidth(), getHeight(), 110);
        c.concat(view);
        for (MarkStroke m : aiStrokes) {
            aiMarkPaint.setStrokeWidth(m.r * 2f);
            if (m.n == 2) {
                aiMarkPaint.setStyle(Paint.Style.FILL);
                c.drawCircle(m.p[0], m.p[1], m.r, aiMarkPaint);
                aiMarkPaint.setStyle(Paint.Style.STROKE);
                continue;
            }
            Path path = new Path();
            path.moveTo(m.p[0], m.p[1]);
            for (int i = 2; i + 1 < m.n; i += 2) path.lineTo(m.p[i], m.p[i + 1]);
            c.drawPath(path, aiMarkPaint);
        }
        c.restoreToCount(sc);
    }

    /** Capa para la IA (null y aviso si no se puede). */
    public Layer aiTargetLayer() {
        if (project == null || busy) return null;
        if (mode == MODE_TRANSFORM && transformActive) { msg("Termina o cancela Transformar primero"); return null; }
        Layer t = needLayer();
        if (t == null) return null;
        try { t.px(); } catch (OutOfMemoryError e) { msg("Falta memoria para abrir la capa"); return null; }
        return t;
    }

    /** Zona que mira la IA: lo seleccionado (recuadro) o toda la capa. */
    public Rect aiCropRect() {
        if (project == null) return null;
        if (project.hasSelection()) {
            Rect b = project.selectionBounds();
            if (b != null && b.width() >= 16 && b.height() >= 16) return b;
        }
        return project.fullRect();
    }

    /**
     * Aplica el recorte de la IA. newLayer = capa nueva "Recorte IA" encima (la original queda
     * intacta y se oculta); si no, cambia la capa elegida. Un solo Deshacer en los dos casos.
     */
    public void applyAiCut(Layer src, int[] out, boolean newLayer) {
        if (project == null || src == null || out == null || out.length != project.w * project.h) return;
        int idx = project.layers.indexOf(src);
        if (idx < 0) { msg("La capa ya no existe"); return; }
        undo.setLabel("Recortar con IA");
        undo.begin();
        if (newLayer) {
            undo.recordStruct();
            undo.recordProps();
            Layer nl = new Layer(uniqueName("Recorte IA"), out);
            project.layers.add(idx + 1, nl);
            src.visible = false;
            project.active = idx + 1;
            lastNormalLayer = nl;
            undo.end();
            layersChanged();
        } else {
            // v8.35: la copia de antes de recortar = lo que Restaurar puede devolver
            takeBgSnapshot(src);
            undo.recordLayer(src, project.fullRect());
            System.arraycopy(out, 0, src.px(), 0, out.length);
            undo.end();
            invalidateBgAnalysis();
            pixelsChanged(project.fullRect());
            refreshDisplay();
        }
        if (newLayer) showHud("Recorte en capa nueva (la original quedo oculta)");
        else showHud("Fondo quitado · Restaurar o Deshacer lo devuelven", 2600);
    }

    /**
     * v8.36: la capa tiene dibujo Y transparencia (un personaje recortado)? Muestra de 48x48
     * puntos, sin abrir la capa.
     */
    public boolean layerHasTransparency(Layer l) {
        if (project == null || l == null) return false;
        int w = project.w, h = project.h, clear = 0, solid = 0, n = 0;
        for (int gy = 0; gy < 48; gy++) {
            int y = Math.min(h - 1, (int) ((gy + .5f) * h / 48f));
            for (int gx = 0; gx < 48; gx++) {
                int x = Math.min(w - 1, (int) ((gx + .5f) * w / 48f));
                int a = l.at(x, y, w) >>> 24;
                n++;
                if (a < 128) clear++; else solid++;
            }
        }
        return clear * 20 >= n && solid * 20 >= n;
    }

    public void addEmptyLayer() {
        undo.setLabel("Capa nueva");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        project.layers.add(Math.min(at, project.layers.size()),
                new Layer(uniqueName("capa"), project.w, project.h));
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
    }

    /**
     * v8.39: capa nueva llena de un color (hoja blanca u otro color), encima de la elegida.
     * Sirve como pagina nueva para pintar.
     */
    public void addFilledLayer(int color) {
        if (project == null) return;
        int[] px;
        try {
            px = new int[project.w * project.h];
        } catch (OutOfMemoryError e) {
            msg("Falta memoria para una hoja de color");
            return;
        }
        java.util.Arrays.fill(px, color | 0xFF000000);
        undo.setLabel("Hoja de color");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        project.layers.add(Math.min(at, project.layers.size()), new Layer(uniqueName("hoja"), px));
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
    }

    /** Crea una capa de pintura en modo Superponer y la deja activa. */
    public void addOverlayPaintLayer() {
        if (project == null) return;
        undo.setLabel("Capa Superposición");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        Layer l = new Layer(uniqueName("Superposición"), project.w, project.h);
        l.mode = Layer.MODE_OVERLAY;
        project.layers.add(Math.min(at, project.layers.size()), l);
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
        mode = MODE_PAINT;
        showHud("Capa Superposición lista para pintar");
    }

    // ---------------- v8.52: Toques suaves, voltear capa, quitar blanco, difuminar capa ----------------
    /** Cuanto se funde cada trazo en una capa de Toques (0 = nada, 100 = mucho). */
    private int softBlendPct = 60;

    /** v8.53: hay un dedo pintando ahora mismo. */
    public boolean isTouching() { return drawing; }

    public void setSoftBlend(int pct) { softBlendPct = Math.max(0, Math.min(100, pct)); }
    public int getSoftBlend() { return softBlendPct; }

    public static final int SOFT_COLOR = 0, SOFT_SHADOW = 1, SOFT_LIGHT = 2;
    private static final String[] SOFT_NAMES = {"✦ Toque color", "✦ Toque sombra", "✦ Toque luz"};

    /** Que tipo de toque es la capa (por su nombre; si la renombraron cuenta como color). */
    public static int softKind(Layer l) {
        if (l == null || l.name == null) return SOFT_COLOR;
        if (l.name.startsWith(SOFT_NAMES[1])) return SOFT_SHADOW;
        if (l.name.startsWith(SOFT_NAMES[2])) return SOFT_LIGHT;
        return SOFT_COLOR;
    }

    /** Difumina solo lo que agrego el ultimo trazo (la diferencia con como estaba). */
    private void softBlendStroke() {
        Layer t = strokeLayer;
        if (t == null || project == null || strokeRect == null) return;
        float sigma = Math.max(1.5f, getBrushSize() * softBlendPct / 100f * 0.45f);
        int m = (int) Math.ceil(sigma * 3f) + 2;
        Rect r = new Rect(strokeRect);
        r.inset(-m, -m);
        if (!r.intersect(0, 0, project.w, project.h)) return;
        if ((long) r.width() * r.height() > 4_500_000L) return;
        if (!captureEffectStrokeBackup(r)) return;
        try {
            int rw = r.width(), rh = r.height();
            int[] orig = new int[rw * rh];
            for (int y = 0; y < rh; y++) {
                int row = (r.top + y) * project.w + r.left;
                for (int x = 0; x < rw; x++) orig[y * rw + x] = strokeOriginalAt(row + x);
            }
            com.pacco.animecut.core.SoftBlend.apply(t.px(), project.w, r.left, r.top, rw, rh, orig, sigma);
        } catch (OutOfMemoryError e) {
            return;
        }
        strokeRect.union(r);
        project.markDirty();
        updateDisplayRegion(r);
    }

    /**
     * La capa de Toques del tipo pedido: si ya existe se elige; si no, se crea UNA encima de
     * 'over' (la capa de color), con flecha (solo se ve dentro de lo pintado).
     * Color: Normal; si debajo hay lineas de manga, Multiplicar (no tapa la tinta).
     * Sombra: Multiplicar. Luz: Superponer (el "dar vida" de Ibis).
     */
    public Layer softLayer(int kind, Layer over) {
        if (project == null) return null;
        for (int i = 0; i < project.layers.size(); i++) {
            Layer l = project.layers.get(i);
            if (l.role == Layer.ROLE_SOFT && softKind(l) == kind && l.name.startsWith(SOFT_NAMES[kind])) {
                project.active = i;
                if (!l.visible) { l.visible = true; layersChangedAsync(); }
                changed();
                return l;
            }
        }
        if (over == null || over.role == Layer.ROLE_SOFT) {
            over = null;
            for (int i = project.layers.size() - 1; i >= 0 && over == null; i--)
                if (project.layers.get(i).role == Layer.ROLE_TONE) over = project.layers.get(i);
            for (int i = project.layers.size() - 1; i >= 0 && over == null; i--) {
                Layer l = project.layers.get(i);
                if (l.role == Layer.ROLE_BASE || l.role == Layer.ROLE_COLOR) over = l;
            }
            if (over == null) over = project.activeLayer();
            if (over != null && over.role == Layer.ROLE_SOFT) over = null;
        }
        int at = over == null ? project.layers.size() : project.layers.indexOf(over) + 1;
        if (over != null && over.role == Layer.ROLE_INK) {
            // la tinta: los toques van arriba de los colores que tenga encima
            while (at < project.layers.size() && project.layers.get(at).mode == Layer.MODE_MULTIPLY
                    && project.layers.get(at).role != Layer.ROLE_SOFT) at++;
        }
        while (at < project.layers.size() && project.layers.get(at).role == Layer.ROLE_SOFT) at++;
        Layer l = new Layer(SOFT_NAMES[kind], project.w, project.h);
        l.role = Layer.ROLE_SOFT;
        // v8.53: fuerzas de las guias (sombra ~40 %, rubor ~45 %, luz Superponer ~70 % como en Ibis)
        if (kind == SOFT_SHADOW) { l.mode = Layer.MODE_MULTIPLY; l.opacity = 105; }
        else if (kind == SOFT_LIGHT) { l.mode = Layer.MODE_OVERLAY; l.opacity = 178; }
        else { l.mode = linesUnder(over) ? Layer.MODE_MULTIPLY : Layer.MODE_NORMAL; l.opacity = 120; }
        l.clip = at > 0 && over != null && !mostlyOpaque(over) ? true : false;
        undo.setLabel("Toques");
        undo.recordStruct();
        project.layers.add(Math.min(at, project.layers.size()), l);
        project.active = project.layers.indexOf(l);
        layersChanged();
        return l;
    }

    /** Hay tinta de manga debajo (o la capa misma tiene las lineas y es opaca). */
    private boolean linesUnder(Layer over) {
        if (project == null) return false;
        if (project.mangaMode) return true;
        if (over == null) return false;
        if (over.role == Layer.ROLE_INK || over.role == Layer.ROLE_BASE || over.role == Layer.ROLE_TONE
                || over.role == Layer.ROLE_COLOR || over.mode == Layer.MODE_MULTIPLY) return true;
        return mostlyOpaque(over);
    }

    /** La capa cubre casi todo el lienzo (una imagen entera): recortar con flecha no sirve. */
    private boolean mostlyOpaque(Layer l) {
        if (l == null || project == null) return false;
        int w = project.w, h = project.h, step = Math.max(1, (int) Math.sqrt((double) w * h / 40000.0));
        int tot = 0, op = 0;
        for (int y = 0; y < h; y += step)
            for (int x = 0; x < w; x += step) {
                tot++;
                if ((l.at(x, y, w) >>> 24) > 200) op++;
            }
        return tot > 0 && op * 10 >= tot * 9;
    }

    /** Quita las capas de Toques que quedaron vacias (se puede deshacer). */
    public void dropEmptySoftLayers() {
        if (project == null) return;
        boolean rec = false;
        for (int i = project.layers.size() - 1; i >= 0; i--) {
            Layer l = project.layers.get(i);
            if (l.role != Layer.ROLE_SOFT || l.bounds(project.w, project.h) != null) continue;
            if (project.layers.size() <= 1) break;
            if (!rec) { undo.setLabel("Toques"); undo.recordStruct(); rec = true; }
            project.layers.remove(i);
            if (project.active >= project.layers.size()) project.active = project.layers.size() - 1;
            else if (project.active > i) project.active--;
        }
        if (rec) layersChanged();
    }

    /** Difumina toda la capa (Mezclar todo). amount 0..100 (radio relativo al lienzo). */
    private boolean blurring;

    public void blurLayer(final Layer l, int amount) {
        if (project == null || l == null || l.locked) { if (l != null && l.locked) msg("La capa esta bloqueada"); return; }
        if (blurring) return;
        Rect b = l.bounds(project.w, project.h);
        if (b == null) { msg("La capa esta vacia"); return; }
        final float sigma = Math.max(1.5f, Math.max(project.w, project.h) * (0.002f + amount / 100f * 0.03f));
        int m = (int) Math.ceil(sigma * 3f) + 2;
        b.inset(-m, -m);
        if (!b.intersect(0, 0, project.w, project.h)) return;
        // v8.69: se calcula por detras (antes congelaba la app varios segundos en capas grandes).
        // Se trabaja sobre una copia; si mientras tanto pintas en esa capa, tus trazos se respetan.
        final Rect r = new Rect(b);
        final int W = project.w, rw = r.width(), rh = r.height();
        final int[] before, work;
        try {
            int[] px = l.px();
            before = new int[rw * rh];
            for (int y = 0; y < rh; y++) System.arraycopy(px, (r.top + y) * W + r.left, before, y * rw, rw);
            work = before.clone();
        } catch (OutOfMemoryError e) {
            msg("Falta memoria para difuminar");
            return;
        }
        final Project owner = project;
        final boolean[] ok = {false};
        blurring = true;
        showHud("Fundiendo…", 8000);
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    com.pacco.animecut.core.SoftBlend.apply(work, rw, 0, 0, rw, rh, null, sigma);
                    ok[0] = true;
                } catch (OutOfMemoryError e) { ok[0] = false; }
            }
        }, new Runnable() {
            @Override public void run() {
                blurring = false;
                if (owner != project || !project.layers.contains(l)) { showHud("", 1); return; }
                if (!ok[0]) { msg("Falta memoria para difuminar"); return; }
                undo.setLabel("Fundir todo");
                undo.begin();
                undo.recordLayer(l, r);
                undo.end();
                int[] px = l.px();
                for (int y = 0; y < rh; y++) {
                    int row = (r.top + y) * W + r.left, o = y * rw;
                    for (int x = 0; x < rw; x++)
                        if (px[row + x] == before[o + x]) px[row + x] = work[o + x];   // lo pintado mientras tanto se queda
                }
                project.markDirty();
                pixelsChanged(r);
                showHud("Listo: toques fundidos", 1400);
                changed();
            }
        });
    }

    /** Voltear SOLO esta capa (como Ibis). */
    public void flipLayer(Layer l, boolean horizontal) {
        if (project == null || l == null) return;
        if (l.locked) { msg("La capa esta bloqueada"); return; }
        undo.setLabel(horizontal ? "Voltear capa ↔" : "Voltear capa ↕");
        undo.begin();
        undo.recordLayer(l, project.fullRect());
        undo.end();
        l.setPx(Project.flipInts(l.px(), project.w, project.h, horizontal));
        project.markDirty();
        refreshDisplay();
        changed();
    }

    // ---- v8.53: Sacar lineas con vista previa en la misma capa (Cancelar la deja como estaba) ----
    private int[] linesBackup;
    private Layer linesLayer;

    public boolean linesBegin(Layer l) {
        if (project == null || l == null) return false;
        if (l.locked) { msg("La capa esta bloqueada"); return false; }
        try { linesBackup = l.px().clone(); } catch (OutOfMemoryError e) { msg("Falta memoria"); return false; }
        linesLayer = l;
        return true;
    }

    public void linesPreview(int white, int black, int mid, boolean color) {
        if (linesLayer == null || linesBackup == null) return;
        int[] px = linesLayer.px();
        if (px.length != linesBackup.length) return;
        com.pacco.animecut.core.SoftBlend.extractLines(linesBackup, px, white, black, mid, color);
        project.markDirty();
        refreshDisplay();
    }

    public void linesEnd(boolean keep) {
        if (linesLayer == null || linesBackup == null) { linesLayer = null; linesBackup = null; return; }
        if (keep) {
            undo.setLabel("Sacar lineas");
            undo.begin();
            undo.recordLayerFromBackup(linesLayer, project.fullRect(), linesBackup);
            undo.end();
        } else {
            System.arraycopy(linesBackup, 0, linesLayer.px(), 0, linesBackup.length);
        }
        linesLayer = null;
        linesBackup = null;
        project.markDirty();
        refreshDisplay();
        changed();
    }

    /** Quitar blanco (Blanco claro de Ibis): lo blanco se vuelve transparente. */
    public void whiteToAlpha(Layer l, boolean keepColor) {
        if (project == null || l == null) return;
        if (l.locked) { msg("La capa esta bloqueada"); return; }
        undo.setLabel(keepColor ? "Quitar blanco (color)" : "Quitar blanco");
        undo.begin();
        undo.recordLayer(l, project.fullRect());
        undo.end();
        com.pacco.animecut.core.SoftBlend.whiteToAlpha(l.px(), keepColor);
        project.markDirty();
        refreshDisplay();
        changed();
    }

    /** Una imagen de afuera como capa nueva, centrada y ajustada al lienzo. */
    public void addImageLayer(Bitmap img) { addImageLayer(img, false); }

    /**
     * v8.72: como en Alight Motion: la imagen entra en modo NORMAL (tu decides la mezcla) y
     * encima de la capa elegida, o como FONDO (debajo de todo: un paisaje detras del personaje).
     */
    public void addImageLayer(Bitmap img, boolean asBackground) {
        // va directo a la memoria grande del telefono, sin pasar por la de Java
        float s = Math.min((float) project.w / img.getWidth(), (float) project.h / img.getHeight());
        int tw = Math.max(1, Math.round(img.getWidth() * s)), th = Math.max(1, Math.round(img.getHeight() * s));
        Layer nl;
        try {
            Bitmap sc = Bitmap.createScaledBitmap(img, tw, th, true);
            Bitmap crop = Layer.newBitmap(tw, th);
            int[] row = new int[tw];
            for (int y = 0; y < th; y++) {
                sc.getPixels(row, 0, tw, 0, y, tw, 1);
                crop.setPixels(row, 0, tw, 0, y, tw, 1);
            }
            if (sc != img) sc.recycle();
            int ox = (project.w - tw) / 2, oy = (project.h - th) / 2;
            nl = Layer.fromBitmap(uniqueName("imagen"), ox, oy, crop, project.w, project.h);
        } catch (OutOfMemoryError e) {
            msg("La imagen es muy grande para agregarla");
            return;
        }
        boolean light = false;
        try { light = looksLikeLightOnBlack(img); } catch (Throwable ignored) { }
        undo.setLabel(asBackground ? "Imagen de fondo" : "Agregar imagen");
        undo.recordStruct();
        int at = asBackground ? 0 : Math.max(0, project.active + 1);
        project.layers.add(Math.min(at, project.layers.size()), nl);
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
        // ya NO se cambia sola la mezcla: solo un consejo si parece una luz con fondo negro
        if (light) showHud("Parece una luz con fondo negro: en Mezcla elige \"Pantalla\" y el negro desaparece", 3600);
    }

    // ---- propiedades de la capa elegida (como Ibis) ----

    public void setLayerMode(Layer l, int mode) {
        if (l == null) return;
        if (l.mode == mode) return;
        undo.setLabel("Modo de mezcla");
        undo.recordProps();
        l.mode = mode;
        layersChangedAsync();
    }

    public void setLayerClip(Layer l, boolean on) {
        if (l == null) return;
        if (on && project.layers.indexOf(l) <= 0) {
            msg("La capa de mas abajo no puede tener recorte: no hay base");
            return;
        }
        undo.setLabel(on ? "Recorte" : "Quitar recorte");
        undo.recordProps();
        l.clip = on;
        if (!on) l.clipOut = false;
        layersChangedAsync();
    }

    /** v8.71 Enmascarar como Alight: 0 = nada, 1 = Recorte (solo sobre la capa de abajo), 2 = Excluir. */
    public boolean canClip(Layer l) {
        return l != null && project != null && project.layers.indexOf(l) > 0;
    }

    /**
     * v8.71 "Color de la luz": tine la capa (una luz blanca queda dorada, azul...). El centro muy
     * brillante sigue casi blanco, como una luz de verdad. Por detras; se deshace con Deshacer.
     */
    public void tintLayer(final Layer l, final int color) {
        if (project == null || l == null || l.locked) { if (l != null && l.locked) msg("La capa esta bloqueada"); return; }
        if (blurring) return;
        final Rect r = l.bounds(project.w, project.h);
        if (r == null) { msg("La capa esta vacia"); return; }
        final int W = project.w, rw = r.width(), rh = r.height();
        final int[] before, work;
        try {
            int[] px = l.px();
            before = new int[rw * rh];
            for (int y = 0; y < rh; y++) System.arraycopy(px, (r.top + y) * W + r.left, before, y * rw, rw);
            work = new int[rw * rh];
        } catch (OutOfMemoryError e) {
            msg("Falta memoria para cambiar el color");
            return;
        }
        final Project owner = project;
        blurring = true;
        showHud("Cambiando el color de la luz…", 6000);
        Task.run(new Runnable() {
            @Override public void run() {
                int tr = (color >> 16) & 255, tg = (color >> 8) & 255, tb = color & 255;
                // tabla por brillo (0..255): rapido aunque la imagen sea grande
                int[] lr = new int[256], lg = new int[256], lb = new int[256];
                for (int v = 0; v < 256; v++) {
                    float f = v / 255f, core = f * f * f * f;
                    lr[v] = Math.min(255, Math.round(v * tr / 255f + (255 - tr) * core));
                    lg[v] = Math.min(255, Math.round(v * tg / 255f + (255 - tg) * core));
                    lb[v] = Math.min(255, Math.round(v * tb / 255f + (255 - tb) * core));
                }
                for (int i = 0; i < before.length; i++) {
                    int c = before[i], a = c >>> 24;
                    if (a == 0) { work[i] = 0; continue; }
                    int R = (c >> 16) & 255, G = (c >> 8) & 255, B = c & 255;
                    int v = Math.max(R, Math.max(G, B));
                    work[i] = (a << 24) | (lr[v] << 16) | (lg[v] << 8) | lb[v];
                }
            }
        }, new Runnable() {
            @Override public void run() {
                blurring = false;
                if (owner != project || !project.layers.contains(l)) { showHud("", 1); return; }
                undo.setLabel("Color de la luz");
                undo.begin();
                undo.recordLayer(l, r);
                undo.end();
                int[] px = l.px();
                for (int y = 0; y < rh; y++) {
                    int row = (r.top + y) * W + r.left, o = y * rw;
                    for (int x = 0; x < rw; x++)
                        if (px[row + x] == before[o + x]) px[row + x] = work[o + x];
                }
                project.markDirty();
                pixelsChanged(r);
                showHud("Listo: color de la luz cambiado (Deshacer lo devuelve)", 1600);
                changed();
            }
        });
    }

    /**
     * v8.71: una foto de luz con fondo NEGRO (destellos, rayos, bokeh) en modo Normal tapa todo con
     * un cuadro negro. Si la imagen es asi, se pone sola en Pantalla: el negro desaparece.
     */
    static boolean looksLikeLightOnBlack(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int step = Math.max(1, (int) Math.sqrt((double) w * h / 40000.0));
        int[] row = new int[w];
        long n = 0, dark = 0, bright = 0, border = 0, borderDark = 0;
        for (int y = 0; y < h; y += step) {
            b.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x += step) {
                int c = row[x];
                if ((c >>> 24) < 200) continue;
                int v = Math.max((c >> 16) & 255, Math.max((c >> 8) & 255, c & 255));
                n++;
                if (v < 40) dark++;
                if (v > 200) bright++;
                if (x < step * 3 || x >= w - step * 3 || y < step * 3 || y >= h - step * 3) {
                    border++;
                    if (v < 50) borderDark++;
                }
            }
        }
        return n > 0 && dark * 100 >= n * 45 && bright * 1000 >= n * 3 && border > 0 && borderDark * 100 >= border * 70;
    }

    /** v8.24: marcar la capa como referencia de contornos para el balde. */
    public void setLayerReference(Layer l, boolean on) {
        if (l == null || project == null) return;
        undo.setLabel("Referencia del balde");
        undo.recordProps();
        l.reference = on;
        project.markDirty();
        changed();
    }

    public void setLayerAlphaLock(Layer l, boolean on) {
        if (l == null) return;
        undo.setLabel("Bloquear alfa");
        undo.recordProps();
        l.alphaLock = on;
        changed();
    }

    public void duplicateActive() {
        Layer a = target();
        if (a == null) {
            msg("Toca una capa para duplicarla");
            return;
        }
        Layer copy;
        try {
            copy = a.copy(uniqueName(a.name), project.w, project.h);
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para duplicar. Combina o borra alguna capa.");
            return;
        }
        undo.setLabel("Duplicar");
        undo.recordStruct();
        project.layers.add(project.active + 1, copy);
        project.active++;
        layersChanged();
    }

    /** v8.24: la capa elegida parece una imagen a color (para avisar en "Lineas"). */
    public boolean activeLooksColored() {
        Layer a = target();
        return a != null && LineArt.isColored(a.px());
    }

    /**
     * v8.24 Vista previa de "Lineas" a tamano real: un recorte de 'side' x 'side'
     * alrededor del centro de lo que se ve en pantalla. @return {w, h, pixeles...}
     */
    public int[] previewLines(LineArt.Extract e, int side) {
        Layer a = target();
        if (a == null || project == null) return null;
        float[] c = {getWidth() / 2f, getHeight() / 2f};
        Matrix inv = new Matrix();
        view.invert(inv);
        inv.mapPoints(c);
        int w = project.w, h = project.h;
        int cw = Math.min(side, w), ch = Math.min(side, h);
        int x0 = Math.max(0, Math.min(w - cw, Math.round(c[0]) - cw / 2));
        int y0 = Math.max(0, Math.min(h - ch, Math.round(c[1]) - ch / 2));
        int[] crop = new int[cw * ch];
        int[] px = a.px();
        for (int y = 0; y < ch; y++) System.arraycopy(px, (y0 + y) * w + x0, crop, y * cw, cw);
        int[] lines = LineArt.extract(crop, cw, ch, e);
        int[] out = new int[2 + lines.length];
        out[0] = cw;
        out[1] = ch;
        System.arraycopy(lines, 0, out, 2, lines.length);
        return out;
    }

    /**
     * v8.24 "Lineas" (une el "Lineas" de v8.23 y el antiguo "Preparar para colorear"):
     * crea encima de la capa elegida una capa "Lineas" con las lineas sobre
     * transparente. La capa original NO cambia. Con withColor, crea ademas una capa
     * "Color" vacia entre las dos para pintar debajo de las lineas. Deshacer quita todo.
     */
    public void extractLinesLayer(final LineArt.Extract e, final boolean withColor) {
        final Layer a = target();
        if (a == null || project == null) {
            msg("Toca en Capas la capa del dibujo");
            return;
        }
        if (busy) return;
        final Project owner = project;
        final int[][] out = new int[1][];
        if (!ensureMemory((long) project.w * project.h * (e.colored ? 20L : 8L))) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    out[0] = LineArt.extract(a.px(), owner.w, owner.h, e);
                } catch (OutOfMemoryError err) {
                    out[0] = null;
                }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project) return;
                int idx = project.layers.indexOf(a);
                if (out[0] == null || idx < 0) {
                    msg("No alcanzo la memoria para separar las lineas");
                    return;
                }
                undo.setLabel("Lineas");
                undo.recordStruct();
                Layer ln = new Layer(uniqueName("Lineas"), out[0]);
                project.layers.add(idx + 1, ln);
                if (withColor) {
                    Layer col = new Layer(uniqueName(COLOR_LAYER_NAME), project.w, project.h);
                    // v8.27: si todavia no hay capa de color automatica, esta lo es (el balde la reutiliza)
                    if (autoColorLayer() == null) col.role = Layer.ROLE_COLOR;
                    project.layers.add(idx + 1, col);
                    project.active = idx + 1;
                    lastNormalLayer = col;
                } else {
                    project.active = idx + 1;
                    lastNormalLayer = ln;
                }
                layersChanged();
                showHud(withColor ? "Listo: pinta en \"Color\"; las lineas quedan arriba. Deshacer lo quita"
                        : "Lineas en capa aparte (el original no cambio). Deshacer la quita");
            }
        });
    }

    /** Lo seleccionado de la capa elegida pasa a una capa nueva. Con cortar, se quita de la original. */
    public void layerFromSelection(boolean cut) {
        layerFromSelection(cut, 0, null);
    }

    /**
     * Crea una parte lista para animar. overlap conserva unos pixeles extra
     * alrededor de la seleccion para que al rotar brazos/cabeza en Alight Motion
     * no aparezcan huecos en las uniones. Al cortar, se elimina solo el nucleo
     * seleccionado y el solapamiento queda compartido entre ambas capas.
     */
    public void layerFromSelection(boolean cut, int overlap, String preferredName) {
        Layer a = target();
        if (a == null && project != null && !project.layers.isEmpty()) {
            if (lastNormalLayer != null && project.layers.contains(lastNormalLayer)) a = lastNormalLayer;
            else a = project.layers.get(Math.max(0, project.layers.size() - 1));
        }
        if (a == null) {
            msg("Toca en Capas la capa de donde quieres sacar la parte");
            return;
        }
        if (cut && a.locked) {
            msg("\"" + a.name + "\" esta bloqueada: se copia la parte sin cortar el original");
            cut = false;
        }
        final int sourceIndex = project.layers.indexOf(a);
        if (sourceIndex < 0) {
            msg("No se encontro la capa origen");
            return;
        }
        if (!project.hasSelection()) {
            msg("Primero marca en azul la parte");
            return;
        }
        Rect core = selectionBoundsAny();
        if (core == null || core.isEmpty()) {
            msg("Primero marca en azul la parte");
            return;
        }
        overlap = Math.max(0, Math.min(24, overlap));
        Rect sb = new Rect(core);
        int pad = overlap + 2;
        sb.inset(-pad, -pad);
        clamp(sb);
        int w = project.w;
        int cw = sb.width(), ch = sb.height();
        if (!ensureMemory((long) cw * ch * 6L)) return;
        int[] crop;
        byte[] localSel;
        int[] apx;
        try {
            crop = new int[cw * ch];
            localSel = new byte[cw * ch];
            apx = a.px();
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para crear la capa. Combina o borra alguna capa.");
            return;
        }
        for (int y = 0; y < ch; y++)
            System.arraycopy(project.selection, (sb.top + y) * w + sb.left, localSel, y * cw, cw);
        if (overlap > 0) {
            MaskOps.dilate(localSel, cw, ch, overlap);
            if (overlap >= 3) MaskOps.feather(localSel, cw, ch, 1);
        }
        for (int y = 0; y < ch; y++) {
            int so = (sb.top + y) * w + sb.left, lo = y * cw;
            for (int x = 0; x < cw; x++) {
                int s = localSel[lo + x] & 0xFF;
                if (s == 0) continue;
                int c = apx[so + x];
                // v8.24: al CORTAR sin solapamiento, el borde suave se reparte: la parte se
                // queda con la mitad interior (alfa x min(1, 2s)) y la capa de abajo con la
                // exterior. Encajan sin linea en reposo y, al mover la parte, no queda su
                // contorno en la capa de abajo.
                int sp = cut && overlap == 0 ? Math.min(255, s * 2) : s;
                int al = ((c >>> 24) * sp) / 255;
                if (al > 0) crop[lo + x] = (al << 24) | (c & 0x00FFFFFF);
            }
        }
        undo.setLabel(cut ? "Cortar parte" : "Crear parte");
        undo.begin();
        undo.recordStruct();
        if (cut) {
            undo.recordLayer(a, core);
            for (int y = core.top; y < core.bottom; y++) {
                int off = y * w, lo = (y - sb.top) * cw - sb.left;
                for (int x = core.left; x < core.right; x++) {
                    int i = off + x;
                    int sv = project.selection[i] & 0xFF;
                    if (sv == 0) continue;
                    int c = apx[i];
                    int ao = c >>> 24, ap = crop[lo + x] >>> 24;
                    // Lo que queda (B) se calcula para que la parte encima (P) devuelva EXACTAMENTE
                    // el original en reposo: P + B*(1-P) = A. Como la parte se lleva todo donde la
                    // seleccion es mayoria (P = A), ahi la capa de abajo queda vacia: al mover la
                    // parte no queda su contorno (v8.23 dejaba ese borde entero).
                    int al = ap >= ao ? 0 : Math.max(0, Math.min(ao, Math.round((ao - ap) * 255f / (255 - ap))));
                    apx[i] = (al << 24) | (c & 0x00FFFFFF);
                }
            }
        }
        undo.end();
        String base = preferredName == null ? "parte" : preferredName.trim();
        if (base.length() == 0) base = "parte";
        int insertAt = Math.min(project.layers.size(), sourceIndex + 1);
        project.layers.add(insertAt,
                Layer.fromCrop(uniqueName(base), sb.left, sb.top, cw, ch, project.w, project.h, crop));
        project.active = insertAt;
        lastNormalLayer = project.layers.get(insertAt);
        layersChanged();
        showHud((cut ? "Parte cortada" : "Parte creada")
                + (overlap > 0 ? " con " + overlap + " px de solapamiento" : ""));
    }

    /** Rectangulo de todo lo azul, incluido lo muy suave del borde. */
    private Rect selectionBoundsAny() {
        byte[] m = project.selection;
        int w = project.w, h = project.h;
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (m[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** Combina la capa elegida con la de abajo, como en Ibis. */
    public void mergeDown() {
        Layer a = target();
        int i = project.active;
        if (a == null || i <= 0) {
            msg("No hay capa abajo para combinar");
            return;
        }
        Layer below = project.layers.get(i - 1);
        if (refuseLocked(below) || refuseLocked(a)) return;
        Rect ab = a.bounds(project.w, project.h);
        if (!ensureMemory((long) project.w * project.h * 4)) return;
        try {
            below.px();
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para combinar. Borra alguna capa.");
            return;
        }
        undo.setLabel("Combinar");
        undo.begin();
        undo.recordStruct();
        if (ab != null) undo.recordLayer(below, ab);
        undo.end();
        if (ab != null) {
            int[] bp = below.px(), ap = a.px();
            int w = project.w;
            com.pacco.animecut.core.ColorAdjust adj = a.adjuster();
            for (int y = ab.top; y < ab.bottom; y++) {
                for (int x = ab.left; x < ab.right; x++) {
                    int k = y * w + x;
                    int c = ap[k];
                    if (adj != null) c = adj.apply(c);
                    int ca = c >>> 24;
                    if (a.clip) ca = Layer.clipA(ca, bp[k] >>> 24, a.clipOut);
                    int sa = (ca * a.opacity) / 255;
                    if (sa > 0) bp[k] = Project.blend(bp[k], c, a.mode, sa);
                }
            }
        }
        project.layers.remove(i);
        a.pack(project.w, project.h);
        project.active = i - 1;
        layersChanged();
    }

    public void deleteActive() {
        if (target() == null) return;
        if (refuseLocked(target())) return;
        if (project.layers.size() <= 1) {
            msg("Tiene que quedar al menos una capa");
            return;
        }
        undo.setLabel("Eliminar capa");
        undo.recordStruct();
        Layer gone = project.layers.remove(project.active);
        gone.pack(project.w, project.h);
        project.active = Math.min(project.active, project.layers.size() - 1);
        layersChanged();
    }

    public void moveActive(int delta) {
        int i = project.active, t = i + delta;
        if (i < 0 || t < 0 || t >= project.layers.size()) return;
        undo.setLabel("Ordenar capas");
        undo.recordStruct();
        Layer a = project.layers.get(i);
        project.layers.set(i, project.layers.get(t));
        project.layers.set(t, a);
        project.active = t;
        layersChanged();
    }

    public void clearActive() {
        Layer t = needLayer();
        if (t == null) return;
        undo.setLabel("Limpiar capa");
        undo.recordLayer(t, project.fullRect());
        if (project.hasSelection()) {
            for (int i = 0; i < t.px().length; i++) {
                int s = project.selection[i] & 0xFF;
                int al = ((t.px()[i] >>> 24) * (255 - s)) / 255;
                t.px()[i] = (al << 24) | (t.px()[i] & 0x00FFFFFF);
            }
        } else {
            Arrays.fill(t.px(), 0);
        }
        layersChanged();
    }

    /** Borrar area: quita de la capa lo que esta en azul. */
    public void eraseSelectionFromLayer() {
        if (!project.hasSelection()) {
            msg("No hay nada en azul");
            return;
        }
        clearActive();
    }

    /** Dejar solo esto: en la capa queda solo lo azul. */
    public void keepSelectionInLayer() {
        Layer t = needLayer();
        if (t == null || !needHole()) return;
        undo.setLabel("Dejar solo esto");
        undo.recordLayer(t, project.fullRect());
        for (int i = 0; i < t.px().length; i++) {
            int s = project.selection[i] & 0xFF;
            int al = ((t.px()[i] >>> 24) * s) / 255;
            t.px()[i] = (al << 24) | (t.px()[i] & 0x00FFFFFF);
        }
        layersChanged();
    }

    private String uniqueName(String base) {
        int n = 1;
        while (true) {
            String cand = base + "_" + n;
            boolean clash = false;
            for (Layer l : project.layers) if (l.name.equals(cand)) {
                clash = true;
                break;
            }
            if (!clash) return cand;
            n++;
        }
    }

    // ==================================================================
    // Seleccion: acciones del menu
    // ==================================================================

    public void clearTemporarySelectionAfterCopy() {
        if (project == null || !project.hasSelection()) return;
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void clearSelection() {
        if (project == null) return;
        undo.setLabel("Quitar seleccion");
        undo.recordSelection(project.fullRect());
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void invertSelection() {
        if (project == null) return;
        undo.setLabel("Invertir");
        undo.recordSelection(project.fullRect());
        MaskOps.invert(project.selection);
        refreshOverlay(null);
        changed();
    }

    /** kind: 0 expandir, 1 contraer, 2 suavizar, 3 endurecer, 4 cerrar puntos, 5 zonas encerradas */
    public void edgeOp(final int kind, final int radius) {
        if (project == null) return;
        if (!project.hasSelection()) {
            msg("Primero marca algo en azul (con la varita o el lazo). Esto trabaja sobre lo azul.");
            return;
        }
        final long before = selectionSum();
        setBusy(true);
        undo.setLabel("Borde");
        undo.recordSelection(project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] s = project.selection;
                switch (kind) {
                    case 0:
                        MaskOps.dilate(s, project.w, project.h, radius);
                        break;
                    case 1:
                        MaskOps.erode(s, project.w, project.h, radius);
                        break;
                    case 2:
                        MaskOps.feather(s, project.w, project.h, radius);
                        break;
                    case 4:
                        MaskOps.closeHoles(s, project.w, project.h, radius);
                        break;
                    case 5:
                        MaskOps.fillEnclosed(s, project.w, project.h, radius <= 0 ? 0 : radius * 400);
                        break;
                    default:
                        MaskOps.threshold(s, 128);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
                if (kind == 4 || kind == 5) {
                    long diff = selectionSum() - before;
                    showHud(diff > 0 ? "Listo: se rellenaron los huequitos dentro de lo azul"
                            : "No habia huequitos que cerrar dentro de lo azul");
                }
            }
        });
    }

    private long selectionSum() {
        long t = 0;
        for (byte b : project.selection) t += b & 0xFF;
        return t;
    }

    public void expandSelection(final float px) {
        if (project == null) return;
        if (!project.hasSelection()) {
            msg("Primero marca algo en azul (con la varita o el lazo)");
            return;
        }
        setBusy(true);
        undo.setLabel("Ampliar");
        undo.recordSelection(project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                MaskOps.expandSubpixel(project.selection, project.w, project.h, px, null);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void refineEdge(final int radius, final float eps) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Refinar borde");
        undo.recordSelection(project.fullRect());
        final Rect area = project.selectionBounds();
        Task.run(new Runnable() {
            @Override
            public void run() {
                GuidedFilter.refine(project.selection, project.ref(), project.w, project.h, radius, eps, area);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void buildBarrier(final int threshold, final int closeGap) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                project.barrier = LineArt.build(project.ref(), project.w, project.h, threshold, closeGap);
                gapBarrier = null;
            }
        }, new Runnable() {
            @Override
            public void run() {
                useBarrier = true;
                setBusy(false);
                showHud("En rojo: lo que la varita toma como linea");
                showRedLines(project.barrier);
                changed();
            }
        });
    }

    /** kind: 0 mediana, 1 posterizar, 2 niveles, 3 extraer line art. Sobre la capa elegida. */
    /** v8.42 Mejorar imagen: true si el lienzo puede quedar de ese tamano. */
    public static boolean sizeOk(long nw, long nh) {
        return nw * nh <= 40_000_000L && nw <= 12000 && nh <= 12000;
    }

    /**
     * v8.42 Mejorar imagen (x2/x4): TODA la obra pasa a nw x nh con estos pixeles por capa
     * (mismo orden que las capas; null = capa vacia). Se queda en la misma obra y Deshacer
     * la devuelve como era.
     */
    public void resizeProject(int nw, int nh, int[][] px) {
        if (project == null || px == null || px.length != project.layers.size()) return;
        if (transformActive) cancelTransform(false);
        undo.setLabel("Mejorar imagen");
        Object before = undo.resizeState();
        project.rescale(nw, nh, px);
        undo.recordResize(before);
        resetAfterGeometry();
        layersChanged();
        changed();
    }

    // ------------------------------------------------------------------
    // v8.57 pantalla "Filtros": la capa elegida, memoria y aplicar con Deshacer.
    // ------------------------------------------------------------------

    /** Capa para filtrar (null + aviso si es la de seleccion, esta bloqueada o hay un calculo). */
    public Layer fxTarget() {
        if (project == null || busy) return null;
        if (transformActive) cancelTransform(false);
        return needLayer();
    }

    /** Libera lo que se pueda y dice si quedan 'bytes' libres (no bloquea). */
    public boolean fxMemory(long bytes) {
        return ensureMemory(bytes);
    }

    /**
     * Pone el resultado: en la misma capa (Deshacer la devuelve) o en una capa nueva encima
     * (la original no cambia). No crea capas si no se pide.
     */
    public void fxCommit(Layer t, int[] px, boolean asNewLayer, String name) {
        if (project == null || t == null || px == null || px.length != project.w * project.h
                || !project.layers.contains(t)) {
            msg("Cambiaste de obra o de capa: no se aplico");
            return;
        }
        if (asNewLayer) {
            undo.setLabel(name);
            undo.recordStruct();
            Layer nl = new Layer(uniqueName(name), px);
            int idx = project.layers.indexOf(t);
            project.layers.add(idx + 1, nl);
            project.active = idx + 1;
            lastNormalLayer = nl;
            layersChanged();
            showHud(name + " en una capa nueva. Deshacer la quita");
        } else {
            undo.setLabel(name);
            undo.begin();
            undo.recordLayer(t, project.fullRect());
            System.arraycopy(px, 0, t.px(), 0, px.length);
            undo.end();
            project.markDirty();
            layersChanged();
            showHud(name + " aplicado. Deshacer lo devuelve");
        }
        changed();
    }

    /**
     * v8.80: capa de EFECTO nueva (por ejemplo Rayos de luz en modo Anadir) encima de 't' y de sus
     * capas recortadas. La capa 't' no cambia. Un solo paso en Deshacer.
     */
    public boolean fxAddEffectLayer(Layer t, int[] px, String name, int blendMode) {
        return fxAddEffectLayer(t, px, name, blendMode, false);
    }

    /** below = la capa de efecto va DEBAJO de 't' (contorno exterior, lineas detras del personaje). */
    public boolean fxAddEffectLayer(Layer t, int[] px, String name, int blendMode, boolean below) {
        if (project == null || t == null || px == null || px.length != project.w * project.h
                || !project.layers.contains(t)) {
            msg("Cambiaste de obra o de capa: no se aplico");
            return false;
        }
        undo.setLabel(name);
        undo.recordStruct();
        Layer nl = new Layer(uniqueName(name), px);
        nl.mode = blendMode;
        int idx;
        if (below && !t.clip) {
            idx = project.layers.indexOf(t);
        } else {
            below = false;
            idx = project.layers.indexOf(t) + 1;
            while (idx < project.layers.size() && project.layers.get(idx).clip) idx++;
        }
        project.layers.add(idx, nl);
        project.active = idx;
        layersChanged();
        showHud(name + " en una capa nueva " + (below ? "debajo" : "encima") + " ("
                + Layer.MODE_NAMES[Math.max(0, Math.min(Layer.MODE_NAMES.length - 1, blendMode))]
                + "). Deshacer la quita");
        changed();
        return true;
    }

    /** v8.42 Mejorar imagen (mismo tamano): cambia los pixeles de esas capas, con Deshacer. */
    public void replaceLayersPixels(Layer[] ls, int[][] px) {
        if (project == null) return;
        int n = project.w * project.h;
        undo.setLabel("Mejorar imagen");
        undo.begin();
        for (int i = 0; i < ls.length; i++) {
            if (ls[i] == null || px[i] == null || px[i].length != n || !project.layers.contains(ls[i])) continue;
            undo.recordLayer(ls[i], project.fullRect());
            System.arraycopy(px[i], 0, ls[i].px(), 0, n);
        }
        undo.end();
        layersChanged();
        changed();
    }

    public void applyFilter(final int kind, final int a, final int b, final int c) {
        final Layer t = needLayer();
        if (t == null) return;
        setBusy(true);
        undo.setLabel("Filtro");
        undo.recordLayer(t, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        Filters.median3(t.px(), project.w, project.h);
                        break;
                    case 1:
                        Filters.posterize(t.px(), a);
                        break;
                    case 2:
                        Filters.levels(t.px(), a, b, c / 100f);
                        break;
                    default:
                        Filters.extractLineArt(t.px(), project.w, project.h, a, b, c);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                layersChanged();
            }
        });
    }

    /**
     * Agranda el lienzo con margenes transparentes. v8.27: se puede DESHACER (antes el
     * historial se reiniciaba). 'after' (puede ser null) corre al terminar.
     */
    public void enlargeCanvas(final int left, final int top, final int right, final int bottom) {
        enlargeCanvas(left, top, right, bottom, null);
    }

    public void enlargeCanvas(final int left, final int top, final int right, final int bottom, final Runnable after) {
        if (project == null || busy) return;
        if (transformActive) cancelTransform(false);
        long nw = (long) project.w + left + right, nh = (long) project.h + top + bottom;
        if (nw * nh > 40_000_000L || nw > 12000 || nh > 12000) {
            msg("El lienzo quedaria demasiado grande para el telefono");
            return;
        }
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                project.enlarge(left, top, right, bottom);
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.setLabel("Ampliar lienzo");
                undo.recordEnlarge(left, top, right, bottom);
                resetAfterGeometry();
                setBusy(false);
                showHud("Lienzo " + project.w + " x " + project.h + ". Deshacer lo devuelve");
                changed();
                if (after != null) after.run();
            }
        });
    }

    /** Buffers del tamano viejo fuera; pantalla y capa azul de nuevo (tras cambiar el tamano). */
    private void resetAfterGeometry() {
        scratch = selBackup = gapBarrier = gradient = markers = repairLines = null;
        pxBackup = null;
        cov = null;
        covDirty = null;
        allowMask = null;
        allowDirty = null;
        clearEffectStrokeBackup();
        clearSelectionStrokeBackup();
        if (markersOverlay != null) markersOverlay.recycle();
        markersOverlay = null;
        wire = null;
        bucketLines = null;
        mangaLines = null;
        mangaTexture = null;
        scissorsReset();
        buildDisplay();
        buildOverlay();
        fit();
    }

    public void transform(final int kind) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (kind == 0) project.rotate90(true);
                else if (kind == 1) project.rotate90(false);
                else project.flip(kind == 2);
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.clear();
                scratch = selBackup = gapBarrier = gradient = markers = repairLines = null;
                pxBackup = null;
                clearEffectStrokeBackup();
                clearSelectionStrokeBackup();
                if (markersOverlay != null) markersOverlay.recycle();
                markersOverlay = null;
                wire = null;
                scissorsReset();
                buildDisplay();
                buildOverlay();
                fit();
                setBusy(false);
                showHud("Listo. El historial se reinicia al girar");
                changed();
            }
        });
    }

    // ==================================================================
    // Deshacer
    // ==================================================================

    public void doUndo() {
        belowEpoch++;
        // v8.32: el grosor de linea medido para Borrar fondo se vuelve a medir despues
        invalidateBgAnalysis();
        if (edgeLayer != null) {
            // v8.27: Refinar borde todavia no se acepto: deshacer lo cancela
            cancelEdgeRefine();
            showHud("Refinar borde cancelado");
            return;
        }
        if (hasFillPreview()) {
            // v8.26: la vista previa del balde todavia no pinto nada: deshacer la cancela
            cancelFillPreview();
            showHud("Vista previa cancelada");
            return;
        }
        if (mode == MODE_TRANSFORM && (transformActive || transformPreparing || transformApplying)) {
            // Durante Transformar/Deformar la imagen original esta apartada:
            // deshacer actua sobre los puntos o nodos, nunca sobre la obra.
            deformHistory(true);
            return;
        }
        finishLiquifyCommitNow();
        if (mode == MODE_SHAPE && geo != null) {
            // la figura todavia no se pinto: Deshacer solo la quita
            discardShapeDraft();
            showHud("Figura quitada");
            return;
        }
        if (isShapeTool() && !shapePts.isEmpty()) {
            shapePts.remove(shapePts.size() - 1);
            shapeSel = shapePts.size() - 1;
            invalidate();
            return;
        }
        if (undo == null) return;
        int ow = project.w, oh = project.h;
        if (compareBefore != null) { stopCompare(); if (callback != null) callback.onToolStateChanged(); }
        Rect r = undo.undo();
        if (project.w != ow || project.h != oh) resetAfterGeometry();
        afterRestore(r, "Deshacer");
    }

    /**
     * v8.55: varios Deshacer (o Rehacer, n negativo) de una vez, con UNA sola actualizacion de la
     * pantalla. Si tocas el boton muy rapido, los toques se juntan aqui: antes cada toque rehacia
     * toda la pantalla (y medía la imagen en otro hilo) y el telefono se trababa.
     */
    public void doUndoSteps(int n) {
        if (n == 0 || project == null) return;
        boolean back = n > 0;
        int k = Math.abs(n);
        boolean special = edgeLayer != null || hasFillPreview()
                || (mode == MODE_TRANSFORM && (transformActive || transformPreparing || transformApplying))
                || (back && hasShapeWork()) || undo == null;
        if (special) {
            // cancelar una vista previa, puntos de Transformar o de una figura: uno por toque
            for (int i = 0; i < k; i++) {
                if (back) doUndo(); else doRedo();
                if (edgeLayer == null && !hasFillPreview()) break;
            }
            return;
        }
        if (k == 1) {
            if (back) doUndo(); else doRedo();
            return;
        }
        belowEpoch++;
        invalidateBgAnalysis();
        finishLiquifyCommitNow();
        if (back && compareBefore != null) { stopCompare(); if (callback != null) callback.onToolStateChanged(); }
        int ow = project.w, oh = project.h;
        Rect all = null;
        boolean struct = false;
        for (int i = 0; i < k; i++) {
            Rect r = back ? undo.undo() : undo.redo();
            if (r == null) break;
            struct |= undo.lastWasStruct();
            if (all == null) all = new Rect(r); else all.union(r);
        }
        if (project.w != ow || project.h != oh) resetAfterGeometry();
        afterRestore(all, back ? "Deshacer" : "Rehacer", struct);
    }

    public void doRedo() {
        belowEpoch++;
        invalidateBgAnalysis();
        if (hasFillPreview()) cancelFillPreview();
        if (mode == MODE_TRANSFORM && (transformActive || transformPreparing || transformApplying)) {
            deformHistory(false);
            return;
        }
        finishLiquifyCommitNow();
        if (undo == null) return;
        int ow = project.w, oh = project.h;
        Rect r = undo.redo();
        if (project.w != ow || project.h != oh) resetAfterGeometry();
        afterRestore(r, "Rehacer");
    }

    private void afterRestore(Rect r, String word) {
        afterRestore(r, word, undo != null && undo.lastWasStruct());
    }

    private void afterRestore(Rect r, String word, boolean struct) {
        if (r == null) {
            showHud(word.equals("Deshacer") ? "Nada que deshacer" : "Nada que rehacer");
            return;
        }
        wire = null;
        // Si Deshacer/Rehacer cambia la capa, el campo de Licuar anterior ya no
        // corresponde a esos pixeles. Se reinicia sin tocar el resultado restaurado.
        if (mode == MODE_LIQUIFY) resetLiquifySession();
        // v8.55: cambio de capas: la pantalla se rehace en otro hilo (la imagen de antes se queda
        // hasta que llega la nueva); antes se rehacia aqui mismo y con toques rapidos se trababa
        if (struct) {
            if (display == null) refreshDisplay();
            else { refreshDisplayAsync(); staleDetail(); scheduleDetail(); }
        } else updateDisplayRegion(r);
        paintOverlay(r);
        if (protectBmp != null || (project.protect != null)) rebuildProtectBitmap();
        if (callback != null) callback.onToolStateChanged();
        invalidate();
        String l = undo.lastLabel();
        showHud(l == null || l.isEmpty() ? word : word + ": " + l);
        changed();
    }

    // ==================================================================
    // Utilidades
    // ==================================================================

    private void ensureScratch() {
        int n = project.w * project.h;
        if (scratch == null || scratch.length != n) scratch = new byte[n];
    }

    private void clamp(Rect r) {
        if (r.left < 0) r.left = 0;
        if (r.top < 0) r.top = 0;
        if (r.right > project.w) r.right = project.w;
        if (r.bottom > project.h) r.bottom = project.h;
    }

    private void setBusy(boolean b) {
        busy = b;
        if (callback != null) callback.onBusy(b);
    }

    private void changed() {
        scheduleCompact();
        if (callback != null) callback.onChanged();
    }

    // ------------------------------------------------------------------
    // Memoria: las capas que no se usan se empacan (solo su recorte).
    // ------------------------------------------------------------------

    private final Runnable compactRunnable = new Runnable() {
        @Override
        public void run() {
            if (project == null) return;
            if (busy || drawing || compactHold) {
                handler.postDelayed(this, 400);
                return;
            }
            try {
                project.packInactive();
            } catch (OutOfMemoryError e) {
                // se intenta la proxima vez
            }
        }
    };

    private void scheduleCompact() {
        handler.removeCallbacks(compactRunnable);
        handler.postDelayed(compactRunnable, 1200);
    }

    /** Mientras arrastras una capa no se empaca nada, para que no se trabe. */
    private boolean compactHold;

    public void setCompactHold(boolean hold) {
        compactHold = hold;
        if (!hold) scheduleCompact();
    }

    /** Empaca ya todo lo que no se usa y avisa si igual no alcanza la memoria. */
    private boolean ensureMemory(long bytes) {
        belowDetail.drop();
        if (project != null && !busy) {
            try {
                project.packInactive();
            } catch (OutOfMemoryError ignored) {
            }
        }
        // solo cuenta lo que va a la memoria de Java; las capas guardadas usan la del telefono
        if (freeMemory() > bytes + (8L << 20)) return true;
        if (undo != null) undo.trimTo(0.5f);
        pxBackup = null;
        System.gc();
        // no se bloquea: lo que falte lo atrapan los try/catch de cada accion
        return true;
    }

    private static long freeMemory() {
        Runtime rt = Runtime.getRuntime();
        return rt.maxMemory() - (rt.totalMemory() - rt.freeMemory());
    }

    /** Memoria que gasta la obra ahora, para mostrar en Capas. */
    public String memoryInfo() {
        if (project == null) return "";
        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        return (used >> 20) + " de " + (rt.maxMemory() >> 20) + " MB";
    }

    private void msg(String s) {
        if (callback != null) callback.onMessage(s);
    }

    // ---- ajustes ----

    public void setMode(int m) {
        if (m != MODE_BUCKET && hasFillPreview()) cancelFillPreview();
        // Deformar comparte la sesion de Transformar: se guarda como TRANSFORM
        // con la marca puppetTool (Malla = 2, Marioneta = 3).
        boolean wantDeform = m == MODE_PUPPET;
        if (wantDeform) m = MODE_TRANSFORM;
        if (transformApplying && (m != MODE_TRANSFORM || wantDeform != puppetTool)) return;
        if (drawing && mode == MODE_LIQUIFY && m != MODE_LIQUIFY) endStroke();
        if ((mode == MODE_SCISSORS || mode == MODE_MAGNET) && m != mode) scissorsReset();
        if (mode == MODE_TRANSFORM && transformActive && (m != MODE_TRANSFORM || wantDeform != puppetTool)) cancelTransform(false);
        if (mode == MODE_LIQUIFY && m != MODE_LIQUIFY) resetLiquifySession();
        if (m == MODE_LIQUIFY && mode != MODE_LIQUIFY) resetLiquifySession();
        // v8.32: los mapas de Borrar fondo se liberan al salir de la herramienta
        if (mode == MODE_BGERASE && m != MODE_BGERASE) releaseBgEngine();
        if (aiMark && m != MODE_BGERASE) cancelAiMark();
        boolean enterBg = m == MODE_BGERASE && mode != MODE_BGERASE;
        // v8.79: al cambiar de herramienta, la figura en borrador se pinta (Deshacer la quita)
        if (mode == MODE_SHAPE && m != MODE_SHAPE && geo != null) {
            geoDownOn = false;
            geoGrab = G_NONE;
            commitGeo(geo);
            geo = null;
            geoPrev = null;
        }
        mode = m;
        updateGrayFilter();     // v8.38: el gris de B/N solo se ve en Borrar fondo
        // el grosor de linea se mide en otro hilo mientras eliges (el primer trazo no espera)
        if (enterBg) prefetchBgWidth();
        if (m == MODE_TRANSFORM) {
            puppetTool = wantDeform;
            if (puppetTool) transformType = 4;
            else if (transformType == 4) transformType = 0;
        } else {
            puppetTool = false;
        }
        invalidate();
    }

    public int getMode() {
        return mode == MODE_TRANSFORM && puppetTool ? MODE_PUPPET : mode;
    }

    public void setTolerance(int t) {
        tolerance = t;
    }

    public int getTolerance() {
        return tolerance;
    }

    public void setSoftness(int s) {
        softness = Math.max(0, s);
    }

    public int getSoftness() {
        return softness;
    }

    public void setColorMode(int m) {
        colorMode = m;
    }

    public int getColorMode() {
        return colorMode;
    }

    public void setExpansion(float e) {
        expansion = e;
    }

    public float getExpansion() {
        return expansion;
    }

    public void setGap(boolean on, int r) {
        gapOn = on;
        gapRadius = Math.max(1, r);
        gapBarrier = null;
    }

    public boolean isGapOn() {
        return gapOn;
    }

    public int getGapRadius() {
        return gapRadius;
    }

    public void setBrushSize(float px) {
        brushRadius = Math.max(0.5f, px / 2f);
        if (mode == MODE_SHAPE && geo != null) invalidate();   // v8.79: el grosor del contorno se ve al instante
    }

    private float sizePreview;
    private long sizePreviewUntil;
    private final Paint sizePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Al mover la barra de tamano se ve el circulo del pincel en el centro, como en ibis. */
    public void showSizePreview(float size) {
        sizePreview = size;
        sizePreviewUntil = System.currentTimeMillis() + 900;
        invalidate();
        postDelayed(new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        }, 950);
    }

    private void drawSizePreview(Canvas c) {
        if (System.currentTimeMillis() > sizePreviewUntil) return;
        float r = Math.max(2f, sizePreview * currentScale() / 2f);
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        sizePaint.setStyle(Paint.Style.FILL);
        sizePaint.setColor(0x55000000);
        c.drawCircle(cx, cy, r, sizePaint);
        sizePaint.setStyle(Paint.Style.STROKE);
        sizePaint.setStrokeWidth(3f);
        sizePaint.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, r, sizePaint);
        sizePaint.setStrokeWidth(1.5f);
        sizePaint.setColor(0xFF000000);
        c.drawCircle(cx, cy, r + 2f, sizePaint);
        sizePaint.setStyle(Paint.Style.FILL);
        sizePaint.setColor(0xFFFFFFFF);
        sizePaint.setTextSize(34f);
        sizePaint.setTextAlign(Paint.Align.CENTER);
        c.drawText(String.valueOf((int) sizePreview), cx, cy + 12f, sizePaint);
    }

    public float getHardness() {
        return hardness;
    }

    public float getBrushSize() {
        return brushRadius * 2f;
    }

    public void setHardness(float h) {
        hardness = Math.max(0.05f, Math.min(1f, h));
    }

    public void setBrushOpacity(float v) {
        brushOpacity = Math.max(0.02f, Math.min(1f, v));
    }

    public void setColor(int c) {
        // v8.55: balde de colorear manga con vista previa: lo pendiente se pinta con el color de
        // antes; el color nuevo es para lo siguiente (antes cambiaba todo lo pendiente)
        if (c != paintColor && mode == MODE_BUCKET && colorBucket) commitColorPreview();
        paintColor = c;
    }

    /** v8.55: pinta lo pendiente de la vista previa del balde de colorear (no la del balde normal). */
    private void commitColorPreview() {
        if (fillPreview.isEmpty() || busy) return;
        if (fillPreview.get(0).bucket) return;
        acceptFillPreview();
    }

    public int getColor() {
        return paintColor;
    }

    public void setEffectStrength(float v) {
        effectStrength = Math.max(0.05f, Math.min(1f, v));
    }

    public float getEffectStrength() { return effectStrength; }

    public void setEffectSoftness(float v) {
        effectSoftness = Math.max(0f, Math.min(1f, v));
        showHud("Suavidad " + Math.round(effectSoftness * 100f) + "%");
    }

    public float getEffectSoftness() { return effectSoftness; }

    public void setLiquifyType(int type) {
        if (drawing && mode == MODE_LIQUIFY) endStroke();
        liquifyType = Math.max(0, Math.min(4, type));
        showHud(liquifyType == 0 ? "Licuar: Arrastrar" : liquifyType == 1 ? "Licuar: Contraer"
                : liquifyType == 2 ? "Licuar: Expandir" : liquifyType == 3 ? "Licuar: Suavizar"
                : "Licuar: Restaurar");
        invalidate();
    }

    public int getLiquifyType() { return liquifyType; }

    public float getBrushOpacity() { return brushOpacity; }

    public void setWandGlobal(boolean g) {
        wandGlobal = g;
    }

    public boolean isWandGlobal() {
        return wandGlobal;
    }

    public void setUseBarrier(boolean b) {
        useBarrier = b;
    }

    public boolean isUseBarrier() {
        return useBarrier;
    }

    public void setSubtract(boolean s) {
        subtract = s;
    }

    public boolean isSubtract() {
        return subtract;
    }

    public void setSmart(boolean s) {
        smart = s;
    }

    public boolean isSmart() {
        return smart;
    }

    public void setStabilizer(float v) {
        stabilizer = Math.max(0f, Math.min(0.92f, v));
        stabLevel = Math.round(stabilizer / 0.092f);      // v8.78: nivel 0..10
    }

    public void setAim(boolean on) {
        aimOn = on;
        invalidate();
    }

    public boolean isAim() {
        return aimOn;
    }

    public void setBgOnce(boolean b) {
        bgOnce = b;
    }

    public boolean isBgOnce() {
        return bgOnce;
    }

    public void setBgBucket(boolean b) {
        bgBucket = b;
    }

    public boolean isBgBucket() {
        return bgBucket;
    }

    public void setBgTolerance(int t) {
        bgTolerance = Math.max(0, Math.min(160, t));
    }

    public int getBgTolerance() {
        return bgTolerance;
    }

    /**
     * v8.30: SUAVIDAD del borde de Borrar fondo (barra de abajo, 0 a 4 px). El borde del recorte se
     * vuelve transparente poco a poco hacia adentro: a 1 px del hueco queda 1/(r+1) del alfa, a
     * 2 px 2/(r+1), y asi. No borra mas personaje que eso y repetirlo no lo come mas (siempre
     * se mide desde lo que ya es transparente del todo). 0 = borde nitido, como antes.
     */
    private float bgFeather = 0f;

    public void setBgFeather(float px) { bgFeather = Math.max(0f, Math.min(4f, px)); }

    public float getBgFeather() { return bgFeather; }

    /** Aplica la suavidad dentro de r (la capa ya esta guardada para deshacer). */
    private void featherBg(Layer t, Rect r) {
        if (t == null || r == null || bgFeather <= 0.05f) return;
        int W = project.w, H = project.h;
        int m = (int) Math.ceil(bgFeather) + 2;
        int x0 = Math.max(0, r.left - m), y0 = Math.max(0, r.top - m);
        int x1 = Math.min(W, r.right + m), y1 = Math.min(H, r.bottom + m);
        int ww = x1 - x0, wh = y1 - y0;
        if (ww <= 0 || wh <= 0) return;
        int[] px = t.px();
        byte[] sel = project.hasSelection() ? project.selection : null;
        int big = 3 * (m + 2);
        short[] d = new short[ww * wh];
        boolean any = false;
        for (int y = 0; y < wh; y++)
            for (int x = 0; x < ww; x++) {
                boolean clear = (px[(y + y0) * W + x + x0] >>> 24) == 0;
                d[y * ww + x] = (short) (clear ? 0 : big);
                if (clear) any = true;
            }
        if (!any) return;
        // distancia (chaflan 3-4) a lo transparente
        for (int y = 0; y < wh; y++)
            for (int x = 0; x < ww; x++) {
                int j = y * ww + x, v = d[j];
                if (v == 0) continue;
                if (x > 0) v = Math.min(v, d[j - 1] + 3);
                if (y > 0) {
                    v = Math.min(v, d[j - ww] + 3);
                    if (x > 0) v = Math.min(v, d[j - ww - 1] + 4);
                    if (x < ww - 1) v = Math.min(v, d[j - ww + 1] + 4);
                }
                d[j] = (short) v;
            }
        for (int y = wh - 1; y >= 0; y--)
            for (int x = ww - 1; x >= 0; x--) {
                int j = y * ww + x, v = d[j];
                if (v == 0) continue;
                if (x < ww - 1) v = Math.min(v, d[j + 1] + 3);
                if (y < wh - 1) {
                    v = Math.min(v, d[j + ww] + 3);
                    if (x < ww - 1) v = Math.min(v, d[j + ww + 1] + 4);
                    if (x > 0) v = Math.min(v, d[j + ww - 1] + 4);
                }
                d[j] = (short) v;
            }
        float rad = bgFeather;
        int rx0 = Math.max(0, r.left), ry0 = Math.max(0, r.top), rx1 = Math.min(W, r.right), ry1 = Math.min(H, r.bottom);
        for (int y = ry0; y < ry1; y++)
            for (int x = rx0; x < rx1; x++) {
                int i = y * W + x;
                int a = px[i] >>> 24;
                if (a == 0) continue;
                float dist = d[(y - y0) * ww + x - x0] / 3f;
                if (dist > rad + 0.5f) continue;
                int lim = Math.round(255f * Math.min(1f, dist / (rad + 1f)));
                if (sel != null) lim = 255 - ((255 - lim) * (sel[i] & 0xFF)) / 255;
                if (lim < a) px[i] = (lim << 24) | (px[i] & 0x00FFFFFF);
            }
    }

    /** Suavidad aplicada a TODO el recorte de la capa (al soltar la barra). Se deshace. */
    public void featherWholeLayer() {
        if (project == null || busy || bgFeather <= 0.05f) return;
        Layer t = needLayer();
        if (t == null || refuseLocked(t)) return;
        boolean any = false;
        int[] px = t.px();
        for (int q = 0; q < px.length; q++) if ((px[q] >>> 24) == 0) { any = true; break; }
        if (!any) return;
        Rect all = new Rect(0, 0, project.w, project.h);
        undo.setLabel("Suavizar borde");
        undo.recordLayer(t, all);
        featherBg(t, all);
        project.markDirty();
        refreshDisplay();
        changed();
    }

    public void setBgSoftness(int s) {
        bgSoftness = Math.max(0, Math.min(160, s));
    }

    public int getBgSoftness() {
        return bgSoftness;
    }

    public void setBgLimit(int l) {
        bgLimit = Math.max(0, Math.min(2, l));
    }

    public int getBgLimit() {
        return bgLimit;
    }

    public void setProtect(boolean on) {
        protectOn = on;
        protectColor = paintColor;
    }

    public boolean isProtect() {
        return protectOn;
    }

    public void setCloneMirror(boolean m) {
        cloneMirror = m;
    }

    public boolean isCloneMirror() {
        return cloneMirror;
    }

    public void setCloneAngle(float a) {
        cloneAngle = a;
    }

    public float getCloneAngle() {
        return cloneAngle;
    }

    /** Libera temporales de la vista al cerrar el editor. No recicla las capas
     * del proyecto porque un autoguardado que ya empezo puede seguir leyendolas. */
    public void releaseUiResources() {
        callback = null;
        cancelQuickTimer();
        handler.removeCallbacksAndMessages(null);
        if (undo != null) undo.clear();
        dropLiquifySession();
        clearEffectStrokeBackup();
        clearSelectionStrokeBackup();
        effectTmp = null;
        blurSrc = blurOut = null;
        blurTmp = null;
        endGhost();
        dropPreview();
        dropDetail();
        if (redLines != null && !redLines.isRecycled()) redLines.recycle();
        redLines = null;
        if (markersOverlay != null && !markersOverlay.isRecycled()) markersOverlay.recycle();
        markersOverlay = null;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (project == null) return;
        if (ow == 0 || oh == 0) { fit(); return; }
        if (w == ow && h == oh) return;
        // v8.74: al girar el celular, partir la pantalla o abrir un plegable. Antes el dibujo quedaba
        // descentrado o fuera de la pantalla. Si estaba encuadrado, se vuelve a encuadrar; si tenias
        // zoom, se mantiene el zoom y lo que mirabas queda en el centro.
        view.getValues(viewMatrixValues);
        boolean straight = Math.abs(viewMatrixValues[Matrix.MSKEW_X]) < 1e-4f && !viewFlipped;
        float oldFit = fitScaleFor(ow, oh);
        if (straight && oldFit > 0f && Math.abs(currentScale() / oldFit - 1f) < 0.03f) {
            fit();
        } else {
            view.postTranslate((w - ow) / 2f, (h - oh) / 2f);
            invalidate();
        }
    }

    /** Escala con la que fit() encuadra la imagen en una vista de vw x vh. */
    private float fitScaleFor(int vw, int vh) {
        if (project == null || vw <= 0 || vh <= 0) return 0f;
        int usable = vh - insetTop - insetBottom;
        if (usable < 80) usable = vh;
        return Math.min((float) vw / project.w, (float) usable / project.h) * 0.96f;
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelQuickTimer();
        handler.removeCallbacks(startPending);
        super.onDetachedFromWindow();
    }

    // ==================================================================
    // v8.26 COLOREAR MANGA: preset, balde por lineas con vista previa,
    // zonas protegidas, rellenar seleccion, sombra/luz rapida, cambiar color,
    // bloqueo total y gotero Visible / Capa actual.
    // ==================================================================

    public static final String INK_NAME = "Tinta B/N";
    public static final String BASE_NAME = "Color base";

    /** Ajustes del balde manga (los cambia el usuario desde la barra del balde). */
    private final com.pacco.animecut.core.MangaFill.Params mangaPrm = new com.pacco.animecut.core.MangaFill.Params();
    /** Vista previa antes de pintar (prendida de fabrica en el preset). */
    private boolean fillPreviewOn = true;
    /** Nivel de "Cerrar huecos": 0 No, 1 Pequeno, 2 Medio, 3 Grande. */
    private int mangaGapLevel = 2;

    public com.pacco.animecut.core.MangaFill.Params getMangaParams() { return mangaPrm; }

    public boolean isMangaMode() { return project != null && project.mangaMode; }

    /**
     * v8.54: el balde trabaja como "Colorear" (zonas con sombra y luz, por lineas del manga) solo
     * si se entro por 1 Colorear o Manga. Desde v8.43 Colorear dejaba la obra en modo manga y el
     * Relleno normal se convertia para siempre en ese balde. Ahora son dos cosas separadas.
     */
    private boolean colorBucket;

    public void setColorBucket(boolean on) {
        if (colorBucket != on && hasFillPreview()) cancelFillPreview();
        colorBucket = on;
    }

    /** true = el balde esta en modo Colorear (y la obra tiene las capas de manga preparadas). */
    public boolean isColorBucket() { return colorBucket && isMangaMode(); }

    // ==================================================================
    // v8.40 COLOR POR ZONAS (dentro de "Colorear manga"). Tocas una zona con el balde manga (la
    // vista previa ya muestra el color), eliges trio (sombra/base/luz) y acabado, y al aceptar la
    // zona va con su MAPA DE DEGRADADO a la capa "Color zonas" (una sola capa para todas). Las
    // zonas se guardan con su mascara y estilo: se pueden cambiar despues sin repintar.
    // ==================================================================

    public static final String TONE_NAME = "Color zonas", RIM_NAME = "Brillo contorno", GRAD_NAME = "Fondo degradado";
    private int zoneKind = -1;
    /** Ultima zona aplicada o elegida en la lista (para "aplicar a la zona"). */
    private int zoneSel = -1;

    public boolean isZoneMode() { return project != null && project.zoneMode && project.mangaMode; }

    public void setZoneMode(boolean on) {
        if (project == null) return;
        cancelFillPreview();
        project.zoneMode = on;
        mangaLines = null;
        project.markDirty();
        if (callback != null) callback.onToolStateChanged();
    }

    public com.pacco.animecut.core.ZoneTone.Style getZoneStyle() {
        return project == null ? new com.pacco.animecut.core.ZoneTone.Style() : project.zoneStyle;
    }

    /** Cambia el estilo del panel (trio, acabado, intensidad...). La vista previa se actualiza. */
    public void setZoneStyle(com.pacco.animecut.core.ZoneTone.Style st) {
        if (project == null || st == null) return;
        // v8.55: lo que quedo en vista previa se pinta con SU color antes de cambiar al nuevo
        commitColorPreview();
        project.zoneStyle = st;
        project.markDirty();
        if (!fillPreview.isEmpty()) rebuildPreviewBitmap();
    }

    /** Tipo de dibujo detectado (ZoneTone.KIND_*) o -1 si todavia no se toco ninguna zona. */
    public int getZoneKind() { return zoneKind; }

    public int getZoneSel() { return project != null && zoneSel >= 0 && zoneSel < project.zones.size() ? zoneSel : -1; }

    public void setZoneSel(int i) { zoneSel = i; }

    public java.util.List<com.pacco.animecut.core.ZoneTone.Zone> zoneList() {
        return project == null ? new java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone>() : project.zones;
    }

    /** Capa que sirve de referencia para leer el dibujo (la tinta) en Color por zonas. */
    private Layer zoneRefTarget() {
        Layer z = roleLayer(Layer.ROLE_TONE);
        if (z != null) return z;
        Layer b = mangaBase();
        if (b != null) return b;
        return target();
    }

    private Layer roleLayer(int role) {
        if (project == null) return null;
        for (Layer l : project.layers) if (l.role == role) return l;
        return null;
    }

    /**
     * Lineas para Color por zonas: el mapa de tinta del balde manga, mas (en dibujos de grises
     * suaves) las lineas grises finas, mas lo transparente como pared. Se calcula en otro hilo.
     */
    private byte[] zoneLines(int[] ref, int w, int h, com.pacco.animecut.core.MangaFill.Params prm) {
        if (zoneKind < 0) zoneKind = com.pacco.animecut.core.ZoneTone.kind(ref, w, h);
        com.pacco.animecut.core.MangaFill.Params p2 = prm;
        boolean soft = zoneKind == com.pacco.animecut.core.ZoneTone.KIND_SOFT;
        // grises suaves o imagen a color: un gris o color oscuro de sombra no es linea
        if ((soft || zoneKind == com.pacco.animecut.core.ZoneTone.KIND_COLOR) && prm.darkThr > 80) {
            // grises suaves: el gris oscuro de una sombra no es linea
            p2 = new com.pacco.animecut.core.MangaFill.Params();
            p2.darkThr = 80; p2.tone = prm.tone; p2.maxDot = prm.maxDot; p2.maxDotSide = prm.maxDotSide;
        }
        byte[] l = com.pacco.animecut.core.MangaFill.lineMap(ref, w, h, p2);
        // v8.67: en dibujos a color tambien: las lineas de color (azul oscuro en pelo azul, marron en
        // la piel) no son negras y no se veian; el color se pasaba de la cara al pelo
        if (soft || zoneKind == com.pacco.animecut.core.ZoneTone.KIND_COLOR) {
            byte[] sl = com.pacco.animecut.core.ZoneTone.softLines(ref, w, h, 14, p2.darkThr);
            for (int i = 0; i < l.length; i++) if (sl[i] != 0) l[i] = 1;
        }
        // v8.63: en grises o a color, un salto fuerte de tono (cara clara / pelo gris) tambien corta:
        // si no, el color se escapaba por donde la linea no esta completa
        if (soft || zoneKind == com.pacco.animecut.core.ZoneTone.KIND_COLOR) {
            byte[] tw = com.pacco.animecut.core.ZoneTone.toneWalls(ref, w, h, 60);
            for (int i = 0; i < l.length; i++) if (tw[i] != 0) l[i] = 1;
        }
        // v8.68: las sombras gris oscuro del dibujo (pliegues del saco, sombras del lazo) NO son
        // lineas: se pueden pintar. Solo un salto de tono muy fuerte (pelo oscuro junto a la cara) corta.
        {
            byte[] sh = com.pacco.animecut.core.ZoneTone.shadeMask(ref, w, h, 0, 0, w, h);
            byte[] strong = com.pacco.animecut.core.ZoneTone.toneWalls(ref, w, h, 100);
            for (int i = 0; i < l.length; i++) if (sh[i] != 0 && strong[i] == 0) l[i] = 0;
        }
        com.pacco.animecut.core.ZoneTone.addAlphaWalls(ref, w, l);
        final int k = zoneKind;
        post(new Runnable() {
            @Override public void run() {
                if (!hintedZoneKind) {
                    hintedZoneKind = true;
                    showHud("Dibujo: " + com.pacco.animecut.core.ZoneTone.KIND_NAMES[k]
                            + (k == com.pacco.animecut.core.ZoneTone.KIND_TONE ? " · la trama se suaviza solo para calcular la luz" : ""), 2600);
                }
            }
        });
        return l;
    }

    private boolean hintedZoneKind;

    /** Tabla de colores de la vista previa (estadistica de las zonas de la vista previa). */
    private int[] zonePreviewLut(Rect r) {
        int[] ref = fillPreviewRef;
        if (ref == null || project == null || ref.length != project.w * project.h) return null;
        int rw = r.width(), rh = r.height();
        byte[] m = new byte[rw * rh];
        for (PreviewZone z : fillPreview) {
            int zw = z.r.width();
            for (int y = z.r.top; y < z.r.bottom; y++)
                for (int x = z.r.left; x < z.r.right; x++)
                    if (z.m[(y - z.r.top) * zw + x - z.r.left] != 0) m[(y - r.top) * rw + x - r.left] = (byte) 255;
        }
        com.pacco.animecut.core.ZoneTone.Zone zz = new com.pacco.animecut.core.ZoneTone.Zone(r.left, r.top, rw, rh, m, project.zoneStyle);
        com.pacco.animecut.core.ZoneTone.Stats st = com.pacco.animecut.core.ZoneTone.stats(ref, project.w, zz);
        if (st.n == 0) return null;
        int[] lut = com.pacco.animecut.core.ZoneTone.lut(project.zoneStyle, st, false);
        int inten = project.zoneStyle.intensity;
        if (inten < 100 && project.zoneStyle.finish != com.pacco.animecut.core.ZoneTone.IMPROVE) {
            for (int v = 0; v < 256; v++)
                lut[v] = com.pacco.animecut.core.ZoneTone.mixRgb(0xFF000000 | (v << 16) | (v << 8) | v, lut[v], inten / 100f);
        }
        return lut;
    }

    /** La capa "Color zonas" (Normal, encima de la tinta). La crea si falta (dentro del deshacer abierto). */
    private Layer ensureToneLayer(boolean[] created) {
        Layer t = roleLayer(Layer.ROLE_TONE);
        if (t != null && project.layers.contains(t)) return t;
        undo.recordStruct();
        undo.recordProps();
        t = new Layer(uniqueName(TONE_NAME), project.w, project.h);
        t.role = Layer.ROLE_TONE;
        t.mode = Layer.MODE_NORMAL;
        Layer ink = mangaInk();
        int at = ink != null ? project.layers.indexOf(ink) + 1 : Math.max(0, project.active + 1);
        project.layers.add(Math.min(at, project.layers.size()), t);
        // v8.68: la capa de trabajo pasa a ser "Color zonas" (el pincel ya no cae en la tinta)
        Layer act = project.active >= 0 && project.active < project.layers.size() ? project.layers.get(project.active) : null;
        if (act == null || act == ink || act.reference) project.active = project.layers.indexOf(t);
        if (created != null) created[0] = true;
        return t;
    }

    /** Pinta las zonas aceptadas (una zona = union de las tocadas, con el estilo del panel). */
    private void applyToneZones(java.util.List<PreviewZone> zs, int[] refIn) {
        if (project == null || zs.isEmpty()) return;
        final int W = project.w, H = project.h;
        byte[] full = new byte[W * H];
        for (PreviewZone z : zs) {
            int zw = z.r.width();
            for (int y = z.r.top; y < z.r.bottom; y++)
                for (int x = z.r.left; x < z.r.right; x++)
                    if (z.m[(y - z.r.top) * zw + x - z.r.left] != 0) full[y * W + x] = (byte) 255;
        }
        // Lazo / seleccion: limita la zona (corregir antes de aplicar); zonas protegidas: fuera
        if (project.hasSelection()) {
            byte[] sel = project.selection;
            for (int i = 0; i < full.length; i++) if (full[i] != 0) full[i] = (byte) Math.min(full[i] & 0xFF, sel[i] & 0xFF);
        }
        if (project.protect != null && project.protect.length == full.length)
            for (int i = 0; i < full.length; i++) if (project.protect[i] != 0) full[i] = 0;
        com.pacco.animecut.core.ZoneTone.feather(full, W, H);      // borde sin escalones
        final com.pacco.animecut.core.ZoneTone.Zone zone =
                com.pacco.animecut.core.ZoneTone.fromMask(full, W, H, project.zoneStyle.copy());
        if (zone == null) { msg("La zona quedo vacia (fuera de la seleccion o protegida)"); return; }
        // v8.69: aviso claro cuando el color no va a cambiar nada (antes solo salia "Zona N")
        String same = sameColorHint(zone);
        if (same != null) { showHud(same, 2600); return; }
        final int[] ref = refIn != null && refIn.length == W * H ? refIn : mangaRef(zoneRefTarget());
        final Project owner = project;
        final int[][] out = new int[1][];
        final java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone> allZ =
                new java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone>(project.zones);
        allZ.add(zone);
        setBusy(true);
        Task.run(new Runnable() {
            @Override public void run() {
                try { out[0] = com.pacco.animecut.core.ZoneTone.renderLocal(ref, W, H, zone, allZ); }
                catch (OutOfMemoryError e) { out[0] = null; }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project) return;            // se cambio de obra: no se aplica nada
                if (out[0] == null) { msg("No se pudo colorear la zona (falta memoria)"); return; }
                Rect r = new Rect(zone.x, zone.y, zone.x + zone.w, zone.y + zone.h);
                boolean[] created = {false};
                undo.setLabel("Color por zonas");
                undo.begin();
                Layer t = ensureToneLayer(created);
                undo.recordZones();
                undo.recordLayer(t, r);
                undo.end();
                com.pacco.animecut.core.ZoneTone.paste(out[0], zone, W, H, t.px(), null);
                project.zones.add(zone);
                zoneSel = project.zones.size() - 1;
                project.markDirty();
                if (created[0]) layersChanged();
                pixelsChanged(r);
                showHud("Zona " + project.zones.size() + " · " + com.pacco.animecut.core.ZoneTone.FINISH_NAMES[zone.s.finish]
                        + " · se puede cambiar despues en Zonas", 2200);
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    /**
     * v8.69: si la parte ya esta pintada con ese mismo color, o es blanco sobre papel blanco, no se
     * crea otra zona encima (no cambiaria nada): se avisa. null = se puede pintar.
     */
    private String sameColorHint(com.pacco.animecut.core.ZoneTone.Zone nz) {
        int W = project.w;
        int base = nz.s.base & 0xFFFFFF;
        long area = 0;
        for (byte b : nz.m) if ((b & 0xFF) >= 128) area++;
        if (area == 0) return null;
        // cuanto de esa parte ya esta pintado de verdad en "Color zonas" (si se borro con la goma,
        // se puede volver a pintar con el mismo color)
        Layer t = roleLayer(Layer.ROLE_TONE);
        int[] px = t != null && project.layers.contains(t) && !project.zones.isEmpty() ? t.px() : null;
        long painted = 0;
        if (px != null)
            for (int y = 0; y < nz.h; y++)
                for (int x = 0; x < nz.w; x++)
                    if ((nz.m[y * nz.w + x] & 0xFF) >= 128 && (px[(y + nz.y) * W + x + nz.x] >>> 24) > 40) painted++;
        if (painted * 10 >= area * 8) for (com.pacco.animecut.core.ZoneTone.Zone oz : project.zones) {
            if ((oz.s.base & 0xFFFFFF) != base || oz.s.finish != nz.s.finish) continue;
            int x0 = Math.max(oz.x, nz.x), y0 = Math.max(oz.y, nz.y);
            int x1 = Math.min(oz.x + oz.w, nz.x + nz.w), y1 = Math.min(oz.y + oz.h, nz.y + nz.h);
            if (x1 <= x0 || y1 <= y0) continue;
            long in = 0;
            for (int y = y0; y < y1; y++)
                for (int x = x0; x < x1; x++)
                    if ((nz.m[(y - nz.y) * nz.w + x - nz.x] & 0xFF) >= 128
                            && (oz.m[(y - oz.y) * oz.w + x - oz.x] & 0xFF) >= 128) in++;
            if (in * 10 >= area * 9) return "Esta parte ya tiene ese color: elige otro color abajo";
        }
        int r = (base >> 16) & 0xFF, g = (base >> 8) & 0xFF, b = base & 0xFF;
        if (r > 246 && g > 246 && b > 246 && nz.s.finish == com.pacco.animecut.core.ZoneTone.MULTIPLY) {
            if (painted * 5 < area) return "Blanco sobre papel blanco no se nota: elige otro color abajo";
        }
        return null;
    }

    /** Cambia el estilo de una zona ya pintada (tonos, acabado, intensidad) sin repintar a mano. */
    public void restyleZone(int idx, com.pacco.animecut.core.ZoneTone.Style st) {
        if (project == null || idx < 0 || idx >= project.zones.size() || st == null) return;
        rerenderZone(idx, project.zones.get(idx).withStyle(st.copy()), "Cambiar zona");
    }

    /**
     * v8.43 Colorear facil, paso 2: el mismo acabado (sombras) para TODAS las zonas de una vez.
     * Se borra lo de las zonas en "Color zonas" y se pintan todas de nuevo (con Deshacer).
     */
    public void restyleAllZones(final int finish) {
        restyleAllZones(finish, -1, null, null, -1);
    }

    /**
     * v8.47: tambien fuerza (0..100, -1 = no cambiar), sombra automatica, brillo de pelo y
     * direccion de la luz (-1 = no cambiar). El brillo va solo a la zona del pelo (la mas arriba y
     * oscura del personaje).
     */
    public void restyleAllZones(final int finish, int power, Boolean autoShade, Boolean shine, int lightDir) {
        if (project == null || project.zones.isEmpty() || busy) return;
        final java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone> after =
                new java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone>();
        java.util.Set<Integer> hair = shine != null && shine ? hairZones(project.zones) : null;
        for (int zi = 0; zi < project.zones.size(); zi++) {
            com.pacco.animecut.core.ZoneTone.Zone z = project.zones.get(zi);
            com.pacco.animecut.core.ZoneTone.Style st = z.s.copy();
            st.finish = finish;
            if (power >= 0) st.power = power;
            if (autoShade != null) st.autoShade = autoShade;
            if (shine != null) st.shine = hair != null && hair.contains(zi);
            if (lightDir >= 0) st.lightDir = lightDir;
            after.add(z.withStyle(st));
        }
        project.zoneStyle.finish = finish;
        final Layer t = roleLayer(Layer.ROLE_TONE);
        if (t == null) {
            undo.setLabel("Sombras");
            undo.recordZones();
            project.zones = after;
            project.markDirty();
            return;
        }
        final int W = project.w, H = project.h;
        final byte[] area = new byte[W * H];
        for (com.pacco.animecut.core.ZoneTone.Zone z : project.zones)
            for (int y = 0; y < z.h; y++)
                for (int x = 0; x < z.w; x++)
                    if (z.m[y * z.w + x] != 0) {
                        int gx = x + z.x, gy = y + z.y;
                        if (gx >= 0 && gy >= 0 && gx < W && gy < H) area[gy * W + gx] = 1;
                    }
        final int[] ref = mangaRef(zoneRefTarget());
        final Project owner = project;
        final java.util.ArrayList<int[]> parts = new java.util.ArrayList<int[]>();
        setBusy(true);
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    for (com.pacco.animecut.core.ZoneTone.Zone z : after)
                        parts.add(com.pacco.animecut.core.ZoneTone.renderLocal(ref, W, H, z, after));
                } catch (OutOfMemoryError e) { parts.clear(); }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project || !project.layers.contains(t)) return;
                if (parts.size() != after.size()) { msg("Falta memoria para cambiar las sombras"); return; }
                undo.setLabel("Sombras");
                undo.begin();
                undo.recordZones();
                undo.recordLayer(t, project.fullRect());
                undo.end();
                int[] px = t.px();
                for (int i = 0; i < area.length; i++) if (area[i] != 0) px[i] = 0;
                for (int k = 0; k < after.size(); k++)
                    if (parts.get(k) != null) com.pacco.animecut.core.ZoneTone.paste(parts.get(k), after.get(k), W, H, px, area);
                project.zones = after;
                project.markDirty();
                pixelsChanged(project.fullRect());
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    /** v8.47: zonas del pelo: las de color mas oscuro entre las que estan arriba del personaje. */
    private java.util.Set<Integer> hairZones(java.util.List<com.pacco.animecut.core.ZoneTone.Zone> zs) {
        java.util.Set<Integer> out = new java.util.HashSet<Integer>();
        long big = (long) project.w * project.h * 35 / 100;
        int top = Integer.MAX_VALUE, bottom = 0;
        for (com.pacco.animecut.core.ZoneTone.Zone z : zs) {
            if (z.area() > big) continue;
            top = Math.min(top, z.y);
            bottom = Math.max(bottom, z.y + z.h);
        }
        if (top == Integer.MAX_VALUE) return out;
        int lim = top + Math.max(1, (bottom - top) / 4);
        int best = -1;
        float bestL = 9f;
        for (int i = 0; i < zs.size(); i++) {
            com.pacco.animecut.core.ZoneTone.Zone z = zs.get(i);
            if (z.area() > big || z.y > lim) continue;
            float L = com.pacco.animecut.core.ZoneTone.oklab(z.s.base)[0];
            if (L < 0.8f && L < bestL) { bestL = L; best = i; }
        }
        if (best < 0) return out;
        int base = zs.get(best).s.base;
        for (int i = 0; i < zs.size(); i++) if (zs.get(i).s.base == base && zs.get(i).area() <= big) out.add(i);
        return out;
    }

    public void deleteZone(int idx) {
        if (project == null || idx < 0 || idx >= project.zones.size()) return;
        rerenderZone(idx, null, "Borrar zona");
    }

    /**
     * Rehace los pixeles de una zona: se borran los de su mascara en "Color zonas" y se vuelven a
     * pintar (en orden) las zonas que tocan esa parte. Con deshacer. Fuera de la zona no cambia nada.
     */
    private void rerenderZone(final int idx, final com.pacco.animecut.core.ZoneTone.Zone repl, final String label) {
        final Layer t = roleLayer(Layer.ROLE_TONE);
        final int W = project.w, H = project.h;
        final com.pacco.animecut.core.ZoneTone.Zone old = project.zones.get(idx);
        final java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone> after =
                new java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Zone>(project.zones);
        if (repl != null) after.set(idx, repl); else after.remove(idx);
        if (t == null) {
            undo.setLabel(label);
            undo.recordZones();
            project.zones = after;
            project.markDirty();
            return;
        }
        final byte[] area = new byte[W * H];
        for (int y = 0; y < old.h; y++)
            for (int x = 0; x < old.w; x++)
                if (old.m[y * old.w + x] != 0) {
                    int gx = x + old.x, gy = y + old.y;
                    if (gx >= 0 && gy >= 0 && gx < W && gy < H) area[gy * W + gx] = 1;
                }
        final Rect r = new Rect(old.x, old.y, old.x + old.w, old.y + old.h);
        final int[] ref = mangaRef(zoneRefTarget());
        final Project owner = project;
        final java.util.ArrayList<Object[]> parts = new java.util.ArrayList<Object[]>();
        setBusy(true);
        Task.run(new Runnable() {
            @Override public void run() {
                for (com.pacco.animecut.core.ZoneTone.Zone z : after) {
                    if (z.x >= r.right || z.y >= r.bottom || z.x + z.w <= r.left || z.y + z.h <= r.top) continue;
                    try {
                        int[] loc = com.pacco.animecut.core.ZoneTone.renderLocal(ref, W, H, z, after);
                        if (loc != null) parts.add(new Object[]{z, loc});
                    } catch (OutOfMemoryError e) { parts.clear(); return; }
                }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project || !project.layers.contains(t)) return;
                undo.setLabel(label);
                undo.begin();
                undo.recordZones();
                undo.recordLayer(t, r);
                undo.end();
                int[] px = t.px();
                for (int i = 0; i < area.length; i++) if (area[i] != 0) px[i] = 0;
                for (Object[] o : parts)
                    com.pacco.animecut.core.ZoneTone.paste((int[]) o[1], (com.pacco.animecut.core.ZoneTone.Zone) o[0], W, H, px, area);
                project.zones = after;
                if (zoneSel >= after.size()) zoneSel = after.size() - 1;
                project.markDirty();
                pixelsChanged(r);
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    /** Lo seleccionado (Lazo, Varita, pincel de seleccion) entra a la vista previa como zona. */
    public boolean addSelectionAsZone() {
        if (project == null) return false;
        Rect b = project.selectionBounds();
        if (b == null || b.isEmpty()) { msg("Primero marca la zona con Lazo o Varita (lo azul)"); return false; }
        PreviewZone z = new PreviewZone();
        z.r = new Rect(b);
        int rw = b.width(), rh = b.height(), n = 0;
        z.m = new byte[rw * rh];
        for (int y = 0; y < rh; y++)
            for (int x = 0; x < rw; x++)
                if ((project.selection[(y + b.top) * project.w + x + b.left] & 0xFF) >= 128) { z.m[y * rw + x] = 1; n++; }
        if (n == 0) { msg("La seleccion esta vacia"); return false; }
        z.area = n;
        if (fillPreview.isEmpty()) {
            fillPreviewTarget = zoneRefTarget();
            fillPreviewRef = mangaRef(fillPreviewTarget);
        }
        fillPreview.add(z);
        project.clearSelection();
        refreshOverlay(null);
        rebuildPreviewBitmap();
        showHud("Seleccion agregada a la vista previa: ✓ para colorear");
        if (callback != null) callback.onToolStateChanged();
        return true;
    }

    // ---------------- brillo de contorno y fondo degradado ----------------

    private byte[] zoneSilhouette(int[] ref) {
        int W = project.w, H = project.h;
        byte[] u = com.pacco.animecut.core.ZoneTone.union(project.zones, W, H);
        return com.pacco.animecut.core.ZoneTone.silhouette(u, ref, W, H, Math.max(4, Math.max(W, H) / 150));
    }

    /**
     * Brillo de contorno: franja de luz en el borde del personaje, del lado de la luz, en su capa
     * (Pantalla, arriba de todo). No toca el original; se apaga con el ojo o con Quitar.
     */
    public void applyRim(final int color, final int dir, final int level) {
        if (project == null) return;
        if (project.zones.isEmpty() && !refHasTransparency()) { msg("Primero colorea alguna zona (o recorta el personaje)"); return; }
        final int W = project.w, H = project.h;
        final int[] ref = mangaRef(zoneRefTarget());
        final Project owner = project;
        final byte[][] rim = new byte[1][];
        setBusy(true);
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    byte[] sil = zoneSilhouette(ref);
                    int wpx = Math.max(2, Math.max(W, H) * Math.max(1, Math.min(10, level)) / 600);
                    rim[0] = com.pacco.animecut.core.ZoneTone.rim(sil, W, H, dir, wpx);
                } catch (OutOfMemoryError e) { rim[0] = null; }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project || rim[0] == null) return;
                undo.setLabel("Brillo de contorno");
                undo.begin();
                Layer l = roleLayer(Layer.ROLE_RIM);
                boolean created = false;
                if (l == null) {
                    undo.recordStruct();
                    l = new Layer(uniqueName(RIM_NAME), W, H);
                    l.role = Layer.ROLE_RIM;
                    l.mode = Layer.MODE_SCREEN;
                    project.layers.add(l);
                    created = true;
                } else {
                    undo.recordLayer(l, project.fullRect());
                }
                undo.end();
                int[] px = l.px();
                int c = color & 0x00FFFFFF;
                for (int i = 0; i < px.length; i++) {
                    int a = (rim[0][i] & 0xFF) * 220 / 255;
                    px[i] = a == 0 ? 0 : (a << 24) | c;
                }
                l.visible = true;
                project.zoneFx[0] = color; project.zoneFx[1] = dir; project.zoneFx[2] = level;
                project.markDirty();
                if (created) layersChanged();
                pixelsChanged(project.fullRect());
                showHud("Brillo de contorno en su capa (" + RIM_NAME + "): se apaga con el ojo", 2200);
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    private boolean refHasTransparency() {
        Layer ink = mangaInk();
        return ink != null && layerHasTransparency(ink);
    }

    /**
     * Fondo degradado de dos colores. Si el personaje esta recortado (fondo transparente) va abajo
     * de todo; si no, va en Multiplicar sobre el papel, solo FUERA del personaje. En su capa: el
     * fondo original no se reemplaza y el PNG puede quedar sin fondo (se apaga con el ojo).
     */
    public void applyGradient(final int top, final int bottom) {
        if (project == null) return;
        final int W = project.w, H = project.h;
        final boolean cut = refHasTransparency();
        if (!cut && project.zones.isEmpty()) { msg("Primero colorea alguna zona (para saber donde esta el personaje)"); return; }
        final int[] ref = mangaRef(zoneRefTarget());
        final Project owner = project;
        final int[][] px = new int[1][];
        setBusy(true);
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    int[] o = new int[W * H];
                    com.pacco.animecut.core.ZoneTone.gradient(o, W, H, top, bottom, cut ? null : zoneSilhouette(ref));
                    px[0] = o;
                } catch (OutOfMemoryError e) { px[0] = null; }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project || px[0] == null) return;
                undo.setLabel("Fondo degradado");
                undo.begin();
                Layer old = roleLayer(Layer.ROLE_GRAD);
                undo.recordStruct();
                undo.recordProps();
                if (old != null) project.layers.remove(old);
                Layer l = new Layer(uniqueName(GRAD_NAME), px[0]);
                l.role = Layer.ROLE_GRAD;
                if (cut) {
                    l.mode = Layer.MODE_NORMAL;
                    project.layers.add(0, l);
                } else {
                    l.mode = Layer.MODE_MULTIPLY;
                    Layer ink = mangaInk();
                    int at = ink != null ? project.layers.indexOf(ink) + 1 : 0;
                    project.layers.add(Math.min(at, project.layers.size()), l);
                }
                undo.end();
                project.active = Math.max(0, Math.min(project.active, project.layers.size() - 1));
                project.zoneFx[3] = top; project.zoneFx[4] = bottom;
                project.markDirty();
                layersChanged();
                showHud(cut ? "Fondo degradado detras del personaje (se apaga con el ojo)"
                        : "Fondo degradado sobre el papel, fuera del personaje (en su capa)", 2400);
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    /** Quita la capa del brillo o del fondo (con deshacer). */
    public void removeRoleLayer(int role) {
        Layer l = roleLayer(role);
        if (l == null) return;
        undo.setLabel("Quitar capa");
        undo.begin();
        undo.recordStruct();
        undo.end();
        project.layers.remove(l);
        project.active = Math.max(0, Math.min(project.active, project.layers.size() - 1));
        layersChanged();
        if (callback != null) callback.onToolStateChanged();
    }

    public boolean hasRoleLayer(int role) { return roleLayer(role) != null; }


    public void setFillPreview(boolean on) {
        fillPreviewOn = on;
        if (!on) cancelFillPreview();
    }

    public boolean isFillPreview() { return fillPreviewOn; }

    public void setMangaTone(boolean on) { setMangaToneLevel(on ? 1 : 0); }

    public boolean isMangaTone() { return mangaPrm.tone; }

    /** Modo trama: 0 No, 1 Puntos sueltos (de fabrica), 2 Densa (experimental). */
    private int mangaToneLevel = 1;
    public static final String[] TONE_NAMES = {"No", "Puntos sueltos", "Densa (revisar vista previa)"};

    public void setMangaToneLevel(int lv) {
        mangaToneLevel = Math.max(0, Math.min(2, lv));
        mangaPrm.tone = mangaToneLevel >= 1;
        mangaLines = null;
        mangaTexture = null;
    }

    public int getMangaToneLevel() { return mangaToneLevel; }

    public void setMangaGapLevel(int lv) {
        mangaGapLevel = Math.max(0, Math.min(3, lv));
        mangaPrm.gap = com.pacco.animecut.core.MangaFill.GAP_LEVELS[mangaGapLevel];
    }

    public int getMangaGapLevel() { return mangaGapLevel; }

    public void setMangaExpand(int px) { mangaPrm.expand = Math.max(0, Math.min(6, px)); }

    public int getMangaExpand() { return mangaPrm.expand; }

    /** Umbral de tinta: lo mas oscuro que esto es linea (64..200). */
    public void setMangaInk(int thr) { mangaPrm.darkThr = Math.max(40, Math.min(220, thr)); mangaLines = null; }

    public int getMangaInk() { return mangaPrm.darkThr; }

    // ---------------- capas del preset ----------------

    public Layer mangaInk() {
        if (project == null) return null;
        for (Layer l : project.layers) if (l.role == Layer.ROLE_INK) return l;
        return null;
    }

    public Layer mangaBase() {
        if (project == null) return null;
        for (Layer l : project.layers) if (l.role == Layer.ROLE_BASE) return l;
        return null;
    }

    private static boolean hasPixels(Layer l, int w, int h) {
        return l != null && l.bounds(w, h) != null;
    }

    /** v8.55c: parte del lienzo (0..1) que la capa cubre con pixeles casi opacos (muestreo). */
    private float coverage(Layer l) {
        if (project == null || l == null) return 0f;
        int w = project.w, h = project.h;
        int step = Math.max(1, (int) Math.sqrt((double) w * h / 40000.0));
        int tot = 0, op = 0;
        for (int y = step / 2; y < h; y += step)
            for (int x = step / 2; x < w; x += step) {
                tot++;
                if ((l.at(x, y, w) >>> 24) > 128) op++;
            }
        return tot == 0 ? 0f : op / (float) tot;
    }

    /** Capa visible, sin papel especial, que cubre al menos la mitad del lienzo (la que mas cubre); -1 si no hay. */
    private int bestInkLayer() {
        int best = -1;
        float bc = 0.5f;
        for (int i = 0; i < project.layers.size(); i++) {
            Layer l = project.layers.get(i);
            if (!l.visible || (l.role != Layer.ROLE_NONE && l.role != Layer.ROLE_INK)) continue;
            float c = coverage(l);
            if (c >= bc) { bc = c; best = i; }
        }
        return best;
    }

    /**
     * v8.55c: si la "Tinta B/N" casi no tiene dibujo (se eligio por error una capa de Toques o una
     * vacia), se cambia por la imagen que mas cubre el lienzo. Sin esto, todo lo transparente de esa
     * capa contaba como linea y cada toque decia "Tocaste la linea negra". Se puede deshacer.
     */
    public boolean repairMangaInk() {
        if (project == null) return false;
        Layer ink = mangaInk();
        if (ink == null || coverage(ink) >= 0.25f) return false;
        int bi = -1;
        float bc = 0.5f;
        for (int i = 0; i < project.layers.size(); i++) {
            Layer l = project.layers.get(i);
            if (l == ink || l.role != Layer.ROLE_NONE) continue;
            float c = coverage(l);
            if (c >= bc) { bc = c; bi = i; }
        }
        if (bi < 0) return false;
        Layer best = project.layers.get(bi);
        undo.setLabel("Arreglar la tinta del manga");
        undo.begin();
        undo.recordStruct();
        undo.recordProps();
        ink.role = Layer.ROLE_NONE;
        ink.locked = false;
        ink.reference = false;
        ink.name = uniqueName("capa (antes Tinta)");
        best.name = INK_NAME;
        best.role = Layer.ROLE_INK;
        best.locked = true;
        best.reference = true;
        best.visible = true;
        // las capas de color tienen que quedar ENCIMA de la tinta (si no, la imagen las tapa)
        int at = project.layers.indexOf(best);
        java.util.ArrayList<Layer> move = new java.util.ArrayList<Layer>();
        for (int i = 0; i < at; i++) {
            Layer l = project.layers.get(i);
            int r = l.role;
            if (r == Layer.ROLE_BASE || r == Layer.ROLE_TONE || r == Layer.ROLE_SHADOW || r == Layer.ROLE_LIGHT
                    || r == Layer.ROLE_COLOR || r == Layer.ROLE_SHINE || r == Layer.ROLE_SOFT) move.add(l);
        }
        Layer act = project.activeLayer();
        if (!move.isEmpty()) {
            project.layers.removeAll(move);
            at = project.layers.indexOf(best);
            project.layers.addAll(at + 1, move);
        }
        int ai = act == null ? -1 : project.layers.indexOf(act);
        project.active = ai >= 0 ? ai : project.layers.indexOf(best);
        undo.end();
        mangaLines = null;
        mangaTexture = null;
        zoneKind = -1;
        layersChanged();
        showHud("Arreglado: la tinta ahora es \"" + INK_NAME + "\" (la imagen). Deshacer lo devuelve", 2800);
        return true;
    }

    /**
     * Que capa seria la tinta: -2 si el preset ya esta hecho; -1 si no se puede
     * decidir solo (hay varias capas con dibujo: la interfaz pregunta); si no, el indice.
     */
    public int mangaInkCandidate() {
        if (project == null) return -1;
        if (mangaInk() != null) return -2;
        // v8.55c: la imagen que mas cubre el lienzo (sin capas de efecto: Toques, Luz, Estilo...).
        // Antes, con una capa de Toques visible preguntaba cual era el manga y era facil elegir la
        // capa de Toques: quedaba como "Tinta" (casi vacia) y todo el lienzo contaba como linea.
        int best = bestInkLayer();
        if (best >= 0) return best;
        int found = -1, count = 0;
        for (int i = 0; i < project.layers.size(); i++) {
            Layer l = project.layers.get(i);
            if (!l.visible || !hasPixels(l, project.w, project.h)) continue;
            count++;
            found = i;
        }
        if (count == 1) return found;
        return -1;
    }

    /**
     * Prepara el coloreado de manga sobre la capa inkIdx (el original NO cambia):
     * la renombra "Tinta B/N", la bloquea por completo, la marca como referencia de
     * contornos y crea encima "Color base" en Multiplicar 100 %, que queda elegida.
     * Si ya estaba preparado, solo vuelve a activar el modo y elige el Color base
     * (no crea duplicados). Todo se deshace de una vez.
     */
    public boolean prepareManga(int inkIdx) { return prepareManga(inkIdx, true); }

    /**
     * v8.66: withBase=false (Colorear facil): el color va en "Color zonas", asi que NO se crea el
     * "Color base" (quedaba una capa vacia encima). Si ya habia un Color base vacio, se quita.
     */
    public boolean prepareManga(int inkIdx, boolean withBase) {
        if (project == null) return false;
        cancelFillPreview();
        Layer ink = mangaInk();
        Layer base = mangaBase();
        undo.setLabel("Colorear manga");
        undo.begin();
        undo.recordStruct();
        undo.recordProps();
        if (ink == null) {
            if (inkIdx < 0 || inkIdx >= project.layers.size()) {
                undo.end();
                msg("Elige en Capas la capa del manga");
                return false;
            }
            ink = project.layers.get(inkIdx);
            ink.name = INK_NAME;
            ink.role = Layer.ROLE_INK;
            ink.locked = withBase;          // v8.68: en Colorear NO se bloquea sola
            ink.reference = true;
            ink.visible = true;
            for (Layer l : project.layers) if (l != ink) l.reference = false;
        } else {
            if (withBase) ink.locked = true;
            else ink.locked = false;        // v8.68: las versiones viejas la bloqueaban solas
            ink.reference = true;
        }
        if (!withBase) {
            if (base != null && !hasPixels(base, project.w, project.h)) {
                project.layers.remove(base);
                base = null;
            }
        } else if (base == null) {
            base = new Layer(BASE_NAME, project.w, project.h);
            base.mode = Layer.MODE_MULTIPLY;
            base.opacity = 255;
            base.role = Layer.ROLE_BASE;
            int at = project.layers.indexOf(ink) + 1;
            project.layers.add(Math.min(at, project.layers.size()), base);
        }
        project.mangaMode = true;
        if (base != null) project.active = project.layers.indexOf(base);
        else {
            Layer tone = roleLayer(Layer.ROLE_TONE);
            if (tone != null) project.active = project.layers.indexOf(tone);
            else project.active = Math.max(0, Math.min(project.layers.size() - 1, project.active));
        }
        undo.end();
        mangaLines = null;
        fillPreviewOn = true;
        layersChanged();
        showHud("Toca una zona para rellenar; la tinta esta protegida. Usa Lazo si el contorno esta abierto");
        if (callback != null) callback.onToolStateChanged();
        return true;
    }

    /** Sale del preset: el balde vuelve a ser el normal y la tinta se puede editar. Las capas quedan. */
    public void exitManga() {
        if (project == null || !project.mangaMode) return;
        cancelFillPreview();
        undo.setLabel("Salir de Colorear manga");
        undo.recordProps();
        project.mangaMode = false;
        Layer ink = mangaInk();
        if (ink != null) ink.locked = false;
        layersChanged();
        showHud("Colorear manga apagado: tus capas de color se quedan");
        if (callback != null) callback.onToolStateChanged();
    }

    /** Donde va el color en modo manga: la capa elegida si se puede pintar; si no, el Color base. */
    private Layer mangaTarget() {
        Layer a = target();
        if (a != null && !a.locked && a.role != Layer.ROLE_INK) return a;
        Layer b = mangaBase();
        if (b != null && !b.locked) {
            project.active = project.layers.indexOf(b);
            showHud("El color va en \"" + b.name + "\": la tinta esta bloqueada");
            changed();
            return b;
        }
        msg("Esa capa esta bloqueada. Elige en Capas una capa de color");
        return null;
    }

    // ---------------- bloqueo total ----------------

    public void setLayerLocked(Layer l, boolean on) {
        if (l == null || project == null) return;
        undo.setLabel(on ? "Bloquear capa" : "Desbloquear capa");
        undo.recordProps();
        l.locked = on;
        changed();
    }

    private boolean refuseLocked(Layer t) {
        if (t != null && t.locked) {
            msg("\"" + t.name + "\" esta bloqueada (bloqueo total). Desbloqueala en Opciones de capa para editarla");
            return true;
        }
        return false;
    }

    // ---------------- lineas (cache) ----------------

    private byte[] mangaLines, mangaTexture;
    private Object mangaLinesKey;

    /** Clave de la cache: capas de referencia, su bloqueo y forma; si alguna no esta bloqueada, la version. */
    private Object mangaKey(Layer target) {
        java.util.ArrayList<Object> k = new java.util.ArrayList<Object>();
        k.add(project);
        k.add(project.w);
        k.add(project.h);
        k.add(project.geomVersion);
        k.add(mangaPrm.darkThr);
        k.add(mangaPrm.tone);
        k.add(isZoneMode());       // v8.40: en Color por zonas se suman las lineas suaves y las paredes
        k.add(zoneKind);
        boolean anyRef = false, allLocked = true;
        for (Layer l : project.layers) {
            if (!l.reference || !l.visible) continue;
            anyRef = true;
            k.add(System.identityHashCode(l));
            k.add(l.opacity);
            k.add(l.denseOrNull() != null ? System.identityHashCode(l.denseOrNull()) : System.identityHashCode(l.packedOrNull()));
            // v8.68: sin bloquear, la clave es la HUELLA del dibujo (no la version del proyecto):
            // pintar en "Color zonas" no obliga a recalcular las lineas en cada toque
            if (!l.locked) {
                int[] d = l.denseOrNull();
                if (d != null) k.add(java.util.Arrays.hashCode(d));
                else allLocked = false;
            }
        }
        if (!anyRef) {
            k.add("below");
            k.add(project.layers.indexOf(target));
            allLocked = false;
        }
        if (!allLocked) k.add(project.version);
        return k;
    }

    private int[] mangaRef(Layer target) {
        if (hasReferenceLayers()) return compositeReference();
        return compositeBelow(project.layers.indexOf(target));
    }

    // ---------------- vista previa del balde ----------------

    private static final class PreviewZone {
        Rect r;
        byte[] m;
        int area, seedLum;
        boolean suggested;
        /** v8.27: zona del balde normal (mascara 1..255 con filo antialias). */
        boolean bucket;
        /** Referencia de la que salio la zona (para mezclar el filo con la tinta). */
        int[] ref;
        int seedColor;
        boolean shade, flat;

        boolean has(int x, int y) {
            if (!r.contains(x, y)) return false;
            return m[(y - r.top) * r.width() + x - r.left] != 0;
        }
    }

    private final java.util.ArrayList<PreviewZone> fillPreview = new java.util.ArrayList<PreviewZone>();
    private Layer fillPreviewTarget;
    private Bitmap fillPreviewBmp;
    private Rect fillPreviewRect;
    private int fillPreviewSample = 1;
    private int[] fillPreviewRef;
    /** Ultimo resultado (diagnostico y pruebas). */
    public com.pacco.animecut.core.MangaFill.Result lastManga;
    /** Ultima vez que se rechazo un toque del balde manga (diagnostico). */
    public String lastMangaWhy;

    public boolean hasFillPreview() { return !fillPreview.isEmpty(); }

    public int fillPreviewCount() { return fillPreview.size(); }

    /** Pixeles que se pintarian si se acepta (union de las zonas). */
    public int fillPreviewArea() {
        byte[] u = previewUnion();
        int n = 0;
        if (u != null) for (byte b : u) if (b != 0) n++;
        return n;
    }

    private void runMangaBucket(final int sx, final int sy) {
        if (busy) return; // un calculo a la vez (un toque rapido extra no se encola)
        // tocar una zona de la vista previa la quita (ya sea propia o sugerida)
        for (int k = fillPreview.size() - 1; k >= 0; k--) {
            if (fillPreview.get(k).has(sx, sy)) {
                fillPreview.remove(k);
                rebuildPreviewBitmap();
                showHud(fillPreview.isEmpty() ? "Vista previa vacia" : "Zona quitada de la vista previa");
                if (callback != null) callback.onToolStateChanged();
                return;
            }
        }
        if (project.protect != null && project.protect[sy * project.w + sx] != 0) {
            lastMangaWhy = "protegida";
            msg("Esa zona esta protegida (No colorear)");
            return;
        }
        final boolean zoneOn = isZoneMode();
        final Layer t = fillPreview.isEmpty() ? (zoneOn ? zoneRefTarget() : mangaTarget()) : fillPreviewTarget;
        if (t == null) return;
        if (!zoneOn && t.mode == Layer.MODE_NORMAL && t.role != Layer.ROLE_SHINE && !t.clip && !hintedNormalManga) {
            hintedNormalManga = true;
            showHud("Esta capa esta en Normal: el color tapara la tinta. Usa \"Color base\" (Multiplicar)");
        }
        setBusy(true);
        final Project owner = project;
        final Object key = mangaKey(t);
        final com.pacco.animecut.core.MangaFill.Params prm = new com.pacco.animecut.core.MangaFill.Params();
        prm.darkThr = mangaPrm.darkThr;
        prm.tone = mangaPrm.tone;
        prm.maxDot = mangaPrm.maxDot;
        prm.maxDotSide = mangaPrm.maxDotSide;
        prm.gap = mangaPrm.gap;
        // bajo la linea solo en Multiplicar: en Normal taparia la tinta. v8.40: en Color por zonas
        // si (2 px): la linea se pinta con el tono oscuro de la zona, sin franja gris entre color y linea
        prm.expand = zoneOn ? Math.max(3, mangaPrm.expand) : t.mode == Layer.MODE_MULTIPLY ? mangaPrm.expand : 0;
        prm.holeMax = mangaPrm.holeMax;
        prm.protect = project.protect;
        prm.darkHoleLum = zoneOn ? 110 : 0;   // v8.66: sombras pintadas encerradas entran a la zona
        final boolean dense = mangaToneLevel == 2;
        final PreviewZone[] zoneOut = new PreviewZone[1];
        final com.pacco.animecut.core.MangaFill.Result[] resOut = new com.pacco.animecut.core.MangaFill.Result[1];
        Task.run(new Runnable() {
            @Override
            public void run() {
                int[] ref = mangaRef(t);
                fillPreviewRef = ref;
                if (mangaLines == null || !key.equals(mangaLinesKey) || mangaLines.length != ref.length) {
                    mangaLines = null;
                    mangaTexture = null;
                    if (zoneOn) mangaLines = zoneLines(ref, owner.w, owner.h, prm);
                    else mangaLines = com.pacco.animecut.core.MangaFill.lineMap(ref, owner.w, owner.h, prm);
                    mangaLinesKey = key;
                }
                if (dense && mangaTexture == null)
                    mangaTexture = com.pacco.animecut.core.MangaFill.textureMap(ref, mangaLines, owner.w, owner.h, prm);
                prm.texture = dense ? mangaTexture : null;
                byte[] out = new byte[owner.w * owner.h];
                int tx = sx, ty = sy;
                if (zoneOn) {
                    // v8.40: tocar un puntito de trama o una linea fina no falla: el lugar libre mas cercano
                    int[] fp = com.pacco.animecut.core.ZoneTone.nearestFree(mangaLines, owner.w, owner.h, sx, sy, 5);
                    if (fp != null) { tx = fp[0]; ty = fp[1]; }
                }
                com.pacco.animecut.core.MangaFill.Result res =
                        com.pacco.animecut.core.MangaFill.compute(ref, mangaLines, owner.w, owner.h, tx, ty, prm, out);
                resOut[0] = res;
                if (res != null) zoneOut[0] = cutZone(out, owner.w, res);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (owner != project) return;
                lastManga = resOut[0];
                PreviewZone z = zoneOut[0];
                if (z == null) {
                    lastMangaWhy = "linea";
                    msg("Tocaste la linea negra: toca dentro de la zona (o usa Lazo y Rellenar seleccion)");
                    return;
                }
                lastMangaWhy = null;
                z.seedLum = resOut[0].seedLum;
                // v8.55: en Colorear (zonas) cada toque pinta AL MOMENTO con el color elegido. Con la
                // vista previa, al elegir otro color se cambiaban todas las zonas pendientes, y tocar
                // de nuevo una zona la "despintaba" (la quitaba de la vista previa).
                if (!fillPreviewOn || zoneOn) {
                    java.util.ArrayList<PreviewZone> one = new java.util.ArrayList<PreviewZone>();
                    one.add(z);
                    if (zoneOn) applyToneZones(one, fillPreviewRef);
                    else applyZones(one, t);
                    return;
                }
                fillPreviewTarget = t;
                fillPreview.add(z);
                rebuildPreviewBitmap();
                showHud(fillPreview.size() == 1
                        ? "Vista previa: ✓ para pintar, ✕ para cancelar. Toca otra zona para sumarla"
                        : fillPreview.size() + " zonas en la vista previa");
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    private boolean hintedNormalManga;

    private static PreviewZone cutZone(byte[] out, int w, com.pacco.animecut.core.MangaFill.Result res) {
        PreviewZone z = new PreviewZone();
        z.r = new Rect(res.bounds);
        int rw = z.r.width(), rh = z.r.height();
        z.m = new byte[rw * rh];
        for (int y = 0; y < rh; y++) System.arraycopy(out, (y + z.r.top) * w + z.r.left, z.m, y * rw, rw);
        z.area = res.area;
        return z;
    }

    private byte[] previewUnion() {
        if (fillPreview.isEmpty() || project == null) return null;
        byte[] u = new byte[project.w * project.h];
        for (PreviewZone z : fillPreview) {
            int rw = z.r.width();
            for (int y = z.r.top; y < z.r.bottom; y++)
                for (int x = z.r.left; x < z.r.right; x++)
                    if (z.m[(y - z.r.top) * rw + x - z.r.left] != 0) u[y * project.w + x] = 1;
        }
        return u;
    }

    private Rect previewBounds() {
        Rect r = null;
        for (PreviewZone z : fillPreview) {
            if (r == null) r = new Rect(z.r);
            else r.union(z.r);
        }
        return r;
    }

    /** Pinta las zonas de la vista previa en la capa (con deshacer). Nada se escribe antes. */
    public void acceptFillPreview() {
        if (fillPreview.isEmpty() || project == null) return;
        if (fillPreview.get(0).bucket) {
            // v8.27: vista previa del balde normal: mismo destino que se mostro
            Layer bt = fillPreviewTarget;
            boolean bc = fillPreviewCreate, ba = fillPreviewAdopt;
            java.util.ArrayList<PreviewZone> bz = new java.util.ArrayList<PreviewZone>(fillPreview);
            clearPreviewState();
            if (bt != null && !project.layers.contains(bt)) {
                bt = null;
                bc = fillTarget == FILL_TARGET_AUTO && autoColorLayer() == null;
            }
            if (bt == null && !bc) bt = fillTarget == FILL_TARGET_AUTO ? autoColorLayer() : target();
            if (bt != null || bc) applyBucketZones(bz, bt, bc, ba);
            if (callback != null) callback.onToolStateChanged();
            return;
        }
        if (isZoneMode()) {
            // v8.40 Color por zonas: mapa de degradado en la capa "Color zonas"
            java.util.ArrayList<PreviewZone> zs = new java.util.ArrayList<PreviewZone>(fillPreview);
            int[] ref = fillPreviewRef;
            clearPreviewState();
            applyToneZones(zs, ref);
            if (callback != null) callback.onToolStateChanged();
            return;
        }
        Layer t = fillPreviewTarget != null && project.layers.contains(fillPreviewTarget) ? fillPreviewTarget : mangaTarget();
        java.util.ArrayList<PreviewZone> zs = new java.util.ArrayList<PreviewZone>(fillPreview);
        clearPreviewState();
        if (t != null) applyZones(zs, t);
        if (callback != null) callback.onToolStateChanged();
    }

    /** Cancelar: no se pinta nada. */
    public void cancelFillPreview() {
        if (fillPreview.isEmpty() && fillPreviewBmp == null) return;
        clearPreviewState();
        invalidate();
        if (callback != null) callback.onToolStateChanged();
    }

    private void clearPreviewState() {
        fillPreview.clear();
        fillPreviewTarget = null;
        fillPreviewCreate = false;
        fillPreviewAdopt = false;
        if (fillPreviewBmp != null && !fillPreviewBmp.isRecycled()) fillPreviewBmp.recycle();
        fillPreviewBmp = null;
        fillPreviewRect = null;
    }

    /** Ultimo color de relleno en una capa de color (para sugerir sombra y luz). */
    private int lastBaseColor = 0;

    private void applyZones(java.util.List<PreviewZone> zs, Layer t) {
        if (refuseLocked(t)) return;
        if (t.role != Layer.ROLE_SHADOW && t.role != Layer.ROLE_LIGHT) lastBaseColor = paintColor;
        Rect r = null;
        for (PreviewZone z : zs) {
            if (r == null) r = new Rect(z.r);
            else r.union(z.r);
        }
        if (r == null) return;
        int w = project.w;
        byte[] prot = project.protect;
        boolean useSel = project.hasSelection();
        undo.setLabel("Relleno manga");
        undo.begin();
        undo.recordLayer(t, r);
        undo.end();
        int[] px = t.px();
        int ca = paintColor >>> 24;
        for (PreviewZone z : zs) {
            int rw = z.r.width();
            for (int y = z.r.top; y < z.r.bottom; y++) {
                for (int x = z.r.left; x < z.r.right; x++) {
                    if (z.m[(y - z.r.top) * rw + x - z.r.left] == 0) continue;
                    int i = y * w + x;
                    if (prot != null && prot[i] != 0) continue;
                    float f = brushOpacity;
                    if (useSel) f *= (project.selection[i] & 0xFF) / 255f;
                    int sa = Math.round(f * ca);
                    if (sa <= 0) continue;
                    px[i] = t.alphaLock ? Project.lockOver(px[i], paintColor, sa) : Project.over(px[i], paintColor, sa);
                }
            }
        }
        pixelsChanged(r);
    }

    /**
     * "Parecidas": agrega a la vista previa otras zonas cercanas de tamano y tono
     * parecido (por ejemplo cuello o la otra mano). No pinta: el usuario quita las que
     * no quiere tocandolas y luego acepta.
     */
    public void suggestSimilarZones() {
        if (fillPreview.isEmpty() || mangaLines == null || fillPreviewRef == null) {
            msg("Primero toca una zona con el balde");
            return;
        }
        final PreviewZone last = fillPreview.get(fillPreview.size() - 1);
        final byte[] taken = previewUnion();
        final int[] ref = fillPreviewRef;
        final byte[] lines = mangaLines;
        final Project owner = project;
        final Layer t = fillPreviewTarget;
        final com.pacco.animecut.core.MangaFill.Params prm = new com.pacco.animecut.core.MangaFill.Params();
        prm.darkThr = mangaPrm.darkThr;
        prm.tone = mangaPrm.tone;
        prm.gap = mangaPrm.gap;
        prm.expand = t != null && t.mode == Layer.MODE_MULTIPLY ? mangaPrm.expand : 0;
        prm.protect = project.protect;
        prm.texture = mangaToneLevel == 2 ? mangaTexture : null;
        final java.util.ArrayList<PreviewZone> found = new java.util.ArrayList<PreviewZone>();
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                java.util.List<int[]> seeds = com.pacco.animecut.core.MangaFill.similarSeeds(ref, lines, prm.protect,
                        owner.w, owner.h, taken, last.r, last.area, last.seedLum, 6);
                byte[] mark = taken.clone();
                for (int[] s : seeds) {
                    if (mark[s[1] * owner.w + s[0]] != 0) continue;
                    byte[] out = new byte[owner.w * owner.h];
                    com.pacco.animecut.core.MangaFill.Result res =
                            com.pacco.animecut.core.MangaFill.compute(ref, lines, owner.w, owner.h, s[0], s[1], prm, out);
                    if (res == null) continue;
                    PreviewZone z = cutZone(out, owner.w, res);
                    z.suggested = true;
                    z.seedLum = res.seedLum;
                    found.add(z);
                    for (int i = 0; i < out.length; i++) if (out[i] != 0) mark[i] = 1;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (owner != project) return;
                fillPreview.addAll(found);
                rebuildPreviewBitmap();
                showHud(found.isEmpty() ? "No encontre zonas parecidas cerca"
                        : found.size() + " zonas parecidas (rayadas). Toca las que NO quieras para quitarlas");
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    /** Dibujo de la vista previa: color semitransparente, sugeridas rayadas y borde punteado. */
    private void rebuildPreviewBitmap() {
        if (fillPreviewBmp != null && !fillPreviewBmp.isRecycled()) fillPreviewBmp.recycle();
        fillPreviewBmp = null;
        fillPreviewRect = null;
        Rect r = previewBounds();
        if (r == null || project == null) {
            invalidate();
            return;
        }
        long area = (long) r.width() * r.height();
        int s = 1;
        while (area / ((long) s * s) > 3_000_000L) s++;
        int bw = Math.max(1, r.width() / s), bh = Math.max(1, r.height() / s);
        int[] row = new int[bw];
        int col = paintColor & 0x00FFFFFF;
        // v8.40: en Color por zonas la vista previa muestra el color de verdad (mapa de degradado)
        int[] zl = isZoneMode() ? zonePreviewLut(r) : null;
        int[] zref = fillPreviewRef;
        try {
            fillPreviewBmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError e) {
            fillPreviewBmp = null;
            return;
        }
        for (int y = 0; y < bh; y++) {
            int iy = r.top + y * s;
            for (int x = 0; x < bw; x++) {
                int ix = r.left + x * s;
                int v = 0;
                for (PreviewZone z : fillPreview) {
                    if (!z.has(ix, iy)) continue;
                    boolean edge = !z.has(ix - s, iy) || !z.has(ix + s, iy) || !z.has(ix, iy - s) || !z.has(ix, iy + s);
                    if (edge) v = (((ix + iy) / (3 * s)) & 1) == 0 ? 0xFF000000 : 0xFFFFFFFF;
                    // v8.60: la vista previa muestra el color DE VERDAD (antes iba medio transparente y
                    // al aplicar salia mas fuerte). Las sugeridas siguen rayadas para distinguirlas.
                    else if (zl != null && zref != null) {
                        int zc = zl[com.pacco.animecut.core.ZoneTone.lum(zref[iy * project.w + ix])] & 0x00FFFFFF;
                        v = (z.suggested && (((ix - iy) / (4 * s)) & 1) == 0 ? 0x70000000 : 0xFF000000) | zc;
                    }
                    else if (z.suggested) v = ((((ix - iy) / (4 * s)) & 1) == 0 ? 0xFF000000 : 0x50000000) | col;
                    else v = 0xFF000000 | col;
                    break;
                }
                row[x] = v;
            }
            fillPreviewBmp.setPixels(row, 0, bw, 0, y, bw, 1);
        }
        fillPreviewRect = r;
        fillPreviewSample = s;
        invalidate();
    }

    // ---------------- zonas protegidas ----------------

    private boolean showProtect = true;
    private Bitmap protectBmp;
    private int protectBmpScale = 1;

    public void setShowProtect(boolean on) { showProtect = on; invalidate(); }

    public boolean isShowProtect() { return showProtect; }

    public boolean hasProtectZones() { return project != null && project.hasProtect(); }

    /** add=true: lo seleccionado (azul) pasa a ser "No colorear"; false: deja de serlo. */
    public void protectSelection(boolean add) {
        if (project == null) return;
        if (!project.hasSelection()) {
            msg("Primero marca la zona con Lazo o Varita (lo azul)");
            return;
        }
        cancelFillPreview();
        undo.setLabel(add ? "Proteger zona" : "Quitar proteccion");
        undo.begin();
        undo.recordProtect();
        undo.recordSelection(project.fullRect());
        undo.end();
        int n = project.w * project.h;
        if (project.protect == null || project.protect.length != n) project.protect = new byte[n];
        int cnt = 0;
        for (int i = 0; i < n; i++) {
            if ((project.selection[i] & 0xFF) < 128) continue;
            project.protect[i] = add ? (byte) 1 : 0;
            cnt++;
        }
        project.clearSelection();
        paintOverlay(project.fullRect());
        rebuildProtectBitmap();
        project.markDirty();
        changed();
        showHud(add ? "Zona protegida: el balde y Rellenar seleccion no la tocan (" + cnt + " px)"
                : "Proteccion quitada en esa zona");
    }

    public void clearProtect() {
        if (project == null || project.protect == null) return;
        undo.setLabel("Borrar zonas protegidas");
        undo.recordProtect();
        project.protect = null;
        rebuildProtectBitmap();
        changed();
        showHud("Ya no hay zonas protegidas");
    }

    private void rebuildProtectBitmap() {
        if (protectBmp != null && !protectBmp.isRecycled()) protectBmp.recycle();
        protectBmp = null;
        if (project == null || !project.hasProtect()) {
            invalidate();
            return;
        }
        int max = Math.max(project.w, project.h);
        int s = max > 1440 ? (int) Math.ceil(max / 1440f) : 1;
        int bw = Math.max(1, project.w / s), bh = Math.max(1, project.h / s);
        try {
            protectBmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError e) {
            return;
        }
        int[] row = new int[bw];
        for (int y = 0; y < bh; y++) {
            for (int x = 0; x < bw; x++) {
                int ix = Math.min(project.w - 1, x * s), iy = Math.min(project.h - 1, y * s);
                boolean p = project.protect[iy * project.w + ix] != 0;
                row[x] = !p ? 0 : (((x + y) / 4) & 1) == 0 ? 0x90E03030 : 0x40E03030;
            }
            protectBmp.setPixels(row, 0, bw, 0, y, bw, 1);
        }
        protectBmpScale = s;
        invalidate();
    }

    private Paint fillPrevPaint;

    private void drawMangaOverlays(Canvas c) {
        boolean fillTool = mode == MODE_BUCKET || (project != null && project.mangaMode);
        if (showProtect && fillTool && project != null && project.protect != null) {
            if (protectBmp == null) rebuildProtectBitmap();
            if (protectBmp != null && !protectBmp.isRecycled()) {
                c.save();
                c.concat(view);
                c.scale(protectBmpScale, protectBmpScale);
                c.drawBitmap(protectBmp, 0, 0, previewPaint);
                c.restore();
            }
        }
        if (fillPreviewBmp != null && !fillPreviewBmp.isRecycled() && fillPreviewRect != null) {
            c.save();
            c.concat(view);
            // v8.60: si el color va a una capa en Multiplicar (Color base del manga), la vista previa
            // tambien multiplica: se ve igual que al aplicar (la tinta y los grises no se tapan)
            Layer dest = isZoneMode() ? roleLayer(Layer.ROLE_TONE) : target();
            if (fillPrevPaint == null) fillPrevPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
            fillPrevPaint.setXfermode(dest != null && dest.mode == Layer.MODE_MULTIPLY
                    ? new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.MULTIPLY) : null);
            c.drawBitmap(fillPreviewBmp, null, new RectF(fillPreviewRect.left, fillPreviewRect.top,
                    fillPreviewRect.left + fillPreviewBmp.getWidth() * fillPreviewSample,
                    fillPreviewRect.top + fillPreviewBmp.getHeight() * fillPreviewSample), fillPrevPaint);
            c.restore();
        }
    }

    // ---------------- rellenar seleccion ----------------

    /** Rellena lo azul con el color elegido (respeta el borde suave y las zonas protegidas). */
    public void fillSelectionWithColor() {
        if (project == null) return;
        if (!project.hasSelection()) {
            msg("Primero marca la zona con Lazo (lo azul)");
            return;
        }
        cancelFillPreview();
        Layer t = project.mangaMode ? mangaTarget() : needLayer();
        if (t == null || refuseLocked(t)) return;
        Rect r = project.selectionBounds();
        if (r == null) return;
        if (t.role != Layer.ROLE_SHADOW && t.role != Layer.ROLE_LIGHT) lastBaseColor = paintColor;
        int w = project.w;
        byte[] prot = project.protect;
        undo.setLabel("Rellenar seleccion");
        undo.begin();
        undo.recordLayer(t, r);
        undo.end();
        int[] px = t.px();
        int ca = paintColor >>> 24;
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                int i = y * w + x;
                int sel = project.selection[i] & 0xFF;
                if (sel == 0) continue;
                if (prot != null && prot[i] != 0) continue;
                int sa = Math.round(brushOpacity * ca * sel / 255f);
                if (sa <= 0) continue;
                px[i] = t.alphaLock ? Project.lockOver(px[i], paintColor, sa) : Project.over(px[i], paintColor, sa);
            }
        }
        pixelsChanged(r);
        showHud("Seleccion rellenada en \"" + t.name + "\"");
    }

    // ---------------- sombra, luz y brillo rapidos ----------------

    /**
     * Color de sombra sugerido para la capa Sombras (Multiplicar): el color base mezclado
     * con un violeta frio (35 %) y algo mas oscuro. Piel #FFDCC4 -> malva #B79EA6.
     */
    public static int suggestShadow(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        int vr = 142, vg = 124, vb = 195;
        r = Math.round((r * .65f + vr * .35f) * .85f);
        g = Math.round((g * .65f + vg * .35f) * .85f);
        b = Math.round((b * .65f + vb * .35f) * .85f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Color de luz sugerido (capa Luces en Pantalla): el color base mitad hacia un blanco calido. */
    public static int suggestLight(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        r = Math.round(r + (255 - r) * .5f);
        g = Math.round(g + (244 - g) * .5f);
        b = Math.round(b + (214 - b) * .5f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** La capa sobre la que se recortan sombra y luz: la base del grupo de la capa elegida. */
    private int clipBaseIndex() {
        Layer a = target();
        int i = a == null ? -1 : project.layers.indexOf(a);
        if (a == null || a.locked || a.role == Layer.ROLE_INK) {
            Layer b = mangaBase();
            return b == null ? -1 : project.layers.indexOf(b);
        }
        while (i > 0 && project.layers.get(i).clip) i--;
        return i;
    }

    /**
     * v8.33: Sombra automatica por direccion de luz: capa NUEVA recortada en Multiplicar (60 %)
     * con una base de sombra del lado contrario a la luz, por partes (respeta la linea). No toca
     * la capa del dibujo; se corrige con Brocha/Goma en su capa o se borra con Deshacer.
     * lx, ly = hacia donde va la luz.
     */
    public void addAutoShade(final float lx, final float ly, final int width, final boolean parts) {
        if (project == null || busy) return;
        cancelFillPreview();
        final int baseIdx = clipBaseIndex();
        if (baseIdx < 0) { msg("Elige en Capas la capa del personaje"); return; }
        final Layer base = project.layers.get(baseIdx);
        final int[] src;
        try { src = base.px(); } catch (OutOfMemoryError e) { msg("Falta memoria"); return; }
        final int W = project.w, H = project.h;
        final Project owner = project;
        final int[][] out = new int[1][];
        setBusy(true);
        showHud("Calculando sombra...");
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    byte[] lines = parts ? com.pacco.animecut.core.AutoLines.build(src, W, H) : null;
                    byte[] m = com.pacco.animecut.core.AutoShade.shade(src, W, H, lx, ly, width, lines);
                    int[] o = new int[W * H];
                    int col = 0x8C7BB8;   // sombra fria (violeta grisaceo) en Multiplicar
                    for (int i = 0; i < o.length; i++) { int a = m[i] & 0xFF; if (a > 0) o[i] = (a << 24) | col; }
                    out[0] = o;
                } catch (OutOfMemoryError e) {
                    out[0] = null;
                }
            }
        }, new Runnable() {
            @Override public void run() {
                setBusy(false);
                if (owner != project) return;
                if (out[0] == null) { msg("Falta memoria para la sombra"); return; }
                int at = project.layers.indexOf(base) + 1;
                if (at <= 0) return;
                while (at < project.layers.size() && project.layers.get(at).clip) at++;
                Layer l = new Layer(uniqueName("Sombra auto"), out[0]);
                l.mode = Layer.MODE_MULTIPLY;
                l.opacity = 153;
                l.clip = true;
                l.role = Layer.ROLE_SHADOW;
                undo.setLabel("Sombra automatica");
                undo.recordStruct();
                project.layers.add(at, l);
                project.active = at;
                layersChanged();
                showHud("Sombra en capa aparte (Multiplicar 60 %): corrigela con Brocha o Goma");
                if (callback != null) callback.onToolStateChanged();
            }
        });
    }

    /**
     * Sombra rapida (Multiplicar, 40 %) o Luz rapida (Pantalla, 60 %): capa recortada
     * al color base, encima del grupo. Deja elegida la Brocha con el color sugerido.
     */
    public Layer addQuickShadeLayer(boolean shadow) {
        if (project == null) return null;
        cancelFillPreview();
        int baseIdx = clipBaseIndex();
        if (baseIdx < 0) {
            msg("Primero elige en Capas la capa de color (o usa Colorear manga)");
            return null;
        }
        int at = baseIdx + 1;
        while (at < project.layers.size() && project.layers.get(at).clip) at++;
        Layer l = new Layer(uniqueName(shadow ? "Sombras" : "Luces"), project.w, project.h);
        l.mode = shadow ? Layer.MODE_MULTIPLY : Layer.MODE_SCREEN;
        l.opacity = shadow ? 102 : 153; // 40 % y 60 % (se cambian con el deslizador de opacidad)
        l.clip = true;
        l.role = shadow ? Layer.ROLE_SHADOW : Layer.ROLE_LIGHT;
        undo.setLabel(shadow ? "Sombra rapida" : "Luz rapida");
        undo.recordStruct();
        project.layers.add(at, l);
        project.active = at;
        // la sugerencia sale del ultimo color base usado (no de la sombra recien sugerida)
        int base = lastBaseColor != 0 ? lastBaseColor : paintColor;
        paintColor = shadow ? suggestShadow(base) : suggestLight(base);
        if (callback != null) callback.onColorPicked(paintColor);
        setMode(MODE_PAINT);
        layersChanged();
        showHud(shadow ? "Capa \"" + l.name + "\" (Multiplicar 40 %, recortada): pinta las sombras"
                : "Capa \"" + l.name + "\" (Pantalla 60 %, recortada): pinta las luces");
        if (callback != null) callback.onToolStateChanged();
        return l;
    }

    /** Brillo encima: capa Normal arriba de todo (blancos de los ojos, reflejos que tapan la tinta). */
    public Layer addShineLayer() {
        if (project == null) return null;
        cancelFillPreview();
        Layer l = new Layer(uniqueName("Brillos encima"), project.w, project.h);
        l.role = Layer.ROLE_SHINE;
        undo.setLabel("Brillo encima");
        undo.recordStruct();
        project.layers.add(l);
        project.active = project.layers.size() - 1;
        paintColor = 0xFFFFFFFF;
        if (callback != null) callback.onColorPicked(paintColor);
        setMode(MODE_PAINT);
        layersChanged();
        showHud("Capa \"" + l.name + "\" encima de todo (Normal): pinta brillos blancos");
        if (callback != null) callback.onToolStateChanged();
        return l;
    }

    // ---------------- cambiar color (tono, saturacion, luminosidad) ----------------

    /** Vista en vivo mientras se mueven los deslizadores (sin deshacer). */
    public void previewLayerAdjust(Layer l, int hue, int sat, int lit) {
        if (l == null) return;
        l.hue = hue;
        l.sat = sat;
        l.lit = lit;
        layersChangedAsync();
    }

    /** Fija el ajuste NO destructivo con deshacer. prev = valores antes del dialogo. */
    public void commitLayerAdjust(Layer l, int[] prev, int hue, int sat, int lit) {
        if (l == null) return;
        l.hue = prev[0];
        l.sat = prev[1];
        l.lit = prev[2];
        undo.setLabel("Cambiar color");
        undo.recordProps();
        l.hue = hue;
        l.sat = sat;
        l.lit = lit;
        layersChanged();
    }

    /** Pasa el ajuste a los pixeles (la capa queda sin ajuste). Se puede deshacer. */
    public void bakeLayerAdjust(Layer l) {
        if (l == null || !l.hasAdjust()) return;
        if (refuseLocked(l)) return;
        Rect b = l.bounds(project.w, project.h);
        undo.setLabel("Fijar color");
        undo.begin();
        undo.recordProps();
        if (b != null) undo.recordLayer(l, b);
        undo.end();
        if (b != null) {
            com.pacco.animecut.core.ColorAdjust adj = l.adjuster();
            int[] px = l.px();
            for (int y = b.top; y < b.bottom; y++)
                for (int x = b.left; x < b.right; x++) {
                    int i = y * project.w + x;
                    if (px[i] != 0) px[i] = adj.apply(px[i]);
                }
        }
        l.hue = l.sat = l.lit = 0;
        layersChanged();
    }

    /** Cambia el color SOLO de lo seleccionado en la capa elegida (destructivo, con deshacer). */
    public void adjustSelectionColors(int hue, int sat, int lit) {
        if (project == null) return;
        if (!project.hasSelection()) {
            msg("No hay nada seleccionado");
            return;
        }
        Layer t = needLayer();
        if (t == null) return;
        Rect r = project.selectionBounds();
        if (r == null) return;
        undo.setLabel("Cambiar color de la seleccion");
        undo.recordLayer(t, r);
        int[] px = t.px();
        for (int y = r.top; y < r.bottom; y++)
            for (int x = r.left; x < r.right; x++) {
                int i = y * project.w + x;
                int s = project.selection[i] & 0xFF;
                if (s == 0 || px[i] == 0) continue;
                int a = px[i] & 0xFF000000;
                int nc = com.pacco.animecut.core.ColorAdjust.adjustRgb(px[i] & 0xFFFFFF, hue, sat, lit);
                if (s >= 255) px[i] = a | nc;
                else {
                    int oc = px[i];
                    int rr = (((nc >> 16) & 255) * s + ((oc >> 16) & 255) * (255 - s)) / 255;
                    int gg = (((nc >> 8) & 255) * s + ((oc >> 8) & 255) * (255 - s)) / 255;
                    int bb = ((nc & 255) * s + (oc & 255) * (255 - s)) / 255;
                    px[i] = a | (rr << 16) | (gg << 8) | bb;
                }
            }
        pixelsChanged(r);
    }

    // ---------------- gotero Visible / Capa actual ----------------

    public static final int PICK_AUTO = 0, PICK_VISIBLE = 1, PICK_LAYER = 2;
    private int pickSource = PICK_AUTO;

    public void setPickSource(int s) { pickSource = Math.max(0, Math.min(2, s)); }

    public int getPickSource() { return pickSource; }

    /** Si el gotero tomara de la capa (true) o lo visible (false) ahora mismo. */
    public boolean pickFromLayerNow() {
        if (pickSource == PICK_LAYER) return true;
        if (pickSource == PICK_VISIBLE) return false;
        Layer a = target();
        return a != null && a.mode != Layer.MODE_NORMAL && !a.locked;
    }

    /**
     * Color del gotero en (x,y). "Visible": lo que se ve sobre papel blanco. "Capa
     * actual": el color de la capa elegida tal cual (con su Cambiar color); en una capa
     * Multiplicar evita copiar un tono ya oscurecido por la tinta y multiplicarlo dos veces.
     * Si la capa esta vacia ahi, usa lo visible y avisa.
     */
    public int pickColorAt(int x, int y) {
        if (project == null || x < 0 || y < 0 || x >= project.w || y >= project.h) return paintColor;
        if (pickFromLayerNow()) {
            Layer a = target();
            if (a != null) {
                int c = a.at(x, y, project.w);
                if ((c >>> 24) != 0) {
                    com.pacco.animecut.core.ColorAdjust adj = a.adjuster();
                    if (adj != null) c = adj.apply(c);
                    lastPickFromLayer = true;
                    return c | 0xFF000000;
                }
            }
            showHud("La capa esta vacia ahi: tome el color visible");
        }
        lastPickFromLayer = false;
        int v = project.ref()[y * project.w + x];
        return com.pacco.animecut.core.Compositor.overOpaque(0xFFFFFFFF, v);
    }

    /** Diagnostico: el ultimo gotero tomo de la capa. */
    public boolean lastPickFromLayer;

    // ---------------- exportar / medir ----------------

    /** v8.26: deshacer para cambios de propiedades hechos desde la interfaz (opacidad, ojo). */
    public void recordPropsUndo(String label) {
        if (undo == null || project == null) return;
        undo.setLabel(label);
        undo.recordProps();
    }

    /** Lo que se ve, sin fondo (para pruebas y para la exportacion completa). */
    public int[] flattenedPixels() {
        return project == null ? null : com.pacco.animecut.core.Compositor.flatten(project);
    }
}
