package com.pacco.animecut.core;

import java.util.Random;

/**
 * v8.81: efectos que salen de la SILUETA del dibujo (su transparencia) y lineas de manga.
 * Todos devuelven solo el efecto (para una capa nueva): contorno, resplandor de silueta,
 * lineas radiales (de concentracion) y lineas de velocidad. Java puro (pruebas de PC).
 *
 * Trabajan por franjas como los otros filtros: (ox,oy) = donde empieza la franja dentro de la
 * imagen (fw x fh) y s = escala (1 = tamano real). Las lineas se calculan con coordenadas de
 * toda la imagen: no hay cortes entre franjas.
 */
public final class EdgeFx {
    private EdgeFx() { }

    /** Modos de contorno y resplandor. */
    public static final int OUTER = 0, INNER = 1, BOTH = 2;

    private static final float INF = 1e12f;

    // ================================================================== contorno

    /**
     * Contorno: v0 grosor (px), v1 opacidad %, v2 suavidad. Exterior: la silueta engordada (va
     * DEBAJO del dibujo, asi el borde suave del dibujo cae sobre el contorno sin rendija).
     * Interior y ambos: el anillo (va ENCIMA). Sigue huecos y piezas sueltas.
     */
    static int[] outline(int[] in, int w, int h, Fx.P p, float s, Fx.Job job) {
        int n = w * h;
        int[] out = new int[n];
        float r = p.v[0] * s;
        float op = Math.max(0, Math.min(100, p.v[1])) / 100f * ((p.color >>> 24) / 255f);
        if (r <= 0f || op <= 0f) return out;
        int mode = p.mode;
        boolean[] inside = new boolean[n];
        boolean any = false, anyOut = false;
        for (int i = 0; i < n; i++) {
            inside[i] = (in[i] >>> 24) >= 128;
            if (inside[i]) any = true; else anyOut = true;
        }
        if (!any) return out;
        chk(job);
        float[] dOut = mode != INNER ? edt(inside, w, h, true) : null;       // distancia a lo de adentro
        chk(job);
        float[] dIn = mode != OUTER && anyOut ? edt(inside, w, h, false) : null;  // distancia a lo de afuera
        chk(job);
        float[] cov = new float[n];
        for (int i = 0; i < n; i++) {
            float a = (in[i] >>> 24) / 255f;
            float c;
            if (mode == OUTER) {
                c = Math.max(a, clamp01(r + 1f - (float) Math.sqrt(dOut[i])));
            } else if (mode == INNER) {
                float e = inside[i] ? (dIn == null ? INF : (float) Math.sqrt(dIn[i])) : 0f;
                c = a * clamp01(r + 1f - e);
            } else {
                if (inside[i]) c = clamp01(r + 1f - (dIn == null ? INF : (float) Math.sqrt(dIn[i])));
                else c = clamp01(r + 1f - (float) Math.sqrt(dOut[i]));
            }
            cov[i] = c;
        }
        float soft = Math.max(0, Math.min(100, p.v[2])) / 100f;
        if (soft > 0f) {
            float sig = soft * Math.max(0.6f, r * 0.45f);
            float[] keep = mode == OUTER ? alphaPlane(in) : null;
            Fx.gaussPlaneF(cov, new float[n], w, h, sig);
            if (mode == INNER) for (int i = 0; i < n; i++) cov[i] = Math.min(cov[i], (in[i] >>> 24) / 255f);
            if (keep != null) for (int i = 0; i < n; i++) cov[i] = Math.max(cov[i], keep[i]);
        }
        fill(out, cov, p.color, op);
        return out;
    }

    // ================================================================== resplandor de silueta

    /**
     * Resplandor que sale de la forma (no de lo claro: una figura oscura tambien brilla).
     * v0 radio (px), v1 intensidad %, v2 suavidad. Exterior va debajo; interior y ambos encima.
     */
    static int[] silGlow(int[] in, int w, int h, Fx.P p, float s, Fx.Job job) {
        int n = w * h;
        int[] out = new int[n];
        float rad = Math.max(1f, p.v[0] * s);
        float inten = Math.max(0, Math.min(200, p.v[1])) / 100f * ((p.color >>> 24) / 255f);
        if (inten <= 0f) return out;
        float[] a = alphaPlane(in);
        boolean any = false;
        for (float v : a) if (v > 0f) { any = true; break; }
        if (!any) return out;
        float soft = Math.max(0, Math.min(100, p.v[2])) / 100f;
        float gain = 1f + (1f - soft) * 3f;               // menos suavidad = borde del brillo mas firme
        float sig = rad * 0.5f;
        int mode = p.mode;
        float[] tmp = new float[n];
        float[] ext = null, inn = null;
        if (mode != INNER) {
            ext = a.clone();
            Fx.gaussPlaneF(ext, tmp, w, h, sig);
            chk(job);
        }
        if (mode != OUTER) {
            inn = new float[n];
            for (int i = 0; i < n; i++) inn[i] = 1f - a[i];
            Fx.gaussPlaneF(inn, tmp, w, h, sig);
            chk(job);
        }
        float[] cov = new float[n];
        for (int i = 0; i < n; i++) {
            float c;
            if (mode == OUTER) c = clamp01(ext[i] * gain);                       // debajo del dibujo
            else if (mode == INNER) c = a[i] * clamp01(inn[i] * gain);
            else c = Math.max(clamp01(ext[i] * gain) * (1f - a[i]), a[i] * clamp01(inn[i] * gain));
            cov[i] = c;
        }
        fill(out, cov, p.color, Math.min(1f, inten));
        if (inten > 1f) {
            // mas de 100 %: el brillo se aclara hacia blanco
            float k = inten;
            for (int i = 0; i < n; i++) {
                int c = out[i];
                if (c == 0) continue;
                int r = Fx.clampf(((c >> 16) & 255) * k), g = Fx.clampf(((c >> 8) & 255) * k), b = Fx.clampf((c & 255) * k);
                out[i] = (c & 0xFF000000) | (r << 16) | (g << 8) | b;
            }
        }
        return out;
    }

    // ================================================================== lineas radiales

    /**
     * Lineas de concentracion (manga): cunas finas que apuntan al centro y dejan libre la zona
     * central. v0 cantidad, v1 grosor (px), v2 zona libre %, v3 largo %, v4 variacion, v5 opacidad.
     * Misma semilla = mismas lineas al mover barras.
     */
    static int[] focusLines(int w, int h, int ox, int oy, int fw, int fh, Fx.P p, float s) {
        int[] out = new int[w * h];
        float op = Math.max(0, Math.min(100, p.v[5])) / 100f * ((p.color >>> 24) / 255f);
        int cnt = Math.max(1, Math.min(600, p.v[0]));
        if (op <= 0f || p.v[1] <= 0) return out;
        float cx = p.px * fw, cy = p.py * fh;
        float rOut = 0f;
        float[][] cs = {{0, 0}, {fw, 0}, {0, fh}, {fw, fh}};
        for (float[] c : cs) rOut = Math.max(rOut, (float) Math.hypot(c[0] - cx, c[1] - cy));
        rOut += 2f;
        float diagH = (float) Math.hypot(fw, fh) * 0.5f;
        float free = Math.max(0, Math.min(95, p.v[2])) / 100f * diagH;
        float len = Math.max(5, Math.min(100, p.v[3])) / 100f;
        float var = Math.max(0, Math.min(100, p.v[4])) / 100f;
        float wid = Math.max(0.3f, p.v[1] * s);
        Random rnd = new Random(0x5EEDL * 31 + p.seed * 7919L + 17);
        float[] ang = new float[cnt], hw = new float[cnt], r0 = new float[cnt];
        float rot = rnd.nextFloat() * 6.2831855f;
        for (int i = 0; i < cnt; i++) {
            float jit = (rnd.nextFloat() - 0.5f) * 0.9f * var;
            ang[i] = (float) ((i + 0.5f + jit) / cnt * Math.PI * 2 + rot);
            hw[i] = wid * 0.5f * (1f - 0.65f * var * rnd.nextFloat());
            // inicio de la linea: la zona libre, mas un poco al azar; con "largo" corto, mas afuera
            float extra = var * 0.55f * rnd.nextFloat();
            float startFree = free * (1f + extra);
            float startLen = rOut - (rOut - free) * len * (1f - 0.5f * var * rnd.nextFloat());
            r0[i] = Math.max(startFree, startLen);
        }
        sortBy(ang, hw, r0);
        for (int y = 0; y < h; y++) {
            float py = oy + y + .5f;
            for (int x = 0; x < w; x++) {
                float px = ox + x + .5f;
                float dx = px - cx, dy = py - cy;
                float rho = (float) Math.sqrt(dx * dx + dy * dy);
                if (rho <= free * 0.98f) continue;
                float th = (float) Math.atan2(dy, dx);
                int k = nearestAngle(ang, th);
                float c = 0f;
                for (int d = -3; d <= 3; d++) {
                    int j = ((k + d) % cnt + cnt) % cnt;
                    if (rho <= r0[j]) continue;
                    float da = Math.abs(angDiff(th, ang[j]));
                    if (da > 0.5f) continue;
                    float dist = rho * da;
                    if (dist > hw[j] + 1f) continue;
                    float t = (rho - r0[j]) / Math.max(1f, rOut - r0[j]);
                    float half = hw[j] * Math.min(1f, t);
                    // punta: se cierra suave en el inicio de la linea
                    float cv = clamp01(half - dist + 0.5f) * clamp01((rho - r0[j]) * 0.5f + 0.5f);
                    if (cv > c) c = cv;
                }
                if (c > 0f) out[y * w + x] = pix(p.color, c * op);
            }
        }
        return out;
    }

    // ================================================================== lineas de velocidad

    /**
     * Lineas paralelas en una direccion, finas en las puntas (huso). v0 angulo, v1 cantidad,
     * v2 grosor (px), v3 largo %, v4 variacion, v5 opacidad. Semilla estable.
     */
    static int[] speedLines(int w, int h, int ox, int oy, int fw, int fh, Fx.P p, float s) {
        int[] out = new int[w * h];
        float op = Math.max(0, Math.min(100, p.v[5])) / 100f * ((p.color >>> 24) / 255f);
        int cnt = Math.max(1, Math.min(600, p.v[1]));
        if (op <= 0f || p.v[2] <= 0) return out;
        double phi = Math.toRadians(p.v[0]);
        float ux = (float) Math.cos(phi), uy = (float) Math.sin(phi), nx = -uy, ny = ux;
        float umin = Float.MAX_VALUE, umax = -Float.MAX_VALUE, vmin = Float.MAX_VALUE, vmax = -Float.MAX_VALUE;
        float[][] cs = {{0, 0}, {fw, 0}, {0, fh}, {fw, fh}};
        for (float[] c : cs) {
            float u = c[0] * ux + c[1] * uy, v = c[0] * nx + c[1] * ny;
            umin = Math.min(umin, u); umax = Math.max(umax, u);
            vmin = Math.min(vmin, v); vmax = Math.max(vmax, v);
        }
        float span = umax - umin;
        float len = Math.max(5, Math.min(100, p.v[3])) / 100f;
        float var = Math.max(0, Math.min(100, p.v[4])) / 100f;
        float wid = Math.max(0.3f, p.v[2] * s);
        Random rnd = new Random(0x5BEEDL * 37 + p.seed * 7919L + 3);
        float[] lv = new float[cnt], hw = new float[cnt], u0 = new float[cnt], u1 = new float[cnt];
        for (int i = 0; i < cnt; i++) {
            float jit = (rnd.nextFloat() - 0.5f) * 0.9f * var;
            lv[i] = vmin + (i + 0.5f + jit) / cnt * (vmax - vmin);
            hw[i] = wid * 0.5f * (1f - 0.65f * var * rnd.nextFloat());
            float l = span * len * (1f - 0.55f * var * rnd.nextFloat());
            float c = umin + l * 0.5f + rnd.nextFloat() * Math.max(0f, span - l);
            u0[i] = c - l * 0.5f;
            u1[i] = c + l * 0.5f;
        }
        sortBy(lv, hw, u0, u1);
        for (int y = 0; y < h; y++) {
            float py = oy + y + .5f;
            for (int x = 0; x < w; x++) {
                float px = ox + x + .5f;
                float u = px * ux + py * uy, v = px * nx + py * ny;
                int k = nearest(lv, v);
                float c = 0f;
                for (int d = -3; d <= 3; d++) {
                    int j = k + d;
                    if (j < 0 || j >= cnt || u <= u0[j] || u >= u1[j]) continue;
                    float dv = Math.abs(v - lv[j]);
                    if (dv > hw[j] + 1f) continue;
                    float t = (u - u0[j]) / (u1[j] - u0[j]);
                    float half = hw[j] * (float) Math.sqrt(4f * t * (1f - t));
                    float cv = clamp01(half - dv + 0.5f);
                    if (cv > c) c = cv;
                }
                if (c > 0f) out[y * w + x] = pix(p.color, c * op);
            }
        }
        return out;
    }

    // ================================================================== ayudas

    /**
     * Distancia (al cuadrado) de cada pixel al pixel mas cercano del conjunto: inside==target.
     * Exacta (dos pasadas). Fuera de la franja/imagen no hay nada.
     */
    static float[] edt(boolean[] inside, int w, int h, boolean target) {
        int n = w * h;
        float[] g = new float[n];
        for (int i = 0; i < n; i++) g[i] = inside[i] == target ? 0f : INF;
        int m = Math.max(w, h);
        float[] f = new float[m], d = new float[m], z = new float[m + 1];
        int[] v = new int[m];
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) f[y] = g[y * w + x];
            edt1(f, h, d, v, z);
            for (int y = 0; y < h; y++) g[y * w + x] = d[y];
        }
        for (int y = 0; y < h; y++) {
            System.arraycopy(g, y * w, f, 0, w);
            edt1(f, w, d, v, z);
            System.arraycopy(d, 0, g, y * w, w);
        }
        return g;
    }

    /** Una fila: distancia minima a (q-p)^2 + f[p] (Felzenszwalb). Los infinitos no son sitios. */
    private static void edt1(float[] f, int n, float[] d, int[] v, float[] z) {
        int k = -1;
        for (int q = 0; q < n; q++) {
            if (f[q] >= INF) continue;
            if (k < 0) {
                k = 0;
                v[0] = q;
                z[0] = -INF;
                z[1] = INF;
                continue;
            }
            float sq = f[q] + (float) q * q;
            float s;
            while (true) {
                int p = v[k];
                s = (sq - (f[p] + (float) p * p)) / (2f * (q - p));
                if (s <= z[k] && k > 0) k--;
                else break;
            }
            k++;
            v[k] = q;
            z[k] = s;
            z[k + 1] = INF;
        }
        if (k < 0) {
            for (int q = 0; q < n; q++) d[q] = INF;
            return;
        }
        int j = 0;
        for (int q = 0; q < n; q++) {
            while (z[j + 1] < q) j++;
            int p = v[j];
            d[q] = (q - p) * (float) (q - p) + f[p];
        }
    }

    static float[] alphaPlane(int[] in) {
        float[] a = new float[in.length];
        for (int i = 0; i < in.length; i++) a[i] = (in[i] >>> 24) / 255f;
        return a;
    }

    private static void fill(int[] out, float[] cov, int color, float op) {
        for (int i = 0; i < out.length; i++) {
            float c = cov[i] * op;
            if (c > 0.002f) out[i] = pix(color, c);
        }
    }

    private static int pix(int color, float a) {
        int al = a >= 1f ? 255 : (int) (a * 255f + .5f);
        return al <= 0 ? 0 : (al << 24) | (color & 0xFFFFFF);
    }

    private static float clamp01(float v) { return v <= 0f ? 0f : v >= 1f ? 1f : v; }

    private static float angDiff(float a, float b) {
        float d = a - b;
        while (d > Math.PI) d -= (float) (Math.PI * 2);
        while (d < -Math.PI) d += (float) (Math.PI * 2);
        return d;
    }

    /** Indice del angulo mas cercano (lista ordenada, circular). */
    private static int nearestAngle(float[] a, float th) {
        int n = a.length;
        int lo = 0, hi = n - 1;
        // llevar th al rango de la lista
        float base = a[0];
        while (th < base) th += (float) (Math.PI * 2);
        while (th >= base + Math.PI * 2) th -= (float) (Math.PI * 2);
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (a[mid] < th) lo = mid + 1; else hi = mid;
        }
        return lo;
    }

    private static int nearest(float[] a, float v) {
        int lo = 0, hi = a.length - 1;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (a[mid] < v) lo = mid + 1; else hi = mid;
        }
        return lo;
    }

    /** Ordena por el primer arreglo y mueve los otros igual. */
    private static void sortBy(float[] key, float[]... others) {
        int n = key.length;
        Integer[] idx = new Integer[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        final float[] k = key;
        java.util.Arrays.sort(idx, (x, y) -> Float.compare(k[x], k[y]));
        float[] kk = new float[n];
        for (int i = 0; i < n; i++) kk[i] = key[idx[i]];
        System.arraycopy(kk, 0, key, 0, n);
        for (float[] o : others) {
            float[] t = new float[n];
            for (int i = 0; i < n; i++) t[i] = o[idx[i]];
            System.arraycopy(t, 0, o, 0, n);
        }
    }

    private static void chk(Fx.Job j) {
        if (j != null && j.cancelled()) throw new Fx.Cancelled();
    }
}
