package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.ProjectStore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Galeria de obras: la pantalla con la que arranca la app.
 * Muestra todo lo que has editado con su miniatura, como la galeria de Ibis.
 */
public class GalleryActivity extends AppCompatActivity {

    private GridView grid;
    private TextView empty;
    private List<ProjectStore.Entry> items;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        PzSystem.init(this);   // v8.62: nivel del celular y registro de errores
        super.onCreate(b);
        setContentView(R.layout.activity_gallery);
        PzSystem.edgeToEdge(this);
        PzSystem.showLastCrash(this);   // si la ultima vez se cerro por un error, se puede copiar
        grid = findViewById(R.id.grid);
        empty = findViewById(R.id.empty);

        findViewById(R.id.btnNew).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(null);
            }
        });

        // v8.73: Acerca de, privacidad y licencias de codigo abierto
        findViewById(R.id.btnAbout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GalleryActivity.this, AboutActivity.class));
            }
        });

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                if (selecting) toggle(items.get(pos).id);
                else open(items.get(pos).id);
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                // v8.45: como la galeria del telefono: mantener pulsado ya selecciona
                if (selecting) toggle(items.get(pos).id);
                else startSelecting(items.get(pos).id);
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    /** Miniaturas en memoria: al volver a la galeria no se recargan ni parpadean. */
    private final android.util.LruCache<String, Bitmap> thumbs =
            new android.util.LruCache<String, Bitmap>(24 * 1024 * 1024) {
                @Override
                protected int sizeOf(String k, Bitmap b) {
                    return b.getByteCount();
                }
            };
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();
    private Adapter adapter;

    private void refresh() {
        items = ProjectStore.list(this);
        if (adapter == null) {
            adapter = new Adapter();
            grid.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void open(String id) {
        Intent i = new Intent(this, MainActivity.class);
        if (id != null) i.putExtra(MainActivity.EXTRA_PROJECT, id);
        startActivity(i);
        overridePendingTransition(R.anim.pz_fade_in, R.anim.pz_stay);
    }

    private void options(final ProjectStore.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Obra")
                .setItems(new String[]{"Abrir", "Renombrar", "Eliminar", "Seleccionar varias (para borrar)"},
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (which == 0) open(e.id);
                                else if (which == 1) rename(e);
                                else if (which == 2) confirmDelete(e);
                                else startSelecting(e.id);
                            }
                        })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void rename(final ProjectStore.Entry e) {
        final android.widget.EditText in = new android.widget.EditText(this);
        String cur = ProjectStore.name(this, e.id);
        in.setText(cur == null ? "" : cur);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la obra")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        ProjectStore.setName(GalleryActivity.this, e.id, s);
                        refresh();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void confirmDelete(final ProjectStore.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar")
                .setMessage("Se borra esta obra con todas sus capas. No se puede recuperar.")
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        ProjectStore.delete(GalleryActivity.this, e.id);
                        Toast.makeText(GalleryActivity.this, "Obra eliminada", Toast.LENGTH_SHORT).show();
                        refresh();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ---------------- v8.43: seleccionar varias obras y borrarlas juntas ----------------
    private boolean selecting;
    private final java.util.Set<String> picked = new java.util.HashSet<String>();
    private LinearLayout selBar;
    private TextView selCount, renameBtn;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void startSelecting(String first) {
        selecting = true;
        picked.clear();
        if (first != null) picked.add(first);
        if (selBar == null) {
            selBar = new LinearLayout(this);
            selBar.setOrientation(LinearLayout.HORIZONTAL);
            selBar.setGravity(android.view.Gravity.CENTER_VERTICAL);
            selBar.setBackgroundColor(0xFF24242A);
            selBar.setPadding(dp(14), dp(8), dp(8), dp(8));
            selBar.setClickable(true);
            selCount = new TextView(this);
            selCount.setTextColor(0xFFFFFFFF);
            selCount.setTextSize(15f);
            selBar.addView(selCount, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            selBar.addView(barButton("Todas", new Runnable() { public void run() {
                if (picked.size() == items.size()) picked.clear();
                else for (ProjectStore.Entry e : items) picked.add(e.id);
                updateSel();
            }}));
            renameBtn = barButton("Nombre", new Runnable() { public void run() {
                if (picked.size() != 1) return;
                String id = picked.iterator().next();
                for (ProjectStore.Entry e : items) if (e.id.equals(id)) { stopSelecting(); rename(e); return; }
            }});
            selBar.addView(renameBtn);
            selBar.addView(barButton("Eliminar", new Runnable() { public void run() { confirmDeleteMany(); } }));
            selBar.addView(barButton("Cancelar", new Runnable() { public void run() { stopSelecting(); } }));
            android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.BOTTOM);
            ((ViewGroup) findViewById(android.R.id.content)).addView(selBar, lp);
        }
        selBar.setVisibility(View.VISIBLE);
        grid.setPadding(grid.getPaddingLeft(), grid.getPaddingTop(), grid.getPaddingRight(), dp(64));
        grid.setClipToPadding(false);
        updateSel();
    }

    private TextView barButton(String t, final Runnable r) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextColor(t.equals("Eliminar") ? 0xFFFF8A80 : 0xFF80CBC4);
        b.setTextSize(14f);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        return b;
    }

    private void toggle(String id) {
        if (!picked.remove(id)) picked.add(id);
        updateSel();
    }

    private void updateSel() {
        if (selCount != null) selCount.setText(picked.size() == 1 ? "1 seleccionada" : picked.size() + " seleccionadas");
        if (renameBtn != null) renameBtn.setVisibility(picked.size() == 1 ? View.VISIBLE : View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void stopSelecting() {
        selecting = false;
        picked.clear();
        if (selBar != null) selBar.setVisibility(View.GONE);
        grid.setPadding(grid.getPaddingLeft(), grid.getPaddingTop(), grid.getPaddingRight(), 0);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void confirmDeleteMany() {
        final java.util.List<String> ids = new java.util.ArrayList<String>(picked);
        if (ids.isEmpty()) {
            Toast.makeText(this, "Toca las obras que quieres borrar", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Eliminar " + ids.size() + (ids.size() == 1 ? " obra" : " obras"))
                .setMessage("Se borran con todas sus capas. No se puede recuperar.")
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        for (String id : ids) ProjectStore.delete(GalleryActivity.this, id);
                        Toast.makeText(GalleryActivity.this, ids.size() + (ids.size() == 1 ? " obra eliminada" : " obras eliminadas"),
                                Toast.LENGTH_SHORT).show();
                        stopSelecting();
                        refresh();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        if (selecting) { stopSelecting(); return; }
        super.onBackPressed();
    }

    private class Adapter extends BaseAdapter {

        private final SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm", Locale.US);

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int i) {
            return items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View reuse, ViewGroup parent) {
            Context c = GalleryActivity.this;
            LinearLayout root;
            if (reuse instanceof LinearLayout) {
                root = (LinearLayout) reuse;
            } else {
                root = (LinearLayout) getLayoutInflater().inflate(R.layout.item_gallery, parent, false);
            }
            ProjectStore.Entry e = items.get(pos);
            ImageView img = root.findViewById(R.id.thumb);
            TextView label = root.findViewById(R.id.label);

            final String key = e.thumb.getAbsolutePath() + ":" + e.thumb.lastModified();
            img.setTag(key);
            Bitmap bmp = thumbs.get(key);
            if (bmp != null) {
                img.setImageBitmap(bmp);
            } else if (!e.thumb.exists()) {
                img.setImageResource(R.drawable.ic_open);
            } else {
                img.setImageDrawable(null);
                final ImageView target = img;
                final String path = e.thumb.getAbsolutePath();
                io.execute(new Runnable() {
                    @Override
                    public void run() {
                        final Bitmap b = BitmapFactory.decodeFile(path);
                        if (b != null) thumbs.put(key, b);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (!key.equals(target.getTag())) return;
                                if (b != null) target.setImageBitmap(b);
                                else target.setImageResource(R.drawable.ic_open);
                            }
                        });
                    }
                });
            }

            String name = ProjectStore.name(GalleryActivity.this, e.id);
            String when = fmt.format(new Date(e.modified));
            label.setText(name == null || name.isEmpty() ? when : name + "\n" + when);
            // v8.43: marcadas en azul al seleccionar varias
            boolean on = selecting && picked.contains(e.id);
            root.setForeground(on ? new android.graphics.drawable.ColorDrawable(0x553D7BFF) : null);
            img.setAlpha(selecting && !on ? 0.55f : 1f);
            if (on) label.setText("✓ " + label.getText());
            return root;
        }
    }
}
