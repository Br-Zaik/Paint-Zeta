# Paint Zeta v8.70

## No se instalaba el APK
- **Causa**: el APK salio como "app-release-unsigned" (SIN firma). Android nunca instala un APK
  sin firma. Ademas, la firma de prueba cambiaba en cada compilacion.
- **Ahora**: el proyecto trae su propia llave de firma (app/paintzeta.keystore). Salga como
  "debug" o como "release", el APK queda firmado, y las proximas versiones se instalan encima
  de la anterior sin desinstalar.
- La primera vez con esta llave hay que desinstalar la version vieja una sola vez.

Codigo de la app igual que 8.69 (todos sus arreglos incluidos). La IA no se toco.
