# Paint Zeta v8.29 — Borrar fondo simple y sin sobras

Versión 8.29 (versionCode 67). Base: v8.28. No se quitó ninguna función: lo que estaba en la barra de Borrar fondo pasó a Ajustes. No se tocó GitHub ni el flujo de GitHub Actions.

Pruebas en un servidor con Android simulado y la imagen del duende (6) y del manga (7). **No es un teléfono.**

## 1. Qué cambia para ti

- **Barra de Borrar fondo con 7 iconos y sin textos.** Mantener pulsado un icono dice su nombre.
  - **Balde (Toque):** un toque borra el fondo pegado.
  - **Pincel:** borra el fondo por donde pasas, sin cruzar la línea negra.
  - **Goma:** borra todo lo que tocas. Sirve para lo que el pincel no debe adivinar.
  - **Restaurar:** devuelve lo que borraste por error, exacto como estaba.
  - **Escoba (Limpiar restos):** quita de un toque los pedazos sueltos de fondo, los bordes blanquecinos a medio borrar y el polvo casi invisible. Rellena los agujeritos dentro del personaje. Se deshace con un toque.
  - **Ojo:** ver el recorte sobre cuadros, blanco, negro, gris o verde. No cambia el PNG.
  - **Ajustes:** parecido del color, borde suave, tomar el color solo al empezar, pincel entre mechones, proteger un color, refinar borde y dilatación.
- **Ajustes de Borrar fondo vuelven a los de fábrica una vez**, al instalar esta versión. Una dilatación o una tolerancia cambiadas sin querer dejaban sobras.
- **Menú «Más» de Capas con iconos:** separar líneas, limpiar la capa (escoba), opciones de la capa y capa con lo seleccionado. Ya no hay lista de textos.

## 2. Qué estaba mal (capturas 2 a 5 de v8.28) y qué se hizo

**CONFIRMADO: bordes blanquecinos a medio borrar (capturas 2 y 4).**

- Causa:
  - El pincel aclaraba a medias el fondo de otro tono que seguía (la cueva), por la suavidad del pincel y por el «refinado del filo».
  - Esos píxeles quedaban semitransparentes y blanquecinos, y después ni el toque ni el pincel los reconocían como fondo.
- Ahora:
  - El fondo que el pincel alcanza se borra **entero**.
  - El refinado solo trabaja en el filo de verdad, no en una zona pareja de fondo ni pegado a la línea.
  - Lo semitransparente de color parecido al fondo se borra con otro toque.

**CONFIRMADO: sobras pegadas a la línea que no se podían quitar (capturas 3 y 5).**

- Causa:
  - Junto a la línea el borrado no avanzaba, para no colarse por los cortes.
  - Los píxeles claros de brillo del JPEG quedaban como puntitos.
  - En el toque, el refinado les ponía el color de la piel del otro lado de la línea.
- Ahora:
  - Junto a la línea, lo claro se borra (hasta 2 píxeles a lo largo de la línea, sin cruzarla).
  - Lo oscuro conserva su parte de tinta.
  - Al terminar el toque se quita el filo claro a medio borrar.

**CONFIRMADO: el pincel no seguía los cambios del fondo.** Con «todo el rato» solo aceptaba colores parecidos al del comienzo. En la luz celeste junto al hombro casi no borraba. Ahora toma el color bajo el dedo cuando la zona es pareja (no línea, no borde, no trama).

**CONFIRMADO: repasar lo ya borrado no alcanzaba las sobras.** Lo transparente de antes no contaba como camino. Ahora lo ya borrado sirve de puente, y lo que no cruzó una línea se alcanza.

**El personaje sigue protegido.** Si el dedo entra al personaje cruzando su línea, no se borra nada adentro.

## 3. Resultados (servidor, no teléfono)

Pincel, 3 pasadas junto a la línea del duende (como en las capturas):

- **Hombro:**
  - Fondo que queda: 4 de 2520 píxeles (v8.28: 580).
  - A medio borrar: 4 (v8.28: 147).
  - Sobras claras pegadas a la línea: 9 de 360 (v8.28: 71).
  - Tinta perdida: 0.
- **Panza:**
  - Fondo que queda: 97 de 3360 (v8.28: 130).
  - A medio borrar: 28 (v8.28: 127).
  - Sobras claras pegadas: 4 de 480 (v8.28: 21).
  - Tinta perdida: 0.

Otros resultados:

- **Toques junto a la panza (captura 5):** puntitos claros pegados a la línea 0 de 445 (v8.28: 28).
- **Sobras a medio borrar (8000 píxeles):** con un toque quedan 259 (v8.28: 5752); con el pincel quedan 37 (v8.28: 144).
- **Limpiar restos:**
  - Pedazos sueltos: de 1296 píxeles queda 0.
  - Borde blanquecino: de 380 píxeles quedan 8.
  - El duende no pierde nada.
  - En el manga, la tinta perdida es 0 de 264 184: las puntas de mechones sueltas se conservan.
  - Deshacer es exacto.
- **Goma y Restaurar:** la goma deja transparente todo lo que toca. Restaurar devuelve el original exacto (0 diferencias) y no toca lo que no repasó. Deshacer es exacto.
- **Personaje protegido:** con el dedo que cruza la línea y recorre el duende, el duende pierde 0 de 41 800 píxeles.
- **Toda la batería anterior pasa:** v8.22 a v8.28, incluidas las pruebas A-R de v8.28.
- **Compilación sin SDK:** sin errores.

Imágenes ANTES/AHORA en `docs/qa829/`. Salida completa en `docs/RESULTADOS_PRUEBAS_8_29.txt`.

## 4. Límites (dicho claro)

- **Fondo muy parecido a la línea:** si el fondo es casi negro como la línea, el color no alcanza. Usa la Goma en esa parte, o Restaurar si se borró algo.
- **Toque y variedad de tonos:** un toque borra los tonos parecidos al que tocaste. Las manchas de otro color del fondo se borran tocándolas, con el pincel o con la Escoba si quedaron sueltas.
- **Restaurar** recuerda la capa tal como estaba al empezar a borrar el fondo. Si cambias de capa, recuerda la nueva.
- **No probado en un teléfono real.** En la app, Menú > «Medir rendimiento» da los tiempos de tu teléfono.

## 5. Para probar en el teléfono

1. Sube **Paint-Zeta-v8.29-LITE.zip** a GitHub y descarga el APK.
2. Abre el duende y elige Borrar fondo. Prueba el Balde (toque) en la cueva y luego el Pincel junto a la panza y el hombro.
3. Toca la Escoba: los pedazos sueltos y los bordes blanquecinos deben desaparecer.
4. Pasa la Goma por un pedazo y luego Restaurar por el mismo lugar: debe volver igual.
5. Toca el Ojo hasta «Negro» y «Blanco» para revisar.
6. En Capas, toca «Más»: deben verse solo iconos.
