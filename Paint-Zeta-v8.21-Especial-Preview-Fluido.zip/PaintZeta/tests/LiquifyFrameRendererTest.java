import java.util.Random;
import com.pacco.animecut.core.InverseLiquifyEngine;
import com.pacco.animecut.core.LiquifyFrameRenderer;
import com.pacco.animecut.core.AlphaColors;

/** Comprueba calidad, estampa -> render y snapshots estables en manga con alfa. */
public class LiquifyFrameRendererTest {
    private static void yes(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static final int W=180,H=152,STEP=8;
    private static final int COLS=(W-1+STEP-1)/STEP+1, ROWS=(H-1+STEP-1)/STEP+1;
    private final float[] dx=new float[COLS*ROWS], dy=new float[dx.length];
    private final float[] oldX=new float[dx.length],oldY=new float[dx.length];
    private final int[] source = new int[W*H];
    private LiquifyFrameRendererTest() {
        Random rnd = new Random(15);
        for (int y=0;y<H;y++)for(int x=0;x<W;x++) {
            // Lineas finas, distintos grises, cabello, fondo transparente.
            int alpha = x<10 || y<10 ? 0 : (x%17==0 ? 125 : 255);
            int shade = (x*11 + y*7)%52<4 ? 12 : (rnd.nextInt(4)==0 ? 155 : 251);
            source[y*W+x] = (alpha<<24)|(shade<<16)|(shade<<8)|shade;
        }
    }
    private void stamp() {
        for (int i=0; i<50; i++) {
            float x=70+i*.48f, y=80+(float)Math.sin(i*.14)*8;
            int x0=Math.max(0,(int)Math.floor((x-42)/STEP));
            int y0=Math.max(0,(int)Math.floor((y-42)/STEP));
            int x1=Math.min(COLS-1,(int)Math.ceil((x+42)/STEP));
            int y1=Math.min(ROWS-1,(int)Math.ceil((y+42)/STEP));
            InverseLiquifyEngine.stamp(dx,dy,oldX,oldY,COLS,ROWS,STEP,W,H,
                x,y,.48f,(float)Math.cos(i*.14)*1.1f,42f,.32f,.72f,0,null,x0,y0,x1,y1);
        }
    }
    private int[] render(int sx,int sy,int sw,int sh,int x,int y,int dw,int dh,byte[] sel) {
        int[] chunk=new int[sw*sh];
        for(int yy=0;yy<sh;yy++)System.arraycopy(source,(sy+yy)*W+sx,chunk,yy*sw,sw);
        return LiquifyFrameRenderer.render(chunk,sw,sh,sx,sy,W,H,x,y,dw,dh,dx.clone(),dy.clone(),COLS,ROWS,STEP,sel);
    }
    private void noStaleNorAccumulation() {
        int[] a=render(0,0,W,H,0,0,W,H,null);
        int[] b=render(0,0,W,H,0,0,W,H,null);
        yes(java.util.Arrays.equals(a,b),"El preview repetido debe ser determinista y sin acumulacion");
        int[] sub=render(25,30,110,110,40,40,55,55,null);
        for(int yy=0;yy<55;yy++)for(int xx=0;xx<55;xx++) {
            int expect=a[(40+yy)*W+(40+xx)];
            yes(expect==sub[yy*55+xx],"ROI del preview no coincide con la imagen completa");
        }
        yes(a[0]==source[0],"El borde transparente original cambio");
    }
    private void opaqueAndTransparent() {
        int[] pixels = {0,0xffffffff,0xff000000,0x8000ff00};
        int mixed=LiquifyFrameRenderer.blend(pixels[0],pixels[1],pixels[0],pixels[1],.5f,0f);
        yes((mixed>>>24)==128, "Alfa del borde incorrecto");
        yes(((mixed>>>16)&255)>=254, "Halo negro al interpolar transparente y blanco");
        yes(LiquifyFrameRenderer.blend(0xff000000,0xffffffff,0xff000000,0xffffffff,.5f,0f)==0xff808080,
                "Interpolacion negro/blanco incorrecta");
        // La mascara completa debe coincidir con remapeo normal; en cero no toca nada.
        byte[] none=new byte[W*H];
        int[] z=render(0,0,W,H,0,0,W,H,none);
        yes(java.util.Arrays.equals(source,z),"El preview debe respetar seleccion vacia");
        java.util.Arrays.fill(none,(byte)255);
        yes(java.util.Arrays.equals(render(0,0,W,H,0,0,W,H,null),render(0,0,W,H,0,0,W,H,none)),
                "Mascara completa diferente al render original");
    }
    public static void main(String[] args) {
        LiquifyFrameRendererTest t=new LiquifyFrameRendererTest();
        t.stamp();
        t.noStaleNorAccumulation();
        t.opaqueAndTransparent();
        System.out.println("OK LiquifyFrameRenderer: preview/ROI, 50 stamps, alfa, mascara y estabilidad");
    }
}
