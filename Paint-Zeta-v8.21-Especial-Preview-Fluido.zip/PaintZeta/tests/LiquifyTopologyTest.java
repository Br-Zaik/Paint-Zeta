import com.pacco.animecut.core.LiquifyTopologyGuard;

/** Test independiente de Android: garantiza que el guard rechaza celdas invertidas. */
public final class LiquifyTopologyTest {
    private static void require(boolean b, String msg) {
        if (!b) throw new AssertionError(msg);
    }
    private static float min(float[] dx,float[] dy,int cols,int rows,float step,int w,int h) {
        return LiquifyTopologyGuard.minTriangleRatio(dx,dy,cols,rows,step,w,h,0,0,cols-2,rows-2);
    }
    private static void basic() {
        int w=225, h=225, cols=16, rows=16; float step=15f;
        float[] dx=new float[cols*rows], dy=new float[cols*rows];
        require(Math.abs(min(dx,dy,cols,rows,step,w,h)-1f)<1e-5,"identity");
        // Voltear la celda superior izquierda cruzando 30 px un vertice.
        dx[1]=-30f;
        require(min(dx,dy,cols,rows,step,w,h)<0f, "foldover not detected");
        dx[1]=0;
        // Test de esquina no multiplo del paso. El jacobiano se normaliza por area real.
        require(Math.abs(min(dx,dy,cols,rows,step,224,224)-1f)<1e-5,"truncated edge");
    }
    private static void stress(String name, int type) {
        final int w=481,h=481,cols=41,rows=41; final float step=12f;
        float[] dx=new float[cols*rows],dy=new float[cols*rows];
        float[] oldX=new float[dx.length],oldY=new float[dy.length];
        float lastX=210,lastY=230;
        int rejected=0,accepted=0;
        for (int n=0;n<220;n++) {
            float a=n*.19f;
            float cx,cy;
            if(type==0){cx=210+(float)Math.sin(a)*68;cy=230+(float)Math.cos(2*a)*36;}
            else {cx=220+(float)Math.cos(a)*65;cy=215+(float)Math.sin(a)*65;}
            float dragX=cx-lastX,dragY=cy-lastY;
            lastX=cx;lastY=cy;
            System.arraycopy(dx,0,oldX,0,dx.length);System.arraycopy(dy,0,oldY,0,dy.length);
            float r=57.5f,r2=r*r,str=.32f;
            for(int gy=0;gy<rows;gy++) for(int gx=0;gx<cols;gx++){
                int i=gy*cols+gx;
                float px=gx*step+dx[i],py=gy*step+dy[i];
                float ddx=px-cx,ddy=py-cy,d2=ddx*ddx+ddy*ddy;
                if(d2>=r2)continue;
                float q=1-d2/r2;q=q*q*(3-2*q);
                float fall=(float)Math.pow(q,1.65-.72*.85);
                if(type==0){dx[i]+=dragX*(.12f+.88f*str)*fall;dy[i]+=dragY*(.12f+.88f*str)*fall;}
                else {float amt=(.018f+.075f*str)*fall;
                    dx[i]+=(cx-px)*amt;dy[i]+=(cy-py)*amt;}
            }
            float min=min(dx,dy,cols,rows,step,w,h);
            int halves=0;
            while(min<.12f&&halves++<12){
                for(int i=0;i<dx.length;i++){dx[i]=(dx[i]+oldX[i])*.5f;dy[i]=(dy[i]+oldY[i])*.5f;}
                min=min(dx,dy,cols,rows,step,w,h);
            }
            if(min<.12f){System.arraycopy(oldX,0,dx,0,dx.length);System.arraycopy(oldY,0,dy,0,dy.length);rejected++;}
            else accepted++;
            require(min(dx,dy,cols,rows,step,w,h)>=.119f, name+" fold at step "+n);
        }
        require(accepted>=200,name+" rejected too many gestures: "+rejected);
        System.out.println(name+": 220 stamps, accepted="+accepted+", rejected="+rejected+", min area="+min(dx,dy,cols,rows,step,w,h));
    }
    public static void main(String[] args) {
        basic();
        stress("zigzag drag 115px 32%",0);
        stress("circular shrink 115px 32%",1);
        System.out.println("LiquifyTopologyGuard TESTS OK");
    }
}
