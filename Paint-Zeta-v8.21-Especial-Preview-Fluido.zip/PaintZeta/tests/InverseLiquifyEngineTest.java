import com.pacco.animecut.core.InverseLiquifyEngine;
import com.pacco.animecut.core.LiquifyTopologyGuard;
import java.util.Random;

/** Pruebas reproducibles del motor de Especial v8.20, sin depender de Android. */
public final class InverseLiquifyEngineTest {
    private static final int W = 360, H = 240, STEP = 8;
    private static final int COLS = (W - 1 + STEP - 1) / STEP + 1;
    private static final int ROWS = (H - 1 + STEP - 1) / STEP + 1;
    private final float[] x = new float[COLS * ROWS], y = new float[COLS * ROWS];
    private final float[] px = new float[x.length], py = new float[y.length];
    private final float[] sample = new float[2];
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    private boolean stamp(int mode,float cx,float cy,float dx,float dy,float r,float str,byte[] sel) {
        int gx0 = Math.max(0,(int)Math.floor((cx-r)/STEP));
        int gy0 = Math.max(0,(int)Math.floor((cy-r)/STEP));
        int gx1 = Math.min(COLS-1,(int)Math.ceil((cx+r)/STEP));
        int gy1 = Math.min(ROWS-1,(int)Math.ceil((cy+r)/STEP));
        return InverseLiquifyEngine.stamp(x,y,px,py,COLS,ROWS,STEP,W,H,
            cx,cy,dx,dy,r,str,.72f,mode,sel,gx0,gy0,gx1,gy1);
    }
    private void get(float atX,float atY) {
        InverseLiquifyEngine.sample(x,y,COLS,ROWS,STEP,W,H,atX,atY,sample);
        check(Float.isFinite(sample[0])&&Float.isFinite(sample[1]),"campo no finito");
    }
    private void topo() {
        float min = LiquifyTopologyGuard.minTriangleRatio(x,y,COLS,ROWS,STEP,W,H,
                0,0,COLS-2,ROWS-2);
        check(min >= .2499f, "celda invertida/colapsada: "+min);
    }
    private void testDragAndBoundaries() {
        check(stamp(0,150,100,6,0,62,.32f,null), "Arrastrar no modifica");
        get(150,100);
        check(sample[0]< -1.5f && sample[0]>-4.0f,"Arrastrar hacia derecha debe leer fuente a izquierda: "+sample[0]);
        get(20,20); check(Math.abs(sample[0])+Math.abs(sample[1])<.00001f,"zona exterior cambio");
        topo();
    }
    private void testPinchExpandSmoothRestore() {
        check(stamp(1,150,100,0,0,65,.8f,null),"contraer sin efecto");
        get(174,100); float contracted=sample[0];
        check(contracted> -2.0f, "Contraer no debe mover en sentido incorrecto");
        topo();
        check(stamp(2,150,100,0,0,65,.8f,null),"expandir sin efecto");
        topo();
        stamp(3,150,100,0,0,65,.8f,null); topo();
        for(int k=0;k<12;k++) stamp(4,150,100,0,0,65,1f,null);
        topo();
        get(150,100); check(Math.abs(sample[0]) < 3f,"restaurar no disminuye la distorsion");
    }
    private void testSelectionAndZoomPrecision() {
        byte[] sel=new byte[W*H];
        for(int yy=0;yy<H;yy++)for(int xx=0;xx<W/2;xx++)sel[yy*W+xx]=(byte)255;
        check(stamp(0,170,110,4,-2,55,.6f,sel),"seleccion no pinta");
        get(192,110);check(Math.abs(sample[0])+Math.abs(sample[1])<.00001f,"fuera de seleccion cambio");
        get(145.25f,101.75f);topo();
    }
    private void testFastZigzagAndCircle() {
        Random rnd=new Random(12345);
        for(int n=0;n<800;n++) {
            float t=n*.105f;
            float xx=180f+(float)Math.cos(t)*48f;
            float yy=120f+(float)Math.sin(t)*36f;
            float dx=(float)(Math.sin(t*1.7)*4.0);
            float dy=(float)(Math.cos(t*2.3)*3.5);
            int type=(n%61==0) ? 3 : 0;
            stamp(type,xx,yy,dx,dy,36f,.32f,null);
            if(n%15==0) topo();
        }
        topo();
        for(int n=0;n<500;n++) {
            float xx=100f+rnd.nextInt(160), yy=60f+rnd.nextInt(110);
            stamp(n%4==0?2:0,xx,yy,(rnd.nextFloat()-.5f)*9,(rnd.nextFloat()-.5f)*9,48f,.38f,null);
            if(n%20==0) topo();
        }
        topo();
        get(175.25f,110.75f);
    }
    public static void main(String[] args) {
        InverseLiquifyEngineTest a=new InverseLiquifyEngineTest();
        a.testDragAndBoundaries();
        new InverseLiquifyEngineTest().testPinchExpandSmoothRestore();
        new InverseLiquifyEngineTest().testSelectionAndZoomPrecision();
        new InverseLiquifyEngineTest().testFastZigzagAndCircle();
        System.out.println("OK InverseLiquifyEngine: signo Arrastrar, cinco modos, seleccion, muestreo subpixel, topologia y 1300 gestos");
    }
}
