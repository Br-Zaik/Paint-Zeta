package com.pacco.animecut.core;

/**
 * Restriccion geometrica para Especial/Licuar. No depende de Android y por ello
 * puede probarse con un JDK normal. Evalua las cuatro esquinas del jacobiano
 * de cada quad bilineal (ambas diagonales): evita elementos volteados.
 */
public final class LiquifyTopologyGuard {
    private LiquifyTopologyGuard() { }

    public static float minTriangleRatio(float[] dx, float[] dy,
            int cols, int rows, float step, int width, int height,
            int x0, int y0, int x1, int y1) {
        if (cols < 2 || rows < 2 || width < 2 || height < 2) return 1f;
        x0 = Math.max(0, x0); y0 = Math.max(0, y0);
        x1 = Math.min(cols - 2, x1); y1 = Math.min(rows - 2, y1);
        float minimum = Float.POSITIVE_INFINITY;
        for (int y = y0; y <= y1; ++y) {
            float top = Math.min(height - 1f, y * step);
            float bottom = Math.min(height - 1f, (y + 1) * step);
            for (int x = x0; x <= x1; ++x) {
                float left = Math.min(width - 1f, x * step);
                float right = Math.min(width - 1f, (x + 1) * step);
                float area0 = (right - left) * (bottom - top);
                if (area0 <= 0f) continue;
                int i = y * cols + x;
                int a = i, b = i + 1, c = i + cols + 1, d = i + cols;
                float ax = left + dx[a], ay = top + dy[a];
                float bx = right + dx[b], by = top + dy[b];
                float cx = right + dx[c], cy = bottom + dy[c];
                float ddx = left + dx[d], ddy = bottom + dy[d];
                // Las cuatro combinaciones son det(J) en las esquinas del quad.
                float t1 = cross(bx - ax, by - ay, cx - ax, cy - ay) / area0;
                float t2 = cross(cx - ax, cy - ay, ddx - ax, ddy - ay) / area0;
                float t3 = cross(bx - ax, by - ay, ddx - ax, ddy - ay) / area0;
                float t4 = cross(cx - bx, cy - by, ddx - bx, ddy - by) / area0;
                minimum = Math.min(minimum, Math.min(Math.min(t1, t2), Math.min(t3, t4)));
                if (!Float.isFinite(minimum)) return Float.NEGATIVE_INFINITY;
            }
        }
        return minimum == Float.POSITIVE_INFINITY ? 1f : minimum;
    }

    private static float cross(float x0, float y0, float x1, float y1) {
        return x0 * y1 - y0 * x1;
    }
}
