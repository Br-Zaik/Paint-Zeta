package com.pacco.animecut.core;

/**
 * Rasterizador de Especial sin dependencias Android. Trabaja SOLO con snapshots:
 * el hilo que dibuja la interfaz nunca escribe pixels ni matrices desde aqui.
 * La vista previa y el render final comparten remapeo inverso y muestras ARGB
 * con alfa premultiplicado (no produce halo negro en capas transparentes).
 */
public final class LiquifyFrameRenderer {
    private LiquifyFrameRenderer() { }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    /** Interpolacion de la posicion de origen a partir del campo inverso. */
    private static void displacement(float[] dx, float[] dy, int cols, int rows,
            float step, int canvasW, int canvasH, float x, float y, float[] out) {
        InverseLiquifyEngine.sample(dx, dy, cols, rows, step, canvasW, canvasH, x, y, out);
    }

    /** Retorna ARGB no premultiplicado; la interpolacion interna SI es premultiplicada. */
    public static int sampleArgb(int[] source, int sw, int sh, int originX, int originY,
            int canvasW, int canvasH, float x, float y) {
        // Replicar el borde del lienzo, NO mezclar con pixels transparentes externos.
        x = clamp(x, 0f, canvasW - 1f) - originX;
        y = clamp(y, 0f, canvasH - 1f) - originY;
        x = clamp(x, 0f, sw - 1f);
        y = clamp(y, 0f, sh - 1f);
        int x0 = (int)x, y0 = (int)y;
        int x1 = Math.min(sw - 1, x0 + 1), y1 = Math.min(sh - 1, y0 + 1);
        float fx = x - x0, fy = y - y0;
        int a = source[y0 * sw + x0];
        if (fx == 0f && fy == 0f) return a;
        int b = source[y0 * sw + x1], c = source[y1 * sw + x0], d = source[y1 * sw + x1];
        return blend(a, b, c, d, fx, fy);
    }

    public static int blend(int a, int b, int c, int d, float fx, float fy) {
        float w0 = (1f - fx) * (1f - fy), w1 = fx * (1f - fy);
        float w2 = (1f - fx) * fy, w3 = fx * fy;
        int aa = a >>> 24, ab = b >>> 24, ac = c >>> 24, ad = d >>> 24;
        float alpha = aa * w0 + ab * w1 + ac * w2 + ad * w3;
        int ia = Math.min(255, Math.max(0, Math.round(alpha)));
        if (ia == 0 || alpha < .0001f) return 0;
        // Caso comun manga opaco: interpolar sin multiplicar cuatro canales por alfa.
        if (aa == 255 && ab == 255 && ac == 255 && ad == 255) {
            int rr = Math.round(((a >>> 16) & 255) * w0 + ((b >>> 16) & 255) * w1
                    + ((c >>> 16) & 255) * w2 + ((d >>> 16) & 255) * w3);
            int gg = Math.round(((a >>> 8) & 255) * w0 + ((b >>> 8) & 255) * w1
                    + ((c >>> 8) & 255) * w2 + ((d >>> 8) & 255) * w3);
            int bb = Math.round((a & 255) * w0 + (b & 255) * w1 + (c & 255) * w2 + (d & 255) * w3);
            return 0xff000000 | (rr << 16) | (gg << 8) | bb;
        }
        float r = (((a >>> 16) & 255) * aa * w0 + ((b >>> 16) & 255) * ab * w1
                + ((c >>> 16) & 255) * ac * w2 + ((d >>> 16) & 255) * ad * w3) / alpha;
        float g = (((a >>> 8) & 255) * aa * w0 + ((b >>> 8) & 255) * ab * w1
                + ((c >>> 8) & 255) * ac * w2 + ((d >>> 8) & 255) * ad * w3) / alpha;
        float bl = ((a & 255) * aa * w0 + (b & 255) * ab * w1
                + (c & 255) * ac * w2 + (d & 255) * ad * w3) / alpha;
        return (ia << 24) | (Math.min(255, Math.round(r)) << 16)
                | (Math.min(255, Math.round(g)) << 8) | Math.min(255, Math.round(bl));
    }

    /**
     * Todos los arrays recibidos son copias inmutables de un unico instante.
     * El pixel en (x,y) se mapea usando el mismo convenio del render final,
     * incluyendo la mascara de seleccion opcional.
     */
    public static int[] render(int[] source, int sourceW, int sourceH,
            int sourceX, int sourceY, int canvasW, int canvasH,
            int destX, int destY, int destW, int destH,
            float[] dx, float[] dy, int cols, int rows, float gridStep,
            byte[] selection) {
        if (destW <= 0 || destH <= 0) return new int[0];
        int[] result = new int[destW * destH];
        float[] uv = new float[2];
        int p = 0;
        for (int yy = 0; yy < destH; yy++) {
            int y = destY + yy;
            for (int xx = 0; xx < destW; xx++, p++) {
                int x = destX + xx;
                displacement(dx, dy, cols, rows, gridStep, canvasW, canvasH,
                        x + .5f, y + .5f, uv);
                int base = source[(y - sourceY) * sourceW + x - sourceX];
                int warped = Math.abs(uv[0]) + Math.abs(uv[1]) < .002f ? base
                        : sampleArgb(source, sourceW, sourceH, sourceX, sourceY,
                                canvasW, canvasH, x + uv[0], y + uv[1]);
                if (selection == null) result[p] = warped;
                else {
                    int mask = selection[p] & 255;
                    result[p] = mask == 0 ? base : mask == 255 ? warped
                            : AlphaColors.mix(base, warped, mask / 255f);
                }
            }
        }
        return result;
    }
}
