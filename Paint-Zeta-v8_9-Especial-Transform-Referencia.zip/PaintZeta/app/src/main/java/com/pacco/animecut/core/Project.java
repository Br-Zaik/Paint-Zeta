package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * El documento: una lista de capas del mismo tamano, mas la capa de
 * seleccion (lo azul). Igual que en Ibis.
 */
public class Project {

    /** Indice especial: la capa de seleccion esta activa y se pinta lo azul. */
    public static final int SEL = -1;

    public int w;
    public int h;
    public final List<Layer> layers = new ArrayList<Layer>();
    public byte[] selection;
    public byte[] barrier;
    public int active = 0;

    private int[] ref;
    private boolean refDirty = true;

    /** Proyecto nuevo con la imagen en la primera capa. */
    public Project(Bitmap img) {
        this.w = img.getWidth();
        this.h = img.getHeight();
        int[] px = new int[w * h];
        img.getPixels(px, 0, w, 0, 0, w, h);
        layers.add(new Layer("imagen", px));
        selection = new byte[w * h];
        active = 0;
    }

    /** Proyecto vacio, para cargar desde archivo. */
    public Project(int w, int h) {
        this.w = w;
        this.h = h;
        selection = new byte[w * h];
    }

    public Layer activeLayer() {
        return active >= 0 && active < layers.size() ? layers.get(active) : null;
    }

    public boolean isSelectionLayerActive() {
        return active == SEL;
    }

    /** Sube cada vez que cambian los pixeles (para saber cuando rehacer calculos). */
    public volatile int version;

    public void markDirty() {
        refDirty = true;
        version++;
    }

    /**
     * Como se ve todo junto (sin fondo de vista). Es lo que miran la varita,
     * el gotero y el balde, igual que "Lienzo" en Ibis.
     */
    public int[] ref() {
        if (ref == null || ref.length != w * h) {
            ref = new int[w * h];
            refDirty = true;
        }
        if (!refDirty) return ref;
        Arrays.fill(ref, 0);
        boolean anyClip = false;
        for (Layer l : layers) if (l.clip) anyClip = true;
        // alfa de la capa base (para el recorte), solo si hace falta
        byte[] base = anyClip ? new byte[ref.length] : null;
        boolean baseSeen = false, baseHidden = false;
        for (Layer l : layers) {
            boolean clipped = l.clip && baseSeen;
            if (!clipped) {
                baseSeen = true;
                baseHidden = !l.visible || l.opacity <= 0;
            }
            if (clipped && baseHidden) continue;
            boolean isBase = base != null && !clipped;
            if (isBase) Arrays.fill(base, (byte) 0);
            if (!l.visible || l.opacity <= 0) continue;
            int op = l.opacity, md = l.mode;
            int[] s = l.denseOrNull();
            if (s != null && s.length == ref.length) {
                for (int i = 0; i < ref.length; i++) {
                    int c = s[i];
                    int ca = c >>> 24;
                    if (isBase) base[i] = (byte) ca;
                    if (clipped) ca = ca * (base[i] & 0xFF) / 255;
                    int sa = (ca * op) / 255;
                    if (sa == 0) continue;
                    ref[i] = over(ref[i], md == 0 ? c : mixMode(ref[i], c, md), sa);
                }
                continue;
            }
            Layer.Packed pk = l.snapshot(w, h);
            if (pk.empty()) continue;
            int[] buf = new int[pk.w];
            for (int yy = 0; yy < pk.h; yy++) {
                pk.row(pk.y + yy, buf);
                int dst = (pk.y + yy) * w + pk.x;
                for (int xx = 0; xx < pk.w; xx++) {
                    int c = buf[xx];
                    int ca = c >>> 24;
                    int k = dst + xx;
                    if (isBase) base[k] = (byte) ca;
                    if (clipped) ca = ca * (base[k] & 0xFF) / 255;
                    int sa = (ca * op) / 255;
                    if (sa == 0) continue;
                    ref[k] = over(ref[k], md == 0 ? c : mixMode(ref[k], c, md), sa);
                }
            }
        }
        refDirty = false;
        return ref;
    }

    // ---------------- modos de mezcla (como Ibis) ----------------

    private static int ch(int b, int s, int mode) {
        switch (mode) {
            case Layer.MODE_MULTIPLY:
                return b * s / 255;
            case Layer.MODE_SCREEN:
                return 255 - (255 - b) * (255 - s) / 255;
            case Layer.MODE_ADD:
                return Math.min(255, b + s);
            case Layer.MODE_OVERLAY:
                return b < 128 ? 2 * b * s / 255 : 255 - 2 * (255 - b) * (255 - s) / 255;
            default:
                return s;
        }
    }

    /**
     * El color de src ya mezclado con lo de abajo segun el modo. Donde abajo
     * es transparente se usa el color propio (como en Ibis). Guarda el alfa de src.
     */
    public static int mixMode(int dst, int src, int mode) {
        if (mode == Layer.MODE_NORMAL) return src;
        int da = dst >>> 24;
        if (da == 0) return src;
        int sr = (src >> 16) & 0xFF, sg = (src >> 8) & 0xFF, sb = src & 0xFF;
        int br = (dst >> 16) & 0xFF, bg = (dst >> 8) & 0xFF, bb = dst & 0xFF;
        int r = ch(br, sr, mode), g = ch(bg, sg, mode), b = ch(bb, sb, mode);
        if (da < 255) {
            r = (sr * (255 - da) + r * da) / 255;
            g = (sg * (255 - da) + g * da) / 255;
            b = (sb * (255 - da) + b * da) / 255;
        }
        return (src & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    /** Bloquear alfa: cambia el color pero deja la transparencia como estaba. */
    public static int lockOver(int dst, int src, int sa) {
        int da = dst >>> 24;
        if (da == 0 || sa <= 0) return dst;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * (255 - sa)) / 255;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * (255 - sa)) / 255;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * (255 - sa)) / 255;
        return (da << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Pintado "plano" (Saturacion de opacidad de Ibis): repasar con el mismo
     * color no oscurece; la opacidad nunca pasa de la elegida.
     */
    public static int flatOver(int dst, int src, int sa) {
        int da = dst >>> 24;
        if (da == 0) return (src & 0x00FFFFFF) | (sa << 24);
        int na = Math.max(da, sa);
        int dw = (da * (255 - sa)) / 255;
        int tot = sa + dw;
        if (tot <= 0) return dst;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * dw) / tot;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * dw) / tot;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * dw) / tot;
        return (na << 24) | (r << 16) | (g << 8) | b;
    }

    /** Pone src con alfa sa encima de dst. Todo sin premultiplicar. */
    public static int over(int dst, int src, int sa) {
        if (sa >= 255) return (src & 0x00FFFFFF) | 0xFF000000;
        int da = dst >>> 24;
        if (da == 0) return (src & 0x00FFFFFF) | (sa << 24);
        int oa = sa + (da * (255 - sa)) / 255;
        if (oa == 0) return 0;
        int dw = (da * (255 - sa)) / 255;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * dw) / oa;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * dw) / oa;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * dw) / oa;
        return (oa << 24) | (r << 16) | (g << 8) | b;
    }

    public boolean hasSelection() {
        for (byte b : selection) if (b != 0) return true;
        return false;
    }

    public void clearSelection() {
        Arrays.fill(selection, (byte) 0);
    }

    public Rect fullRect() {
        return new Rect(0, 0, w, h);
    }

    public Rect selectionBounds() {
        return HoleFill.bounds(selection, w, h);
    }

    /** Imagen reducida de todo junto, para miniaturas de la galeria. */
    public Bitmap previewBitmap(int maxSide) {
        int m = Math.max(w, h);
        float sc = m > maxSide ? (float) maxSide / m : 1f;
        int tw = Math.max(1, Math.round(w * sc)), th = Math.max(1, Math.round(h * sc));
        Bitmap b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        int[] row = new int[tw];
        List<Layer> ls = new ArrayList<Layer>(layers);
        for (int y = 0; y < th; y++) {
            int sy = Math.min(h - 1, y * h / th);
            for (int x = 0; x < tw; x++) {
                int sx = Math.min(w - 1, x * w / tw);
                // sobre blanco, para que se vea en la galeria
                int c = 0xFFFFFFFF;
                int baseA = -1;
                boolean baseHidden = false;
                for (Layer l : ls) {
                    boolean clipped = l.clip && baseA >= 0;
                    if (clipped && baseHidden) continue;
                    if (!clipped) baseHidden = !l.visible || l.opacity <= 0;
                    if (!l.visible || l.opacity <= 0) {
                        if (!clipped) baseA = 0;
                        continue;
                    }
                    int v = l.at(sx, sy, w);
                    int ca = v >>> 24;
                    if (clipped) ca = ca * baseA / 255;
                    else baseA = ca;
                    int sa = (ca * l.opacity) / 255;
                    if (sa > 0) c = over(c, l.mode == 0 ? v : mixMode(c, v, l.mode), sa);
                }
                row[x] = c;
            }
            b.setPixels(row, 0, tw, 0, y, tw, 1);
        }
        return b;
    }

    // ---------------- girar y voltear todo junto ----------------

    public void rotate90(boolean cw) {
        int ow = w, oh = h;
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            l.setPx(rotInts(l.px(), ow, oh, cw));
            if (wasPacked && k != active) l.pack(oh, ow);
        }
        selection = rotBytes(selection, ow, oh, cw);
        barrier = null;
        ref = null;
        w = oh;
        h = ow;
        markDirty();
    }

    public void flip(boolean horizontal) {
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            l.setPx(flipInts(l.px(), w, h, horizontal));
            if (wasPacked && k != active) l.pack(w, h);
        }
        selection = flipBytes(selection, w, h, horizontal);
        barrier = null;
        markDirty();
    }

    /** Empaca las capas que no se estan usando para liberar memoria. */
    public void packInactive() {
        for (int k = 0; k < layers.size(); k++) {
            if (k == active) continue;
            Layer l = layers.get(k);
            if (!l.isPacked()) l.pack(w, h);
        }
    }

    /** Memoria que ocupan las capas ahora (aprox). */
    public long layersMemory() {
        long s = 0;
        for (Layer l : layers) s += l.javaMemory();
        return s;
    }

    private static int[] rotInts(int[] s, int w, int h, boolean cw) {
        int[] d = new int[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = cw ? h - 1 - y : y, ny = cw ? x : w - 1 - x;
                d[ny * h + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static byte[] rotBytes(byte[] s, int w, int h, boolean cw) {
        byte[] d = new byte[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = cw ? h - 1 - y : y, ny = cw ? x : w - 1 - x;
                d[ny * h + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static int[] flipInts(int[] s, int w, int h, boolean hor) {
        int[] d = new int[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = hor ? w - 1 - x : x, ny = hor ? y : h - 1 - y;
                d[ny * w + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static byte[] flipBytes(byte[] s, int w, int h, boolean hor) {
        byte[] d = new byte[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = hor ? w - 1 - x : x, ny = hor ? y : h - 1 - y;
                d[ny * w + nx] = s[y * w + x];
            }
        }
        return d;
    }
}
