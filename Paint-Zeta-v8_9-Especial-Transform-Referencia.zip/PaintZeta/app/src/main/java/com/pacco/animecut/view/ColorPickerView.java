package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Selector HSV compacto: aro de tono y rombo interior de saturacion/valor.
 * No crea bitmaps por movimiento; solo usa shaders y unas pocas primitivas.
 */
public class ColorPickerView extends View {
    public interface Listener { void onColorChanged(int color); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint marker = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path diamond = new Path();
    private final float[] hsv = {0f, 1f, 1f};
    private final float[] hueOnly = {0f, 1f, 1f};
    private static final float[] HUE_POS = {0f, 1f / 6f, 2f / 6f, 3f / 6f, 4f / 6f, 5f / 6f, 1f};
    private static final int[] HUE_COLORS = {Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED};
    private Listener listener;
    private float cx, cy, outerR, innerR, dR;
    private int drag = 0; // 1 aro, 2 rombo

    public ColorPickerView(Context c) { super(c); init(); }
    public ColorPickerView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        marker.setStyle(Paint.Style.STROKE);
        marker.setStrokeWidth(dp(3));
        marker.setColor(Color.WHITE);
    }

    public void setListener(Listener l) { listener = l; }

    public void setColor(int color) {
        Color.colorToHSV(color | 0xFF000000, hsv);
        invalidate();
    }

    public int getColor() { return Color.HSVToColor(hsv); }

    @Override protected void onMeasure(int ws, int hs) {
        int want = dp(300);
        int w = resolveSize(want, ws), h = resolveSize(want, hs);
        int s = Math.min(w, h);
        setMeasuredDimension(s, s);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        cx = w / 2f; cy = h / 2f;
        outerR = Math.min(w, h) * .48f;
        innerR = outerR * .70f;
        dR = innerR * .86f;
        buildDiamond();
    }

    private void buildDiamond() {
        diamond.reset();
        diamond.moveTo(cx, cy - dR);
        diamond.lineTo(cx + dR, cy);
        diamond.lineTo(cx, cy + dR);
        diamond.lineTo(cx - dR, cy);
        diamond.close();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (outerR <= 0) return;

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(dp(22), outerR - innerR));
        p.setShader(new SweepGradient(cx, cy, HUE_COLORS, HUE_POS));
        float rr = (outerR + innerR) * .5f;
        c.drawCircle(cx, cy, rr, p);
        p.setShader(null);

        // Rombo: primero valor (blanco -> color), luego negro hacia abajo.
        hueOnly[0] = hsv[0];
        int hueColor = Color.HSVToColor(hueOnly);
        c.save();
        c.clipPath(diamond);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(cx - dR, cy, cx + dR, cy,
                Color.WHITE, hueColor, Shader.TileMode.CLAMP));
        c.drawRect(cx - dR, cy - dR, cx + dR, cy + dR, p);
        p.setShader(new LinearGradient(cx, cy - dR, cx, cy + dR,
                0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
        c.drawRect(cx - dR, cy - dR, cx + dR, cy + dR, p);
        p.setShader(null);
        c.restore();

        // Marcador de tono.
        double a = Math.toRadians(hsv[0]);
        float tr = rr;
        float tx = cx + (float) Math.cos(a) * tr;
        float ty = cy + (float) Math.sin(a) * tr;
        c.drawCircle(tx, ty, dp(8), marker);
        marker.setColor(Color.BLACK);
        marker.setStrokeWidth(dp(1.5f));
        c.drawCircle(tx, ty, dp(10), marker);

        // Marcador del rombo. Mapeo estable y facil de usar: x=saturacion, y=valor.
        float lx = (hsv[1] - .5f) * 2f * dR;
        float ly = (.5f - hsv[2]) * 2f * dR;
        // proyectar al rombo si quedara fuera
        float sum = Math.abs(lx) + Math.abs(ly);
        if (sum > dR) { lx *= dR / sum; ly *= dR / sum; }
        marker.setColor(Color.WHITE); marker.setStrokeWidth(dp(3));
        c.drawCircle(cx + lx, cy + ly, dp(8), marker);
        marker.setColor(Color.BLACK); marker.setStrokeWidth(dp(1.5f));
        c.drawCircle(cx + lx, cy + ly, dp(10), marker);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        float dx = x - cx, dy = y - cy;
        float r = (float) Math.hypot(dx, dy);
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            if (r >= innerR * .88f && r <= outerR * 1.08f) drag = 1;
            else if (Math.abs(dx) + Math.abs(dy) <= dR * 1.12f) drag = 2;
            else return false;
            getParent().requestDisallowInterceptTouchEvent(true);
            updateFrom(x, y);
            return true;
        }
        if (a == MotionEvent.ACTION_MOVE && drag != 0) {
            updateFrom(x, y); return true;
        }
        if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) && drag != 0) {
            updateFrom(x, y); drag = 0; return true;
        }
        return true;
    }

    private void updateFrom(float x, float y) {
        float dx = x - cx, dy = y - cy;
        if (drag == 1) {
            float deg = (float) Math.toDegrees(Math.atan2(dy, dx));
            if (deg < 0) deg += 360f;
            hsv[0] = deg;
        } else {
            // Proyecta el punto al rombo y obtiene S/V sin saltos.
            float sum = Math.abs(dx) + Math.abs(dy);
            if (sum > dR) { dx *= dR / sum; dy *= dR / sum; }
            hsv[1] = clamp(.5f + dx / (2f * dR));
            hsv[2] = clamp(.5f - dy / (2f * dR));
        }
        invalidate();
        if (listener != null) listener.onColorChanged(getColor());
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
