package com.pacco.animecut.core;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Exporta capas como PNG transparente conservando el tamano/posicion del
 * lienzo para que entren alineadas en Alight Motion.
 *
 * v8.7: la limpieza y el trabajo temporal se hacen solo sobre el rectangulo
 * con contenido de cada capa. En una pieza pequena ya no se crean 3-4 buffers
 * del tamano completo del lienzo.
 */
public final class Exporter {

    private Exporter() {}

    private static final class Prepared {
        final Rect r;
        final int[] px;
        Prepared(Rect r, int[] px) { this.r = r; this.px = px; }
        boolean empty() { return r == null || px == null || r.isEmpty(); }
    }

    public static int exportZip(ContentResolver cr, Project p, Uri uri, int outW, int outH,
                                int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os));
        zos.setLevel(1);
        int count = 0;
        try {
            int idx = 1;
            for (Layer l : p.layers) {
                if (!l.visible) continue;
                zos.putNextEntry(new ZipEntry(String.format(Locale.US, "%02d_%s.png", idx++, safe(l.name))));
                writePng(p, prepare(p, l, edgeClean), outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            zos.finish();
        } finally {
            try { zos.close(); } catch (IOException ignored) {}
        }
        return count;
    }

    public static void exportLayer(ContentResolver cr, Project p, Layer l, Uri uri, int outW, int outH,
                                   int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writePng(p, prepare(p, l, edgeClean), outW, outH, bos);
            bos.flush();
        } finally {
            try { bos.close(); } catch (IOException ignored) {}
        }
    }

    public static void exportLayer(ContentResolver cr, Project p, Layer l, Uri uri, int edgeClean)
            throws IOException {
        exportLayer(cr, p, l, uri, p.w, p.h, edgeClean);
    }

    /** Prepara solo el rectangulo que realmente ocupa la capa. */
    private static Prepared prepare(Project p, Layer l, int edgeClean) {
        Rect b = l.bounds(p.w, p.h);
        if (b == null || b.isEmpty()) return new Prepared(new Rect(0, 0, 0, 0), new int[0]);
        int rw = b.width(), rh = b.height(), n = rw * rh;
        int[] out = new int[n];
        l.read(b.left, b.top, rw, rh, out, p.w, p.h);

        int[] base = null;
        if (l.clip) {
            int idx = p.layers.indexOf(l);
            for (int k = idx - 1; k >= 0; k--) {
                Layer below = p.layers.get(k);
                if (!below.clip) {
                    base = new int[n];
                    below.read(b.left, b.top, rw, rh, base, p.w, p.h);
                    break;
                }
            }
        }

        byte[] mask = edgeClean > 0 ? new byte[n] : null;
        for (int i = 0; i < n; i++) {
            int c = out[i];
            int a = ((c >>> 24) * l.opacity) / 255;
            if (base != null) a = a * (base[i] >>> 24) / 255;
            out[i] = (a << 24) | (c & 0x00FFFFFF);
            if (mask != null) mask[i] = (byte) a;
        }
        base = null;
        if (mask == null) return new Prepared(b, out);

        // Defringe tambien regional: evita buffers gigantes cuando solo se
        // exporta un brazo/cabello/cabeza.
        int[] rgb = new int[n];
        for (int i = 0; i < n; i++) rgb[i] = out[i] | 0xFF000000;
        // Una capa transparente no conserva el color real que habia detras.
        // Intentar adivinarlo desde RGB=0 de los transparentes crea halos negros.
        // Por eso limpiamos tomando color de adentro; modo 2 usa un radio mayor.
        int radius = edgeClean >= 2 ? 4 : 3;
        int[] clean = Defringe.clean(rgb, mask, rw, rh, radius, false, 0);
        for (int i = 0; i < n; i++) out[i] = (out[i] & 0xFF000000) | (clean[i] & 0x00FFFFFF);
        return new Prepared(b, out);
    }

    private static void writePng(Project p, Prepared prep, int outW, int outH, OutputStream out) {
        if (outW <= 0) outW = p.w;
        if (outH <= 0) outH = p.h;
        Bitmap dst = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        dst.setPremultiplied(false);
        if (!prep.empty()) {
            int rw = prep.r.width(), rh = prep.r.height();
            if (outW == p.w && outH == p.h) {
                dst.setPixels(prep.px, 0, rw, prep.r.left, prep.r.top, rw, rh);
            } else {
                Bitmap part = Bitmap.createBitmap(prep.px, rw, rh, Bitmap.Config.ARGB_8888);
                part.setPremultiplied(false);
                Canvas c = new Canvas(dst);
                RectF to = new RectF(
                        prep.r.left * outW / (float) p.w,
                        prep.r.top * outH / (float) p.h,
                        prep.r.right * outW / (float) p.w,
                        prep.r.bottom * outH / (float) p.h);
                Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                c.drawBitmap(part, null, to, paint);
                part.recycle();
            }
        }
        dst.compress(Bitmap.CompressFormat.PNG, 100, out);
        dst.recycle();
    }

    private static String safe(String s) {
        if (s == null) return "capa";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(Character.isLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
        return sb.length() == 0 ? "capa" : sb.toString();
    }
}
