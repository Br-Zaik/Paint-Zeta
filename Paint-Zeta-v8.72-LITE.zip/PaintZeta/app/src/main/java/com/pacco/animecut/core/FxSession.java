package com.pacco.animecut.core;

import java.util.ArrayList;
import java.util.List;

/**
 * v8.57: lo que hay detras de la pantalla "Filtros", sin nada de Android (se prueba en PC).
 *
 *  - Al abrir hace UNA copia chica de cada capa (lado mayor &lt;= mainSide) leyendo por franjas,
 *    asi no se necesita otra copia de la imagen grande en memoria.
 *  - Las capas de abajo se juntan una sola vez; en cada cambio solo se filtra la capa elegida
 *    (en chico) y se juntan las de arriba (pueden tener modos de mezcla: no se pre-juntan).
 *  - Mientras se arrastra la barra se usa una copia todavia mas chica (dragSide) para que vaya
 *    fluido en telefonos modestos; al soltar se calcula en la copia normal.
 *  - Si hay seleccion, el filtro solo cambia lo seleccionado (vista previa y resultado).
 *  - El resultado final se calcula a tamano real con el mismo motor (Fx).
 */
public final class FxSession {
    private final List<Layer> layers;
    private final Layer active;
    private final int activeIdx, w, h;
    private final byte[] selection;
    private final int mainSide, dragSide;
    private int hiSide;

    /** Copias: [0] normal, [1] para arrastrar, [2] v8.59 "resultado real" (tamano real o casi). */
    public static final int MAIN = 0, DRAG = 1, HI = 2;
    private final Level[] lv = new Level[3];
    /** Guarda calculos caros entre cambios (sombra, volumen, papel). Una por nivel. */
    private final Fx.Cache[] caches = {new Fx.Cache(), new Fx.Cache(), new Fx.Cache()};
    /** v8.59: ultimo resultado del nivel real (si es tamano real, Aceptar lo usa sin recalcular). */
    private int[] hiFilt;
    private int hiId = -1;
    private Fx.P hiP;

    static final class Level {
        int pw, ph;
        float s;
        int[] src;                 // capa elegida en chico
        Layer below;               // todo lo de abajo ya junto (null si no se pudo)
        List<Layer> all;           // todas en chico (si la elegida esta recortada)
        List<Layer> above;         // las de arriba en chico
        byte[] sel;                // seleccion en chico (null = todo)
        int[] out, tmp;            // buffers reutilizados
    }

    public FxSession(List<Layer> layers, int activeIdx, int w, int h, byte[] selection, int mainSide, int dragSide) {
        this.layers = new ArrayList<>(layers);
        this.activeIdx = activeIdx;
        this.active = layers.get(activeIdx);
        this.w = w;
        this.h = h;
        boolean any = false;
        if (selection != null) for (byte b : selection) if (b != 0) { any = true; break; }
        this.selection = any ? selection : null;
        this.mainSide = mainSide;
        this.dragSide = Math.min(dragSide, mainSide);
    }

    public int width(boolean drag) { return lv[drag ? 1 : 0].pw; }

    public int height(boolean drag) { return lv[drag ? 1 : 0].ph; }

    public float scale(boolean drag) { return lv[drag ? 1 : 0].s; }

    public int widthAt(int level) { return lv[level].pw; }

    public int heightAt(int level) { return lv[level].ph; }

    public float scaleAt(int level) { return lv[level].s; }

    /** Lado del nivel "resultado real" (0 = no usar). */
    public void setHiSide(int side) { hiSide = side; }

    public boolean hasHi() { return lv[HI] != null; }

    /** Arma el nivel real la primera vez que se pide (lento: fuera de la pantalla). */
    public boolean buildHi(Fx.Job job) {
        if (lv[HI] != null) return true;
        if (hiSide <= mainSide && Math.max(w, h) > mainSide) return false;
        int side = Math.min(Math.max(w, h), hiSide);
        if (side <= lv[MAIN].pw && side <= lv[MAIN].ph) { lv[HI] = lv[MAIN]; return true; }
        lv[HI] = buildLevel(side, job);
        return true;
    }

    /** Como render(), en el nivel pedido. En el nivel real guarda el resultado para Aceptar. */
    public int[] renderAt(int level, int id, Fx.P p, Fx.Job job) {
        Level L = lv[level];
        int[] f = Fx.apply(id, L.src, L.pw, L.ph, p, L.s, job, caches[level]);
        if (L.sel != null) f = mixMask(L.src, f, L.sel);
        if (level == HI && L.s >= 0.999f) { hiFilt = f; hiId = id; hiP = p.copy(); }
        return compose(L, f, job);
    }

    /** El resultado a tamano real ya calculado para estos valores (o null). */
    public int[] fullCached(int id, Fx.P p) {
        if (hiFilt == null || hiId != id || hiP == null || lv[HI] == null || lv[HI].s < 0.999f) return null;
        if (hiP.opt != p.opt || hiP.px != p.px || hiP.py != p.py) return null;
        for (int i = 0; i < 3; i++) if (hiP.v[i] != p.v[i]) return null;
        return hiFilt;
    }

    public boolean hasSelection() { return selection != null; }

    /** Prepara las copias chicas (lento: llamar fuera del hilo de la pantalla). */
    public void build(Fx.Job job) {
        lv[0] = buildLevel(mainSide, job);
        lv[1] = dragSide < mainSide ? buildLevel(dragSide, job) : lv[0];
    }

    private Level buildLevel(int side, Fx.Job job) {
        Level L = new Level();
        float sc = Math.min(1f, side / (float) Math.max(w, h));
        L.pw = Math.max(1, Math.round(w * sc));
        L.ph = Math.max(1, Math.round(h * sc));
        L.s = L.pw / (float) w;
        List<Layer> small = new ArrayList<>();
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            if (job != null && job.cancelled()) throw new Fx.Cancelled();
            int[] px = (l == active || (l.visible && l.opacity > 0)) ? shrink(l, L.pw, L.ph) : new int[L.pw * L.ph];
            if (l == active) L.src = px;
            small.add(props(new Layer(l.name, px), l));
        }
        if (selection != null) {
            L.sel = new byte[L.pw * L.ph];
            for (int y = 0; y < L.ph; y++) {
                int sy = Math.min(h - 1, (int) ((y + .5f) * h / L.ph));
                for (int x = 0; x < L.pw; x++)
                    L.sel[y * L.pw + x] = selection[sy * w + Math.min(w - 1, (int) ((x + .5f) * w / L.pw))];
            }
        }
        if (!active.clip) {
            int[] b = new int[L.pw * L.ph];
            Compositor.composite(small, activeIdx, L.pw, L.ph, 0, 0, L.pw, L.ph, b);
            L.below = new Layer("abajo", b);
            L.above = new ArrayList<>(small.subList(activeIdx + 1, small.size()));
        } else {
            L.all = small;
        }
        L.out = new int[L.pw * L.ph];
        return L;
    }

    private static Layer props(Layer d, Layer s) {
        d.visible = s.visible;
        d.opacity = s.opacity;
        d.mode = s.mode;
        d.clip = s.clip;
        d.clipOut = s.clipOut;
        d.hue = s.hue;
        d.sat = s.sat;
        d.lit = s.lit;
        return d;
    }

    /** Copia chica de una capa leyendola por franjas (promedio premultiplicado). */
    private int[] shrink(Layer l, int pw, int ph) {
        int[] d = l.denseOrNull();
        if (d != null && d.length == w * h) {
            int[] dims = new int[2];
            int[] r = Fx.downscale(d, w, h, Math.max(pw, ph), dims);
            if (dims[0] == pw && dims[1] == ph) return r;
        }
        long[] sa = new long[pw * ph], sr = new long[sa.length], sg = new long[sa.length], sb = new long[sa.length];
        int[] cnt = new int[sa.length];
        int strip = Math.max(1, Math.min(h, 1_000_000 / Math.max(1, w)));
        int[] buf = new int[w * strip];
        for (int y0 = 0; y0 < h; y0 += strip) {
            int rh = Math.min(strip, h - y0);
            l.read(0, y0, w, rh, buf, w, h);
            for (int yy = 0; yy < rh; yy++) {
                int py = Math.min(ph - 1, (int) ((long) (y0 + yy) * ph / h));
                int row = yy * w;
                for (int x = 0; x < w; x++) {
                    int px = Math.min(pw - 1, (int) ((long) x * pw / w));
                    int k = py * pw + px, c = buf[row + x], a = c >>> 24;
                    cnt[k]++;
                    if (a == 0) continue;
                    sa[k] += a;
                    sr[k] += (long) ((c >> 16) & 255) * a;
                    sg[k] += (long) ((c >> 8) & 255) * a;
                    sb[k] += (long) (c & 255) * a;
                }
            }
        }
        int[] out = new int[pw * ph];
        for (int k = 0; k < out.length; k++) {
            if (sa[k] == 0) continue;
            out[k] = ((int) (sa[k] / cnt[k]) << 24) | ((int) (sr[k] / sa[k]) << 16) | ((int) (sg[k] / sa[k]) << 8) | (int) (sb[k] / sa[k]);
        }
        return out;
    }

    /**
     * Filtra la capa elegida en chico y junta todo. @return pixeles opacos (sobre cuadros)
     * de width(drag) x height(drag). El arreglo devuelto se reutiliza: copiarlo antes de pedir otro.
     */
    public int[] render(int id, Fx.P p, boolean drag, Fx.Job job) {
        Level L = lv[drag ? 1 : 0];
        int[] f = Fx.apply(id, L.src, L.pw, L.ph, p, L.s, job, caches[drag ? 1 : 0]);
        if (L.sel != null) f = mixMask(L.src, f, L.sel);
        return compose(L, f, job);
    }

    /** Sin filtro (para comparar o mientras carga). */
    public int[] original(boolean drag) {
        Level L = lv[drag ? 1 : 0];
        return compose(L, L.src, null);
    }

    private int[] compose(Level L, int[] activePx, Fx.Job job) {
        if (job != null && job.cancelled()) throw new Fx.Cancelled();
        List<Layer> list = new ArrayList<>();
        Layer act = props(new Layer(active.name, activePx), active);
        if (L.below != null) {
            list.add(L.below);
            list.add(act);
            list.addAll(L.above);
        } else {
            list.addAll(L.all);
            list.set(activeIdx, act);
        }
        int n = L.pw * L.ph;
        if (L.tmp == null) L.tmp = new int[n];
        Compositor.composite(list, list.size(), L.pw, L.ph, 0, 0, L.pw, L.ph, L.tmp);
        int[] o = L.out;
        for (int y = 0; y < L.ph; y++)
            for (int x = 0; x < L.pw; x++) {
                int i = y * L.pw + x;
                int bg = (((x >> 3) + (y >> 3)) & 1) == 0 ? 0xFFFFFFFF : 0xFFDADDE2;
                o[i] = Compositor.overOpaque(bg, L.tmp[i]);
            }
        return o;
    }

    /** Miniatura de un filtro (valores por defecto) sobre cuadros, lado &lt;= side. */
    public int[] thumb(int id, int side, int[] dims) {
        Level L = lv[1];
        int[] small = Fx.downscale(L.src, L.pw, L.ph, side, dims);
        float s = L.s * dims[0] / (float) L.pw;
        int[] f = Fx.apply(id, small, dims[0], dims[1], Fx.defaults(id), s, null, null);
        for (int y = 0; y < dims[1]; y++)
            for (int x = 0; x < dims[0]; x++) {
                int i = y * dims[0] + x;
                int bg = (((x >> 2) + (y >> 2)) & 1) == 0 ? 0xFFFFFFFF : 0xFFDADDE2;
                f[i] = Compositor.overOpaque(bg, f[i]);
            }
        return f;
    }

    /** Resultado a tamano real de la capa elegida (con la seleccion, si hay). */
    public int[] full(int id, Fx.P p, Fx.Job job) {
        int[] src = new int[w * h];
        active.copyTo(src, w, h);
        int[] f = Fx.apply(id, src, w, h, p, 1f, job, null);
        if (selection != null) f = mixMask(src, f, selection);
        return f;
    }

    /** orig donde no hay seleccion, filtrado donde si (borde suave, premultiplicado). */
    public static int[] mixMask(int[] orig, int[] filt, byte[] sel) {
        int[] o = new int[orig.length];
        for (int i = 0; i < o.length; i++) {
            int m = sel[i] & 0xFF;
            if (m == 0) { o[i] = orig[i]; continue; }
            if (m == 255) { o[i] = filt[i]; continue; }
            int a = orig[i], b = filt[i];
            int aa = a >>> 24, ba = b >>> 24;
            int oa = (aa * (255 - m) + ba * m) / 255;
            if (oa == 0) continue;
            int r = (((a >> 16) & 255) * aa * (255 - m) + ((b >> 16) & 255) * ba * m) / (oa * 255);
            int g = (((a >> 8) & 255) * aa * (255 - m) + ((b >> 8) & 255) * ba * m) / (oa * 255);
            int bl = ((a & 255) * aa * (255 - m) + (b & 255) * ba * m) / (oa * 255);
            o[i] = (oa << 24) | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, bl);
        }
        return o;
    }

    public void release() {
        lv[0] = lv[1] = lv[2] = null;
        hiFilt = null;
        for (Fx.Cache c : caches) c.clear();
    }
}
