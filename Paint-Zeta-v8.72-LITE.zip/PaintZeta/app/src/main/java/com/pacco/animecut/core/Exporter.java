package com.pacco.animecut.core;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Exporta capas como PNG transparente conservando el tamano/posicion del
 * lienzo para que entren alineadas en Alight Motion.
 *
 * v8.7: la limpieza y el trabajo temporal se hacen solo sobre el rectangulo
 * con contenido de cada capa. En una pieza pequena ya no se crean 3-4 buffers
 * del tamano completo del lienzo.
 */
public final class Exporter {

    private Exporter() {}

    private static final class Prepared {
        final Rect r;
        final int[] px;
        Prepared(Rect r, int[] px) { this.r = r; this.px = px; }
        boolean empty() { return r == null || px == null || r.isEmpty(); }
    }

    public static int exportZip(ContentResolver cr, Project p, Uri uri, int outW, int outH,
                                int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os));
        zos.setLevel(1);
        int count = 0;
        try {
            int idx = 1;
            for (Layer l : p.layers) {
                if (!l.visible) continue;
                zos.putNextEntry(new ZipEntry(String.format(Locale.US, "%02d_%s.png", idx++, safe(l.name))));
                writePng(p, prepare(p, l, edgeClean), outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            zos.putNextEntry(new ZipEntry("LEEME_Partes.txt"));
            String help = "Paint Zeta - Capas para animacion\n"
                    + "Lienzo: " + outW + " x " + outH + " px\n"
                    + "Cada PNG tiene transparencia y el mismo origen (0,0).\n"
                    + "Extrae los PNG e importalos como capas individuales en tu editor de animacion.\n"
                    + "No recortes automaticamente los PNG: perderian su alineacion.\n"
                    + "Las capas en Multiplicar u otro modo (por ejemplo la capa Color) se guardan ya\n"
                    + "mezcladas con lo de abajo, porque un PNG no guarda el modo: usalas en modo Normal.\n";
            zos.write(help.getBytes("UTF-8"));
            zos.closeEntry();
            zos.finish();
        } finally {
            try { zos.close(); } catch (IOException ignored) {}
        }
        return count;
    }

    public static void exportLayer(ContentResolver cr, Project p, Layer l, Uri uri, int outW, int outH,
                                   int edgeClean) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writePng(p, prepare(p, l, edgeClean), outW, outH, bos);
            bos.flush();
        } finally {
            try { bos.close(); } catch (IOException ignored) {}
        }
    }

    public static void exportLayer(ContentResolver cr, Project p, Layer l, Uri uri, int edgeClean)
            throws IOException {
        exportLayer(cr, p, l, uri, p.w, p.h, edgeClean);
    }

    /** Prepara solo el rectangulo que realmente ocupa la capa. */
    private static Prepared prepare(Project p, Layer l, int edgeClean) {
        Rect b = l.bounds(p.w, p.h);
        if (b == null || b.isEmpty()) return new Prepared(new Rect(0, 0, 0, 0), new int[0]);
        int rw = b.width(), rh = b.height(), n = rw * rh;
        int[] out = new int[n];
        l.read(b.left, b.top, rw, rh, out, p.w, p.h);
        // v8.26: "Cambiar color" no destructivo se ve igual en el PNG
        ColorAdjust adj = l.adjuster();
        if (adj != null) for (int i = 0; i < n; i++) out[i] = adj.apply(out[i]);

        int[] base = null;
        if (l.clip) {
            int idx = p.layers.indexOf(l);
            for (int k = idx - 1; k >= 0; k--) {
                Layer below = p.layers.get(k);
                if (!below.clip) {
                    base = new int[n];
                    below.read(b.left, b.top, rw, rh, base, p.w, p.h);
                    break;
                }
            }
        }

        // v8.23: un PNG no guarda el modo de mezcla. Una capa en Multiplicar (por
        // ejemplo "Color (sin tapar lineas)") se exporta YA mezclada con lo que tiene
        // debajo, asi se ve igual en Alight Motion en modo Normal. Las capas en
        // modo Normal se exportan exactamente como antes.
        if (l.mode != Layer.MODE_NORMAL) bakeBlend(p, l, b, out);

        byte[] mask = edgeClean > 0 ? new byte[n] : null;
        for (int i = 0; i < n; i++) {
            int c = out[i];
            int a = ((c >>> 24) * l.opacity) / 255;
            if (base != null) a = Layer.clipA(a, base[i] >>> 24, l.clipOut);
            out[i] = (a << 24) | (c & 0x00FFFFFF);
            if (mask != null) mask[i] = (byte) a;
        }
        base = null;
        if (mask == null) return new Prepared(b, out);

        // Defringe tambien regional: evita buffers gigantes cuando solo se
        // exporta un brazo/cabello/cabeza.
        int[] rgb = new int[n];
        for (int i = 0; i < n; i++) rgb[i] = out[i] | 0xFF000000;
        // Una capa transparente no conserva el color real que habia detras.
        // Intentar adivinarlo desde RGB=0 de los transparentes crea halos negros.
        // Por eso limpiamos tomando color de adentro; modo 2 usa un radio mayor.
        int radius = edgeClean >= 2 ? 4 : 3;
        int[] clean = Defringe.clean(rgb, mask, rw, rh, radius, false, 0);
        for (int i = 0; i < n; i++) out[i] = (out[i] & 0xFF000000) | (clean[i] & 0x00FFFFFF);
        return new Prepared(b, out);
    }

    /**
     * Mezcla la capa con la composicion de las capas visibles de debajo (solo color;
     * conserva su alfa). v8.26: la composicion de abajo respeta recortes, bases ocultas
     * y "Cambiar color" (antes ignoraba el recorte de las capas de abajo).
     */
    static void bakeBlend(Project p, Layer l, Rect b, int[] out) {
        int idx = p.layers.indexOf(l);
        if (idx <= 0) return;
        int rw = b.width(), rh = b.height(), n = rw * rh;
        int[] below = new int[n];
        Compositor.composite(p.layers, idx, p.w, p.h, b.left, b.top, rw, rh, below);
        for (int i = 0; i < n; i++) {
            int c = out[i];
            if ((c >>> 24) == 0 || (below[i] >>> 24) == 0) continue;
            out[i] = Project.mixMode(below[i], c, l.mode);
        }
    }

    /**
     * v8.26 "Imagen completa": un solo PNG con todas las capas visibles juntas, igual
     * que en pantalla (Multiplicar, recorte, opacidad, Cambiar color). Lo transparente
     * queda transparente. La referencia de colores nunca entra (no es una capa).
     */
    public static void exportFlattened(ContentResolver cr, Project p, Uri uri, int outW, int outH) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writeFlattened(p, outW, outH, bos);
            bos.flush();
        } finally {
            try { bos.close(); } catch (IOException ignored) {}
        }
    }

    /** Una capa como PNG (lo mismo que exportLayer, sin ContentResolver; lo usan las pruebas). */
    public static void writeLayerPng(Project p, Layer l, int edgeClean, OutputStream out) {
        writePng(p, prepare(p, l, edgeClean), p.w, p.h, out);
    }

    /** Escribe la imagen completa como PNG (tambien lo usan las pruebas). */
    public static void writeFlattened(Project p, int outW, int outH, OutputStream out) {
        int[] px = Compositor.flatten(p);
        writePng(p, new Prepared(new Rect(0, 0, p.w, p.h), px), outW, outH, out);
    }

    private static void writePng(Project p, Prepared prep, int outW, int outH, OutputStream out) {
        if (outW <= 0) outW = p.w;
        if (outH <= 0) outH = p.h;
        Bitmap dst = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        dst.setPremultiplied(false);
        if (!prep.empty()) {
            int rw = prep.r.width(), rh = prep.r.height();
            if (outW == p.w && outH == p.h) {
                dst.setPixels(prep.px, 0, rw, prep.r.left, prep.r.top, rw, rh);
            } else {
                Bitmap part = Bitmap.createBitmap(prep.px, rw, rh, Bitmap.Config.ARGB_8888);
                part.setPremultiplied(false);
                Canvas c = new Canvas(dst);
                RectF to = new RectF(
                        prep.r.left * outW / (float) p.w,
                        prep.r.top * outH / (float) p.h,
                        prep.r.right * outW / (float) p.w,
                        prep.r.bottom * outH / (float) p.h);
                Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                c.drawBitmap(part, null, to, paint);
                part.recycle();
            }
        }
        dst.compress(Bitmap.CompressFormat.PNG, 100, out);
        dst.recycle();
    }

    private static String safe(String s) {
        if (s == null) return "capa";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(Character.isLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
        return sb.length() == 0 ? "capa" : sb.toString();
    }
}
