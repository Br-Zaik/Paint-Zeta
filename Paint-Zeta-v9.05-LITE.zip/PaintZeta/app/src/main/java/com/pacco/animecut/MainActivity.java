package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ShapeGeom;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.core.ProjectStore;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.Thumbs;
import com.pacco.animecut.ai.Upscaler;
import com.pacco.animecut.view.CanvasView;
import com.pacco.animecut.view.ColorPickerView;
import com.pacco.animecut.view.SelDemoView;
import com.pacco.animecut.view.ReferenceImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Pantalla principal. Funciona como Ibis: capas de verdad, capa de seleccion,
 * herramientas en un panel chico abajo a la izquierda.
 */
public class MainActivity extends AppCompatActivity implements CanvasView.Callback {

    // v8.86: la letra de la app crece con la del telefono solo hasta 115% (botones sin cortes)
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(PzSystem.fontCap(base));
    }

    public static final String EXTRA_PROJECT = "obra";

    private static final int[] PALETTE = {
            0xFF000000, 0xFF444444, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF, 0xFF7A4A2B,
            0xFFE05A5A, 0xFFFF7A45, 0xFFFFB03A, 0xFFFFE05C, 0xFFB5E05A, 0xFF4FC66B,
            0xFF3DD6C0, 0xFF4DA3FF, 0xFF3D6BFF, 0xFF7B5CFF, 0xFFB558FF, 0xFFFF6FC3,
            0xFFFFE0C4, 0xFFF5C9A6, 0xFFD9A377, 0xFF9C6B4A, 0xFF2B2B3A, 0xFF1B3358
    };

    private CanvasView canvas;
    private TextView sliderLabel;
    private SeekBar slider;
    // La fila inferior es Opacidad en Brocha y Fortaleza en Especial.
    // Ambos valores se mantienen independientes al cambiar de herramienta.
    private int previousControlMode = -100;

    private ActivityResultLauncher<String> openImage;
    private ActivityResultLauncher<String> addImage;
    private ActivityResultLauncher<String> createZip;
    private ActivityResultLauncher<String> createPng;
    private ActivityResultLauncher<Uri> pickFolder;
    private ActivityResultLauncher<String> createProject;
    private ActivityResultLauncher<String[]> openProject;
    private ActivityResultLauncher<String[]> pickColorRef;

    private interface ColorPickTarget {
        void onColor(int color);
    }

    private String projectId;
    private String lastError;
    private int lastExportCount;
    private int outW, outH;
    private int edgeClean = 2;
    private boolean saving = false;
    private volatile boolean recoveredBackup = false;
    private boolean destroyed = false;
    private boolean showAdvanced = false;
    private Layer pendingLayerExport;
    private ProjectIO.Loaded loaded;
    private int[] tintNext;
    private Runnable hideDemo;
    private Bitmap colorRefBitmap;
    private ColorPickTarget pendingColorRefTarget;
    private PopupWindow colorRefWindow;
    private ReferenceImageView colorRefView;
    private int colorRefX = 18, colorRefY = 90;
    private int colorRefW = 330, colorRefH = 390;
    private final android.os.Handler previewHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    @Override
    protected void onCreate(@Nullable Bundle b) {
        PzSystem.init(this);   // v8.62: nivel del celular y registro de errores
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        PzSystem.edgeToEdge(this);   // v8.62: Android 15/16 (nada queda debajo de las barras)
        android.content.SharedPreferences refPrefs = getSharedPreferences("pz", MODE_PRIVATE);
        colorRefX = refPrefs.getInt("ref_x", 18);
        colorRefY = refPrefs.getInt("ref_y", 90);
        colorRefW = refPrefs.getInt("ref_w", 330);
        colorRefH = refPrefs.getInt("ref_h", 390);
        canvas = findViewById(R.id.canvas);
        sliderLabel = findViewById(R.id.sliderLabel);
        slider = findViewById(R.id.slider);
        canvas.setCallback(this);

        openImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        picking = false;
                        if (uri != null) loadImage(uri);
                        else if (canvas.getProject() == null && loadGen == 0) finish();
                    }
                });
        addImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) {
                            // v8.74: si Android cerro la app mientras elegias, la obra aun se esta
                            // abriendo: la imagen se agrega apenas termine (antes se perdia)
                            if (canvas.getProject() == null || projectLoading) {
                                pendingAddUri = uri;
                                pendingAddBelow = pendingImageBelow;
                            } else addImageLayer(uri, pendingImageBelow);
                        }
                        pendingImageBelow = false;
                    }
                });
        createZip = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/zip"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportZip(uri);
                    }
                });
        pickFolder = registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportFolder(uri);
                    }
                });
        createPng = registerForActivityResult(new ActivityResultContracts.CreateDocument("image/png"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri == null) { pendingFlatExport = false; return; }
                        if (pendingFlatExport) { pendingFlatExport = false; doExportFlat(uri); }
                        else doExportLayer(uri);
                    }
                });
        createProject = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) saveProjectTo(uri);
                    }
                });
        openProject = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) openProjectFrom(uri);
                    }
                });

        pickColorRef = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri == null) {
                            pendingColorRefTarget = null;
                            return;
                        }
                        Bitmap bmp = decodeReference(uri);
                        if (bmp == null) return;
                        if (colorRefBitmap != null && colorRefBitmap != bmp && !colorRefBitmap.isRecycled()) {
                            colorRefBitmap.recycle();
                        }
                        colorRefBitmap = bmp;
                        toast("Referencia de color cargada");
                        // v8.26: si se eligio guardarla con la obra, se guarda una copia reducida
                        if (keepRefInProject() && canvas.getProject() != null) {
                            canvas.getProject().refImagePng = compactReferencePng(bmp);
                            markDirty();
                        }
                        if (pendingColorRefTarget != null) {
                            showReferenceColorPanel(pendingColorRefTarget);
                            pendingColorRefTarget = null;
                        }
                    }
                });

        // v8.55: los toques rapidos se juntan (ver queueUndo)
        click(R.id.btnUndo, new Runnable() {
            public void run() { queueUndo(1); }
        });
        click(R.id.btnRedo, new Runnable() {
            public void run() { queueUndo(-1); }
        });
        click(R.id.btnSelMenu, new Runnable() {
            public void run() {
                selectionMenu();
            }
        });
        click(R.id.btnMenu, new Runnable() {
            public void run() {
                mainMenu();
            }
        });
        // v8.78: estabilizador y puntas
        click(R.id.btnStab, new Runnable() {
            public void run() {
                showStabPanel();
            }
        });
        findViewById(R.id.btnStab).setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                toast("Estabilizador y puntas finas");
                return true;
            }
        });
        loadStabPrefs();
        // v8.79: figuras
        click(R.id.btnShapes, new Runnable() {
            public void run() {
                showShapePicker(findViewById(R.id.btnShapes));
            }
        });
        findViewById(R.id.btnShapes).setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                toast("Figuras: linea, rectangulo, circulo, flecha, bocadillo...");
                return true;
            }
        });
        loadShapePrefs();
        loadMarkPrefs();
        // v8.53: girar el lienzo a la vista, como Ibis: toque = 90 grados, mantener = derecho
        click(R.id.btnRotate, new Runnable() {
            public void run() {
                if (needProject()) canvas.rotateView90();
            }
        });
        click(R.id.btnTools, new Runnable() {
            public void run() {
                toolGrid();
            }
        });
        click(R.id.btnSize, new Runnable() {
            public void run() {
                brushPresets();
            }
        });
        click(R.id.btnColor, new Runnable() {
            public void run() {
                colorDialog();
            }
        });
        click(R.id.btnLayers, new Runnable() {
            public void run() {
                toggleLayersPanel();
            }
        });
        click(R.id.btnLayersClose, new Runnable() {
            public void run() {
                closeLayers();
            }
        });
        click(R.id.btnExport, new Runnable() {
            public void run() {
                exportDialog();
            }
        });
        click(R.id.btnAddMode, new Runnable() {
            public void run() {
                canvas.setSubtract(false);
                updateUi();
            }
        });
        click(R.id.btnSubMode, new Runnable() {
            public void run() {
                canvas.setSubtract(true);
                updateUi();
            }
        });
        click(R.id.btnSmart, new Runnable() {
            public void run() {
                canvas.setSmart(!canvas.isSmart());
                canvas.showHud(canvas.isSmart() ? "Fino: SI (se queda en el color que tocas)" : "Fino: NO");
                updateUi();
            }
        });
        click(R.id.btnLineart, new Runnable() {
            public void run() {
                lineArtDialog();
            }
        });
        click(R.id.btnSizeMinus, new Runnable() {
            public void run() {
                slider.setProgress(Math.max(0, slider.getProgress() - 1));
            }
        });
        click(R.id.btnSizePlus, new Runnable() {
            public void run() {
                slider.setProgress(Math.min(slider.getMax(), slider.getProgress() + 1));
            }
        });
        final SeekBar op = findViewById(R.id.opacity);
        click(R.id.btnOpMinus, new Runnable() {
            public void run() {
                if (bgFeatherSlider()) {
                    op.setProgress(Math.max(0, op.getProgress() - 25));
                    return;
                }
                op.setProgress(Math.max(2, op.getProgress() - 5));
            }
        });
        click(R.id.btnOpPlus, new Runnable() {
            public void run() {
                if (bgFeatherSlider()) {
                    op.setProgress(Math.min(100, op.getProgress() + 25));
                    canvas.featherWholeLayer();
                    return;
                }
                op.setProgress(Math.min(100, op.getProgress() + 5));
            }
        });
        op.setOnSeekBarChangeListener(new SimpleSeek() {
            private float featherAtTouch;

            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (canvas.getMode() == CanvasView.MODE_BGERASE && canvas.getBgSub() == CanvasView.BG_SUB_ERASER) {
                    // v8.32: con el Borrador manual esta barra es su FUERZA
                    v = Math.max(2, v);
                    canvas.setBgEraserStrength(v / 100f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText("Fuerza " + v + "%");
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_er_strength", v).apply();
                } else if (canvas.getMode() == CanvasView.MODE_BGERASE) {
                    // v8.30: en Borrar fondo esta barra es la SUAVIDAD del borde (0 a 4 px)
                    canvas.setBgFeather(v / 25f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText(featherLabel(v));
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_feather", v).apply();
                } else if (canvas.getMode() == CanvasView.MODE_LIQUIFY) {
                    v = Math.max(5, v);
                    canvas.setEffectStrength(v / 100f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText("Fuerza " + v + "%");
                } else {
                    v = Math.max(2, v);
                    canvas.setBrushOpacity(v / 100f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText(String.valueOf(v));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                featherAtTouch = canvas.getBgFeather();
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                // mas suave: se aplica tambien a lo que ya estaba recortado (se deshace con un toque)
                if (bgFeatherSlider() && canvas.getBgFeather() > featherAtTouch + 0.05f)
                    canvas.featherWholeLayer();
            }
        });
        slider.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                applySlider(v);
                // v8.93: moviendo la barra con el dedo cambia el grosor de la flecha o el numero elegido
                if (u && !sliderIsTolerance()) canvas.markSizeFromBar();
            }
        });
        installTooltips();

        canvas.setBrushSize(20f);
        canvas.setSmoothZoom(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("smooth_zoom", true));
        // v8.76: -1 = todavia no se uso un lapiz; 1 = solo el lapiz pinta; 0 = el dedo tambien pinta
        canvas.setStylusOnly(getSharedPreferences("pz", MODE_PRIVATE).getInt("solo_lapiz", -1) == 1);
        canvas.setPenPressure(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("presion_lapiz", true));
        canvas.setRotateEnabled(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("rotate_view", true));
        {
            // v8.29: Borrar fondo nuevo (simple). Una vez se vuelven los ajustes a los de fabrica:
            // una dilatacion o tolerancia cambiadas a escondidas dejaban sobras que no se podian quitar.
            android.content.SharedPreferences sp0 = getSharedPreferences("pz", MODE_PRIVATE);
            if (!sp0.getBoolean("bg_reset_v829", false)) {
                sp0.edit().putBoolean("bg_reset_v829", true).putBoolean("bg_exp_on", false).putInt("bg_tol", 46)
                        .putInt("bg_soft", 42).putBoolean("bg_once", false).putInt("bg_limit", 0)
                        .putBoolean("bg_decontam", true).apply();
            }
            // v8.31: otra vez de fabrica (en el telefono estaban en 55/78 y el pincel cruzaba la linea);
            // el icono de Ajustes ya no esta en la barra
            // v8.32: motor nuevo; Disperso y Dilatacion ya no existen en Borrar fondo
            if (!sp0.getBoolean("bg_reset_v832", false)) {
                sp0.edit().putBoolean("bg_reset_v832", true).putInt("bg_limit", 0).putInt("bg_gap", 100).apply();
            }
            if (!sp0.getBoolean("bg_reset_v831", false)) {
                sp0.edit().putBoolean("bg_reset_v831", true).putBoolean("bg_exp_on", false).putInt("bg_tol", 46)
                        .putInt("bg_soft", 42).putBoolean("bg_once", false).putInt("bg_limit", 0)
                        .putBoolean("bg_decontam", true).apply();
            }
        }
        bgExpOn = getSharedPreferences("pz", MODE_PRIVATE).getBoolean("bg_exp_on", false);
        bgExpAmt = getSharedPreferences("pz", MODE_PRIVATE).getInt("bg_exp_amt", 2);
        canvas.setBgExpansion(bgExpOn ? bgExpAmt : 0f);
        {
            android.content.SharedPreferences bsp = getSharedPreferences("pz", MODE_PRIVATE);
            canvas.setBgTolerance(bsp.getInt("bg_tol", 46));
            canvas.setBgSoftness(bsp.getInt("bg_soft", 42));
            canvas.setBgDecontam(bsp.getBoolean("bg_decontam", true));
            canvas.setBgOnce(bsp.getBoolean("bg_once", false));
            // v8.32: el Borrador manual vuelve a la barra de Borrar fondo (con su propia fuerza y dureza)
            canvas.setBgSub(bsp.getInt("bg_sub", CanvasView.BG_SUB_TAP));
            canvas.setBgEraserStrength(bsp.getInt("bg_er_strength", 100) / 100f);
            canvas.setBgEraserHard(bsp.getInt("bg_er_hard", 85) / 100f);
            canvas.setBgGapScale(bsp.getInt("bg_gap", 100) / 100f);
            canvas.setSuggestMultiply(bsp.getBoolean("suggest_multiply", true));
            canvas.setBgLimit(bsp.getInt("bg_limit", 0));
            canvas.setBgFeather(bsp.getInt("bg_feather", 0) / 25f);
        }
        loadFillPrefs();
        loadPuppetPrefs();
        loadMangaPrefs();
        {
            // v8.27: el pincel elegido Y su dureza se guardan. Antes la dureza no se guardaba:
            // al volver a abrir la app quedaba en 0,7 (borde borroso) aunque el pincel fuera otro.
            android.content.SharedPreferences bsp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean firstTime = !bsp.contains("brush_preset4") && !bsp.contains("brush_preset3");
            int bi;
            if (bsp.contains("brush_preset4")) bi = bsp.getInt("brush_preset4", 0);
            else bi = com.pacco.animecut.core.BrushPreset.migrateV826(bsp.getInt("brush_preset3", 0));
            if (bi < 0 || bi >= com.pacco.animecut.core.BrushPreset.PRESETS.length) bi = 0;
            com.pacco.animecut.core.BrushPreset bp = com.pacco.animecut.core.BrushPreset.PRESETS[bi];
            applyBrushPreset(bi, false);
            canvas.setHardness(bsp.getFloat("brush_hardness_v827", bp.hardness));
            if (firstTime) canvas.setBrushSize(bp.size);
            bsp.edit().putInt("brush_preset4", bi).putFloat("brush_hardness_v827", canvas.getHardness()).apply();
        }
        canvas.setFlatPaint(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("flat_paint", true));
        canvas.setLineStop(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("line_stop", false));
        canvas.setAutoLines(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("auto_lines", true));
        canvas.setToLine(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("to_line", true));
        canvas.setFillUnpainted(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("fill_unpainted", false));
        // boton de ajustes de la varita, junto a los de la barra de seleccion
        ImageButton gear = new ImageButton(this);
        gear.setImageResource(R.drawable.ic_menu);
        gear.setBackgroundResource(R.drawable.bg_tool);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER);
        gear.setPadding(dp(9), dp(9), dp(9), dp(9));
        gear.setContentDescription("Ajustes de la varita");
        gear.setId(View.generateViewId());
        wandGear = gear;
        ((ViewGroup) findViewById(R.id.btnLineart).getParent()).addView(gear,
                new LinearLayout.LayoutParams(dp(44), dp(40)));
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wandDialog();
            }
        });
        Task.setErrorListener(new Task.ErrorListener() {
            @Override
            public void onError(Throwable t) {
                if (destroyed) return;
                if (t instanceof OutOfMemoryError) {
                    toast("No alcanzo la memoria para eso. Combina o borra alguna capa y prueba otra vez.");
                }
            }
        });
        syncSlider();
        updateUi();
        measureBars();
        installBack();

        saveHandler.postDelayed(savePeriodic, 30000);
        projectId = getIntent().getStringExtra(EXTRA_PROJECT);
        // v8.74: si Android cerro y volvio a abrir esta pantalla (poca memoria mientras elegias
        // una imagen, por ejemplo), se vuelve a abrir LA MISMA obra (antes pedia otra imagen)
        if (b != null) {
            String saved = b.getString(STATE_PROJECT);
            if (saved != null) projectId = saved;
            picking = b.getBoolean(STATE_PICKING, false);
            pendingImageBelow = b.getBoolean(STATE_BELOW, false);
        }
        File pf = projectId == null ? null : ProjectStore.fileFor(this, projectId);
        if (pf != null && (pf.exists() || new File(pf.getAbsolutePath() + ".bak").exists())) {
            // la obra aparece de una vez ya ajustada, sin salto de zoom
            canvas.setAlpha(0f);
            recoverFrom(pf);
        } else if (b != null && picking) {
            // el selector de imagenes sigue abierto: su resultado llega solo
            projectId = null;
        } else {
            projectId = null;
            picking = true;
            openImage.launch("image/*");
        }
    }

    private static final String STATE_PROJECT = "pz_project", STATE_PICKING = "pz_picking", STATE_BELOW = "pz_below";
    /** v8.74: el selector de la primera imagen esta abierto. */
    private boolean picking;
    /** v8.74: una imagen para agregar como capa que llego antes de que la obra terminara de abrir. */
    private Uri pendingAddUri;
    private boolean pendingAddBelow;
    /** v8.74: cada apertura (obra guardada o imagen nueva) tiene su numero; gana la ultima. */
    private int loadGen;
    private boolean projectLoading;

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        // la obra todavia sin guardar recibe su nombre ya, asi se encuentra al volver
        if (projectId == null && canvas != null && canvas.getProject() != null) projectId = ProjectStore.newId();
        if (projectId != null) out.putString(STATE_PROJECT, projectId);
        out.putBoolean(STATE_PICKING, picking);
        out.putBoolean(STATE_BELOW, pendingImageBelow);
    }

    /**
     * v8.74: girar, modo oscuro, pantalla dividida, plegables, teclado o lapiz conectado: la
     * pantalla ya NO se vuelve a crear (antes se recargaba la obra y se perdia el Deshacer).
     * Solo se vuelve a medir el espacio de las barras.
     */
    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        measureBars(false);
    }

    /** Agrega la imagen que llego mientras la obra se abria. */
    private void applyPendingAdd() {
        if (pendingAddUri == null || canvas.getProject() == null) return;
        Uri u = pendingAddUri;
        boolean below = pendingAddBelow;
        pendingAddUri = null;
        pendingAddBelow = false;
        addImageLayer(u, below);
    }

    /** v8.73: la app esta en segundo plano (o saliendo): guardar enseguida, sin esperar. */
    private boolean paused;

    @Override
    protected void onResume() {
        super.onResume();
        paused = false;
    }

    @Override
    protected void onPause() {
        super.onPause();
        paused = true;
        // v8.73: con Transformar abierto (por ejemplo una imagen recien agregada) la parte movida
        // no esta en la capa: se aplica sola y, al terminar, se guarda (ver markDirty)
        if (canvas != null && canvas.isTransformActive()) {
            try { canvas.settleTransformForSave(); } catch (Throwable ignored) { }
        }
        // al salir con Atras la obra ya se guardo: no se guarda dos veces
        if (!leaving || dirty) autosave(false);
    }

    // ==================================================================
    // v8.73 Boton / gesto ATRAS (antes cerraba la obra de golpe, aunque hubiera un panel abierto,
    // y con navegacion por gestos un trazo desde el borde la cerraba).
    // Orden: 1) cierra la ventana o panel abierto, 2) con Transformar abierto lo aplica (como
    // Listo), 3) para salir hay que tocar Atras dos veces, y se sale cuando la obra ya se guardo.
    // ==================================================================

    private long backArmedAt;
    private boolean leaving;

    private void installBack() {
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    onBackKey();
                } catch (Throwable t) {
                    // nunca dejar Atras sin respuesta: se sale guardando
                    if (!leaving) leaveSaving();
                }
            }
        });
    }

    private void onBackKey() {
        if (leaving) return;
        if (canvas == null || canvas.getProject() == null) { finish(); return; }
        // v8.99: Atras con la pantalla de escribir abierta = listo (el texto queda)
        if (typeScreenShown()) { stopTyping(false); updateUi(); return; }
        // 1) ventanas flotantes y paneles
        if (modePop != null && modePop.isShowing()) { modePop.dismiss(); return; }
        if (stabPop != null && stabPop.isShowing()) { stabPop.dismiss(); return; }
        if (shapePop != null && shapePop.isShowing()) { shapePop.dismiss(); return; }
        if (shapeStylePop != null && shapeStylePop.isShowing()) { shapeStylePop.dismiss(); return; }
        if (imgPop != null && imgPop.isShowing()) { imgPop.dismiss(); return; }
        if (imagePop != null && imagePop.isShowing()) {
            // igual que "Listo" en la barra de la imagen
            if (canvas.isTransformActive() && !canvas.isBusy()) canvas.applyTransform();
            imagePop.dismiss();
            afterLayerOp();
            return;
        }
        if (grayPop != null && grayPop.isShowing()) { closeGrayPop(); return; }
        if (bwPop != null && bwPop.isShowing()) { if (bwCancel != null) bwCancel.run(); return; }
        if (findViewById(R.id.toolPanel).getVisibility() == View.VISIBLE) { closeTools(); updateUi(); return; }
        if (layersOpen()) { closeLayers(); return; }
        if (fxKind != 0 || fxCard != null) { fxClose(); updateUi(); return; }
        if (softCard != null) { softClose(); updateUi(); return; }
        if (easyCard != null) { hideEasyCard(); updateUi(); return; }
        // 2) Transformar abierto: se aplica (Deshacer lo quita)
        if (canvas.isTransformActive()) {
            if (canvas.isBusy()) { canvas.showHud("Espera un momento...", 1200); return; }
            canvas.applyTransform();
            return;
        }
        // v8.94: editor de texto abierto: listo con ese texto. Recortar: se cancela
        if (canvas.getMode() == CanvasView.MODE_MARK && canvas.isMarkTextDraft()) {
            stopTyping(false);
            canvas.markTextDone();
            updateUi();
            return;
        }
        if (canvas.getMode() == CanvasView.MODE_CROP) {
            canvas.resetCropBox();
            selectTool(cropReturnMode);
            return;
        }
        // v8.95: Atras en Marcar: pinta las marcas (si hay) y vuelve a la herramienta de antes
        if (canvas.getMode() == CanvasView.MODE_MARK) {
            if (canvas.hasMarkDraft()) canvas.applyMarkDrafts();
            selectTool(markReturnMode);
            return;
        }
        // v8.79: una figura sin pintar se pinta (igual que Transformar; Deshacer la quita)
        if (canvas.getMode() == CanvasView.MODE_SHAPE && canvas.hasShapeDraft()) {
            if (canvas.applyShapeDraft()) canvas.showHud("Figura lista. Deshacer la quita", 1600);
            return;
        }
        // 3) salir: dos toques seguidos (un roce del borde ya no cierra la obra)
        long now = android.os.SystemClock.uptimeMillis();
        if (now - backArmedAt > 2500) {
            backArmedAt = now;
            canvas.showHud("Toca Atras otra vez para salir (tu obra se guarda sola)", 2200);
            return;
        }
        leaveSaving();
    }

    /** Guarda y recien entonces cierra la obra (asi la galeria ya muestra lo ultimo). */
    private void leaveSaving() {
        leaving = true;
        if (canvas == null || canvas.getProject() == null) { finish(); return; }
        canvas.showHud("Guardando tu obra...", 10000);
        if (canvas.isTransformActive()) {
            try { canvas.settleTransformForSave(); } catch (Throwable ignored) { }
        }
        final long t0 = android.os.SystemClock.uptimeMillis();
        saveHandler.post(new Runnable() {
            private boolean started;

            @Override
            public void run() {
                if (destroyed) return;
                long waited = android.os.SystemClock.uptimeMillis() - t0;
                // primero que termine lo que se este aplicando (Transformar, un filtro...)
                if (!started && (canvas.isTransformActive() || canvas.isBusy()) && waited < 10000) {
                    saveHandler.postDelayed(this, 100);
                    return;
                }
                if (!started) {
                    started = true;
                    lastError = null;
                    if (dirty || saving) autosave(false);
                }
                if (saving && waited < 30000) {
                    saveHandler.postDelayed(this, 100);
                    return;
                }
                // dirty = quedo algo sin guardar (fallo, o Transformar no se pudo cerrar)
                if (lastError != null || saving || dirty) {
                    askLeaveAnyway(lastError);
                    return;
                }
                finish();
            }
        });
    }

    private void askLeaveAnyway(String err) {
        canvas.showHud("", 0);
        new SheetBuilder(this)
                .setTitle("No se pudo guardar")
                .setMessage("Tu obra no se pudo guardar" + (err != null && !err.equals("null") ? " (" + err + ")" : "")
                        + ". Puede faltar espacio en el telefono.\n\nSi sales ahora puedes perder lo ultimo que hiciste. "
                        + "Libera espacio o exporta tu obra antes de salir.")
                .setCancelable(false)
                .setPositiveButton("Quedarme", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        leaving = false;
                        backArmedAt = 0;
                        markDirty();
                    }
                })
                .setNegativeButton("Salir igual", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        finish();
                    }
                })
                .show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (dirty) autosave(false);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        closeGrayPop();
        // v8.73: las ventanas flotantes se cierran con la obra (antes quedaban "colgadas")
        try { if (imagePop != null && imagePop.isShowing()) imagePop.dismiss(); } catch (Throwable ignored) {}
        try { if (modePop != null && modePop.isShowing()) modePop.dismiss(); } catch (Throwable ignored) {}
        try { if (stabPop != null && stabPop.isShowing()) stabPop.dismiss(); } catch (Throwable ignored) {}
        try { if (shapePop != null && shapePop.isShowing()) shapePop.dismiss(); } catch (Throwable ignored) {}
        try { if (bwPop != null && bwPop.isShowing()) bwPop.dismiss(); } catch (Throwable ignored) {}
        try { if (shapeStylePop != null && shapeStylePop.isShowing()) shapeStylePop.dismiss(); } catch (Throwable ignored) {}
        try { if (imgPop != null && imgPop.isShowing()) imgPop.dismiss(); } catch (Throwable ignored) {}
        saveHandler.removeCallbacksAndMessages(null);
        previewHandler.removeCallbacksAndMessages(null);
        opHandler.removeCallbacksAndMessages(null);
        Task.setErrorListener(null);
        try { thumbPool.shutdownNow(); } catch (Throwable ignored) {}
        // v8.60: los hilos de la vista previa no quedan vivos al cerrar la obra
        try { fxExec.shutdownNow(); } catch (Throwable ignored) {}
        try { finExec.shutdownNow(); } catch (Throwable ignored) {}
        for (Bitmap b : new ArrayList<Bitmap>(thumbCache.values()))
            if (b != null && !b.isRecycled()) b.recycle();
        thumbCache.clear();
        if (colorRefWindow != null) {
            try { colorRefWindow.dismiss(); } catch (Throwable ignored) {}
            colorRefWindow = null; colorRefView = null;
        }
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) {
            colorRefBitmap.recycle();
            colorRefBitmap = null;
        }
        rowHolders.clear();
        if (canvas != null) {
            canvas.setCallback(null);
            canvas.releaseUiResources();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // Guardado automatico: poco despues de cada cambio y cada 30 segundos.
    // Asi, si la app se cierra de golpe, se pierde muy poco.
    // ------------------------------------------------------------------

    private boolean dirty = false, saveAgain = false;
    private final android.os.Handler saveHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable saveSoon = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            // v8.49: no guardar mientras pintas (v8.73: en segundo plano no se pinta: guardar ya)
            if (!paused && touchingNow()) { saveHandler.postDelayed(this, 2000); return; }
            if (dirty) autosave(false);
        }
    };

    /**
     * v8.49: el dedo esta en el lienzo o lo solto hace poco. v8.53: 5 s (como recomiendan las apps de
     * pintura: guardar solo con el lienzo quieto), y 8 s en Borrar fondo, que se usa con pausas cortas.
     */
    private boolean touchingNow() {
        if (canvas == null) return false;
        long idle = canvas.getMode() == CanvasView.MODE_BGERASE ? 8000 : 5000;
        return android.os.SystemClock.uptimeMillis() - canvas.lastTouchMs < idle;
    }

    private final Runnable savePeriodic = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            if (dirty && touchingNow()) { saveHandler.removeCallbacks(saveSoon); saveHandler.postDelayed(saveSoon, 2000); }
            else if (dirty) autosave(false);
            if (!destroyed) saveHandler.postDelayed(this, 30000);
        }
    };

    // v8.74: antes el guardado automatico podia fallar en silencio (por ejemplo, telefono sin
    // espacio) y uno seguia trabajando sin saber que nada se guardaba.
    private int saveFails;
    private boolean saveWarned;

    private void noteSaveResult(String err) {
        if (destroyed) return;
        if (err == null) {
            if (saveWarned) canvas.showHud("Tu obra se volvio a guardar bien", 2400);
            saveFails = 0;
            saveWarned = false;
            return;
        }
        saveFails++;
        if (saveFails < 2 || saveWarned || leaving) return;   // un fallo suelto se reintenta solo
        saveWarned = true;
        new SheetBuilder(this)
                .setTitle("No se esta guardando tu obra")
                .setMessage("El guardado automatico fallo" + (err.equals("null") ? "" : " (" + err + ")")
                        + ". Lo mas comun es que falte espacio en el telefono.\n\n"
                        + "Libera espacio: la app lo vuelve a intentar sola cada 30 segundos. "
                        + "Mientras tanto puedes guardar una copia en un archivo.")
                .setPositiveButton("Entendido", null)
                .setNeutralButton("Guardar copia", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { runMenu("Guardar copia en un archivo"); }
                })
                .show();
    }

    private void markDirty() {
        dirty = true;
        saveHandler.removeCallbacks(saveSoon);
        // v8.73: si la app ya esta en segundo plano (Transformar se termino de aplicar al salir),
        // se guarda casi enseguida: Android puede cerrarla en cualquier momento
        saveHandler.postDelayed(saveSoon, paused ? 250 : 5000);
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    private void installTooltips() {
        findViewById(R.id.btnRotate).setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (canvas.getProject() != null) canvas.resetView();
                return true;
            }
        });
        int[] ids = {R.id.btnUndo, R.id.btnRedo, R.id.btnSelMenu, R.id.btnMenu, R.id.btnTools, R.id.btnSize,
                R.id.btnColor, R.id.btnLayers, R.id.btnExport, R.id.btnAddMode, R.id.btnSubMode, R.id.btnSmart,
                R.id.btnLineart};
        String[] names = {"Deshacer (o toca con dos dedos)", "Rehacer (o toca con tres dedos)",
                "Seleccion: acciones con lo azul", "Mas opciones", "Herramientas", "Tipo de pincel",
                "Color", "Capas", "Exportar", "Agregar a lo azul", "Quitar de lo azul",
                "Fino: se queda en el color que tocas", "Line art: la linea hace de pared"};
        for (int i = 0; i < ids.length; i++) {
            final String n = names[i];
            findViewById(ids[i]).setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    toast(n);
                    return true;
                }
            });
        }
    }

    // ==================================================================
    // Abrir, agregar imagen, guardar
    // ==================================================================

    /**
     * Ya no hay un limite artificial de 4096 px. El tamano de apertura se decide
     * con la memoria real disponible del dispositivo para no cerrar Android.
     */
    private long safeOpenPixels() {
        long heap = Runtime.getRuntime().maxMemory();
        // Abrir una obra necesita temporalmente Bitmap + int[] de la capa + buffers.
        // v8.62: segun el nivel del celular (antes: minimo 8 MP aunque la memoria no alcanzara;
        // en gama baja eso podia cerrar la app)
        return com.pacco.animecut.core.DeviceTier.maxOpenPixels(heap);
    }

    /** Abre la imagen en el hilo actual (los avisos se muestran en pantalla). */
    private Bitmap decode(Uri uri) {
        String[] note = new String[1];
        Bitmap bmp = decodeBg(uri, note);
        if (note[0] != null) toast(note[0]);
        return bmp;
    }

    /**
     * Lee la imagen sin tocar la pantalla (sirve en segundo plano). note[0] = aviso para mostrar.
     * v8.74: respeta la orientacion de la foto (EXIF). Antes las fotos de camara podian entrar
     * acostadas o de cabeza.
     */
    private Bitmap decodeBg(Uri uri, String[] note) {
        try {
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            InputStream is0 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is0, null, b);
            if (is0 != null) is0.close();
            int ow = b.outWidth, oh = b.outHeight;
            if (ow <= 0 || oh <= 0) {
                note[0] = "No se pudo leer el tamano de la imagen";
                return null;
            }

            long safePixels = safeOpenPixels();
            int sample = 1;
            while ((long) Math.max(1, ow / sample) * Math.max(1, oh / sample) > safePixels * 2L) {
                sample *= 2;
            }

            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            if (bmp == null) {
                note[0] = "No se pudo abrir la imagen";
                return null;
            }

            long got = (long) bmp.getWidth() * bmp.getHeight();
            if (got > safePixels) {
                float f = (float) Math.sqrt(safePixels / (double) got);
                int tw = Math.max(1, Math.round(bmp.getWidth() * f));
                int th = Math.max(1, Math.round(bmp.getHeight() * f));
                Bitmap sc = Bitmap.createScaledBitmap(bmp, tw, th, true);
                if (sc != bmp) bmp.recycle();
                bmp = sc;
            }
            boolean resized = bmp.getWidth() != ow || bmp.getHeight() != oh;
            int orient = exifOrientation(uri);
            if (orient > 1 && orient <= 8) {
                try {
                    bmp = applyExif(bmp, orient);
                    if (orient >= 5) { int t = ow; ow = oh; oh = t; }   // de lado: ancho y alto cambian
                } catch (OutOfMemoryError e) {
                    note[0] = "La foto se abrio sin girar (falto memoria para girarla)";
                }
            }
            if (resized && note[0] == null) {
                note[0] = "La imagen " + ow + "x" + oh + " se ajusto a " + bmp.getWidth() + "x"
                        + bmp.getHeight() + " segun la memoria disponible del telefono";
            }
            return bmp;
        } catch (OutOfMemoryError e) {
            note[0] = "Android se quedo sin memoria al abrir esa imagen";
        } catch (Exception e) {
            note[0] = "No se pudo abrir: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
        return null;
    }

    /** Orientacion guardada por la camara (1 = normal). */
    private int exifOrientation(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return 1;
            android.media.ExifInterface ex = new android.media.ExifInterface(in);
            return ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,
                    android.media.ExifInterface.ORIENTATION_NORMAL);
        } catch (Throwable t) {
            return 1;   // PNG, WebP sin datos, etc.: normal
        }
    }

    /** Gira / voltea la foto como indica su orientacion (la misma tabla que usan las galerias). */
    static Bitmap applyExif(Bitmap b, int orientation) {
        android.graphics.Matrix m = new android.graphics.Matrix();
        switch (orientation) {
            case 2: m.setScale(-1f, 1f); break;                     // espejo horizontal
            case 3: m.setRotate(180f); break;
            case 4: m.setScale(1f, -1f); break;                     // espejo vertical
            case 5: m.setRotate(90f); m.postScale(-1f, 1f); break;  // transpuesta
            case 6: m.setRotate(90f); break;
            case 7: m.setRotate(-90f); m.postScale(-1f, 1f); break; // transversa
            case 8: m.setRotate(-90f); break;
            default: return b;
        }
        Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, false);
        if (r != b) b.recycle();
        return r;
    }

    /**
     * v8.74: abrir una imagen ya no congela la pantalla: se lee en segundo plano con el aviso
     * "Abriendo imagen..." (antes, en telefonos lentos, Android podia mostrar "la app no responde").
     */
    private void loadImage(final Uri uri) {
        final int gen = ++loadGen;
        projectLoading = true;
        showLoading("Abriendo imagen...");
        onBusy(true);
        final String[] note = new String[1];
        final Project[] made = new Project[1];
        Task.run(new Runnable() {
            @Override
            public void run() {
                Bitmap bmp = decodeBg(uri, note);
                if (bmp == null) return;
                try {
                    made[0] = new Project(bmp);
                } catch (OutOfMemoryError e) {
                    note[0] = "Android se quedo sin memoria al abrir esa imagen";
                } finally {
                    bmp.recycle();
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                if (destroyed) return;
                onBusy(false);
                hideLoading();
                if (gen != loadGen) return;          // se abrio otra cosa despues
                projectLoading = false;
                if (note[0] != null) toast(note[0]);
                if (made[0] == null) return;
                projectId = null;
                canvas.setProject(made[0]);
                canvas.setAlpha(1f);
                afterProjectLoaded();
                markDirty();
                toast("Imagen abierta en la capa \"imagen\"");
                // v8.83: primero la pregunta de las lineas; el tutorial sale despues (no uno encima de otro)
                maybeAskExtractLines();
                applyPendingAdd();
            }
        });
    }

    /**
     * v8.57 (idea de Clip Studio): al abrir una imagen que parece manga en blanco y negro sobre
     * papel, pregunta UNA vez si quieres extraer las lineas. No sale con fotos ni con imagenes a
     * color, no bloquea nada y tiene "No volver a preguntar". La herramienta sigue en Filtros.
     */
    private void maybeAskExtractLines() {
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("ask_extract_never", false)) { guideIfFirstTime(); return; }
        Project p = canvas.getProject();
        if (p == null || p.layers.isEmpty()) return;
        // v8.59: pregunta SIEMPRE al abrir una imagen nueva (hasta "No volver a preguntar")
        canvas.postDelayed(new Runnable() {
            @Override public void run() {
                if (destroyed || canvas.getProject() == null) return;
                final boolean[] toFx = {false};
                AlertDialog ask = new SheetBuilder(MainActivity.this)
                        .setTitle("¿Extraer las líneas?")
                        .setMessage("Deja solo las líneas, con el fondo transparente.")
                        .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                toFx[0] = true;
                                // el tutorial espera a que cierres Filtros
                                FxScreen.afterClose = new Runnable() {
                                    @Override public void run() { if (!destroyed) guideIfFirstTime(); }
                                };
                                FxScreen.open(MainActivity.this, canvas, com.pacco.animecut.core.Fx.EXTRACT);
                            }
                        })
                        .setNegativeButton("No", null)
                        .setNeutralButton("No volver a preguntar", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                sp.edit().putBoolean("ask_extract_never", true).apply();
                            }
                        })
                        .create();
                ask.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override public void onDismiss(DialogInterface d) {
                        // "No" o tocar afuera: ahora si el tutorial (solo la primera vez)
                        if (!toFx[0] && !destroyed) guideIfFirstTime();
                    }
                });
                ask.show();
            }
        }, 700);
    }

    /** Blanco y negro (o gris), mucho papel claro y algo de tinta: una pagina de manga. */
    public static boolean looksLikeMangaPage(int[] px) {
        if (com.pacco.animecut.core.LineArt.isColored(px)) return false;
        int step = Math.max(1, px.length / 60000), n = 0, light = 0, dark = 0, transp = 0;
        for (int i = 0; i < px.length; i += step) {
            int c = px[i];
            n++;
            if ((c >>> 24) < 200) { transp++; continue; }
            int l = (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
            if (l > 200) light++;
            else if (l < 90) dark++;
        }
        if (n == 0 || transp * 20 > n) return false;     // ya tiene transparencia: ya esta separado
        return light * 100 >= n * 40 && dark * 100 >= n * 2;
    }

    /** v8.72: la proxima imagen elegida va como fondo (debajo de todo). */
    private boolean pendingImageBelow;

    private void addImageLayer(Uri uri) { addImageLayer(uri, false); }

    private void addImageLayer(final Uri uri, final boolean asBackground) {
        if (!needProject()) return;
        // v8.86: con muchas imagenes grandes Android podia cerrar la app de golpe (sin aviso) y se
        // perdia lo ultimo. Ahora: si queda poca memoria libre en el telefono se avisa y no se
        // agrega; y antes de agregar se guarda la obra (si Android la cierra, no se pierde nada).
        Project cp = canvas.getProject();
        long need = (long) cp.w * cp.h * 4L * 3L;
        long free = availMemBytes();
        if (free < need + (256L << 20)) {
            new SheetBuilder(this)
                    .setTitle("Poca memoria libre")
                    .setMessage("El telefono tiene poca memoria libre para otra imagen grande. Cierra otras apps, "
                            + "o une o borra capas que ya no uses, y vuelve a intentar.")
                    .setPositiveButton("Entendido", null)
                    .show();
            return;
        }
        if (dirty) autosave(false);
        // v8.74: la imagen se lee en segundo plano (la pantalla no se congela)
        canvas.showHud("Abriendo imagen...", 8000);
        final String[] note = new String[1];
        final Bitmap[] got = new Bitmap[1];
        Task.runSide(new Runnable() {   // v8.87: no espera detras del guardado
            @Override public void run() { got[0] = decodeBg(uri, note); }
        }, new Runnable() {
            @Override public void run() {
                if (destroyed) { if (got[0] != null) got[0].recycle(); return; }
                canvas.showHud("", 0);
                if (note[0] != null) toast(note[0]);
                if (got[0] != null) placeImageLayer(got[0], asBackground);
            }
        });
    }

    private void placeImageLayer(Bitmap bmp, boolean asBackground) {
        if (canvas.getProject() == null) { bmp.recycle(); return; }
        canvas.addImageLayer(bmp, asBackground);
        bmp.recycle();
        updateUi();
        Project p = canvas.getProject();
        Layer l = p == null ? null : p.activeLayer();
        // como en Alight: queda elegida con sus cuadritos para moverla y agrandarla, y con su barra
        if (l != null) {
            selectTool(CanvasView.MODE_TRANSFORM);
            imageCard(l);
        }
    }

    private PopupWindow imagePop;

    /**
     * v8.72 Barra de la IMAGEN (como la de Alight Motion al elegir una imagen): sus propias
     * opciones, aparte de las demas herramientas. Mover y transformar, Mezcla y opacidad (con
     * Color de la luz y Enmascarar), Al frente / Al fondo, Eliminar y Listo.
     */
    private void imageCard(final Layer l) {
        if (imagePop != null && imagePop.isShowing()) imagePop.dismiss();
        final Project p = canvas.getProject();
        if (p == null || !p.layers.contains(l)) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(6), dp(8), dp(8));
        android.graphics.drawable.GradientDrawable bgd = new android.graphics.drawable.GradientDrawable();
        bgd.setColor(0xF2232328);
        bgd.setCornerRadius(dp(12));
        box.setBackground(bgd);
        TextView ttl = new TextView(this);
        ttl.setText("Imagen: " + l.name + "  ·  " + Layer.MODE_NAMES[l.mode] + " " + Math.round(l.opacity * 100f / 255f) + "%");
        ttl.setTextColor(0xFFFFFFFF);
        ttl.setTextSize(13f);
        ttl.setSingleLine(true);
        ttl.setPadding(dp(4), dp(2), dp(4), dp(6));
        box.addView(ttl);
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        box.addView(r1);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp2.setMargins(0, dp(6), 0, 0);
        box.addView(r2, lp2);
        r1.addView(chooserCell(R.drawable.ic_transform, "Mover y\ntransformar", 0, new Runnable() {
            public void run() {
                if (!p.layers.contains(l)) return;
                canvas.setActive(p.layers.indexOf(l));
                selectTool(CanvasView.MODE_TRANSFORM);
            }
        }));
        r1.addView(chooserCell(R.drawable.ic_blend, "Mezcla y\nopacidad", 0, new Runnable() {
            public void run() {
                if (!p.layers.contains(l)) return;
                if (canvas.isTransformActive()) canvas.applyTransform();   // lo movido queda puesto
                imagePop.dismiss();
                modeWheel(l);
            }
        }));
        r1.addView(chooserCell(R.drawable.ic_up, "Al frente", 0, new Runnable() {
            public void run() {
                if (!p.layers.contains(l)) return;
                if (canvas.isTransformActive()) canvas.applyTransform();
                int i = p.layers.indexOf(l);
                if (i < p.layers.size() - 1) canvas.moveLayer(i, p.layers.size() - 1);
                canvas.showHud("Imagen al frente (encima de todo)", 1600);
                afterLayerOp();
            }
        }));
        r2.addView(chooserCell(R.drawable.ic_down, "Al fondo", 0, new Runnable() {
            public void run() {
                if (!p.layers.contains(l)) return;
                if (canvas.isTransformActive()) canvas.applyTransform();
                int i = p.layers.indexOf(l);
                if (i > 0) canvas.moveLayer(i, 0);
                canvas.showHud("Imagen al fondo (detras de todo)", 1600);
                afterLayerOp();
            }
        }));
        r2.addView(chooserCell(R.drawable.ic_trash, "Eliminar", 0, new Runnable() {
            public void run() {
                if (!p.layers.contains(l)) return;
                if (canvas.isTransformActive()) canvas.cancelTransform();
                canvas.setActive(p.layers.indexOf(l));
                canvas.deleteActive();
                imagePop.dismiss();
                afterLayerOp();
            }
        }));
        r2.addView(chooserCell(R.drawable.ic_check, "Listo", 0xFF2EE6A6, new Runnable() {
            public void run() {
                if (canvas.isTransformActive()) canvas.applyTransform();
                imagePop.dismiss();
                afterLayerOp();
            }
        }));
        int w = Math.min(dp(360), getResources().getDisplayMetrics().widthPixels - dp(16));
        imagePop = new PopupWindow(box, w, ViewGroup.LayoutParams.WRAP_CONTENT, false);
        imagePop.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
        imagePop.setOutsideTouchable(false);
        View bottomBar = findViewById(R.id.bottomPanel);
        int y = (bottomBar != null && bottomBar.getHeight() > 0 ? bottomBar.getHeight() : dp(120)) + dp(6);
        imagePop.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, y);
    }

    private void afterProjectLoaded() {
        if (softCard != null && softCard.getParent() instanceof ViewGroup) ((ViewGroup) softCard.getParent()).removeView(softCard);
        softCard = null;
        softPrevSize = softPrevHard = softPrevOp = -1f;
        fxClose();
        hideEasyCard();
        hideCompareChip();
        closeTools();
        closeLayers();
        // Abrir con Mano: nunca arrancar en una herramienta retirada del menu.
        canvas.setMode(CanvasView.MODE_PAN);
        canvas.setSubtract(false);
        syncSlider();
        updateUi();
    }

    private void applyLoaded() {
        if (lastError != null) {
            canvas.setAlpha(1f);
            toast("No se pudo abrir: " + lastError);
            return;
        }
        if (loaded == null || loaded.project == null) {
            canvas.setAlpha(1f);
            return;
        }
        canvas.setProject(loaded.project);
        canvas.setColor(loaded.color);
        loaded = null;
        restoreProjectReference();
        afterProjectLoaded();
        revealCanvas();
        if (recoveredBackup) {
            recoveredBackup = false;
            toast("Recuperamos la copia de seguridad de tu obra");
            markDirty();
        }
    }

    private boolean barsMeasured, pendingReveal;

    /** Muestra el lienzo con un fundido corto, cuando ya esta en su lugar. */
    private void revealCanvas() {
        if (!barsMeasured) {
            pendingReveal = true;
            return;
        }
        pendingReveal = false;
        canvas.post(new Runnable() {
            @Override
            public void run() {
                if (!canvas.isFitted()) canvas.fit();
                canvas.animate().alpha(1f).setDuration(140).start();
            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.pz_stay, R.anim.pz_fade_out);
    }

    /** Guarda sola en la galeria al salir y al hacer cambios de capas. */
    private void autosave(final boolean notify) {
        if (canvas != null && canvas.isTransformActive()) {
            saveAgain = true;
            return;
        }
        final Project p = canvas.getProject();
        if (p == null) return;
        if (saving) {
            saveAgain = true;
            return;
        }
        saving = true;
        dirty = false;
        if (projectId == null) projectId = ProjectStore.newId();
        final String id = projectId;
        final int color = canvas.getColor();
        final File dest = ProjectStore.fileFor(this, id);
        final File tmp = new File(dest.getAbsolutePath() + ".tmp");
        final File bak = new File(dest.getAbsolutePath() + ".bak");
        if (notify) toast("Guardando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                // v8.53: el guardado va con prioridad baja: el dedo y la pantalla van primero
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                try {
                    // Primero crear y cerrar la revision nueva. Nunca borrar el
                    // proyecto valido antes de tener el reemplazo listo.
                    try (FileOutputStream fo = new FileOutputStream(tmp)) {
                        ProjectIO.save(fo, p, color);
                    }
                    if (!tmp.exists() || tmp.length() < 60)
                        throw new java.io.IOException("Proyecto temporal incompleto");
                    if (dest.exists()) {
                        // Conservar la ultima revision valida por si hay un corte
                        // entre mover el viejo y colocar el nuevo.
                        if (bak.exists() && !bak.delete())
                            throw new java.io.IOException("No se pudo renovar el respaldo");
                        if (!dest.renameTo(bak))
                            throw new java.io.IOException("No se pudo respaldar el proyecto");
                    }
                    if (!tmp.renameTo(dest)) {
                        if (!dest.exists() && bak.exists()) bak.renameTo(dest);
                        throw new java.io.IOException("No se pudo confirmar el guardado");
                    }
                    int vb = p.viewBg;
                    Bitmap th = p.previewBitmap(320, vb >= 0 && vb < CanvasView.VIEW_BG.length ? CanvasView.VIEW_BG[vb] : null);
                    ProjectStore.saveThumb(MainActivity.this, id, th);
                    th.recycle();
                    lastError = null;
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                } finally {
                    android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DEFAULT);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                saving = false;
                if (lastError != null) dirty = true;
                if (notify) toast(lastError != null ? "Error al guardar: " + lastError : "Guardado en la galeria");
                noteSaveResult(lastError);
                if (saveAgain) {
                    saveAgain = false;
                    if (dirty) autosave(false);
                }
            }
        });
    }

    // ==================================================================
    // Herramientas
    // ==================================================================

    // Menú de herramientas práctico para extraer personajes y animar.
    // Los modos antiguos siguen en CanvasView para proyectos previos.
    // v8.53: primero lo de pintar (lo mas usado), despues extraer y animar
    private static final String[] GROUPS = {"EXTRAER PERSONAJES", "PINTAR Y RETOCAR", "MOVER Y ANIMAR",
            "MARCAR Y AJUSTAR"};
    private static final int[][] TOOLS = {
            // v8.60: el Lapiz se quito de aca (hacia lo mismo que la Brocha): es la punta "Lapiz digital"
            // en Tipo de pincel
            {1, CanvasView.MODE_PAINT, 0, 0}, {1, CanvasView.MODE_ERASER, 0, 0},
            {1, CanvasView.MODE_BUCKET, 0, 0}, {1, CanvasView.MODE_SMUDGE, 0, 0},
            {1, CanvasView.MODE_BLUR, 0, 0}, {1, CanvasView.MODE_LIQUIFY, 0, 0},
            // Curva y Polilínea no dependen de selección azul y son útiles para dibujar partes.
            {1, CanvasView.MODE_SHAPE, 0, 0},
            {1, CanvasView.MODE_CURVE, 0, 0}, {1, CanvasView.MODE_POLY, 0, 0},
            {0, CanvasView.MODE_BGERASE, 0, 0}, {0, CanvasView.MODE_MARKER, 0, 0},
            {0, CanvasView.MODE_LASSO, 0, 0},
            {2, CanvasView.MODE_PAN, 0, 0}, {2, CanvasView.MODE_MOVE, 0, 0},
            {2, CanvasView.MODE_TRANSFORM, 0, 0}, {2, CanvasView.MODE_PUPPET, 0, 0},
            // v8.88 memes y guias
            {3, CanvasView.MODE_MARK, 0, 0}, {3, CanvasView.MODE_CROP, 0, 0}
    };

    private static final int[] COLOR_DEMOS = {com.pacco.animecut.view.ToolDemoView.DEMO_COLOR,
            com.pacco.animecut.view.ToolDemoView.DEMO_SOFT, com.pacco.animecut.view.ToolDemoView.DEMO_LIGHT,
            com.pacco.animecut.view.ToolDemoView.DEMO_STYLE, com.pacco.animecut.view.ToolDemoView.DEMO_IMPROVE};

    private String[] toolInfo(int mode, int sub) {
        switch (mode) {
            case com.pacco.animecut.view.ToolDemoView.DEMO_COLOR: return new String[]{"1 Colorear",
                    "Pinta tu dibujo en blanco y negro por partes, y despues le da sombras y luces.",
                    "Paso 1: elige un color abajo y toca una parte (cara, pelo, ropa). Paso 2 Acabado: pon el sol.",
                    "Paso 3 Final: guarda o sigue retocando."};
            case com.pacco.animecut.view.ToolDemoView.DEMO_SOFT: return new String[]{"2 Toques",
                    "Rubor, sombra y luz a mano que se funden solos (piel natural).",
                    "Elige Color, Sombra o Luz y pinta encima. \"Fundir\" difumina todos los toques de la capa.",
                    "Van en su propia capa: tu dibujo no se toca."};
            case com.pacco.animecut.view.ToolDemoView.DEMO_LIGHT: return new String[]{"3 Luz",
                    "Luz, brillo, sombra y cielo en capas aparte.",
                    "Mueve el sol con el dedo: la luz y la sombra lo siguen.",
                    "Tu dibujo no se toca: todo va en capas encima."};
            case com.pacco.animecut.view.ToolDemoView.DEMO_STYLE: return new String[]{"4 Estilo",
                    "Acabado de edicion para toda la imagen: anime, violeta, celeste, grano.",
                    "Toca un estilo y ajusta la fuerza.", ""};
            case com.pacco.animecut.view.ToolDemoView.DEMO_IMPROVE: return new String[]{"Mejorar",
                    "IA sin internet: limpia el JPEG (cuadritos) y afina las lineas.",
                    "Tocalo y espera un momento: la imagen queda mas nitida.", ""};
            case CanvasView.MODE_BGERASE: return new String[]{"Borrar fondo",
                    "Balde: toca el fondo. Pincel: pasa junto a la linea.",
                    "Borrador: borra todo. Restaurar: lo devuelve.",
                    "Escoba: limpia puntos."};
            case CanvasView.MODE_WAND: return new String[]{"Varita",
                    "Marca en azul una zona del mismo color.",
                    "Toca una zona. Abajo, el + agrega y el - quita.",
                    "Despues: en el cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_BRUSH: return sub == 2 ? new String[]{"Borrar azul",
                    "Quita parte de lo marcado en azul. No borra el dibujo.",
                    "Pinta sobre lo azul que sobra.", "Sirve para corregir lo que marco la Varita."}
                    : new String[]{"Marcar azul", "Marca a mano lo que quieres sacar.",
                    "Pinta encima. Lo azul es lo que vas a copiar o borrar.",
                    "Despues: cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_ERASER: return new String[]{"Goma",
                    "Borra el dibujo de la capa elegida, como una goma.",
                    "Elige la capa en Capas y borra. Si hay algo azul, solo borra dentro.",
                    "Si en Capas esta elegida la capa de seleccion, borra lo azul."};
            case CanvasView.MODE_MARKER: return new String[]{"Separar",
                    "Saca partes (pelo, brazo, ojo) a capas propias para animarlas. No pinta.",
                    "Raya cada parte con un color. El color que ves es solo vista previa.",
                    "Check: cada parte a su capa, con sus colores reales. Una sola raya: solo lo encerrado por la linea."};
            case CanvasView.MODE_SCISSORS: return new String[]{"Tijeras", "Marca siguiendo el contorno.",
                    "Arrastra cerca de la linea y se pega sola. Vuelve al punto verde para cerrar.",
                    "Queda azul."};
            case CanvasView.MODE_MAGNET: return new String[]{"Magnetico", "Como las tijeras, de un solo trazo.",
                    "Arrastra por el contorno sin soltar. Al soltar se cierra.", "Queda azul."};
            case CanvasView.MODE_LASSO: return new String[]{"Lazo", "Copia una parte en otra capa.",
                    "Rodea la parte; elige nombre y solapamiento para animación.",
                    "Crea la capa sin borrar el original."};
            case CanvasView.MODE_BUCKET: return new String[]{"Relleno",
                    "Pinta de un color toda una zona de golpe.",
                    "Toca la zona. Abajo: tolerancia (gota), dilatacion (cuadrito +, y sus tres puntos), "
                            + "mirar todas las capas o solo esta, hasta la linea y \"→ capa\" (el DESTINO).",
                    "El destino se ve en la barra: Pintar en capa actual (de fabrica) o Capa de color automatica. "
                            + "Ahi tambien: Por lineas (manga) y Vista previa."};
            case CanvasView.MODE_PAINT: if (sub == 3) return new String[]{"Lapiz",
                    "Dibuja a mano libre: lineas y formas rapidas, borde definido.",
                    "Pasa el dedo. El tamano y el color son los de abajo.",
                    "Para colorear zonas grandes usa la Brocha o el Relleno."};
                return new String[]{"Brocha",
                    "Pinta con el color de abajo, con el pincel que elijas.",
                    "Pasa el dedo. Abajo: el escudo prende \"Proteger contornos\": "
                            + "pinta solo la zona donde empiezas y no tapa la tinta. \"→ capa\" muestra donde pinta.",
                    "Pinceles: Color plano (borde duro, de fabrica) o Brocha suave. Si hay algo azul, solo pinta dentro."};
            case CanvasView.MODE_CROP: return new String[]{"Recortar",
                    "Recorta o agranda el lienzo con medidas (1:1, 4:5, 9:16...), gira, voltea y cambia el tamano.",
                    "Lados o esquinas hacia adentro: recorta. Hacia afuera: agrega espacio de ese lado (se ve con cuadritos). Se pegan solos al borde de la imagen.",
                    "Check: aplica a todas las capas. Deshacer lo devuelve."};
            case CanvasView.MODE_MARK: return new String[]{"Marcar",
                    "Texto, destacar, tapar, lupa y numeros para memes y guias.",
                    "Abajo eliges que poner. Toca o arrastra en la imagen; muevelo y cambia el tamano con las esquinas.",
                    "Check: se pinta en la capa Marcas (arriba de todo). Tocar afuera tambien lo pinta. Deshacer lo quita."};
            case CanvasView.MODE_SHAPE: return new String[]{"Figuras",
                    "Linea, rectangulo, circulo, elipse, poligono, flecha y bocadillo.",
                    "Arrastra para crearla. Despues muevela, agrandala con las esquinas y girala con el punto verde.",
                    "Check: se pinta en la capa. Tocar afuera tambien la pinta. Deshacer la quita."};
            case CanvasView.MODE_CURVE: return new String[]{"Curva",
                    "Dibuja una linea curva suave por los puntos que pones.",
                    "Toca para poner puntos. Arrastra un punto para moverlo. Deshacer quita el ultimo.",
                    "Check: se dibuja con el color y el grosor de abajo. Llenar: pinta por dentro."};
            case CanvasView.MODE_POLY: return new String[]{"Polilinea",
                    "Lineas rectas de punto a punto: cuadros, bordes, vinetas.",
                    "Toca para poner puntos. Arrastra un punto para moverlo. Deshacer quita el ultimo.",
                    "Check: se dibuja con el color y el grosor de abajo. Llenar: pinta por dentro."};
            case CanvasView.MODE_PICKER: return new String[]{"Gotero", "Toma un color de la imagen.",
                    "Toca un color. Tambien manteniendo pulsado con cualquier herramienta.", "Despues: Brocha o Relleno."};
            case CanvasView.MODE_ZONE: return new String[]{"Zona",
                    "Rellena lo azul con el color plano que tiene alrededor.",
                    "Marca en azul lo que hay que rehacer (donde estaba el ojo). Toca dentro de lo azul.",
                    "Hazlo en la capa de atras, la que quedo con el hueco."};
            case CanvasView.MODE_CLONE: return new String[]{"Clonar", "Copia un trozo de la capa a otro lugar.",
                    "Toca de donde copiar (cruz roja). Despues pinta. Tiene espejo y giro abajo.",
                    "Para tapar huecos copiando algo parecido."};
            case CanvasView.MODE_LINE: return new String[]{"Linea",
                    "Continua una linea cortada dentro de lo azul.",
                    "Traza por donde seguia la linea. Se engancha a la linea real.", "Despues: Zona."};
            case CanvasView.MODE_HEAL: return new String[]{"Corrector",
                    "Copia de un lado a otro y funde el color para que no se note.",
                    "Toca de donde copiar. Despues pinta donde quieres.", "Para disimular cortes."};
            case CanvasView.MODE_TONE: return new String[]{"Trama",
                    "Continua la trama de puntos del manga dentro de lo azul.",
                    "Toca la trama que esta al lado de lo azul.", "Solo para manga."};
            case CanvasView.MODE_SMUDGE: return new String[]{"Difuminar",
                    "Arrastra y mezcla los pixeles siguiendo el dedo.",
                    "Pasa el pincel sobre pelo, sombras o bordes. Abajo puedes ajustar la fuerza.",
                    "Trabaja solo en la zona del pincel para mantener fluidez."};
            case CanvasView.MODE_BLUR: return new String[]{"Borrosidad",
                    "Desenfoca solo donde pintas.",
                    "Pasa varias veces para aumentar el desenfoque. Ajusta tamano y fuerza.",
                    "No desenfoca toda la capa."};
            case CanvasView.MODE_LIQUIFY: return new String[]{"Especial",
                    "Licua la imagen con cinco modos.",
                    "Arrastrar, Contraer, Expandir, Suavizar y Restaurar. Elige el modo abajo.",
                    "Restaurar vuelve hacia el estado que tenia la capa al entrar a Especial."};
            case CanvasView.MODE_TRANSFORM: return new String[]{"Transformar",
                    "Mueve, escala, gira, cambia perspectiva o deforma con malla o puntos.",
                    "Mover: arrastra; dos dedos escalan y giran. Perspectiva/Malla/Puntos: arrastra sus puntos.",
                    "Usa check para aplicar o X para cancelar. Para enderezar un personaje usa Marioneta."};
            case CanvasView.MODE_PUPPET: return new String[]{"Marioneta",
                    "Endereza o cambia la postura con puntos, como si moviera una marioneta.",
                    "Toca el dibujo para poner puntos. Fija los pies (Fijar) y arrastra cadera, hombros y cabeza. "
                            + "Por partes: un punto en la corbata mueve solo la corbata. El anillo del punto lo gira.",
                    "Check aplica, X cancela. Deshacer/Rehacer de arriba deshacen puntos mientras trabajas. "
                            + "Lo que estaba tapado no se inventa: retocalo despues con Clonar."};
            case CanvasView.MODE_MOVE: return new String[]{"Mover",
                    "Mueve la capa entera, o solo lo azul si hay algo marcado.",
                    "Arrastra.", ""};
            default: return new String[]{"Mano", "Mueve y acerca la imagen sin pintar.",
                    "Arrastra con un dedo. Con dos dedos haces zoom en cualquier herramienta.", ""};
        }
    }

    /** v8.53: una seccion de acciones (no herramientas) en el panel de herramientas. */
    private void addToolAction(LinearLayout box, int cols, String[] names, int[] icons, final String[] help, final String[] keys) {
        TextView h = new TextView(this);
        h.setText("COLOREAR (EN ORDEN)");
        h.setTextColor(0xFF8A8A92);
        h.setTextSize(10f);
        h.setPadding(dp(4), dp(8), 0, dp(2));
        box.addView(h);
        LinearLayout row = null;
        int inRow = 0;
        for (int i = 0; i < names.length; i++) {
            if (row == null || inRow == cols) {
                if (row != null) fillRow(row, inRow, cols);
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row);
                inRow = 0;
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(2), dp(6), dp(2), dp(5));
            cell.setBackgroundResource(R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(1), dp(1), dp(1), dp(1));
            cell.setLayoutParams(clp);
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
            img.setImageResource(icons[i]);
            cell.addView(img);
            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextColor(0xFFE0E0E0);
            t.setTextSize(9.5f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setMaxLines(1);
            t.setPadding(0, dp(3), 0, 0);
            cell.addView(t);
            final int k = i;
            cell.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTools(); runMenu(keys[k]); }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                // v8.69: mantener pulsado muestra su ficha con animacion (antes solo un texto)
                @Override public boolean onLongClick(View v) {
                    if (k < COLOR_DEMOS.length) showToolCard(COLOR_DEMOS[k], 0); else toast(help[k]);
                    return true;
                }
            });
            row.addView(cell);
            inRow++;
        }
        if (row != null) fillRow(row, inRow, cols);
    }

    private void toolGrid() {
        final View panel = findViewById(R.id.toolPanel);
        final View scrim = findViewById(R.id.toolScrim);
        if (panel.getVisibility() == View.VISIBLE) {
            closeTools();
            return;
        }
        closeLayers();
        hideCards(true);
        LinearLayout box = findViewById(R.id.toolPanelContent);
        box.removeAllViews();
        TextView tip = new TextView(this);
        tip.setText("Manten pulsada una herramienta para ver que hace");
        tip.setTextColor(0xFF9FC6FF);
        tip.setTextSize(10f);
        tip.setPadding(dp(4), dp(2), dp(4), dp(2));
        box.addView(tip);
        int cols = 4, lastGroup = -1, inRow = 0;
        // v8.53: COLOREAR arriba de todo (lo mas importante), en el orden en que se usa
        // v8.60: "Manga" se quito de aca: hacia lo mismo que Colorear (Colorear prepara las capas del
        // manga solo). Sus opciones siguen en el boton de manga de la barra del balde.
        addToolAction(box, cols, new String[]{"1 Colorear", "2 Toques", "3 Luz", "4 Estilo",
                        "Mejorar"},
                new int[]{R.drawable.ic_zone_grad, R.drawable.ic_soft, R.drawable.ic_light, R.drawable.ic_hue,
                        R.drawable.ic_sparkle},
                new String[]{"Colores base y acabado de tu B/N: sombras, luces, pelo y ojos.",
                        "Rubor, sombra y luz a mano que se funden solos.",
                        "Luz, brillo, sombra y cielo en capas aparte: tu dibujo no se toca.",
                        "Acabado de edit: anime, violeta, celeste, grano.",
                        "IA sin internet: limpia el JPEG y afina las lineas."},
                new String[]{"Colorear facil (pasos)", "Toques suaves (rubor, sombra, luz)", "Luz y ambiente (atardecer)",
                        "Estilo de edicion", "Mejorar imagen (IA)"});
        LinearLayout row = null;
        for (int[] tdef : TOOLS) {
            final int group = tdef[0], mode = tdef[1], sub = tdef[2];
            // v8.86: Figuras, Curva y Polilinea ya estan en el boton Figuras de arriba (no se repiten)
            if (isShapeMode(mode)) continue;
            if (group != lastGroup) {
                if (row != null) fillRow(row, inRow, cols);
                TextView h = new TextView(this);
                h.setText(GROUPS[group]);
                h.setTextColor(0xFF8A8A92);
                h.setTextSize(10f);
                h.setPadding(dp(4), dp(8), 0, dp(2));
                box.addView(h);
                row = null;
                inRow = 0;
                lastGroup = group;
            }
            if (row == null || inRow == cols) {
                if (row != null) fillRow(row, inRow, cols);
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row);
                inRow = 0;
            }
            boolean active = canvas.getMode() == mode && (mode == CanvasView.MODE_PAINT ? (sub == 3) == pencilOn
                    : (sub == 0 || (sub == 2) == canvas.isSubtract()));
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(2), dp(6), dp(2), dp(5));
            cell.setBackgroundResource(active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(1), dp(1), dp(1), dp(1));
            cell.setLayoutParams(clp);
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
            img.setImageResource(sub == 2 ? R.drawable.ic_remove : sub == 3 ? R.drawable.ic_pencil : toolIcon(mode));
            cell.addView(img);
            TextView t = new TextView(this);
            t.setText(toolInfo(mode, sub)[0]);
            t.setTextColor(0xFFE0E0E0);
            t.setTextSize(9.5f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setMaxLines(1);
            t.setPadding(0, dp(3), 0, 0);
            cell.addView(t);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closeTools();
                    if (sub == 1) canvas.setSubtract(false);
                    if (sub == 2) canvas.setSubtract(true);
                    canvas.setRayMode(false);   // v8.44: Separar normal (no Rayar partes)
                    if (mode == CanvasView.MODE_BUCKET) {
                        // v8.54: Relleno = balde normal (el de Colorear se abre con 1 Colorear o Manga)
                        canvas.setColorBucket(false);
                        if (easyCard != null) removeEasyCardView();
                    }
                    if (mode == CanvasView.MODE_PAINT) setPencil(sub == 3);
                    selectTool(mode);
                    // Sin tutorial emergente al cambiar de herramienta.
                    // La explicación sigue disponible al mantener pulsado.
                }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showToolCard(mode, sub);
                    return true;
                }
            });
            row.addView(cell);
            inRow++;
        }
        if (row != null) fillRow(row, inRow, cols);

        View bottom = findViewById(R.id.bottomPanel);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) panel.getLayoutParams();
        lp.bottomMargin = bottom.getHeight() + dp(4);
        panel.setLayoutParams(lp);
        final int limit = canvas.getHeight() - bottom.getHeight() - findViewById(R.id.topBar).getHeight() - dp(16);
        scrim.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        panel.post(new Runnable() {
            @Override
            public void run() {
                if (limit > 0 && panel.getHeight() > limit) {
                    FrameLayout.LayoutParams l2 = (FrameLayout.LayoutParams) panel.getLayoutParams();
                    l2.height = limit;
                    panel.setLayoutParams(l2);
                }
            }
        });
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeTools();
            }
        });
    }

    private void selectTool(int mode) {
        // v8.60: elegir otra herramienta deja el Acabado puesto y lo cierra
        if (finOpen()) {
            finAccept();
            if (easyCard != null) { easyStep = 3; showEasyCard(); }
        }
        // v8.68: ya no se pregunta "Borrar fondo del dibujo pintado": se trabaja en la capa elegida
        selectToolNow(mode);
    }

    private void selectToolNow(int mode) {
        // v9.00: Separar y Borrar/Tomar color de Colorear se apagan al cambiar de herramienta
        canvas.setWallMode(false);
        if (mode != CanvasView.MODE_BUCKET) canvas.setZoneTapTool(CanvasView.ZT_PAINT);
        // v8.94: X y check de Recortar vuelven a la herramienta de antes
        if (mode == CanvasView.MODE_CROP && canvas.getMode() != CanvasView.MODE_CROP) cropReturnMode = canvas.getMode();
        if (mode == CanvasView.MODE_CROP && (cropReturnMode == CanvasView.MODE_CROP || cropReturnMode == CanvasView.MODE_MARK))
            cropReturnMode = CanvasView.MODE_BRUSH;
        if (canvas.getMode() == CanvasView.MODE_MARK && mode != CanvasView.MODE_MARK) stopTyping(false);
        // v8.95: lo mismo para Marcar
        if (mode == CanvasView.MODE_MARK && canvas.getMode() != CanvasView.MODE_MARK)
            markReturnMode = canvas.getMode() == CanvasView.MODE_CROP ? CanvasView.MODE_BRUSH : canvas.getMode();
        // v8.72: la barra de la imagen se cierra al pasar a otra herramienta
        if (mode != CanvasView.MODE_TRANSFORM && imagePop != null && imagePop.isShowing()) imagePop.dismiss();
        if (mode == CanvasView.MODE_LASSO) {
            canvas.setSubtract(false);
            if (canvas.getProject() != null && canvas.getProject().hasSelection())
                canvas.clearSelection(); // cada parte nueva comienza sin máscara anterior
        }
        canvas.setMode(mode);
        // Deformar arranca al elegirlo: la malla o los puntos aparecen enseguida.
        if (mode == CanvasView.MODE_PUPPET) canvas.setTransformType(canvas.getTransformType());
        if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) canvas.resetCloneSource();
        syncSlider();
        updateUi();
    }

    /** Opciones propias de cada herramienta, solo iconos. */
    private void buildOptBar(int mode) {
        LinearLayout bar = findViewById(R.id.optBar);
        bar.removeAllViews();
        bar.setVisibility(View.VISIBLE);
        if (mode != CanvasView.MODE_BGERASE || !canvas.isBgGray()) closeGrayPop();
        if (mode == CanvasView.MODE_BGERASE) {
            // v8.30: Borrar fondo SIMPLE, solo iconos (mantener pulsado dice el nombre):
            // Toque · Pincel · Restaurar | Limpiar restos · Ver
            // La Goma de aqui se quito: era igual a la Goma de la caja de herramientas y se usaba
            // creyendo que respetaba la linea (captura 1 de v8.29). Para borrar todo: la Goma normal.
            final int sub = canvas.getBgSub();
            // v8.33: Recortar con IA (primero y resaltado). No reemplaza a las herramientas manuales.
            // v8.33: es un BOTON (abre el recorte con IA), no una herramienta: no queda marcado. Lo
            // marcado en azul es la herramienta manual elegida (Balde, Pincel, Borrador, Restaurar).
            // v8.36: primer toque = pinta encima del personaje (celeste); queda marcado mientras pintas.
            // Otro toque sin pintar = toda la imagen.
            ImageButton ai = iconButton(R.drawable.ic_ai, canvas.isAiMarking()
                    ? "Pinta el personaje. Toca otra vez: toda la imagen"
                    : "Recortar con IA: pinta encima del personaje que quieres", new Runnable() {
                public void run() { aiFlow().start(); }
            });
            if (canvas.isAiMarking()) ai.setBackgroundResource(R.drawable.bg_tool_on);
            bar.addView(ai);
            View sep = new View(this);
            sep.setBackgroundColor(0x55FFFFFF);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(1), dp(26));
            slp.setMargins(dp(4), 0, dp(4), 0);
            sep.setLayoutParams(slp);
            bar.addView(sep);
            // v8.32: Balde · Pincel protegido · Borrador manual · Restaurar | Escoba · Ver
            final int[] subIds = {CanvasView.BG_SUB_TAP, CanvasView.BG_SUB_BRUSH, CanvasView.BG_SUB_ERASER, CanvasView.BG_SUB_RESTORE};
            int[] subIcons = {R.drawable.ic_bucket, R.drawable.ic_bgerase, R.drawable.ic_eraser, R.drawable.ic_restore_brush};
            final String[] subNames = {"Balde: un toque borra el fondo", "Pincel protegido: no cruza la linea",
                    "Borrador: borra justo donde pasas", "Restaurar: devuelve lo borrado"};
            for (int k = 0; k < subIds.length; k++) {
                final int which = k;
                ImageButton b = iconButton(subIcons[k], subNames[k], new Runnable() {
                    public void run() {
                        canvas.setBgSub(subIds[which]);
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_sub", subIds[which]).apply();
                        canvas.showHud(subNames[which]);
                        updateUi();
                    }
                });
                b.setBackgroundResource(!canvas.isAiMarking() && sub == subIds[k] ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(b);
            }
            bar.addView(iconButton(R.drawable.ic_broom, "Escoba: limpia puntos y bordes sueltos", new Runnable() {
                public void run() { canvas.cleanBackgroundRemnants(); }
            }));
            bar.addView(iconButton(R.drawable.ic_eye, "Ver sobre cuadros, blanco, negro, gris o verde (no cambia el PNG)", new Runnable() {
                public void run() { cycleViewBg(); }
            }));
            // v8.37: B/N. Primer toque: el Balde y el Pincel miran en blanco y negro (fondos con
            // muchos colores). Con B/N prendido, otro toque abre sus ajustes y "Volver a color".
            final TextView bw = smallTextButton("B/N");
            bw.setBackgroundResource(canvas.isBgGray() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bw.setContentDescription("Blanco y negro: el Balde mira en gris (tu color no cambia)");
            bw.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!canvas.isBgGray()) {
                        canvas.setBgGrayView(loadGrayView());
                        canvas.setBgGray(true);
                        canvas.showHud("B/N: el Balde mira en gris · toca B/N para ajustar", 2600);
                        updateUi();
                    } else {
                        grayDialog();
                    }
                }
            });
            bw.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    canvas.showHud("Blanco y negro: solo para mirar; tu color no cambia");
                    return true;
                }
            });
            bar.addView(bw);
            // v8.31: sin icono de Ajustes (era confuso y no se notaba diferencia). Los ajustes de
            // fabrica son los que mejor funcionan; quien los quiera cambiar los tiene en Menu >
            // "Borrar fondo: ajustes avanzados".
        } else if (mode == CanvasView.MODE_BUCKET && canvas.isColorBucket()) {
            buildMangaBucketBar(bar);
        } else if ((mode == CanvasView.MODE_LASSO || mode == CanvasView.MODE_WAND) && canvas.isMangaMode()) {
            buildMangaSelectionBar(bar);
        } else if (mode == CanvasView.MODE_PICKER) {
            final int ps = canvas.getPickSource();
            TextView t = smallTextButton("Gotero: " + (ps == CanvasView.PICK_VISIBLE ? "Visible" : ps == CanvasView.PICK_LAYER ? "Capa actual" : "Automatico"));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { pickSourceDialog(); }
            });
            bar.addView(t);
            bar.addView(iconButton(R.drawable.ic_add, "Guardar el color actual en la paleta", new Runnable() {
                public void run() { saveSwatchDialog(canvas.getColor(), null); }
            }));
        } else if (mode == CanvasView.MODE_BUCKET) {
            if (canvas.hasFillPreview()) {
                // v8.27: vista previa del balde normal: Aceptar / Cancelar
                ImageButton okp = iconButton(R.drawable.ic_check, "Aceptar: pintar la vista previa", new Runnable() {
                    public void run() {
                        canvas.acceptFillPreview();
                        updateUi();
                    }
                });
                okp.setBackgroundResource(R.drawable.bg_save);
                bar.addView(okp);
                bar.addView(iconButton(R.drawable.ic_close, "Cancelar: no pintar nada", new Runnable() {
                    public void run() {
                        canvas.cancelFillPreview();
                        updateUi();
                    }
                }));
                bar.addView(destinationChip(true));
                return;
            }
            bar.addView(iconButton(R.drawable.ic_range, "Cuanto se parece el color", new Runnable() {
                public void run() {
                    fillToleranceDialog();
                }
            }));
            ImageButton fd = iconButton(R.drawable.ic_grow, "Dilatacion del relleno", new Runnable() {
                public void run() {
                    fillExpOn = !fillExpOn;
                    applyFillPrefs();
                    canvas.showHud(fillExpOn ? "Dilatacion prendida: " + signed(fillExpAmt) + " px" : "Dilatacion apagada");
                    updateUi();
                }
            });
            fd.setBackgroundResource(fillExpOn ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fd);
            bar.addView(dotsButton("Ajustar la dilatacion", new Runnable() {
                public void run() {
                    expansionDialog(true);
                }
            }));
            final boolean all = canvas.isFillAllLayers();
            ImageButton src = iconButton(all ? R.drawable.ic_layers : R.drawable.ic_image,
                    all ? "Mira todas las capas" : "Mira solo la capa elegida", new Runnable() {
                        public void run() {
                            canvas.setFillAllLayers(!canvas.isFillAllLayers());
                            applyFillPrefs();
                            canvas.showHud(canvas.isFillAllLayers()
                                    ? "Mira todas las capas: rellena debajo de la linea"
                                    : "Mira solo la capa elegida");
                            updateUi();
                        }
                    });
            src.setBackgroundResource(all ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(src);
            ImageButton ln = iconButton(R.drawable.ic_edge, "Hasta la linea", new Runnable() {
                public void run() {
                    canvas.setFillToLine(!canvas.isFillToLine());
                    applyFillPrefs();
                    canvas.showHud(canvas.isFillToLine() ? "Hasta la linea: SI" : "Hasta la linea: NO");
                    updateUi();
                }
            });
            ln.setBackgroundResource(canvas.isFillToLine() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(ln);
            bar.addView(iconButton(R.drawable.ic_ref_color, "Referencia de color: abrir otra imagen y tomar sus colores (no se exporta)", new Runnable() {
                public void run() { requestColorReference(paintColorTarget()); }
            }));
            // v8.27: el destino se VE en la barra y se elige en su panel (Pintar en capa actual /
            // Capa de color automatica, Por lineas, Vista previa). Antes un boton "capa aparte"
            // prendido de fabrica creaba Color_1 aunque el usuario hubiera creado su capa.
            bar.addView(destinationChip(true));
        } else if (mode == CanvasView.MODE_MARK) {
            buildMarkBar(bar);       // v8.88
        } else if (mode == CanvasView.MODE_CROP) {
            buildCropBar(bar);       // v8.89
        } else if (mode == CanvasView.MODE_SHAPE) {
            // v8.79: figura · ajustes · quitar · pintar
            final ImageButton[] kind = new ImageButton[1];
            kind[0] = iconButton(shapeIcon(canvas.getShapeType()), "Elegir figura", new Runnable() {
                public void run() { showShapePicker(kind[0]); }
            });
            kind[0].setBackgroundResource(R.drawable.bg_tool_on);
            bar.addView(kind[0]);
            final ImageButton[] tune = new ImageButton[1];
            tune[0] = iconButton(R.drawable.ic_tune, "Contorno, relleno y mas", new Runnable() {
                public void run() { showShapeStylePanel(tune[0]); }
            });
            bar.addView(tune[0]);
            // v8.80: "Dar luz": pinta la figura (si falta) y abre Rayos de luz (el mismo filtro de Filtros)
            bar.addView(iconButton(R.drawable.ic_light, "Dar luz: rayos de luz desde la figura", new Runnable() {
                public void run() {
                    if (canvas.hasShapeDraft() && !canvas.applyShapeDraft()) return;
                    FxScreen.open(MainActivity.this, canvas, com.pacco.animecut.core.Fx.RAYS);
                }
            }));
            bar.addView(iconButton(R.drawable.ic_close, "Quitar la figura (sin pintar)", new Runnable() {
                public void run() {
                    if (canvas.hasShapeDraft()) {
                        canvas.discardShapeDraft();
                        canvas.showHud("Figura quitada");
                    }
                }
            }));
            ImageButton ok = iconButton(R.drawable.ic_check, "Pintar la figura en la capa", new Runnable() {
                public void run() {
                    if (canvas.applyShapeDraft()) canvas.showHud("Figura lista. Deshacer la quita", 1600);
                }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
        } else if (mode == CanvasView.MODE_CURVE || mode == CanvasView.MODE_POLY) {
            final boolean curve = mode == CanvasView.MODE_CURVE;
            bar.addView(iconButton(curve ? R.drawable.ic_poly : R.drawable.ic_curve,
                    curve ? "Pasar a lineas rectas" : "Pasar a curva", new Runnable() {
                        public void run() {
                            canvas.setMode(curve ? CanvasView.MODE_POLY : CanvasView.MODE_CURVE);
                            canvas.showHud(curve ? "Polilinea: lineas rectas" : "Curva");
                            updateUi();
                        }
                    }));
            ImageButton fl = iconButton(R.drawable.ic_bucket, "Llenar por dentro", new Runnable() {
                public void run() {
                    canvas.setShapeFill(!canvas.isShapeFill());
                    canvas.showHud(canvas.isShapeFill() ? "Llenar: SI (necesita 3 puntos)" : "Llenar: NO");
                    updateUi();
                }
            });
            fl.setBackgroundResource(canvas.isShapeFill() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fl);
            bar.addView(iconButton(R.drawable.ic_remove, "Quitar el punto rojo", new Runnable() {
                public void run() {
                    canvas.shapeDeleteSelected();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todos los puntos", new Runnable() {
                public void run() {
                    canvas.shapeClear();
                }
            }));
            ImageButton ok = iconButton(R.drawable.ic_check, "Dibujar en la capa", new Runnable() {
                public void run() {
                    canvas.commitShape();
                    updateUi();
                }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
        } else if (mode == CanvasView.MODE_MARKER && canvas.isRayMode()) {
            buildRayBar(bar);
        } else if (mode == CanvasView.MODE_MARKER) {
            int lab = canvas.getMarkerLabel();
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            sw.setLayoutParams(lp);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(CanvasView.LABEL_COLORS[lab - 1]);
            g.setStroke(dp(2), 0xFFFFFFFF);
            sw.setBackground(g);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    labelPicker();
                }
            });
            bar.addView(sw);
            final int bgLab = CanvasView.LABEL_NAMES.length;
            final boolean onBg = lab == bgLab;
            ImageButton fondo = iconButton(R.drawable.ic_sub, onBg ? "Volver a marcar partes" : "Marcar fondo (gris)",
                    new Runnable() {
                        public void run() {
                            if (canvas.getMarkerLabel() == bgLab) {
                                canvas.setMarkerLabel(lastPartLabel);
                            } else {
                                lastPartLabel = canvas.getMarkerLabel();
                                canvas.setMarkerLabel(bgLab);
                            }
                            if (canvas.isSubtract()) canvas.setSubtract(false);
                            updateUi();
                        }
                    });
            fondo.setBackgroundResource(onBg ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fondo);
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar rayones", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(markerTrash());
            bar.addView(iconButton(R.drawable.ic_bgerase, "Quitar fondo: queda lo marcado con color", new Runnable() {
                public void run() {
                    canvas.removeBackgroundByMarks();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Separar las partes", new Runnable() {
                public void run() {
                    canvas.separateParts();
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else if (mode == CanvasView.MODE_LINE) {
            bar.addView(iconButton(R.drawable.ic_join, "Unir solas las lineas cortadas", new Runnable() {
                public void run() {
                    canvas.autoJoinLines();
                }
            }));
        } else if (mode == CanvasView.MODE_ZONE || mode == CanvasView.MODE_TONE) {
            bar.addView(iconButton(R.drawable.ic_patch, "Tapar todo lo azul de una vez", new Runnable() {
                public void run() {
                    canvas.fillHoleInSelection();
                }
            }));
        } else if (mode == CanvasView.MODE_SMUDGE || mode == CanvasView.MODE_BLUR) {
            bar.addView(iconButton(R.drawable.ic_range, "Fuerza del efecto", new Runnable() {
                public void run() { effectStrengthDialog(); }
            }));
        } else if (mode == CanvasView.MODE_LIQUIFY) {
            // Barra compacta inspirada en el flujo de ibis: 5 modos accesibles,
            // sin tapar el lienzo con una ficha cada vez que se toca un icono.
            // Los iconos deben poder tocarse sin la etiqueta grande que los
            // comprimia a solo 31dp; descripcion accesible al mantener pulsado.
            final int lt = canvas.getLiquifyType();
            int[] icons = {R.drawable.ic_liq_drag, R.drawable.ic_liq_pinch, R.drawable.ic_liq_expand, R.drawable.ic_liq_smooth, R.drawable.ic_liq_restore};
            String[] names = {"Arrastrar", "Contraer", "Expandir", "Suavizar", "Restaurar"};
            for (int i = 0; i < 5; i++) {
                final int which = i;
                ImageButton b = compactIconButton(icons[i], "Especial: " + names[i], new Runnable() {
                    public void run() {
                        canvas.setLiquifyType(which);
                        updateUi();
                    }
                });
                // La animacion solo aparece al mantener pulsado, no al tocar.
                b.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override public boolean onLongClick(View v) {
                        showDemo(CanvasView.MODE_LIQUIFY, 0);
                        return true;
                    }
                });
                b.setLayoutParams(new LinearLayout.LayoutParams(dp(43), dp(42)));
                b.setPadding(dp(8), dp(8), dp(8), dp(8));
                b.setBackgroundResource(lt == i ? R.drawable.bg_liq_active : R.drawable.bg_liq_idle);
                if (lt == i) b.setColorFilter(0xFF121216);
                bar.addView(b);
            }
            // La fortaleza se controla siempre con el segundo deslizador visible.
            // El boton de ajustes da acceso rapido a la suavidad del borde.
            ImageButton liqSettings = compactIconButton(R.drawable.ic_liq_settings, "Suavidad de deformacion", new Runnable() {
                public void run() { effectSoftnessDialog(); }
            });
            liqSettings.setLayoutParams(new LinearLayout.LayoutParams(dp(43), dp(42)));
            liqSettings.setPadding(dp(8), dp(8), dp(8), dp(8));
            bar.addView(liqSettings);
        } else if (mode == CanvasView.MODE_TRANSFORM) {
            // Transformar como antes: Mover, Perspectiva, Malla y Puntos de anclaje.
            int tt = canvas.getTransformType();
            ImageButton free = compactIconButton(R.drawable.ic_move, "Mover, escalar y girar", new Runnable() {
                public void run() { canvas.setTransformType(0); canvas.showHud("Mover / escalar / girar"); updateUi(); }
            });
            free.setBackgroundResource(tt == 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(free);
            ImageButton persp = compactIconButton(R.drawable.ic_curve, "Perspectiva: 4 esquinas", new Runnable() {
                public void run() { canvas.setTransformType(1); canvas.showHud("Perspectiva: 1 dedo esquinas · 2 dedos mover/zoom"); updateUi(); }
            });
            persp.setBackgroundResource(tt == 1 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(persp);
            ImageButton mesh = compactIconButton(R.drawable.ic_transform, "Malla deformable", new Runnable() {
                public void run() { canvas.setTransformType(2); canvas.showHud("Malla: 1 dedo nodos · 2 dedos mover/zoom"); updateUi(); }
            });
            mesh.setBackgroundResource(tt == 2 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(mesh);
            ImageButton anchors = compactIconButton(R.drawable.ic_anchor_points, "Puntos y anclajes", new Runnable() {
                public void run() { canvas.setTransformType(3); canvas.showHud("Puntos: azul fija · naranja mueve · 2 dedos mover/zoom"); updateUi(); }
            });
            anchors.setBackgroundResource(tt == 3 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(anchors);
            if (tt == 2) {
                bar.addView(compactIconButton(R.drawable.ic_sub, "Malla menos densa", new Runnable() {
                    public void run() { canvas.changeTransformGrid(-1); updateUi(); }
                }));
                TextView gridInfo = new TextView(this);
                gridInfo.setText(canvas.getTransformGridCols() + "x" + canvas.getTransformGridRows());
                gridInfo.setTextColor(0xFFE6E6E6);
                gridInfo.setTextSize(11f);
                gridInfo.setGravity(android.view.Gravity.CENTER);
                gridInfo.setPadding(dp(2), 0, dp(2), 0);
                bar.addView(gridInfo, new LinearLayout.LayoutParams(dp(38), dp(36)));
                bar.addView(compactIconButton(R.drawable.ic_add, "Malla mas densa", new Runnable() {
                    public void run() { canvas.changeTransformGrid(1); updateUi(); }
                }));
                bar.addView(compactIconButton(R.drawable.ic_menu, "Opciones de malla", new Runnable() {
                    public void run() { meshOptionsDialog(); }
                }));
            } else if (tt == 3) {
                final int am = canvas.getTransformAnchorAddMode();
                ImageButton fixed = compactIconButton(R.drawable.ic_anchor_fixed, "Agregar punto fijo azul", new Runnable() {
                    public void run() { canvas.setTransformAnchorAddMode(0); updateUi(); }
                });
                fixed.setBackgroundResource(am == 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(fixed);
                ImageButton movable = compactIconButton(R.drawable.ic_anchor_move, "Agregar punto movil naranja", new Runnable() {
                    public void run() { canvas.setTransformAnchorAddMode(1); updateUi(); }
                });
                movable.setBackgroundResource(am == 1 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(movable);
                bar.addView(compactIconButton(R.drawable.ic_trash, "Eliminar punto seleccionado", new Runnable() {
                    public void run() { canvas.deleteSelectedTransformAnchor(); }
                }));
                bar.addView(compactIconButton(R.drawable.ic_menu, "Mas opciones de puntos", new Runnable() {
                    public void run() { transformAnchorOptionsDialog(); }
                }));
            }
            addTransformApplyCancel(bar);
        } else if (mode == CanvasView.MODE_PUPPET) {
            buildDeformBar(bar);
        } else if (mode == CanvasView.MODE_PAINT) {
            ImageButton ls = iconButton(R.drawable.ic_line_guard, "Proteger contornos negros (no tapar la tinta)", new Runnable() {
                public void run() {
                    boolean on = !canvas.isLineStop();
                    canvas.setLineStop(on);
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("line_stop", on).apply();
                    canvas.showHud(on ? "Proteger contornos: pinta solo la zona donde empiezas y no tapa la tinta"
                            : "Pincel libre: pasa por encima de la linea");
                    updateUi();
                }
            });
            ls.setBackgroundResource(canvas.isLineStop() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            // v8.28: COLOR PLANO o SOMBRA SUAVE a un toque (el tamano no cambia)
            final int curPreset = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset4", 0);
            final TextView style = smallTextButton(curPreset == 1 ? "Suave" : "Plano");
            style.setContentDescription(curPreset == 1 ? "Sombra suave: borde difuminado. Toca para Color plano"
                    : "Color plano: borde definido. Toca para Sombra suave");
            style.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int next = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset4", 0) == 1 ? 0 : 1;
                    applyBrushStyle(next);
                    canvas.showHud(next == 1 ? "Sombra suave: borde difuminado para sombras y degradados"
                            : "Color plano: borde definido y color parejo");
                    updateUi();
                }
            });
            bar.addView(style);
            bar.addView(ls);
            bar.addView(iconButton(R.drawable.ic_ref_color, "Referencia de color: abrir otra imagen y tomar sus colores (no se exporta)", new Runnable() {
                public void run() { requestColorReference(paintColorTarget()); }
            }));
            bar.addView(iconButton(toolIcon(CanvasView.MODE_PAINT), "Pinceles", new Runnable() {
                public void run() {
                    brushPresets();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_layers, "Crear capa Superposicion", new Runnable() {
                public void run() {
                    canvas.addOverlayPaintLayer();
                    updateUi();
                }
            }));
            // v8.33: sombra automatica por direccion de la luz (capa aparte, se corrige a mano)
            bar.addView(iconButton(R.drawable.ic_shadow, "Sombra automatica: elige de donde viene la luz", new Runnable() {
                public void run() { autoShadeDialog(); }
            }));
            if (canvas.isMangaMode()) {
                // v8.26: sombras y luces a un toque mientras se pinta el manga
                // v8.52: Toques suaves (se funden solos, una capa por tipo)
                bar.addView(iconButton(R.drawable.ic_soft, "Toques: rubor, sombra y luz suaves", new Runnable() {
                    public void run() { softOpen(-1); }
                }));
                bar.addView(iconButton(R.drawable.ic_manga, "Colorear manga: mas opciones", new Runnable() {
                    public void run() { mangaMenu(); }
                }));
            }
            bar.addView(destinationChip(false));
        } else if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) {
            bar.addView(iconButton(R.drawable.ic_aim, "Elegir otro origen", new Runnable() {
                public void run() {
                    canvas.resetCloneSource();
                }
            }));
            ImageButton mir = iconButton(R.drawable.ic_mirror, "Espejo", new Runnable() {
                public void run() {
                    canvas.setCloneMirror(!canvas.isCloneMirror());
                    canvas.showHud(canvas.isCloneMirror() ? "Espejo: SI" : "Espejo: NO");
                    updateUi();
                }
            });
            mir.setBackgroundResource(canvas.isCloneMirror() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(mir);
            bar.addView(iconButton(R.drawable.ic_rotate, "Girar el origen", new Runnable() {
                public void run() {
                    cloneAngleDialog();
                }
            }));
        } else {
            bar.setVisibility(View.GONE);
        }
    }

    private void effectStrengthDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF);
        value.setTextSize(18f);
        value.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(95);
        int cur = Math.max(5, Math.round(canvas.getEffectStrength() * 100f));
        bar.setProgress(cur - 5);
        value.setText("Fuerza " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                int x = v + 5;
                canvas.setEffectStrength(x / 100f);
                value.setText("Fuerza " + x + "%");
            }
        });
        root.addView(value);
        root.addView(bar);
        new SheetBuilder(this).setTitle("Fuerza").setView(root).setPositiveButton("Listo", null).show();
    }

    private void effectSoftnessDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF);
        value.setTextSize(18f);
        value.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getEffectSoftness() * 100f)));
        bar.setProgress(cur);
        value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setEffectSoftness(v / 100f);
                value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value);
        root.addView(bar);
        new SheetBuilder(this).setTitle("Suavidad de Especial").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void transformMeshSmoothnessDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(18f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getTransformMeshSmoothness() * 100f)));
        bar.setProgress(cur); value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setTransformMeshSmoothness(v / 100f); value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value); root.addView(bar);
        new SheetBuilder(this).setTitle("Suavidad de malla").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void addTransformApplyCancel(LinearLayout bar) {
        ImageButton cancel = compactIconButton(R.drawable.ic_close, "Cancelar", new Runnable() {
            public void run() { canvas.cancelTransform(); updateUi(); }
        });
        bar.addView(cancel);
        ImageButton ok = compactIconButton(R.drawable.ic_check, "Aplicar", new Runnable() {
            public void run() { canvas.applyTransform(); updateUi(); }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        bar.addView(ok);
    }

    /** Barra de Marioneta (herramienta propia): controles compactos. */
    private void buildDeformBar(LinearLayout bar) {
        ImageButton add = compactIconButton(R.drawable.ic_pin_add, "Poner puntos al tocar", new Runnable() {
            public void run() { canvas.setPuppetAddMode(!canvas.isPuppetAddMode()); updateUi(); }
        });
        add.setBackgroundResource(canvas.isPuppetAddMode() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(add);
        boolean fixedSel = canvas.isPuppetSelectionFixed();
        ImageButton fix = compactIconButton(fixedSel ? R.drawable.ic_anchor_fixed : R.drawable.ic_anchor_move,
                "Fijar / soltar el punto elegido", new Runnable() {
            public void run() { canvas.togglePuppetFixed(); updateUi(); }
        });
        fix.setBackgroundResource(fixedSel ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(fix);
        bar.addView(compactIconButton(R.drawable.ic_trash, "Eliminar el punto elegido", new Runnable() {
            public void run() { canvas.deletePuppetPin(); updateUi(); }
        }));
        ImageButton parts = compactIconButton(R.drawable.ic_puppet_parts, "Mover por partes (lo demas queda quieto)", new Runnable() {
            public void run() {
                boolean on = !canvas.isPuppetByParts();
                canvas.setPuppetByParts(on);
                savePuppetPrefs();
                canvas.showHud(on ? "Por partes: cada punto mueve solo su parte"
                        : "Todo junto: sin puntos fijos, el dibujo entero sigue al punto");
                updateUi();
            }
        });
        parts.setBackgroundResource(canvas.isPuppetByParts() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(parts);
        ImageButton eye = compactIconButton(canvas.isPuppetShowMesh() ? R.drawable.ic_eye : R.drawable.ic_eye_off,
                "Ver malla (solo se dibuja; el motor la usa igual)", new Runnable() {
            public void run() {
                canvas.setPuppetShowMesh(!canvas.isPuppetShowMesh());
                savePuppetPrefs();
                canvas.showHud(canvas.isPuppetShowMesh() ? "Malla visible" : "Malla oculta (el motor la sigue usando)");
                updateUi();
            }
        });
        eye.setBackgroundResource(canvas.isPuppetShowMesh() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(eye);
        bar.addView(compactIconButton(R.drawable.ic_menu, "Opciones de Marioneta", new Runnable() {
            public void run() { puppetOptionsDialog(); }
        }));
        ImageButton cancel = compactIconButton(R.drawable.ic_close, "Cancelar", new Runnable() {
            public void run() { canvas.cancelTransform(); updateUi(); }
        });
        bar.addView(cancel);
        ImageButton ok = compactIconButton(R.drawable.ic_check, "Aplicar", new Runnable() {
            public void run() { applyPuppetChecked(); }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        bar.addView(ok);
    }

    /**
     * v8.27: Aplicar Marioneta. Si el resultado sale del lienzo se pregunta ANTES (con el
     * lienzo nuevo dibujado en azul): ampliar lo justo y aplicar, moverlo dentro (si cabe),
     * aplicar recortando, o seguir editando. Antes solo avisaba y se cortaba al aplicar.
     */
    private void applyPuppetChecked() {
        if (!canvas.isPuppetReady()) {
            canvas.applyTransform();
            updateUi();
            return;
        }
        final int[] m = canvas.puppetOverflow();
        if (m == null) {
            canvas.applyTransform();
            updateUi();
            return;
        }
        final boolean canMove = canvas.puppetCanMoveInside();
        canvas.setCanvasGrowPreview(m);
        StringBuilder sb = new StringBuilder("Una parte del dibujo sale del lienzo");
        sb.append(" (arriba ").append(m[1]).append(" px, abajo ").append(m[3]).append(" px, izquierda ")
                .append(m[0]).append(" px, derecha ").append(m[2]).append(" px, con 8 px de aire).\n\n");
        sb.append("En azul se ve el lienzo ampliado. Ampliar se puede deshacer y tu original no se pierde.");
        final String[] opts = canMove
                ? new String[]{"Ampliar lienzo y aplicar (recomendado)", "Mover el resultado dentro del lienzo (sin deformarlo)",
                        "Aplicar recortando lo que sale", "Seguir editando"}
                : new String[]{"Ampliar lienzo y aplicar (recomendado)", "Aplicar recortando lo que sale", "Seguir editando"};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(8), dp(18), dp(4));
        TextView msgV = new TextView(this);
        msgV.setText(sb.toString());
        msgV.setTextColor(0xFFDDDDDD);
        msgV.setTextSize(13f);
        root.addView(msgV);
        final boolean[] chosen = {false};
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < opts.length; i++) {
            final String it = opts[i];
            TextView row = new TextView(this);
            row.setText(it);
            row.setTextColor(i == 0 ? 0xFF9FC6FF : 0xFFFFFFFF);
            row.setTextSize(15f);
            row.setPadding(dp(4), dp(12), dp(4), dp(12));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    chosen[0] = true;
                    if (dlg[0] != null) dlg[0].dismiss();
                    if (it.startsWith("Ampliar")) {
                        canvas.applyPuppetEnlarged(m);
                    } else if (it.startsWith("Mover")) {
                        canvas.setCanvasGrowPreview(null);
                        canvas.puppetMoveInside();
                    } else if (it.startsWith("Aplicar recortando")) {
                        canvas.setCanvasGrowPreview(null);
                        canvas.applyTransform();
                    } else {
                        canvas.setCanvasGrowPreview(null);
                    }
                    updateUi();
                }
            });
            root.addView(row);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dlg[0] = new SheetBuilder(this).setTitle("Fuera del lienzo").setView(sv).create();
        dlg[0].setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface dd) {
                if (!chosen[0]) canvas.setCanvasGrowPreview(null);
            }
        });
        dlg[0].show();
    }

    private void transformAnchorOptionsDialog() {
        final String[] items = {"Radio de influencia", "Borrar todos los puntos"};
        new SheetBuilder(this)
                .setTitle("Puntos y anclajes")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == 0) transformAnchorRadiusDialog();
                        else if (which == 1) {
                            new SheetBuilder(MainActivity.this)
                                    .setMessage("¿Borrar todos los puntos?")
                                    .setNegativeButton("Cancelar", null)
                                    .setPositiveButton("Borrar", new android.content.DialogInterface.OnClickListener() {
                                        @Override public void onClick(android.content.DialogInterface d, int w) {
                                            canvas.clearTransformAnchors();
                                        }
                                    }).show();
                        }
                    }
                }).show();
    }

    private void transformAnchorRadiusDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(18f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(860);
        int cur = Math.max(40, Math.min(900, Math.round(canvas.getTransformAnchorRadius())));
        bar.setProgress(cur - 40); value.setText("Radio " + cur + " px");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                int px = v + 40;
                canvas.setTransformAnchorRadius(px);
                value.setText("Radio " + px + " px");
            }
        });
        root.addView(value); root.addView(bar);
        new SheetBuilder(this).setTitle("Influencia de los puntos").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void meshOptionsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(16f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getTransformMeshSmoothness() * 100f)));
        bar.setProgress(cur); value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setTransformMeshSmoothness(v / 100f); value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value); root.addView(bar);
        TextView tip = new TextView(this);
        tip.setText("Los nodos se mueven tan lejos como quieras. Solo se detienen si la malla se doblaria sobre si misma.");
        tip.setTextColor(0xFFB8B8C0); tip.setTextSize(12f); tip.setPadding(0, dp(8), 0, 0);
        root.addView(tip);
        new SheetBuilder(this).setTitle("Opciones de Malla").setView(root)
                .setNeutralButton("Restablecer malla", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { canvas.resetMeshGrid(); }
                })
                .setPositiveButton("Listo", null).show();
    }

    private void loadPuppetPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        canvas.setPuppetRigidity(sp.getInt("puppet_rigidity", 1));
        canvas.setPuppetMeshOptions(sp.getInt("puppet_density", 1), sp.getInt("puppet_expansion", 2));
        canvas.setPuppetFoldGuard(sp.getBoolean("puppet_foldguard2", false));
        canvas.setPuppetStiffCells(sp.getFloat("puppet_stiff_cells", 3f));
        canvas.setPuppetByParts(sp.getBoolean("puppet_by_parts", true));
        canvas.setPuppetReachCells(sp.getFloat("puppet_reach_cells", 12f));
        canvas.setPuppetShowMesh(sp.getBoolean("puppet_show_mesh_v834", true));
        canvas.setPuppetMinAlpha(sp.getInt("puppet_min_alpha", 8));
        canvas.setPuppetCharOnly(sp.getBoolean("puppet_char_only", true));
        canvas.setPuppetSmooth(sp.getBoolean("puppet_smooth", true));
    }

    private void savePuppetPrefs() {
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putInt("puppet_rigidity", canvas.getPuppetRigidity())
                .putInt("puppet_density", canvas.getPuppetDensity())
                .putInt("puppet_expansion", canvas.getPuppetExpansion())
                .putBoolean("puppet_foldguard2", canvas.isPuppetFoldGuard())
                .putFloat("puppet_stiff_cells", canvas.getPuppetStiffCells())
                .putBoolean("puppet_by_parts", canvas.isPuppetByParts())
                .putFloat("puppet_reach_cells", canvas.getPuppetReachCells())
                .putBoolean("puppet_show_mesh_v834", canvas.isPuppetShowMesh())
                .putBoolean("puppet_char_only", canvas.isPuppetCharOnly())
                .putBoolean("puppet_smooth", canvas.isPuppetSmooth())
                .putInt("puppet_min_alpha", canvas.getPuppetMinAlpha()).apply();
    }

    private RadioGroup choiceRow(String[] labels, int checked, final IntConsumerCompat onPick) {
        RadioGroup g = new RadioGroup(this);
        g.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < labels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(labels[i]);
            rb.setTextColor(0xFFFFFFFF);
            rb.setTextSize(13f);
            rb.setId(1000 + i);
            g.addView(rb);
        }
        g.check(1000 + checked);
        g.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup group, int id) { onPick.accept(id - 1000); }
        });
        return g;
    }

    /** Equivalente simple de IntConsumer (Android 26 lo tiene, pero asi no dependemos de java.util.function). */
    private interface IntConsumerCompat { void accept(int v); }

    private TextView optLabel(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFF9FC6FF);
        v.setTextSize(12f);
        v.setPadding(0, dp(10), 0, dp(2));
        return v;
    }

    /** Panel plegable de Marioneta: lo avanzado no ocupa la barra. */
    private void puppetOptionsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(6), dp(18), dp(4));
        root.addView(optLabel("Rigidez"));
        root.addView(choiceRow(new String[]{"Flexible", "Normal", "Rigido"}, canvas.getPuppetRigidity(), new IntConsumerCompat() {
            public void accept(int v) { canvas.setPuppetRigidity(v); savePuppetPrefs(); }
        }));
        root.addView(optLabel("Densidad de la malla"));
        root.addView(choiceRow(new String[]{"Menos", "Normal", "Mas"}, canvas.getPuppetDensity(), new IntConsumerCompat() {
            public void accept(int v) { canvas.setPuppetMeshOptions(v, canvas.getPuppetExpansion()); savePuppetPrefs(); }
        }));
        final TextView expL = optLabel("Expansion: " + canvas.getPuppetExpansion() + " px");
        root.addView(expL);
        final SeekBar exp = new SeekBar(this);
        exp.setMax(20);
        exp.setProgress(canvas.getPuppetExpansion());
        exp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) { expL.setText("Expansion: " + v + " px"); }
            @Override public void onStopTrackingTouch(SeekBar s) {
                canvas.setPuppetMeshOptions(canvas.getPuppetDensity(), s.getProgress());
                savePuppetPrefs();
            }
        });
        root.addView(exp);
        final TextView rl = optLabel("Alcance de cada punto (por partes): " + Math.round(canvas.getPuppetReachCells()) + " celdas");
        root.addView(rl);
        SeekBar reach = new SeekBar(this);
        reach.setMax(28);
        reach.setProgress(Math.round(canvas.getPuppetReachCells()) - 2);
        reach.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean fromUser) {
                rl.setText("Alcance de cada punto (por partes): " + (v + 2) + " celdas");
            }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                canvas.setPuppetReachCells(sb.getProgress() + 2);
                savePuppetPrefs();
            }
        });
        root.addView(reach);
        final CheckBox stiff = new CheckBox(this);
        stiff.setText("Proteger la zona del punto elegido (cara, manos)");
        stiff.setTextColor(0xFFFFFFFF);
        stiff.setChecked(canvas.isPuppetSelectionStiff());
        stiff.setEnabled(canvas.hasPuppetSelection());
        stiff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (on != canvas.isPuppetSelectionStiff()) canvas.togglePuppetStiff();
            }
        });
        root.addView(stiff);
        final TextView zl = optLabel("Tamano de la zona protegida: " + Math.round(canvas.getPuppetStiffCells()) + " celdas");
        root.addView(zl);
        SeekBar zone = new SeekBar(this);
        zone.setMax(7);
        zone.setProgress(Math.round(canvas.getPuppetStiffCells()) - 1);
        zone.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                zl.setText("Tamano de la zona protegida: " + (v + 1) + " celdas");
            }
            @Override public void onStopTrackingTouch(SeekBar s) {
                canvas.setPuppetStiffCells(s.getProgress() + 1);
                savePuppetPrefs();
            }
        });
        root.addView(zone);
        CheckBox haze = new CheckBox(this);
        haze.setText("Ignorar restos casi invisibles del recorte (alfa menor a 3 %): malla solo sobre el dibujo");
        haze.setTextColor(0xFFFFFFFF);
        haze.setChecked(canvas.getPuppetMinAlpha() > 1);
        haze.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setPuppetMinAlpha(on ? 8 : 1); savePuppetPrefs(); }
        });
        root.addView(haze);
        CheckBox charOnly = new CheckBox(this);
        charOnly.setText("Solo el personaje: el papel blanco se queda quieto (no se estira la hoja)");
        charOnly.setTextColor(0xFFFFFFFF);
        charOnly.setChecked(canvas.isPuppetCharOnly());
        charOnly.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setPuppetCharOnly(on); savePuppetPrefs(); }
        });
        root.addView(charOnly);
        CheckBox fold = new CheckBox(this);
        fold.setText("Evitar pliegues (el punto se detiene antes de doblar la malla)");
        fold.setTextColor(0xFFFFFFFF);
        fold.setChecked(canvas.isPuppetFoldGuard());
        fold.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setPuppetFoldGuard(on); savePuppetPrefs(); }
        });
        root.addView(fold);
        // v8.83
        CheckBox smooth = new CheckBox(this);
        smooth.setText("Vista fluida (apagala solo si la imagen no se ve al mover)");
        smooth.setTextColor(0xFFFFFFFF);
        smooth.setChecked(canvas.isPuppetSmooth());
        smooth.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setPuppetSmooth(on); savePuppetPrefs(); }
        });
        root.addView(smooth);
        TextView tip = new TextView(this);
        tip.setText("Girar: toca un punto naranja y arrastra su anillo. Rojo = pliegue (se ve aunque la malla este oculta). "
                + "Expansion = margen de seguridad de la malla alrededor del dibujo.");
        tip.setTextColor(0xFFB8B8C0);
        tip.setTextSize(12f);
        tip.setPadding(0, dp(8), 0, 0);
        root.addView(tip);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new SheetBuilder(this).setTitle("Opciones de Marioneta").setView(sv)
                .setNeutralButton("Quitar todos los puntos", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { canvas.resetPuppetPins(); updateUi(); }
                })
                .setPositiveButton("Listo", null).show();
    }

    /**
     * Dilatacion propia de Borrar fondo. Se prende y apaga con un toque;
     * manteniendo presionado se ajusta de 1 en 1. Funciona en vivo mientras
     * pasas el pincel: al soltar no se come nada mas.
     */
    private boolean bgExpOn;
    private int bgExpAmt = 2;
    private static final int EXP_MIN = -3, EXP_MAX = 10;

    private void applyBgExp() {
        canvas.setBgExpansion(bgExpOn ? bgExpAmt : 0f);
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putBoolean("bg_exp_on", bgExpOn).putInt("bg_exp_amt", bgExpAmt).apply();
    }

    // ---- Relleno: opciones guardadas ----
    private boolean fillExpOn = true;
    private int fillExpAmt = 2;

    private void applyFillPrefs() {
        canvas.setFillExpansion(fillExpOn ? fillExpAmt : 0f);
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putBoolean("fill_exp_on", fillExpOn).putInt("fill_exp_amt", fillExpAmt)
                .putInt("fill_tol_v824", canvas.getFillTolerance())
                .putBoolean("fill_shade", canvas.isFillShade())
                .putBoolean("fill_all", canvas.isFillAllLayers())
                .putBoolean("fill_line", canvas.isFillToLine())
                .putInt("fill_target_v827", canvas.getFillTarget())
                .putBoolean("fill_by_lines", canvas.isFillByLines())
                .putBoolean("bucket_preview", canvas.isBucketPreview())
                .putInt("fill_gap", canvas.getGapRadius()).apply();
    }

    private void loadFillPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        fillExpOn = sp.getBoolean("fill_exp_on", true);
        fillExpAmt = sp.getInt("fill_exp_amt", 2);
        // v8.24: la tolerancia ahora es estricta (antes se sumaba la suavidad): nuevo valor inicial
        canvas.setFillTolerance(sp.getInt("fill_tol_v824", 20));
        canvas.setFillShade(sp.getBoolean("fill_shade", false));
        canvas.setFillAllLayers(sp.getBoolean("fill_all", true));
        canvas.setFillToLine(sp.getBoolean("fill_line", true));
        // v8.27: destino del balde. Clave nueva: el "capa aparte" de fabrica de v8.24-8.26
        // creaba Color_1 encima de la capa del usuario. De fabrica: pintar en la capa actual.
        canvas.setFillTarget(sp.getInt("fill_target_v827", CanvasView.FILL_TARGET_CURRENT));
        canvas.setFillByLines(sp.getBoolean("fill_by_lines", false));
        canvas.setBucketPreview(sp.getBoolean("bucket_preview", false));
        canvas.setGap(canvas.isGapOn(), sp.getInt("fill_gap", 4));
        canvas.setFillExpansion(fillExpOn ? fillExpAmt : 0f);
    }

    private static String signed(int v) {
        return (v > 0 ? "+" : "") + v;
    }

    /** Boton de tres puntos para abrir las opciones de al lado. */
    private ImageButton dotsButton(String name, Runnable r) {
        ImageButton b = iconButton(R.drawable.ic_menu, name, r);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(26), dp(38)));
        b.setPadding(dp(2), dp(9), dp(2), dp(9));
        b.setBackground(null);
        return b;
    }

    private void fillToleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getFillTolerance());
        final TextView t = new TextView(this);
        t.setText("Tolerancia " + canvas.getFillTolerance());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta rellena colores mas distintos. Si se sale de la zona, bajala. "
                + "Si quedan puntitos sin pintar, subela un poco.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Tolerancia " + v);
                canvas.setFillTolerance(v);
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                applyFillPrefs();
            }
        });
        // v8.23: el cierre de huecos ya existia (automatico con lineas); aqui se ajusta su tamano.
        final TextView gt = new TextView(this);
        gt.setText(gapText(canvas.getGapRadius()));
        gt.setTextColor(0xFFFFFFFF);
        gt.setTextSize(16f);
        gt.setGravity(android.view.Gravity.CENTER);
        gt.setPadding(0, dp(14), 0, 0);
        final SeekBar gb = new SeekBar(this);
        gb.setMax(9); // niveles 3..12 (el relleno con lineas usa 3 como minimo)
        gb.setProgress(Math.max(3, Math.min(12, canvas.getGapRadius())) - 3);
        TextView gh = new TextView(this);
        gh.setText("Si el color se escapa por un corte de la linea, subelo. Si no llega a rincones finos, bajalo.");
        gh.setTextColor(0xFFAAAAAA);
        gh.setTextSize(12f);
        root.addView(gt);
        root.addView(gb);
        root.addView(gh);
        // v8.24: plano (color exacto) o conservando las sombras del dibujo
        final CheckBox sh = new CheckBox(this);
        sh.setText("Conservar sombras (el color toma las sombras del dibujo)");
        sh.setTextColor(0xFFFFFFFF);
        sh.setChecked(canvas.isFillShade());
        sh.setPadding(0, dp(10), 0, 0);
        sh.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                canvas.setFillShade(on);
                applyFillPrefs();
            }
        });
        root.addView(sh);
        gb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                gt.setText(gapText(v + 3));
                canvas.setGap(canvas.isGapOn(), v + 3);
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                applyFillPrefs();
            }
        });
        new SheetBuilder(this).setView(root).setPositiveButton("OK", null).show();
    }

    private static String gapText(int r) {
        // medido en pruebas: el nivel N cierra cortes de hasta unos 2N px
        return "Cerrar cortes de la linea de hasta " + (r * 2) + " px";
    }

    /** Dilatacion de 1 en 1, para Borrar fondo (fill=false) o Relleno (fill=true). */
    private void expansionDialog(final boolean fill) {
        final int min = fill ? 0 : EXP_MIN;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        // v9.04: sin fondo propio: se ve el fondo un poco transparente de la ventana
        final TextView t = new TextView(this);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(EXP_MAX - min);
        final int cur = fill ? fillExpAmt : bgExpAmt;
        bar.setProgress(cur - min);
        t.setText(expText(cur));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageButton minus = iconButton(R.drawable.ic_sub, "Menos 1", new Runnable() {
            public void run() {
                bar.setProgress(Math.max(0, bar.getProgress() - 1));
                setExp(fill, bar.getProgress() + min, t);
            }
        });
        ImageButton plus = iconButton(R.drawable.ic_add, "Mas 1", new Runnable() {
            public void run() {
                bar.setProgress(Math.min(EXP_MAX - min, bar.getProgress() + 1));
                setExp(fill, bar.getProgress() + min, t);
            }
        });
        row.addView(minus);
        row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(plus);
        TextView hint = new TextView(this);
        hint.setText(fill
                ? "Cuantos pixeles se mete el color debajo del borde de la linea. Asi no queda filo blanco."
                : "Mas alto: se come el borde de color pegado al fondo, sin tocar la linea negra. "
                + "Negativo: deja un poco de borde. Se ve en vivo mientras pasas el dedo.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        hint.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        root.addView(row);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (u) setExp(fill, v + min, t);
            }
        });
        new SheetBuilder(this).setView(root)
                .setNeutralButton("Restablecer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        setExp(fill, 2, null);
                    }
                })
                .setPositiveButton("Listo", null)
                .setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface d) {
                        updateUi();
                    }
                })
                .show();
    }

    private void setExp(boolean fill, int amount, TextView label) {
        if (fill) {
            fillExpAmt = Math.max(0, Math.min(EXP_MAX, amount));
            fillExpOn = true;
            applyFillPrefs();
            if (label != null) label.setText(expText(fillExpAmt));
        } else {
            setBgExp(amount, label);
        }
    }

    /** Al ajustar el valor, la dilatacion queda prendida. */
    private void setBgExp(int amount, TextView label) {
        bgExpAmt = Math.max(EXP_MIN, Math.min(EXP_MAX, amount));
        bgExpOn = true;
        applyBgExp();
        if (label != null) label.setText(expText(bgExpAmt));
    }

    private static String expText(int e) {
        return "Dilatacion " + (e > 0 ? "+" : "") + e + " px";
    }

    /** Tolerancia propia de Borrar fondo: no toca la de la varita. */
    /**
     * v8.27 Refinar borde: descontaminar el color del fondo viejo, contraer/expandir con
     * fracciones de pixel, suavizar solo el borde y quitar restos sueltos. La vista previa
     * es el resultado real en el lienzo; Cancelar deja la capa exacta.
     */
    private void edgeRefineDialog() {
        if (!canvas.beginEdgeRefine()) return;
        final com.pacco.animecut.core.EdgeRefine.Params prm = new com.pacco.animecut.core.EdgeRefine.Params();
        final int picked = canvas.getBgRefColor();
        prm.bg = 0xFFFFFFFF;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(4), dp(18), dp(4));
        final TextView info = smallText("Lo que ves en el lienzo es el resultado. Para revisar usa fondo gris, negro o blanco.");
        root.addView(info);
        root.addView(optLabel("Color del fondo que se borro"));
        root.addView(choiceRow(new String[]{"Blanco", "Negro", String.format(Locale.US, "Tomado #%06X", picked & 0xFFFFFF)}, 0,
                new IntConsumerCompat() {
                    public void accept(int v) {
                        prm.bg = v == 0 ? 0xFFFFFFFF : v == 1 ? 0xFF000000 : picked;
                        edgeRefinePreview(prm, info);
                    }
                }));
        final TextView dl = optLabel("Quitar el color del fondo: 100 %");
        root.addView(dl);
        SeekBar dec = new SeekBar(this);
        dec.setMax(100);
        dec.setProgress(100);
        dec.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                dl.setText("Quitar el color del fondo: " + v + " %");
                prm.decontam = v / 100f;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(dec);
        final TextView sl = optLabel("Contraer / expandir: 0 px");
        root.addView(sl);
        SeekBar sh = new SeekBar(this);
        sh.setMax(16);
        sh.setProgress(8);
        sh.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                float px = (v - 8) * 0.25f;
                prm.shift = px;
                sl.setText("Contraer / expandir: " + (px > 0 ? "+" : "") + String.format(Locale.US, "%.2f", px)
                        + " px" + (px > 0 ? " (come el filo)" : px < 0 ? " (devuelve el filo)" : ""));
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(sh);
        final TextView ml = optLabel("Suavizar solo el borde: 0 %");
        root.addView(ml);
        SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(0);
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                ml.setText("Suavizar solo el borde: " + v + " %");
                prm.smooth = v / 100f;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(sm);
        final TextView rl = optLabel("Quitar restos sueltos de hasta: " + prm.speckle + " px");
        root.addView(rl);
        SeekBar rs = new SeekBar(this);
        rs.setMax(200);
        rs.setProgress(prm.speckle);
        rs.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                rl.setText(v == 0 ? "Quitar restos sueltos: no" : "Quitar restos sueltos de hasta: " + v + " px");
                prm.speckle = v;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(rs);
        CheckBox dark = new CheckBox(this);
        dark.setText("No comerse las lineas oscuras al contraer");
        dark.setTextColor(0xFFFFFFFF);
        dark.setChecked(true);
        dark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                prm.keepDark = on;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(dark);
        root.addView(optLabel("Ver sobre"));
        final int[] bgIdx = {0, 2, 3, 5, 4};
        int curBg = 0;
        for (int k = 0; k < bgIdx.length; k++) if (bgIdx[k] == canvas.getViewBg()) curBg = k;
        root.addView(choiceRow(new String[]{"Cuadros", "Blanco", "Negro", "Gris", "Verde"}, curBg, new IntConsumerCompat() {
            public void accept(int v) {
                canvas.setViewBg(bgIdx[v]);
                if (layersOpen()) buildViewBg();
            }
        }));
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        final boolean[] done = {false};
        AlertDialog d = new SheetBuilder(this).setTitle("Refinar borde").setView(sv)
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dd, int w) {
                        done[0] = true;
                        canvas.cancelEdgeRefine();
                        updateUi();
                    }
                })
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dd, int w) {
                        done[0] = true;
                        canvas.acceptEdgeRefine();
                        updateUi();
                    }
                })
                .create();
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface dd) {
                if (!done[0]) canvas.cancelEdgeRefine();
            }
        });
        if (d.getWindow() != null) {
            // abajo y sin oscurecer: el lienzo con la vista previa queda a la vista
            d.getWindow().setGravity(Gravity.BOTTOM);
            d.getWindow().setDimAmount(0f);
        }
        d.show();
        edgeRefinePreview(prm, info);
    }

    private final Runnable[] edgeRefineJob = new Runnable[1];

    /** Pide la vista previa (con una pausa corta mientras se mueve la barra). */
    private void edgeRefinePreview(final com.pacco.animecut.core.EdgeRefine.Params prm, final TextView info) {
        if (edgeRefineJob[0] != null) opHandler.removeCallbacks(edgeRefineJob[0]);
        edgeRefineJob[0] = new Runnable() {
            @Override public void run() {
                com.pacco.animecut.core.EdgeRefine.Params p = new com.pacco.animecut.core.EdgeRefine.Params();
                p.bg = prm.bg; p.decontam = prm.decontam; p.shift = prm.shift; p.smooth = prm.smooth;
                p.speckle = prm.speckle; p.keepDark = prm.keepDark;
                canvas.previewEdgeRefine(p);
                opHandler.postDelayed(new Runnable() {
                    @Override public void run() {
                        com.pacco.animecut.core.EdgeRefine.Result r = canvas.lastEdgeRefine;
                        if (r != null && canvas.isEdgeRefineActive())
                            info.setText("Cambian " + r.changed + " px: fondo quitado " + r.decontaminated + ", restos " + r.speckles
                                    + ", contraidos " + r.contracted + ", devueltos " + r.expanded + ", suavizados " + r.smoothed);
                    }
                }, 450);
            }
        };
        opHandler.postDelayed(edgeRefineJob[0], 120);
    }

    // ---- v8.27: medir rendimiento en el telefono ----
    private com.pacco.animecut.view.PerfBench perfBench;
    private CanvasView perfCanvas;

    private void perfDialog() {
        final TextView out = new TextView(this);
        out.setTextColor(0xFFE0E0E0);
        out.setTextSize(11f);
        out.setTypeface(android.graphics.Typeface.MONOSPACE);
        out.setTextIsSelectable(true);
        out.setPadding(dp(14), dp(8), dp(14), dp(8));
        String live = com.pacco.animecut.core.PerfStats.report();
        out.setText("Tiempos de TU uso real desde que abriste la app (este telefono):\n"
                + (live.isEmpty() ? "(todavia no hay; pinta un rato y vuelve)\n" : live)
                + "\nMedir: prueba automatica con obras de prueba (tu obra se guarda antes y no se toca). "
                + "Rapida: 720p y 1080p (~1 min). Completa: hasta 4K y A4 (2-4 min). No toques la pantalla mientras corre.");
        ScrollView sv = new ScrollView(this);
        sv.addView(out);
        final AlertDialog d = new SheetBuilder(this).setTitle("Rendimiento").setView(sv)
                .setPositiveButton("Medir completa", null)
                .setNeutralButton("Medir rapida", null)
                .setNegativeButton("Cerrar", null)
                .create();
        d.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface di) {
                d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { startPerfBench(true, out, d); }
                });
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { startPerfBench(false, out, d); }
                });
            }
        });
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface di) { stopPerfBench(); }
        });
        d.show();
    }

    private void startPerfBench(boolean all, final TextView out, final AlertDialog d) {
        if (perfBench != null) return;
        autosave(false);
        ViewGroup host = findViewById(android.R.id.content);
        if (host == null) return;
        perfCanvas = new CanvasView(this);
        perfCanvas.setVisibility(View.INVISIBLE);
        host.addView(perfCanvas, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(false);
        perfBench = new com.pacco.animecut.view.PerfBench(perfCanvas, opHandler, new com.pacco.animecut.view.PerfBench.Listener() {
            @Override public void onProgress(String step) { out.setText("Midiendo... " + step); }

            @Override public void onDone(String report) {
                out.setText(report);
                lastPerfReport = report;
                stopPerfBench();
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setText("Copiar");
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(true);
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("Paint Zeta rendimiento", lastPerfReport));
                        toast("Informe copiado");
                    }
                });
            }
        });
        // la vista se mide y se coloca en el siguiente cuadro; luego empieza
        opHandler.postDelayed(new Runnable() {
            @Override public void run() { if (perfBench != null) perfBench.start(all); }
        }, 120);
    }

    private String lastPerfReport = "";

    private void stopPerfBench() {
        if (perfBench != null) perfBench.cancel();
        perfBench = null;
        if (perfCanvas != null) {
            ViewGroup parent = (ViewGroup) perfCanvas.getParent();
            if (parent != null) parent.removeView(perfCanvas);
            perfCanvas = null;
        }
    }

    private void bgToleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getBgTolerance());
        final TextView t = new TextView(this);
        t.setText("Tolerancia " + canvas.getBgTolerance());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta borra mas de golpe. Si se come el dibujo, bajala.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Tolerancia " + v);
                canvas.setBgTolerance(v);
                if (u) getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_tol", v).apply();
            }
        });
        new SheetBuilder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Suavidad independiente: crea una transicion de alfa en el borde en vez de un corte duro. */
    private void bgSoftnessDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getBgSoftness());
        final TextView t = new TextView(this);
        t.setText("Suavidad " + canvas.getBgSoftness());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta suaviza el borde y ayuda a quitar halos. Si queda demasiado transparente, bajala.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Suavidad " + v);
                canvas.setBgSoftness(v);
                if (u) getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_soft", v).apply();
            }
        });
        // v8.23: limpieza del filo (quita el color del fondo del borde del personaje).
        final CheckBox dc = new CheckBox(this);
        dc.setText("Limpiar el filo (sin franja del color del fondo)");
        dc.setTextColor(0xFFFFFFFF);
        dc.setChecked(canvas.isBgDecontam());
        dc.setPadding(0, dp(10), 0, 0);
        dc.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                canvas.setBgDecontam(on);
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("bg_decontam", on).apply();
            }
        });
        root.addView(dc);
        new SheetBuilder(this).setView(root).setPositiveButton("OK", null).show();
    }

    private void cloneAngleDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(360);
        bar.setProgress(Math.round(canvas.getCloneAngle()) + 180);
        final TextView t = new TextView(this);
        t.setText(Math.round(canvas.getCloneAngle()) + "°");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int a = v - 180;
                for (int snap : new int[]{-180, -90, 0, 90, 180}) if (Math.abs(a - snap) <= 4) a = snap;
                t.setText(a + "°");
                canvas.setCloneAngle(a);
            }
        });
        new SheetBuilder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Lazo: el usuario puede crear directamente una capa sin buscar Copiar. */
    /** v8.28: colorear manga en una capa Normal tapa tramas y grises: se ofrece Multiplicar. */
    @Override public void onSuggestMultiply(final Layer l) {
        if (l == null || isFinishing()) return;
        new SheetBuilder(this)
                .setTitle("Conservar tramas y sombras")
                .setMessage("Vas a pintar color sobre un dibujo en blanco y negro. Con la capa \"" + l.name
                        + "\" en Normal, el color TAPA los grises, las tramas y las sombras.\n\n"
                        + "En Multiplicar el color queda debajo de la tinta y se siguen viendo. "
                        + "Lo que ya pintaste en esta capa tambien cambia (se puede deshacer).")
                .setPositiveButton("Usar Multiplicar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.setLayerMode(l, Layer.MODE_MULTIPLY);
                        canvas.showHud("\"" + l.name + "\" en Multiplicar: se ven las tramas debajo del color");
                        markDirty();
                        updateUi();
                        canvas.resumeSuggestedFill();
                    }
                })
                .setNegativeButton("Dejar Normal", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.resumeSuggestedFill();
                    }
                })
                .setNeutralButton("No preguntar mas", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.setSuggestMultiply(false);
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("suggest_multiply", false).apply();
                        canvas.resumeSuggestedFill();
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface d) {
                        canvas.resumeSuggestedFill();
                    }
                })
                .show();
    }

    @Override public void onLassoCompleted() {
        if (!destroyed && canvas.getProject() != null && canvas.getProject().hasSelection()) {
            if (canvas.isMangaMode()) mangaLassoDialog();
            else partFromSelectionDialog(false);
        }
    }

    // ==================================================================
    // Menu de seleccion (cuadro punteado de arriba)
    // ==================================================================

    private void selectionMenu() {
        if (!needProject()) return;
        int[] icons = {R.drawable.ic_layer_add, R.drawable.ic_sel_delete, R.drawable.ic_clone,
                R.drawable.ic_sel_keep, R.drawable.ic_sel_invert, R.drawable.ic_close};
        String[] names = {"Copiar a capa", "Cortar a capa", "Duplicar capa", "Dejar solo esto",
                "Invertir", "Quitar azul"};
        Runnable[] actions = {
                new Runnable() { public void run() { partFromSelectionDialog(false); } },
                new Runnable() { public void run() { partFromSelectionDialog(true); } },
                new Runnable() { public void run() { canvas.duplicateActive(); updateUi(); } },
                new Runnable() { public void run() { canvas.keepSelectionInLayer(); } },
                new Runnable() { public void run() { canvas.invertSelection(); } },
                new Runnable() { public void run() { canvas.clearSelection(); } }
        };
        demoNext = new int[]{SelDemoView.COPY, SelDemoView.CUT, SelDemoView.DUP, SelDemoView.KEEP,
                SelDemoView.INVERT, SelDemoView.CLEAR};
        showIconGrid(null, icons, names, actions, 3, -1);
        demoNext = null;
    }

    /** Crear una parte con nombre y solapamiento listos para Alight Motion. */
    private void partFromSelectionDialog(final boolean cut) {
        Project p = canvas.getProject();
        if (p == null || !p.hasSelection()) {
            toast("Primero marca en azul la parte");
            return;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(8), dp(16), dp(4));

        TextView hint = new TextView(this);
        hint.setText("El solapamiento deja unos pixeles escondidos para que al mover la parte no aparezcan huecos.");
        hint.setTextColor(0xFFCCCCCC);
        hint.setTextSize(12.5f);
        root.addView(hint);

        final String[] names = {"parte", "cabeza", "cabello_frontal", "cabello_trasero",
                "brazo_I", "brazo_D", "mano_I", "mano_D", "torso", "pierna_I", "pierna_D"};
        final android.widget.Spinner spin = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> ad = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, names);
        spin.setAdapter(ad);
        root.addView(spin);

        final TextView ovText = new TextView(this);
        final SeekBar ov = new SeekBar(this);
        ov.setMax(12);
        ov.setProgress(6);
        ovText.setText("Solapamiento para animar: 6 px");
        ov.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar b, int v, boolean u) {
                ovText.setText("Solapamiento para animar: " + v + " px");
            }
        });
        root.addView(ovText);
        root.addView(ov);

        new SheetBuilder(this)
                .setTitle("Separar parte para animar")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton(cut ? "Cortar" : "Copiar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        finishPartExtraction(cut, ov.getProgress(), names[spin.getSelectedItemPosition()]);
                    }
                })
                .setNeutralButton(cut ? "Copiar" : "Cortar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        finishPartExtraction(!cut, ov.getProgress(), names[spin.getSelectedItemPosition()]);
                    }
                }).show();
    }

    /** Copiar conserva la fuente. Cortar deja el hueco para reparar después. */
    private void finishPartExtraction(boolean cut, int overlap, String name) {
        Project p = canvas.getProject();
        if (p == null) return;
        int before = p.layers.size();
        canvas.layerFromSelection(cut, overlap, name);
        if (p.layers.size() > before) {
            canvas.clearTemporarySelectionAfterCopy();
            canvas.showHud(cut ? "Parte separada. Revisa el hueco de la capa original"
                    : "Capa copiada sin borrar la imagen original");
        }
        updateUi();
        if (layersOpen()) buildLayersPanel();
    }

    private int[] demoNext;
    private int lastPartLabel = 1;
    private ImageButton wandGear;

    private static final String[][] SEL_INFO = {
            {"Copiar a capa", "Copia lo azul a una capa nueva. La imagen queda igual."},
            {"Cortar a capa", "Saca lo azul a una capa nueva y lo borra de la capa original."},
            {"Duplicar capa", "Hace una copia de la capa entera."},
            {"Dejar solo esto", "Borra todo lo que no esta en azul, en la capa elegida."},
            {"Invertir", "Lo azul pasa a no azul y al reves. Elige el fondo con la varita e invierte para quedarte con el personaje."},
            {"Quitar azul", "Borra la seleccion. Los dibujos no se tocan."},
            {"Ampliar", "Agranda lo azul unos pixeles hacia afuera."},
            {"Refinar borde", "Ajusta el borde azul al dibujo real. Para pelo y bordes finos."},
            {"Cerrar puntos", "Rellena los huequitos que quedaron sin azul dentro de la seleccion."},
            {"Gama color", "Selecciona todos los pixeles de un color parecido en toda la imagen."},
            {"Tapar hueco", "Rellena lo azul con el color de al lado y une la linea negra. Usalo en el cuerpo despues de sacar un brazo."},
            {"Cerrar tijeras", "Cierra el contorno que marcaste con las tijeras y lo vuelve azul."},
            {"Varita que no se escapa", "La varita respeta la linea negra aunque tenga cortes chicos. Se prende y apaga en el menu de tres puntos."},
            {"Separar partes", "Raya cada parte con un color (pelo, cuerpo, brazo) y el fondo en gris. Toca el check y cada parte sale en su capa, cortada sobre la linea negra."}
    };

    /** Ficha con la animacion de antes y despues. */
    private void showSelCard(int scene) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        // v9.04: sin fondo propio: se ve el fondo un poco transparente de la ventana
        TextView title = new TextView(this);
        title.setText(SEL_INFO[scene][0]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        SelDemoView art = new SelDemoView(this, scene);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(200), dp(200));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        root.addView(cardLine("", SEL_INFO[scene][1]));
        new SheetBuilder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    // ==================================================================
    // Panel de capas, como Ibis
    // ==================================================================

    private void toggleLayersPanel() {
        if (!needProject()) return;
        View panel = findViewById(R.id.layersPanel);
        if (panel.getVisibility() == View.VISIBLE) {
            closeLayers();
        } else {
            closeTools();
            if (modePop != null && modePop.isShowing()) modePop.dismiss();
            panel.setVisibility(View.VISIBLE);
            hideCards(true);
            hideForLayers(true);
            setupLayersHandle();
            applyLayersHeight();
            buildLayersPanel();
            scrollToActiveLayer();
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            if (!sp.getBoolean("hint_layer_drag", false)) {
                sp.edit().putBoolean("hint_layer_drag", true).apply();
                toast("Arrastra las rayitas de la derecha para subir o bajar una capa. Toca la capa elegida para cambiarle el nombre.");
            }
        }
    }

    // ------------------------------------------------------------------
    // v8.57 panel de capas compacto: la lista ocupa ~1/8 de la pantalla (antes 270 dp, casi la
    // mitad con los botones). El tirador "Más/Menos" la agranda a ~1/3 y la vuelve a achicar
    // (se recuerda). Con muchas capas la lista se desplaza por dentro y no crece hacia arriba.
    // ------------------------------------------------------------------

    // v8.59: el panel de capas se estira con el dedo (tirador arriba), como maximo hasta la mitad
    // de la pantalla. El alto elegido se guarda y vuelve igual al abrir la app.
    private View layersGrip;

    private void setupLayersHandle() {
        if (layersGrip != null) return;
        final View panel = findViewById(R.id.layersPanel);
        if (!(panel instanceof LinearLayout)) return;
        FrameLayout grip = new FrameLayout(this);
        View bar = new View(this);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(0xCCFFFFFF);
        g.setCornerRadius(dp(3));
        bar.setBackground(g);
        grip.addView(bar, new FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER));
        ((LinearLayout) panel).addView(grip, 0, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20)));
        layersGrip = grip;
        grip.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            int h0;

            @Override public boolean onTouch(View v, MotionEvent e) {
                View list = findViewById(R.id.layersScroll);
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        y0 = e.getRawY();
                        h0 = list.getHeight();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        setLayersListHeight(h0 + Math.round(y0 - e.getRawY()), false);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        setLayersListHeight(list.getHeight(), true);
                        scrollToActiveLayer();
                        return true;
                }
                return false;
            }
        });
    }

    /** Alto de la lista, entre una fila y lo que deja el panel en la mitad de la pantalla. */
    private void setLayersListHeight(int hList, boolean save) {
        int screenH = getResources().getDisplayMetrics().heightPixels;
        View panel = findViewById(R.id.layersPanel), list = findViewById(R.id.layersScroll);
        int other = panel.getHeight() > 0 ? panel.getHeight() - list.getHeight() : dp(170);
        int max = Math.max(dp(80), screenH / 2 - other);
        hList = Math.max(dp(64), Math.min(max, hList));
        for (int id : new int[]{R.id.layersScroll, R.id.layersSideScroll}) {
            View v = findViewById(id);
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            if (lp.height != hList) { lp.height = hList; v.setLayoutParams(lp); }
        }
        if (save) getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("layers_list_h", hList).apply();
    }

    private void applyLayersHeight() {
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int saved = getSharedPreferences("pz", MODE_PRIVATE).getInt("layers_list_h", 0);
        setLayersListHeight(saved > 0 ? saved : Math.max(dp(110), screenH / 5), false);
    }

    /** Deja a la vista la capa elegida (la lista se mueve por dentro). */
    private void scrollToActiveLayer() {
        final ScrollView sc = findViewById(R.id.layersScroll);
        sc.post(new Runnable() {
            @Override public void run() {
                Project p = canvas.getProject();
                if (p == null) return;
                Layer a = p.activeLayer();
                RowHolder h = a == null ? null : rowHolders.get(a);
                if (h == null || h.row.getParent() == null) return;
                int top = h.row.getTop(), bottom = h.row.getBottom();
                int y = sc.getScrollY(), vh = sc.getHeight();
                if (top < y) sc.smoothScrollTo(0, Math.max(0, top - dp(4)));
                else if (bottom > y + vh) sc.smoothScrollTo(0, bottom - vh + dp(4));
            }
        });
    }

    private void closeLayers() {
        if (layerDrag != null) layerDrag.cancel();
        findViewById(R.id.layersPanel).setVisibility(View.GONE);
        canvas.setCompactHold(false);
        hideForLayers(false);
        if (findViewById(R.id.toolPanel).getVisibility() != View.VISIBLE) hideCards(false);
        updateUi();
    }

    private void hideForLayers(boolean hide) {
        int v = hide ? View.GONE : View.VISIBLE;
        findViewById(R.id.sizeRow).setVisibility(v);
        findViewById(R.id.opacityRow).setVisibility(v);
        if (hide) {
            findViewById(R.id.selBar).setVisibility(View.GONE);
            findViewById(R.id.optBar).setVisibility(View.GONE);
        }
    }

    private boolean layersOpen() {
        return findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE;
    }

    // ------------------------------------------------------------------
    // Filas de capas: se crean una vez y despues solo se actualizan.
    // Antes se borraba y rehacia todo el panel en cada toque (y las
    // miniaturas tambien), por eso se trababa.
    // ------------------------------------------------------------------

    private static final class RowHolder {
        Layer layer;
        LinearLayout row;
        ImageView thumb;
        TextView text;
        ImageButton eye;
        ImageButton clip;      // v8.39: flecha de recorte (pintar solo dentro de la capa de abajo)
        LinearLayout quick;    // v8.45: 3 botones junto a las rayitas (solo en la capa elegida)
        ImageButton qClip, qMul;
    }

    private final java.util.IdentityHashMap<Layer, RowHolder> rowHolders = new java.util.IdentityHashMap<Layer, RowHolder>();
    private final java.util.IdentityHashMap<Layer, Bitmap> thumbCache = new java.util.IdentityHashMap<Layer, Bitmap>();
    private final java.util.concurrent.ExecutorService thumbPool = java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean thumbsBusy, thumbsAgain, layerActionsBuilt, opacityRowReady, panelRefreshing;
    private LayerDrag layerDrag;
    private LinearLayout selectionPanelRow;
    private TextView selectionPanelText;

    private void buildLayersPanel() {
        final Project p = canvas.getProject();
        if (p == null || panelRefreshing) return;
        if (layerDrag != null && layerDrag.active) return;
        panelRefreshing = true;
        try {
            buildViewBg();
            setupOpacityRow();
            updateOpacityRow();

            LinearLayout list = findViewById(R.id.layersList);
            java.util.IdentityHashMap<Layer, Boolean> alive = new java.util.IdentityHashMap<Layer, Boolean>();
            for (Layer l : p.layers) alive.put(l, Boolean.TRUE);
            for (Layer l : new ArrayList<Layer>(rowHolders.keySet()))
                if (!alive.containsKey(l)) rowHolders.remove(l);
            for (Layer l : new ArrayList<Layer>(thumbCache.keySet())) {
                if (!alive.containsKey(l)) {
                    Bitmap old = thumbCache.remove(l);
                    if (old != null && !old.isRecycled()) old.recycle();
                }
            }

            boolean hasMask = p.hasSelection();
            if (hasMask) ensureSelectionPanelRow();
            int n = p.layers.size(), offset = hasMask ? 1 : 0;
            boolean same = list.getChildCount() == n + offset
                    && (!hasMask || list.getChildAt(0) == selectionPanelRow);
            for (int pos = 0; pos < n; pos++) {
                Layer l = p.layers.get(n - 1 - pos);
                RowHolder h = rowHolders.get(l);
                if (h == null) {
                    h = makeRow(l);
                    rowHolders.put(l, h);
                    same = false;
                } else if (same && list.getChildAt(pos + offset) != h.row) {
                    same = false;
                }
            }
            if (!same) {
                list.removeAllViews();
                if (hasMask) list.addView(selectionPanelRow);
                for (int pos = 0; pos < n; pos++) {
                    RowHolder h = rowHolders.get(p.layers.get(n - 1 - pos));
                    h.row.setTranslationY(0f);
                    list.addView(h.row);
                }
            }
            if (hasMask) bindSelectionPanelRow(p);
            for (int i = 0; i < n; i++) bindRow(rowHolders.get(p.layers.get(i)), i == p.active);
            if (!layerActionsBuilt) {
                buildLayerActions();
                layerActionsBuilt = true;
            }
        } finally {
            panelRefreshing = false;
        }
        requestThumbs();
    }

    private void ensureSelectionPanelRow() {
        if (selectionPanelRow != null) return;
        selectionPanelRow = rowBase(false);
        ImageView icon = thumb(null);
        icon.setImageResource(R.drawable.ic_select);
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));
        selectionPanelText = rowText("Seleccion", "Lo azul", true);
        ImageButton clear = iconButton(R.drawable.ic_close, "Quitar seleccion", new Runnable() {
            @Override public void run() {
                canvas.clearSelection();
                buildLayersPanel();
            }
        });
        clear.setBackground(null);
        selectionPanelRow.addView(icon);
        selectionPanelRow.addView(selectionPanelText);
        selectionPanelRow.addView(clear);
        selectionPanelRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Project p = canvas.getProject();
                if (p == null) return;
                canvas.setActive(Project.SEL);
                buildLayersPanel();
            }
        });
    }

    private void bindSelectionPanelRow(Project p) {
        if (selectionPanelRow == null || p == null) return;
        boolean on = p.active == Project.SEL;
        selectionPanelRow.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        selectionPanelText.setText("Seleccion\n" + (p.hasSelection() ? "Azul activo - toca para editar" : "Vacia - pinta o usa Varita"));
        selectionPanelText.setTextColor(p.hasSelection() ? 0xFFFFFFFF : 0xFF9A9A9A);
    }

    private void bindRow(RowHolder h, boolean on) {
        Layer l = h.layer;
        h.row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        h.row.setPadding(dp(6), dp(6), dp(2), dp(6));
        StringBuilder sub = new StringBuilder();
        sub.append(l.opacity * 100 / 255).append('%');
        if (l.mode != Layer.MODE_NORMAL) sub.append("  ").append(Layer.MODE_NAMES[l.mode]);
        if (l.alphaLock) sub.append("  alfa bloq.");
        if (l.reference) sub.append("  ref. balde");
        if (l.locked) sub.append("  BLOQUEADA");
        if (l.hasAdjust()) sub.append("  color cambiado");
        h.text.setText(l.name + "\n" + sub);
        // v8.39: flecha de recorte como en Ibis (encendida = pinta solo dentro de la de abajo)
        Project pj = canvas.getProject();
        boolean bottom = pj == null || pj.layers.indexOf(l) <= 0;
        // v8.45: la flecha de la izquierda solo se ve si esta puesta (se pone con los botones de la derecha)
        h.clip.setVisibility(!bottom && l.clip ? View.VISIBLE : View.GONE);
        if (h.quick != null) {
            h.quick.setVisibility(on ? View.VISIBLE : View.GONE);
            h.qClip.setVisibility(bottom ? View.GONE : View.VISIBLE);
            h.qClip.setColorFilter(l.clip ? 0xFF7FE0D4 : 0xFFFFFFFF);
            h.qClip.setBackgroundResource(l.clip ? R.drawable.bg_tool_on : 0);
            boolean mul = l.mode == Layer.MODE_MULTIPLY;
            h.qMul.setColorFilter(mul ? 0xFF7FE0D4 : 0xFFFFFFFF);
            h.qMul.setBackgroundResource(mul ? R.drawable.bg_tool_on : 0);
        }
        h.clip.setColorFilter(l.clip ? 0xFF7FE0D4 : 0xFFFFFFFF);
        h.clip.setAlpha(l.clip ? 1f : 0.35f);
        h.clip.setBackgroundResource(l.clip ? R.drawable.bg_tool_on : 0);
        // la capa con recorte va corrida a la derecha, como en Ibis
        ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) h.row.getLayoutParams();
        int want = l.clip ? dp(18) : 0;
        if (mlp != null && mlp.leftMargin != want) {
            mlp.leftMargin = want;
            h.row.setLayoutParams(mlp);
        }
        h.text.setTextColor(l.visible ? 0xFFFFFFFF : 0xFF7A7A7A);
        h.eye.setImageResource(l.visible ? R.drawable.ic_eye : R.drawable.ic_eye_off);
        h.eye.setContentDescription(l.visible ? "Ocultar" : "Mostrar");
        Bitmap tb = thumbCache.get(l);
        if (tb != null && h.thumb.getTag() != tb) {
            h.thumb.setImageBitmap(tb);
            h.thumb.setTag(tb);
        }
    }

    /** v8.45: boton chico de la fila de capa (mantener = dice que hace). */
    private ImageButton quickBtn(int icon, final String what, final Runnable r) {
        ImageButton b = iconButton(icon, what, r);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(40)));
        b.setPadding(dp(7), dp(10), dp(7), dp(10));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setBackground(null);
        return b;
    }

    private RowHolder makeRow(final Layer l) {
        final RowHolder h = new RowHolder();
        h.layer = l;
        h.row = rowBase(false);
        h.thumb = thumb(null);
        h.thumb.setBackgroundColor(0xFF3A3A40);
        h.text = rowText(l.name, "", true);
        h.eye = iconButton(R.drawable.ic_eye, "Ocultar o mostrar", new Runnable() {
            public void run() {
                canvas.recordPropsUndo(l.visible ? "Ocultar capa" : "Mostrar capa");
                l.visible = !l.visible;
                bindRow(h, canvas.getProject().activeLayer() == l);
                canvas.layersChangedAsync();
            }
        });
        h.eye.setBackground(null);
        h.clip = iconButton(R.drawable.ic_clip, "Flecha: pintar solo dentro de la capa de abajo", new Runnable() {
            public void run() {
                Project pj = canvas.getProject();
                if (pj == null) return;
                boolean on = !l.clip;
                canvas.setLayerClip(l, on);
                if (l.clip == on) canvas.showHud(on ? "Flecha: solo dentro de la capa de abajo" : "Sin flecha: pinta libre", 1600);
                bindRow(h, pj.activeLayer() == l);
            }
        });
        h.clip.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(44)));
        h.clip.setPadding(dp(4), dp(10), dp(4), dp(10));
        h.clip.setBackground(null);
        ImageView handle = new ImageView(this);
        handle.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(48)));
        handle.setPadding(dp(8), dp(12), dp(8), dp(12));
        handle.setScaleType(ImageView.ScaleType.FIT_CENTER);
        handle.setImageResource(R.drawable.ic_drag);
        handle.setContentDescription("Arrastra para subir o bajar la capa");
        h.row.addView(h.clip);
        h.row.addView(h.thumb);
        h.row.addView(h.text);
        h.row.addView(h.eye);
        h.quick = new LinearLayout(this);
        h.quick.setOrientation(LinearLayout.HORIZONTAL);
        h.quick.setGravity(Gravity.CENTER_VERTICAL);
        h.qClip = quickBtn(R.drawable.ic_clip, "Flecha: pintar solo dentro de la capa de abajo", new Runnable() {
            public void run() {
                Project pj = canvas.getProject();
                if (pj == null) return;
                boolean on = !l.clip;
                canvas.setLayerClip(l, on);
                canvas.showHud(l.clip ? "Flecha: solo dentro de la capa de abajo" : "Flecha quitada", 1600);
                bindRow(h, pj.activeLayer() == l);
            }
        });
        h.qMul = quickBtn(R.drawable.ic_paint, "Colorear B/N: el color no tapa las lineas negras (Multiplicar)", new Runnable() {
            public void run() {
                Project pj = canvas.getProject();
                if (pj == null) return;
                boolean mul = l.mode == Layer.MODE_MULTIPLY;
                canvas.setLayerMode(l, mul ? Layer.MODE_NORMAL : Layer.MODE_MULTIPLY);
                canvas.showHud(mul ? "Modo Normal" : "Colorear B/N: el color no tapa las lineas", 1800);
                bindRow(h, pj.activeLayer() == l);
            }
        });
        ImageButton qMore = quickBtn(R.drawable.ic_menu, "Mas opciones de la capa", new Runnable() {
            public void run() { layerOptions(l); }
        });
        h.quick.addView(h.qClip);
        h.quick.addView(h.qMul);
        h.quick.addView(qMore);
        h.row.addView(h.quick);
        h.row.addView(handle);
        h.row.setOnTouchListener(new RowTouch(h, false));
        handle.setOnTouchListener(new RowTouch(h, true));
        return h;
    }

    /** Toque corto: elige la capa (o abre sus opciones si ya era la elegida). Mantener: arrastrar. */
    private void onRowTap(RowHolder h) {
        Project p = canvas.getProject();
        if (p == null) return;
        int idx = p.layers.indexOf(h.layer);
        if (idx < 0) return;
        if (idx == p.active) layerOptions(h.layer);
        else canvas.setActive(idx); // avisa por onChanged y el panel se actualiza solo
    }

    private final class RowTouch implements View.OnTouchListener {
        final RowHolder h;
        final boolean handle;
        float downX, downY, lastY;
        boolean pressed, dragging;
        final Runnable longPress;

        RowTouch(final RowHolder h, boolean handle) {
            this.h = h;
            this.handle = handle;
            longPress = new Runnable() {
                @Override
                public void run() {
                    if (pressed && !dragging) {
                        dragging = true;
                        h.row.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        startDrag(h, lastY);
                    }
                }
            };
        }

        @Override
        public boolean onTouch(View v, android.view.MotionEvent e) {
            int slop = android.view.ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = lastY = e.getRawY();
                    pressed = true;
                    dragging = false;
                    if (handle) {
                        dragging = true;
                        startDrag(h, lastY);
                    } else {
                        h.row.postDelayed(longPress, android.view.ViewConfiguration.getLongPressTimeout());
                    }
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    lastY = e.getRawY();
                    if (dragging) {
                        if (layerDrag != null) layerDrag.move(lastY);
                    } else if (Math.abs(e.getRawX() - downX) > slop || Math.abs(lastY - downY) > slop) {
                        pressed = false;
                        h.row.removeCallbacks(longPress);
                    }
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                    h.row.removeCallbacks(longPress);
                    boolean tapHandle = handle && Math.abs(e.getRawX() - downX) <= slop && Math.abs(e.getRawY() - downY) <= slop;
                    if (dragging) {
                        if (layerDrag != null) layerDrag.finish();
                        // v8.45: las opciones ya estan a la vista junto a las rayitas
                    } else if (pressed && !handle) {
                        onRowTap(h);
                    }
                    pressed = dragging = false;
                    return true;
                case android.view.MotionEvent.ACTION_CANCEL:
                    h.row.removeCallbacks(longPress);
                    if (dragging && layerDrag != null) layerDrag.finish();
                    pressed = dragging = false;
                    return true;
            }
            return false;
        }
    }

    private void startDrag(RowHolder h, float rawY) {
        if (layerDrag != null && layerDrag.active) return;
        layerDrag = new LayerDrag(h, rawY);
    }

    /** Arrastrar una capa como en Ibis: las demas se corren para hacerle espacio. */
    private final class LayerDrag {
        final RowHolder h;
        final LinearLayout list;
        final ScrollView scroll;
        final float startY;
        final int startScroll, from, n;
        final float pitch;
        int to;
        boolean active = true;

        LayerDrag(RowHolder h, float rawY) {
            this.h = h;
            list = findViewById(R.id.layersList);
            scroll = findViewById(R.id.layersScroll);
            startY = rawY;
            startScroll = scroll.getScrollY();
            from = to = list.indexOfChild(h.row);
            n = list.getChildCount();
            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) h.row.getLayoutParams();
            pitch = h.row.getHeight() + lp.topMargin + lp.bottomMargin;
            scroll.requestDisallowInterceptTouchEvent(true);
            canvas.setCompactHold(true);
            h.row.setElevation(dp(10));
            h.row.animate().scaleX(1.03f).scaleY(1.03f).alpha(0.94f).setDuration(90).start();
            if (from < 0 || pitch <= 0) active = false;
        }

        void move(float rawY) {
            if (!active) return;
            int[] loc = new int[2];
            scroll.getLocationOnScreen(loc);
            float yIn = rawY - loc[1];
            int edge = dp(40);
            if (yIn < edge) scroll.scrollBy(0, -dp(12));
            else if (yIn > scroll.getHeight() - edge) scroll.scrollBy(0, dp(12));
            float dy = (rawY - startY) + (scroll.getScrollY() - startScroll);
            // La fila 0 es la capa Seleccion y no forma parte del orden de capas.
            // Nunca dejamos que una capa normal se arrastre por encima de ella.
            int firstLayerRow = selectionPanelRow != null && list.getChildAt(0) == selectionPanelRow ? 1 : 0;
            float min = (firstLayerRow - from) * pitch, max = (n - 1 - from) * pitch;
            if (dy < min) dy = min;
            if (dy > max) dy = max;
            h.row.setTranslationY(dy);
            int t = Math.round(from + dy / pitch);
            t = Math.max(firstLayerRow, Math.min(n - 1, t));
            if (t == to) return;
            to = t;
            for (int k = 0; k < n; k++) {
                if (k == from) continue;
                View c = list.getChildAt(k);
                float want = 0f;
                if (from < to && k > from && k <= to) want = -pitch;
                else if (from > to && k >= to && k < from) want = pitch;
                if (c.getTranslationY() != want) c.animate().translationY(want).setDuration(110).start();
            }
        }

        void finish() {
            if (!active) return;
            active = false;
            float dy = h.row.getTranslationY();
            for (int k = 0; k < list.getChildCount(); k++) {
                View c = list.getChildAt(k);
                c.animate().cancel();
                if (c != h.row) c.setTranslationY(0f);
            }
            if (to != from && from >= 0) {
                list.removeView(h.row);
                list.addView(h.row, to);
                h.row.setTranslationY(dy - (to - from) * pitch);
                int fromIdx = n - 1 - from, toIdx = n - 1 - to;
                canvas.moveLayer(fromIdx, toIdx);
            }
            h.row.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(1f).setDuration(120)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            h.row.setElevation(0f);
                        }
                    }).start();
            canvas.setCompactHold(false);
            buildLayersPanel();
        }

        void cancel() {
            if (!active) return;
            to = from;
            finish();
        }
    }

    /** Miniaturas en segundo plano: se ve la anterior hasta que llega la nueva. */
    private void requestThumbs() {
        if (!layersOpen()) return;
        if (thumbsBusy) {
            thumbsAgain = true;
            return;
        }
        final Project p = canvas.getProject();
        if (p == null) return;
        thumbsBusy = true;
        thumbsAgain = false;
        final List<Layer> ls = new ArrayList<Layer>(p.layers);
        final Bitmap[] out = new Bitmap[ls.size()];
        thumbPool.execute(new Runnable() {
            @Override
            public void run() {
                for (int k = 0; k < ls.size(); k++) {
                    try {
                        out[k] = Thumbs.forLayer(p, ls.get(k), 96);
                    } catch (Throwable ignored) {
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (destroyed) {
                            for (Bitmap b : out) if (b != null && !b.isRecycled()) b.recycle();
                            return;
                        }
                        thumbsBusy = false;
                        if (canvas.getProject() == p) {
                            for (int k = 0; k < ls.size(); k++) {
                                if (out[k] == null) continue;
                                thumbCache.put(ls.get(k), out[k]);
                                RowHolder h = rowHolders.get(ls.get(k));
                                if (h != null) {
                                    h.thumb.setImageBitmap(out[k]);
                                    h.thumb.setTag(out[k]);
                                }
                            }
                        }
                        if (thumbsAgain) requestThumbs();
                    }
                });
            }
        });
    }

    /** Opacidad arriba, fija, como en Ibis: se ve al momento y sin trabarse. */
    private void setupOpacityRow() {
        if (opacityRowReady) return;
        opacityRowReady = true;
        SeekBar ob = findViewById(R.id.layersOpBar);
        ob.setMax(100);
        ob.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (!u) return;
                Project p = canvas.getProject();
                Layer l = p == null ? null : p.activeLayer();
                if (l == null) return;
                l.opacity = Math.round(v * 255 / 100f);
                ((TextView) findViewById(R.id.layersOpText)).setText("Opacidad " + v + "%");
                RowHolder h = rowHolders.get(l);
                if (h != null) bindRow(h, true);
                canvas.refreshDisplayAsync();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                canvas.recordPropsUndo("Opacidad de capa");
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                canvas.layersChangedAsync();
            }
        });
    }

    private void updateOpacityRow() {
        Project p = canvas.getProject();
        Layer l = p == null ? null : p.activeLayer();
        SeekBar ob = findViewById(R.id.layersOpBar);
        TextView ot = findViewById(R.id.layersOpText);
        ob.setEnabled(l != null);
        int v = l == null ? 100 : l.opacity * 100 / 255;
        if (ob.getProgress() != v) ob.setProgress(v);
        ot.setText("Opacidad " + v + "%");
    }

    /**
     * v8.55: la barra de opacidad se ve como la de Ibis: a la izquierda cuadritos (transparente) y a
     * la derecha oscuro (100 %). Se entiende sin leer: menos = mas transparente.
     */
    private void styleOpacityBar(SeekBar ob) {
        try {
            int cs = dp(5);
            Bitmap chk = Bitmap.createBitmap(cs * 2, cs * 2, Bitmap.Config.ARGB_8888);
            for (int y = 0; y < cs * 2; y++)
                for (int x = 0; x < cs * 2; x++)
                    chk.setPixel(x, y, ((x / cs) + (y / cs)) % 2 == 0 ? 0xFFE6E6E6 : 0xFFA8A8A8);
            android.graphics.drawable.BitmapDrawable bd = new android.graphics.drawable.BitmapDrawable(getResources(), chk);
            bd.setTileModeXY(android.graphics.Shader.TileMode.REPEAT, android.graphics.Shader.TileMode.REPEAT);
            android.graphics.drawable.GradientDrawable gr = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x00202024, 0xFF202024});
            android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                    new android.graphics.drawable.Drawable[]{bd, gr});
            int in = dp(9);
            ld.setLayerInset(0, dp(8), in, dp(8), in);
            ld.setLayerInset(1, dp(8), in, dp(8), in);
            ob.setBackground(ld);
            ob.setProgressDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            ob.setMinimumHeight(dp(34));
        } catch (Throwable ignored) { }
    }

    /** Fondo para mirar: cuadros claros, cuadros oscuros, blanco, negro, verde. */
    private void buildViewBg() {
        LinearLayout row = findViewById(R.id.viewBgRow);
        if (row.getChildCount() != CanvasView.VIEW_BG.length) {
            row.removeAllViews();
            for (int k = 0; k < CanvasView.VIEW_BG.length; k++) {
                final int idx = k;
                View sw = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
                lp.setMargins(dp(3), 0, dp(3), 0);
                sw.setLayoutParams(lp);
                sw.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        canvas.setViewBg(idx);
                        buildViewBg();
                        requestThumbs();   // v8.45: miniaturas con el fondo elegido
                    }
                });
                row.addView(sw);
            }
        }
        for (int k = 0; k < CanvasView.VIEW_BG.length; k++) {
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(6));
            int[] c = CanvasView.VIEW_BG[k];
            if (c[0] != c[1]) g.setColors(new int[]{c[0], c[1]});
            else g.setColor(c[0]);
            boolean on = canvas.getViewBg() == k;
            g.setStroke(dp(on ? 3 : 1), on ? 0xFF2F6BD8 : 0xFF777777);
            row.getChildAt(k).setBackground(g);
        }
    }

    /**
     * Botones de abajo del panel (v8.24): las 4 acciones principales y "Mas".
     * Lo secundario va en el menu "Mas" para que los textos no se corten en
     * telefonos chicos y no haya iconos repetidos para cosas distintas.
     */
    private void buildLayerActions() {
        buildLayerSide();
        LinearLayout bar = findViewById(R.id.layersActions);
        bar.removeAllViews();
        addAction(bar, R.drawable.ic_add, "Nueva", new Runnable() {
            public void run() {
                // v8.43: Nueva = capa transparente al toque. Lo demas (flecha, colorear B/N,
                // hojas) va en las rayitas de la capa o en Mas > Tipos de capa.
                canvas.addEmptyLayer();
                afterLayerOp();
                canvas.showHud("Capa nueva. Toca sus rayitas para flecha, colorear B/N y mas", 2400);
            }
        });
        addAction(bar, R.drawable.ic_dup, "Duplicar", new Runnable() {
            public void run() {
                canvas.duplicateActive();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_merge, "Combinar", new Runnable() {
            public void run() {
                canvas.mergeDown();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_trash, "Eliminar", new Runnable() {
            public void run() {
                canvas.deleteActive();
                afterLayerOp();
            }
        });
        // v8.28: la referencia de color vuelve a estar a la vista en Capas (captura 3: no se
        // encontraba dentro de "Mas"). NO crea capa: abre la ventana de referencia.
        addAction(bar, R.drawable.ic_ref_color, "Ref. color", new Runnable() {
            public void run() {
                requestColorReference(paintColorTarget());
            }
        });
        addAction(bar, R.drawable.ic_menu, "Mas", new Runnable() {
            public void run() {
                layersMoreMenu();
            }
        });
    }

    /**
     * v8.53: barra de iconos CON NOMBRE al costado de las capas (como la de Ibis): lo que se usa
     * con la capa elegida, sin entrar a otro menu. Mantener pulsado dice que hace.
     */
    private void buildLayerSide() {
        LinearLayout side = findViewById(R.id.layersSide);
        if (side == null) return;
        side.removeAllViews();
        sideCell(side, R.drawable.ic_broom, "Limpiar", "Borra todo lo de la capa (se puede deshacer)", new Runnable() { public void run() {
            canvas.clearActive(); afterLayerOp(); canvas.showHud("Capa limpia (deshacer la devuelve)", 1600); } });
        sideCell(side, R.drawable.ic_move, "Mover", "Mover la capa con el dedo", new Runnable() { public void run() {
            closeLayers(); selectTool(CanvasView.MODE_MOVE); } });
        sideCell(side, R.drawable.ic_flip_h, "Voltear ↔", "Voltea solo esta capa (izquierda-derecha)", new Runnable() { public void run() {
            Layer l = activeLayerOrToast(); if (l != null) { canvas.flipLayer(l, true); afterLayerOp(); } } });
        sideCell(side, R.drawable.ic_flip_v, "Voltear ↕", "Voltea solo esta capa (arriba-abajo)", new Runnable() { public void run() {
            Layer l = activeLayerOrToast(); if (l != null) { canvas.flipLayer(l, false); afterLayerOp(); } } });
        sideCell(side, R.drawable.ic_rotate, "Girar 90°", "Gira toda la imagen 90 grados (todas las capas)", new Runnable() { public void run() {
            canvas.transform(0); markDirty(); } });
        sideCell(side, R.drawable.ic_blend, "Modo", "Como se mezcla con lo de abajo", new Runnable() { public void run() {
            Layer l = activeLayerOrToast(); if (l != null) modeDialog(l); } });
        sideCell(side, R.drawable.ic_white_alpha, "Sacar lineas", "Lo blanco se vuelve transparente y quedan las lineas", new Runnable() { public void run() {
            Layer l = activeLayerOrToast(); if (l != null) extractLinesDialog(l); } });
        sideCell(side, R.drawable.ic_blur, "Difuminar", "Funde toda la capa", new Runnable() { public void run() {
            Layer l = activeLayerOrToast(); if (l != null) blurLayerDialog(l); } });
        sideCell(side, R.drawable.ic_hue, "Color", "Tono, saturacion y brillo de la capa", new Runnable() { public void run() {
            Layer l = activeLayerOrToast(); if (l != null) changeColorDialog(l); } });
        sideCell(side, R.drawable.ic_tune, "Filtros", "Filtros de la capa", new Runnable() { public void run() {
            runMenu("Filtros de la capa"); } });
        sideCell(side, R.drawable.ic_menu, "Opciones", "Todas las opciones de la capa", new Runnable() { public void run() {
            Layer l = activeLayerOrToast(); if (l != null) layerOptions(l); } });
    }

    private Layer activeLayerOrToast() {
        Project p = canvas.getProject();
        Layer l = p == null ? null : p.activeLayer();
        if (l == null) toast("Toca una capa primero");
        return l;
    }

    private void sideCell(LinearLayout side, int icon, String name, final String what, final Runnable r) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(dp(2), dp(6), dp(2), dp(5));
        cell.setBackgroundResource(R.drawable.bg_cell);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.setMargins(dp(2), dp(2), dp(2), dp(2));
        cell.setLayoutParams(clp);
        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
        img.setImageResource(icon);
        cell.addView(img);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFDDDDDD);
        t.setTextSize(9f);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        t.setPadding(0, dp(2), 0, 0);
        cell.addView(t);
        cell.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        cell.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { toast(what); return true; } });
        side.addView(cell);
    }

    /** Menu "Mas" del panel de capas. "Crear capa desde la seleccion" solo aparece si hay seleccion. */
    /**
     * v8.29: "Mas" de Capas con ICONOS (sin lista de textos). Mantener pulsado un icono dice su nombre.
     */
    private void layersMoreMenu() {
        final Project p = canvas.getProject();
        if (p == null) return;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(8), dp(14), dp(8), dp(14));
        final AlertDialog[] dlg = new AlertDialog[1];
        java.util.List<Object[]> items = new java.util.ArrayList<Object[]>();
        if (p.hasSelection()) items.add(new Object[]{R.drawable.ic_layer_add, "Capa con lo seleccionado", new Runnable() {
            public void run() { partFromSelectionDialog(false); }
        }, "Seleccion a capa"});
        items.add(new Object[]{R.drawable.ic_layer_add, "Capa nueva de un tipo (flecha, colorear B/N, hoja)", new Runnable() {
            public void run() { newLayerChooser(); }
        }, "Tipos de capa"});
        items.add(new Object[]{R.drawable.ic_lineart, "Separar las lineas en una capa", new Runnable() {
            public void run() { linesDialog(); }
        }, "Separar lineas"});
        items.add(new Object[]{R.drawable.ic_broom, "Limpiar la capa (borra todo lo que tiene)", new Runnable() {
            public void run() { canvas.clearActive(); afterLayerOp(); }
        }, "Vaciar capa"});
        if (p.activeLayer() != null) items.add(new Object[]{R.drawable.ic_tune, "Opciones de la capa", new Runnable() {
            public void run() {
                Layer l = canvas.getProject() == null ? null : canvas.getProject().activeLayer();
                if (l != null) layerOptions(l);
            }
        }, "Opciones"});
        // v8.39: cada icono con un nombre corto debajo (antes solo iconos y no se entendian)
        for (final Object[] it : items) {
            row.addView(chooserCell((Integer) it[0], (String) it[3], 0, new Runnable() {
                public void run() {
                    if (dlg[0] != null) dlg[0].dismiss();
                    ((Runnable) it[2]).run();
                }
            }));
        }
        dlg[0] = new SheetBuilder(this).setView(row).create();
        dlg[0].show();
    }

    /**
     * v8.24 "Lineas": separa las lineas del dibujo en una capa transparente, con vista
     * previa a tamano real. Avisa si la imagen es a color (ahi se usan solo los
     * trazos finos, para no tomar sombras ni zonas oscuras como linea).
     */
    private void linesDialog() {
        if (!needProject()) return;
        final com.pacco.animecut.core.LineArt.Extract ex = new com.pacco.animecut.core.LineArt.Extract();
        ex.colored = canvas.activeLooksColored();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(4));
        TextView info = new TextView(this);
        info.setTextColor(0xFFCCCCCC);
        info.setTextSize(13f);
        info.setText(ex.colored
                ? "ATENCION: la imagen es a color. Solo se separan los trazos finos y oscuros; el pelo oscuro, "
                + "la ropa y las sombras NO cuentan como linea. Revisa la vista previa: con imagenes a color "
                + "el resultado puede no ser perfecto."
                : "Crea una capa nueva encima con las lineas sobre fondo transparente. Tu dibujo original no cambia. "
                + "Sirve para pintar debajo de las lineas sin taparlas.");
        root.addView(info);
        final ImageView prev = new ImageView(this);
        prev.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(200)));
        prev.setScaleType(ImageView.ScaleType.FIT_CENTER);
        prev.setBackgroundColor(0xFFB0D0F0); // fondo de color: se ve que el papel quedo transparente
        prev.setPadding(0, dp(8), 0, dp(8));
        root.addView(prev);
        TextView ph = new TextView(this);
        ph.setText("Vista previa a tamano real del centro de la pantalla, sobre fondo celeste");
        ph.setTextColor(0xFF999999);
        ph.setTextSize(11f);
        root.addView(ph);
        final TextView t1 = new TextView(this), t2 = new TextView(this);
        t1.setTextColor(0xFFFFFFFF);
        t2.setTextColor(0xFFFFFFFF);
        final SeekBar s1 = new SeekBar(this), s2 = new SeekBar(this);
        if (ex.colored) {
            s1.setMax(12); s1.setProgress(ex.maxWidth - 1);
            s2.setMax(120); s2.setProgress(ex.contrast);
        } else {
            s1.setMax(255); s1.setProgress(ex.white);
            s2.setMax(255); s2.setProgress(ex.black);
        }
        root.addView(t1); root.addView(s1); root.addView(t2); root.addView(s2);
        final CheckBox withColor = new CheckBox(this);
        withColor.setText("Crear tambien una capa \"Color\" debajo de las lineas para pintar");
        withColor.setTextColor(0xFFFFFFFF);
        withColor.setChecked(true);
        root.addView(withColor);
        final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable[] refresh = new Runnable[1];
        refresh[0] = new Runnable() {
            @Override public void run() {
                if (ex.colored) {
                    ex.maxWidth = s1.getProgress() + 1;
                    ex.contrast = s2.getProgress();
                    t1.setText("Grosor maximo de linea: " + ex.maxWidth + " px");
                    t2.setText("Contraste minimo del trazo: " + ex.contrast + " (mas alto: menos sombras)");
                } else {
                    ex.white = s1.getProgress();
                    ex.black = Math.min(s2.getProgress(), ex.white - 1);
                    t1.setText("Blanco (lo que se vuelve transparente): " + ex.white);
                    t2.setText("Negro (lo que queda como linea llena): " + ex.black);
                }
                final com.pacco.animecut.core.LineArt.Extract snap = new com.pacco.animecut.core.LineArt.Extract();
                snap.colored = ex.colored; snap.white = ex.white; snap.black = ex.black;
                snap.maxWidth = ex.maxWidth; snap.contrast = ex.contrast;
                new Thread(new Runnable() {
                    @Override public void run() {
                        final int[] r = canvas.previewLines(snap, 300);
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (r == null || destroyed) return;
                                Bitmap b = Bitmap.createBitmap(r, 2, r[0], r[0], r[1], Bitmap.Config.ARGB_8888);
                                prev.setImageBitmap(b);
                            }
                        });
                    }
                }).start();
            }
        };
        SimpleSeek seek = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
                hd.removeCallbacks(refresh[0]);
                hd.postDelayed(refresh[0], 150);
            }
        };
        s1.setOnSeekBarChangeListener(seek);
        s2.setOnSeekBarChangeListener(seek);
        refresh[0].run();
        new SheetBuilder(this)
                .setTitle("Lineas")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear capa", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        canvas.extractLinesLayer(ex, withColor.isChecked());
                        afterLayerOp();
                    }
                })
                .show();
    }

    private void addAction(LinearLayout bar, int icon, String name, final Runnable r) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(android.view.Gravity.CENTER);
        cell.setPadding(dp(2), dp(6), dp(2), dp(6));
        cell.setBackgroundResource(R.drawable.bg_cell);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        clp.setMargins(dp(2), 0, dp(2), 0);
        cell.setLayoutParams(clp);
        ImageView img = new ImageView(this);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(24), dp(24));
        ilp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        img.setLayoutParams(ilp);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageResource(icon);
        cell.addView(img);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFDDDDDD);
        t.setTextSize(10f);
        t.setSingleLine(true);
        t.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, dp(3), 0, 0);
        cell.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        bar.addView(cell);
    }

    /**
     * v8.36: capa nueva encima de un dibujo recortado (con fondo transparente): se pregunta si
     * lo pintado debe verse SOLO dentro del dibujo (Recorte). Asi pasarse del borde no ensucia
     * el fondo transparente. "No volver a preguntar" recuerda la respuesta; se cambia tocando la
     * capa elegida > Recorte.
     */
    private void askClipNewLayer(final Layer below) {
        final Layer nl = canvas.getProject() == null ? null : canvas.getProject().activeLayer();
        if (below == null || nl == null || nl == below || !canvas.layerHasTransparency(below)) return;
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (!sp.getBoolean("clip_new_ask", true)) {
            if (sp.getBoolean("clip_new_on", true)) setClipQuiet(nl);
            return;
        }
        final CheckBox remember = new CheckBox(this);
        remember.setText("No volver a preguntar");
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(remember);
        new SheetBuilder(this)
                .setTitle("Pintar solo dentro del dibujo?")
                .setMessage("Lo que pintes fuera del personaje no se vera.")
                .setView(box)
                .setPositiveButton("Solo dentro", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (remember.isChecked()) sp.edit().putBoolean("clip_new_ask", false).putBoolean("clip_new_on", true).apply();
                        setClipQuiet(nl);
                    }
                })
                .setNegativeButton("Libre", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (remember.isChecked()) sp.edit().putBoolean("clip_new_ask", false).putBoolean("clip_new_on", false).apply();
                    }
                })
                .show();
    }

    /**
     * v8.39 "Nueva": Transparente (normal), Con flecha (pinta solo dentro del dibujo de abajo),
     * Hoja blanca, o Hoja de color (un toque en el color). Ya no sale la pregunta de antes.
     */
    private void newLayerChooser() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(12), dp(10), dp(6));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row);
        final Runnable plain = new Runnable() {
            public void run() { canvas.addEmptyLayer(); afterLayerOp(); }
        };
        row.addView(chooserCell(R.drawable.ic_layer_clear, "Transparente", 0, new Runnable() {
            public void run() { if (dlg[0] != null) dlg[0].dismiss(); plain.run(); }
        }));
        row.addView(chooserCell(R.drawable.ic_clip, "Con flecha", 0, new Runnable() {
            public void run() {
                if (dlg[0] != null) dlg[0].dismiss();
                Layer below = p.activeLayer();
                canvas.addEmptyLayer();
                Layer nl = p.activeLayer();
                if (below != null && nl != null && nl != below) canvas.setLayerClip(nl, true);
                canvas.showHud("Flecha: lo que pintes queda solo dentro del dibujo de abajo", 2200);
                afterLayerOp();
            }
        }));
        row.addView(chooserCell(R.drawable.ic_paint, "Colorear B/N", 0, new Runnable() {
            public void run() {
                if (dlg[0] != null) dlg[0].dismiss();
                canvas.addEmptyLayer();
                Layer nl = p.activeLayer();
                if (nl != null) { canvas.setLayerMode(nl, Layer.MODE_MULTIPLY); nl.name = "color B/N"; }
                canvas.showHud("Capa para colorear B/N (Multiplicar): el color no tapa las lineas negras", 2600);
                afterLayerOp();
            }
        }));
        row.addView(chooserCell(R.drawable.ic_layer_sheet, "Hoja blanca", 0, new Runnable() {
            public void run() { if (dlg[0] != null) dlg[0].dismiss(); canvas.addFilledLayer(0xFFFFFFFF); afterLayerOp(); }
        }));
        // v8.72: imagenes desde Capas (como en Alight): encima, o de fondo detras de todo
        LinearLayout imgRow = new LinearLayout(this);
        imgRow.setOrientation(LinearLayout.HORIZONTAL);
        imgRow.setPadding(0, dp(8), 0, 0);
        imgRow.addView(chooserCell(R.drawable.ic_image, "Imagen encima", 0, new Runnable() {
            public void run() {
                if (dlg[0] != null) dlg[0].dismiss();
                pendingImageBelow = false;
                addImage.launch("image/*");
            }
        }));
        imgRow.addView(chooserCell(R.drawable.ic_image, "Imagen de fondo", 0, new Runnable() {
            public void run() {
                if (dlg[0] != null) dlg[0].dismiss();
                pendingImageBelow = true;
                addImage.launch("image/*");
            }
        }));
        row.addView(chooserCell(R.drawable.ic_layer_sheet, "Color actual", canvas.getColor() | 0xFF000000, new Runnable() {
            public void run() { if (dlg[0] != null) dlg[0].dismiss(); canvas.addFilledLayer(canvas.getColor()); afterLayerOp(); }
        }));
        root.addView(sectionTitle("Imagen (de tu galeria)"));
        root.addView(imgRow);
        root.addView(sectionTitle("Hoja de otro color (un toque)"));
        for (int r = 0; r < 2; r++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setPadding(0, dp(2), 0, dp(2));
            for (int k = 0; k < 9; k++) {
                final int c = BASIC_COLORS[r * 9 + k];
                View sw = swatch(c, new ColorPickTarget() {
                    @Override public void onColor(int color) {
                        if (dlg[0] != null) dlg[0].dismiss();
                        canvas.addFilledLayer(color);
                        afterLayerOp();
                    }
                }, null);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(30), 1f);
                lp.setMargins(dp(2), 0, dp(2), 0);
                sw.setLayoutParams(lp);
                line.addView(sw);
            }
            root.addView(line);
        }
        dlg[0] = new SheetBuilder(this).setTitle("Tipos de capa").setView(root).setNegativeButton("Cancelar", null).show();
    }

    /**
     * v8.43: toque en las rayitas de una capa: lo mas usado con iconos (flecha, colorear B/N,
     * modo, nombre, todas las opciones). Mantener y arrastrar las rayitas sigue moviendo la capa.
     */
    private void layerQuickMenu(final Layer l) {
        final Project p = canvas.getProject();
        if (p == null || !p.layers.contains(l)) return;
        int idx = p.layers.indexOf(l);
        if (idx != p.active) canvas.setActive(idx);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(12), dp(8), dp(6));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row);
        final AlertDialog[] dlg = new AlertDialog[1];
        row.addView(chooserCell(R.drawable.ic_clip, l.clip ? "Flecha: SI" : "Flecha: NO", l.clip ? 0xFF64B5F6 : 0, new Runnable() {
            public void run() {
                if (dlg[0] != null) dlg[0].dismiss();
                canvas.setLayerClip(l, !l.clip);
                canvas.showHud(l.clip ? "Flecha: lo que pintes queda solo dentro del dibujo de abajo" : "Flecha quitada", 2200);
                buildLayersPanel();
            }
        }));
        final boolean mult = l.mode == Layer.MODE_MULTIPLY;
        row.addView(chooserCell(R.drawable.ic_paint, mult ? "Colorear B/N: SI" : "Colorear B/N", mult ? 0xFF64B5F6 : 0, new Runnable() {
            public void run() {
                if (dlg[0] != null) dlg[0].dismiss();
                canvas.setLayerMode(l, mult ? Layer.MODE_NORMAL : Layer.MODE_MULTIPLY);
                canvas.showHud(mult ? "Modo Normal" : "Multiplicar: el color no tapa las lineas negras ni las sombras grises", 2400);
                buildLayersPanel();
            }
        }));
        row.addView(chooserCell(R.drawable.ic_tune, "Modo", 0, new Runnable() {
            public void run() { if (dlg[0] != null) dlg[0].dismiss(); modeDialog(l); }
        }));
        row.addView(chooserCell(R.drawable.ic_menu, "Mas opciones", 0, new Runnable() {
            public void run() { if (dlg[0] != null) dlg[0].dismiss(); layerOptions(l); }
        }));
        // v8.72: la barra de la imagen (mover, mezcla, al frente / al fondo) para cualquier capa
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(0, dp(8), 0, 0);
        root.addView(row2);
        row2.addView(chooserCell(R.drawable.ic_image, "Opciones de imagen", 0, new Runnable() {
            public void run() {
                if (dlg[0] != null) dlg[0].dismiss();
                closeLayers();
                imageCard(l);
            }
        }));
        TextView tip = new TextView(this);
        tip.setText("Para mover la capa: manten y arrastra las rayitas.");
        tip.setTextColor(0xFF9FC6FF);
        tip.setTextSize(12f);
        tip.setPadding(dp(6), dp(10), dp(6), 0);
        root.addView(tip);
        dlg[0] = new SheetBuilder(this).setTitle(l.name).setView(root).setNegativeButton("Cerrar", null).show();
    }

    /** Icono con su nombre debajo (para los menus de iconos). tint = 0: blanco. */
    private View chooserCell(int icon, String name, int tint, final Runnable r) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(dp(2), dp(8), dp(2), dp(6));
        cell.setBackgroundResource(R.drawable.bg_tool);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        clp.setMargins(dp(3), 0, dp(3), 0);
        cell.setLayoutParams(clp);
        ImageView img = new ImageView(this);
        img.setImageResource(icon);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (tint != 0) img.setColorFilter(tint, android.graphics.PorterDuff.Mode.SRC_IN);
        cell.addView(img, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFE6E6EA);
        t.setTextSize(11f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(4), 0, 0);
        cell.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { r.run(); }
        });
        return cell;
    }

    private void setClipQuiet(Layer l) {
        canvas.setLayerClip(l, true);
        canvas.showHud("Solo dentro del dibujo · se cambia tocando la capa", 2200);
        afterLayerOp();
    }

    // ------------------------------------------------------------------ v8.37 B/N
    private com.pacco.animecut.core.GrayView loadGrayView() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        com.pacco.animecut.core.GrayView g = new com.pacco.animecut.core.GrayView();
        g.channel = Math.max(0, Math.min(3, sp.getInt("bg_gray_ch", 0)));
        g.saturation = Math.max(0, Math.min(100, sp.getInt("bg_gray_sat", 0)));
        g.contrast = Math.max(-100, Math.min(100, sp.getInt("bg_gray_con", 0)));
        g.brightness = Math.max(-100, Math.min(100, sp.getInt("bg_gray_bri", 0)));
        return g;
    }

    private void saveGrayView(com.pacco.animecut.core.GrayView g) {
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_gray_ch", g.channel).putInt("bg_gray_sat", g.saturation)
                .putInt("bg_gray_con", g.contrast).putInt("bg_gray_bri", g.brightness).apply();
    }

    /**
     * v8.38: ajustes del B/N en una barra CHICA pegada abajo (justo encima de las herramientas):
     * el lienzo queda a la vista mientras mueves el brillo o el contraste. Todo se guarda al
     * momento (apagar y prender B/N lo deja igual). Ver color: mira tu color un momento sin
     * perder el ajuste. La barra no bloquea el lienzo: puedes seguir usando el Balde.
     */
    private PopupWindow grayPop;

    private void grayDialog() {
        if (grayPop != null && grayPop.isShowing()) { grayPop.dismiss(); return; }
        final com.pacco.animecut.core.GrayView g = canvas.getBgGrayView();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(6));
        android.graphics.drawable.GradientDrawable bgd = new android.graphics.drawable.GradientDrawable();
        bgd.setColor(0xE6202024);
        bgd.setCornerRadius(dp(14));
        box.setBackground(bgd);
        // fila 1: de que color sale el gris
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER_VERTICAL);
        final TextView[] ch = new TextView[4];
        for (int k = 0; k < 4; k++) {
            final int which = k;
            ch[k] = smallTextButton(com.pacco.animecut.core.GrayView.CH_NAMES[k]);
            ch[k].setBackgroundResource(k == g.channel ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            ch[k].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    g.channel = which;
                    for (int j = 0; j < 4; j++) ch[j].setBackgroundResource(j == which ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                    canvas.setBgGrayView(g);
                    saveGrayView(g);
                }
            });
            chips.addView(ch[k]);
        }
        box.addView(chips);
        // filas 2-4: tres barras cortas
        final SeekBar sat = grayRow(box, "Saturacion", 100, g.saturation);
        final SeekBar con = grayRow(box, "Contraste", 200, g.contrast + 100);
        final SeekBar bri = grayRow(box, "Brillo", 200, g.brightness + 100);
        SeekBar.OnSeekBarChangeListener live = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean user) {
                g.saturation = sat.getProgress();
                g.contrast = con.getProgress() - 100;
                g.brightness = bri.getProgress() - 100;
                canvas.setBgGrayView(g);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { saveGrayView(g); }
        };
        sat.setOnSeekBarChangeListener(live);
        con.setOnSeekBarChangeListener(live);
        bri.setOnSeekBarChangeListener(live);
        // fila 5: Ver color · De fabrica · Apagar · Listo
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        final TextView peek = smallTextButton(canvas.isBgGrayPeek() ? "Ver B/N" : "Ver color");
        peek.setBackgroundResource(canvas.isBgGrayPeek() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        peek.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !canvas.isBgGrayPeek();
                canvas.setBgGrayPeek(on);
                peek.setText(on ? "Ver B/N" : "Ver color");
                peek.setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            }
        });
        TextView reset = smallTextButton("De fabrica");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                g.reset();
                sat.setProgress(g.saturation);
                con.setProgress(g.contrast + 100);
                bri.setProgress(g.brightness + 100);
                for (int j = 0; j < 4; j++) ch[j].setBackgroundResource(j == g.channel ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                canvas.setBgGrayView(g);
                saveGrayView(g);
            }
        });
        TextView off = smallTextButton("Apagar B/N");
        off.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveGrayView(g);
                canvas.setBgGray(false);
                canvas.showHud("Color original");
                if (grayPop != null) grayPop.dismiss();
                updateUi();
            }
        });
        TextView done = smallTextButton("Listo");
        done.setBackgroundResource(R.drawable.bg_tool_on);
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveGrayView(g);
                if (canvas.isBgGrayPeek()) canvas.setBgGrayPeek(false);
                if (grayPop != null) grayPop.dismiss();
            }
        });
        btns.addView(peek);
        btns.addView(reset);
        btns.addView(off);
        btns.addView(done);
        box.addView(btns);
        View bar = findViewById(R.id.optBar);
        int w = getResources().getDisplayMetrics().widthPixels - dp(16);
        grayPop = new PopupWindow(box, w, ViewGroup.LayoutParams.WRAP_CONTENT, false);
        grayPop.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override public void onDismiss() { canvas.setBgGrayTuning(false); }
        });
        grayPop.setOutsideTouchable(false);
        grayPop.setTouchable(true);
        // justo encima de la barra de herramientas: el lienzo queda libre arriba
        int[] loc = new int[2];
        bar.getLocationInWindow(loc);
        int screenH = getWindow().getDecorView().getHeight();
        int y = Math.max(0, screenH - loc[1] + dp(4));
        grayPop.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, y);
    }

    private void closeGrayPop() {
        if (grayPop != null && grayPop.isShowing()) grayPop.dismiss();
        grayPop = null;
    }

    private SeekBar grayRow(LinearLayout box, String name, int max, int val) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(12f);
        row.addView(t, new LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(val);
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(32), 1f));
        box.addView(row);
        return sb;
    }

    private void afterLayerOp() {
        if (layersOpen()) buildLayersPanel();
        updateUi();
    }

    /** v8.52: opciones de la capa en iconos (como Ibis), con voltear, quitar blanco y difuminar. */
    private void layerOptions(final Layer l) {
        List<String> heads = new ArrayList<String>();
        List<List<MItem>> secs = new ArrayList<List<MItem>>();
        List<MItem> m;
        heads.add("CAPA"); secs.add(m = new ArrayList<MItem>());
        m.add(new MItem("Modo: " + Layer.MODE_NAMES[Math.max(0, Math.min(Layer.MODE_NAMES.length - 1, l.mode))], "mode",
                R.drawable.ic_blend, -1, "Como se mezcla con lo de abajo: multiplicar, superponer, luz suave..."));
        m.add(new MItem("Flecha", "clip", R.drawable.ic_clip, l.clip ? 1 : 0, "Solo se ve dentro de la capa de abajo."));
        m.add(new MItem("Solo sobre lo pintado", "alpha", R.drawable.ic_opacity, l.alphaLock ? 1 : 0, "Pintas solo donde esta capa ya tiene dibujo."));
        m.add(new MItem("Bloquear", "lock", R.drawable.ic_lock, l.locked ? 1 : 0, "No se puede pintar, borrar ni mover."));
        m.add(new MItem("Lineas balde", "ref", R.drawable.ic_lineart, l.reference ? 1 : 0, "El balde toma los contornos de esta capa."));
        m.add(new MItem("Nombre", "name", R.drawable.ic_rename, -1, "Cambiar el nombre de la capa."));
        heads.add("CAMBIAR"); secs.add(m = new ArrayList<MItem>());
        m.add(new MItem("Voltear ↔", "fliph", R.drawable.ic_flip_h, -1, "Voltea solo esta capa de izquierda a derecha."));
        m.add(new MItem("Voltear ↕", "flipv", R.drawable.ic_flip_v, -1, "Voltea solo esta capa de arriba a abajo."));
        m.add(new MItem("Sacar lineas", "white", R.drawable.ic_white_alpha, -1,
                "Con tres ajustes: blanco, negro y medio. Lo blanco se vuelve transparente y quedan las lineas."));
        m.add(new MItem("Quitar blanco color", "whitec", R.drawable.ic_white_alpha, -1,
                "Lo blanco se vuelve transparente pero las lineas guardan su color."));
        m.add(new MItem("Difuminar", "blur", R.drawable.ic_blur, -1, "Funde toda la capa (desenfoque suave)."));
        m.add(new MItem(l.hasAdjust() ? "Color (cambiado)" : "Cambiar color", "adjust", R.drawable.ic_hue, -1, "Tono, saturacion y brillo de la capa."));
        if (l.hasAdjust()) m.add(new MItem("Fijar color", "bake", R.drawable.ic_check, -1, "Deja el cambio de color en los pixeles."));
        m.add(new MItem("Guardar PNG", "export", R.drawable.ic_export, -1, "Guarda esta capa sola, con fondo transparente."));
        showIconGrid(l.name, heads, secs, new KeyAction() { public void run(String k) { layerAction(l, k); } });
    }

    private void layerAction(final Layer l, String k) {
        if (k.equals("mode")) modeDialog(l);
        else if (k.equals("clip")) {
            canvas.setLayerClip(l, !l.clip);
            canvas.showHud(l.clip ? "Flecha: solo se ve dentro de la de abajo" : "Flecha quitada");
        } else if (k.equals("alpha")) {
            canvas.setLayerAlphaLock(l, !l.alphaLock);
            canvas.showHud(l.alphaLock ? "Solo se pinta sobre lo que ya hay" : "Pintar libre");
        } else if (k.equals("ref")) {
            canvas.setLayerReference(l, !l.reference);
            canvas.showHud(l.reference ? "El balde toma estos contornos" : "Ya no es linea del balde");
        } else if (k.equals("name")) { renameDialog(l); return; }
        else if (k.equals("lock")) {
            canvas.setLayerLocked(l, !l.locked);
            canvas.showHud(l.locked ? "Capa bloqueada" : "Capa desbloqueada");
        } else if (k.equals("adjust")) { changeColorDialog(l); return; }
        else if (k.equals("bake")) {
            if (l.hasAdjust()) { canvas.bakeLayerAdjust(l); canvas.showHud("Color fijado (se puede deshacer)"); }
        } else if (k.equals("fliph") || k.equals("flipv")) canvas.flipLayer(l, k.equals("fliph"));
        else if (k.equals("white")) { extractLinesDialog(l); return; }
        else if (k.equals("whitec")) {
            canvas.whiteToAlpha(l, true);
            canvas.showHud("Blanco quitado: pinta en una capa debajo", 2000);
        } else if (k.equals("blur")) { blurLayerDialog(l); return; }
        else if (k.equals("export")) {
            pendingFlatExport = false;
            pendingLayerExport = l;
            Uri lu = appFolderUri(safeName(l.name) + "_" + stampNow() + ".png", "image/png", false);
            if (lu != null) { exportWhere = "Imagenes > Paint Zeta"; doExportLayer(lu); }
            else createPng.launch(l.name + ".png");
            return;
        }
        afterLayerOp();
    }

    /**
     * v8.53 "Sacar lineas" (Extraer dibujo lineal de Ibis): Blanco 85, Negro 20, Medio 50 de entrada.
     * Se ve en el lienzo mientras mueves; Listo lo deja (se puede deshacer), Cancelar lo devuelve.
     */
    private void extractLinesDialog(final Layer l) {
        if (!canvas.linesBegin(l)) return;
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        final int[] v = {sp.getInt("lines_w", 85), sp.getInt("lines_b", 20), sp.getInt("lines_m", 50)};
        final boolean[] col = {sp.getBoolean("lines_c", false)};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(8), dp(14), dp(4));
        final Runnable[] go = new Runnable[1];
        final Runnable later = new Runnable() { public void run() { canvas.linesPreview(v[0], v[1], v[2], col[0]); } };
        go[0] = new Runnable() { public void run() { canvas.removeCallbacks(later); canvas.postDelayed(later, 180); } };
        String[] names = {"Blanco: lo mas claro se va", "Negro: lo mas oscuro queda", "Medio: grises mas llenos"};
        int[] icons = {R.drawable.ic_light, R.drawable.ic_shadow, R.drawable.ic_tone};
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            box.addView(iconSlider(icons[k], names[k], v[k], new IntConsumerCompat() {
                public void accept(int x) { v[kk] = x; go[0].run(); } }));
        }
        LinearLayout tg = new LinearLayout(this);
        tg.setOrientation(LinearLayout.HORIZONTAL);
        final ImageButton[] cb = new ImageButton[1];
        cb[0] = fxToggle(R.drawable.ic_color, "Las lineas guardan su color", col[0], new Runnable() { public void run() {
            col[0] = !col[0];
            cb[0].setBackgroundResource(col[0] ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            go[0].run();
        }});
        tg.addView(cb[0]);
        box.addView(tg);
        canvas.linesPreview(v[0], v[1], v[2], col[0]);
        new SheetBuilder(this).setTitle("Sacar lineas").setView(box).setCancelable(false)
                .setPositiveButton("Listo", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.removeCallbacks(later);
                        canvas.linesPreview(v[0], v[1], v[2], col[0]);
                        canvas.linesEnd(true);
                        sp.edit().putInt("lines_w", v[0]).putInt("lines_b", v[1]).putInt("lines_m", v[2]).putBoolean("lines_c", col[0]).apply();
                        afterLayerOp();
                        canvas.showHud("Lineas listas: pinta en una capa nueva DEBAJO", 2200);
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.removeCallbacks(later);
                        canvas.linesEnd(false);
                        afterLayerOp();
                    }
                }).show();
    }

    /** Difuminar la capa entera, con un deslizador (se aplica al soltar). */
    private void blurLayerDialog(final Layer l) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(4));
        final int[] amt = {getSharedPreferences("pz", MODE_PRIVATE).getInt("blur_layer", 35)};
        box.addView(iconSlider(R.drawable.ic_blur, "Cuanto difuminar", amt[0], new IntConsumerCompat() {
            public void accept(int v) { amt[0] = v; } }));
        new SheetBuilder(this).setTitle("Difuminar " + l.name).setView(box)
                .setPositiveButton("Difuminar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("blur_layer", amt[0]).apply();
                        canvas.blurLayer(l, amt[0]);
                        afterLayerOp();
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    /** v8.52: todos los modos de mezcla (como Ibis), en grupos con icono. */
    /**
     * v8.55: lista de modos como la de Ibis: al lado del panel, por grupos (Oscurecer, Aclarar,
     * Contraste...). Tocar un modo lo aplica AL MOMENTO y la lista sigue abierta para probar otro;
     * se cierra tocando fuera. Mantener pulsado un modo dice para que sirve.
     */
    private PopupWindow modePop;

    private void modeDialog(final Layer l) {
        modeWheel(l);
    }

    /**
     * v8.57 rueda de modos (como Clip Studio): se desliza la lista y el modo del centro se ve AL
     * MOMENTO en el lienzo. Arriba la opacidad (cuadros = transparente, oscuro = 100 %).
     * Aceptar lo deja (con Deshacer); Cancelar vuelve al modo y opacidad de antes.
     */
    /**
     * v8.71 "Mezcla y opacidad" (como Alight Motion, pero con Zeta): grupos que se abren
     * (Oscurecer, Aclarar, Contraste, Diferencia, Color, Enmascarar) con una MINIATURA por modo:
     * Zeta con una luz de prueba mezclada con ese modo, para ver de un vistazo que hace. Al tocar
     * se ve al instante en el dibujo. Enmascarar: Recorte (solo sobre la capa de abajo) y Excluir
     * (todo menos la capa de abajo). Color de la luz: tine la capa (luces blancas -> doradas...).
     */
    private static final int[][] MODE_GROUPS = {
            {Layer.MODE_DARKEN, Layer.MODE_MULTIPLY, Layer.MODE_COLOR_BURN, Layer.MODE_LINEAR_BURN, Layer.MODE_DARKER_COLOR},
            {Layer.MODE_LIGHTEN, Layer.MODE_SCREEN, Layer.MODE_COLOR_DODGE, Layer.MODE_ADD, Layer.MODE_LIGHTER_COLOR,
                    Layer.MODE_GLOW_DODGE, Layer.MODE_ADD_GLOW},
            {Layer.MODE_OVERLAY, Layer.MODE_SOFT_LIGHT, Layer.MODE_HARD_LIGHT, Layer.MODE_VIVID_LIGHT,
                    Layer.MODE_LINEAR_LIGHT, Layer.MODE_PIN_LIGHT, Layer.MODE_HARD_MIX},
            {Layer.MODE_DIFFERENCE, Layer.MODE_EXCLUSION, Layer.MODE_SUBTRACT, Layer.MODE_DIVIDE},
            {Layer.MODE_HUE, Layer.MODE_SATURATION, Layer.MODE_COLOR, Layer.MODE_LUMINOSITY}};
    private static final String[] MODE_GROUP_NAMES = {"Oscurecer", "Aclarar", "Contraste", "Diferencia", "Color"};
    private static final int[] LIGHT_TINTS = {0xFFFFC14D, 0xFFFF8A3D, 0xFFFF4D5E, 0xFFFF6FB5, 0xFFA66BFF,
            0xFF4D8BFF, 0xFF5CE1FF, 0xFF5CFF9B};
    private static final String[] LIGHT_TINT_NAMES = {"Dorado", "Naranja", "Rojo", "Rosa", "Violeta", "Azul", "Celeste", "Verde"};

    private void modeWheel(final Layer l) {
        if (l == null) return;
        if (modePop != null && modePop.isShowing()) { modePop.dismiss(); return; }
        final int oldMode = l.mode, oldOp = l.opacity;
        final boolean oldClip = l.clip, oldOut = l.clipOut;
        final boolean reopenLayers = findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE;
        if (reopenLayers) closeLayers();
        final int tpx = dp(54);
        final float rad = dp(8);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(4), dp(12), dp(6));
        android.graphics.drawable.GradientDrawable bgd = new android.graphics.drawable.GradientDrawable();
        bgd.setColor(0xF2232328);
        bgd.setCornerRadius(dp(12));
        box.setBackground(bgd);
        final TextView ttl = new TextView(this);
        ttl.setText("⠿  Mezcla y opacidad");
        ttl.setTextColor(0xFFFFFFFF);
        ttl.setTextSize(14f);
        ttl.setPadding(0, dp(6), 0, dp(4));
        box.addView(ttl);
        final TextView opText = new TextView(this);
        opText.setTextColor(0xFFDDDDDD);
        opText.setTextSize(12f);
        opText.setText("Opacidad " + Math.round(oldOp * 100f / 255f) + "%");
        box.addView(opText);
        final SeekBar opBar = new SeekBar(this);
        opBar.setMax(100);
        opBar.setProgress(Math.round(oldOp * 100f / 255f));
        styleOpacityBar(opBar);
        box.addView(opBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        final ScrollView sc = new ScrollView(this);
        sc.addView(list);
        int listH = Math.min(dp(330), Math.round(getResources().getDisplayMetrics().heightPixels * 0.42f));
        box.addView(sc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, listH));

        final TextView hint = new TextView(this);
        hint.setTextColor(0xFF9FA3AA);
        hint.setTextSize(11f);
        hint.setPadding(0, dp(4), 0, 0);
        hint.setText(Layer.MODE_NAMES[oldMode] + ": " + modeHelp(oldMode));
        box.addView(hint);

        // ---- miniaturas (se arman una vez; luego quedan guardadas) ----
        final List<ImageView> modeViews = new ArrayList<ImageView>();
        final List<Integer> modeKeys = new ArrayList<Integer>();
        final List<ImageView> maskViews = new ArrayList<ImageView>();
        final boolean[] thumbsReady = {com.pacco.animecut.view.BlendThumbs.ready(tpx)};
        final Runnable refreshSel = new Runnable() {
            @Override public void run() {
                if (!thumbsReady[0]) return;          // todavia se estan armando (por detras)
                for (int k = 0; k < modeViews.size(); k++) {
                    int md = modeKeys.get(k);
                    modeViews.get(k).setImageBitmap(com.pacco.animecut.view.BlendThumbs.modeTile(md, tpx, md == l.mode, rad));
                }
                int mk = !l.clip ? 0 : l.clipOut ? 2 : 1;
                for (int k = 0; k < maskViews.size(); k++)
                    maskViews.get(k).setImageBitmap(com.pacco.animecut.view.BlendThumbs.maskTile(k, tpx, k == mk, rad));
            }
        };

        // Normal
        LinearLayout normalRow = new LinearLayout(this);
        normalRow.setPadding(0, dp(4), 0, dp(2));
        normalRow.addView(modeTile(l, Layer.MODE_NORMAL, tpx, modeViews, modeKeys, hint, refreshSel));
        list.addView(normalRow);
        // grupos
        int curGroup = -1;
        for (int g = 0; g < MODE_GROUPS.length; g++) for (int md : MODE_GROUPS[g]) if (md == oldMode) curGroup = g;
        for (int g = 0; g < MODE_GROUPS.length; g++) {
            LinearLayout row = new LinearLayout(this);
            row.setPadding(0, dp(2), 0, dp(4));
            for (int md : MODE_GROUPS[g]) row.addView(modeTile(l, md, tpx, modeViews, modeKeys, hint, refreshSel));
            android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            hs.addView(row);
            addGroup(list, MODE_GROUP_NAMES[g], hs, g == curGroup || g == 1);
        }
        // Enmascarar
        {
            LinearLayout row = new LinearLayout(this);
            row.setPadding(0, dp(2), 0, dp(4));
            String[] mkNames = {"Nada", "Recorte", "Excluir"};
            final String[] mkHelp = {"Se ve en todo el dibujo.",
                    "Solo encima de lo que hay en la capa de abajo (la luz cae solo sobre el personaje).",
                    "En todo MENOS en la capa de abajo (la luz pasa por detras del personaje)."};
            for (int k = 0; k < 3; k++) {
                final int kind = k;
                ImageView iv = new ImageView(this);
                maskViews.add(iv);
                row.addView(tileOf(iv, mkNames[k], tpx, new Runnable() {
                    @Override public void run() {
                        if (kind != 0 && !canvas.canClip(l)) {
                            toast("La capa de mas abajo no puede: no tiene otra capa debajo");
                            return;
                        }
                        l.clip = kind != 0;
                        l.clipOut = kind == 2;
                        hint.setText(mkHelp[kind]);
                        refreshSel.run();
                        canvas.refreshDisplayAsync();
                    }
                }));
            }
            android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            hs.addView(row);
            addGroup(list, "Enmascarar", hs, oldClip);
        }
        // Color de la luz
        {
            LinearLayout row = new LinearLayout(this);
            row.setPadding(0, dp(4), 0, dp(6));
            for (int k = 0; k < LIGHT_TINTS.length; k++) {
                final int col = LIGHT_TINTS[k];
                final String nm = LIGHT_TINT_NAMES[k];
                TextView chip = new TextView(this);
                android.graphics.drawable.GradientDrawable cd = new android.graphics.drawable.GradientDrawable();
                cd.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                cd.setColors(new int[]{0xFFFFFFFF, col});
                cd.setGradientType(android.graphics.drawable.GradientDrawable.RADIAL_GRADIENT);
                cd.setGradientRadius(dp(17));
                cd.setStroke(dp(1), 0x66FFFFFF);
                chip.setBackground(cd);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
                lp.setMargins(dp(3), 0, dp(3), 0);
                chip.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        hint.setText("Color de la luz: " + nm + " (Deshacer lo devuelve)");
                        canvas.tintLayer(l, col);
                    }
                });
                row.addView(chip, lp);
            }
            android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            hs.addView(row);
            addGroup(list, "Color de la luz", hs, false);
        }
        if (thumbsReady[0]) refreshSel.run();
        else {
            // la primera vez se arman por detras (la pantalla no se traba) y aparecen solas
            com.pacco.animecut.core.Task.run(new Runnable() {
                @Override public void run() {
                    try { com.pacco.animecut.view.BlendThumbs.warm(tpx, rad); } catch (OutOfMemoryError ignored) { }
                }
            }, new Runnable() {
                @Override public void run() {
                    thumbsReady[0] = com.pacco.animecut.view.BlendThumbs.ready(tpx);
                    refreshSel.run();
                }
            });
        }

        LinearLayout btns = new LinearLayout(this);
        btns.setGravity(Gravity.END);
        TextView cancel = new TextView(this), ok = new TextView(this);
        for (TextView b : new TextView[]{cancel, ok}) {
            b.setTextColor(0xFFFFFFFF);
            b.setTextSize(14f);
            b.setPadding(dp(14), dp(8), dp(14), dp(8));
        }
        cancel.setText("Cancelar");
        ok.setText("Aceptar");
        android.graphics.drawable.GradientDrawable okBg = new android.graphics.drawable.GradientDrawable();
        okBg.setColor(0xFF2F6BD8);
        okBg.setCornerRadius(dp(16));
        ok.setBackground(okBg);
        btns.addView(cancel);
        btns.addView(ok);
        box.addView(btns);
        opBar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                if (!u) return;
                l.opacity = Math.round(v * 255 / 100f);
                opText.setText("Opacidad " + v + "%");
                canvas.refreshDisplayAsync();
            }
        });
        final boolean[] decided = new boolean[1];
        final int popW = Math.min(dp(340), getResources().getDisplayMetrics().widthPixels - dp(16));
        modePop = new PopupWindow(box, popW, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        modePop.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
        modePop.setOutsideTouchable(false);
        modePop.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override public void onDismiss() {
                if (!decided[0]) {          // cerrar sin elegir = Cancelar
                    l.mode = oldMode;
                    l.opacity = oldOp;
                    l.clip = oldClip;
                    l.clipOut = oldOut;
                    canvas.refreshDisplayAsync();
                }
                afterLayerOp();
                if (reopenLayers) toggleLayersPanel();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { modePop.dismiss(); }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                decided[0] = true;
                int nm = l.mode, no = l.opacity;
                boolean nc = l.clip, nout = l.clipOut;
                if (nm != oldMode || no != oldOp || nc != oldClip || nout != oldOut) {
                    l.mode = oldMode;
                    l.opacity = oldOp;
                    l.clip = oldClip;
                    l.clipOut = oldOut;
                    canvas.recordPropsUndo("Mezcla y opacidad");
                    l.mode = nm;
                    l.opacity = no;
                    l.clip = nc;
                    l.clipOut = nout;
                    canvas.layersChangedAsync();
                    canvas.showHud(Layer.MODE_NAMES[nm] + " · " + Math.round(no * 100f / 255f) + "%"
                            + (nc ? (nout ? " · Excluir" : " · Recorte") : ""));
                    markDirty();
                }
                RowHolder h = rowHolders.get(l);
                if (h != null) bindRow(h, canvas.getProject() != null && canvas.getProject().activeLayer() == l);
                modePop.dismiss();
            }
        });
        View bottomBar = findViewById(R.id.bottomPanel);
        final int[] pos = {0, (bottomBar != null && bottomBar.getHeight() > 0 ? bottomBar.getHeight() : dp(120)) + dp(6)};
        modePop.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, pos[0], pos[1]);
        // se arrastra desde el titulo a cualquier lugar de la pantalla
        ttl.setOnTouchListener(new View.OnTouchListener() {
            float rx, ry;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { rx = e.getRawX(); ry = e.getRawY(); return true; }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    pos[0] += Math.round(e.getRawX() - rx);
                    pos[1] -= Math.round(e.getRawY() - ry);
                    rx = e.getRawX(); ry = e.getRawY();
                    int maxY = getResources().getDisplayMetrics().heightPixels - dp(120);
                    pos[1] = Math.max(0, Math.min(maxY, pos[1]));
                    modePop.update(pos[0], pos[1], -1, -1);
                    return true;
                }
                return true;
            }
        });
    }

    /** Un grupo que se abre y cierra (▶ / ▼), como en Alight Motion. */
    private void addGroup(LinearLayout list, final String name, final View content, boolean open) {
        final TextView hd = new TextView(this);
        hd.setTextColor(0xFFFFFFFF);
        hd.setTextSize(13f);
        hd.setPadding(dp(10), dp(9), dp(10), dp(9));
        android.graphics.drawable.GradientDrawable hb = new android.graphics.drawable.GradientDrawable();
        hb.setColor(0xFF31313A);
        hb.setCornerRadius(dp(8));
        hd.setBackground(hb);
        hd.setText((open ? "▼  " : "▶  ") + name);
        content.setVisibility(open ? View.VISIBLE : View.GONE);
        hd.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean now = content.getVisibility() != View.VISIBLE;
                content.setVisibility(now ? View.VISIBLE : View.GONE);
                hd.setText((now ? "▼  " : "▶  ") + name);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, 0);
        list.addView(hd, lp);
        list.addView(content);
    }

    private View modeTile(final Layer l, final int md, int tpx, List<ImageView> views, List<Integer> keys,
                          final TextView hint, final Runnable refreshSel) {
        ImageView iv = new ImageView(this);
        views.add(iv);
        keys.add(md);
        return tileOf(iv, Layer.MODE_NAMES[md], tpx, new Runnable() {
            @Override public void run() {
                l.mode = md;
                hint.setText(Layer.MODE_NAMES[md] + ": " + modeHelp(md));
                refreshSel.run();
                canvas.refreshDisplayAsync();     // al instante en el dibujo
            }
        });
    }

    private View tileOf(ImageView iv, String name, int tpx, final Runnable onTap) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.addView(iv, new LinearLayout.LayoutParams(tpx, tpx));
        TextView tv = new TextView(this);
        tv.setText(name);
        tv.setTextColor(0xFFCFD3DA);
        tv.setTextSize(10f);
        tv.setGravity(Gravity.CENTER);
        tv.setMaxLines(2);
        t.addView(tv, new LinearLayout.LayoutParams(tpx + dp(10), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), 0, dp(2), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onTap.run(); }
        });
        return t;
    }

    /** v8.55: lista de modos tipo Ibis (ya no se usa: la reemplazo la rueda). */
    private void modeListOld(final Layer l) {
        if (modePop != null && modePop.isShowing()) { modePop.dismiss(); return; }
        int[][] groups = {
                {Layer.MODE_NORMAL},
                {Layer.MODE_DARKEN, Layer.MODE_MULTIPLY, Layer.MODE_COLOR_BURN, Layer.MODE_LINEAR_BURN},
                {Layer.MODE_LIGHTEN, Layer.MODE_SCREEN, Layer.MODE_COLOR_DODGE, Layer.MODE_ADD},
                {Layer.MODE_OVERLAY, Layer.MODE_SOFT_LIGHT, Layer.MODE_HARD_LIGHT, Layer.MODE_VIVID_LIGHT,
                        Layer.MODE_LINEAR_LIGHT, Layer.MODE_PIN_LIGHT, Layer.MODE_HARD_MIX},
                {Layer.MODE_DIFFERENCE, Layer.MODE_EXCLUSION, Layer.MODE_SUBTRACT, Layer.MODE_DIVIDE},
                {Layer.MODE_COLOR, Layer.MODE_HUE, Layer.MODE_SATURATION, Layer.MODE_LUMINOSITY}};
        String[] gName = {null, "Oscurecer", "Aclarar", "Contraste", "Diferencia", "Color"};
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        final List<TextView> items = new ArrayList<TextView>();
        final List<Integer> itemModes = new ArrayList<Integer>();
        for (int g = 0; g < groups.length; g++) {
            if (gName[g] != null) {
                TextView hd = new TextView(this);
                hd.setText(gName[g]);
                hd.setTextColor(0xFFFFFFFF);
                hd.setTextSize(12f);
                hd.setBackgroundColor(0xFF3A3A42);
                hd.setPadding(dp(10), dp(3), dp(10), dp(3));
                box.addView(hd);
            }
            for (final int md : groups[g]) {
                final TextView it = new TextView(this);
                it.setText(Layer.MODE_NAMES[md]);
                it.setTextSize(14f);
                it.setPadding(dp(14), dp(9), dp(10), dp(9));
                it.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        canvas.setLayerMode(l, md);
                        for (int k = 0; k < items.size(); k++) {
                            boolean on = itemModes.get(k) == md;
                            items.get(k).setBackgroundColor(on ? 0xFFD3E3FA : 0xFFEDEDED);
                        }
                        RowHolder h = rowHolders.get(l);
                        if (h != null) bindRow(h, canvas.getProject() != null && canvas.getProject().activeLayer() == l);
                        markDirty();
                    }
                });
                it.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override public boolean onLongClick(View v) { toast(modeHelp(md)); return true; }
                });
                it.setTextColor(0xFF202020);
                it.setBackgroundColor(l.mode == md ? 0xFFD3E3FA : 0xFFEDEDED);
                items.add(it);
                itemModes.add(md);
                box.addView(it);
            }
        }
        ScrollView sc = new ScrollView(this);
        sc.addView(box);
        android.graphics.drawable.GradientDrawable bgd = new android.graphics.drawable.GradientDrawable();
        bgd.setColor(0xFFEDEDED);
        bgd.setCornerRadius(dp(8));
        sc.setBackground(bgd);
        int h = Math.min(dp(420), getResources().getDisplayMetrics().heightPixels / 2);
        modePop = new PopupWindow(sc, dp(200), h, true);
        modePop.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
        modePop.setOutsideTouchable(true);
        modePop.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override public void onDismiss() { afterLayerOp(); }
        });
        View panel = findViewById(R.id.layersPanel);
        if (panel != null && panel.getVisibility() == View.VISIBLE) {
            int[] loc = new int[2];
            panel.getLocationInWindow(loc);
            int x = Math.max(dp(4), loc[0] - dp(200) + dp(40));
            int y = Math.max(dp(40), loc[1] - h / 3);
            modePop.showAtLocation(getWindow().getDecorView(), Gravity.TOP | Gravity.START, x, y);
        } else {
            modePop.showAtLocation(getWindow().getDecorView(), Gravity.CENTER, 0, 0);
        }
    }

    /** El selector de modos de antes (iconos en cuadricula); queda por si se necesita. */
    private void modeGridDialog(final Layer l) {
        int[][] groups = {
                {Layer.MODE_NORMAL, Layer.MODE_MULTIPLY, Layer.MODE_ADD, Layer.MODE_OVERLAY, Layer.MODE_SCREEN},
                {Layer.MODE_DARKEN, Layer.MODE_MULTIPLY, Layer.MODE_COLOR_BURN, Layer.MODE_LINEAR_BURN},
                {Layer.MODE_LIGHTEN, Layer.MODE_SCREEN, Layer.MODE_COLOR_DODGE, Layer.MODE_ADD},
                {Layer.MODE_OVERLAY, Layer.MODE_SOFT_LIGHT, Layer.MODE_HARD_LIGHT, Layer.MODE_VIVID_LIGHT,
                        Layer.MODE_LINEAR_LIGHT, Layer.MODE_PIN_LIGHT, Layer.MODE_HARD_MIX},
                {Layer.MODE_DIFFERENCE, Layer.MODE_EXCLUSION, Layer.MODE_SUBTRACT, Layer.MODE_DIVIDE},
                {Layer.MODE_COLOR, Layer.MODE_HUE, Layer.MODE_SATURATION, Layer.MODE_LUMINOSITY}};
        String[] gName = {"MAS USADOS", "OSCURECER", "ACLARAR", "CONTRASTE (LUZ)", "DIFERENCIA", "COLOR"};
        int[] gIcon = {R.drawable.ic_paint, R.drawable.ic_shadow, R.drawable.ic_light, R.drawable.ic_tone, R.drawable.ic_sub, R.drawable.ic_hue};
        List<String> heads = new ArrayList<String>();
        List<List<MItem>> secs = new ArrayList<List<MItem>>();
        for (int g = 0; g < groups.length; g++) {
            List<MItem> m = new ArrayList<MItem>();
            for (int md : groups[g])
                m.add(new MItem(Layer.MODE_NAMES[md], String.valueOf(md), gIcon[g], l.mode == md ? 2 : -1, modeHelp(md)));
            heads.add(gName[g]);
            secs.add(m);
        }
        showIconGrid("Modo de mezcla", heads, secs, new KeyAction() { public void run(String k) {
            int md = Integer.parseInt(k);
            canvas.setLayerMode(l, md);
            canvas.showHud("Modo: " + Layer.MODE_NAMES[md]);
            afterLayerOp();
        }});
    }

    private static String modeHelp(int md) {
        switch (md) {
            case Layer.MODE_NORMAL: return "Tapa lo de abajo.";
            case Layer.MODE_MULTIPLY: return "Colorear B/N y sombras: no tapa la tinta.";
            case Layer.MODE_DARKEN: return "Se queda lo mas oscuro.";
            case Layer.MODE_COLOR_BURN: return "Sombra fuerte y saturada.";
            case Layer.MODE_LINEAR_BURN: return "Sombra muy fuerte.";
            case Layer.MODE_LIGHTEN: return "Se queda lo mas claro. Con amarillo: pinta lo negro de amarillo.";
            case Layer.MODE_SCREEN: return "Luces: el negro desaparece y queda solo la luz (fotos de luces con fondo negro).";
            case Layer.MODE_COLOR_DODGE: return "Brillo intenso (fuego, magia).";
            case Layer.MODE_ADD: return "Brillo fuerte (luz que quema), tambien llamado \"Sobreexposicion lineal\".";
            case Layer.MODE_OVERLAY: return "Dar vida: blanco aclara, oscuro oscurece, sin tapar.";
            case Layer.MODE_SOFT_LIGHT: return "Como Superponer pero mas suave.";
            case Layer.MODE_HARD_LIGHT: return "Como Superponer pero mas fuerte.";
            case Layer.MODE_VIVID_LIGHT: return "Contraste muy fuerte.";
            case Layer.MODE_LINEAR_LIGHT: return "Luz y sombra fuertes.";
            case Layer.MODE_PIN_LIGHT: return "Cambia solo donde hay mucha diferencia.";
            case Layer.MODE_HARD_MIX: return "Colores puros, estilo poster.";
            case Layer.MODE_DIFFERENCE: return "Invierte donde hay color (efectos).";
            case Layer.MODE_EXCLUSION: return "Como Diferencia pero mas suave.";
            case Layer.MODE_SUBTRACT: return "Resta el color.";
            case Layer.MODE_DIVIDE: return "Aclara mucho.";
            case Layer.MODE_COLOR: return "Tine los grises: el manga toma color sin perder sombras.";
            case Layer.MODE_HUE: return "Cambia solo el tono.";
            case Layer.MODE_SATURATION: return "Cambia solo que tan vivo es el color.";
            case Layer.MODE_LUMINOSITY: return "Cambia solo la luz (brillo).";
            case Layer.MODE_DARKER_COLOR: return "Deja el color entero mas oscuro: el de la capa o el de abajo.";
            case Layer.MODE_LIGHTER_COLOR: return "Deja el color entero mas claro: el de la capa o el de abajo.";
            case Layer.MODE_GLOW_DODGE: return "Brillo fuerte, mas intenso en los bordes suaves.";
            case Layer.MODE_ADD_GLOW: return "Luz que se suma, mas intensa en los bordes suaves.";
        }
        return "";
    }

    // ==================================================================
    // Menu de tres puntos
    // ==================================================================

    /** v8.42: una opcion del menu de tres puntos (icono + nombre; mantener pulsado = que hace). */
    private static final class MItem {
        final String label, key, desc;
        final int icon, state;   // state: -1 boton normal, 0 NO, 1 SI
        MItem(String label, String key, int icon, int state, String desc) {
            this.label = label; this.key = key; this.icon = icon; this.state = state; this.desc = desc;
        }
    }

    /**
     * v8.42: el menu de tres puntos como el panel de herramientas: secciones con iconos y el
     * nombre abajo. Los SI/NO se ven encendidos. Mantener pulsado explica la opcion abajo.
     * Las claves (key) son los mismos textos de siempre: runMenu no cambia.
     */
    private void mainMenu() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        final List<String> heads = new ArrayList<String>();
        final List<List<MItem>> secs = new ArrayList<List<MItem>>();
        List<MItem> m;

        heads.add("IMAGEN"); secs.add(m = new ArrayList<MItem>());
        m.add(new MItem("Abrir imagen", "Abrir otra imagen", R.drawable.ic_open, -1, "Abre otra imagen como obra nueva. La de ahora queda guardada."));
        m.add(new MItem("Imagen como capa", "Agregar una imagen como capa", R.drawable.ic_image, -1, "Pone otra imagen encima, en una capa nueva (tambien en Capas > Nueva)."));
        Layer actL = canvas.getProject() == null ? null : canvas.getProject().activeLayer();
        boolean bwOn = actL != null && actL.sat < 0 && (actL.sat <= -100 || actL.con != 0 || actL.gch != 0 || actL.hue == 0);
        m.add(new MItem("Blanco y negro", "Blanco y negro de la capa", R.drawable.ic_tone, bwOn ? 1 : 0,
                "Pasa la capa elegida a blanco y negro sin perder el color: se puede apagar cuando quieras."));
        // v8.97: los atajos vuelven (Brian los usa para trabajar rapido). Girar abre Recortar > Girar
        m.add(new MItem("Filtros", "Filtros de la capa", R.drawable.ic_tune, -1, "Extraer lineas, pictorizar, desenfoques, nitidez, sombra, resplandor, ruido y mas, con vista previa."));
        m.add(new MItem("Girar imagen", "Girar la imagen", R.drawable.ic_rotate, -1, "Abre Recortar en Girar: gira o voltea toda la obra."));
        // v8.89: "Ampliar lienzo" se paso a Herramientas > Recortar (no se repite aqui)
        m.add(new MItem(colorRefBitmap != null ? "Cambiar referencia" : "Referencia color",
                colorRefBitmap != null ? "Referencia de color: CAMBIAR" : "Importar referencia de color", R.drawable.ic_ref_color, -1,
                "Una imagen a color para tomar sus colores mientras pintas."));
        if (colorRefBitmap != null)
            m.add(new MItem("Quitar referencia", "Quitar referencia de color", R.drawable.ic_trash, -1, "Cierra la imagen de referencia."));

        // v8.53: aqui solo lo basico. Colorear, Toques, Luz, Estilo, Mejorar y Manga estan arriba de
        // todo en Herramientas; girar el lienzo tiene su boton arriba; voltear y girar capas, al
        // costado de Capas.
        heads.add("PINCEL Y PERSONAJE"); secs.add(m = new ArrayList<MItem>());
        m.add(new MItem("Preparar personaje", "Preparar personaje (pasos rapidos)", R.drawable.ic_puppet, -1, "Pasos guiados para sacar un personaje y dejarlo listo para animar."));
        m.add(new MItem("Pintado plano", "Repasar no oscurece (pintado plano): " + (canvas.isFlatPaint() ? "SI" : "NO"), R.drawable.ic_paint,
                canvas.isFlatPaint() ? 1 : 0, "SI: repasar con el mismo color no lo oscurece (color parejo)."));
        m.add(new MItem("Estabilizador", "Estabilizador del trazo", R.drawable.ic_line_cont, -1, "Suaviza el temblor del dedo al dibujar."));
        m.add(new MItem("Dureza pincel", "Dureza del pincel", R.drawable.ic_brush, -1, "Borde duro o suave del pincel."));
        m.add(new MItem("Borrar fondo +", "Borrar fondo: ajustes avanzados", R.drawable.ic_bgerase, -1, "Ajustes finos de la herramienta Borrar fondo."));

        heads.add("VISTA"); secs.add(m = new ArrayList<MItem>());
        m.add(new MItem("Encuadrar", "Encuadrar la imagen", R.drawable.ic_fit, -1, "Muestra la imagen entera en la pantalla."));
        m.add(new MItem("Vista normal", "Restablecer vista (sin giro ni volteo)", R.drawable.ic_view_reset, -1, "Quita el giro y el espejo de la vista."));
        m.add(new MItem("Espejo", "Voltear la vista (espejo): " + (canvas.isViewFlipped() ? "SI" : "NO"), R.drawable.ic_mirror,
                canvas.isViewFlipped() ? 1 : 0, "Mira tu dibujo al reves para ver errores. No cambia la imagen."));
        m.add(new MItem("Girar 2 dedos", "Girar el lienzo con dos dedos: " + (canvas.isRotateEnabled() ? "SI" : "NO"), R.drawable.ic_hand,
                canvas.isRotateEnabled() ? 1 : 0, "SI: con dos dedos tambien giras el lienzo."));
        m.add(new MItem("Cursor lupa", "Cursor separado con lupa: " + (canvas.isAim() ? "SI" : "NO"), R.drawable.ic_aim,
                canvas.isAim() ? 1 : 0, "El punto de pintar queda separado del dedo, con lupa, para ver donde pintas."));
        m.add(new MItem("Solo lapiz", "Solo el lapiz pinta: " + (canvas.isStylusOnly() ? "SI" : "NO"), R.drawable.ic_brush,
                canvas.isStylusOnly() ? 1 : 0, "SI: con lapiz (S Pen u otro) el dedo y la palma no pintan; el dedo solo mueve y hace zoom."));
        m.add(new MItem("Presion lapiz", "Presion del lapiz: " + (canvas.isPenPressure() ? "SI" : "NO"), R.drawable.ic_brush,
                canvas.isPenPressure() ? 1 : 0, "SI: con lapiz, apretar mas hace el trazo mas grueso (Pintar y Goma)."));
        m.add(new MItem("Zoom suave", "Zoom suave (como la galeria): " + (canvas.isSmoothZoom() ? "SI" : "NO"), R.drawable.ic_zoom,
                canvas.isSmoothZoom() ? 1 : 0, "SI: el zoom se mueve suave, como en la galeria."));

        heads.add("AYUDA Y AJUSTES"); secs.add(m = new ArrayList<MItem>());
        m.add(new MItem("Guia rapida", "Guia rapida: como se usa", R.drawable.ic_help, -1, "Los pasos basicos de la app."));
        m.add(new MItem("Herramientas", "Que hace cada herramienta", R.drawable.ic_info, -1, "Tarjetas con lo que hace cada herramienta."));
        boolean demo = sp.getBoolean("demo_on", false);
        m.add(new MItem("Animacion", "Animacion al elegir herramienta: " + (demo ? "SI" : "NO"), R.drawable.ic_preview,
                demo ? 1 : 0, "SI: al elegir una herramienta se ve una animacion corta de como se usa."));
        m.add(new MItem("Rendimiento", "Medir rendimiento (prueba en este telefono)", R.drawable.ic_speed, -1, "Mide que tan rapido va este telefono."));
        m.add(new MItem("Acerca de", "Acerca de y licencias", R.drawable.ic_info, -1, "Version, privacidad y licencias de las piezas de otros autores que usa la app."));

        heads.add("GUARDAR"); secs.add(m = new ArrayList<MItem>());
        m.add(new MItem("Guardar ahora", "Guardar ahora", R.drawable.ic_save, -1, "Guarda la obra en Mis obras."));
        m.add(new MItem("Guardar copia", "Guardar copia en un archivo", R.drawable.ic_export, -1, "Guarda una copia de la obra en un archivo."));

        showIconGrid("Paint Zeta", heads, secs, new KeyAction() { public void run(String k) { runMenu(k); } });
    }

    private interface KeyAction { void run(String key); }

    /** v8.52: rejilla de iconos con secciones (menu ⋮, opciones de capa, modos de mezcla). */
    private void showIconGrid(String title, List<String> heads, List<List<MItem>> secs, final KeyAction act) {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(2), dp(10), dp(4));
        sv.addView(box);
        final TextView foot = new TextView(this);
        foot.setText("Manten pulsada una opcion para ver que hace");
        foot.setTextColor(0xFF9FC6FF);
        foot.setTextSize(11f);
        foot.setPadding(dp(14), dp(4), dp(14), dp(2));
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        // WRAP + peso: si no cabe, se achica la lista (con scroll) y el texto de abajo sigue visible.
        outer.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        outer.addView(foot);
        final AlertDialog[] dlg = new AlertDialog[1];
        int cols = 5;   // v8.59: mas compacto
        for (int si = 0; si < secs.size(); si++) {
            TextView h = new TextView(this);
            h.setText(heads.get(si));
            h.setTextColor(0xFF8A8A92);
            h.setTextSize(11f);
            h.setPadding(dp(4), dp(6), 0, dp(1));
            box.addView(h);
            LinearLayout row = null;
            int inRow = 0;
            for (final MItem it : secs.get(si)) {
                if (row == null || inRow == cols) {
                    if (row != null) fillRow(row, inRow, cols);
                    row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    box.addView(row);
                    inRow = 0;
                }
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(1), dp(5), dp(1), dp(3));
                cell.setBackgroundResource(it.state >= 1 ? R.drawable.bg_tool_on : R.drawable.bg_cell);
                // v8.43: alto fijo (WRAP + minimo). Con MATCH_PARENT las filas incompletas median 1 px y no se veian.
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                clp.setMargins(dp(1), dp(1), dp(1), dp(1));
                cell.setLayoutParams(clp);
                cell.setMinimumHeight(dp(58));
                ImageView img = new ImageView(this);
                img.setLayoutParams(new LinearLayout.LayoutParams(dp(20), dp(20)));
                img.setImageResource(it.icon);
                cell.addView(img);
                TextView t = new TextView(this);
                t.setText(it.label);
                t.setTextColor(0xFFE0E0E0);
                t.setTextSize(9f);
                t.setGravity(android.view.Gravity.CENTER);
                t.setMaxLines(2);
                t.setPadding(0, dp(2), 0, 0);
                cell.addView(t);
                if (it.state == 0 || it.state == 1) {
                    TextView st = new TextView(this);
                    st.setText(it.state == 1 ? "SI" : "NO");
                    st.setTextColor(it.state == 1 ? 0xFFFFFFFF : 0xFF8A8A92);
                    st.setTextSize(9f);
                    st.setGravity(android.view.Gravity.CENTER);
                    cell.addView(st);
                }
                cell.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (dlg[0] != null) dlg[0].dismiss();
                        act.run(it.key);
                    }
                });
                cell.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override public boolean onLongClick(View v) {
                        foot.setText(it.label + ": " + it.desc);
                        return true;
                    }
                });
                row.addView(cell);
                inRow++;
            }
            if (row != null) fillRow(row, inRow, cols);
        }
        // v8.59: titulo chico con ✕ en la misma linea (sin barra de titulo ni boton grande abajo)
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(8), dp(6), 0);
        TextView tt = new TextView(this);
        tt.setText(title);
        tt.setTextColor(0xFFFFFFFF);
        tt.setTextSize(15f);
        TextView x = new TextView(this);
        x.setText("✕");
        x.setTextColor(0xFFDDDDDD);
        x.setTextSize(18f);
        x.setPadding(dp(12), dp(4), dp(12), dp(4));
        top.addView(tt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(x);
        outer.addView(top, 0);
        dlg[0] = new SheetBuilder(this).setView(outer).show();
        x.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dlg[0].dismiss(); }
        });
    }

    private void runMenu(String item) {
        if (item.startsWith("Acerca de")) {
            startActivity(new android.content.Intent(this, AboutActivity.class));
        } else if (item.startsWith("Preparar personaje (pasos rapidos)")) {
            animationWorkflowDialog();
        } else if (item.startsWith("Toques suaves")) {
            softOpen(-1);
        } else if (item.startsWith("Luz y ambiente")) {
            atmosOpen();
        } else if (item.startsWith("Colorear facil")) {
            easyColorStart();
        } else if (item.startsWith("Colorear manga")) {
            mangaEntry();
        } else if (item.startsWith("Guia")) {
            guideDialog();
        } else if (item.startsWith("Que hace")) {
            toolCardsList();
        } else if (item.startsWith("Encuadrar")) {
            if (needProject()) canvas.fit();
        } else if (item.startsWith("Restablecer vista")) {
            if (needProject()) canvas.resetView();
        } else if (item.startsWith("Voltear la vista")) {
            if (needProject()) canvas.toggleViewFlip();
        } else if (item.startsWith("Girar el lienzo con dos dedos")) {
            boolean on = !canvas.isRotateEnabled();
            canvas.setRotateEnabled(on);
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("rotate_view", on).apply();
            canvas.showHud(on ? "Dos dedos: mover, ampliar y GIRAR" : "Dos dedos: solo mover y ampliar");
        } else if (item.startsWith("Cursor")) {
            canvas.setAim(!canvas.isAim());
            canvas.showHud(canvas.isAim() ? "Cursor separado del dedo, con lupa" : "Cursor normal");
        } else if (item.startsWith("Ver en rojo")) {
            canvas.previewAutoLines();
        } else if (item.startsWith("Varita no se escapa")) {
            boolean on = !canvas.isAutoLines();
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("auto_lines", on).apply();
            canvas.setAutoLines(on);
            canvas.showHud(on ? "La varita respeta la linea negra aunque tenga cortes" : "Varita normal");
            if (on) canvas.previewAutoLines();
        } else if (item.startsWith("Solo el lapiz pinta")) {
            boolean on = !canvas.isStylusOnly();
            getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("solo_lapiz", on ? 1 : 0).apply();
            canvas.setStylusOnly(on);
            canvas.showHud(on ? "Solo el lapiz pinta: el dedo mueve y hace zoom" : "El dedo tambien pinta", 2000);
        } else if (item.startsWith("Presion del lapiz")) {
            boolean on = !canvas.isPenPressure();
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("presion_lapiz", on).apply();
            canvas.setPenPressure(on);
            canvas.showHud(on ? "Presion del lapiz: apretar mas = trazo mas grueso" : "Presion del lapiz apagada: grosor fijo", 2000);
        } else if (item.startsWith("Zoom suave")) {
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean on = !canvas.isSmoothZoom();
            sp.edit().putBoolean("smooth_zoom", on).apply();
            canvas.setSmoothZoom(on);
            canvas.showHud(on ? "Zoom suave" : "Zoom con pixeles marcados, para bordes exactos");
        } else if (item.startsWith("Animacion")) {
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean on = !sp.getBoolean("demo_on", false);
            sp.edit().putBoolean("demo_on", on).apply();
            toast(on ? "Animacion al elegir herramienta: SI" : "Animaciones apagadas");
        } else if (item.startsWith("Ampliar lienzo")) {
            enlargeCanvasDialog();
        } else if (item.startsWith("Medir rendimiento")) {
            perfDialog();
        } else if (item.startsWith("Borrar fondo: ajustes")) {
            bgSettingsDialog();
        } else if (item.startsWith("Abrir otra")) {
            autosave(false);
            openImage.launch("image/*");
        } else if (item.startsWith("Agregar una imagen")) {
            addImage.launch("image/*");
        } else if (item.startsWith("Importar referencia") || item.startsWith("Referencia de color")) {
            pendingColorRefTarget = null;
            pickColorRef.launch(new String[]{"image/*"});
        } else if (item.startsWith("Quitar referencia")) {
            clearColorReference(true);
        } else if (item.startsWith("Ajustes de la varita")) {
            wandDialog();
        } else if (item.startsWith("Varita en toda")) {
            canvas.setWandGlobal(!canvas.isWandGlobal());
            toast(canvas.isWandGlobal() ? "La varita busca ese color en toda la imagen" : "La varita agarra solo lo pegado");
        } else if (item.startsWith("Repasar no oscurece")) {
            boolean on = !canvas.isFlatPaint();
            canvas.setFlatPaint(on);
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("flat_paint", on).apply();
            canvas.showHud(on ? "Repasar no oscurece: el color queda parejo" : "Cada pasada oscurece un poco mas");
        } else if (item.startsWith("Blanco y negro de la capa")) {
            bwDialog();
        } else if (item.startsWith("Estilo de edicion")) {
            lookOpen();
        } else if (item.startsWith("Mejorar imagen")) {
            enhanceDialog();
        } else if (item.startsWith("Filtros")) {
            filtersDialog();
        } else if (item.startsWith("Girar")) {
            // v8.96: no otra ventana: Recortar en la pestana Girar
            if (needProject()) {
                cropTab = 2;
                selectTool(CanvasView.MODE_CROP);
            }
        } else if (item.startsWith("Estabilizador")) {
            stabilizerDialog();
        } else if (item.startsWith("Dureza")) {
            hardnessDialog();
        } else if (item.startsWith("Guardar ahora")) {
            if (needProject()) autosave(true);
        } else if (item.startsWith("Guardar copia")) {
            projectDialog();
        }
    }

    /** Lista de todas las herramientas; al tocar una, sale su ficha animada. */
    private void toolCardsList() {
        final List<int[]> defs = new ArrayList<int[]>();
        List<String> names = new ArrayList<String>();
        for (int[] t : TOOLS) {
            if (t[1] == CanvasView.MODE_CURVE || t[1] == CanvasView.MODE_POLY) continue;   // v8.86: van dentro de Figuras
            defs.add(t);
            names.add(toolInfo(t[1], t[2])[0]);
        }
        new SheetBuilder(this)
                .setTitle("Toca una para ver que hace")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        showToolCard(defs.get(i)[1], defs.get(i)[2]);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Flujo guiado: cinco acciones reales, sin exponer herramientas antiguas de azul. */
    private void animationWorkflowDialog() {
        if (!needProject()) return;
        final String[] steps = {
                "1. Quitar fondo",
                "2. Seleccionar parte con Lazo",
                "3. Pintar o corregir bordes",
                "4. Ajustar con Especial",
                "5. Exportar partes como PNG transparentes",
                "Ver las capas"
        };
        new SheetBuilder(this)
                .setTitle("Preparar personaje para animar")
                .setMessage("Cada parte debe estar en su propia capa. Pellizca con dos dedos para acercar y mover sin cambiar de herramienta.")
                .setItems(steps, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int index) {
                        if (index == 0) selectTool(CanvasView.MODE_BGERASE);
                        else if (index == 1) {
                            selectTool(CanvasView.MODE_LASSO);
                            canvas.showHud("Rodea la parte: se creara una capa nueva");
                        } else if (index == 2) selectTool(CanvasView.MODE_PAINT);
                        else if (index == 3) selectTool(CanvasView.MODE_LIQUIFY);
                        else if (index == 4) exportAnimationZip();
                        else if (!layersOpen()) toggleLayersPanel();
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Exportacion recomendada para Alight Motion: un PNG completo por capa. */
    private void exportAnimationZip() {
        final Project p = canvas.getProject();
        if (p == null) return;
        int count = 0;
        for (Layer l : p.layers) if (l.visible) count++;
        if (count == 0) {
            toast("Activa por lo menos una capa para exportar");
            return;
        }
        outW = p.w;
        outH = p.h;
        edgeClean = 1;  // Mantiene la transparencia y limpia RGB de bordes.
        new SheetBuilder(this)
                .setTitle("Exportar " + count + " capas")
                .setMessage("Se guardara un ZIP con un PNG transparente por capa visible. "
                        + "Todas conservaran " + p.w + " × " + p.h
                        + " pixeles para quedar alineadas al importarlas en tu app de animacion.")
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        // v8.39: directo a Descargas > Paint Zeta (sin elegir carpeta)
                        Uri zu = appFolderUri(obraName() + "_partes_" + stampNow() + ".zip", "application/zip", true);
                        if (zu != null) { exportWhere = "Descargas > Paint Zeta"; doExportZip(zu); }
                        else createZip.launch("PaintZeta_partes.zip");
                    }
                })
                .setNeutralButton("Elegir carpeta", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        createZip.launch("PaintZeta_partes.zip");
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ==================================================================
    // Exportar
    // ==================================================================

    private void exportDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        // v8.90: la imagen completa se guarda en PNG, JPG o WebP, con medida, calidad, peso y compartir
        final boolean direct = getSharedPreferences("pz", MODE_PRIVATE).getBoolean("img_direct", false);
        String[] items = direct
                ? new String[]{"Para animar: PNG por capa en ZIP (recomendado)",
                "Imagen completa (directo, con tus ajustes)",
                "Opciones avanzadas: capas sueltas y tamanos",
                "Imagen completa: cambiar formato, calidad, peso..."}
                : new String[]{"Para animar: PNG por capa en ZIP (recomendado)",
                "Imagen completa: PNG, JPG o WebP, como se ve (y compartir)",
                "Opciones avanzadas: capas sueltas y tamanos"};
        new SheetBuilder(this)
                .setTitle("¿Que necesitas exportar?")
                .setItems(items,
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int which) {
                                if (which == 0) exportAnimationZip();
                                else if (which == 1) saveImageEntry();
                                else if (which == 3) saveImageDialog();
                                else exportAdvancedDialog();
                            }
                        }).show();
    }

    // ==================================================================
    // v8.90 Guardar imagen: formato, calidad, medida, peso maximo, nombre y compartir
    // ==================================================================

    private static final String[] IMG_SIZE_NAMES = {"Original", "75 %", "50 %", "Lado 1080"};
    private static final String[] IMG_MAX_NAMES = {"Sin limite", "300 kB", "500 kB", "1 MB", "2 MB"};
    private static final long[] IMG_MAX = {0L, 300_000L, 500_000L, 1_000_000L, 2_000_000L};
    private PopupWindow imgPop;

    private int[] imgOutSize(Project p, int sel) {
        // v8.92: 100 + n = medida de "Para:" (WhatsApp, Instagram...)
        if (sel >= 100) return com.pacco.animecut.core.SharePresets.outSize(sel - 100, p.w, p.h);
        switch (sel) {
            case 1: return new int[]{Math.max(1, Math.round(p.w * 0.75f)), Math.max(1, Math.round(p.h * 0.75f))};
            case 2: return new int[]{Math.max(1, p.w / 2), Math.max(1, p.h / 2)};
            case 3: case 4: case 5: {
                // 3 lado 1080; v8.99: 4 lado 2048 y 5 lado 1280 (Galeria Alta y Normal)
                int side = sel == 3 ? 1080 : sel == 4 ? 2048 : 1280;
                int L = Math.max(p.w, p.h);
                if (L <= side) return new int[]{p.w, p.h};
                return new int[]{Math.max(1, Math.round(p.w * side / (float) L)), Math.max(1, Math.round(p.h * side / (float) L))};
            }
            default: return new int[]{p.w, p.h};
        }
    }

    /** "Imagen completa": con "Guardar directo" prendido no pregunta nada. */
    private void saveImageEntry() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("img_direct", false)) {
            saveImageNow(sp.getInt("img_size", 0), sp.getInt("img_fmt", 0), sp.getInt("img_q", 90),
                    IMG_MAX[Math.max(0, Math.min(IMG_MAX.length - 1, sp.getInt("img_max", 0)))],
                    obraName() + "_" + stampNow(), false);
        } else {
            saveImageDialog();
        }
    }

    /**
     * v8.99 Guardar imagen, ordenado (pedido de Brian, mirando iMarkup): arriba "Para donde" con
     * iconos redondos (cada uno pone solo la medida y el formato justos), "Calidad" con 3 opciones,
     * todo lo demas escondido en "Mas opciones", y abajo dos botones grandes: Compartir y Guardar.
     */
    private static final String[] DEST_NAMES = {"Galeria", "WhatsApp", "Instagram", "Historias", "Facebook", "Correo", "X"};
    private static final int[] DEST_ICON = {R.drawable.ic_dest_gallery, R.drawable.ic_dest_chat, R.drawable.ic_dest_camera,
            R.drawable.ic_dest_story, R.drawable.ic_dest_people, R.drawable.ic_dest_mail, R.drawable.ic_dest_hash};
    private static final int[] DEST_COLOR = {0xFF3D3D48, 0xFF2E8B57, 0xFFB0407A, 0xFF7D4BB0, 0xFF3566C8, 0xFFC0703A, 0xFF4A4A55};
    private static final String[] QLEVEL_NAMES = {"Normal", "Alta", "Maxima"};

    /** Medida, formato, calidad y peso segun "Para donde" y "Calidad". out = {size, fmt, q, max}. */
    private static void destSettings(int dest, int ql, int[] out) {
        if (dest <= 0) {
            // galeria: siempre PNG (guarda la transparencia del recorte)
            out[0] = ql >= 2 ? 0 : ql == 1 ? 4 : 5;
            out[1] = Exporter.FMT_PNG;
            out[2] = 95;
            out[3] = 0;
            return;
        }
        int k = dest - 1;
        out[0] = 100 + k;
        out[1] = Exporter.FMT_JPG;
        int q = com.pacco.animecut.core.SharePresets.quality(k);
        long mb = com.pacco.animecut.core.SharePresets.maxBytes(k);
        if (ql <= 0) q = Math.max(60, q - 10);
        else if (ql >= 2) { q = 95; mb = 0L; }
        out[2] = q;
        out[3] = 0;
        for (int i = 0; i < IMG_MAX.length; i++) if (IMG_MAX[i] == mb) out[3] = i;
    }

    /** Fila de opciones con colores tranquilos (elegida: verde azulado; las demas: gris). */
    private Runnable softSegRow(LinearLayout parent, String[] names, final int[] value, final int[] ids, final Runnable changed) {
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] tvs = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            tvs[i] = new TextView(this);
            tvs[i].setText(names[i]);
            tvs[i].setTextColor(0xFFFFFFFF);
            tvs[i].setTextSize(13f);
            tvs[i].setGravity(Gravity.CENTER);
            tvs[i].setSingleLine(true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            if (i > 0) lp.setMargins(dp(6), 0, 0, 0);
            seg.addView(tvs[i], lp);
        }
        parent.addView(seg);
        final Runnable paint = new Runnable() {
            @Override public void run() {
                for (int i = 0; i < tvs.length; i++) {
                    android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
                    boolean on = value[0] == ids[i];
                    bg.setColor(on ? 0xFF1F8A6A : 0xFF2C2C34);
                    bg.setCornerRadius(dp(10));
                    tvs[i].setBackground(bg);
                }
            }
        };
        for (int i = 0; i < tvs.length; i++) {
            final int id = ids[i];
            tvs[i].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    value[0] = id;
                    paint.run();
                    changed.run();
                }
            });
        }
        paint.run();
        return paint;
    }

    private TextView saveHead(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFE8E8EE);
        t.setTextSize(14f);
        t.setPadding(0, dp(12), 0, dp(6));
        return t;
    }

    private void saveImageDialog() {
        if (!needProject()) return;
        if (imgPop != null && imgPop.isShowing()) imgPop.dismiss();
        final Project p = canvas.getProject();
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        final int[] size = {sp.getInt("img_size", 0)}, fmt = {sp.getInt("img_fmt", 0)},
                q = {sp.getInt("img_q", 90)}, max = {sp.getInt("img_max", 0)};
        final int[] dest = {Math.max(0, Math.min(DEST_NAMES.length - 1, sp.getInt("img_dest", 0)))};
        final int[] ql = {Math.max(0, Math.min(2, sp.getInt("img_ql", 2)))};
        final boolean[] custom = {sp.getBoolean("img_custom", false)};
        if (!custom[0]) {
            int[] o = new int[4];
            destSettings(dest[0], ql[0], o);
            size[0] = o[0]; fmt[0] = o[1]; q[0] = o[2]; max[0] = o[3];
        }
        LinearLayout box = darkCard();
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        TextView title = new TextView(this);
        title.setText("Guardar imagen");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(17f);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        box.addView(title);
        final TextView info = new TextView(this);
        info.setTextColor(0xFF9A9AA6);
        info.setTextSize(12f);
        info.setPadding(0, dp(2), 0, 0);
        box.addView(info);
        final Runnable[] refresh = new Runnable[1];
        final Runnable[] moreRows = new Runnable[3];        // formato, medida, peso
        final SeekBar[] qBar = new SeekBar[1];
        final TextView[] qVal = new TextView[1];

        // ---- Para donde
        box.addView(saveHead("Para donde"));
        HorizontalScrollView dhs = new HorizontalScrollView(this);
        dhs.setHorizontalScrollBarEnabled(false);
        LinearLayout drow = new LinearLayout(this);
        drow.setOrientation(LinearLayout.HORIZONTAL);
        dhs.addView(drow);
        final ImageView[] dIcon = new ImageView[DEST_NAMES.length];
        final TextView[] dName = new TextView[DEST_NAMES.length];
        final Runnable paintDest = new Runnable() {
            @Override public void run() {
                for (int i = 0; i < dIcon.length; i++) {
                    boolean on = !custom[0] && dest[0] == i;
                    android.graphics.drawable.GradientDrawable c = new android.graphics.drawable.GradientDrawable();
                    c.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                    c.setColor(DEST_COLOR[i]);
                    if (on) c.setStroke(dp(3), 0xFF2EE6A6);
                    dIcon[i].setBackground(c);
                    dName[i].setTextColor(on ? 0xFF2EE6A6 : 0xFFC8C8D0);
                }
            }
        };
        final Runnable applyDest = new Runnable() {
            @Override public void run() {
                custom[0] = false;
                int[] o = new int[4];
                destSettings(dest[0], ql[0], o);
                size[0] = o[0]; fmt[0] = o[1]; q[0] = o[2]; max[0] = o[3];
                if (qBar[0] != null) qBar[0].setProgress(q[0]);
                for (Runnable r : moreRows) if (r != null) r.run();
                paintDest.run();
                refresh[0].run();
            }
        };
        for (int i = 0; i < DEST_NAMES.length; i++) {
            final int k = i;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            dIcon[i] = new ImageView(this);
            dIcon[i].setImageResource(DEST_ICON[i]);
            dIcon[i].setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            dIcon[i].setPadding(dp(12), dp(12), dp(12), dp(12));
            it.addView(dIcon[i], new LinearLayout.LayoutParams(dp(50), dp(50)));
            dName[i] = new TextView(this);
            dName[i].setText(DEST_NAMES[i]);
            dName[i].setTextSize(11f);
            dName[i].setSingleLine(true);
            dName[i].setGravity(Gravity.CENTER);
            dName[i].setPadding(0, dp(4), 0, 0);
            it.addView(dName[i], new LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT));
            it.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dest[0] = k;
                    applyDest.run();
                    if (k > 0) canvas.showHud(com.pacco.animecut.core.SharePresets.DESC[k - 1], 2000);
                    else canvas.showHud("Galeria: PNG, guarda la transparencia", 1600);
                }
            });
            drow.addView(it, new LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        box.addView(dhs);

        // ---- Calidad (3 opciones)
        box.addView(saveHead("Calidad"));
        final Runnable[] qlRow = new Runnable[1];
        qlRow[0] = softSegRow(box, QLEVEL_NAMES, ql, new int[]{0, 1, 2}, new Runnable() {
            @Override public void run() { applyDest.run(); }
        });

        // ---- Mas opciones (cerrado)
        final TextView moreBtn = new TextView(this);
        moreBtn.setTextColor(0xFF2EE6A6);
        moreBtn.setTextSize(13f);
        moreBtn.setPadding(0, dp(14), 0, dp(6));
        box.addView(moreBtn);
        final LinearLayout more = new LinearLayout(this);
        more.setOrientation(LinearLayout.VERTICAL);
        box.addView(more);
        final Runnable manual = new Runnable() {
            @Override public void run() {
                custom[0] = true;
                paintDest.run();
                refresh[0].run();
            }
        };
        more.addView(stabLabel("Formato"));
        moreRows[0] = softSegRow(more, new String[]{"PNG", "JPG", "WebP"}, fmt, new int[]{0, 1, 2}, manual);
        more.addView(stabLabel("Medida"));
        moreRows[1] = softSegRow(more, IMG_SIZE_NAMES, size, new int[]{0, 1, 2, 3}, manual);
        final LinearLayout lossy = new LinearLayout(this);
        lossy.setOrientation(LinearLayout.VERTICAL);
        more.addView(lossy);
        qVal[0] = stabHead(lossy, "Calidad exacta");
        qBar[0] = stabSlider(lossy, 100, q[0], new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                q[0] = Math.max(30, v);
                qVal[0].setText(String.valueOf(q[0]));
                if (user) manual.run();
            }
        });
        qVal[0].setText(String.valueOf(q[0]));
        lossy.addView(stabLabel("Peso maximo"));
        moreRows[2] = softSegRow(lossy, new String[]{"Libre", "300 kB", "500 kB", "1 MB"}, max, new int[]{0, 1, 2, 3}, manual);
        more.addView(stabLabel("Nombre"));
        final android.widget.EditText name = new android.widget.EditText(this);
        name.setSingleLine(true);
        name.setText(obraName() + "_" + stampNow());
        name.setTextColor(0xFFFFFFFF);
        name.setTextSize(13f);
        more.addView(name);
        final android.widget.CheckBox direct = new android.widget.CheckBox(this);
        direct.setText("La proxima vez guardar directo (sin esta ventana)");
        direct.setTextColor(0xFFD0D0D6);
        direct.setTextSize(12f);
        direct.setChecked(sp.getBoolean("img_direct", false));
        more.addView(direct);
        final boolean[] open = {false};
        final Runnable paintMore = new Runnable() {
            @Override public void run() {
                more.setVisibility(open[0] ? View.VISIBLE : View.GONE);
                moreBtn.setText(open[0] ? "Menos opciones  ▴" : "Mas opciones  ▾");
            }
        };
        moreBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { open[0] = !open[0]; paintMore.run(); }
        });
        paintMore.run();

        refresh[0] = new Runnable() {
            @Override public void run() {
                boolean lossyOn = fmt[0] != Exporter.FMT_PNG;
                lossy.setAlpha(lossyOn ? 1f : 0.35f);
                setEnabledDeep(lossy, lossyOn);
                int[] o = imgOutSize(p, size[0]);
                String f = fmt[0] == Exporter.FMT_PNG ? "PNG con transparencia" : fmt[0] == Exporter.FMT_JPG ? "JPG liviano" : "WebP liviano";
                info.setText(o[0] + " x " + o[1] + "  ·  " + f
                        + (lossyOn && max[0] > 0 ? "  ·  hasta " + IMG_MAX_NAMES[max[0]] : "")
                        + (custom[0] ? "  ·  a tu gusto" : ""));
            }
        };
        paintDest.run();
        refresh[0].run();

        // ---- botones grandes
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(0, dp(16), 0, 0);
        TextView share = softButton("Compartir", false);
        TextView save = softButton("Guardar", true);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, dp(46), 1f);
        btns.addView(share, bl);
        LinearLayout.LayoutParams bl2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        bl2.setMargins(dp(10), 0, 0, 0);
        btns.addView(save, bl2);
        box.addView(btns);
        View.OnClickListener go = new View.OnClickListener() {
            @Override public void onClick(View v) {
                sp.edit().putInt("img_size", size[0]).putInt("img_fmt", fmt[0]).putInt("img_q", q[0])
                        .putInt("img_max", max[0]).putBoolean("img_direct", direct.isChecked())
                        .putInt("img_dest", dest[0]).putInt("img_ql", ql[0]).putBoolean("img_custom", custom[0]).apply();
                String n = name.getText().toString().trim();
                if (n.isEmpty()) n = obraName() + "_" + stampNow();
                if (imgPop != null) imgPop.dismiss();
                saveImageNow(size[0], fmt[0], q[0], fmt[0] == Exporter.FMT_PNG ? 0L : IMG_MAX[max[0]], n,
                        v.getTag() != null);
            }
        };
        share.setTag("share");
        share.setOnClickListener(go);
        save.setOnClickListener(go);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        int w = Math.min(dp(360), getResources().getDisplayMetrics().widthPixels - dp(16));
        imgPop = showCardPop(sv, box, null, w, 0.85f);
    }

    private static String kb(long n) {
        return n >= 1_000_000L ? String.format(Locale.US, "%.1f MB", n / 1e6) : Math.max(1, Math.round(n / 1000.0)) + " kB";
    }

    private void saveImageNow(final int sizeSel, final int fmt, final int q, final long maxBytes, String name, final boolean share) {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        final int[] o = imgOutSize(p, sizeSel);
        final String file = safeName(name) + "." + Exporter.FMT_EXT[fmt];
        final Uri u = appFolderUri(file, Exporter.FMT_MIME[fmt], false);
        if (u == null) { toast("No se pudo crear el archivo en Imagenes"); return; }
        onBusy(true);
        lastError = null;
        final Exporter.Encoded[] res = new Exporter.Encoded[1];
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    res[0] = Exporter.encodeFlattened(p, o[0], o[1], fmt, q, maxBytes);
                    java.io.OutputStream os = getContentResolver().openOutputStream(u);
                    if (os == null) throw new java.io.IOException("No se pudo abrir el archivo");
                    try { os.write(res[0].bytes); } finally { os.close(); }
                } catch (Throwable t) {
                    lastError = errText(t);
                    dropBroken(u);
                }
            }
        }, new Runnable() {
            @Override public void run() {
                onBusy(false);
                if (lastError != null || res[0] == null) {
                    toast("Error al guardar: " + lastError);
                    return;
                }
                Exporter.Encoded e = res[0];
                toast("Guardado en Imagenes > Paint Zeta: " + file + "  (" + e.w + " x " + e.h + ", " + kb(e.bytes.length)
                        + (fmt != Exporter.FMT_PNG && maxBytes > 0 && e.quality < q ? ", calidad " + e.quality : "") + ")");
                if (share) {
                    try {
                        android.content.Intent send = new android.content.Intent(android.content.Intent.ACTION_SEND);
                        send.setType(Exporter.FMT_MIME[fmt]);
                        send.putExtra(android.content.Intent.EXTRA_STREAM, u);
                        send.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(android.content.Intent.createChooser(send, "Compartir imagen"));
                    } catch (Throwable t) {
                        toast("No hay apps para compartir");
                    }
                }
            }
        });
    }

    private void exportAdvancedDialog() {
        final Project p = canvas.getProject();
        final int[][] sizes = {{p.w, p.h}, {Math.max(1, p.w / 2), Math.max(1, p.h / 2)},
                longSide(p, 1920), longSide(p, 1280)};
        final String[] items = {"Original  " + sizes[0][0] + "x" + sizes[0][1],
                "Mitad  " + sizes[1][0] + "x" + sizes[1][1],
                "Lado largo 1920  " + sizes[2][0] + "x" + sizes[2][1],
                "Lado largo 1280  " + sizes[3][0] + "x" + sizes[3][1]};
        new SheetBuilder(this)
                .setTitle("Exportar las capas visibles")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        outW = sizes[i][0];
                        outH = sizes[i][1];
                        edgeDialogExport();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void edgeDialogExport() {
        final String[] items = {"Limpiar borde y quitar el fondo pegado (recomendado)", "Solo limpiar borde",
                "No tocar el borde"};
        final int[] vals = {2, 1, 0};
        new SheetBuilder(this)
                .setTitle("Borde de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        edgeClean = vals[i];
                        formatDialog();
                    }
                })
                .show();
    }

    private void formatDialog() {
        final String[] items = {"Elegir capas y guardar en Imagenes > Paint Zeta (automatico)",
                "PNG sueltos en una carpeta que elijo", "Todo junto en un ZIP"};
        new SheetBuilder(this)
                .setTitle("Como guardar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 0) {
                            chooseLayersToSave();
                        } else if (i == 1) {
                            toast("Elige o crea la carpeta donde van los PNG");
                            pickFolder.launch(null);
                        } else {
                            createZip.launch("capas_anime.zip");
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Marca las capas que quieres; salen todas juntas como PNG transparente. */
    private void chooseLayersToSave() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int n = p.layers.size();
        final String[] names = new String[n];
        final boolean[] on = new boolean[n];
        for (int k = 0; k < n; k++) {
            Layer l = p.layers.get(n - 1 - k);
            names[k] = l.name;
            on[k] = l.visible;
        }
        new SheetBuilder(this)
                .setTitle("Capas a guardar")
                .setMultiChoiceItems(names, on, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i, boolean c) {
                        on[i] = c;
                    }
                })
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        ArrayList<Layer> pick = new ArrayList<Layer>();
                        for (int k = n - 1; k >= 0; k--) if (on[k]) pick.add(p.layers.get(n - 1 - k));
                        if (pick.isEmpty()) {
                            toast("No marcaste ninguna capa");
                            return;
                        }
                        doExportAuto(pick);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Guarda en Pictures/PaintZeta/<fecha>/ sin preguntar carpeta (Android 10 o mas). */
    private void doExportAuto(final List<Layer> layers) {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            toast("En este Android elige la carpeta una vez");
            pickFolder.launch(null);
            return;
        }
        final Project p = canvas.getProject();
        final String folder = "Pictures/Paint Zeta/" + new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US)
                .format(new java.util.Date());
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                Uri cur = null;
                try {
                    android.content.ContentResolver cr = getContentResolver();
                    int idx = 1;
                    for (Layer l : layers) {
                        String name = String.format(Locale.US, "%02d_%s.png", idx++, safeName(l.name));
                        android.content.ContentValues cv = new android.content.ContentValues();
                        cv.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, name);
                        cv.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png");
                        cv.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, folder);
                        Uri uri = cr.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        if (uri == null) throw new java.io.IOException("No se pudo crear " + name);
                        cur = uri;
                        Exporter.exportLayer(cr, p, l, uri, outW, outH, edgeClean);
                        cur = null;
                        lastExportCount++;
                    }
                } catch (Throwable t) {
                    lastError = errText(t);
                    dropBroken(cur);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al guardar: " + lastError
                        : lastExportCount + " PNG transparentes guardados en " + folder);
            }
        });
    }

    /** Cada capa visible sale como PNG suelto en la carpeta: 01_pelo.png, 02_brazo.png... */
    private void doExportFolder(final Uri tree) {
        final Project p = canvas.getProject();
        if (p == null) return;
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                Uri cur = null;
                try {
                    android.content.ContentResolver cr = getContentResolver();
                    Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,
                            android.provider.DocumentsContract.getTreeDocumentId(tree));
                    int idx = 1;
                    for (Layer l : new ArrayList<Layer>(p.layers)) {
                        if (!l.visible) continue;
                        String name = String.format(java.util.Locale.US, "%02d_%s", idx++, safeName(l.name));
                        Uri doc = android.provider.DocumentsContract.createDocument(cr, parent, "image/png", name);
                        if (doc == null) throw new java.io.IOException("No se pudo crear " + name);
                        cur = doc;
                        Exporter.exportLayer(cr, p, l, doc, outW, outH, edgeClean);
                        cur = null;
                        lastExportCount++;
                    }
                } catch (Throwable t) {
                    lastError = errText(t);
                    dropBroken(cur);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al exportar: " + lastError
                        : lastExportCount + " PNG de " + outW + "x" + outH + " guardados en la carpeta");
            }
        });
    }

    /** v8.73: si exportar fallo, no dejar un archivo vacio o roto en Descargas / Imagenes / la carpeta. */
    private void dropBroken(Uri uri) {
        if (uri == null) return;
        try {
            if ("media".equals(uri.getAuthority())) getContentResolver().delete(uri, null, null);
            else android.provider.DocumentsContract.deleteDocument(getContentResolver(), uri);
        } catch (Throwable ignored) { }
    }

    /** v8.73: un error entendible (antes podia salir "Error: null"). */
    private static String errText(Throwable t) {
        if (t instanceof OutOfMemoryError) return "falta memoria (prueba un tamano menor o cierra otras apps)";
        String m = t.getMessage();
        return m == null || m.trim().isEmpty() ? t.getClass().getSimpleName() : m;
    }

    private static String safeName(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(Character.isLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
        return sb.length() == 0 ? "capa" : sb.toString();
    }

    private void doExportZip(final Uri uri) {
        final Project p = canvas.getProject();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    lastExportCount = Exporter.exportZip(getContentResolver(), p, uri, outW, outH, edgeClean);
                } catch (Throwable t) {
                    lastError = errText(t);
                    dropBroken(uri);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al exportar: " + lastError
                        : lastExportCount + " PNG de " + outW + "x" + outH + " guardados en el ZIP" + whereSuffix());
            }
        });
    }

    private void doExportLayer(final Uri uri) {
        final Project p = canvas.getProject();
        final Layer l = pendingLayerExport;
        pendingLayerExport = null;
        if (l == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    Exporter.exportLayer(getContentResolver(), p, l, uri, edgeClean);
                } catch (Throwable t) {
                    lastError = errText(t);
                    dropBroken(uri);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error: " + lastError : "PNG guardado" + whereSuffix());
            }
        });
    }

    // ==================================================================
    // Interfaz
    // ==================================================================

    // ---- v8.39: barra de la marca de la IA (pintar varias veces y luego quitar) ----
    private LinearLayout aiMarkBar;

    private void syncAiMarkBar() {
        boolean show = canvas.isAiMarking();
        if (!show) {
            if (aiMarkBar != null) aiMarkBar.setVisibility(View.GONE);
            return;
        }
        if (aiMarkBar == null) {
            aiMarkBar = new LinearLayout(this);
            aiMarkBar.setOrientation(LinearLayout.HORIZONTAL);
            aiMarkBar.setBackgroundResource(R.drawable.bg_panel);
            aiMarkBar.setPadding(dp(4), dp(4), dp(4), dp(4));
            aiMarkBar.addView(chooserCell(R.drawable.ic_check, "Quitar fondo", 0xFF7FE0D4, new Runnable() {
                public void run() { aiFlow().runMarked(); }
            }));
            aiMarkBar.addView(chooserCell(R.drawable.ic_ai, "Toda la imagen", 0, new Runnable() {
                public void run() { aiFlow().runWhole(); }
            }));
            aiMarkBar.addView(chooserCell(R.drawable.ic_undo, "Borrar trazo", 0, new Runnable() {
                public void run() { if (!canvas.undoAiMarkStroke()) toast("No hay trazos"); }
            }));
            aiMarkBar.addView(chooserCell(R.drawable.ic_close, "Cancelar", 0, new Runnable() {
                public void run() { canvas.cancelAiMark(); updateUi(); }
            }));
            android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                    Math.min(dp(380), getResources().getDisplayMetrics().widthPixels - dp(16)),
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            lp.topMargin = dp(64);
            ((android.widget.FrameLayout) findViewById(R.id.canvas).getParent()).addView(aiMarkBar, lp);
        }
        aiMarkBar.setVisibility(View.VISIBLE);
        aiMarkBar.bringToFront();
    }

    void updateUi() {
        syncAiMarkBar();
        Project p = canvas.getProject();
        ((TextView) findViewById(R.id.layerCount)).setText(String.valueOf(p == null ? 0 : p.layers.size()));
        ((TextView) findViewById(R.id.btnSize)).setText(String.format(Locale.US,
                canvas.getBrushSize() < 10 ? "%.1f" : "%.0f", canvas.getBrushSize()));
        android.graphics.drawable.GradientDrawable sw = new android.graphics.drawable.GradientDrawable();
        sw.setCornerRadius(dp(4));
        sw.setColor(canvas.getColor());
        sw.setStroke(dp(2), 0xFFFFFFFF);
        findViewById(R.id.btnColor).setBackground(sw);
        ((ImageButton) findViewById(R.id.btnTools)).setImageResource(
                canvas.getMode() == CanvasView.MODE_BRUSH && canvas.isSubtract() ? R.drawable.ic_remove
                        : toolIcon(canvas.getMode()));

        if (layersOpen()) {
            // v8.95: con las capas abiertas vuelve la barra de siempre (el panel de Marcar/Recortar se arma al cerrar)
            if (editPanel != null) editPanel.setVisibility(View.GONE);
            if (epKind != 0) {
                findViewById(R.id.bottomPanel).setVisibility(View.VISIBLE);
                showTypeBar(false);
                epKind = 0;
            }
            hideForLayers(true);
            buildLayersPanel();
            return;
        }
        int m = canvas.getMode();
        syncEffectControls(m);
        // Lazo ofrece copiar directamente: ocultar los ajustes de máscara azul.
        findViewById(R.id.selBar).setVisibility(View.GONE);
        findViewById(R.id.btnSelMenu).setVisibility(
                p != null && p.hasSelection() ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnAddMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg : R.drawable.bg_seg_on);
        findViewById(R.id.btnSubMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_seg);
        toggle(R.id.btnSmart, canvas.isSmart());
        toggle(R.id.btnLineart, canvas.isUseBarrier() && p != null && p.barrier != null);
        if (wandGear != null) wandGear.setVisibility(m == CanvasView.MODE_WAND ? View.VISIBLE : View.GONE);
        refreshShapesButton();
        fitTopBar();
        buildOptBar(m);
        syncEditPanel(m);         // v8.94: editor de texto / Recortar en pestanas
    }

    /** Texto corto de la Suavidad de Borrar fondo (0 = nitido). */
    /** En Borrar fondo la segunda barra es la Suavidad (salvo con el Borrador manual: Fuerza). */
    private boolean bgFeatherSlider() {
        return canvas.getMode() == CanvasView.MODE_BGERASE && canvas.getBgSub() != CanvasView.BG_SUB_ERASER;
    }

    private static String featherLabel(int v) {
        float px = v / 25f;
        return "\u25D0 " + (px < 0.05f ? "0" : String.format(Locale.US, px == Math.round(px) ? "%.0f" : "%.1f", px));
    }

    /** Especial trabaja con Fortaleza, no con la opacidad del pincel. */
    private void syncEffectControls(int mode) {
        final boolean special = mode == CanvasView.MODE_LIQUIFY;
        TextView sizeLabel = findViewById(R.id.sliderLabel);
        LinearLayout.LayoutParams sizeLp = (LinearLayout.LayoutParams) sizeLabel.getLayoutParams();
        int sizeWidth = dp(special ? 58 : 46);
        if (sizeLp.width != sizeWidth) { sizeLp.width = sizeWidth; sizeLabel.setLayoutParams(sizeLp); }
        sizeLabel.setTextSize(special ? 10f : 13f);
        sizeLabel.setGravity(special ? Gravity.CENTER : Gravity.RIGHT);
        TextView label = findViewById(R.id.opacityLabel);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) label.getLayoutParams();
        int width = dp(special ? 80 : 46);
        if (lp.width != width) { lp.width = width; label.setLayoutParams(lp); }
        SeekBar strength = findViewById(R.id.opacity);
        final boolean bgEr = mode == CanvasView.MODE_BGERASE && canvas.getBgSub() == CanvasView.BG_SUB_ERASER;
        final boolean feather = mode == CanvasView.MODE_BGERASE && !bgEr;
        int controlKey = mode == CanvasView.MODE_BGERASE ? 1000 + canvas.getBgSub() : mode;
        if (controlKey != previousControlMode) {
            previousControlMode = controlKey;
            strength.setProgress(bgEr ? Math.round(canvas.getBgEraserStrength() * 100f)
                    : feather ? Math.round(canvas.getBgFeather() * 25f) : Math.round(100f * (special
                    ? canvas.getEffectStrength() : canvas.getBrushOpacity())));
        }
        int pct = strength.getProgress();
        label.setText(bgEr ? "Fuerza " + Math.max(2, pct) + "%" : feather ? featherLabel(pct)
                : special ? "Fuerza " + Math.max(5, pct) + "%" : String.valueOf(Math.max(2, pct)));
        findViewById(R.id.opacityRow).setContentDescription(bgEr ? "Fuerza del borrador" : feather ? "Suavidad del borde (0 a 4 px)"
                : special ? "Fortaleza de Especial" : "Opacidad del pincel");
    }

    // ==================================================================
    // Avisos del lienzo
    // ==================================================================

    @Override
    public void onBusy(boolean busy) {
        int[] ids = {R.id.btnExport, R.id.btnTools, R.id.btnUndo, R.id.btnRedo,
                R.id.btnLayers, R.id.btnMenu, R.id.btnSelMenu};
        for (int id : ids) {
            View v = findViewById(id);
            if (v != null) v.setEnabled(!busy);
        }
    }

    /** v8.76: la primera vez que se usa un lapiz, la palma y el dedo dejan de pintar. */
    @Override
    public void onStylusDetected() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getInt("solo_lapiz", -1) != -1) return;          // ya lo decidiste antes
        sp.edit().putInt("solo_lapiz", 1).apply();
        canvas.setStylusOnly(true);
        canvas.showHud("Lapiz detectado: ahora solo el lapiz pinta y la palma no marca. "
                + "El dedo mueve y hace zoom (se cambia en Mas opciones > Vista)", 4200);
    }

    /** v8.76: Android pide memoria: se suelta lo que se vuelve a armar solo. */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (destroyed || canvas == null) return;
        boolean hard = level == TRIM_MEMORY_RUNNING_CRITICAL || level >= TRIM_MEMORY_MODERATE;
        if (level >= TRIM_MEMORY_UI_HIDDEN || level == TRIM_MEMORY_RUNNING_LOW || hard) {
            try { canvas.trimMemory(hard); } catch (Throwable ignored) { }
        }
    }

    @Override
    public void onChanged() {
        markDirty();
        // v8.53: la barra y el panel se rehacen un momento despues (no en cada trazo mientras pintas)
        saveHandler.removeCallbacks(uiSoon);
        saveHandler.postDelayed(uiSoon, canvas != null && canvas.isTouching() ? 400 : 120);
    }

    private final Runnable uiSoon = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            if (canvas != null && canvas.isTouching()) { saveHandler.postDelayed(this, 300); return; }
            updateUi();
        }
    };

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    @Override
    public void onToolStateChanged() {
        if (compareChip != null && !canvas.isComparing()) hideCompareChip();
        if (aiMarkBar != null && aiMarkBar.getVisibility() == View.VISIBLE && !canvas.isAiMarking()) syncAiMarkBar();
        int m = canvas.getMode();
        if (m == CanvasView.MODE_PUPPET || m == CanvasView.MODE_TRANSFORM || m == CanvasView.MODE_BUCKET
                || canvas.isMangaMode()) updateUi();
    }

    @Override
    public void onColorPicked(int color) {
        updateUi();
        canvas.showHud(String.format(Locale.US, "Color #%06X", color & 0xFFFFFF));
    }

    @Override
    public void onUndoGesture() {
        queueUndo(1);
    }

    @Override
    public void onRedoGesture() {
        queueUndo(-1);
    }

    /**
     * v8.55: Deshacer (+1) / Rehacer (-1). Si se toca muchas veces seguidas, los toques se suman y
     * se hacen juntos con una sola actualizacion de pantalla y de botones: ya no se traba.
     */
    private int pendingUndo;
    private final Runnable undoRun = new Runnable() {
        @Override public void run() {
            int n = pendingUndo;
            pendingUndo = 0;
            if (n == 0 || canvas == null || canvas.getProject() == null) return;
            if (canvas.isBusy()) { pendingUndo += n; saveHandler.postDelayed(this, 120); return; }
            canvas.doUndoSteps(n);
            saveHandler.removeCallbacks(uiSoon);
            saveHandler.postDelayed(uiSoon, 60);
        }
    };

    private void queueUndo(int d) {
        // v8.60: con el Acabado abierto, Deshacer quita el ultimo retoque (la capa no se toca)
        if (finOpen()) {
            if (d > 0 && finSession != null && finSession.undo()) { finRender(); canvas.showHud("Retoque deshecho", 900); }
            else canvas.showHud("Para quitar el acabado toca ✕ (o ✓ para dejarlo)", 1600);
            return;
        }
        pendingUndo += d;
        saveHandler.removeCallbacks(undoRun);
        saveHandler.postDelayed(undoRun, 40);
    }


    // ==================================================================
    // Dialogos
    // ==================================================================

    /** Ajustes de la varita, al estilo de los de Ibis. */
    /** Panel chico de la varita, como en ibis: se aplica al momento. */
    private void wandDialog() {
        if (!needProject()) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(4));
        // v9.04: sin fondo propio: se ve el fondo un poco transparente de la ventana

        final TextView tExp = smallText("Dilatacion " + String.format(Locale.US, "%.1f", canvas.getExpansion()));
        final SeekBar sExp = new SeekBar(this);
        sExp.setMax(80); // -3.0 .. +5.0
        sExp.setProgress(Math.round((canvas.getExpansion() + 3f) * 10f));
        sExp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                float e = v / 10f - 3f;
                tExp.setText("Dilatacion " + String.format(Locale.US, "%.1f", e));
                canvas.setExpansion(e);
            }
        });
        root.addView(tExp);
        root.addView(sExp);

        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        root.addView(smallSwitch("Hasta la linea", canvas.isToLine(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setToLine(on);
                sp.edit().putBoolean("to_line", on).apply();
            }
        }));
        root.addView(smallSwitch("Reconocimiento de huecos", canvas.isAutoLines(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setAutoLines(on);
                sp.edit().putBoolean("auto_lines", on).apply();
            }
        }));
        root.addView(smallSwitch("Zonas sin pintar", canvas.isFillUnpainted(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setFillUnpainted(on);
                sp.edit().putBoolean("fill_unpainted", on).apply();
            }
        }));
        root.addView(smallSwitch("Llenado continuo", !canvas.isWandGlobal(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setWandGlobal(!on);
            }
        }));

        final AlertDialog dlg = new SheetBuilder(this).setView(root)
                .setPositiveButton("Listo", null)
                .setNeutralButton("Restablecer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(28);
                        canvas.setSoftness(24);
                        canvas.setExpansion(1.5f);
                        canvas.setAutoLines(true);
                        canvas.setWandGlobal(false);
                        canvas.setToLine(true);
                        canvas.setFillUnpainted(false);
                        canvas.setColorMode(ColorDist.RGB);
                        sp.edit().putBoolean("auto_lines", true).putBoolean("to_line", true)
                                .putBoolean("fill_unpainted", false).apply();
                        syncSlider();
                        toast("Restablecido");
                    }
                })
                .create();
        dlg.show();
        // cuadro chico, no toda la pantalla
        if (dlg.getWindow() != null) {
            dlg.getWindow().setLayout(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private interface SwitchDo {
        void set(boolean on);
    }

    private TextView smallText(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFFE0E0E0);
        v.setTextSize(13f);
        v.setPadding(0, dp(4), 0, 0);
        return v;
    }

    private android.widget.Switch smallSwitch(String text, boolean on, final SwitchDo d) {
        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setText(text);
        sw.setTextSize(13f);
        sw.setTextColor(0xFFE0E0E0);
        sw.setChecked(on);
        sw.setPadding(0, dp(2), 0, dp(2));
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean c) {
                d.set(c);
            }
        });
        return sw;
    }

    private String expLabel(float v) {
        return String.format(Locale.US, "Expansion del borde: %.1f px", v);
    }

    /** Gama de colores, con vista previa mientras mueves el margen. */
    private void colorRangeDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView info = new TextView(this);
        info.setText("Se usa el color cargado. Mueve el margen y mira el lienzo: la seleccion se actualiza sola.");
        root.addView(info);

        final View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        lp.topMargin = dp(8);
        sw.setLayoutParams(lp);
        sw.setBackgroundColor(canvas.getColor());
        root.addView(sw);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Margen: " + canvas.getTolerance());
        root.addView(tTol);
        root.addView(sTol);

        final CheckBox replace = new CheckBox(this);
        replace.setText("Reemplazar la seleccion actual");
        replace.setChecked(true);
        root.addView(replace);

        canvas.beginPreview();
        final Runnable[] pending = new Runnable[1];
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, final int v, boolean u) {
                tTol.setText("Margen: " + v);
                if (pending[0] != null) previewHandler.removeCallbacks(pending[0]);
                pending[0] = new Runnable() {
                    @Override
                    public void run() {
                        canvas.previewColorRange(canvas.getColor(), v, replace.isChecked());
                    }
                };
                previewHandler.postDelayed(pending[0], 180);
            }
        });
        canvas.previewColorRange(canvas.getColor(), sTol.getProgress(), replace.isChecked());

        new SheetBuilder(this)
                .setTitle("Gama de colores")
                .setView(scroll)
                .setCancelable(false)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.endPreview(true);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.endPreview(false);
                    }
                })
                .show();
    }

    private void refineDialog() {
        if (!needProject()) return;
        final String[] items = {"Suave (pelo fino)", "Medio", "Fuerte"};
        final int[] rad = {6, 12, 20};
        final float[] eps = {0.0004f, 0.0016f, 0.006f};
        new SheetBuilder(this)
                .setTitle("Refinar borde")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.refineEdge(rad[i], eps[i]);
                    }
                })
                .show();
    }

    private void unpaintedDialog() {
        if (!needProject()) return;
        final String[] items = {"Solo huecos chicos", "Huecos medianos", "Huecos grandes", "Todos los huecos"};
        final int[] vals = {2, 8, 30, 0};
        new SheetBuilder(this)
                .setTitle("Rellenar zonas sin pintar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(5, vals[i]);
                    }
                })
                .show();
    }

    /** Saca la linea del manga a su capa y deja una capa de color debajo. */
    private void filtersDialog() {
        if (!needProject()) return;
        // v8.57: una sola pantalla de filtros con vista previa (incluye los de limpieza de antes)
        FxScreen.open(this, canvas, -1);
    }

    private void posterizeDialog() {
        final String[] items = {"4 tonos", "6 tonos", "10 tonos", "16 tonos"};
        final int[] vals = {4, 6, 10, 16};
        new SheetBuilder(this)
                .setTitle("Aplanar tonos")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.applyFilter(1, vals[i], 0, 0);
                    }
                })
                .show();
    }

    /** Extraer line art con sus tres controles, como el filtro de Ibis. */
    private void lineArtFilterDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tw = new TextView(this);
        final SeekBar sw = new SeekBar(this);
        sw.setMax(255);
        sw.setProgress(210);
        tw.setText("Blanco: 210");
        sw.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tw.setText("Blanco: " + v);
            }
        });
        root.addView(tw);
        root.addView(sw);

        final TextView tb = new TextView(this);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(255);
        sb.setProgress(40);
        tb.setText("Negro: 40");
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tb.setText("Negro: " + v);
            }
        });
        root.addView(tb);
        root.addView(sb);

        final TextView tm = new TextView(this);
        final SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(50);
        tm.setText("Medio: 50");
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tm.setText("Medio: " + Math.max(1, v));
            }
        });
        root.addView(tm);
        root.addView(sm);

        new SheetBuilder(this)
                .setTitle("Extraer line art")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.applyFilter(3, sw.getProgress(), sb.getProgress(),
                                Math.max(1, sm.getProgress()));
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** v8.78: el estabilizador ahora tiene su panel (antes 4 opciones fijas). */
    private void stabilizerDialog() {
        showStabPanel();
    }

    // ==================================================================
    // v8.79 FIGURAS: boton propio arriba (verde = herramienta de figuras activa), lista de
    // figuras y un panel con contorno, relleno y lo propio de cada figura.
    // ==================================================================

    private PopupWindow shapePop, shapeStylePop;
    private static final int SH_FREE = -1, SH_CURVE = -2, SH_POLY = -3;
    private static final int[] SH_KIND = {SH_FREE, ShapeGeom.LINE, ShapeGeom.RECT, ShapeGeom.CIRCLE,
            ShapeGeom.ELLIPSE, ShapeGeom.POLYGON, ShapeGeom.RRECT, ShapeGeom.ARROW, ShapeGeom.BUBBLE, SH_CURVE, SH_POLY};
    private static final String[] SH_NAME = {"Libre", "Linea", "Rectangulo", "Circulo", "Elipse", "Poligono",
            "Redondeado", "Flecha", "Bocadillo", "Curva", "Polilinea"};
    private static final int[] SH_ICON = {R.drawable.ic_paint, R.drawable.ic_sh_line, R.drawable.ic_sh_rect,
            R.drawable.ic_sh_circle, R.drawable.ic_sh_ellipse, R.drawable.ic_sh_polygon, R.drawable.ic_sh_rrect,
            R.drawable.ic_sh_arrow, R.drawable.ic_sh_bubble, R.drawable.ic_curve, R.drawable.ic_poly};

    private static boolean isShapeMode(int m) {
        return m == CanvasView.MODE_SHAPE || m == CanvasView.MODE_CURVE || m == CanvasView.MODE_POLY;
    }

    private static int shapeIcon(int type) {
        for (int i = 0; i < SH_KIND.length; i++) if (SH_KIND[i] == type) return SH_ICON[i];
        return R.drawable.ic_shapes;
    }

    private void loadShapePrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        ShapeGeom.Style st = canvas.getShapeStyle();
        st.strokeOn = sp.getBoolean("sh_s_on", true);
        st.strokeCurrent = sp.getBoolean("sh_s_cur", true);
        st.strokeColor = sp.getInt("sh_s_col", 0xFF000000);
        st.strokeOp = sp.getInt("sh_s_op", 100) / 100f;
        st.strokeBrush = sp.getBoolean("sh_s_brush", false);
        st.fillOn = sp.getBoolean("sh_f_on", false);
        st.fillCurrent = sp.getBoolean("sh_f_cur", false);
        st.fillColor = sp.getInt("sh_f_col", 0xFFFFFFFF);
        st.fillOp = sp.getInt("sh_f_op", 100) / 100f;
        st.smooth = sp.getBoolean("sh_smooth", true);
        st.square = sp.getBoolean("sh_square", false);
        st.sides = Math.max(3, Math.min(32, sp.getInt("sh_sides", 6)));
        st.corner = Math.max(0, Math.min(100, sp.getInt("sh_corner", 30)));
        st.thin = sp.getBoolean("sh_thin", false);
        st.heads = Math.max(1, Math.min(3, sp.getInt("sh_heads", 1)));
        st.arrowW = Math.max(2, Math.min(400, sp.getInt("sh_arrow_w", 24)));
        canvas.setShapeType(sp.getInt("sh_type", ShapeGeom.RECT));
    }

    private void saveShapePrefs() {
        ShapeGeom.Style st = canvas.getShapeStyle();
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putInt("sh_type", canvas.getShapeType())
                .putBoolean("sh_s_on", st.strokeOn).putBoolean("sh_s_cur", st.strokeCurrent)
                .putInt("sh_s_col", st.strokeColor).putInt("sh_s_op", Math.round(st.strokeOp * 100f))
                .putBoolean("sh_s_brush", st.strokeBrush)
                .putBoolean("sh_f_on", st.fillOn).putBoolean("sh_f_cur", st.fillCurrent)
                .putInt("sh_f_col", st.fillColor).putInt("sh_f_op", Math.round(st.fillOp * 100f))
                .putBoolean("sh_smooth", st.smooth).putBoolean("sh_square", st.square)
                .putInt("sh_sides", st.sides).putInt("sh_corner", Math.round(st.corner))
                .putBoolean("sh_thin", st.thin).putInt("sh_heads", st.heads)
                .putInt("sh_arrow_w", Math.round(st.arrowW)).apply();
    }

    /** El icono de Figuras se pone verde mientras se usa Figuras, Curva o Polilinea. */
    private void refreshShapesButton() {
        View v = findViewById(R.id.btnShapes);
        if (!(v instanceof ImageButton)) return;
        ((ImageButton) v).setColorFilter(isShapeMode(canvas.getMode()) ? 0xFF2EE6A6 : 0xFFFFFFFF,
                android.graphics.PorterDuff.Mode.SRC_IN);
    }

    /** Tarjeta oscura redondeada (misma de los otros paneles). */
    private LinearLayout darkCard() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(10));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xF0222228);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        return box;
    }

    /** v8.83: fondo algo transparente para ver la figura detras del panel. */
    private static void seeThrough(LinearLayout box, float radius) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xA6202026);
        bg.setCornerRadius(radius);
        box.setBackground(bg);
    }

    /** Muestra un panel cerca de 'anchor' sin salirse de la pantalla. */
    private PopupWindow showCardPop(View content, LinearLayout box, View anchor, int w, float maxFrac) {
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * maxFrac);
        box.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int h = Math.min(maxH, box.getMeasuredHeight());
        // v8.92: con un boton de la parte de abajo, el panel sale ARRIBA del boton: asi no tapa
        // las barras de tamano y color que estan debajo
        int[] loc = null;
        boolean below = false;
        if (anchor != null && anchor.getWindowToken() != null) {
            loc = new int[2];
            anchor.getLocationInWindow(loc);
            int screenH = getWindow().getDecorView().getHeight();
            int roomUp = loc[1] - dp(12), roomDown = screenH - loc[1] - anchor.getHeight() - dp(12);
            below = loc[1] < screenH / 2 || (roomUp < Math.min(h, dp(200)) && roomDown > roomUp);
            h = Math.max(dp(120), Math.min(h, below ? roomDown : roomUp));
        }
        PopupWindow pop = new PopupWindow(content, w, h, true);
        pop.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
        pop.setOutsideTouchable(true);
        try {
            if (loc == null) throw new IllegalStateException();
            int screenW = getResources().getDisplayMetrics().widthPixels;
            int x = Math.max(dp(8), Math.min(screenW - w - dp(8), loc[0] + anchor.getWidth() / 2 - w / 2));
            int y = below ? loc[1] + anchor.getHeight() + dp(4) : Math.max(dp(8), loc[1] - h - dp(4));
            pop.showAtLocation(getWindow().getDecorView(), Gravity.TOP | Gravity.START, x, y);
        } catch (Throwable t) {
            // v8.96: sin boton de referencia, el panel sale abajo (encima de las barras), no en el medio
            View bp = findViewById(R.id.bottomPanel);
            int y = bp != null && bp.getVisibility() == View.VISIBLE ? bp.getHeight() + dp(6) : dp(12);
            pop.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, y);
        }
        return pop;
    }

    // ==================================================================
    // v8.89 Recortar: proporcion, resolucion, girar, voltear, tamano y ampliar lienzo
    // ==================================================================

    private void cropShapePanel(View anchor) {
        if (shapeStylePop != null && shapeStylePop.isShowing()) { shapeStylePop.dismiss(); return; }
        LinearLayout box = darkCard();
        TextView title = stabLabel("Forma del recorte");
        title.setTextColor(0xFF2EE6A6);
        title.setTextSize(14f);
        box.addView(title);
        final int[] v = {canvas.getCropShape()};
        iconPickRow(box, CS_ICON, CanvasView.CROP_SHAPES, v, new Runnable() {
            @Override public void run() {
                canvas.setCropShape(v[0]);
                canvas.showHud(CanvasView.CROP_SHAPES[v[0]] + (v[0] == 0 ? "" : ": lo de afuera queda transparente"), 1600);
                if (shapeStylePop != null) shapeStylePop.dismiss();
                updateUi();
            }
        });
        hintTo(box, "Para un circulo o estrella pareja usa la proporcion 1:1. Guarda en PNG para que se vea transparente.");
        int w = Math.min(dp(320), getResources().getDisplayMetrics().widthPixels - dp(16));
        shapeStylePop = showCardPop(box, box, anchor, w, 0.5f);
    }

    private static final String[] CP_RATIO_NAMES = {"Libre", "Cuadrado 1:1", "4:5 (Instagram)", "3:4", "2:3", "9:16 (historias)",
            "5:4", "4:3", "3:2", "16:9 (video)", "Personalizado..."};
    private static final float[] CP_RATIOS = {0f, 1f, 4f / 5f, 3f / 4f, 2f / 3f, 9f / 16f, 5f / 4f, 4f / 3f, 3f / 2f, 16f / 9f, -1f};
    private static final int[][] CP_RES = {{0, 0}, {1080, 1080}, {1080, 1350}, {1080, 1920}, {1920, 1080},
            {800, 600}, {600, 800}, {1200, 1600}, {1600, 1200}, {-1, -1}};

    private void buildCropBar(LinearLayout bar) {
        final ImageButton[] ratio = new ImageButton[1];
        ratio[0] = iconButton(R.drawable.ic_crop_ratio, "Proporcion del cuadro (libre, 1:1, 4:5, 9:16...)", new Runnable() {
            public void run() { cropRatioDialog(); }
        });
        if (canvas.getCropRatio() > 0f) ratio[0].setBackgroundResource(R.drawable.bg_tool_on);
        bar.addView(ratio[0]);
        ImageButton res = iconButton(R.drawable.ic_crop_res, "Resolucion final (1080x1080, 1080x1920...)", new Runnable() {
            public void run() { cropResDialog(); }
        });
        if (canvas.getCropOutW() > 0) res.setBackgroundResource(R.drawable.bg_tool_on);
        bar.addView(res);
        // v8.93: forma del recorte (circulo, corazon, estrella...): lo de afuera queda transparente
        final ImageButton[] shp = new ImageButton[1];
        shp[0] = iconButton(R.drawable.ic_crop_shape, "Forma del recorte (circulo, corazon, estrella...)", new Runnable() {
            public void run() { cropShapePanel(shp[0]); }
        });
        if (canvas.getCropShape() != CanvasView.CS_RECT) shp[0].setBackgroundResource(R.drawable.bg_tool_on);
        bar.addView(shp[0]);
        bar.addView(iconButton(R.drawable.ic_rotate, "Girar 90 grados (todas las capas)", new Runnable() {
            public void run() { canvas.transform(0); }
        }));
        // v8.92: voltear directo (sin preguntar). Girar ya es el boton de al lado
        bar.addView(iconButton(R.drawable.ic_flip_h, "Voltear: izquierda <-> derecha", new Runnable() {
            public void run() { canvas.transform(2); }
        }));
        bar.addView(iconButton(R.drawable.ic_flip_v, "Voltear: arriba <-> abajo", new Runnable() {
            public void run() { canvas.transform(3); }
        }));
        bar.addView(iconButton(R.drawable.ic_resize, "Tamano: cambiar el tamano de toda la imagen", new Runnable() {
            public void run() { resizeDialog(); }
        }));
        bar.addView(iconButton(R.drawable.ic_undo, "Cuadro de nuevo (toda la imagen)", new Runnable() {
            public void run() { canvas.resetCropBox(); }
        }));
        ImageButton ok = iconButton(R.drawable.ic_check, "Recortar", new Runnable() {
            public void run() { canvas.applyCrop(); }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        bar.addView(ok);
    }

    private void cropRatioDialog() {
        if (!needProject()) return;
        float cur = canvas.getCropRatio();
        int sel = 0;
        for (int i = 0; i < CP_RATIOS.length; i++) if (Math.abs(CP_RATIOS[i] - cur) < 0.001f) sel = i;
        new SheetBuilder(this)
                .setTitle("Proporcion")
                .setSingleChoiceItems(CP_RATIO_NAMES, sel, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        d.dismiss();
                        if (CP_RATIOS[i] < 0f) {
                            twoNumbersDialog("Proporcion personalizada", "Ancho", "Alto", 3, 2, new TwoNumbers() {
                                public void got(int a, int b) {
                                    canvas.setCropOutput(0, 0);
                                    canvas.setCropRatio(a / (float) b);
                                    updateUi();
                                }
                            });
                            return;
                        }
                        canvas.setCropOutput(0, 0);
                        canvas.setCropRatio(CP_RATIOS[i]);
                        updateUi();
                    }
                })
                .show();
    }

    private void cropResDialog() {
        if (!needProject()) return;
        String[] names = new String[CP_RES.length];
        int sel = 0;
        for (int i = 0; i < CP_RES.length; i++) {
            names[i] = CP_RES[i][0] == 0 ? "Libre (la del cuadro)" : CP_RES[i][0] < 0 ? "Personalizado..."
                    : CP_RES[i][0] + " x " + CP_RES[i][1];
            if (CP_RES[i][0] == canvas.getCropOutW() && CP_RES[i][1] == canvas.getCropOutH()) sel = i;
        }
        new SheetBuilder(this)
                .setTitle("Resolucion final")
                .setSingleChoiceItems(names, sel, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        d.dismiss();
                        if (CP_RES[i][0] < 0) {
                            twoNumbersDialog("Resolucion personalizada", "Ancho (px)", "Alto (px)", 1080, 1080, new TwoNumbers() {
                                public void got(int a, int b) {
                                    canvas.setCropOutput(a, b);
                                    updateUi();
                                }
                            });
                            return;
                        }
                        if (CP_RES[i][0] == 0) canvas.setCropOutput(0, 0);
                        else canvas.setCropOutput(CP_RES[i][0], CP_RES[i][1]);
                        if (CP_RES[i][0] > 0)
                            canvas.showHud("El cuadro queda en " + CP_RES[i][0] + ":" + CP_RES[i][1]
                                    + ". Al recortar sale de " + CP_RES[i][0] + " x " + CP_RES[i][1], 2400);
                        updateUi();
                    }
                })
                .show();
    }

    private interface TwoNumbers {
        void got(int a, int b);
    }

    private void twoNumbersDialog(String title, String la, String lb, int da, int db, final TwoNumbers done) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setPadding(dp(18), dp(8), dp(18), 0);
        final android.widget.EditText ea = numberField(la, da), eb = numberField(lb, db);
        TextView x = new TextView(this);
        x.setText("  x  ");
        box.addView(ea, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(x);
        box.addView(eb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        new SheetBuilder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("Listo", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        int a = parseInt(ea), b = parseInt(eb);
                        if (a < 1 || b < 1 || a > 12000 || b > 12000) {
                            canvas.showHud("Numeros de 1 a 12000", 1800);
                            return;
                        }
                        done.got(a, b);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private android.widget.EditText numberField(String hint, int value) {
        android.widget.EditText e = new android.widget.EditText(this);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setHint(hint);
        e.setText(String.valueOf(value));
        e.setSelectAllOnFocus(true);
        return e;
    }

    private static int parseInt(android.widget.EditText e) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Throwable t) { return -1; }
    }

    /** Tamano de toda la imagen: por porcentaje o por ancho x alto (con candado). */
    private void resizeDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        final int ow = p.w, oh = p.h;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), 0);
        TextView now = new TextView(this);
        now.setText("Ahora: " + ow + " x " + oh);
        box.addView(now);
        LinearLayout pr = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        final int[] pcts = {25, 50, 75, 150, 200};
        box.addView(pr);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final android.widget.EditText ew = numberField("Ancho", ow), eh = numberField("Alto", oh);
        TextView x = new TextView(this);
        x.setText("  x  ");
        row.addView(ew, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(x);
        row.addView(eh, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(row);
        final android.widget.CheckBox lock = new android.widget.CheckBox(this);
        lock.setText("Mantener la forma (sin estirar)");
        lock.setChecked(true);
        box.addView(lock);
        final boolean[] busyEdit = {false};
        for (final int pc : pcts) {
            TextView b = new TextView(this);
            b.setText(pc + "%");
            b.setPadding(dp(8), dp(8), dp(8), dp(8));
            b.setTextColor(0xFF4DA3FF);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    busyEdit[0] = true;
                    ew.setText(String.valueOf(Math.max(1, Math.round(ow * pc / 100f))));
                    eh.setText(String.valueOf(Math.max(1, Math.round(oh * pc / 100f))));
                    busyEdit[0] = false;
                }
            });
            pr.addView(b);
        }
        ew.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(android.text.Editable s) {
                if (busyEdit[0] || !lock.isChecked() || !ew.hasFocus()) return;
                int w = parseInt(ew);
                if (w < 1) return;
                busyEdit[0] = true;
                eh.setText(String.valueOf(Math.max(1, Math.round(w * (float) oh / ow))));
                busyEdit[0] = false;
            }
        });
        eh.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(android.text.Editable s) {
                if (busyEdit[0] || !lock.isChecked() || !eh.hasFocus()) return;
                int h = parseInt(eh);
                if (h < 1) return;
                busyEdit[0] = true;
                ew.setText(String.valueOf(Math.max(1, Math.round(h * (float) ow / oh))));
                busyEdit[0] = false;
            }
        });
        TextView note = new TextView(this);
        note.setText("Cambia todas las capas. Deshacer lo devuelve.");
        note.setTextSize(12f);
        box.addView(note);
        new SheetBuilder(this)
                .setTitle("Tamano de la imagen")
                .setView(box)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        int w = parseInt(ew), h = parseInt(eh);
                        if (w < 1 || h < 1) { canvas.showHud("Escribe el ancho y el alto", 1600); return; }
                        canvas.resizeCanvasTo(w, h);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ==================================================================
    // v8.88 Marcar: Texto, Destacar, Tapar, Lupa y Numeros
    // ==================================================================

    private static final int[] MK_ICON = {R.drawable.ic_mk_text, R.drawable.ic_mk_spot, R.drawable.ic_mk_hide,
            R.drawable.ic_mk_loupe, R.drawable.ic_mk_num, R.drawable.ic_mk_arrow, R.drawable.ic_sticker};
    /** v8.99: nombre corto debajo de cada icono de la barra de Marcar (cabe en celulares chicos). */
    private static final String[] MK_SHORT = {"Texto", "Foco", "Tapar", "Lupa", "1 2 3", "Flechas", "Sticker"};
    private static final int[] AR_ICON = {R.drawable.ic_sh_arrow, R.drawable.ic_ar_double, R.drawable.ic_ar_free,
            R.drawable.ic_pencil, R.drawable.ic_sh_line, R.drawable.ic_sh_rect, R.drawable.ic_sh_circle, R.drawable.ic_ar_wedge};
    /** v8.94: orden en pantalla (como iMarkup): lapiz, se ensancha, flecha, doble, linea, cuadro, circulo, a mano. */
    private static final int[] AR_ORDER = {CanvasView.AR_PEN, CanvasView.AR_WEDGE, CanvasView.AR_ARROW, CanvasView.AR_DOUBLE,
            CanvasView.AR_LINE, CanvasView.AR_RECT, CanvasView.AR_OVAL, CanvasView.AR_FREE};
    private static final int[] SPOT_ORDER = {0, 1, 3, 4, 5, 6, 2};
    private static final int[] SPOT_ICON = {R.drawable.ic_sh_circle, R.drawable.ic_sh_rect, R.drawable.ic_sh_rrect,
            R.drawable.ic_sh_tri, R.drawable.ic_sh_heart, R.drawable.ic_sh_star, R.drawable.ic_lasso};
    private static final int[] HIDE_ORDER = {0, 2, 4, 5, 6, 7, 3, 1};
    private static final int[] HIDE_ICON = {R.drawable.ic_sh_rect, R.drawable.ic_sh_circle, R.drawable.ic_sh_rrect,
            R.drawable.ic_sh_tri, R.drawable.ic_sh_heart, R.drawable.ic_sh_star, R.drawable.ic_lasso, R.drawable.ic_brush};
    private static final int[] CS_ICON = {R.drawable.ic_sh_rect, R.drawable.ic_sh_circle, R.drawable.ic_sh_rrect,
            R.drawable.ic_sh_tri, R.drawable.ic_sh_heart, R.drawable.ic_sh_star};
    /** Colores rapidos para contorno y fondo del texto (0 = no, 1 = automatico / el color del texto). */
    private static final int[] TX_COLORS = {0, 1, 0xFF000000, 0xFFFFFFFF, 0xFFE53935, 0xFFFFD600, 0xFF1E88E5, 0xFF43A047};
    private static final String[] MK_HELP = {
            "toca donde va el texto y escribe con el teclado. Tocalo otra vez para cambiarlo",
            "arrastra sobre lo importante: lo demas se oscurece",
            "arrastra sobre lo que quieres tapar",
            "arrastra o toca lo que quieres agrandar",
            "toca para poner 1, 2, 3... Tocalo para moverlo. Esquina: tamano",
            "arrastra para poner flechas, lineas, cuadros o circulos. Tocalas para moverlas",
            "elige uno abajo: sale en el medio. Muevelo con el dedo; punto verde: girar y agrandar"};

    private void loadMarkPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        canvas.setMarkTextStyle(sp.getInt("mk_style", 1));
        for (int k = 0; k < CanvasView.TX_N; k++)
            if (sp.contains("mk_tx" + k)) canvas.setMarkTextOpt(k, sp.getInt("mk_tx" + k, 0));
        canvas.setMarkArrowShape(sp.getInt("mk_ar", CanvasView.AR_ARROW));
        canvas.setMarkArrowAlpha(sp.getInt("mk_ar_a", 255));
        canvas.setMarkArrowEdge(sp.getBoolean("mk_ar_e", false));
        canvas.setMarkArrowHead(sp.getInt("mk_ar_h", 100));
        canvas.setMarkArrowTaper(sp.getInt("mk_ar_t", 100));
        canvas.setMarkArrowHeadStyle(sp.getInt("mk_ar_hs", 0));
        canvas.setMarkArrowDash(sp.getBoolean("mk_ar_d", false));
        canvas.setMarkArrowFill(sp.getBoolean("mk_ar_f", false));
        // v8.94: la sombra de antes (suave / fuerte) pasa a sombra negra
        if (sp.getInt("mk_tx" + CanvasView.TX_SHADOW, 0) > 0 && !sp.contains("mk_tx" + CanvasView.TX_SHCOL))
            canvas.setMarkTextOpt(CanvasView.TX_SHCOL, 0xFF000000);
        canvas.setMarkFont(sp.getInt("mk_font", 1));
        // v8.95: formas guardadas (antes de elegir la forma), tamano propio, lupa y numeros
        canvas.setCustomShapes(readCustomShapes());
        canvas.setMarkSize(sp.getInt("mk_size", 20));
        canvas.setMarkLoupeShape(sp.getInt("mk_loupe_s", 0));
        canvas.setMarkLoupeRing(sp.getInt("mk_loupe_r", 100));
        canvas.setMarkNumShape(sp.getInt("mk_num_s", 0));
        canvas.setMarkNumStyle(sp.getInt("mk_num_st", 0));
        canvas.setMarkNumRing(sp.getInt("mk_num_r", 1));
        canvas.setMarkSpotShape(sp.getInt("mk_spot", 0));
        canvas.setMarkSpotDark(sp.getInt("mk_dark", 60) / 100f);
        canvas.setMarkHideHow(sp.getInt("mk_hide", 0));
        canvas.setMarkHideStrength(sp.getInt("mk_hide_k", 45));
        canvas.setMarkHideShape(sp.getInt("mk_hide_shape", sp.getBoolean("mk_hide_brush", false) ? 1 : 0));
        canvas.setMarkLoupeZoom(sp.getFloat("mk_zoom", 2f));
        canvas.setMarkKind(sp.getInt("mk_kind", CanvasView.MK_TEXT));
        canvas.setMarkListener(new CanvasView.MarkListener() {
            @Override public void onMarkEditText(String current, boolean isNew) {
                // v8.94: se escribe directo sobre la imagen con el teclado del telefono
                if (destroyed || isFinishing()) return;
                if (isNew) { txTab = 0; txItem = 1; }
                startTyping(current);
            }

            @Override public void onMarkSelected(int kind) {
                if (destroyed || isFinishing()) return;
                if (shapeStylePop != null && shapeStylePop.isShowing()) shapeStylePop.dismiss();
                updateUi();
            }

            @Override public void onMarkTypingStop() {
                if (destroyed || isFinishing()) return;
                stopTyping(false);
                updateUi();
            }

            @Override public void onMarkColorPicked(int color) {
                if (destroyed || isFinishing()) return;
                int t = pickTarget;
                pickTarget = -1;
                if (t >= 0) applyTextColor(t, color);
                else { canvas.setColor(color); updateUi(); }
            }
        });
    }

    private void saveMarkPrefs() {
        android.content.SharedPreferences.Editor ed = getSharedPreferences("pz", MODE_PRIVATE).edit();
        for (int k = 0; k < CanvasView.TX_N; k++) ed.putInt("mk_tx" + k, canvas.getMarkTextOpt(k));
        ed.putInt("mk_ar", canvas.getMarkArrowShape()).putInt("mk_ar_a", canvas.getMarkArrowAlpha())
                .putBoolean("mk_ar_e", canvas.getMarkArrowEdge())
                .putInt("mk_ar_h", canvas.getMarkArrowHead()).putInt("mk_ar_t", canvas.getMarkArrowTaper())
                .putInt("mk_ar_hs", canvas.getMarkArrowHeadStyle()).putBoolean("mk_ar_d", canvas.getMarkArrowDash())
                .putBoolean("mk_ar_f", canvas.getMarkArrowFill())
                .putInt("mk_size", canvas.getMarkSize())
                .putInt("mk_loupe_s", canvas.getMarkLoupeShape()).putInt("mk_loupe_r", canvas.getMarkLoupeRing())
                .putInt("mk_num_s", canvas.getMarkNumShape()).putInt("mk_num_st", canvas.getMarkNumStyle())
                .putInt("mk_num_r", canvas.getMarkNumRing()).apply();
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putInt("mk_kind", canvas.getMarkKind())
                .putInt("mk_style", canvas.getMarkTextStyle()).putInt("mk_font", canvas.getMarkFont())
                .putInt("mk_spot", canvas.getMarkSpotShape())
                .putInt("mk_dark", Math.round(canvas.getMarkSpotDark() * 100f))
                .putInt("mk_hide", canvas.getMarkHideHow()).putInt("mk_hide_k", canvas.getMarkHideStrength())
                .putInt("mk_hide_shape", canvas.getMarkHideShape())
                .putFloat("mk_zoom", canvas.getMarkLoupeZoom()).apply();
    }

    /** Escribir o cambiar el texto (con el teclado del telefono). */
    private void markTextDialog(String current, final boolean isNew) {
        if (destroyed || isFinishing()) return;
        final android.widget.EditText ed = new android.widget.EditText(this);
        ed.setText(current);
        ed.setSelection(ed.getText().length());
        ed.setHint("Escribe aqui");
        ed.setMinLines(1);
        ed.setMaxLines(6);
        ed.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(18), dp(6), dp(18), 0);
        box.addView(ed, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog.Builder b = new SheetBuilder(this)
                .setTitle(isNew ? "Texto nuevo" : "Cambiar el texto")
                .setView(box)
                .setPositiveButton("Listo", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        canvas.markSetText(ed.getText().toString(), isNew);
                        if (isNew && canvas.isMarkTextDraft())
                            canvas.showHud("Muevelo con el dedo. Punto verde: girar y agrandar. Lado: ancho. X quita, +1 copia", 2800);
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null);
        if (!isNew) b.setNeutralButton("Quitar", new android.content.DialogInterface.OnClickListener() {
            @Override public void onClick(android.content.DialogInterface d, int w) {
                canvas.markSetText("", false);
                updateUi();
            }
        });
        AlertDialog dlg = b.create();
        if (dlg.getWindow() != null)
            dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        dlg.show();
        ed.requestFocus();
    }

    private void buildMarkBar(LinearLayout bar) {
        int cur = canvas.getMarkKind();
        if (canvas.hasMarkSelected() && !canvas.isMarkTextDraft()) {
            // v8.94: con una marca elegida (como iMarkup): copiar y mover poquito a poquito
            bar.addView(iconButton(R.drawable.ic_dup, "Copiar la marca", new Runnable() {
                public void run() { canvas.duplicateSelectedMark(); updateUi(); }
            }));
            int[] ic = {R.drawable.ic_nudge_l, R.drawable.ic_nudge_r, R.drawable.ic_nudge_u, R.drawable.ic_nudge_d};
            final float[][] dir = {{-1f, 0f}, {1f, 0f}, {0f, -1f}, {0f, 1f}};
            String[] nm = {"Mover a la izquierda", "Mover a la derecha", "Mover arriba", "Mover abajo"};
            for (int i = 0; i < 4; i++) {
                final int k = i;
                bar.addView(repeatButton(ic[i], nm[i], new Runnable() {
                    public void run() { canvas.nudgeSelectedMark(dir[k][0] * dp(1), dir[k][1] * dp(1)); }
                }));
            }
            View sp = new View(this);
            sp.setBackgroundColor(0x55FFFFFF);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(1), dp(26));
            slp.setMargins(dp(4), 0, dp(4), 0);
            bar.addView(sp, slp);
            final ImageButton[] tune = new ImageButton[1];
            tune[0] = iconButton(R.drawable.ic_tune, "Ajustes de " + CanvasView.MK_NAMES[cur], new Runnable() {
                public void run() { showMarkPanel(tune[0]); }
            });
            bar.addView(tune[0]);
            ImageButton ok = iconButton(R.drawable.ic_check, "Pintar las marcas (van a la capa Marcas)", new Runnable() {
                public void run() { canvas.applyMarkDrafts(); updateUi(); }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
            return;
        }
        for (int i = 0; i < MK_ICON.length; i++) {
            final int k = i;
            ImageButton b = iconButton(MK_ICON[i], CanvasView.MK_NAMES[i] + ": " + MK_HELP[i], new Runnable() {
                public void run() {
                    canvas.setMarkKind(k);
                    saveMarkPrefs();
                    canvas.showHud(CanvasView.MK_NAMES[k] + ": " + MK_HELP[k], 2600);
                    updateUi();
                }
            });
            b.setBackgroundResource(i == cur ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(b);
        }
        final ImageButton[] tune = new ImageButton[1];
        tune[0] = iconButton(R.drawable.ic_tune, "Ajustes de " + CanvasView.MK_NAMES[cur], new Runnable() {
            public void run() { showMarkPanel(tune[0]); }
        });
        bar.addView(tune[0]);
        ImageButton ok = iconButton(R.drawable.ic_check, "Pintar las marcas (van a la capa Marcas)", new Runnable() {
            public void run() {
                canvas.applyMarkDrafts();
                updateUi();
            }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        bar.addView(ok);
    }

    // ==================================================================
    // v8.94 EDITOR DE TEXTO (como iMarkup) y RECORTAR en pestanas.
    // Un panel abajo (tapa la barra de siempre mientras lo usas):
    //   tira con barritas o colores  /  fila de iconos  /  X  pestanas  check
    // ==================================================================

    private LinearLayout editPanel;
    private int epKind;                       // 0 nada, 1 texto, 2 recortar
    private int txTab, txItem = 1;            // texto: pestana (Estilo, Borde, Ajustar) y opcion
    private int cropTab;                      // recortar: Proporcion, Forma, Girar, Tamano
    private int cropReturnMode = CanvasView.MODE_BRUSH;
    private boolean typingActive;
    private int pickTarget = -1;              // gotero: a que se le pone el color

    /** Colores rapidos (como la paleta de iMarkup). */
    private static final int[] EP_PAL = {0xFFFFFFFF, 0xFFBDBDBD, 0xFF757575, 0xFF000000, 0xFFE53935, 0xFFFF7043,
            0xFFFFD600, 0xFF43A047, 0xFF1DE9B6, 0xFF29B6F6, 0xFF1E5BD8, 0xFF5E35B1, 0xFFE040A0, 0xFF795548};

    /** Destinos de color del texto. */
    private static final int PT_TEXT = 0, PT_BG = 1, PT_OUT = 2, PT_SHADOW = 3, PT_FRAME = 4;

    private LinearLayout editPanel() {
        if (editPanel == null) {
            editPanel = new LinearLayout(this);
            editPanel.setOrientation(LinearLayout.VERTICAL);
            editPanel.setBackgroundColor(0xFF17171C);
            editPanel.setClickable(true);
            editPanel.setVisibility(View.GONE);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
            ((ViewGroup) findViewById(R.id.canvas).getParent()).addView(editPanel, lp);
        }
        return editPanel;
    }

    /** Muestra el panel que toca (texto elegido en Marcar, o Recortar) o lo esconde. */
    private void syncEditPanel(int mode) {
        // v8.95: 1 texto elegido, 2 recortar, 3 escribiendo (solo X y check arriba), 4 Marcar
        int want = 0;
        if (mode == CanvasView.MODE_MARK) want = canvas.isMarkTyping() ? 3 : canvas.isMarkTextDraft() ? 1 : 4;
        else if (mode == CanvasView.MODE_CROP) want = 2;
        View bottom = findViewById(R.id.bottomPanel);
        showTypeBar(want == 3);
        if (want == 0) {
            if (editPanel != null) editPanel.setVisibility(View.GONE);
            if (epKind != 0) {
                bottom.setVisibility(View.VISIBLE);
                epInsets(false, mode);
            }
            epKind = 0;
            if (typingActive && !canvas.isMarkTyping()) stopTyping(false);
            return;
        }
        LinearLayout p = editPanel();
        p.setPadding(0, 0, 0, bottom.getPaddingBottom());
        boolean entering = epKind == 0 || (epKind == 2) != (want == 2);
        epKind = want;
        if (entering) epInsets(true, mode);
        bottom.setVisibility(View.INVISIBLE);
        if (want == 3) {
            // escribiendo: el teclado ocupa abajo; no se arma ningun panel debajo de el
            p.setVisibility(View.GONE);
            return;
        }
        if (want == 1) buildTextPanel(); else if (want == 2) buildCropPanel(); else buildMarkPanel();
        p.setVisibility(View.VISIBLE);
    }

    // ==================================================================
    // v8.95 MARCAR con todo ABAJO (como iMarkup): nada sale en el medio tapando la imagen.
    //   tira (barrita, colores o formas)  /  opciones del tipo  /  X  tipos  check
    // Mientras escribes solo hay una X y un check arriba (el teclado no tapa ningun panel).
    // ==================================================================

    private final int[] mkItem = new int[7];          // opcion elegida en cada tipo de marca
    private static final int MKI_MOVE = 90;
    private int markReturnMode = CanvasView.MODE_BRUSH;
    private long markExitAsk;
    private int cropSizeItem;
    private LinearLayout typeBar;
    private static final int PT_MARK = 5, PT_NUMRING = 6;

    private static final String[][] MKP_NAMES = {
            {"Escribir"},
            {"Forma", "Oscuro"},
            {"Tipo", "Forma", "Fuerza", "Color", "Grosor"},
            {"Forma", "Aumento", "Borde", "Color"},
            {"Diseno", "Estilo", "Tamano", "Color", "Contorno", "Siguiente"},
            {"Forma", "Grosor", "Color", "Punta", "Tipo", "Inicio", "Linea", "Relleno", "Opacidad", "Borde"},
            {"Senales", "Manos", "Caras"}};
    private static final int[][] MKP_ICONS = {
            {R.drawable.ic_mk_text},
            {R.drawable.ic_shapes, R.drawable.ic_tone},
            {R.drawable.ic_mk_hide, R.drawable.ic_shapes, R.drawable.ic_tune, R.drawable.ic_palette_grid, R.drawable.ic_tx_size},
            {R.drawable.ic_shapes, R.drawable.ic_zoom, R.drawable.ic_tx_pen, R.drawable.ic_palette_grid},
            {R.drawable.ic_shapes, R.drawable.ic_tx_outline, R.drawable.ic_tx_size, R.drawable.ic_palette_grid,
                    R.drawable.ic_tx_pen, R.drawable.ic_mk_num},
            {R.drawable.ic_shapes, R.drawable.ic_tx_size, R.drawable.ic_palette_grid, R.drawable.ic_sh_arrow,
                    R.drawable.ic_ar_double, R.drawable.ic_ar_wedge, R.drawable.ic_sh_line, R.drawable.ic_bucket,
                    R.drawable.ic_opacity, R.drawable.ic_tx_outline},
            {R.drawable.ic_stk_sign, R.drawable.ic_stk_hand, R.drawable.ic_sticker}};
    private static final int[] LOUPE_ICON = {R.drawable.ic_sh_circle, R.drawable.ic_sh_rect, R.drawable.ic_sh_rrect,
            R.drawable.ic_sh_heart, R.drawable.ic_sh_star};
    private static final int[] NUM_ICON = {R.drawable.ic_sh_circle, R.drawable.ic_sh_rect, R.drawable.ic_sh_rrect,
            R.drawable.ic_num_pin, R.drawable.ic_num_diamond};

    /** Que opciones se muestran segun lo elegido (no se muestran las que no hacen nada). */
    private boolean mkItemVisible(int kind, int id) {
        if (kind == CanvasView.MK_HIDE) {
            if (id == 2) return canvas.getMarkHideHow() != 2;
            if (id == 3) return canvas.getMarkHideHow() == 2;
            if (id == 4) return canvas.getMarkHideShape() == 1;
        }
        if (kind == CanvasView.MK_ARROW) {
            int s = canvas.getMarkArrowShape();
            boolean box = s == CanvasView.AR_RECT || s == CanvasView.AR_OVAL;
            boolean head = s == CanvasView.AR_ARROW || s == CanvasView.AR_DOUBLE || s == CanvasView.AR_FREE || s == CanvasView.AR_WEDGE;
            if (id == 3 || id == 4) return head;
            if (id == 5) return s == CanvasView.AR_ARROW || s == CanvasView.AR_LINE;
            if (id == 7) return box;
        }
        return true;
    }

    /** Barra de arriba mientras escribes: X (no poner el texto) y check (listo). */
    private void showTypeBar(boolean on) {
        View top = findViewById(R.id.topBar);
        if (!on) {
            if (typeBar != null && typeBar.getVisibility() == View.VISIBLE) {
                typeBar.setVisibility(View.GONE);
                top.setVisibility(View.VISIBLE);
            }
            return;
        }
        if (typeBar == null) {
            typeBar = new LinearLayout(this);
            typeBar.setOrientation(LinearLayout.HORIZONTAL);
            typeBar.setGravity(Gravity.CENTER_VERTICAL);
            ImageButton x = new ImageButton(this);
            x.setImageResource(R.drawable.ic_close);
            x.setBackgroundColor(0x00000000);
            x.setContentDescription("No poner el texto");
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    stopTyping(false);
                    canvas.markTextCancel();
                    updateUi();
                }
            });
            typeBar.addView(x, new LinearLayout.LayoutParams(dp(56), dp(52)));
            TextView t = new TextView(this);
            t.setText("Escribe con el teclado");
            t.setTextColor(0xCCFFFFFF);
            t.setTextSize(13f);
            t.setGravity(Gravity.CENTER);
            typeBar.addView(t, new LinearLayout.LayoutParams(0, dp(52), 1f));
            ImageButton ok = new ImageButton(this);
            ok.setImageResource(R.drawable.ic_check);
            ok.setBackgroundColor(0x00000000);
            ok.setContentDescription("Listo");
            ok.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    stopTyping(false);        // queda el texto elegido: abajo sale Estilo, Borde y Ajustar
                    updateUi();
                }
            });
            typeBar.addView(ok, new LinearLayout.LayoutParams(dp(56), dp(52)));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
            ((ViewGroup) findViewById(R.id.canvas).getParent()).addView(typeBar, lp);
        }
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) typeBar.getLayoutParams();
        lp.topMargin = Math.max(0, top.getTop());
        typeBar.setLayoutParams(lp);
        typeBar.setVisibility(View.VISIBLE);
        top.setVisibility(View.INVISIBLE);
    }

    // ---- piezas de la tira

    /** Botones de texto en una fila que se desliza. */
    private void epChips(LinearLayout parent, String[] names, int[] ids, int cur, final IntPick pick) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(2), dp(8), dp(4));
        hs.addView(row);
        for (int i = 0; i < names.length; i++) {
            final int id = ids[i];
            TextView t = stabSeg(names[i]);
            t.setMinWidth(dp(72));
            t.setBackgroundResource(id == cur ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
            t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { pick.pick(id); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38));
            lp.setMargins(dp(3), 0, dp(3), 0);
            row.addView(t, lp);
        }
        parent.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void epNote(LinearLayout parent, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(11f);
        t.setTextColor(0xFFA8A8B2);
        t.setPadding(dp(14), dp(2), dp(14), dp(2));
        parent.addView(t);
    }

    /** Una forma guardada en chiquito. */
    private static final class ShapePreview extends android.graphics.drawable.Drawable {
        private final float[] pts;
        private final android.graphics.Paint pt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        ShapePreview(float[] a) { pts = a; }

        @Override public void draw(android.graphics.Canvas c) {
            if (pts == null || pts.length < 6) return;
            android.graphics.Rect b = getBounds();
            float m = Math.min(b.width(), b.height()) * 0.8f;
            float x0 = b.exactCenterX() - m / 2f, y0 = b.exactCenterY() - m / 2f;
            android.graphics.Path p = new android.graphics.Path();
            for (int i = 0; i + 1 < pts.length; i += 2) {
                float x = x0 + pts[i] * m, y = y0 + pts[i + 1] * m;
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            pt.setStyle(android.graphics.Paint.Style.STROKE);
            pt.setStrokeJoin(android.graphics.Paint.Join.ROUND);
            pt.setStrokeWidth(Math.max(2f, m * 0.08f));
            pt.setColor(0xFFFFFFFF);
            c.drawPath(p, pt);
        }

        @Override public void setAlpha(int a) { }

        @Override public void setColorFilter(android.graphics.ColorFilter cf) { pt.setColorFilter(cf); }

        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    /**
     * Fila de formas con iconos. custom = tambien las formas que guardaste (y "Guardar" cuando la
     * marca elegida es una hecha a mano).
     */
    private void epShapes(LinearLayout parent, int[] icons, String[] names, int[] ids, int cur, boolean custom,
                          final IntPick pick) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(2), dp(8), dp(4));
        hs.addView(row);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(46), dp(40));
        clp.setMargins(dp(3), 0, dp(3), 0);
        if (custom && canvas.canSaveSelectedShape()) {
            TextView sv = stabSeg("Guardar esta forma");
            sv.setBackgroundResource(R.drawable.bg_seg_on);
            sv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { saveCustomShape(); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
            lp.setMargins(dp(3), 0, dp(3), 0);
            row.addView(sv, lp);
        }
        for (int i = 0; i < icons.length; i++) {
            final int id = ids[i];
            ImageView b = new ImageView(this);
            b.setImageResource(icons[i]);
            b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            b.setPadding(dp(8), dp(7), dp(8), dp(7));
            b.setContentDescription(names[id < names.length ? id : 0]);
            b.setBackgroundResource(id == cur ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
            b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { pick.pick(id); } });
            row.addView(b, clp);
        }
        if (custom) {
            for (int i = 0; i < canvas.customShapeCount(); i++) {
                final int k = i, id = CanvasView.CS_CUSTOM + i;
                ImageView b = new ImageView(this);
                b.setImageDrawable(new ShapePreview(canvas.customShape(i)));
                b.setPadding(dp(6), dp(5), dp(6), dp(5));
                b.setContentDescription("Mi forma " + (i + 1));
                b.setBackgroundResource(id == cur ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
                b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { pick.pick(id); } });
                b.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override public boolean onLongClick(View v) { deleteCustomShape(k); return true; }
                });
                row.addView(b, clp);
            }
            TextView mine = stabSeg("+ Mi forma");
            mine.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    canvas.showHud("Elige \"A mano\", rodea tu forma con el dedo y tocala: sale \"Guardar esta forma\". "
                            + "Queda en esta lista. Mantener apretada una forma tuya la borra.", 5200);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
            lp.setMargins(dp(3), 0, dp(3), 0);
            row.addView(mine, lp);
        }
        parent.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    // ---- formas guardadas

    private java.util.ArrayList<float[]> customShapeList() {
        java.util.ArrayList<float[]> l = new java.util.ArrayList<float[]>();
        for (int i = 0; i < canvas.customShapeCount(); i++) l.add(canvas.customShape(i));
        return l;
    }

    private void storeCustomShapes(java.util.List<float[]> l) {
        StringBuilder sb = new StringBuilder();
        for (float[] a : l) {
            if (sb.length() > 0) sb.append(';');
            for (int i = 0; i < a.length; i++) {
                if (i > 0) sb.append(',');
                sb.append(Math.round(a[i] * 1000f));
            }
        }
        getSharedPreferences("pz", MODE_PRIVATE).edit().putString("mk_shapes", sb.toString()).apply();
    }

    private java.util.ArrayList<float[]> readCustomShapes() {
        java.util.ArrayList<float[]> l = new java.util.ArrayList<float[]>();
        String s = getSharedPreferences("pz", MODE_PRIVATE).getString("mk_shapes", "");
        if (s == null || s.isEmpty()) return l;
        for (String one : s.split(";")) {
            String[] n = one.split(",");
            if (n.length < 6 || n.length % 2 != 0) continue;
            float[] a = new float[n.length];
            try {
                for (int i = 0; i < n.length; i++) a[i] = Integer.parseInt(n[i].trim()) / 1000f;
            } catch (NumberFormatException e) {
                continue;
            }
            l.add(a);
        }
        return l;
    }

    private void saveCustomShape() {
        float[] a = canvas.selectedShapeNormalized();
        if (a == null) {
            canvas.showHud("Primero rodea una forma con \"A mano\" y tocala", 2200);
            return;
        }
        java.util.ArrayList<float[]> l = customShapeList();
        while (l.size() >= 12) l.remove(0);
        l.add(a);
        canvas.setCustomShapes(l);
        storeCustomShapes(l);
        canvas.showHud("Forma guardada. Ya esta en la lista para usarla cuando quieras", 2600);
        updateUi();
    }

    private void deleteCustomShape(int i) {
        java.util.ArrayList<float[]> l = customShapeList();
        if (i < 0 || i >= l.size()) return;
        l.remove(i);
        canvas.setCustomShapes(l);
        storeCustomShapes(l);
        if (!canvas.hasMarkSelected()) {
            if (canvas.getMarkSpotShape() >= CanvasView.CS_CUSTOM) canvas.setMarkSpotShape(0);
            if (canvas.getMarkHideShape() >= CanvasView.CS_CUSTOM) canvas.setMarkHideShape(0);
            if (canvas.getMarkLoupeShape() >= CanvasView.CS_CUSTOM) canvas.setMarkLoupeShape(0);
        }
        saveMarkPrefs();
        canvas.showHud("Forma borrada de la lista", 1500);
        updateUi();
    }

    // ---- v8.99 botones sobrios y stickers

    /** Boton redondeado de colores tranquilos (principal: verde azulado; si no: gris oscuro). */
    private TextView softButton(String text, boolean primary) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(14f);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(dp(14), 0, dp(14), 0);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(primary ? 0xFF1F8A6A : 0xFF33333C);
        bg.setCornerRadius(dp(12));
        t.setBackground(bg);
        return t;
    }

    /** Un sticker en chiquito (para la lista). */
    private static final class StickerPreview extends android.graphics.drawable.Drawable {
        private final int id;
        private final android.graphics.Paint pt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        StickerPreview(int id) { this.id = id; }

        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            float m = Math.min(b.width(), b.height());
            if (m <= 0f) return;
            c.save();
            c.translate(b.exactCenterX(), b.exactCenterY());
            c.scale(m / 100f, m / 100f);
            CanvasView.drawSticker(c, id, pt);
            c.restore();
        }

        @Override public void setAlpha(int a) { }

        @Override public void setColorFilter(android.graphics.ColorFilter cf) { }

        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private int stkScrollX = -1, stkScrollTab = -1;
    private boolean stkHintShown;

    /** Cuadricula de stickers en 2 filas que se desliza de lado. Tocas uno y sale en la imagen. */
    private void stickerGrid(LinearLayout parent, int from, int n, final int tab) {
        final HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout cols = new LinearLayout(this);
        cols.setOrientation(LinearLayout.HORIZONTAL);
        cols.setPadding(dp(8), dp(2), dp(8), dp(4));
        hs.addView(cols);
        LinearLayout col = null;
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                cols.addView(col);
            }
            final int id = from + i;
            ImageView b = new ImageView(this);
            b.setImageDrawable(new StickerPreview(id));
            b.setPadding(dp(6), dp(5), dp(6), dp(5));
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(0xFF24242B);
            bg.setCornerRadius(dp(10));
            b.setBackground(bg);
            b.setContentDescription(id < CanvasView.STK_EMOJI0 ? CanvasView.STK_SIGN_NAMES[id] : "Sticker");
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    stkScrollX = hs.getScrollX();
                    stkScrollTab = tab;
                    canvas.addSticker(id);
                    if (!stkHintShown) {
                        stkHintShown = true;
                        canvas.showHud("Muevelo con el dedo. Punto verde: girar y agrandar. X quita, +1 copia", 2600);
                    }
                    updateUi();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(50), dp(46));
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            col.addView(b, lp);
        }
        parent.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // al volver a armar el panel la lista queda donde estaba (no salta al principio)
        if (stkScrollTab == tab && stkScrollX > 0) {
            final int sx = stkScrollX;
            hs.post(new Runnable() { @Override public void run() { hs.scrollTo(sx, 0); } });
        }
    }

    // ---- panel de Marcar

    private void buildMarkPanel() {
        LinearLayout p = editPanel();
        p.removeAllViews();
        final int kind = canvas.getMarkKind();
        final boolean sel = canvas.hasMarkSelected();
        if (mkItem[kind] == MKI_MOVE && !sel) mkItem[kind] = 0;
        if (mkItem[kind] != MKI_MOVE && (mkItem[kind] >= MKP_NAMES[kind].length || !mkItemVisible(kind, mkItem[kind]))) mkItem[kind] = 0;
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.VERTICAL);
        strip.setPadding(0, dp(6), 0, dp(2));
        p.addView(strip);
        View sep = new View(this);
        sep.setBackgroundColor(0x22FFFFFF);
        p.addView(sep, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        LinearLayout icons = epIconRow(p);
        if (sel) {
            // con una marca elegida: copiar y mover poquito a poquito (como iMarkup)
            epItem(icons, R.drawable.ic_dup, null, "Copiar", false, new Runnable() {
                public void run() { canvas.duplicateSelectedMark(); updateUi(); }
            });
            epItem(icons, R.drawable.ic_move, null, "Mover", mkItem[kind] == MKI_MOVE, new Runnable() {
                public void run() { mkItem[kind] = MKI_MOVE; buildMarkPanel(); }
            });
            epItem(icons, R.drawable.ic_trash, null, "Quitar", false, new Runnable() {
                public void run() { canvas.deleteSelectedMark(); updateUi(); }
            });
            if (canvas.canSaveSelectedShape()) {
                // una forma hecha a mano: se puede guardar para usarla despues
                epItem(icons, R.drawable.ic_add, null, "Guardar", false, new Runnable() {
                    public void run() { saveCustomShape(); }
                });
            }
        }
        for (int i = 0; i < MKP_NAMES[kind].length; i++) {
            if (!mkItemVisible(kind, i)) continue;
            final int k = i;
            epItem(icons, MKP_ICONS[kind][i], null, MKP_NAMES[kind][i], mkItem[kind] == i, new Runnable() {
                public void run() { mkItem[kind] = k; buildMarkPanel(); }
            });
        }
        buildMarkStrip(strip, kind, mkItem[kind]);
        // fila de abajo: X, los 6 tipos y check
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(0xFF111114);
        ImageButton x = new ImageButton(this);
        x.setImageResource(R.drawable.ic_close);
        x.setBackgroundColor(0x00000000);
        x.setContentDescription("Salir sin poner las marcas");
        x.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (canvas.hasMarkDraft()) {
                    long now = android.os.SystemClock.uptimeMillis();
                    if (now - markExitAsk > 3500) {
                        markExitAsk = now;
                        canvas.showHud("Hay marcas sin pintar. Toca la X otra vez para salir sin ponerlas", 3200);
                        return;
                    }
                    canvas.discardMarkDraft();
                }
                selectTool(markReturnMode);
            }
        });
        row.addView(x, new LinearLayout.LayoutParams(dp(42), dp(56)));
        // v8.99: cada tipo con su nombre debajo (antes solo iconos: no se entendia que era cada uno).
        // Si no caben (celular angosto) la fila se desliza.
        HorizontalScrollView kinds = new HorizontalScrollView(this);
        kinds.setHorizontalScrollBarEnabled(false);
        kinds.setFillViewport(true);
        LinearLayout kr = new LinearLayout(this);
        kr.setOrientation(LinearLayout.HORIZONTAL);
        kinds.addView(kr);
        int avail = getResources().getDisplayMetrics().widthPixels - dp(84);
        int itemW = Math.max(dp(40), avail / MK_ICON.length);
        for (int i = 0; i < MK_ICON.length; i++) {
            final int k = i;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setContentDescription(CanvasView.MK_NAMES[i]);
            ImageView b = new ImageView(this);
            b.setImageResource(MK_ICON[i]);
            b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            if (i == kind) b.setColorFilter(0xFF2EE6A6);
            it.addView(b, new LinearLayout.LayoutParams(dp(24), dp(24)));
            TextView nm = new TextView(this);
            nm.setText(MK_SHORT[i]);
            nm.setTextSize(9.5f);
            nm.setSingleLine(true);
            nm.setGravity(Gravity.CENTER);
            nm.setTextColor(i == kind ? 0xFF2EE6A6 : 0xFFB8B8C0);
            it.addView(nm, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            it.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    canvas.setMarkKind(k);
                    saveMarkPrefs();
                    canvas.showHud(CanvasView.MK_NAMES[k] + ": " + MK_HELP[k], 2000);
                    updateUi();
                }
            });
            kr.addView(it, new LinearLayout.LayoutParams(itemW, dp(56)));
        }
        row.addView(kinds, new LinearLayout.LayoutParams(0, dp(56), 1f));
        ImageButton ok = new ImageButton(this);
        ok.setImageResource(R.drawable.ic_check);
        ok.setBackgroundColor(0x00000000);
        ok.setContentDescription("Pintar las marcas y salir");
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (canvas.hasMarkDraft()) canvas.applyMarkDrafts();
                selectTool(markReturnMode);
            }
        });
        row.addView(ok, new LinearLayout.LayoutParams(dp(42), dp(56)));
        p.addView(row);
    }

    private void buildMarkStrip(LinearLayout s, final int kind, int item) {
        final CanvasView cv = canvas;
        final Runnable redo = new Runnable() { public void run() { saveMarkPrefs(); updateUi(); } };
        if (item == MKI_MOVE) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            int[] ic = {R.drawable.ic_nudge_l, R.drawable.ic_nudge_r, R.drawable.ic_nudge_u, R.drawable.ic_nudge_d};
            final float[][] dir = {{-1f, 0f}, {1f, 0f}, {0f, -1f}, {0f, 1f}};
            String[] nm = {"Mover a la izquierda", "Mover a la derecha", "Mover arriba", "Mover abajo"};
            for (int i = 0; i < 4; i++) {
                final int k = i;
                row.addView(repeatButton(ic[i], nm[i], new Runnable() {
                    public void run() { cv.nudgeSelectedMark(dir[k][0] * dp(1), dir[k][1] * dp(1)); }
                }));
            }
            s.addView(row);
            epNote(s, "Manten apretado para seguir moviendo. Tambien puedes arrastrar la marca con el dedo.");
            return;
        }
        if (kind == CanvasView.MK_TEXT) {
            // v8.99: como iMarkup: un boton grande para escribir. Los estilos (Normal, Meme...)
            // estan en Estilo > Rapido, al tocar un texto.
            TextView w = softButton("+   Escribir texto", true);
            w.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { cv.markNewTextCenter(); }
            });
            LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
            wl.setMargins(dp(14), dp(2), dp(14), dp(2));
            s.addView(w, wl);
            epNote(s, "O toca la imagen donde va el texto");
        } else if (kind == CanvasView.MK_STICK) {
            int from, n;
            if (item == 1) { from = CanvasView.STK_EMOJI0; n = CanvasView.STK_HANDS.length; }
            else if (item == 2) { from = CanvasView.STK_EMOJI0 + CanvasView.STK_HANDS.length; n = CanvasView.STK_FACES.length; }
            else { from = 0; n = CanvasView.STK_SIGN_N; }
            stickerGrid(s, from, n, item);
        } else if (kind == CanvasView.MK_SPOT) {
            if (item == 0) {
                epShapes(s, SPOT_ICON, CanvasView.MK_SPOT_SHAPES, SPOT_ORDER, cv.getMarkSpotShape(), true, new IntPick() {
                    public void pick(int i) { cv.setMarkSpotShape(i); redo.run(); }
                });
            } else {
                epSlider(s, "Oscuro %", 5, 95, Math.round(cv.getMarkSpotDark() * 100f), new IntPick() {
                    public void pick(int v) { cv.setMarkSpotDark(v / 100f); }
                });
            }
        } else if (kind == CanvasView.MK_HIDE) {
            if (item == 0) {
                epChips(s, new String[]{"Cuadritos", "Borroso", "Color"}, new int[]{0, 1, 2}, cv.getMarkHideHow(), new IntPick() {
                    public void pick(int i) { cv.setMarkHideHow(i); redo.run(); }
                });
            } else if (item == 1) {
                epShapes(s, HIDE_ICON, CanvasView.MK_HIDE_SHAPES, HIDE_ORDER, cv.getMarkHideShape(), true, new IntPick() {
                    public void pick(int i) { cv.setMarkHideShape(i); redo.run(); }
                });
            } else if (item == 2) {
                epSlider(s, "Fuerza", 1, 100, cv.getMarkHideStrength(), new IntPick() {
                    public void pick(int v) { cv.setMarkHideStrength(v); }
                });
            } else if (item == 3) {
                epPalette(s, PT_MARK, cv.getMarkSelColor() | 0xFF000000, false, null, new IntPick() {
                    public void pick(int c) { applyTextColor(PT_MARK, c); }
                });
            } else {
                epSlider(s, "Grosor", 1, 100, cv.getMarkSize(), new IntPick() {
                    public void pick(int v) { cv.setMarkSize(v); }
                });
            }
        } else if (kind == CanvasView.MK_LOUPE) {
            if (item == 0) {
                epShapes(s, LOUPE_ICON, CanvasView.MK_LOUPE_SHAPES, new int[]{0, 1, 2, 3, 4}, cv.getMarkLoupeShape(), true, new IntPick() {
                    public void pick(int i) { cv.setMarkLoupeShape(i); redo.run(); }
                });
            } else if (item == 1) {
                epSlider(s, "Aumento %", 125, 600, Math.round(cv.getMarkLoupeZoom() * 100f), new IntPick() {
                    public void pick(int v) { cv.setMarkLoupeZoom(v / 100f); }
                });
            } else if (item == 2) {
                epSlider(s, "Borde %", 0, 300, cv.getMarkLoupeRing(), new IntPick() {
                    public void pick(int v) { cv.setMarkLoupeRing(v); }
                });
            } else {
                epPalette(s, PT_MARK, cv.getMarkSelColor() | 0xFF000000, false, null, new IntPick() {
                    public void pick(int c) { applyTextColor(PT_MARK, c); }
                });
            }
        } else if (kind == CanvasView.MK_NUM) {
            if (item == 0) {
                epShapes(s, NUM_ICON, CanvasView.MK_NUM_SHAPES, new int[]{0, 1, 2, 3, 4}, cv.getMarkNumShape(), false, new IntPick() {
                    public void pick(int i) { cv.setMarkNumShape(i); redo.run(); }
                });
            } else if (item == 1) {
                epChips(s, new String[]{"Relleno", "Solo borde"}, new int[]{0, 1}, cv.getMarkNumStyle(), new IntPick() {
                    public void pick(int i) { cv.setMarkNumStyle(i); redo.run(); }
                });
            } else if (item == 2) {
                epSlider(s, "Tamano", 1, 100, cv.getMarkSize(), new IntPick() {
                    public void pick(int v) { cv.setMarkSize(v); }
                });
            } else if (item == 3) {
                epPalette(s, PT_MARK, cv.getMarkSelColor() | 0xFF000000, false, null, new IntPick() {
                    public void pick(int c) { applyTextColor(PT_MARK, c); }
                });
            } else if (item == 4) {
                epPalette(s, PT_NUMRING, cv.getMarkNumRing(), true, "Auto", new IntPick() {
                    public void pick(int c) { applyTextColor(PT_NUMRING, c); }
                });
            } else {
                epChips(s, new String[]{"- 1", "Volver a 1", "+ 1"}, new int[]{0, 1, 2}, -1, new IntPick() {
                    public void pick(int i) {
                        cv.setMarkNumber(i == 0 ? cv.getMarkNumber() - 1 : i == 1 ? 1 : cv.getMarkNumber() + 1);
                        cv.showHud("El proximo toque pone el " + cv.getMarkNumber(), 1400);
                        buildMarkPanel();
                    }
                });
                epNote(s, "El proximo toque pone el " + cv.getMarkNumber() + ". Si quitas un numero, los que siguen bajan uno.");
            }
        } else {
            if (item == 0) {
                int[] icons = new int[AR_ORDER.length];
                for (int i = 0; i < AR_ORDER.length; i++) icons[i] = AR_ICON[AR_ORDER[i]];
                epShapes(s, icons, CanvasView.MK_ARROW_SHAPES, AR_ORDER, cv.getMarkArrowShape(), false, new IntPick() {
                    public void pick(int i) { cv.setMarkArrowShape(i); redo.run(); }
                });
            } else if (item == 1) {
                epSlider(s, "Grosor", 1, 100, cv.getMarkSize(), new IntPick() {
                    public void pick(int v) { cv.setMarkSize(v); }
                });
            } else if (item == 2) {
                epPalette(s, PT_MARK, cv.getMarkSelColor() | 0xFF000000, false, null, new IntPick() {
                    public void pick(int c) { applyTextColor(PT_MARK, c); }
                });
            } else if (item == 3) {
                epSlider(s, "Punta %", 30, 300, cv.getMarkArrowHead(), new IntPick() {
                    public void pick(int v) { cv.setMarkArrowHead(v); }
                });
            } else if (item == 4) {
                epChips(s, CanvasView.AR_HEADS, new int[]{0, 1, 2}, cv.getMarkArrowHeadStyle(), new IntPick() {
                    public void pick(int i) { cv.setMarkArrowHeadStyle(i); redo.run(); }
                });
            } else if (item == 5) {
                epSlider(s, "Inicio %", 5, 100, cv.getMarkArrowTaper(), new IntPick() {
                    public void pick(int v) { cv.setMarkArrowTaper(v); }
                });
            } else if (item == 6) {
                epChips(s, new String[]{"Continua", "Punteada"}, new int[]{0, 1}, cv.getMarkArrowDash() ? 1 : 0, new IntPick() {
                    public void pick(int i) { cv.setMarkArrowDash(i == 1); redo.run(); }
                });
            } else if (item == 7) {
                epChips(s, new String[]{"Solo borde", "Con relleno"}, new int[]{0, 1}, cv.getMarkArrowFill() ? 1 : 0, new IntPick() {
                    public void pick(int i) { cv.setMarkArrowFill(i == 1); redo.run(); }
                });
            } else if (item == 8) {
                epSlider(s, "Opacidad %", 10, 100, Math.round(cv.getMarkArrowAlpha() * 100f / 255f), new IntPick() {
                    public void pick(int v) { cv.setMarkArrowAlpha(Math.round(v * 2.55f)); }
                });
            } else {
                epChips(s, new String[]{"Sin borde", "Con borde"}, new int[]{0, 1}, cv.getMarkArrowEdge() ? 1 : 0, new IntPick() {
                    public void pick(int i) { cv.setMarkArrowEdge(i == 1); redo.run(); }
                });
            }
        }
    }

    /**
     * v8.96: la imagen se acomoda arriba del panel de abajo (Marcar, Recortar, texto): asi el panel
     * nunca tapa la parte de abajo de la imagen. Al salir vuelve a la barra de siempre.
     */
    private void epInsets(final boolean on, final int mode) {
        final View top = findViewById(R.id.topBar), bottom = findViewById(R.id.bottomPanel);
        final View panel = editPanel();
        panel.post(new Runnable() {
            @Override public void run() {
                if (destroyed) return;
                int b = bottom.getHeight();
                if (on && panel.getVisibility() == View.VISIBLE) b = Math.max(b, panel.getHeight());
                canvas.setInsets(top.getHeight() + dp(12), b);
                // solo Recortar reacomoda la vista (en Marcar no se pierde el zoom que tenias)
                if (on && mode == CanvasView.MODE_CROP && canvas.getProject() != null) canvas.fitForCrop();
            }
        });
    }

    // ---- piezas del panel

    /** Fila de abajo: X, pestanas y check. */
    private void epTabs(LinearLayout p, String[] tabs, int cur, final Runnable cancel, final Runnable ok, final IntPick onTab) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(0xFF111114);
        ImageButton x = new ImageButton(this);
        x.setImageResource(R.drawable.ic_close);
        x.setBackgroundColor(0x00000000);
        x.setContentDescription("Cancelar");
        x.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cancel.run(); } });
        row.addView(x, new LinearLayout.LayoutParams(dp(52), dp(50)));
        for (int i = 0; i < tabs.length; i++) {
            final int k = i;
            TextView t = new TextView(this);
            t.setText(tabs[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(14f);
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            t.setTextColor(i == cur ? 0xFF2EE6A6 : 0xFFE8E8EE);
            t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { onTab.pick(k); } });
            if (i == cur) t.setPaintFlags(t.getPaintFlags() | android.graphics.Paint.UNDERLINE_TEXT_FLAG);
            row.addView(t, new LinearLayout.LayoutParams(0, dp(50), 1f));
        }
        ImageButton ok2 = new ImageButton(this);
        ok2.setImageResource(R.drawable.ic_check);
        ok2.setBackgroundColor(0x00000000);
        ok2.setContentDescription("Listo");
        ok2.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { ok.run(); } });
        row.addView(ok2, new LinearLayout.LayoutParams(dp(52), dp(50)));
        p.addView(row);
    }

    interface IntPick { void pick(int i); }

    /** Fila de iconos con nombre debajo (se desliza si no entra). */
    private LinearLayout epIconRow(LinearLayout p) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(4), dp(4), dp(4), dp(4));
        hs.addView(row);
        p.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private void epItem(LinearLayout row, int icon, android.graphics.drawable.Drawable dr, String name, boolean on,
                        final Runnable click) {
        LinearLayout it = new LinearLayout(this);
        it.setOrientation(LinearLayout.VERTICAL);
        it.setGravity(Gravity.CENTER);
        ImageView iv = new ImageView(this);
        if (dr != null) iv.setImageDrawable(dr); else iv.setImageResource(icon);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        if (on) iv.setColorFilter(0xFF2EE6A6);
        it.addView(iv, new LinearLayout.LayoutParams(dp(dr != null ? 46 : 28), dp(28)));
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(10f);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setTextColor(on ? 0xFF2EE6A6 : 0xFFD8D8DE);
        t.setGravity(Gravity.CENTER);
        it.addView(t);
        it.setContentDescription(name);
        it.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { click.run(); } });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(dr != null ? 64 : 62), dp(56));
        row.addView(it, lp);
    }

    /** Barrita con nombre y valor. min puede ser negativo. */
    private void epSlider(LinearLayout parent, String name, final int min, int max, int value, final IntPick change) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), 0, dp(10), 0);
        TextView l = new TextView(this);
        l.setText(name);
        l.setTextSize(12f);
        l.setTextColor(0xFFD8D8DE);
        row.addView(l, new LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT));
        final TextView v = new TextView(this);
        v.setTextSize(12f);
        v.setTextColor(0xFF2EE6A6);
        v.setGravity(Gravity.END);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, value - min)));
        v.setText(String.valueOf(value));
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                v.setText(String.valueOf(p + min));
                if (user) change.pick(p + min);
            }

            @Override public void onStopTrackingTouch(SeekBar s) { saveMarkPrefs(); }
        });
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(40), 1f));
        row.addView(v, new LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(row);
    }

    /**
     * Fila de colores: (sin) (gotero) y la paleta. cur = el color de ahora (para la marca).
     * extra = un circulo especial (Auto / Brillo / Contraste) con el valor 1, o null.
     */
    private void epPalette(LinearLayout parent, final int target, int cur, boolean none, String extra, final IntPick pick) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(4), dp(8), dp(6));
        hs.addView(row);
        if (none) row.addView(epSwatch(0, cur == 0, "sin", pick), epSwLp());
        ImageView eye = new ImageView(this);
        eye.setImageResource(R.drawable.ic_picker);
        eye.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        eye.setContentDescription("Gotero: toma un color de la imagen");
        eye.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pickTarget = target;
                canvas.markPickOnce();
            }
        });
        row.addView(eye, epSwLp());
        if (extra != null) row.addView(epSwatch(1, cur == 1, extra, pick), epSwLp());
        for (int c : EP_PAL) row.addView(epSwatch(c, (cur | 0xFF000000) == c && cur != 0 && cur != 1, null, pick), epSwLp());
        parent.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private LinearLayout.LayoutParams epSwLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private TextView epSwatch(final int c, boolean on, String label, final IntPick pick) {
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(dp(6));
        boolean special = c == 0 || c == 1;
        g.setColor(special ? 0xFF2C2C33 : c);
        g.setStroke(on ? dp(3) : dp(1), on ? 0xFF2EE6A6 : 0x55FFFFFF);
        t.setBackground(g);
        t.setTextSize(special ? 9f : 16f);
        t.setTextColor(special ? 0xFFFFFFFF : (on ? contrastText(c) : 0x00000000));
        t.setText(special ? label : "✓");
        t.setContentDescription(special ? label : "Color");
        t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { pick.pick(c); } });
        return t;
    }

    /** Pone el color elegido (paleta o gotero) en lo que corresponde del texto. */
    private void applyTextColor(int target, int c) {
        switch (target) {
            case PT_TEXT:
                if (c == 0 || c == 1) return;
                canvas.setColor(c);
                SharedPreferencesHolder.pushRecent(this, c);
                break;
            case PT_BG: canvas.setMarkTextOpt(CanvasView.TX_BG, c); break;
            case PT_OUT: canvas.setMarkTextOpt(CanvasView.TX_OUT, c); break;
            case PT_SHADOW: canvas.setMarkTextOpt(CanvasView.TX_SHCOL, c); break;
            case PT_FRAME:
                if (c == 0 || c == 1) return;
                canvas.setMarkTextOpt(CanvasView.TX_FRCOL, c);
                break;
            case PT_MARK:
                // color de la marca elegida y de las nuevas (flechas, numeros, borde de la lupa, tapar con color)
                if (c == 0 || c == 1) return;
                canvas.setColor(c);
                SharedPreferencesHolder.pushRecent(this, c);
                break;
            case PT_NUMRING: canvas.setMarkNumRing(c); break;
            default: return;
        }
        saveMarkPrefs();
        updateUi();
    }

    /** Muestra un borde o globo en chiquito (para elegirlo). */
    private static final class FramePreview extends android.graphics.drawable.Drawable {
        private final int frame;
        private final android.graphics.Paint pt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        FramePreview(int f) { frame = f; }

        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            float cx = b.exactCenterX(), cy = b.exactCenterY() - b.height() * 0.08f;
            float hw = b.width() * 0.34f, hh = b.height() * 0.24f, size = b.height() * 0.3f;
            c.save();
            c.translate(cx, cy);
            pt.setStyle(android.graphics.Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(2f, b.height() * 0.05f));
            pt.setStrokeJoin(android.graphics.Paint.Join.ROUND);
            pt.setColor(0xFFFFFFFF);
            if (frame == CanvasView.TF_NONE) {
                pt.setPathEffect(new android.graphics.DashPathEffect(new float[]{4f, 4f}, 0f));
                c.drawRect(-hw * 0.6f, -hh, hw * 0.6f, hh, pt);
                pt.setPathEffect(null);
            } else if (frame == CanvasView.TF_POINT) {
                c.drawLine(-hw, hh * 0.6f, hw * 0.5f, hh * 0.6f, pt);
                c.drawLine(hw * 0.5f, hh * 0.6f, hw * 1.1f, 0f, pt);
                pt.setStyle(android.graphics.Paint.Style.FILL);
                c.drawCircle(hw * 1.1f, 0f, pt.getStrokeWidth() * 1.6f, pt);
            } else {
                c.drawPath(CanvasView.textFramePath(frame, hw * (frame == CanvasView.TF_BURST ? 1.15f : 1f),
                        hh * (frame == CanvasView.TF_BURST ? 1.3f : 1f), size), pt);
            }
            pt.setStyle(android.graphics.Paint.Style.FILL);
            pt.setTextAlign(android.graphics.Paint.Align.CENTER);
            pt.setTextSize(size * 0.75f);
            pt.setFakeBoldText(true);
            c.drawText(frame == CanvasView.TF_NONE ? "T" : "Hi", 0f, size * 0.26f, pt);
            pt.setFakeBoldText(false);
            c.restore();
        }

        @Override public void setAlpha(int a) { }

        @Override public void setColorFilter(android.graphics.ColorFilter cf) { pt.setColorFilter(cf); }

        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    /** Proporcion en chiquito (rectangulo de esa forma). */
    private static final class RatioPreview extends android.graphics.drawable.Drawable {
        private final float r;
        private final android.graphics.Paint pt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        RatioPreview(float ratio) { r = ratio; }

        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            float m = Math.min(b.width(), b.height()) * 0.8f;
            float w = r <= 0f ? m * 0.8f : r >= 1f ? m : m * r, h = r <= 0f ? m * 0.8f : r >= 1f ? m / r : m;
            float cx = b.exactCenterX(), cy = b.exactCenterY();
            pt.setStyle(android.graphics.Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(2f, m * 0.08f));
            pt.setColor(0xFFFFFFFF);
            if (r <= 0f) pt.setPathEffect(new android.graphics.DashPathEffect(new float[]{4f, 3f}, 0f));
            c.drawRoundRect(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f, m * 0.08f, m * 0.08f, pt);
            pt.setPathEffect(null);
        }

        @Override public void setAlpha(int a) { }

        @Override public void setColorFilter(android.graphics.ColorFilter cf) { pt.setColorFilter(cf); }

        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    // ---- texto

    private static final String[] TX_TABS = {"Estilo", "Borde", "Ajustar"};
    private static final String[] TX_STYLE_ITEMS = {"Rapido", "Letra", "Tamano", "Formato", "Color", "Fondo", "Contorno", "Sombra"};
    private static final int[] TX_STYLE_ICONS = {R.drawable.ic_sparkle, R.drawable.ic_mk_text, R.drawable.ic_tx_size,
            R.drawable.ic_tx_format, R.drawable.ic_palette_grid, R.drawable.ic_bucket, R.drawable.ic_tx_outline, R.drawable.ic_shadow};
    private static final String[] TX_ADJ_ITEMS = {"Letras", "Lineas", "Girar"};
    private static final int[] TX_ADJ_ICONS = {R.drawable.ic_tx_lsp, R.drawable.ic_tx_lh, R.drawable.ic_rotate};

    private void buildTextPanel() {
        LinearLayout p = editPanel();
        p.removeAllViews();
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.VERTICAL);
        strip.setPadding(0, dp(6), 0, dp(2));
        p.addView(strip);
        View sep = new View(this);
        sep.setBackgroundColor(0x22FFFFFF);
        p.addView(sep, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        LinearLayout icons = epIconRow(p);
        if (txTab == 0) {
            for (int i = 0; i < TX_STYLE_ITEMS.length; i++) {
                final int k = i;
                epItem(icons, TX_STYLE_ICONS[i], null, TX_STYLE_ITEMS[i], txItem == i, new Runnable() {
                    public void run() { txItem = k; buildTextPanel(); }
                });
            }
        } else if (txTab == 1) {
            epItem(icons, R.drawable.ic_tx_pen, null, "Grosor", txItem == 100, new Runnable() {
                public void run() { txItem = 100; buildTextPanel(); }
            });
            epItem(icons, R.drawable.ic_palette_grid, null, "Color", txItem == 101, new Runnable() {
                public void run() { txItem = 101; buildTextPanel(); }
            });
            int fr = canvas.getMarkTextOpt(CanvasView.TX_FRAME);
            for (int f = 0; f < CanvasView.TX_FRAMES.length; f++) {
                final int k = f;
                epItem(icons, 0, new FramePreview(f), CanvasView.TX_FRAMES[f], fr == f, new Runnable() {
                    public void run() {
                        canvas.setMarkTextOpt(CanvasView.TX_FRAME, k);
                        saveMarkPrefs();
                        if (txItem < 100) txItem = 100;
                        buildTextPanel();
                    }
                });
            }
        } else {
            for (int i = 0; i < TX_ADJ_ITEMS.length; i++) {
                final int k = 200 + i;
                epItem(icons, TX_ADJ_ICONS[i], null, TX_ADJ_ITEMS[i], txItem == k, new Runnable() {
                    public void run() { txItem = k; buildTextPanel(); }
                });
            }
        }
        buildTextStrip(strip);
        epTabs(p, TX_TABS, txTab, new Runnable() {
            public void run() {
                stopTyping(false);
                canvas.markTextCancel();
                updateUi();
            }
        }, new Runnable() {
            public void run() {
                stopTyping(false);
                canvas.markTextDone();
                canvas.showHud("Texto listo. El check de abajo pinta todas las marcas", 1800);
                updateUi();
            }
        }, new IntPick() {
            public void pick(int i) {
                txTab = i;
                txItem = i == 0 ? 1 : i == 1 ? 100 : 200;
                buildTextPanel();
            }
        });
    }

    private void buildTextStrip(LinearLayout s) {
        final CanvasView cv = canvas;
        switch (txItem) {
            case 0: {   // estilos rapidos
                LinearLayout box = new LinearLayout(this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(10), 0, dp(10), 0);
                final int[] dummy = {-1};
                String[] names = CanvasView.TX_PRESETS;
                segRow(box, new String[]{names[0], names[1], names[2]}, dummy, new int[]{0, 1, 2}, new Runnable() {
                    public void run() { cv.setMarkTextPreset(dummy[0]); saveMarkPrefs(); dummy[0] = -1; }
                });
                View g = new View(this);
                box.addView(g, new LinearLayout.LayoutParams(1, dp(6)));
                final int[] dummy2 = {-1};
                segRow(box, new String[]{names[3], names[4], names[5]}, dummy2, new int[]{3, 4, 5}, new Runnable() {
                    public void run() { cv.setMarkTextPreset(dummy2[0]); saveMarkPrefs(); dummy2[0] = -1; }
                });
                s.addView(box);
                break;
            }
            case 1: {   // letras del telefono
                HorizontalScrollView hs = new HorizontalScrollView(this);
                hs.setHorizontalScrollBarEnabled(false);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(6), 0, dp(6), 0);
                hs.addView(row);
                int cur = cv.getMarkFont();
                for (int i = 0; i < CanvasView.MK_FONTS.length; i++) {
                    final int k = i;
                    LinearLayout it = new LinearLayout(this);
                    it.setOrientation(LinearLayout.VERTICAL);
                    it.setGravity(Gravity.CENTER);
                    it.setBackgroundResource(i == cur ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
                    TextView a = new TextView(this);
                    a.setText("Aa");
                    a.setTypeface(CanvasView.markTypeface(i));
                    a.setTextSize(20f);
                    a.setTextColor(0xFFFFFFFF);
                    a.setGravity(Gravity.CENTER);
                    it.addView(a);
                    TextView n = new TextView(this);
                    n.setText(CanvasView.MK_FONTS[i]);
                    n.setTextSize(9f);
                    n.setTextColor(0xFFD8D8DE);
                    n.setSingleLine(true);
                    n.setGravity(Gravity.CENTER);
                    it.addView(n);
                    it.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            cv.setMarkFont(k);
                            saveMarkPrefs();
                            buildTextPanel();
                        }
                    });
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(72), dp(58));
                    lp.setMargins(dp(3), 0, dp(3), 0);
                    row.addView(it, lp);
                }
                s.addView(hs);
                break;
            }
            case 2:
                epSlider(s, "Tamano", 1, 100, cv.getMarkTextOpt(CanvasView.TX_SIZE), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_SIZE, v); }
                });
                break;
            case 3: {   // formato
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(8), 0, dp(8), 0);
                final int al = cv.getMarkTextOpt(CanvasView.TX_ALIGN), face = cv.getMarkTextOpt(CanvasView.TX_FACE);
                final boolean und = cv.getMarkTextOpt(CanvasView.TX_UNDER) == 1;
                int[] alIc = {R.drawable.ic_al_l, R.drawable.ic_al_c, R.drawable.ic_al_r};
                String[] alN = {"Izquierda", "Centro", "Derecha"};
                for (int i = 0; i < 3; i++) {
                    final int k = i;
                    ImageView b = new ImageView(this);
                    b.setImageResource(alIc[i]);
                    b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                    b.setContentDescription(alN[i]);
                    if (al == i) b.setColorFilter(0xFF2EE6A6);
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { cv.setMarkTextOpt(CanvasView.TX_ALIGN, k); saveMarkPrefs(); buildTextPanel(); }
                    });
                    row.addView(b, new LinearLayout.LayoutParams(0, dp(44), 1f));
                }
                String[] fl = {"B", "I", "U"};
                for (int i = 0; i < 3; i++) {
                    final int k = i;
                    TextView t = new TextView(this);
                    t.setText(fl[i]);
                    t.setGravity(Gravity.CENTER);
                    t.setTextSize(20f);
                    boolean on = k == 0 ? (face & 1) != 0 : k == 1 ? (face & 2) != 0 : und;
                    t.setTextColor(on ? 0xFF2EE6A6 : 0xFFFFFFFF);
                    t.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SERIF,
                            k == 0 ? android.graphics.Typeface.BOLD : k == 1 ? android.graphics.Typeface.ITALIC : android.graphics.Typeface.NORMAL));
                    if (k == 2) t.setPaintFlags(t.getPaintFlags() | android.graphics.Paint.UNDERLINE_TEXT_FLAG);
                    t.setContentDescription(k == 0 ? "Negrita" : k == 1 ? "Cursiva" : "Subrayado");
                    t.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            if (k == 2) cv.setMarkTextOpt(CanvasView.TX_UNDER, und ? 0 : 1);
                            else cv.setMarkTextOpt(CanvasView.TX_FACE, face ^ (k == 0 ? 1 : 2));
                            saveMarkPrefs();
                            buildTextPanel();
                        }
                    });
                    row.addView(t, new LinearLayout.LayoutParams(0, dp(44), 1f));
                }
                s.addView(row);
                break;
            }
            case 4:
                epSlider(s, "Opacidad", 5, 100, Math.round(cv.getMarkTextOpt(CanvasView.TX_OPACITY) * 100f / 255f), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_OPACITY, Math.round(v * 2.55f)); }
                });
                epPalette(s, PT_TEXT, cv.getMarkSelColor() | 0xFF000000, false, null, new IntPick() {
                    public void pick(int c) { applyTextColor(PT_TEXT, c); }
                });
                break;
            case 5:
                epSlider(s, "Opacidad", 5, 100, Math.round(cv.getMarkTextOpt(CanvasView.TX_BGA) * 100f / 255f), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_BGA, Math.round(v * 2.55f)); }
                });
                epPalette(s, PT_BG, cv.getMarkTextOpt(CanvasView.TX_BG), true, "Texto", new IntPick() {
                    public void pick(int c) { applyTextColor(PT_BG, c); }
                });
                break;
            case 6:
                epSlider(s, "Grosor", 2, 40, cv.getMarkTextOpt(CanvasView.TX_OUTW), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_OUTW, v); }
                });
                epPalette(s, PT_OUT, cv.getMarkTextOpt(CanvasView.TX_OUT), true, "Auto", new IntPick() {
                    public void pick(int c) { applyTextColor(PT_OUT, c); }
                });
                break;
            case 7:
                epSlider(s, "Difuminado", 0, 100, cv.getMarkTextOpt(CanvasView.TX_SHBLUR), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_SHBLUR, v); }
                });
                epSlider(s, "Distancia", 0, 100, cv.getMarkTextOpt(CanvasView.TX_SHDIST), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_SHDIST, v); }
                });
                epPalette(s, PT_SHADOW, cv.getMarkTextOpt(CanvasView.TX_SHCOL), true, "Brillo", new IntPick() {
                    public void pick(int c) { applyTextColor(PT_SHADOW, c); }
                });
                break;
            case 100:
                epSlider(s, "Grosor", 2, 30, cv.getMarkTextOpt(CanvasView.TX_FRW), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_FRW, v); }
                });
                break;
            case 101:
                epPalette(s, PT_FRAME, cv.getMarkTextOpt(CanvasView.TX_FRCOL), false, null, new IntPick() {
                    public void pick(int c) { applyTextColor(PT_FRAME, c); }
                });
                break;
            case 200:
                epSlider(s, "Entre letras", -10, 60, cv.getMarkTextOpt(CanvasView.TX_LSP), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_LSP, v); }
                });
                break;
            case 201:
                epSlider(s, "Entre lineas", 70, 200, cv.getMarkTextOpt(CanvasView.TX_LH), new IntPick() {
                    public void pick(int v) { cv.setMarkTextOpt(CanvasView.TX_LH, v); }
                });
                break;
            case 202:
                epSlider(s, "Girar", -180, 180, cv.getMarkTextAngle(), new IntPick() {
                    public void pick(int v) { cv.setMarkTextAngle(v); }
                });
                break;
            default:
                break;
        }
    }

    // ---- escribir con el teclado del telefono
    // v8.99: como iMarkup. Antes se escribia en una cajita invisible de 2 puntos y en algunos
    // celulares (moto e30) el teclado no salia o tapaba el texto; ademas cada letra rehacia el
    // texto con todos sus efectos (lento en gama baja). Ahora sale una pantalla propia oscura con
    // "Escribe algo" ARRIBA (el teclado nunca la tapa) y el texto va a la imagen al tocar el check.

    private FrameLayout typeScreen;
    private EditText typeEdit;
    private TextView typeTitle;

    private FrameLayout typeScreen() {
        if (typeScreen == null) {
            typeScreen = new FrameLayout(this);
            typeScreen.setBackgroundColor(0xF2101014);
            typeScreen.setClickable(true);          // no pasa toques a la imagen de atras
            typeScreen.setFocusable(true);
            typeScreen.setVisibility(View.GONE);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            ImageButton x = new ImageButton(this);
            x.setImageResource(R.drawable.ic_close);
            x.setBackgroundColor(0x00000000);
            x.setContentDescription("No poner el texto");
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { cancelTyping(); }
            });
            top.addView(x, new LinearLayout.LayoutParams(dp(56), dp(52)));
            typeTitle = new TextView(this);
            typeTitle.setTextColor(0xCCFFFFFF);
            typeTitle.setTextSize(15f);
            typeTitle.setGravity(Gravity.CENTER);
            top.addView(typeTitle, new LinearLayout.LayoutParams(0, dp(52), 1f));
            ImageButton ok = new ImageButton(this);
            ok.setImageResource(R.drawable.ic_check);
            ok.setBackgroundColor(0x00000000);
            ok.setContentDescription("Listo");
            ok.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    stopTyping(false);      // el texto va a la imagen; abajo salen Estilo, Borde y Ajustar
                    updateUi();
                }
            });
            top.addView(ok, new LinearLayout.LayoutParams(dp(56), dp(52)));
            col.addView(top);
            typeEdit = new EditText(this);
            typeEdit.setBackground(null);
            typeEdit.setTextColor(0xFFFFFFFF);
            typeEdit.setHintTextColor(0x66FFFFFF);
            typeEdit.setHint("Escribe algo");
            typeEdit.setTextSize(26f);
            typeEdit.setGravity(Gravity.CENTER);
            typeEdit.setMinLines(1);
            typeEdit.setMaxLines(6);
            typeEdit.setPadding(dp(20), dp(18), dp(20), dp(18));
            typeEdit.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            typeEdit.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
                    | android.view.inputmethod.EditorInfo.IME_FLAG_NO_FULLSCREEN);
            typeEdit.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(500)});
            LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            elp.topMargin = dp(36);
            col.addView(typeEdit, elp);
            TextView tip = new TextView(this);
            tip.setText("Toca el check cuando termines. Despues lo mueves, giras y le cambias el estilo.");
            tip.setTextColor(0x88FFFFFF);
            tip.setTextSize(12f);
            tip.setGravity(Gravity.CENTER);
            tip.setPadding(dp(24), dp(6), dp(24), 0);
            col.addView(tip);
            typeScreen.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
            ((ViewGroup) findViewById(android.R.id.content)).addView(typeScreen,
                    new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return typeScreen;
    }

    private boolean typeScreenShown() { return typeScreen != null && typeScreen.getVisibility() == View.VISIBLE; }

    /** Abre la pantalla para escribir (o cambiar) el texto elegido. */
    private void startTyping(String current) {
        final FrameLayout ts = typeScreen();
        typingActive = true;
        boolean isNew = current == null || current.isEmpty();
        typeTitle.setText(isNew ? "Texto nuevo" : "Cambiar el texto");
        typeEdit.setText(current == null ? "" : current);
        typeEdit.setSelection(typeEdit.getText().length());
        try { typeEdit.setTypeface(CanvasView.markTypeface(canvas.getMarkFont())); } catch (Throwable ignored) { }
        // abajo del todo esta la barra del sistema; arriba, la de la hora: se deja ese espacio
        View topBar = findViewById(R.id.topBar);
        ts.setPadding(0, topBar != null ? Math.max(0, topBar.getTop()) : 0, 0, 0);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        ts.setVisibility(View.VISIBLE);
        ts.bringToFront();
        typeEdit.requestFocus();
        // dos intentos: en algunos celulares el primero llega antes de que la pantalla este lista
        Runnable show = new Runnable() {
            @Override public void run() {
                if (destroyed || !typingActive || !typeScreenShown()) return;
                typeEdit.requestFocus();
                android.view.inputmethod.InputMethodManager imm =
                        (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(typeEdit, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
            }
        };
        typeEdit.postDelayed(show, 60);
        typeEdit.postDelayed(show, 320);
        updateUi();
    }

    private void hideTypeScreen() {
        if (typeEdit != null) {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(typeEdit.getWindowToken(), 0);
            typeEdit.clearFocus();
        }
        if (typeScreen != null) typeScreen.setVisibility(View.GONE);
    }

    /** X de la pantalla de escribir: el texto queda como estaba (o se quita si era nuevo). */
    private void cancelTyping() {
        typingActive = false;
        hideTypeScreen();
        canvas.markTextCancel();
        updateUi();
    }

    /**
     * Cierra la pantalla de escribir y pone lo escrito en la imagen (una sola vez, no letra por
     * letra). endCanvas = avisar al lienzo aunque no se estuviera escribiendo.
     */
    private void stopTyping(boolean endCanvas) {
        boolean was = typingActive;
        typingActive = false;
        if (was && typeEdit != null) canvas.markTypingText(typeEdit.getText().toString());
        hideTypeScreen();
        if (endCanvas || was) canvas.markTypingEnd();
    }

    // ---- recortar en pestanas

    private static final String[] CROP_TABS = {"Proporcion", "Forma", "Girar", "Tamano"};
    private static final String[] CP_RATIO_SHORT = {"Libre", "1:1", "4:5", "3:4", "2:3", "9:16", "5:4", "4:3", "3:2", "16:9", "Otra"};

    private void buildCropPanel() {
        LinearLayout p = editPanel();
        p.removeAllViews();
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.VERTICAL);
        strip.setPadding(0, dp(4), 0, 0);
        p.addView(strip);
        LinearLayout icons = epIconRow(p);
        if (cropTab == 0) {
            float cur = canvas.getCropRatio();
            int sel = 0;
            for (int i = 0; i < CP_RATIOS.length; i++) if (Math.abs(CP_RATIOS[i] - cur) < 0.001f) sel = i;
            if (cur > 0f && sel == 0) sel = CP_RATIOS.length - 1;
            for (int i = 0; i < CP_RATIOS.length; i++) {
                final int k = i;
                epItem(icons, 0, new RatioPreview(CP_RATIOS[i] < 0f ? 1.6f : CP_RATIOS[i]), CP_RATIO_SHORT[i], sel == i,
                        new Runnable() {
                            public void run() {
                                if (CP_RATIOS[k] < 0f) {
                                    twoNumbersDialog("Proporcion personalizada", "Ancho", "Alto", 3, 2, new TwoNumbers() {
                                        public void got(int a, int b) {
                                            canvas.setCropOutput(0, 0);
                                            canvas.setCropRatio(a / (float) b);
                                            updateUi();
                                        }
                                    });
                                    return;
                                }
                                canvas.setCropOutput(0, 0);
                                canvas.setCropRatio(CP_RATIOS[k]);
                                updateUi();
                            }
                        });
            }
        } else if (cropTab == 1) {
            int cs = canvas.getCropShape();
            for (int i = 0; i < CS_ICON.length; i++) {
                final int k = i;
                epItem(icons, CS_ICON[i], null, CanvasView.CROP_SHAPES[i], cs == i, new Runnable() {
                    public void run() {
                        canvas.setCropShape(k);
                        if (k != 0) canvas.showHud("Lo de afuera de la forma queda transparente (guarda en PNG)", 2000);
                        updateUi();
                    }
                });
            }
        } else if (cropTab == 2) {
            epItem(icons, R.drawable.ic_rot_left, null, "Izquierda", false, new Runnable() {
                public void run() { canvas.transform(1); }
            });
            epItem(icons, R.drawable.ic_rot_right, null, "Derecha", false, new Runnable() {
                public void run() { canvas.transform(0); }
            });
            epItem(icons, R.drawable.ic_flip_h, null, "Voltear ↔", false, new Runnable() {
                public void run() { canvas.transform(2); }
            });
            epItem(icons, R.drawable.ic_flip_v, null, "Voltear ↕", false, new Runnable() {
                public void run() { canvas.transform(3); }
            });
        } else {
            // v8.95: las medidas van en una tira (sin ventanas en el medio)
            epItem(icons, R.drawable.ic_crop_res, null, "Resolucion", cropSizeItem == 0, new Runnable() {
                public void run() { cropSizeItem = 0; buildCropPanel(); }
            });
            epItem(icons, R.drawable.ic_resize, null, "Cambiar", cropSizeItem == 1, new Runnable() {
                public void run() { cropSizeItem = 1; buildCropPanel(); }
            });
            epItem(icons, R.drawable.ic_view_reset, null, "Cuadro nuevo", false, new Runnable() {
                public void run() { canvas.resetCropBox(); }
            });
            if (cropSizeItem == 0) {
                String[] names = new String[CP_RES.length];
                int[] ids = new int[CP_RES.length];
                int sel = 0;
                for (int i = 0; i < CP_RES.length; i++) {
                    ids[i] = i;
                    names[i] = CP_RES[i][0] == 0 ? "La del cuadro" : CP_RES[i][0] < 0 ? "Otra..." : CP_RES[i][0] + " x " + CP_RES[i][1];
                    if (CP_RES[i][0] == canvas.getCropOutW() && CP_RES[i][1] == canvas.getCropOutH()) sel = i;
                }
                if (canvas.getCropOutW() > 0 && sel == 0) sel = CP_RES.length - 1;
                epChips(strip, names, ids, sel, new IntPick() {
                    public void pick(int i) {
                        if (CP_RES[i][0] < 0) {
                            twoNumbersDialog("Resolucion", "Ancho (px)", "Alto (px)", 1080, 1080, new TwoNumbers() {
                                public void got(int a, int b) { canvas.setCropOutput(a, b); updateUi(); }
                            });
                            return;
                        }
                        canvas.setCropOutput(CP_RES[i][0], CP_RES[i][1]);
                        if (CP_RES[i][0] > 0)
                            canvas.showHud("Al recortar sale de " + CP_RES[i][0] + " x " + CP_RES[i][1], 2000);
                        updateUi();
                    }
                });
            } else {
                final Project pj = canvas.getProject();
                final int[] pcs = {25, 50, 75, 150, 200, -1};
                String[] names = {"25 %", "50 %", "75 %", "150 %", "200 %", "Medida..."};
                epChips(strip, names, new int[]{0, 1, 2, 3, 4, 5}, -1, new IntPick() {
                    public void pick(int i) {
                        if (pj == null) return;
                        if (pcs[i] < 0) { resizeDialog(); return; }
                        canvas.resizeCanvasTo(Math.max(1, Math.round(pj.w * pcs[i] / 100f)), Math.max(1, Math.round(pj.h * pcs[i] / 100f)));
                    }
                });
                if (pj != null) epNote(strip, "Ahora: " + pj.w + " x " + pj.h + ". Cambia todas las capas. Deshacer lo devuelve.");
            }
        }
        epTabs(p, CROP_TABS, cropTab, new Runnable() {
            public void run() {
                canvas.resetCropBox();
                selectTool(cropReturnMode);
            }
        }, new Runnable() {
            public void run() {
                canvas.applyCrop();
                selectTool(cropReturnMode);
            }
        }, new IntPick() {
            public void pick(int i) {
                cropTab = i;
                buildCropPanel();
            }
        });
    }

    private void showMarkPanel(View anchor) {
        if (shapeStylePop != null && shapeStylePop.isShowing()) { shapeStylePop.dismiss(); return; }
        if (!needProject()) return;
        final int kind = canvas.getMarkKind();
        LinearLayout box = darkCard();
        seeThrough(box, dp(14));
        TextView title = stabLabel(CanvasView.MK_NAMES[kind]);
        title.setTextColor(0xFF2EE6A6);
        title.setTextSize(14f);
        box.addView(title);
        final Runnable saved = new Runnable() {
            @Override public void run() { saveMarkPrefs(); canvas.invalidate(); }
        };
        if (kind == CanvasView.MK_TEXT) {
            // v8.94: los ajustes del texto estan en su editor (abajo, al tocar un texto). Aqui: el
            // estilo con el que salen los textos nuevos
            box.addView(stabLabel("Estilo de los textos nuevos"));
            final int[] st = {-1};
            String[] names = CanvasView.TX_PRESETS;
            segRow(box, new String[]{names[0], names[1], names[2]}, st, new int[]{0, 1, 2}, new Runnable() {
                @Override public void run() { canvas.setMarkTextPreset(st[0]); saved.run(); canvas.showHud(CanvasView.TX_PRESETS[st[0]], 900); }
            });
            View g = new View(this);
            box.addView(g, new LinearLayout.LayoutParams(1, dp(6)));
            final int[] st2 = {-1};
            segRow(box, new String[]{names[3], names[4], names[5]}, st2, new int[]{3, 4, 5}, new Runnable() {
                @Override public void run() { canvas.setMarkTextPreset(st2[0]); saved.run(); canvas.showHud(CanvasView.TX_PRESETS[st2[0]], 900); }
            });
            hintTo(box, "Toca la imagen y escribe con el teclado. Toca un texto para cambiarlo: abajo salen Estilo, Borde y Ajustar.");
        } else if (kind == CanvasView.MK_ARROW) {
            box.addView(stabLabel("Forma"));
            final int[] as = {canvas.getMarkArrowShape()};
            int[] icons = new int[AR_ORDER.length];
            for (int i = 0; i < AR_ORDER.length; i++) icons[i] = AR_ICON[AR_ORDER[i]];
            iconPickRowIds(box, icons, CanvasView.MK_ARROW_SHAPES, AR_ORDER, as, new Runnable() {
                @Override public void run() {
                    canvas.setMarkArrowShape(as[0]);
                    canvas.showHud(CanvasView.MK_ARROW_SHAPES[as[0]], 900);
                    saved.run();
                }
            });
            final TextView hv = stabHead(box, "Tamano de la punta");
            stabSlider(box, 300, canvas.getMarkArrowHead(), new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    int k = Math.max(30, v);
                    hv.setText(k + " %");
                    if (!user) return;
                    canvas.setMarkArrowHead(k);
                    saved.run();
                }
            });
            hv.setText(canvas.getMarkArrowHead() + " %");
            final TextView tv = stabHead(box, "Grosor del inicio (menos = se ensancha)");
            stabSlider(box, 100, canvas.getMarkArrowTaper(), new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    int k = Math.max(5, v);
                    tv.setText(k + " %");
                    if (!user) return;
                    canvas.setMarkArrowTaper(k);
                    saved.run();
                }
            });
            tv.setText(canvas.getMarkArrowTaper() + " %");
            box.addView(stabLabel("Punta"));
            final int[] hs = {canvas.getMarkArrowHeadStyle()};
            segRow(box, CanvasView.AR_HEADS, hs, new int[]{0, 1, 2}, new Runnable() {
                @Override public void run() { canvas.setMarkArrowHeadStyle(hs[0]); saved.run(); }
            });
            box.addView(stabLabel("Linea"));
            final int[] ds = {canvas.getMarkArrowDash() ? 1 : 0};
            segRow(box, new String[]{"Continua", "Punteada"}, ds, new int[]{0, 1}, new Runnable() {
                @Override public void run() { canvas.setMarkArrowDash(ds[0] == 1); saved.run(); }
            });
            box.addView(stabLabel("Cuadro y circulo"));
            final int[] fl = {canvas.getMarkArrowFill() ? 1 : 0};
            segRow(box, new String[]{"Solo borde", "Con relleno"}, fl, new int[]{0, 1}, new Runnable() {
                @Override public void run() { canvas.setMarkArrowFill(fl[0] == 1); saved.run(); }
            });
            final TextView av = stabHead(box, "Opacidad");
            stabSlider(box, 100, Math.round(canvas.getMarkArrowAlpha() * 100f / 255f), new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    int k = Math.max(10, v);
                    av.setText(k + " %");
                    if (!user) return;
                    canvas.setMarkArrowAlpha(Math.round(k * 2.55f));
                    saved.run();
                }
            });
            av.setText(Math.round(canvas.getMarkArrowAlpha() * 100f / 255f) + " %");
            box.addView(stabLabel("Borde (se ve sobre cualquier fondo)"));
            final int[] eg = {canvas.getMarkArrowEdge() ? 1 : 0};
            segRow(box, new String[]{"No", "Si"}, eg, new int[]{0, 1}, new Runnable() {
                @Override public void run() { canvas.setMarkArrowEdge(eg[0] == 1); saved.run(); }
            });
            hintTo(box, "Grosor de la linea: la barra de tamano de abajo. Color: el de abajo. Toca una flecha para "
                    + "moverla; las puntas azules la estiran; la X la quita. Arriba: copiar y mover poquito a poquito.");
        } else if (kind == CanvasView.MK_SPOT) {
            box.addView(stabLabel("Forma"));
            final int[] sh = {canvas.getMarkSpotShape()};
            iconPickRowIds(box, SPOT_ICON, CanvasView.MK_SPOT_SHAPES, SPOT_ORDER, sh, new Runnable() {
                @Override public void run() {
                    canvas.setMarkSpotShape(sh[0]);
                    canvas.showHud(CanvasView.MK_SPOT_SHAPES[sh[0]], 900);
                    saved.run();
                }
            });
            final TextView dv = stabHead(box, "Oscuro alrededor");
            stabSlider(box, 95, Math.round(canvas.getMarkSpotDark() * 100f), new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    int k = Math.max(5, v);
                    dv.setText(k + " %");
                    if (!user) return;
                    canvas.setMarkSpotDark(k / 100f);
                    saved.run();
                }
            });
            dv.setText(Math.round(canvas.getMarkSpotDark() * 100f) + " %");
            hintTo(box, "A mano: rodea con el dedo lo importante. Toca una marca para elegirla y cambiarla.");
        } else if (kind == CanvasView.MK_HIDE) {
            box.addView(stabLabel("Tapar con"));
            final int[] how = {canvas.getMarkHideHow()};
            segRow(box, new String[]{"Cuadritos", "Borroso", "Color"}, how, new int[]{0, 1, 2}, new Runnable() {
                @Override public void run() { canvas.setMarkHideHow(how[0]); saved.run(); }
            });
            box.addView(stabLabel("Forma"));
            final int[] br = {canvas.getMarkHideShape()};
            iconPickRowIds(box, HIDE_ICON, CanvasView.MK_HIDE_SHAPES, HIDE_ORDER, br, new Runnable() {
                @Override public void run() {
                    canvas.setMarkHideShape(br[0]);
                    canvas.showHud(CanvasView.MK_HIDE_SHAPES[br[0]], 900);
                    saved.run();
                }
            });
            final TextView kv = stabHead(box, "Fuerza");
            stabSlider(box, 100, canvas.getMarkHideStrength(), new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    int k = Math.max(1, v);
                    kv.setText(String.valueOf(k));
                    if (!user) return;
                    canvas.setMarkHideStrength(k);
                    saved.run();
                }
            });
            kv.setText(String.valueOf(canvas.getMarkHideStrength()));
            hintTo(box, "A mano: rodea lo que quieres tapar. Dedo: pinta encima (grosor: la barra de abajo). Color: el de abajo.");
        } else if (kind == CanvasView.MK_LOUPE) {
            box.addView(stabLabel("Aumento"));
            final int[] z = {Math.round(canvas.getMarkLoupeZoom() * 10f)};
            segRow(box, new String[]{"1.5x", "2x", "3x", "4x"}, z, new int[]{15, 20, 30, 40}, new Runnable() {
                @Override public void run() { canvas.setMarkLoupeZoom(z[0] / 10f); saved.run(); }
            });
            hintTo(box, "El borde toma el color de abajo (tambien la lupa elegida). Esquina: tamano.");
        } else if (kind == CanvasView.MK_STICK) {
            hintTo(box, "Los stickers estan abajo (Senales, Manos y Caras): toca uno y sale en el medio.");
        } else {
            final TextView nv = stabHead(box, "Siguiente numero");
            nv.setText(String.valueOf(canvas.getMarkNumber()));
            final int[] dummy = {-1};
            segRow(box, new String[]{"- 1", "Volver a 1", "+ 1"}, dummy, new int[]{0, 1, 2}, new Runnable() {
                @Override public void run() {
                    int n = canvas.getMarkNumber();
                    canvas.setMarkNumber(dummy[0] == 0 ? n - 1 : dummy[0] == 1 ? 1 : n + 1);
                    nv.setText(String.valueOf(canvas.getMarkNumber()));
                    dummy[0] = -1;
                }
            });
            hintTo(box, "Cada toque pone el numero y sube solo. Tocalo para moverlo, cambiarle el color o el tamano (esquina). Tamano de los nuevos: la barra de abajo.");
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        int w = Math.min(dp(320), getResources().getDisplayMetrics().widthPixels - dp(16));
        shapeStylePop = showCardPop(sv, box, anchor, w, 0.62f);
    }

    /** Fila de colores redondos. 0 = "No"; 1 = la palabra special (Auto / Texto). */
    private Runnable colorChipRow(LinearLayout parent, final int[] value, final int[] colors, String special, final Runnable changed) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final TextView[] tv = new TextView[colors.length];
        for (int i = 0; i < colors.length; i++) {
            final int c = colors[i];
            TextView t = new TextView(this);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(9f);
            t.setTextColor(0xFFFFFFFF);
            t.setText(c == 0 ? "No" : c == 1 ? special : "");
            t.setContentDescription(c == 0 ? "Sin" : c == 1 ? special : "Color");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(32), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(t, lp);
            tv[i] = t;
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    value[0] = c;
                    for (int k = 0; k < tv.length; k++) tv[k].setBackground(chipBg(colors[k], value[0] == colors[k]));
                    changed.run();
                }
            });
        }
        parent.addView(row);
        Runnable paint = new Runnable() {
            @Override public void run() {
                for (int k = 0; k < tv.length; k++) tv[k].setBackground(chipBg(colors[k], value[0] == colors[k]));
            }
        };
        paint.run();
        return paint;
    }

    private android.graphics.drawable.GradientDrawable chipBg(int c, boolean on) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(c == 0 || c == 1 ? 0xFF2C2C33 : c);
        g.setStroke(on ? dp(3) : dp(1), on ? 0xFF2EE6A6 : 0x66FFFFFF);
        return g;
    }

    /** Boton que repite mientras lo mantienes apretado (mover poquito a poquito). */
    private ImageButton repeatButton(int icon, String desc, final Runnable step) {
        final ImageButton b = iconButton(icon, desc, step);
        b.setOnClickListener(null);
        b.setOnTouchListener(new View.OnTouchListener() {
            final Runnable rep = new Runnable() {
                @Override public void run() {
                    step.run();
                    previewHandler.postDelayed(this, 45);
                }
            };

            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        v.setPressed(true);
                        step.run();
                        previewHandler.postDelayed(rep, 380);
                        return true;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        v.setPressed(false);
                        previewHandler.removeCallbacks(rep);
                        return true;
                    default:
                        return true;
                }
            }
        });
        return b;
    }

    /** Igual que iconPickRow, pero cada icono tiene su numero (ids). */
    private Runnable iconPickRowIds(LinearLayout parent, int[] icons, final String[] names, final int[] ids, final int[] value,
                                    final Runnable changed) {
        final int[] idx = {0};
        for (int i = 0; i < ids.length; i++) if (ids[i] == value[0]) idx[0] = i;
        String[] nm = new String[ids.length];
        for (int i = 0; i < ids.length; i++) nm[i] = names[ids[i]];
        return iconPickRow(parent, icons, nm, idx, new Runnable() {
            @Override public void run() {
                value[0] = ids[idx[0]];
                changed.run();
            }
        });
    }

    /** Fila de iconos para elegir uno (formas de flecha, formas de recorte). */
    private Runnable iconPickRow(LinearLayout parent, int[] icons, final String[] names, final int[] value, final Runnable changed) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final ImageView[] iv = new ImageView[icons.length];
        for (int i = 0; i < icons.length; i++) {
            final int k = i;
            ImageView b = new ImageView(this);
            b.setImageResource(icons[i]);
            b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            b.setPadding(dp(6), dp(6), dp(6), dp(6));
            b.setContentDescription(names[i]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            if (i > 0) lp.setMargins(dp(4), 0, 0, 0);
            row.addView(b, lp);
            iv[i] = b;
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    value[0] = k;
                    for (int j = 0; j < iv.length; j++) iv[j].setBackgroundResource(j == value[0] ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
                    changed.run();
                }
            });
        }
        parent.addView(row);
        Runnable paint = new Runnable() {
            @Override public void run() {
                for (int j = 0; j < iv.length; j++) iv[j].setBackgroundResource(j == value[0] ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
            }
        };
        paint.run();
        return paint;
    }

    private void hintTo(LinearLayout box, String s) {
        TextView h = stabLabel(s);
        h.setTextSize(11f);
        h.setTextColor(0xFF8A8A92);
        h.setPadding(0, dp(8), 0, 0);
        box.addView(h);
    }

    /** Lista de figuras (iconos con nombre). */
    private void showShapePicker(View anchor) {
        if (shapePop != null && shapePop.isShowing()) { shapePop.dismiss(); return; }
        if (!needProject()) return;
        int m = canvas.getMode();
        int current = m == CanvasView.MODE_SHAPE ? canvas.getShapeType()
                : m == CanvasView.MODE_CURVE ? SH_CURVE : m == CanvasView.MODE_POLY ? SH_POLY
                : m == CanvasView.MODE_PAINT ? SH_FREE : Integer.MIN_VALUE;
        LinearLayout box = darkCard();
        TextView title = stabLabel("Figuras");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(14f);
        box.addView(title);
        final int cols = 4;
        LinearLayout row = null;
        for (int i = 0; i < SH_KIND.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row);
            }
            final int kind = SH_KIND[i];
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(2), dp(6), dp(2), dp(4));
            cell.setBackgroundResource(kind == current ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
            ImageView iv = new ImageView(this);
            iv.setImageResource(SH_ICON[i]);
            cell.addView(iv, new LinearLayout.LayoutParams(dp(26), dp(26)));
            TextView tv = new TextView(this);
            tv.setText(SH_NAME[i]);
            tv.setTextColor(0xFFFFFFFF);
            tv.setTextSize(10.5f);
            tv.setSingleLine(true);
            tv.setGravity(Gravity.CENTER);
            cell.addView(tv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            cell.setContentDescription(SH_NAME[i]);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (shapePop != null) shapePop.dismiss();
                    pickShapeKind(kind);
                }
            });
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, dp(58), 1f);
            cl.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(cell, cl);
        }
        // la ultima fila se completa con huecos para que las celdas tengan el mismo ancho
        int rest = (cols - SH_KIND.length % cols) % cols;
        for (int i = 0; i < rest && row != null; i++) {
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, dp(58), 1f);
            cl.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(new View(this), cl);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        int w = Math.min(dp(330), getResources().getDisplayMetrics().widthPixels - dp(16));
        shapePop = showCardPop(sv, box, anchor, w, 0.7f);
    }

    private void pickShapeKind(int kind) {
        int m = canvas.getMode();
        if (kind == SH_FREE) {
            if (m != CanvasView.MODE_PAINT) selectTool(CanvasView.MODE_PAINT);
            canvas.showHud("Libre: dibuja a mano", 1400);
        } else if (kind == SH_CURVE) {
            selectTool(CanvasView.MODE_CURVE);
        } else if (kind == SH_POLY) {
            selectTool(CanvasView.MODE_POLY);
        } else {
            canvas.setShapeType(kind);
            saveShapePrefs();
            if (m != CanvasView.MODE_SHAPE) selectTool(CanvasView.MODE_SHAPE);
            else updateUi();
            canvas.showHud(ShapeGeom.NAMES[kind] + ": " + ShapeGeom.HELP[kind], 2600);
        }
        refreshShapesButton();
    }

    /** Cuadradito con el color; con "actual" muestra el color de abajo. */
    private View colorSwatch(int color) {
        View v = new View(this);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(dp(6));
        g.setColor(color | 0xFF000000);
        g.setStroke(dp(2), 0xFFFFFFFF);
        v.setBackground(g);
        return v;
    }

    private void setSwatch(View v, int color) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(dp(6));
        g.setColor(color | 0xFF000000);
        g.setStroke(dp(2), 0xFFFFFFFF);
        v.setBackground(g);
    }

    /** Fila con texto y un interruptor. */
    private android.widget.Switch switchRow(LinearLayout parent, String text, boolean on, boolean big) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = stabLabel(text);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(big ? 15f : 13f);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(on);
        r.addView(sw);
        parent.addView(r);
        return sw;
    }

    /** Fila "Color: [cuadradito] [Color actual]". */
    private interface ShapeColorAccess {
        int get();
        void set(int c);
        boolean current();
        void setCurrent(boolean b);
    }

    private void shapeColorRow(LinearLayout parent, final String title, final ShapeColorAccess acc, final Runnable changed) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = stabLabel("Color");
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final View sw = colorSwatch(acc.current() ? canvas.getColor() : acc.get());
        r.addView(sw, new LinearLayout.LayoutParams(dp(44), dp(30)));
        final TextView cur = stabSeg("Color actual");
        cur.setPadding(dp(10), 0, dp(10), 0);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30));
        cl.setMargins(dp(8), 0, 0, 0);
        r.addView(cur, cl);
        parent.addView(r);
        final Runnable paint = new Runnable() {
            @Override public void run() {
                cur.setBackgroundResource(acc.current() ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
                setSwatch(sw, acc.current() ? canvas.getColor() : acc.get());
            }
        };
        paint.run();
        cur.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                acc.setCurrent(!acc.current());
                paint.run();
                changed.run();
            }
        });
        sw.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                colorDialog(new ColorPickTarget() {
                    @Override public void onColor(int color) {
                        acc.set(color | 0xFF000000);
                        acc.setCurrent(false);
                        paint.run();
                        changed.run();
                    }
                }, acc.current() ? canvas.getColor() : acc.get(), title);
            }
        });
    }

    /** Segmento de opciones (una elegida). Devuelve el Runnable que lo repinta. */
    private Runnable segRow(LinearLayout parent, String[] names, final int[] value, final int[] ids, final Runnable changed) {
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] tvs = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            tvs[i] = stabSeg(names[i]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            if (i > 0) lp.setMargins(dp(6), 0, 0, 0);
            seg.addView(tvs[i], lp);
        }
        parent.addView(seg);
        final Runnable paint = new Runnable() {
            @Override public void run() {
                for (int i = 0; i < tvs.length; i++)
                    tvs[i].setBackgroundResource(value[0] == ids[i] ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
            }
        };
        for (int i = 0; i < tvs.length; i++) {
            final int id = ids[i];
            tvs[i].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    value[0] = id;
                    paint.run();
                    changed.run();
                }
            });
        }
        paint.run();
        return paint;
    }

    private View panelDivider() {
        View div = new View(this);
        div.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dl.setMargins(0, dp(10), 0, dp(6));
        div.setLayoutParams(dl);
        return div;
    }

    /** Ajustes de figura: contorno, relleno y lo propio de la figura elegida. */
    private void showShapeStylePanel(View anchor) {
        if (shapeStylePop != null && shapeStylePop.isShowing()) { shapeStylePop.dismiss(); return; }
        final ShapeGeom.Style st = canvas.getShapeStyle();
        final int type = canvas.getShapeType();
        final Runnable changed = new Runnable() {
            @Override public void run() {
                canvas.shapeStyleChanged();
                saveShapePrefs();
            }
        };
        LinearLayout box = darkCard();
        seeThrough(box, dp(14));
        TextView title = stabLabel(ShapeGeom.NAMES[type]);
        title.setTextColor(0xFF2EE6A6);
        title.setTextSize(14f);
        box.addView(title);

        // ---- Contorno
        final android.widget.Switch sOn = switchRow(box, "Contorno", st.strokeOn, true);
        final LinearLayout sBox = new LinearLayout(this);
        sBox.setOrientation(LinearLayout.VERTICAL);
        box.addView(sBox);
        shapeColorRow(sBox, "Color del contorno", new ShapeColorAccess() {
            public int get() { return st.strokeColor; }
            public void set(int c) { st.strokeColor = c; }
            public boolean current() { return st.strokeCurrent; }
            public void setCurrent(boolean b) { st.strokeCurrent = b; }
        }, changed);
        final TextView sOpV = stabHead(sBox, "Opacidad");
        stabSlider(sBox, 100, Math.round(st.strokeOp * 100f), new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                sOpV.setText(v + " %");
                if (!user) return;
                st.strokeOp = v / 100f;
                changed.run();
            }
        });
        sOpV.setText(Math.round(st.strokeOp * 100f) + " %");
        final android.widget.Switch sBrush = switchRow(sBox, "Con el pincel actual", st.strokeBrush, false);
        sBrush.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                st.strokeBrush = on;
                changed.run();
            }
        });
        TextView sHint = stabLabel("El grosor es el tamano de la barra de abajo. Con el pincel actual, el borde usa su textura.");
        sHint.setTextSize(11f);
        sHint.setTextColor(0xFF8A8A92);
        sBox.addView(sHint);
        final Runnable enS = new Runnable() {
            @Override public void run() {
                sBox.setAlpha(st.strokeOn ? 1f : 0.35f);
                setEnabledDeep(sBox, st.strokeOn);
            }
        };
        enS.run();
        sOn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                st.strokeOn = on;
                enS.run();
                changed.run();
            }
        });

        // ---- Relleno (la linea y la flecha fina no tienen interior)
        boolean fillable = !(type == ShapeGeom.LINE || (type == ShapeGeom.ARROW && st.thin));
        box.addView(panelDivider());
        final android.widget.Switch fOn = switchRow(box, fillable ? "Relleno" : "Relleno (esta figura no tiene)", st.fillOn, true);
        final LinearLayout fBox = new LinearLayout(this);
        fBox.setOrientation(LinearLayout.VERTICAL);
        box.addView(fBox);
        shapeColorRow(fBox, "Color del relleno", new ShapeColorAccess() {
            public int get() { return st.fillColor; }
            public void set(int c) { st.fillColor = c; }
            public boolean current() { return st.fillCurrent; }
            public void setCurrent(boolean b) { st.fillCurrent = b; }
        }, changed);
        final TextView fOpV = stabHead(fBox, "Opacidad");
        stabSlider(fBox, 100, Math.round(st.fillOp * 100f), new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                fOpV.setText(v + " %");
                if (!user) return;
                st.fillOp = v / 100f;
                changed.run();
            }
        });
        fOpV.setText(Math.round(st.fillOp * 100f) + " %");
        final Runnable enF = new Runnable() {
            @Override public void run() {
                fBox.setAlpha(st.fillOn ? 1f : 0.35f);
                setEnabledDeep(fBox, st.fillOn);
            }
        };
        enF.run();
        fOn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                st.fillOn = on;
                enF.run();
                changed.run();
            }
        });

        // ---- Lo propio de cada figura
        if (type == ShapeGeom.RECT) {
            box.addView(panelDivider());
            final android.widget.Switch sq = switchRow(box, "Cuadrado (1:1)", st.square, false);
            sq.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    st.square = on;
                    changed.run();
                }
            });
        } else if (type == ShapeGeom.POLYGON) {
            box.addView(panelDivider());
            final TextView lv = stabHead(box, "Lados");
            stabSlider(box, 29, st.sides - 3, new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    lv.setText(String.valueOf(v + 3));
                    if (!user) return;
                    st.sides = v + 3;
                    changed.run();
                }
            });
            lv.setText(String.valueOf(st.sides));
        } else if (type == ShapeGeom.RRECT) {
            box.addView(panelDivider());
            final TextView cv = stabHead(box, "Esquinas");
            stabSlider(box, 100, Math.round(st.corner), new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    cv.setText(v + " %");
                    if (!user) return;
                    st.corner = v;
                    changed.run();
                }
            });
            cv.setText(Math.round(st.corner) + " %");
        } else if (type == ShapeGeom.ARROW) {
            box.addView(panelDivider());
            box.addView(stabLabel("Flecha"));
            final int[] thin = {st.thin ? 1 : 0};
            final LinearLayout wBox = new LinearLayout(this);
            final Runnable enW = new Runnable() {
                @Override public void run() {
                    wBox.setAlpha(st.thin ? 0.35f : 1f);
                    setEnabledDeep(wBox, !st.thin);
                }
            };
            segRow(box, new String[]{"Gruesa", "Fina"}, thin, new int[]{0, 1}, new Runnable() {
                @Override public void run() {
                    st.thin = thin[0] == 1;
                    enW.run();
                    changed.run();
                }
            });
            box.addView(stabLabel("Puntas"));
            final int[] heads = {st.heads};
            segRow(box, new String[]{"Al final", "Al inicio", "Las dos"}, heads, new int[]{1, 2, 3}, new Runnable() {
                @Override public void run() {
                    st.heads = heads[0];
                    changed.run();
                }
            });
            wBox.setOrientation(LinearLayout.VERTICAL);
            box.addView(wBox);
            final TextView av = stabHead(wBox, "Ancho de la flecha");
            stabSlider(wBox, 200, Math.round(st.arrowW), new SimpleSeek() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                    int w = Math.max(2, v);
                    av.setText(w + " px");
                    if (!user) return;
                    st.arrowW = w;
                    changed.run();
                }
            });
            av.setText(Math.round(st.arrowW) + " px");
            enW.run();
        }

        // ---- Suavizado
        box.addView(panelDivider());
        final android.widget.Switch sm = switchRow(box, "Bordes suaves (sin dientes)", st.smooth, false);
        sm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                st.smooth = on;
                changed.run();
            }
        });

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.END);
        TextView ok = stabSeg("Listo");
        ok.setBackgroundResource(R.drawable.bg_seg_on);
        ok.setPadding(dp(18), 0, dp(18), 0);
        LinearLayout.LayoutParams okl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        okl.setMargins(0, dp(8), 0, 0);
        btns.addView(ok, okl);
        box.addView(btns);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (shapeStylePop != null) shapeStylePop.dismiss(); }
        });

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        int w = Math.min(dp(320), getResources().getDisplayMetrics().widthPixels - dp(16));
        shapeStylePop = showCardPop(sv, box, anchor, w, 0.62f);
    }

    /**
     * v8.79: arriba hay hasta 7 botones. En pantallas angostas se achican un poco (hasta 34 dp)
     * para que entren todos sin cortarse; en las anchas quedan de 42 dp.
     */
    private void fitTopBar() {
        View tv = findViewById(R.id.topBar);
        if (!(tv instanceof LinearLayout)) return;
        LinearLayout top = (LinearLayout) tv;
        int avail = top.getWidth() - top.getPaddingLeft() - top.getPaddingRight();
        if (avail <= 0) return;
        int n = 0, margins = 0;
        for (int i = 0; i < top.getChildCount(); i++) {
            View v = top.getChildAt(i);
            if (!(v instanceof ImageButton) || v.getVisibility() == View.GONE) continue;
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) v.getLayoutParams();
            n++;
            margins += lp.leftMargin + lp.rightMargin;
        }
        if (n == 0) return;
        int size = Math.max(dp(34), Math.min(dp(42), (avail - margins) / n));
        boolean changed = false;
        for (int i = 0; i < top.getChildCount(); i++) {
            View v = top.getChildAt(i);
            if (!(v instanceof ImageButton)) continue;
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) v.getLayoutParams();
            if (lp.width == size && lp.height == size) continue;
            lp.width = size;
            lp.height = size;
            int pad = Math.round(size * 0.24f);
            v.setPadding(pad, pad, pad, pad);
            v.setLayoutParams(lp);
            changed = true;
        }
        if (changed) measureBars(false);
    }

    // ==================================================================
    // v8.78 ESTABILIZADOR Y PUNTAS: boton propio arriba (verde = activo) y panel compacto.
    // Afecta solo a los trazos nuevos de Pintar y Goma (las puntas solo a Pintar).
    // ==================================================================

    private PopupWindow stabPop;

    /** Lee los ajustes guardados y los pasa al lienzo. */
    private void loadStabPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        canvas.setStabilizerLevel(sp.getInt("stab_level", 0), sp.getBoolean("stab_later", false));
        canvas.setForcedTaper(sp.getBoolean("taper_on", false), sp.getInt("taper_s", 30), sp.getInt("taper_e", 30),
                sp.getInt("taper_shape", com.pacco.animecut.core.StrokeTaper.SOFT));
        refreshStabButton();
    }

    private void saveStabPrefs(int level, boolean later, boolean taperOn, int ts, int te, int shape) {
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putInt("stab_level", level).putBoolean("stab_later", later)
                .putBoolean("taper_on", taperOn).putInt("taper_s", ts).putInt("taper_e", te)
                .putInt("taper_shape", shape).apply();
        canvas.setStabilizerLevel(level, later);
        canvas.setForcedTaper(taperOn, ts, te, shape);
        refreshStabButton();
    }

    /** El icono se pone verde si hay estabilizador o puntas. */
    private void refreshStabButton() {
        View v = findViewById(R.id.btnStab);
        if (!(v instanceof ImageButton)) return;
        boolean on = canvas.getStabilizerLevel() > 0 || canvas.isForcedTaper();
        ((ImageButton) v).setColorFilter(on ? 0xFF2EE6A6 : 0xFFFFFFFF, android.graphics.PorterDuff.Mode.SRC_IN);
    }

    private void showStabPanel() {
        if (stabPop != null && stabPop.isShowing()) { stabPop.dismiss(); return; }
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        final int[] level = {sp.getInt("stab_level", 0)};
        final boolean[] later = {sp.getBoolean("stab_later", false)};
        final boolean[] tOn = {sp.getBoolean("taper_on", false)};
        final int[] ts = {sp.getInt("taper_s", 30)}, te = {sp.getInt("taper_e", 30)};
        final int[] shape = {sp.getInt("taper_shape", com.pacco.animecut.core.StrokeTaper.SOFT)};

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(10));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xF0222228);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);

        final StrokeSampleView sample = new StrokeSampleView(this);
        final Runnable apply = new Runnable() {
            @Override public void run() {
                saveStabPrefs(level[0], later[0], tOn[0], ts[0], te[0], shape[0]);
                sample.set(level[0], tOn[0], ts[0], te[0], shape[0]);
            }
        };

        // ---- Estabilizador 0..10
        final TextView stabVal = stabHead(box, "Estabilizador");
        final SeekBar stabBar = stabSlider(box, 10, level[0], new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                level[0] = v;
                stabVal.setText(v == 0 ? "OFF" : String.valueOf(v));
                if (user) apply.run();
            }
        });
        stabVal.setText(level[0] == 0 ? "OFF" : String.valueOf(level[0]));

        // ---- Metodo
        TextView mt = stabLabel("Método");
        box.addView(mt);
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        final TextView live = stabSeg("En vivo"), after = stabSeg("Al soltar");
        seg.addView(live, new LinearLayout.LayoutParams(0, dp(34), 1f));
        LinearLayout.LayoutParams lpA = new LinearLayout.LayoutParams(0, dp(34), 1f);
        lpA.setMargins(dp(6), 0, 0, 0);
        seg.addView(after, lpA);
        box.addView(seg);
        final Runnable paintSeg = new Runnable() {
            @Override public void run() {
                live.setBackgroundResource(!later[0] ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
                after.setBackgroundResource(later[0] ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
            }
        };
        paintSeg.run();
        live.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { later[0] = false; paintSeg.run(); apply.run(); }
        });
        after.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { later[0] = true; paintSeg.run(); apply.run(); }
        });
        TextView hint = stabLabel("En vivo corrige mientras dibujas. Al soltar corrige todo el trazo de una vez, sin retraso.");
        hint.setTextSize(11f);
        hint.setTextColor(0xFF8A8A92);
        box.addView(hint);

        // ---- Puntas
        View div = new View(this);
        div.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dl.setMargins(0, dp(10), 0, dp(6));
        box.addView(div, dl);
        LinearLayout tRow = new LinearLayout(this);
        tRow.setOrientation(LinearLayout.HORIZONTAL);
        tRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView tl = stabLabel("Puntas finas (forzar)");
        tl.setTextColor(0xFFFFFFFF);
        tl.setTextSize(14f);
        tRow.addView(tl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(tOn[0]);
        tRow.addView(sw);
        box.addView(tRow);

        final LinearLayout tBox = new LinearLayout(this);
        tBox.setOrientation(LinearLayout.VERTICAL);
        box.addView(tBox);
        final TextView sVal = stabHead(tBox, "Inicio");
        stabSlider(tBox, 100, ts[0], new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                ts[0] = v;
                sVal.setText(v + " %");
                if (user) apply.run();
            }
        });
        sVal.setText(ts[0] + " %");
        final TextView eVal = stabHead(tBox, "Final");
        stabSlider(tBox, 100, te[0], new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                te[0] = v;
                eVal.setText(v + " %");
                if (user) apply.run();
            }
        });
        eVal.setText(te[0] + " %");
        tBox.addView(stabLabel("Forma"));
        LinearLayout seg2 = new LinearLayout(this);
        seg2.setOrientation(LinearLayout.HORIZONTAL);
        final TextView soft = stabSeg("Suave"), lin = stabSeg("Lineal");
        seg2.addView(soft, new LinearLayout.LayoutParams(0, dp(34), 1f));
        LinearLayout.LayoutParams lpL = new LinearLayout.LayoutParams(0, dp(34), 1f);
        lpL.setMargins(dp(6), 0, 0, 0);
        seg2.addView(lin, lpL);
        tBox.addView(seg2);
        final Runnable paintSeg2 = new Runnable() {
            @Override public void run() {
                soft.setBackgroundResource(shape[0] == com.pacco.animecut.core.StrokeTaper.SOFT ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
                lin.setBackgroundResource(shape[0] == com.pacco.animecut.core.StrokeTaper.LINEAR ? R.drawable.bg_seg_on : R.drawable.bg_seg_off);
            }
        };
        paintSeg2.run();
        soft.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { shape[0] = com.pacco.animecut.core.StrokeTaper.SOFT; paintSeg2.run(); apply.run(); }
        });
        lin.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { shape[0] = com.pacco.animecut.core.StrokeTaper.LINEAR; paintSeg2.run(); apply.run(); }
        });
        final Runnable enableT = new Runnable() {
            @Override public void run() {
                tBox.setAlpha(tOn[0] ? 1f : 0.35f);
                setEnabledDeep(tBox, tOn[0]);
            }
        };
        enableT.run();
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                tOn[0] = on;
                enableT.run();
                apply.run();
            }
        });

        // ---- Muestra (dibujada una vez por cambio, sin costo continuo)
        sample.set(level[0], tOn[0], ts[0], te[0], shape[0]);
        LinearLayout.LayoutParams spl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        spl.setMargins(0, dp(8), 0, dp(4));
        box.addView(sample, spl);

        // ---- Restablecer / Listo
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.END);
        TextView reset = stabSeg("Restablecer");
        reset.setBackgroundResource(R.drawable.bg_seg_off);
        TextView ok = stabSeg("Listo");
        ok.setBackgroundResource(R.drawable.bg_seg_on);
        btns.addView(reset, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)));
        LinearLayout.LayoutParams okl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        okl.setMargins(dp(8), 0, 0, 0);
        btns.addView(ok, okl);
        box.addView(btns);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                level[0] = 0; later[0] = false; tOn[0] = false; ts[0] = 30; te[0] = 30;
                shape[0] = com.pacco.animecut.core.StrokeTaper.SOFT;
                stabBar.setProgress(0);
                sw.setChecked(false);
                paintSeg.run();
                paintSeg2.run();
                apply.run();
                if (stabPop != null) stabPop.dismiss();
                canvas.showHud("Estabilizador y puntas apagados", 1400);
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (stabPop != null) stabPop.dismiss(); }
        });

        int w = Math.min(dp(320), getResources().getDisplayMetrics().widthPixels - dp(16));
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.62f);
        box.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int h = Math.min(maxH, box.getMeasuredHeight());
        stabPop = new PopupWindow(sv, w, h, true);
        stabPop.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
        stabPop.setOutsideTouchable(true);
        View anchor = findViewById(R.id.btnStab);
        try {
            stabPop.showAsDropDown(anchor, -w / 2 + anchor.getWidth() / 2, dp(4));
        } catch (Throwable t) {
            stabPop.showAtLocation(getWindow().getDecorView(), Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, dp(70));
        }
    }

    private TextView stabLabel(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFC8C8CE);
        t.setTextSize(12f);
        t.setPadding(0, dp(6), 0, dp(3));
        return t;
    }

    /** Titulo con su valor a la derecha; devuelve el texto del valor. */
    private TextView stabHead(LinearLayout parent, String name) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView n = stabLabel(name);
        n.setTextColor(0xFFFFFFFF);
        n.setTextSize(14f);
        row.addView(n, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = stabLabel("");
        v.setTextColor(0xFF2EE6A6);
        v.setTextSize(14f);
        row.addView(v);
        parent.addView(row);
        return v;
    }

    /** Barra con botones - y + a los lados. */
    private SeekBar stabSlider(LinearLayout parent, int max, int value, SimpleSeek listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(max);
        bar.setProgress(Math.max(0, Math.min(max, value)));
        bar.setOnSeekBarChangeListener(listener);
        TextView minus = stabSeg("−"), plus = stabSeg("+");
        minus.setBackgroundResource(R.drawable.bg_round);
        plus.setBackgroundResource(R.drawable.bg_round);
        row.addView(minus, new LinearLayout.LayoutParams(dp(34), dp(34)));
        row.addView(bar, new LinearLayout.LayoutParams(0, dp(34), 1f));
        row.addView(plus, new LinearLayout.LayoutParams(dp(34), dp(34)));
        final SimpleSeek l = listener;
        minus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                bar.setProgress(Math.max(0, bar.getProgress() - 1));
                l.onProgressChanged(bar, bar.getProgress(), true);
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                bar.setProgress(Math.min(bar.getMax(), bar.getProgress() + 1));
                l.onProgressChanged(bar, bar.getProgress(), true);
            }
        });
        parent.addView(row);
        return bar;
    }

    private TextView stabSeg(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(13f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), 0, dp(12), 0);
        t.setBackgroundResource(R.drawable.bg_seg_off);
        return t;
    }

    private static void setEnabledDeep(View v, boolean on) {
        v.setEnabled(on);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) setEnabledDeep(g.getChildAt(i), on);
        }
    }

    /** Muestra chica de como queda un trazo con los ajustes (se dibuja solo al cambiar algo). */
    private static final class StrokeSampleView extends View {
        private int level, ts, te, shape;
        private boolean tOn;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        StrokeSampleView(android.content.Context c) {
            super(c);
            p.setColor(0xFFFFFFFF);
        }

        void set(int level, boolean tOn, int ts, int te, int shape) {
            this.level = level; this.tOn = tOn; this.ts = ts; this.te = te; this.shape = shape;
            invalidate();
        }

        @Override protected void onDraw(android.graphics.Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float r = h * 0.11f;
            int n = 140;
            // largo aproximado de la curva para las puntas
            float[] xs = new float[n + 1], ys = new float[n + 1], arc = new float[n + 1];
            for (int i = 0; i <= n; i++) {
                float t = i / (float) n;
                xs[i] = w * 0.06f + t * w * 0.88f;
                // temblor que se calma con el estabilizador (solo ilustrativo)
                float wob = (float) Math.sin(t * 61f) * h * 0.035f * (1f - level / 10f);
                ys[i] = h * 0.5f - (float) Math.sin(t * Math.PI * 2) * h * 0.26f + wob;
                if (i > 0) arc[i] = arc[i - 1] + (float) Math.hypot(xs[i] - xs[i - 1], ys[i] - ys[i - 1]);
            }
            float total = arc[n];
            for (int i = 0; i <= n; i++) {
                float f = tOn ? com.pacco.animecut.core.StrokeTaper.factor(arc[i], total, ts, te, shape, r) : 1f;
                c.drawCircle(xs[i], ys[i], Math.max(0.6f, r * f), p);
            }
        }
    }

    private void expandDialog() {
        if (!needProject()) return;
        final String[] items = {"+0.5 px", "+1.0 px", "+1.5 px", "+2.0 px", "-0.5 px", "-1.0 px"};
        final float[] vals = {0.5f, 1f, 1.5f, 2f, -0.5f, -1f};
        new SheetBuilder(this)
                .setTitle("Expandir o contraer con decimales")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.expandSelection(vals[i]);
                    }
                })
                .show();
    }

    /** Quita los puntitos que deja la trama del manga dentro de la seleccion. */
    private void closeHolesDialog() {
        if (!needProject()) return;
        final String[] items = {"Puntos chicos (1 px)", "Medianos (2 px)", "Grandes (3 px)", "Muy grandes (5 px)"};
        final int[] vals = {1, 2, 3, 5};
        new SheetBuilder(this)
                .setTitle("Cerrar huecos de la trama")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(4, vals[i]);
                    }
                })
                .show();
    }

    private void hardnessDialog() {
        final String[] items = {"Muy suave 20%", "Suave 40%", "Media 70%", "Dura 100% (color plano, borde limpio)"};
        final float[] vals = {0.2f, 0.4f, 0.7f, 1f};
        new SheetBuilder(this)
                .setTitle("Dureza del pincel")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setHardness(vals[i]);
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putFloat("brush_hardness_v827", vals[i]).apply();
                        toast("Dureza " + items[i]);
                    }
                })
                .show();
    }

    /** Agregar espacio transparente al lienzo (por ejemplo arriba, para enderezar un personaje). */
    private void enlargeCanvasDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(8), dp(18), dp(4));
        final CheckBox top = new CheckBox(this), bottom = new CheckBox(this), left = new CheckBox(this), right = new CheckBox(this);
        top.setText("Arriba"); bottom.setText("Abajo"); left.setText("Izquierda"); right.setText("Derecha");
        top.setChecked(true);
        for (CheckBox c : new CheckBox[]{top, bottom, left, right}) { c.setTextColor(0xFFFFFFFF); root.addView(c); }
        final TextView val = optLabel("");
        root.addView(val);
        final SeekBar amt = new SeekBar(this);
        amt.setMax(45);
        amt.setProgress(10);
        final Runnable upd = new Runnable() {
            public void run() {
                int pct = amt.getProgress() + 5;
                val.setText("Agregar " + pct + "%  (" + Math.round(p.h * pct / 100f) + " px arriba/abajo, "
                        + Math.round(p.w * pct / 100f) + " px a los lados)");
            }
        };
        amt.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { upd.run(); }
        });
        upd.run();
        root.addView(amt);
        TextView note = new TextView(this);
        note.setText("Las capas no se achican: solo se agrega espacio transparente. Deshacer lo devuelve.");
        note.setTextColor(0xFFB8B8C0);
        note.setTextSize(12f);
        note.setPadding(0, dp(6), 0, 0);
        root.addView(note);
        new SheetBuilder(this)
                .setTitle("Ampliar lienzo (" + p.w + " x " + p.h + ")")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Ampliar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        int pct = amt.getProgress() + 5;
                        int v = Math.round(p.h * pct / 100f), hz = Math.round(p.w * pct / 100f);
                        canvas.enlargeCanvas(left.isChecked() ? hz : 0, top.isChecked() ? v : 0,
                                right.isChecked() ? hz : 0, bottom.isChecked() ? v : 0);
                        markDirty();
                    }
                }).show();
    }

    private void rotateDialog() {
        if (!needProject()) return;
        final String[] items = {"Girar a la derecha", "Girar a la izquierda",
                "Voltear horizontal", "Voltear vertical"};
        new SheetBuilder(this)
                .setTitle("Girar imagen")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.transform(i);
                    }
                })
                .show();
    }

    private void lineArtDialog() {
        if (!needProject()) return;
        if (canvas.isUseBarrier() && canvas.getProject().barrier != null) {
            new SheetBuilder(this)
                    .setTitle("Line art")
                    .setMessage("La barrera esta activa. La varita y el balde se detienen en las lineas.")
                    .setPositiveButton("Desactivar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.setUseBarrier(false);
                            updateUi();
                        }
                    })
                    .setNegativeButton("Recalcular", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            thresholdDialog();
                        }
                    })
                    .show();
            return;
        }
        thresholdDialog();
    }

    private void thresholdDialog() {
        final String[] items = {"Lineas muy oscuras (60)", "Oscuras (90)", "Normal (120)", "Tenues (160)"};
        final int[] vals = {60, 90, 120, 160};
        new SheetBuilder(this)
                .setTitle("Que tan oscura es la linea")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int i) {
                        final String[] gaps = {"Sin cerrar huecos", "Cerrar 1 px", "Cerrar 2 px", "Cerrar 3 px"};
                        new SheetBuilder(MainActivity.this)
                                .setTitle("Cerrar huecos de la linea")
                                .setItems(gaps, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int g) {
                                        canvas.buildBarrier(vals[i], g);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    private Bitmap decodeReference(Uri uri) {
        try {
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            InputStream is0 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is0, null, b);
            if (is0 != null) is0.close();
            int ow = b.outWidth, oh = b.outHeight;
            if (ow <= 0 || oh <= 0) return null;
            int sample = 1;
            int maxSide = Math.max(ow, oh);
            while (maxSide / sample > 2800) sample *= 2;
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o.inMutable = false;
            o.inSampleSize = Math.max(1, sample);
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            return bmp;
        } catch (Throwable t) {
            toast("No se pudo abrir la referencia");
            return null;
        }
    }

    private void clearColorReference(boolean showToast) {
        pendingColorRefTarget = null;
        if (colorRefWindow != null) { try { colorRefWindow.dismiss(); } catch (Throwable ignored) {} }
        colorRefWindow = null; colorRefView = null;
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) colorRefBitmap.recycle();
        colorRefBitmap = null;
        refSampleView = null;
        refSampleText = null;
        refPaletteStrip = null;
        // v8.26: si estaba guardada con la obra, se quita de la obra (la foto del telefono no se toca;
        // la exportacion nunca la incluyo)
        Project p = canvas.getProject();
        if (p != null && p.refImagePng != null) {
            p.refImagePng = null;
            markDirty();
        }
        if (showToast) toast("Referencia de color quitada");
    }

    private void requestColorReference(ColorPickTarget target) {
        if (colorRefBitmap == null || colorRefBitmap.isRecycled()) {
            pendingColorRefTarget = target;
            pickColorRef.launch(new String[]{"image/*"});
        } else {
            showReferenceColorPanel(target);
        }
    }

    private int[] extractReferencePalette(Bitmap bmp, int count) {
        if (bmp == null) return new int[0];
        java.util.LinkedHashMap<Integer, Integer> hist = new java.util.LinkedHashMap<Integer, Integer>();
        int w = bmp.getWidth(), h = bmp.getHeight();
        int sx = Math.max(1, w / 80), sy = Math.max(1, h / 80);
        for (int y = 0; y < h; y += sy) {
            for (int x = 0; x < w; x += sx) {
                int c = bmp.getPixel(x, y);
                if (((c >>> 24) & 0xFF) < 20) continue;
                int r = (Color.red(c) >> 4) & 0xF;
                int g = (Color.green(c) >> 4) & 0xF;
                int b = (Color.blue(c) >> 4) & 0xF;
                int key = (r << 8) | (g << 4) | b;
                Integer old = hist.get(key);
                hist.put(key, old == null ? 1 : old + 1);
            }
        }
        java.util.List<java.util.Map.Entry<Integer, Integer>> list = new java.util.ArrayList<java.util.Map.Entry<Integer, Integer>>(hist.entrySet());
        java.util.Collections.sort(list, new java.util.Comparator<java.util.Map.Entry<Integer, Integer>>() {
            @Override
            public int compare(java.util.Map.Entry<Integer, Integer> a, java.util.Map.Entry<Integer, Integer> b) {
                return b.getValue() - a.getValue();
            }
        });
        java.util.ArrayList<Integer> out = new java.util.ArrayList<Integer>();
        for (java.util.Map.Entry<Integer, Integer> e : list) {
            int key = e.getKey();
            int r = ((key >> 8) & 0xF) * 17;
            int g = ((key >> 4) & 0xF) * 17;
            int bl = (key & 0xF) * 17;
            int c = Color.rgb(r, g, bl);
            boolean close = false;
            for (int i = 0; i < out.size(); i++) {
                int oc = out.get(i);
                int dr = Color.red(oc) - r, dg = Color.green(oc) - g, db = Color.blue(oc) - bl;
                if (dr * dr + dg * dg + db * db < 28 * 28) {
                    close = true;
                    break;
                }
            }
            if (!close) out.add(c);
            if (out.size() >= count) break;
        }
        int[] arr = new int[out.size()];
        for (int i = 0; i < out.size(); i++) arr[i] = out.get(i);
        return arr;
    }

    private Integer colorFromImageTouch(ImageView iv, Bitmap bmp, MotionEvent e) {
        if (bmp == null || iv.getDrawable() == null) return null;
        float[] values = new float[9];
        Matrix m = iv.getImageMatrix();
        m.getValues(values);
        float scaleX = values[Matrix.MSCALE_X];
        float scaleY = values[Matrix.MSCALE_Y];
        float transX = values[Matrix.MTRANS_X];
        float transY = values[Matrix.MTRANS_Y];
        if (scaleX == 0f || scaleY == 0f) return null;
        float bx = (e.getX() - transX) / scaleX;
        float by = (e.getY() - transY) / scaleY;
        if (bx < 0 || by < 0 || bx >= bmp.getWidth() || by >= bmp.getHeight()) return null;
        return bmp.getPixel(Math.max(0, Math.min(bmp.getWidth() - 1, Math.round(bx))),
                Math.max(0, Math.min(bmp.getHeight() - 1, Math.round(by))));
    }

    /** Muestra de la ventana de referencia (todavia no se usa hasta "Usar este color"). */
    private int refSample = 0;
    private boolean refFolded;
    private View refSampleView;
    private TextView refSampleText;
    private LinearLayout refPaletteStrip;

    private void setRefSample(int c) {
        refSample = c;
        if (refSampleView != null) refSampleView.setBackgroundColor(c | 0xFF000000);
        if (refSampleText != null) refSampleText.setText(String.format(Locale.US, "#%06X", c & 0xFFFFFF));
    }

    /** Muestras de la obra como cuadritos: tocar = usar ese color. */
    private void fillRefPalette(final ColorPickTarget target) {
        if (refPaletteStrip == null) return;
        refPaletteStrip.removeAllViews();
        Project p = canvas.getProject();
        if (p == null) return;
        for (final Project.Swatch sw : p.swatches) {
            View v = new View(this);
            v.setBackgroundColor(sw.color | 0xFF000000);
            v.setContentDescription(sw.name);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(26), dp(26));
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            v.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View vv) {
                    setRefSample(sw.color);
                    target.onColor(sw.color);
                    toast("\"" + sw.name + "\" en uso");
                }
            });
            refPaletteStrip.addView(v, lp);
        }
    }

    private void showReferenceColorPanel(final ColorPickTarget target) {
        if (colorRefBitmap == null || colorRefBitmap.isRecycled()) return;
        // v8.39: con la referencia arriba, el panel de Capas se baja solo (deja ver el lienzo)
        if (layersOpen()) closeLayers();
        if (colorRefWindow != null && colorRefWindow.isShowing()) {
            if (colorRefView != null) {
                colorRefView.setBitmap(colorRefBitmap);
                colorRefView.setListener(new ReferenceImageView.Listener() {
                    @Override public void onColor(int color) { setRefSample(color); }
                });
            }
            refUseTarget = target;
            fillRefPalette(target);
            return;
        }
        refUseTarget = target;

        final FrameLayout shell = new FrameLayout(this);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(4), dp(4), dp(4), dp(4));
        root.setBackgroundResource(R.drawable.bg_ref_panel);
        shell.addView(root, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Referencia");
        title.setTextColor(0xFFF4F4F6);
        title.setTextSize(14f);
        title.setPadding(dp(8), 0, dp(4), 0);
        head.addView(title, new LinearLayout.LayoutParams(0, dp(34), 1f));

        final ImageButton fold = refIconButton(R.drawable.ic_up, "Plegar / desplegar");
        ImageButton more = refIconButton(R.drawable.ic_menu, "Mas: cambiar, quitar, paleta, guardar con la obra");
        ImageButton close = refIconButton(R.drawable.ic_close, "Cerrar referencia");
        head.addView(fold); head.addView(more); head.addView(close);
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));

        colorRefView = new ReferenceImageView(this);
        colorRefView.setBitmap(colorRefBitmap);
        colorRefView.setAverage3(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("ref_avg3", true));
        colorRefView.setListener(new ReferenceImageView.Listener() {
            @Override public void onColor(int color) { setRefSample(color); }
        });
        final LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(colorRefView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Pie: muestra + Usar + Guardar + Ajustar + 3x3
        LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(0, dp(3), 0, 0);
        refSampleView = new View(this);
        foot.addView(refSampleView, new LinearLayout.LayoutParams(dp(28), dp(28)));
        refSampleText = new TextView(this);
        refSampleText.setTextColor(0xFFE0E0E0);
        refSampleText.setTextSize(10f);
        refSampleText.setPadding(dp(3), 0, dp(3), 0);
        foot.addView(refSampleText);
        TextView use = smallTextButton("Usar");
        TextView save = smallTextButton("Guardar");
        TextView adj = smallTextButton("Ajustar");
        final TextView avg = smallTextButton("");
        foot.addView(use); foot.addView(save); foot.addView(adj); foot.addView(avg);
        android.widget.HorizontalScrollView footScroll = new android.widget.HorizontalScrollView(this);
        footScroll.addView(foot);
        body.addView(footScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        refPaletteStrip = new LinearLayout(this);
        refPaletteStrip.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView palScroll = new android.widget.HorizontalScrollView(this);
        palScroll.addView(refPaletteStrip);
        body.addView(palScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setRefSample(refSample != 0 ? refSample : canvas.getColor());
        fillRefPalette(target);

        final Runnable avgLabel = new Runnable() {
            @Override public void run() { avg.setText(colorRefView.isAverage3() ? "3x3: SI" : "3x3: NO"); }
        };
        avgLabel.run();
        use.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (refUseTarget != null) refUseTarget.onColor(refSample | 0xFF000000);
                toast(String.format(Locale.US, "Color #%06X listo para pincel y balde", refSample & 0xFFFFFF));
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveSwatchDialog(refSample, new Runnable() {
                    @Override public void run() { fillRefPalette(refUseTarget != null ? refUseTarget : target); }
                });
            }
        });
        adj.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                sampleAdjustDialog(refSample, new ColorPickTarget() {
                    @Override public void onColor(int c) { setRefSample(c); }
                });
            }
        });
        avg.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                colorRefView.setAverage3(!colorRefView.isAverage3());
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("ref_avg3", colorRefView.isAverage3()).apply();
                avgLabel.run();
            }
        });

        // Tirador pequeno: solo aparece en la esquina y no tapa la imagen.
        final ImageView resize = new ImageView(this);
        resize.setImageResource(R.drawable.ic_resize_ref);
        resize.setPadding(dp(4), dp(4), dp(4), dp(4));
        resize.setBackgroundResource(R.drawable.bg_ref_handle);
        FrameLayout.LayoutParams rh = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.RIGHT | Gravity.BOTTOM);
        rh.setMargins(0, 0, dp(4), dp(4));
        shell.addView(resize, rh);

        float density = getResources().getDisplayMetrics().density;
        int swDp = Math.round(getResources().getDisplayMetrics().widthPixels / density);
        int shDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        colorRefW = Math.max(200, Math.min(colorRefW, Math.max(200, swDp - 8)));
        colorRefH = Math.max(230, Math.min(colorRefH, Math.max(230, shDp - 8)));
        refFolded = false;
        colorRefWindow = new PopupWindow(shell, dp(colorRefW), dp(colorRefH), false);
        colorRefWindow.setOutsideTouchable(false);
        colorRefWindow.setClippingEnabled(true);
        colorRefWindow.setElevation(dp(8));
        colorRefWindow.showAtLocation(findViewById(android.R.id.content), Gravity.TOP | Gravity.START, colorRefX, colorRefY);

        fold.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (colorRefWindow == null) return;
                refFolded = !refFolded;
                body.setVisibility(refFolded ? View.GONE : View.VISIBLE);
                resize.setVisibility(refFolded ? View.GONE : View.VISIBLE);
                fold.setImageResource(refFolded ? R.drawable.ic_down : R.drawable.ic_up);
                colorRefWindow.update(colorRefX, colorRefY, dp(colorRefW), refFolded ? dp(46) : dp(colorRefH));
            }
        });

        final float[] drag = new float[4];
        head.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (colorRefWindow == null) return false;
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    drag[0] = e.getRawX(); drag[1] = e.getRawY(); drag[2] = colorRefX; drag[3] = colorRefY; return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    int sw = getResources().getDisplayMetrics().widthPixels;
                    int sh = getResources().getDisplayMetrics().heightPixels;
                    colorRefX = Math.max(0, Math.min(sw - dp(70), Math.round(drag[2] + e.getRawX() - drag[0])));
                    colorRefY = Math.max(0, Math.min(sh - dp(70), Math.round(drag[3] + e.getRawY() - drag[1])));
                    colorRefWindow.update(colorRefX, colorRefY, -1, -1); return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("ref_x", colorRefX).putInt("ref_y", colorRefY).apply();
                    return true;
                }
                return false;
            }
        });

        final float[] size = new float[4];
        resize.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (colorRefWindow == null) return false;
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    size[0] = e.getRawX(); size[1] = e.getRawY(); size[2] = colorRefW; size[3] = colorRefH; return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    float d = getResources().getDisplayMetrics().density;
                    int sw = Math.round(getResources().getDisplayMetrics().widthPixels / d);
                    int sh = Math.round(getResources().getDisplayMetrics().heightPixels / d);
                    int dx = Math.round((e.getRawX() - size[0]) / d);
                    int dy = Math.round((e.getRawY() - size[1]) / d);
                    colorRefW = Math.max(200, Math.min(sw - Math.round(colorRefX / d) - 6, Math.round(size[2]) + dx));
                    colorRefH = Math.max(230, Math.min(sh - Math.round(colorRefY / d) - 6, Math.round(size[3]) + dy));
                    colorRefWindow.update(colorRefX, colorRefY, dp(colorRefW), dp(colorRefH));
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("ref_w", colorRefW).putInt("ref_h", colorRefH).apply();
                    return true;
                }
                return false;
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final Project p = canvas.getProject();
                final boolean keep = p != null && p.refImagePng != null;
                final String[] items = {"Cambiar imagen", "Volver a encuadrar", "Paleta automatica (sugerencias)",
                        keep ? "Guardar copia reducida con la obra: SI" : "Guardar copia reducida con la obra: NO",
                        "Quitar referencia (no borra la foto del telefono)"};
                new SheetBuilder(MainActivity.this)
                        .setTitle("Referencia de colores")
                        .setItems(items, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int i) {
                                if (i == 0) { pendingColorRefTarget = refUseTarget; pickColorRef.launch(new String[]{"image/*"}); }
                                else if (i == 1) colorRefView.refit();
                                else if (i == 2) autoPaletteDialog();
                                else if (i == 3) setKeepRefInProject(!keep);
                                else clearColorReference(true);
                            }
                        })
                        .show();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (colorRefWindow != null) colorRefWindow.dismiss(); colorRefWindow = null; colorRefView = null; }
        });
    }

    /** A donde va el color al pulsar "Usar" (pincel/balde, o el dialogo de Color). */
    private ColorPickTarget refUseTarget;

    private ImageButton refIconButton(int icon, String desc) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(icon);
        b.setColorFilter(0xFFF1F1F3);
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setContentDescription(desc);
        b.setPadding(dp(7), dp(7), dp(7), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
        lp.setMargins(dp(1), 0, dp(1), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView smallTextButton(String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(0xFFFFFFFF); v.setTextSize(12f); v.setGravity(Gravity.CENTER);
        v.setPadding(dp(7), 0, dp(7), 0);
        v.setBackgroundResource(R.drawable.bg_tool);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.setMargins(dp(2), 0, dp(2), 0); v.setLayoutParams(lp);
        return v;
    }

    /**
     * v8.33: selector de color profesional y compacto:
     *  anterior | actual (tocar anterior vuelve) - aro de tono + CUADRADO S/V (llega a blanco y
     *  negro) - blanco, grises y negro a un toque - recientes - paleta de la obra y global (+ guarda)
     *  - HEX y barras RGB o HSV - mezclar dos colores con proporcion - referencia: tomar color o
     *  sacar su paleta (la referencia no se exporta) - opacidad - Gotero con lupa.
     */
    /** v8.39: colores basicos fijos del selector (2 filas de 9). */
    private static final int[] BASIC_COLORS = {
            0xFFFFFFFF, 0xFFBDBDBD, 0xFF757575, 0xFF000000, 0xFFFFE0CC, 0xFFF2C29B, 0xFF8D5A3B, 0xFFE53935, 0xFFFF8F1F,
            0xFFFFE135, 0xFF43A047, 0xFF26C6DA, 0xFF1E88E5, 0xFF1A237E, 0xFF8E24AA, 0xFFEC407A, 0xFFF8BBD0, 0xFF8B1E3F
    };

    private void colorDialog() {
        colorDialog(null, 0, null);
    }

    /**
     * v8.40: el mismo selector, pero el color elegido va a 'target' (por ejemplo el tono de
     * sombra de Color por zonas) en vez de al pincel. initial = color con que abre.
     */
    private void colorDialog(final ColorPickTarget target, int initial, String title) {
        final int previous = (target != null ? initial : canvas.getColor()) | 0xFF000000;
        final int[] chosen = {previous};
        final boolean[] syncing = {false};
        final boolean[] hsvMode = {getSharedPreferences("pz", MODE_PRIVATE).getBoolean("color_hsv", true)};

        ScrollView scroll = new ScrollView(this);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(8), dp(12), dp(8));
        scroll.addView(root);

        // anterior | actual
        LinearLayout previews = new LinearLayout(this);
        previews.setOrientation(LinearLayout.HORIZONTAL);
        final TextView oldPreview = new TextView(this);
        final TextView newPreview = new TextView(this);
        oldPreview.setText("Anterior"); newPreview.setText("Actual");
        oldPreview.setGravity(android.view.Gravity.CENTER); newPreview.setGravity(android.view.Gravity.CENTER);
        oldPreview.setTextColor(contrastText(previous)); newPreview.setTextColor(contrastText(previous));
        oldPreview.setBackgroundColor(previous); newPreview.setBackgroundColor(previous);
        previews.addView(oldPreview, new LinearLayout.LayoutParams(0, dp(40), 1f));
        previews.addView(newPreview, new LinearLayout.LayoutParams(0, dp(40), 1f));
        // v8.52 como Ibis: un boton cambia entre la RUEDA y la PALETA (Mis colores + Recientes)
        final android.content.SharedPreferences cps0 = getSharedPreferences("pz", MODE_PRIVATE);
        final int[] page = {cps0.getInt("color_page", 0)};
        final ImageButton pageBtn = new ImageButton(this);
        pageBtn.setBackgroundResource(R.drawable.bg_tool);
        pageBtn.setPadding(dp(8), dp(8), dp(8), dp(8));
        pageBtn.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(dp(44), dp(40));
        pbLp.setMargins(dp(6), 0, 0, 0);
        previews.addView(pageBtn, pbLp);
        root.addView(previews);
        seedPaletteOnce();

        final LinearLayout pageWheel = new LinearLayout(this);
        pageWheel.setOrientation(LinearLayout.VERTICAL);
        final LinearLayout pagePal = new LinearLayout(this);
        pagePal.setOrientation(LinearLayout.VERTICAL);
        root.addView(pageWheel);
        root.addView(pagePal);
        pagePal.addView(sectionTitle("Mis colores  (+ guarda el actual · mantener pulsado: quitar)"));
        final LinearLayout pal = new LinearLayout(this);
        pal.setOrientation(LinearLayout.VERTICAL);
        pagePal.addView(pal);
        pagePal.addView(sectionTitle("Recientes"));
        final LinearLayout recent = new LinearLayout(this);
        recent.setOrientation(LinearLayout.VERTICAL);
        pagePal.addView(recent);

        final ColorPickerView picker = new ColorPickerView(this);
        picker.setColor(previous);
        LinearLayout.LayoutParams pkLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230));
        pkLp.setMargins(0, dp(6), 0, dp(2));
        pageWheel.addView(picker, pkLp);

        final SeekBar s1 = new SeekBar(this), s2 = new SeekBar(this), s3 = new SeekBar(this), sa = new SeekBar(this);
        final TextView v1 = new TextView(this), v2 = new TextView(this), v3 = new TextView(this), va = new TextView(this);
        sa.setMax(100);
        final Runnable[] fromSliders = new Runnable[1];
        final TextView[] lab = new TextView[3];
        lab[0] = addColorChannel2(pageWheel, "R", s1, v1, fromSliders);
        lab[1] = addColorChannel2(pageWheel, "G", s2, v2, fromSliders);
        lab[2] = addColorChannel2(pageWheel, "B", s3, v3, fromSliders);
        addColorChannel(root, "Opacidad", sa, va);
        final Runnable showPage = new Runnable() {
            @Override public void run() {
                // v8.55c: la paleta ocupa el MISMO alto que la rueda: la ventana no salta ni se mueve
                // al cambiar, y aparece con un fundido corto (fluido, como Ibis)
                int hw = pageWheel.getHeight();
                if (hw > 0) pagePal.setMinimumHeight(hw);
                View show = page[0] == 0 ? pageWheel : pagePal;
                pageWheel.setVisibility(page[0] == 0 ? View.VISIBLE : View.GONE);
                pagePal.setVisibility(page[0] == 1 ? View.VISIBLE : View.GONE);
                show.setAlpha(0f);
                show.animate().alpha(1f).setDuration(120).start();
                pageBtn.setImageResource(page[0] == 0 ? R.drawable.ic_palette_grid : R.drawable.ic_wheel);
                pageBtn.setContentDescription(page[0] == 0 ? "Ver mis colores" : "Ver la rueda");
            }
        };
        showPage.run();
        pageBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                page[0] = 1 - page[0];
                cps0.edit().putInt("color_page", page[0]).apply();
                showPage.run();
            }
        });

        final android.content.SharedPreferences cps = getSharedPreferences("pz", MODE_PRIVATE);
        final LinearLayout adv = new LinearLayout(this);
        adv.setOrientation(LinearLayout.VERTICAL);
        adv.setVisibility(cps.getBoolean("color_adv", false) ? View.VISIBLE : View.GONE);
        final TextView advBtn = smallTextButton(adv.getVisibility() == View.VISIBLE ? "Menos opciones \u25B4" : "Mas opciones \u25BE");
        LinearLayout.LayoutParams advLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        advLp.setMargins(0, dp(6), 0, dp(4));
        root.addView(advBtn, advLp);
        root.addView(adv);
        advBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean show = adv.getVisibility() != View.VISIBLE;
                adv.setVisibility(show ? View.VISIBLE : View.GONE);
                advBtn.setText(show ? "Menos opciones \u25B4" : "Mas opciones \u25BE");
                cps.edit().putBoolean("color_adv", show).apply();
            }
        });

        // HEX
        LinearLayout hexRow = new LinearLayout(this);
        hexRow.setOrientation(LinearLayout.HORIZONTAL);
        hexRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        final EditText hex = new EditText(this);
        hex.setSingleLine(true);
        hex.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        hex.setText(com.pacco.animecut.core.ColorTools.toHex(previous));
        TextView hexGo = smallTextButton("OK");
        final TextView modeBtn = smallTextButton(hsvMode[0] ? "HSV" : "RGB");
        hexRow.addView(hex, new LinearLayout.LayoutParams(0, dp(46), 1f));
        hexRow.addView(hexGo);
        hexRow.addView(modeBtn);
        pageWheel.addView(hexRow);

        // mezclar
        adv.addView(sectionTitle("Mezclar dos colores"));
        LinearLayout mixRow = new LinearLayout(this);
        mixRow.setOrientation(LinearLayout.HORIZONTAL);
        mixRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        final View mixA = new View(this), mixB = new View(this), mixR = new View(this);
        final int[] mixCols = {previous, getSharedPreferences("pz", MODE_PRIVATE).getInt("mix_b", 0xFFFFFFFF)};
        final SeekBar mixT = new SeekBar(this);
        mixT.setMax(100);
        mixT.setProgress(50);
        final boolean[] mixLin = {false};
        final TextView mixPct = new TextView(this);
        mixPct.setTextColor(0xFFFFFFFF);
        mixRow.addView(mixA, new LinearLayout.LayoutParams(dp(34), dp(34)));
        mixRow.addView(mixT, new LinearLayout.LayoutParams(0, dp(36), 1f));
        mixRow.addView(mixB, new LinearLayout.LayoutParams(dp(34), dp(34)));
        adv.addView(mixRow);
        LinearLayout mixRow2 = new LinearLayout(this);
        mixRow2.setOrientation(LinearLayout.HORIZONTAL);
        mixRow2.setGravity(android.view.Gravity.CENTER_VERTICAL);
        final TextView setA = smallTextButton("A = actual"), setB = smallTextButton("B = actual"), kind = smallTextButton("Pintura");
        mixRow2.addView(setA); mixRow2.addView(setB); mixRow2.addView(kind);
        mixRow2.addView(mixPct, new LinearLayout.LayoutParams(dp(54), dp(34)));
        mixRow2.addView(mixR, new LinearLayout.LayoutParams(0, dp(34), 1f));
        TextView useMix = smallTextButton("Usar");
        mixRow2.addView(useMix);
        adv.addView(mixRow2);

        // referencia
        final LinearLayout refBox = new LinearLayout(this);
        refBox.setOrientation(LinearLayout.VERTICAL);
        refBox.setPadding(0, dp(8), 0, 0);
        TextView refTitle = sectionTitle("Imagen de referencia para sacar colores (no se exporta, no es una capa)");
        refBox.addView(refTitle);
        LinearLayout refActions = new LinearLayout(this);
        refActions.setOrientation(LinearLayout.HORIZONTAL);
        TextView refBtn = smallAction(colorRefBitmap == null ? "Abrir imagen" : "Tomar color");
        TextView palBtn = smallAction("Sacar paleta");
        TextView changeBtn = smallAction("Cambiar");
        TextView clearBtn = smallAction("Quitar");
        refActions.addView(refBtn, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(38), 1f); ap.setMargins(dp(4), 0, 0, 0);
        refActions.addView(palBtn, ap);
        LinearLayout.LayoutParams ap1 = new LinearLayout.LayoutParams(0, dp(38), 1f); ap1.setMargins(dp(4), 0, 0, 0);
        refActions.addView(changeBtn, ap1);
        LinearLayout.LayoutParams ap2 = new LinearLayout.LayoutParams(0, dp(38), 1f); ap2.setMargins(dp(4), 0, 0, 0);
        refActions.addView(clearBtn, ap2);
        refBox.addView(refActions);
        final android.widget.HorizontalScrollView refPalScroll = new android.widget.HorizontalScrollView(this);
        final LinearLayout refPal = swatchRow();
        refPalScroll.addView(refPal);
        refBox.addView(refPalScroll);
        adv.addView(refBox);

        final Runnable[] fill = new Runnable[1];
        final Runnable syncUi = new Runnable() {
            @Override public void run() {
                syncing[0] = true;
                int c = chosen[0];
                if (hsvMode[0]) {
                    float[] h = com.pacco.animecut.core.ColorTools.rgbToHsv(c);
                    if (h[1] <= 0.001f || h[2] <= 0.001f) h[0] = picker.getHue();
                    s1.setMax(360); s2.setMax(100); s3.setMax(100);
                    s1.setProgress(Math.round(h[0])); s2.setProgress(Math.round(h[1] * 100)); s3.setProgress(Math.round(h[2] * 100));
                    lab[0].setText("H"); lab[1].setText("S"); lab[2].setText("V");
                    v1.setText(Math.round(h[0]) + "°"); v2.setText(Math.round(h[1] * 100) + "%"); v3.setText(Math.round(h[2] * 100) + "%");
                } else {
                    s1.setMax(255); s2.setMax(255); s3.setMax(255);
                    s1.setProgress(Color.red(c)); s2.setProgress(Color.green(c)); s3.setProgress(Color.blue(c));
                    lab[0].setText("R"); lab[1].setText("G"); lab[2].setText("B");
                    v1.setText(String.valueOf(Color.red(c))); v2.setText(String.valueOf(Color.green(c))); v3.setText(String.valueOf(Color.blue(c)));
                }
                hex.setText(com.pacco.animecut.core.ColorTools.toHex(c));
                newPreview.setBackgroundColor(c); newPreview.setTextColor(contrastText(c));
                mixA.setBackgroundColor(mixCols[0]);
                mixB.setBackgroundColor(mixCols[1]);
                int m = com.pacco.animecut.core.ColorTools.mix(mixCols[0], mixCols[1], mixT.getProgress() / 100f, mixLin[0]);
                mixR.setBackgroundColor(m);
                mixPct.setText(" " + (100 - mixT.getProgress()) + "/" + mixT.getProgress());
                syncing[0] = false;
            }
        };
        final ColorPickTarget pickTo = new ColorPickTarget() {
            @Override public void onColor(int color) {
                chosen[0] = color | 0xFF000000;
                picker.setColor(chosen[0]);
                syncUi.run();
            }
        };
        fill[0] = new Runnable() {
            @Override public void run() {
                List<View> recCells = new ArrayList<View>();
                for (int c : com.pacco.animecut.core.ColorTools.parseList(getSharedPreferences("pz", MODE_PRIVATE).getString("recent_colors", "")))
                    recCells.add(swatch(c, pickTo, null));
                fillGrid(recent, recCells, 8);
                final List<View> palCells = new ArrayList<View>();
                final Project p = canvas.getProject();
                // v8.39: "+" guarda el color actual en Mis colores (para todas las obras, sin preguntar)
                ImageButton add = iconButton(R.drawable.ic_add, "Guardar el color actual en Mis colores", new Runnable() {
                    public void run() {
                        int c = chosen[0] | 0xFF000000;
                        for (Project.Swatch g : globalSwatches()) if ((g.color | 0xFF000000) == c) { toast("Ya esta en Mis colores"); return; }
                        addGlobalSwatch("Color", c);
                        fill[0].run();
                        toast("Guardado en Mis colores");
                    }
                });
                palCells.add(add);
                final List<Project.Swatch> gl = globalSwatches();
                for (int gi = 0; gi < gl.size(); gi++) {
                    final int idx = gi;
                    palCells.add(swatch(gl.get(gi).color, pickTo, new Runnable() {
                        public void run() {
                            List<Project.Swatch> g2 = globalSwatches();
                            if (idx < g2.size()) { g2.remove(idx); saveGlobal(g2); }
                            fill[0].run();
                            toast("Quitado de Mis colores");
                        }
                    }));
                }
                if (p != null) for (final Project.Swatch sw : p.swatches) {
                    palCells.add(swatch(sw.color, pickTo, new Runnable() {
                        public void run() { p.swatches.remove(sw); markDirty(); fill[0].run(); toast("Quitado de la paleta"); }
                    }));
                }
                fillGrid(pal, palCells, 8);
            }
        };
        fill[0].run();

        picker.setListener(new ColorPickerView.Listener() {
            @Override public void onColorChanged(int color) {
                if (syncing[0]) return;
                chosen[0] = color | 0xFF000000;
                syncUi.run();
            }
        });
        fromSliders[0] = new Runnable() {
            @Override public void run() {
                if (syncing[0]) return;
                chosen[0] = hsvMode[0]
                        ? com.pacco.animecut.core.ColorTools.hsvToRgb(s1.getProgress(), s2.getProgress() / 100f, s3.getProgress() / 100f)
                        : Color.rgb(s1.getProgress(), s2.getProgress(), s3.getProgress());
                picker.setColor(chosen[0]);
                syncUi.run();
            }
        };
        SeekBar.OnSeekBarChangeListener chan = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (syncing[0] || !fromUser) return;
                fromSliders[0].run();
            }
        };
        s1.setOnSeekBarChangeListener(chan); s2.setOnSeekBarChangeListener(chan); s3.setOnSeekBarChangeListener(chan);
        sa.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) { va.setText(Math.max(1, value) + "%"); }
        });
        modeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                hsvMode[0] = !hsvMode[0];
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("color_hsv", hsvMode[0]).apply();
                modeBtn.setText(hsvMode[0] ? "HSV" : "RGB");
                syncUi.run();
            }
        });
        mixT.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) { if (!syncing[0]) syncUi.run(); }
        });
        setA.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { mixCols[0] = chosen[0]; syncUi.run(); }
        });
        setB.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                mixCols[1] = chosen[0];
                getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("mix_b", chosen[0]).apply();
                syncUi.run();
            }
        });
        kind.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                mixLin[0] = !mixLin[0];
                kind.setText(mixLin[0] ? "Luz" : "Pintura");
                toast(mixLin[0] ? "Mezcla como luz (brillos, sin oscurecer el medio)" : "Mezcla como se ve en pantalla");
                syncUi.run();
            }
        });
        useMix.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pickTo.onColor(com.pacco.animecut.core.ColorTools.mix(mixCols[0], mixCols[1], mixT.getProgress() / 100f, mixLin[0]));
            }
        });
        oldPreview.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pickTo.onColor(previous); }
        });
        refBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestColorReference(pickTo); }
        });
        palBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final Bitmap ref = colorRefBitmap;
                if (ref == null || ref.isRecycled()) { toast("Primero abre una imagen de referencia"); return; }
                final int[][] out = new int[1][];
                Task.run(new Runnable() {
                    @Override public void run() {
                        int w = ref.getWidth(), h = ref.getHeight();
                        float sc = Math.min(1f, 600f / Math.max(w, h));
                        Bitmap b = sc < 1f ? Bitmap.createScaledBitmap(ref, Math.max(1, (int) (w * sc)), Math.max(1, (int) (h * sc)), true) : ref;
                        int[] pxs = new int[b.getWidth() * b.getHeight()];
                        b.getPixels(pxs, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
                        out[0] = com.pacco.animecut.core.ColorTools.palette(pxs, b.getWidth(), b.getHeight(), 12, 24);
                        if (b != ref) b.recycle();
                    }
                }, new Runnable() {
                    @Override public void run() {
                        refPal.removeAllViews();
                        if (out[0] == null) return;
                        for (int c : out[0]) refPal.addView(swatch(c, pickTo, null));
                        toast("Paleta: toca un color para usarlo; + lo guarda");
                    }
                });
            }
        });
        changeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pendingColorRefTarget = pickTo; pickColorRef.launch(new String[]{"image/*"}); }
        });
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { clearColorReference(true); refPal.removeAllViews(); toast("La referencia se puede volver a abrir cuando quieras"); }
        });
        hexGo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Integer parsed = com.pacco.animecut.core.ColorTools.parseHex(hex.getText().toString());
                if (parsed == null) { toast("HEX invalido. Ejemplo: #FF3030"); return; }
                pickTo.onColor(parsed);
            }
        });

        int opa = Math.max(1, Math.round(canvas.getBrushOpacity() * 100f));
        sa.setProgress(opa); va.setText(opa + "%");
        syncUi.run();

        new SheetBuilder(this)
                .setTitle(title != null ? title : "Color")
                .setView(scroll)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Integer parsed = com.pacco.animecut.core.ColorTools.parseHex(hex.getText().toString());
                        if (parsed != null) chosen[0] = parsed | 0xFF000000;
                        if (target != null) {
                            SharedPreferencesHolder.pushRecent(MainActivity.this, chosen[0]);
                            target.onColor(chosen[0]);
                            return;
                        }
                        canvas.setColor(chosen[0]);
                        SharedPreferencesHolder.pushRecent(MainActivity.this, chosen[0]);
                        int op = Math.max(1, sa.getProgress());
                        canvas.setBrushOpacity(op / 100f);
                        SeekBar bottomOp = findViewById(R.id.opacity);
                        if (canvas.getMode() != CanvasView.MODE_LIQUIFY) bottomOp.setProgress(op);
                        updateUi();
                    }
                })
                .setNeutralButton(target == null ? "Gotero" : null, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.setMode(CanvasView.MODE_PICKER);
                        toast("Toca la imagen: la lupa muestra el pixel exacto");
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Recientes guardados en preferencias (12, sin repetir). */
    static final class SharedPreferencesHolder {
        static void pushRecent(android.content.Context c, int color) {
            android.content.SharedPreferences sp = c.getSharedPreferences("pz", MODE_PRIVATE);
            sp.edit().putString("recent_colors", com.pacco.animecut.core.ColorTools.pushRecent(sp.getString("recent_colors", ""), color, 24)).apply();
        }
    }

    /** v8.52: celdas en filas de 'cols' (rejilla como la paleta de Ibis). */
    private void fillGrid(LinearLayout grid, List<View> cells, int cols) {
        grid.removeAllViews();
        LinearLayout row = null;
        for (int i = 0; i < cells.size(); i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(0, dp(2), 0, dp(2));
                grid.addView(row);
            }
            View c = cells.get(i);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            c.setLayoutParams(lp);
            row.addView(c);
        }
        if (row != null) for (int k = cells.size() % cols; k > 0 && k < cols; k++) {
            View sp = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(sp, lp);
        }
    }

    /** La primera vez, Mis colores trae la paleta basica (se puede quitar color por color). */
    private void seedPaletteOnce() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("pal_seed_852", false)) return;
        List<Project.Swatch> g = globalSwatches();
        java.util.HashSet<Integer> have = new java.util.HashSet<Integer>();
        for (Project.Swatch w : g) have.add(w.color | 0xFF000000);
        List<Project.Swatch> out = new ArrayList<Project.Swatch>();
        for (int c : BASIC_COLORS) if (!have.contains(c | 0xFF000000)) out.add(new Project.Swatch("Color", c));
        out.addAll(g);
        saveGlobal(out);
        sp.edit().putBoolean("pal_seed_852", true).apply();
    }

    private LinearLayout swatchRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(2), 0, dp(2));
        return r;
    }

    private TextView sectionTitle(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFF9FC6FF);
        v.setTextSize(11f);
        v.setPadding(0, dp(6), 0, dp(1));
        return v;
    }

    /** Muestra de color: tocar la usa; mantener pulsado la quita (si se puede) o dice su HEX. */
    private View swatch(final int c, final ColorPickTarget to, final Runnable remove) {
        View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(32), dp(32));
        lp.setMargins(dp(2), 0, dp(2), 0);
        sw.setLayoutParams(lp);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(c | 0xFF000000);
        g.setCornerRadius(dp(5));
        g.setStroke(dp(1), 0xFF6A6A72);
        sw.setBackground(g);
        sw.setContentDescription(com.pacco.animecut.core.ColorTools.toHex(c));
        sw.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { to.onColor(c); }
        });
        sw.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (remove != null) remove.run(); else toast(com.pacco.animecut.core.ColorTools.toHex(c));
                return true;
            }
        });
        return sw;
    }

    /** Fila de canal con etiqueta cambiable (RGB / HSV). */
    private TextView addColorChannel2(LinearLayout root, String name, final SeekBar bar, final TextView value, final Runnable[] after) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this);
        label.setText(name); label.setTextColor(0xFFE8E8E8); label.setTextSize(13f); label.setGravity(android.view.Gravity.CENTER);
        row.addView(label, new LinearLayout.LayoutParams(dp(24), dp(38)));
        // v8.52: − y + como Ibis, para ajustar de a uno
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            final int d = sgn;
            TextView b = new TextView(this);
            b.setText(d < 0 ? "−" : "+");
            b.setTextColor(0xFFFFFFFF);
            b.setTextSize(18f);
            b.setGravity(android.view.Gravity.CENTER);
            b.setBackgroundResource(R.drawable.bg_round);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    bar.setProgress(Math.max(0, Math.min(bar.getMax(), bar.getProgress() + d)));
                    if (after != null && after[0] != null) after[0].run();
                }
            });
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(30), dp(30));
            blp.setMargins(dp(2), 0, dp(2), 0);
            if (d < 0) row.addView(b, blp);
            else { row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); row.addView(b, blp); }
        }
        value.setTextColor(0xFFFFFFFF); value.setGravity(android.view.Gravity.CENTER);
        row.addView(value, new LinearLayout.LayoutParams(dp(46), dp(38)));
        root.addView(row);
        return label;
    }

    private TextView smallAction(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setTextColor(0xFFFFFFFF);
        tv.setBackgroundResource(R.drawable.bg_tool);
        tv.setTextSize(12f);
        return tv;
    }

    private void addColorChannel(LinearLayout root, String name, final SeekBar bar, final TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this);
        label.setText(name); label.setTextColor(0xFFE8E8E8); label.setTextSize(13f); label.setGravity(android.view.Gravity.CENTER);
        row.addView(label, new LinearLayout.LayoutParams(dp(name.equals("Opacidad") ? 72 : 26), dp(42)));
        ImageButton minus = iconButton(R.drawable.ic_sub, "Menos", new Runnable() {
            @Override public void run() { bar.setProgress(Math.max(0, bar.getProgress() - (bar.getMax() == 100 ? 5 : 1))); }
        });
        minus.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        row.addView(minus);
        row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        value.setTextColor(0xFFFFFFFF); value.setGravity(android.view.Gravity.CENTER); value.setMinWidth(dp(42));
        row.addView(value, new LinearLayout.LayoutParams(dp(48), dp(42)));
        ImageButton plus = iconButton(R.drawable.ic_add, "Mas", new Runnable() {
            @Override public void run() { bar.setProgress(Math.min(bar.getMax(), bar.getProgress() + (bar.getMax() == 100 ? 5 : 1))); }
        });
        plus.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        row.addView(plus);
        root.addView(row);
    }

    private Integer parseHexColor(String text) {
        if (text == null) return null;
        String s = text.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6) return null;
        try { return 0xFF000000 | (int) Long.parseLong(s, 16); }
        catch (Throwable t) { return null; }
    }

    private int contrastText(int c) {
        int y = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
        return y > 150 ? 0xFF000000 : 0xFFFFFFFF;
    }

    private void addLabeled(LinearLayout root, String name, SeekBar bar, int value,
                            SeekBar.OnSeekBarChangeListener l) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(l);
        root.addView(bar);
    }

    private void renameDialog(final Layer l) {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        in.setText(l.name);
        new SheetBuilder(this)
                .setTitle("Nombre de la capa")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        if (!s.isEmpty()) l.name = s;
                        updateUi();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private final android.os.Handler opHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean opPending;

    /** Mientras mueves la barra de opacidad, la imagen se actualiza seguido pero sin trabarse. */
    private void scheduleOpacityRefresh() {
        if (opPending) return;
        opPending = true;
        opHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                opPending = false;
                canvas.refreshDisplayAsync();
            }
        }, 60);
    }

    /**
     * v8.27: "→ capa_1 · Normal" en la barra de la brocha y del balde: el destino se ve sin
     * leer manuales. Tocarlo muestra el texto completo (y en el balde abre sus opciones).
     */
    private TextView destinationChip(final boolean bucket) {
        String full = bucket ? canvas.fillDestinationText() : canvas.paintDestinationText();
        final TextView t = smallTextButton(full.replace("Destino: ", "→ "));
        t.setTextSize(11f);
        t.setSingleLine(true);
        t.setMaxWidth(dp(104));
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setContentDescription(full);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bucket) bucketDestinationDialog();
                else canvas.showHud(canvas.paintDestinationText());
            }
        });
        return t;
    }

    /** v8.27: destino del balde y sus opciones. Se guarda al reiniciar la app. */
    private void bucketDestinationDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(6), dp(18), dp(4));
        root.addView(optLabel("Donde va el color"));
        final RadioGroup g = new RadioGroup(this);
        g.setOrientation(LinearLayout.VERTICAL);
        RadioButton cur = new RadioButton(this);
        cur.setText("Pintar en capa actual: exactamente la capa elegida en Capas (nunca crea otra)");
        cur.setTextColor(0xFFFFFFFF);
        cur.setTextSize(13f);
        cur.setId(2000);
        g.addView(cur);
        RadioButton auto = new RadioButton(this);
        auto.setText("Capa de color automatica: UNA sola capa \"Color\", creada la primera vez y reutilizada siempre. Tu capa elegida no cambia");
        auto.setTextColor(0xFFFFFFFF);
        auto.setTextSize(13f);
        auto.setId(2001);
        g.addView(auto);
        g.check(canvas.getFillTarget() == CanvasView.FILL_TARGET_AUTO ? 2001 : 2000);
        root.addView(g);
        root.addView(optLabel("Como busca la zona"));
        final CheckBox lines = new CheckBox(this);
        lines.setText("Por lineas (manga blanco y negro): la trama, los grises y el ruido no cortan la zona");
        lines.setTextColor(0xFFFFFFFF);
        lines.setTextSize(13f);
        lines.setChecked(canvas.isFillByLines());
        root.addView(lines);
        final CheckBox prev = new CheckBox(this);
        prev.setText("Vista previa antes de pintar (✓ pinta, ✕ cancela)");
        prev.setTextColor(0xFFFFFFFF);
        prev.setTextSize(13f);
        prev.setChecked(canvas.isBucketPreview());
        root.addView(prev);
        TextView tip = new TextView(this);
        tip.setText(canvas.fillDestinationText() + "\n\"Colorear manga\" (Menu) usa su propia capa \"Color base\" en Multiplicar.");
        tip.setTextColor(0xFFB8B8C0);
        tip.setTextSize(12f);
        tip.setPadding(0, dp(8), 0, 0);
        root.addView(tip);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new SheetBuilder(this).setTitle("Balde").setView(sv)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Listo", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setFillTarget(g.getCheckedRadioButtonId() == 2001
                                ? CanvasView.FILL_TARGET_AUTO : CanvasView.FILL_TARGET_CURRENT);
                        canvas.setFillByLines(lines.isChecked());
                        canvas.setBucketPreview(prev.isChecked());
                        applyFillPrefs();
                        canvas.showHud(canvas.fillDestinationText());
                        updateUi();
                    }
                })
                .show();
    }

    /** Pinceles como la lista basica de Ibis: cada uno con su propio trazo. */
    private void brushPresets() {
        final com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        int current = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset4", 0);
        if (current < 0 || current >= list.length) current = 0;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        // v9.04: sin fondo propio: se ve el fondo un poco transparente de la ventana
        TextView title = new TextView(this);
        title.setText("Pinceles");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(17f);
        title.setPadding(dp(6), dp(2), 0, dp(4));
        root.addView(title);
        final android.widget.CheckBox flat = new android.widget.CheckBox(this);
        flat.setText("Repasar no oscurece (color parejo con poca opacidad)");
        flat.setTextColor(0xFFDDDDDD);
        flat.setTextSize(12.5f);
        flat.setChecked(canvas.isFlatPaint());
        flat.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                canvas.setFlatPaint(on);
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("flat_paint", on).apply();
            }
        });
        root.addView(flat);
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < list.length; i++) {
            final com.pacco.animecut.core.BrushPreset bp = list[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            if (i == current) {
                android.graphics.drawable.GradientDrawable sel = new android.graphics.drawable.GradientDrawable();
                sel.setColor(0xFF1E2A44);
                sel.setStroke(dp(2), 0xFF3D7BFF);
                sel.setCornerRadius(dp(8));
                row.setBackground(sel);
            } else {
                row.setBackgroundResource(R.drawable.bg_cell);
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, 0, 0, dp(4));
            row.setLayoutParams(rlp);
            row.setPadding(dp(10), dp(6), dp(10), dp(6));
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(android.view.Gravity.CENTER_VERTICAL);
            TextView t = new TextView(this);
            t.setText(bp.name + (i == current ? "  (en uso)" : ""));
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12.5f);
            top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView sz = new TextView(this);
            sz.setText(String.format(Locale.US, bp.size < 10 ? "%.1f" : "%.0f", bp.size));
            sz.setTextColor(0xFFAAAAAA);
            sz.setTextSize(12f);
            top.addView(sz);
            row.addView(top);
            final ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
            img.setScaleType(ImageView.ScaleType.FIT_XY);
            row.addView(img);
            // las muestras se dibujan aparte para que la lista abra al instante
            final int pw = dp(260), ph = dp(34);
            thumbPool.execute(new Runnable() {
                @Override
                public void run() {
                    final Bitmap b = bp.preview(pw, ph);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            img.setImageBitmap(b);
                        }
                    });
                }
            });
            final int idx = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dlg[0].dismiss();
                    applyBrushPreset(idx, true);
                    canvas.showHud(bp.name);
                }
            });
            root.addView(row);
        }
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        dlg[0] = new SheetBuilder(this).setView(sc).create();
        dlg[0].show();
    }

    /**
     * v8.55: LAPIZ (dibujar a mano libre, formas rapidas). Es la Brocha con un pincel de borde duro
     * y fino; la Brocha recupera su pincel y tamano al volver. Se recuerda cual estaba.
     */
    private boolean pencilOn;
    private static final int PENCIL_PRESET = 7;   // "Lapiz digital"

    private void setPencil(boolean on) {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (on == pencilOn) return;
        if (on) {
            sp.edit().putInt("brocha_preset", sp.getInt("brush_preset4", 0))
                    .putFloat("brocha_size", canvas.getBrushSize()).apply();
            applyBrushPreset(PENCIL_PRESET, true);
            canvas.setBrushSize(sp.getFloat("lapiz_size", 6f));
            syncSlider();
        } else {
            sp.edit().putFloat("lapiz_size", canvas.getBrushSize()).apply();
            applyBrushPreset(sp.getInt("brocha_preset", 0), true);
            canvas.setBrushSize(sp.getFloat("brocha_size", 20f));
            syncSlider();
        }
        pencilOn = on;
    }

    /** v8.28: Plano (0) / Suave (1) sin cambiar el tamano elegido. */
    private void applyBrushStyle(int idx) {
        com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        if (idx < 0 || idx >= list.length) return;
        com.pacco.animecut.core.BrushPreset bp = list[idx];
        canvas.setBrushDynamics(bp.taperStart, bp.taperEnd, bp.speedThin, bp.particles, bp.grain, bp.spacing, bp.flow);
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("brush_preset4", idx)
                .putFloat("brush_hardness_v827", bp.hardness).apply();
        canvas.setHardness(bp.hardness);
    }

    /** v8.29: el ojo de Borrar fondo: cuadros -> blanco -> negro -> gris -> verde. */
    private void cycleViewBg() {
        final int[] order = {0, 2, 3, 5, 4};
        final String[] names = {"Cuadros", "Blanco", "Negro", "Gris", "Verde"};
        int cur = 0;
        for (int k = 0; k < order.length; k++) if (order[k] == canvas.getViewBg()) cur = k;
        int nx = (cur + 1) % order.length;
        canvas.setViewBg(order[nx]);
        canvas.showHud("Ver: " + names[nx]);
        if (layersOpen()) buildViewBg();
    }

    /** v8.29: todos los ajustes de Borrar fondo juntos (antes eran 6 botones en la barra). */
    private static String gapLabel(int g) {
        return "Cerrar huecos de la linea: " + (g / 100) + "," + (g % 100 / 10) + "x" + (g == 100 ? " (normal)" : "");
    }

    private void bgSettingsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(6));
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        final TextView tt = new TextView(this);
        tt.setTextColor(0xFFFFFFFF);
        tt.setText("Parecido del color: " + canvas.getBgTolerance());
        root.addView(tt);
        SeekBar tb = new SeekBar(this);
        tb.setMax(160);
        tb.setProgress(canvas.getBgTolerance());
        tb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s0, int v, boolean u) {
                canvas.setBgTolerance(v);
                tt.setText("Parecido del color: " + v);
                if (u) sp.edit().putInt("bg_tol", v).apply();
            }
        });
        root.addView(tb);
        // v8.32: "Borde suave" ya no hace falta: el borde sale de desmezclar la linea y el fondo
        final CheckBox once = new CheckBox(this);
        once.setText("Tomar el color solo al empezar");
        once.setTextColor(0xFFFFFFFF);
        once.setChecked(canvas.isBgOnce());
        once.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                canvas.setBgOnce(on);
                sp.edit().putBoolean("bg_once", on).apply();
            }
        });
        root.addView(once);
        // v8.32: CERRAR HUECOS (veces el grosor medido de las lineas). 1x = normal. Mas = no pasa
        // por cortes mas grandes de la linea; menos = entra en rincones mas angostos.
        final TextView gt = new TextView(this);
        gt.setTextColor(0xFFFFFFFF);
        gt.setPadding(0, dp(8), 0, 0);
        gt.setText(gapLabel(Math.round(canvas.getBgGapScale() * 100)));
        root.addView(gt);
        SeekBar gb = new SeekBar(this);
        gb.setMax(250);
        gb.setProgress(Math.round(canvas.getBgGapScale() * 100) - 50);
        gb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s0, int v, boolean u) {
                int g = v + 50;
                canvas.setBgGapScale(g / 100f);
                gt.setText(gapLabel(g));
                if (u) sp.edit().putInt("bg_gap", g).apply();
            }
        });
        root.addView(gb);
        final TextView ht = new TextView(this);
        ht.setTextColor(0xFFFFFFFF);
        ht.setPadding(0, dp(8), 0, 0);
        ht.setText("Dureza del borrador: " + Math.round(canvas.getBgEraserHard() * 100) + "%");
        root.addView(ht);
        SeekBar hb = new SeekBar(this);
        hb.setMax(100);
        hb.setProgress(Math.round(canvas.getBgEraserHard() * 100));
        hb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s0, int v, boolean u) {
                canvas.setBgEraserHard(v / 100f);
                ht.setText("Dureza del borrador: " + v + "%");
                if (u) sp.edit().putInt("bg_er_hard", v).apply();
            }
        });
        root.addView(hb);
        final CheckBox prot = new CheckBox(this);
        prot.setText("Proteger el color elegido");
        prot.setTextColor(0xFFFFFFFF);
        prot.setChecked(canvas.isProtect());
        prot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setProtect(on); }
        });
        root.addView(prot);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        TextView refine = smallTextButton("Refinar borde");
        refine.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { edgeRefineDialog(); }
        });
        TextView fab = smallTextButton("De fabrica");
        fab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                sp.edit().putInt("bg_tol", 46).putInt("bg_soft", 42).putBoolean("bg_once", false)
                        .putInt("bg_gap", 100).putInt("bg_er_hard", 85).apply();
                canvas.setBgTolerance(46);
                canvas.setBgSoftness(42);
                canvas.setBgOnce(false);
                canvas.setBgGapScale(1f);
                canvas.setBgEraserHard(0.85f);
                canvas.showHud("Borrar fondo: de fabrica");
            }
        });
        row.addView(refine);
        row.addView(fab);
        root.addView(row);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new SheetBuilder(this).setTitle("Borrar fondo").setView(sv).setPositiveButton("Listo", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int w) { updateUi(); }
        }).show();
    }

    /** v8.28: cambia el fondo de VISTA (cuadros, blanco, negro, gris, verde). No toca el PNG. */
    private TextView viewBgChip() {
        final int[] order = {0, 2, 3, 5, 4};
        final String[] names = {"Cuadros", "Blanco", "Negro", "Gris", "Verde"};
        int cur = 0;
        for (int k = 0; k < order.length; k++) if (order[k] == canvas.getViewBg()) cur = k;
        final int curF = cur;
        TextView t = smallTextButton("Ver: " + names[cur]);
        t.setContentDescription("Fondo para revisar el recorte (no se guarda en el PNG)");
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int n = (curF + 1) % order.length;
                canvas.setViewBg(order[n]);
                canvas.showHud("Fondo de vista: " + names[n] + " (el PNG queda transparente)");
                if (layersOpen()) buildViewBg();
                updateUi();
            }
        });
        return t;
    }

    /** Aplica un pincel. Con all=false solo su forma de trazo (al abrir la app). */
    private void applyBrushPreset(int idx, boolean all) {
        com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        if (idx < 0 || idx >= list.length) return;
        com.pacco.animecut.core.BrushPreset bp = list[idx];
        canvas.setBrushDynamics(bp.taperStart, bp.taperEnd, bp.speedThin, bp.particles, bp.grain, bp.spacing, bp.flow);
        if (!all) return;
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("brush_preset4", idx)
                .putFloat("brush_hardness_v827", bp.hardness).apply();
        canvas.setBrushSize(bp.size);
        canvas.setHardness(bp.hardness);
        canvas.setBrushOpacity(bp.opacity / 100f);
        if (canvas.getMode() != CanvasView.MODE_LIQUIFY)
            ((SeekBar) findViewById(R.id.opacity)).setProgress(bp.opacity);
        syncSlider();
        updateUi();
    }

    private void toleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getTolerance());
        final TextView t = new TextView(this);
        t.setText(String.valueOf(canvas.getTolerance()));
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText(String.valueOf(v));
                canvas.setTolerance(v);
            }
        });
        new SheetBuilder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Elegir que parte se esta rayando: un color por parte, el gris es el fondo. */
    private void labelPicker() {
        int n = CanvasView.LABEL_NAMES.length;
        int[] icons = new int[n];
        String[] names = new String[n];
        Runnable[] actions = new Runnable[n];
        for (int i = 0; i < n; i++) {
            icons[i] = R.drawable.ic_color;
            names[i] = i == n - 1 ? "fondo" : "parte " + (i + 1);
            final int lab = i + 1;
            actions[i] = new Runnable() {
                public void run() {
                    canvas.setMarkerLabel(lab);
                    canvas.setSubtract(false);
                    canvas.showHud(lab == CanvasView.LABEL_NAMES.length ? "Rayando el fondo" : "Rayando parte " + lab);
                    updateUi();
                }
            };
        }
        showIconGridTinted(icons, names, actions, 3, canvas.getMarkerLabel() - 1, CanvasView.LABEL_COLORS);
    }

    private void showIconGridTinted(int[] icons, String[] names, Runnable[] actions, int cols,
                                    int active, int[] tints) {
        tintNext = tints;
        showIconGrid(null, icons, names, actions, cols, active);
        tintNext = null;
    }

    /** Cuadricula de iconos con su nombre corto debajo. */
    private void showIconGrid(String title, int[] icons, String[] names, final Runnable[] actions,
                              int cols, int active) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        // v9.04: sin fondo propio: se ve el fondo un poco transparente de la ventana
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                root.addView(row);
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(4), dp(10), dp(4), dp(10));
            cell.setBackgroundResource(i == active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(3), dp(3), dp(3), dp(3));
            cell.setLayoutParams(clp);

            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
            img.setImageResource(icons[i]);
            if (tintNext != null && i < tintNext.length) img.setColorFilter(tintNext[i]);
            cell.addView(img);

            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, dp(4), 0, 0);
            cell.addView(t);

            final int idx = i;
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    actions[idx].run();
                }
            });
            if (demoNext != null && i < demoNext.length) {
                final int scene = demoNext[i];
                cell.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showSelCard(scene);
                        return true;
                    }
                });
            }
            row.addView(cell);
        }
        // rellenar la ultima fila para que no se estiren las celdas
        int rest = icons.length % cols;
        if (rest != 0 && row != null) {
            for (int k = rest; k < cols; k++) {
                View v = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
                v.setLayoutParams(lp);
                row.addView(v);
            }
        }
        if (demoNext != null) {
            TextView hint = new TextView(this);
            hint.setText("Manten presionado un boton para ver que hace");
            hint.setTextColor(0xFF9FC6FF);
            hint.setTextSize(12f);
            hint.setGravity(android.view.Gravity.CENTER);
            hint.setPadding(0, dp(8), 0, dp(2));
            root.addView(hint);
        }
        AlertDialog.Builder b = new SheetBuilder(this).setView(root);
        if (title != null) b.setTitle(title);
        dlg[0] = b.create();
        dlg[0].show();
    }

    /** Ficha de la herramienta: dibujo de antes y despues y tres lineas cortas. */
    private void showToolCard(int mode, int sub) {
        String[] info = toolInfo(mode, sub);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        // v9.04: sin fondo propio: se ve el fondo un poco transparente de la ventana
        TextView title = new TextView(this);
        title.setText(info[0]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        View art = demoFor(mode, sub);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        root.addView(cardLine("Para que:", info[1]));
        root.addView(cardLine("Como:", info[2]));
        if (!info[3].isEmpty()) root.addView(cardLine("", info[3]));
        new SheetBuilder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    private TextView cardLine(String head, String text) {
        TextView t = new TextView(this);
        t.setText(head.isEmpty() ? text : head + " " + text);
        t.setTextColor(head.isEmpty() ? 0xFF9FC6FF : 0xFFE0E0E0);
        t.setTextSize(13f);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    /**
     * La primera vez que eliges una herramienta sale su ficha completa. Las
     * siguientes veces, un cuadrito con la animacion unos segundos.
     */
    private void cardFirstTime(int mode, int sub) {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        String key = "card_" + mode + "_" + sub;
        if (!sp.getBoolean(key, false)) {
            sp.edit().putBoolean(key, true).apply();
            showToolCard(mode, sub);
            return;
        }
        if (sp.getBoolean("demo_on", false)) showDemo(mode, sub);
    }

    /** Animacion de la herramienta. Separar y la varita usan la de antes y despues. */
    private View demoFor(int mode, int sub) {
        // v8.69: Separar con Zeta (rayones -> cada parte en su capa)
        if (mode == CanvasView.MODE_WAND && canvas.isAutoLines()) return new SelDemoView(this, SelDemoView.WAND_LINES);
        int variant = mode == CanvasView.MODE_LIQUIFY ? canvas.getLiquifyType() : 0;
        return new com.pacco.animecut.view.ToolDemoView(this, mode, sub == 2, variant);
    }

    /** Cuadrito arriba a la izquierda con la herramienta trabajando. Se va solo. */
    private void showDemo(int mode, int sub) {
        final View box = findViewById(R.id.demoBox);
        FrameLayout holder = findViewById(R.id.demoHolder);
        holder.removeAllViews();
        holder.addView(demoFor(mode, sub),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        String demoTitle = toolInfo(mode, sub)[0];
        if (mode == CanvasView.MODE_LIQUIFY) {
            int lt = canvas.getLiquifyType();
            demoTitle = "Especial · " + (lt == 0 ? "Arrastrar" : lt == 1 ? "Contraer"
                    : lt == 2 ? "Expandir" : lt == 3 ? "Suavizar" : "Restaurar");
        }
        ((TextView) findViewById(R.id.demoName)).setText(demoTitle);
        box.setVisibility(View.VISIBLE);
        box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                box.setVisibility(View.GONE);
            }
        });
        if (hideDemo != null) box.removeCallbacks(hideDemo);
        hideDemo = new Runnable() {
            @Override
            public void run() {
                box.setVisibility(View.GONE);
                ((FrameLayout) findViewById(R.id.demoHolder)).removeAllViews();
            }
        };
        box.postDelayed(hideDemo, 4500);
    }

    private void tutorialPage(final int page) {
        final int[] modes = {CanvasView.MODE_BGERASE, CanvasView.MODE_MARKER, CanvasView.MODE_ZONE,
                CanvasView.MODE_PAN};
        final String[] titles = {"1. Saca el personaje", "2. Separa las partes",
                "3. Rellena lo de atras", "4. Exporta"};
        final String[] texts = {
                "Tu imagen queda en la capa \"imagen\". Con Borrar fondo pasas el pincel por el borde y "
                        + "solo se borra el fondo. En Capas puedes mirar sobre negro o verde para ver si quedo limpio.",
                "Separar: raya cada parte con un color (pelo, cara, ojos) y el fondo en gris, y toca el check "
                        + "verde. Cada parte sale en su capa. Tambien: Varita y en el cuadro punteado, Copiar a capa.",
                "Donde sacaste un ojo o un brazo, en la capa de atras queda el dibujo viejo. Marca esa zona en azul, "
                        + "toca esa capa en Capas y usa Zona tocando dentro de lo azul: queda con el color de alrededor.",
                "La flecha de abajo guarda un PNG por cada capa visible, todas del mismo tamano, "
                        + "listas para tu app de animacion."
        };        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        // v9.04: sin fondo propio: se ve el fondo un poco transparente de la ventana
        TextView title = new TextView(this);
        title.setText(titles[page]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        com.pacco.animecut.view.ToolDemoView art =
                new com.pacco.animecut.view.ToolDemoView(this, modes[page], false);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        TextView t = new TextView(this);
        t.setText(texts[page]);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(14f);
        root.addView(t);
        TextView foot = new TextView(this);
        foot.setText((page + 1) + " de 4    Manten pulsada cualquier herramienta para ver su ficha");
        foot.setTextColor(0xFF8A8A92);
        foot.setTextSize(11f);
        foot.setPadding(0, dp(10), 0, 0);
        root.addView(foot);
        AlertDialog.Builder b = new SheetBuilder(this).setView(root);
        if (page < 3) {
            b.setPositiveButton("Siguiente", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    tutorialPage(page + 1);
                }
            });
            b.setNegativeButton("Saltar", null);
        } else {
            b.setPositiveButton("Empezar", null);
        }
        b.show();
    }

    /** Tutorial: cuatro fichas con dibujo, una detras de otra. */
    private void guideDialog() {
        tutorialPage(0);
    }

    private void guideIfFirstTime() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("guia3", false)) return;
        sp.edit().putBoolean("guia3", true).apply();
        guideDialog();
    }

    private void projectDialog() {
        final boolean has = canvas.getProject() != null;
        final String[] items = {
                "Guardar proyecto en un archivo",
                "Abrir un proyecto guardado",
                "Guardar ahora en la app"
        };
        new SheetBuilder(this)
                .setTitle("Proyecto")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 1) {
                            openProject.launch(new String[]{"*/*"});
                            return;
                        }
                        if (!has) {
                            toast("Abre una imagen primero");
                            return;
                        }
                        if (i == 0) createProject.launch("proyecto.acut");
                        else autosave(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void saveProjectTo(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int color = canvas.getColor();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    ProjectIO.save(os, p, color);
                    if (os != null) os.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al guardar: " + lastError);
                else toast("Proyecto guardado con sus " + p.layers.size() + " capas");
            }
        });
    }

    private void openProjectFrom(final Uri uri) {
        final int gen = ++loadGen;
        projectLoading = true;
        showLoading("Abriendo tu obra...");
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    loaded = ProjectIO.load(is);
                    if (is != null) is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                if (destroyed) return;
                onBusy(false);
                hideLoading();
                if (gen != loadGen) { loaded = null; return; }   // v8.74: se abrio otra cosa despues
                projectLoading = false;
                applyLoaded();
                applyPendingAdd();
            }
        });
    }

    /** v8.43: aviso "Abriendo tu obra..." mientras carga (antes se veia todo negro unos segundos). */
    private View loadingView;

    private void showLoading(String text) {
        hideLoading();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(0xFF151518);
        box.setClickable(true);
        android.widget.ProgressBar pb = new android.widget.ProgressBar(this);
        box.addView(pb, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(15f);
        t.setPadding(0, dp(14), 0, 0);
        box.addView(t);
        ((ViewGroup) findViewById(android.R.id.content)).addView(box,
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        loadingView = box;
    }

    private void hideLoading() {
        if (loadingView != null && loadingView.getParent() instanceof ViewGroup)
            ((ViewGroup) loadingView.getParent()).removeView(loadingView);
        loadingView = null;
    }

    private void recoverFrom(final File f) {
        final int gen = ++loadGen;
        projectLoading = true;
        showLoading("Abriendo tu obra...");
        onBusy(true);
        lastError = null;
        loaded = null;
        recoveredBackup = false;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try (FileInputStream is = new FileInputStream(f)) {
                    loaded = ProjectIO.load(is);
                } catch (Throwable t) {
                    // Un cierre inesperado no debe inutilizar toda la obra.
                    File bak = new File(f.getAbsolutePath() + ".bak");
                    try (FileInputStream is = new FileInputStream(bak)) {
                        loaded = ProjectIO.load(is);
                        lastError = null;
                        recoveredBackup = true;
                    } catch (Throwable fallback) {
                        lastError = String.valueOf(t.getMessage());
                    }
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                if (destroyed) return;
                onBusy(false);
                hideLoading();
                if (gen != loadGen) { loaded = null; return; }   // v8.74: se abrio otra cosa despues
                projectLoading = false;
                applyLoaded();
                applyPendingAdd();
            }
        });
    }

    /** Mantiene la proporcion para que todas las capas sigan cuadrando entre si. */
    private int[] longSide(Project p, int target) {
        int max = Math.max(p.w, p.h);
        if (max <= target) return new int[]{p.w, p.h};
        float f = target / (float) max;
        return new int[]{Math.max(1, Math.round(p.w * f)), Math.max(1, Math.round(p.h * f))};
    }

    private int toolIcon(int mode) {
        switch (mode) {
            case CanvasView.MODE_LASSO: return R.drawable.ic_lasso;
            case CanvasView.MODE_SCISSORS: return R.drawable.ic_scissors;
            case CanvasView.MODE_BRUSH: return R.drawable.ic_brush;
            case CanvasView.MODE_ERASER: return R.drawable.ic_eraser;
            case CanvasView.MODE_PAINT: return R.drawable.ic_paint;
            case CanvasView.MODE_BUCKET: return R.drawable.ic_bucket;
            case CanvasView.MODE_PICKER: return R.drawable.ic_picker;
            case CanvasView.MODE_CLONE: return R.drawable.ic_clone;
            case CanvasView.MODE_MOVE: return R.drawable.ic_move;
            case CanvasView.MODE_PAN: return R.drawable.ic_hand;
            case CanvasView.MODE_BGERASE: return R.drawable.ic_bgerase;
            case CanvasView.MODE_MARKER: return R.drawable.ic_marker;
            case CanvasView.MODE_MAGNET: return R.drawable.ic_magnet;
            case CanvasView.MODE_LINE: return R.drawable.ic_line_cont;
            case CanvasView.MODE_SHAPE: return R.drawable.ic_shapes;
            case CanvasView.MODE_MARK: return R.drawable.ic_mark;
            case CanvasView.MODE_CROP: return R.drawable.ic_crop;
            case CanvasView.MODE_CURVE: return R.drawable.ic_curve;
            case CanvasView.MODE_POLY: return R.drawable.ic_poly;
            case CanvasView.MODE_ZONE: return R.drawable.ic_zone;
            case CanvasView.MODE_HEAL: return R.drawable.ic_heal;
            case CanvasView.MODE_TONE: return R.drawable.ic_tone;
            case CanvasView.MODE_SMUDGE: return R.drawable.ic_smudge;
            case CanvasView.MODE_BLUR: return R.drawable.ic_blur;
            case CanvasView.MODE_LIQUIFY: return R.drawable.ic_liquify;
            case CanvasView.MODE_TRANSFORM: return R.drawable.ic_transform;
            case CanvasView.MODE_PUPPET: return R.drawable.ic_puppet;
            default: return R.drawable.ic_wand;
        }
    }

    private void fillRow(LinearLayout row, int used, int cols) {
        for (int k = used; k < cols; k++) {
            View v = new View(this);
            v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
            row.addView(v);
        }
    }

    private void closeTools() {
        if (findViewById(R.id.layersPanel).getVisibility() != View.VISIBLE) hideCards(false);
        findViewById(R.id.toolPanel).setVisibility(View.GONE);
        findViewById(R.id.toolScrim).setVisibility(View.GONE);
        FrameLayout.LayoutParams l = (FrameLayout.LayoutParams) findViewById(R.id.toolPanel).getLayoutParams();
        l.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        findViewById(R.id.toolPanel).setLayoutParams(l);
    }

    /** v8.33: de donde viene la luz (8 flechas) + ancho de la sombra. */
    private void autoShadeDialog() {
        final Project p = canvas.getProject();
        if (p == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(4));
        TextView t = new TextView(this);
        t.setText("Toca de donde VIENE la luz:");
        box.addView(t);
        final String[] arrows = {"↖", "↑", "↗", "←", "", "→", "↙", "↓", "↘"};
        final float[][] dir = {{1, 1}, {0, 1}, {-1, 1}, {1, 0}, {0, 0}, {-1, 0}, {1, -1}, {0, -1}, {-1, -1}};
        final int[] chosen = {getSharedPreferences("pz", MODE_PRIVATE).getInt("shade_dir", 0)};
        final TextView[] cells = new TextView[9];
        for (int r = 0; r < 3; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for (int c = 0; c < 3; c++) {
                final int k = r * 3 + c;
                TextView b = smallTextButton(arrows[k]);
                b.setTextSize(20f);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(46));
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                b.setLayoutParams(lp);
                if (k == 4) b.setVisibility(View.INVISIBLE);
                cells[k] = b;
                b.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        chosen[0] = k;
                        for (int q = 0; q < 9; q++) cells[q].setBackgroundResource(q == k ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                    }
                });
                row.addView(b);
            }
            box.addView(row);
        }
        cells[chosen[0] == 4 ? 0 : chosen[0]].setBackgroundResource(R.drawable.bg_tool_on);
        TextView wt = new TextView(this);
        wt.setText("Ancho de la sombra");
        wt.setPadding(0, dp(8), 0, 0);
        box.addView(wt);
        final SeekBar wb = new SeekBar(this);
        wb.setMax(100);
        wb.setProgress(getSharedPreferences("pz", MODE_PRIVATE).getInt("shade_w", 35));
        box.addView(wb);
        final CheckBox parts = new CheckBox(this);
        parts.setText("Por partes (cara, pelo y ropa por separado)");
        parts.setChecked(true);
        box.addView(parts);
        new SheetBuilder(this)
                .setTitle("Sombra automatica")
                .setView(box)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        int k = chosen[0] == 4 ? 0 : chosen[0];
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("shade_dir", k).putInt("shade_w", wb.getProgress()).apply();
                        int width = Math.max(2, Math.round(Math.max(p.w, p.h) * (0.005f + wb.getProgress() / 100f * 0.06f)));
                        canvas.addAutoShade(dir[k][0], dir[k][1], width, parts.isChecked());
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    // ---- v8.33: Recortar con IA ----
    private AiCutFlow aiFlow;

    private AiCutFlow aiFlow() {
        if (aiFlow == null) aiFlow = new AiCutFlow(this, canvas);
        return aiFlow;
    }

    /** Despues de aplicar el recorte de la IA. */
    void afterAiCut() {
        markDirty();
        updateUi();
    }

    /** Corre algo corto en segundo plano con un aviso, y despues "after" en pantalla. */
    void runBusy(String text, Runnable bg, Runnable after) {
        if (text != null) canvas.showHud(text);
        Task.run(bg, after);
    }

    /**
     * v8.69 tacho de Separar / Rayar partes: toca = borra solo los rayones del color elegido
     * (la cara, el cuello...); mantener apretado = borrar todos.
     */
    private ImageButton markerTrash() {
        ImageButton b = iconButton(R.drawable.ic_trash, "Borrar los rayones de este color", new Runnable() {
            public void run() {
                int n = canvas.clearMarkersOfCurrent();
                toast(n > 0 ? "Rayones de este color borrados · mantener el tacho = borrar todos"
                        : "Este color no tiene rayones · mantener el tacho = borrar todos");
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                canvas.clearMarkers();
                toast("Todos los rayones borrados");
                return true;
            }
        });
        return b;
    }

    private ImageButton iconButton(int icon, final String name, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setImageResource(icon);
        b.setContentDescription(name);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                toast(name);
                return true;
            }
        });
        return b;
    }

    /** Boton compacto para Transformar: evita que X/✓ queden fuera de pantalla. */
    private ImageButton compactIconButton(int icon, final String name, final Runnable action) {
        ImageButton b = iconButton(icon, name, action);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(31), dp(36)));
        b.setPadding(dp(6), dp(7), dp(6), dp(7));
        return b;
    }

    private ImageView thumb(Bitmap b) {
        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageBitmap(b);
        return img;
    }

    private TextView rowText(String name, String sub, boolean bright) {
        TextView t = new TextView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(10);
        t.setLayoutParams(lp);
        t.setText(name + "\n" + sub);
        t.setTextColor(bright ? 0xFFFFFFFF : 0xFF7A7A7A);
        t.setTextSize(13f);
        return t;
    }

    private LinearLayout rowBase(boolean on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);
        return row;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void click(int id, final Runnable r) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
    }

    private boolean needProject() {
        if (canvas.getProject() == null) {
            toast("Abre una imagen primero");
            return false;
        }
        return true;
    }

    /** Marca en azul lo que esta activado, para que se vea sin leer nada. */
    private void toggle(int id, boolean on) {
        findViewById(id).setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
    }

    private boolean sliderIsTolerance() {
        int m = canvas.getMode();
        return m == CanvasView.MODE_WAND || m == CanvasView.MODE_BUCKET;
    }

    private void applySlider(int v) {
        if (sliderIsTolerance()) {
            canvas.setTolerance(v);
            sliderLabel.setText(String.valueOf(v));
        } else {
            float t = v / 120f;
            float size = 1f + t * t * 299f;
            canvas.setBrushSize(size);
            canvas.showSizePreview(size);
            String sizeText = String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size);
            sliderLabel.setText(canvas.getMode() == CanvasView.MODE_LIQUIFY
                    ? "Grosor\n" + sizeText + "px" : sizeText);
            ((TextView) findViewById(R.id.btnSize)).setText(
                    String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void syncSlider() {
        if (sliderIsTolerance()) {
            slider.setProgress(canvas.getTolerance());
            sliderLabel.setText(String.valueOf(canvas.getTolerance()));
        } else {
            float t = (float) Math.sqrt(Math.max(0f, (canvas.getBrushSize() - 1f) / 299f));
            slider.setProgress(Math.round(t * 120f));
            float size = canvas.getBrushSize();
            String sizeText = String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size);
            sliderLabel.setText(canvas.getMode() == CanvasView.MODE_LIQUIFY
                    ? "Grosor\n" + sizeText + "px" : sizeText);
        }
    }

    private void measureBars() { measureBars(true); }

    /** v8.74: refit=false al girar o cambiar la ventana (el lienzo ya se reacomodo solo). */
    private void measureBars(final boolean refit) {
        final View top = findViewById(R.id.topBar);
        final View bottom = findViewById(R.id.bottomPanel);
        top.post(new Runnable() {
            @Override
            public void run() {
                if (destroyed) return;
                fitTopBar();
                canvas.setInsets(top.getHeight() + dp(12), bottom.getHeight());
                if (refit && canvas.getProject() != null) canvas.fit();
                barsMeasured = true;
                if (pendingReveal) revealCanvas();
            }
        });
    }

    /** Para no repetir los tres metodos del SeekBar en cada dialogo. */
    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }

    // ==================================================================
    // v8.26 COLOREAR MANGA (interfaz)
    // ==================================================================

    private void loadMangaPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        canvas.setMangaToneLevel(sp.getInt("manga_tone_level", 1));
        canvas.setMangaGapLevel(sp.getInt("manga_gap", 2));
        canvas.setMangaExpand(sp.getInt("manga_expand", 2));
        canvas.setMangaInk(sp.getInt("manga_ink", 128));
        canvas.setFillPreview(sp.getBoolean("manga_preview", true));
        canvas.setShowProtect(sp.getBoolean("manga_show_protect", true));
        canvas.setPickSource(sp.getInt("pick_source", CanvasView.PICK_AUTO));
    }

    private void saveMangaPrefs() {
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putInt("manga_tone_level", canvas.getMangaToneLevel())
                .putInt("manga_gap", canvas.getMangaGapLevel())
                .putInt("manga_expand", canvas.getMangaExpand())
                .putInt("manga_ink", canvas.getMangaInk())
                .putBoolean("manga_preview", canvas.isFillPreview())
                .putBoolean("manga_show_protect", canvas.isShowProtect())
                .putInt("pick_source", canvas.getPickSource())
                .apply();
    }

    /** v8.66: true = viene de Colorear facil (sin capa "Color base"). */
    private boolean mangaNoBase;

    /** Entrada del menu: prepara el preset o, si ya esta activo, muestra sus acciones. */
    private void mangaEntry() {
        final boolean withBase = !mangaNoBase;
        mangaNoBase = false;
        if (!needProject()) return;
        if (canvas.isMangaMode()) {
            canvas.repairMangaInk();
            mangaMenu();
            return;
        }
        final Project p = canvas.getProject();
        int c = canvas.mangaInkCandidate();
        if (c == -2) {
            canvas.prepareManga(-1, withBase);
            afterMangaReady();
            return;
        }
        if (c >= 0) {
            final int idx = c;
            new SheetBuilder(this)
                    .setTitle("Colorear manga")
                    .setMessage("Se prepara asi (el manga original NO cambia):\n\n"
                            + "- \"" + p.layers.get(idx).name + "\" pasa a llamarse \"Tinta B/N\", queda BLOQUEADA y sus lineas "
                            + "marcan los limites del balde.\n"
                            + (withBase ? "- Encima se crea \"Color base\" en Multiplicar: el color no tapa la tinta, los grises ni las tramas.\n\n"
                                    : "- El color va en la capa \"Color zonas\" (se crea sola al pintar).\n\n")
                            + "Luego: elige un color y toca una zona. Veras una vista previa antes de pintar.")
                    .setPositiveButton("Preparar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            if (canvas.prepareManga(idx, withBase)) afterMangaReady();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        // varias capas con dibujo: el usuario elige cual es el manga
        final List<Integer> idxs = new ArrayList<Integer>();
        final List<String> names = new ArrayList<String>();
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            Layer l = p.layers.get(i);
            if (l.bounds(p.w, p.h) == null) continue;
            // v8.55c: las capas de Toques, Luz, Estilo y color no son el manga
            if (l.role != Layer.ROLE_NONE && l.role != Layer.ROLE_INK) continue;
            idxs.add(i);
            names.add(l.name + (l.visible ? "" : " (oculta)"));
        }
        if (idxs.isEmpty()) {
            toast("No hay ninguna capa con dibujo");
            return;
        }
        new SheetBuilder(this)
                .setTitle("¿Cual capa es el manga original?")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (canvas.prepareManga(idxs.get(i), withBase)) afterMangaReady();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** v8.54: el balde de Colorear (zonas / manga). El Relleno de la caja es el balde normal. */
    private void selectColorBucket() {
        canvas.setColorBucket(true);
        selectTool(CanvasView.MODE_BUCKET);
    }

    private void afterMangaReady() {
        selectColorBucket();
        if (layersOpen()) buildLayersPanel();
        updateUi();
        markDirty();
        Runnable h = afterMangaHook;
        afterMangaHook = null;
        if (h != null) h.run();
    }

    /** v8.43: lo que sigue despues de preparar el manga (Colorear facil). */
    private Runnable afterMangaHook;

    // ===================== v8.51: Luz y ambiente + Estilo de edicion: simples y en UNA capa =====================
    // Mientras ajustas se ve una vista previa ENCIMA del lienzo (achicada, rapida): no se crean ni
    // se borran capas. Con ✓ se hace en tamano real y queda UNA sola capa (✦ Luz / ✦ Estilo).
    // Con ✕ no queda nada. Su opacidad (en Capas) es la fuerza; ocultarla = ver como era.

    private static final long FX_PREVIEW_PX = 260_000L;
    /**
     * v8.53: la vista previa se arma a este tamano con el DIBUJO NITIDO (antes todo salia del tamano
     * chico estirado y se veia borroso). Los efectos (suaves) se calculan chicos y se agrandan.
     */
    private static final long FX_MID_PX = 700_000L;
    private int[] fxCompM, fxSceneM;
    private int fxMW, fxMH;

    /** Barra de efectos abierta: 1 = Luz y ambiente, 2 = Estilo. 0 = ninguna. */
    private int fxKind;
    private View fxCard;
    private Project fxProject;
    private int[] fxComp, fxScene, fxCompS, fxSceneS;
    private int fxW, fxH, fxSW, fxSH, fxGen, fxSit;
    private Layer fxBg;
    private com.pacco.animecut.core.Atmos.Preset fxScenePreset;
    private final float[] fxScenePos = new float[2];
    private final com.pacco.animecut.core.Atmos.Params atmosP = new com.pacco.animecut.core.Atmos.Params();
    private final com.pacco.animecut.core.Looks.Params lookP = new com.pacco.animecut.core.Looks.Params();
    /** Luz y ambiente: 0..100 de Fondo, Luz, Sombra y Reflejo. */
    private final int[] atmosK = {70, 55, 50, 0};
    private final Runnable fxRun = new Runnable() { public void run() { fxPreview(); } };

    private void atmosOpen() { fxOpen(1); }

    private void lookOpen() { fxOpen(2); }

    private void atmosClose(boolean keep, boolean notify) { if (fxKind == 1) fxClose(); }

    private void lookClose(boolean keep) { if (fxKind == 2) fxClose(); }

    private void fxOpen(final int kind) {
        if (!needProject()) return;
        if (softCard != null) softClose();
        fxClose();
        hideEasyCard();
        final Project p = canvas.getProject();
        fxProject = p;
        fxKind = kind;
        if (kind == 1) fxHideOldAtmos(p);
        // lo que entra: todas las capas visibles menos las de efectos (✦) de esta herramienta (y,
        // para la luz, tambien el estilo, que va despues)
        final List<Layer> base = new ArrayList<Layer>();
        for (Layer l : p.layers) {
            if (l.role == Layer.ROLE_LOOK) continue;
            if (kind == 1 && l.role == Layer.ROLE_ATMOS) continue;
            base.add(l);
        }
        Layer first = null;
        int vis = 0;
        for (Layer l : base) if (l.visible) { if (first == null) first = l; vis++; }
        final Layer bgCand = kind == 1 && vis >= 2 ? first : null;
        canvas.showHud("Preparando...", 800);
        new Thread(new Runnable() {
            @Override public void run() {
                int[] comp = null, scene = null;
                try {
                    if (bgCand != null) {
                        scene = new int[p.w * p.h];
                        bgCand.copyTo(scene, p.w, p.h);
                        if (com.pacco.animecut.core.Atmos.hasTransparency(scene)) scene = null;
                    }
                    List<Layer> chars = new ArrayList<Layer>(base);
                    if (scene != null) chars.remove(bgCand);
                    comp = new int[p.w * p.h];
                    com.pacco.animecut.core.Compositor.composite(chars, chars.size(), p.w, p.h, 0, 0, p.w, p.h, comp);
                    if (scene != null) fxScenePreset = com.pacco.animecut.core.Atmos.analyze(scene, p.w, p.h, fxScenePos);
                } catch (OutOfMemoryError e) { comp = null; }
                final int[] c = comp, sc = scene;
                int sw = p.w, sh = p.h;
                long n = (long) p.w * p.h;
                if (n > FX_PREVIEW_PX) {
                    float f = (float) Math.sqrt(FX_PREVIEW_PX / (double) n);
                    sw = Math.max(1, Math.round(p.w * f));
                    sh = Math.max(1, Math.round(p.h * f));
                }
                int[] cs = null, ss = null;
                try {
                    if (c != null) cs = sw == p.w ? c : scalePx(c, p.w, p.h, sw, sh);
                    if (sc != null) ss = sw == p.w ? sc : scalePx(sc, p.w, p.h, sw, sh);
                } catch (OutOfMemoryError e) { cs = null; }
                int mw = p.w, mh = p.h;
                if (n > FX_MID_PX) {
                    float f = (float) Math.sqrt(FX_MID_PX / (double) n);
                    mw = Math.max(1, Math.round(p.w * f));
                    mh = Math.max(1, Math.round(p.h * f));
                }
                int[] cm = null, sm = null;
                try {
                    if (c != null) cm = mw == p.w ? c : scalePx(c, p.w, p.h, mw, mh);
                    if (sc != null) sm = mw == p.w ? sc : scalePx(sc, p.w, p.h, mw, mh);
                } catch (OutOfMemoryError e) { cm = null; }
                final int[] fcm = cm, fsm = sm;
                final int fmw = mw, fmh = mh;
                final int[] fcs = cs, fss = ss;
                final int fsw = sw, fsh = sh;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (canvas.getProject() != p || fxKind != kind) return;
                        if (c == null || fcs == null) { toast("Falta memoria"); fxClose(); return; }
                        fxComp = c; fxScene = sc; fxCompS = fcs; fxSceneS = fss;
                        fxW = p.w; fxH = p.h; fxSW = fsw; fxSH = fsh;
                        fxCompM = fcm != null ? fcm : fcs; fxSceneM = fcm != null ? fsm : fss;
                        fxMW = fcm != null ? fmw : fsw; fxMH = fcm != null ? fmh : fsh;
                        fxBg = sc != null ? bgCand : null;
                        if (kind == 1) {
                            fxSit = com.pacco.animecut.core.Atmos.situation(c, sc);
                            atmosP.scene = null;
                            if (fxSit == 2 && fxScenePreset != null) {
                                atmosP.preset = fxScenePreset;
                                atmosP.sunX = fxScenePos[0];
                                atmosP.sunY = fxScenePos[1];
                            } else if ("Escena".equals(atmosP.preset.name)) {
                                atmosP.preset = com.pacco.animecut.core.Atmos.PRESETS[0];
                            }
                            selectToolNow(CanvasView.MODE_PAN);
                            canvas.setTapPick(new CanvasView.TapPick() {
                                @Override public void onPick(float fx, float fy) {
                                    atmosP.sunX = Math.max(-0.2f, Math.min(1.2f, fx));
                                    atmosP.sunY = Math.max(-0.2f, Math.min(1.2f, fy));
                                    fxSoon(0);
                                }
                            });
                        } else {
                            boolean mono = com.pacco.animecut.core.Looks.isMono(c);
                            if (!mono && lookP.look.map) lookP.look = com.pacco.animecut.core.Looks.LOOKS[0];
                            if (mono && !lookP.look.map) lookP.look = com.pacco.animecut.core.Looks.LOOKS[1];
                        }
                        fxShowCard();
                        fxSoon(0);
                    }
                });
            }
        }, "pz-fx").start();
    }

    private void fxSoon(long ms) {
        canvas.removeCallbacks(fxRun);
        canvas.postDelayed(fxRun, ms);
    }

    /** v8.53: Luz y ambiente en capas solo de efecto (fondo, tono, sombra, luz). */
    private static int[][] fxGroups(int[] comp, int[] scene, int w, int h, com.pacco.animecut.core.Atmos.Params ap) {
        com.pacco.animecut.core.Atmos.Params q = ap.copy();
        q.scene = scene;
        int[][] fx = com.pacco.animecut.core.Atmos.render(comp, w, h, q, null);
        return fx == null ? null : com.pacco.animecut.core.Atmos.groups(fx, w, h);
    }

    /** Calcula el resultado en una imagen (a tamano w x h). */
    private int[] fxCompute(int kind, int[] comp, int[] scene, int w, int h,
                            com.pacco.animecut.core.Atmos.Params ap, com.pacco.animecut.core.Looks.Params lp) {
        if (kind == 1) {
            com.pacco.animecut.core.Atmos.Params q = ap.copy();
            q.scene = scene;
            int[][] fx = com.pacco.animecut.core.Atmos.render(comp, w, h, q, null);
            if (fx == null) return null;
            return com.pacco.animecut.core.Atmos.compose(comp, fx, w, h, scene);
        }
        int[][] fx = com.pacco.animecut.core.Looks.render(comp, w, h, lp);
        return com.pacco.animecut.core.Looks.compose(comp, fx, w, h);
    }

    private void fxApplySettings() {
        if (fxKind == 1) com.pacco.animecut.core.Atmos.setSimple(atmosP, fxSit, atmosK[0], atmosK[1], atmosK[2], atmosK[3]);
    }

    /** v8.59: un solo hilo para la vista previa; lo viejo se salta o se corta (sin cola). */
    private final java.util.concurrent.ExecutorService fxExec = java.util.concurrent.Executors.newSingleThreadExecutor();
    /** Capas ✦ de una luz anterior que se esconden mientras se prueba la nueva. */
    private final List<Layer> fxHiddenAtmos = new ArrayList<Layer>();

    /**
     * Vista previa encima del lienzo (rapida: no toca capas).
     * v8.59 Luz: el dibujo de la pantalla queda NITIDO y solo se dibujan encima los efectos
     * (sombra en Multiplicar, luz en Superponer, brillo en Trama), igual que las capas ✦ que
     * quedan al aceptar. Antes se mostraba el dibujo entero en una copia chica estirada (borroso).
     */
    private void fxPreview() {
        final Project p = canvas.getProject();
        if (p == null || p != fxProject || fxCompS == null || fxCard == null) return;
        fxApplySettings();
        final int gen = ++fxGen, kind = fxKind;
        final int[] comp = fxCompS, scene = fxSceneS, compM = fxCompM, sceneM = fxSceneM;
        final int w = fxSW, h = fxSH, mw = fxMW, mh = fxMH;
        final com.pacco.animecut.core.Atmos.Params ap = atmosP.copy();
        final com.pacco.animecut.core.Looks.Params lp = lookP.copy();
        fxExec.execute(new Runnable() {
            @Override public void run() {
                if (gen != fxGen) return;
                Bitmap b = null;
                Bitmap[] eff = null;
                int[] effModes = null;
                try {
                    int[] o = null;
                    if (kind == 1) {
                        com.pacco.animecut.core.Atmos.Params q = ap.copy();
                        q.scene = scene;
                        int[][] fx = com.pacco.animecut.core.Atmos.render(comp, w, h, q,
                                new com.pacco.animecut.core.Atmos.Progress() {
                                    @Override public boolean step(int pct) { return gen == fxGen; }
                                });
                        if (gen != fxGen) return;
                        int[][] g = fx == null ? null : com.pacco.animecut.core.Atmos.groups(fx, w, h);
                        if (g == null) return;
                        boolean fondo = g[com.pacco.animecut.core.Atmos.G_FONDO] != null
                                && !allClear(g[com.pacco.animecut.core.Atmos.G_FONDO]);
                        if (android.os.Build.VERSION.SDK_INT >= 29 && scene == null && !fondo) {
                            int cnt = 0;
                            for (int k = 0; k < g.length; k++) if (k != com.pacco.animecut.core.Atmos.G_FONDO && g[k] != null) cnt++;
                            eff = new Bitmap[cnt];
                            effModes = new int[cnt];
                            int j = 0;
                            for (int k = 0; k < g.length; k++) {
                                if (k == com.pacco.animecut.core.Atmos.G_FONDO || g[k] == null) continue;
                                eff[j] = Bitmap.createBitmap(g[k], w, h, Bitmap.Config.ARGB_8888);
                                effModes[j] = com.pacco.animecut.core.Atmos.G_MODES[k];
                                j++;
                            }
                        } else {
                            if (mw != w || mh != h)
                                for (int k = 0; k < g.length; k++) if (g[k] != null) g[k] = scalePx(g[k], w, h, mw, mh);
                            o = com.pacco.animecut.core.Atmos.composeGroups(compM, sceneM, g, mw, mh);
                        }
                    } else {
                        int[][] fx = com.pacco.animecut.core.Looks.render(compM, mw, mh, lp);
                        o = com.pacco.animecut.core.Looks.compose(compM, fx, mw, mh);
                    }
                    if (o != null && gen == fxGen) b = Bitmap.createBitmap(o, mw, mh, Bitmap.Config.ARGB_8888);
                } catch (OutOfMemoryError e) { b = null; eff = null; }
                final Bitmap fb = b;
                final Bitmap[] fe = eff;
                final int[] fm = effModes;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (gen != fxGen || canvas.getProject() != p || fxCard == null) {
                            if (fb != null) fb.recycle();
                            return;
                        }
                        if (fe != null) { canvas.setPreviewOver(null); canvas.setPreviewEffects(fe, fm); }
                        else if (fb != null) { canvas.setPreviewEffects(null, null); canvas.setPreviewOver(fb); }
                    }
                });
            }
        });
    }

    private static boolean allClear(int[] a) {
        for (int v : a) if ((v >>> 24) != 0) return false;
        return true;
    }

    /** Esconde las capas ✦ de una luz anterior mientras se prueba otra (se devuelven al cancelar). */
    private void fxHideOldAtmos(Project p) {
        fxHiddenAtmos.clear();
        for (Layer l : p.layers) if (l.role == Layer.ROLE_ATMOS && l.visible) { l.visible = false; fxHiddenAtmos.add(l); }
        if (!fxHiddenAtmos.isEmpty()) canvas.refreshDisplayAsync();
    }

    private void fxRestoreOldAtmos() {
        Project p = canvas.getProject();
        boolean any = false;
        for (Layer l : fxHiddenAtmos) if (p != null && p.layers.contains(l)) { l.visible = true; any = true; }
        fxHiddenAtmos.clear();
        if (any) canvas.refreshDisplayAsync();
    }

    /** ✓: en tamano real, UNA capa. Se reemplaza la anterior de la misma herramienta. */
    private void fxFinish() {
        final Project p = canvas.getProject();
        if (p == null || p != fxProject || fxComp == null) { fxClose(); return; }
        fxApplySettings();
        final int gen = ++fxGen, kind = fxKind;
        final int[] comp = fxComp, scene = fxScene;
        final int W = fxW, H = fxH;
        final com.pacco.animecut.core.Atmos.Params ap = atmosP.copy();
        final com.pacco.animecut.core.Looks.Params lp = lookP.copy();
        if (fxCard != null && fxCard.getParent() instanceof ViewGroup) ((ViewGroup) fxCard.getParent()).removeView(fxCard);
        final Busy busy = new Busy(kind == 1 ? "Luz y ambiente" : "Estilo");
        busy.set(-1, "Terminando...");
        new Thread(new Runnable() {
            @Override public void run() {
                int[] o = null;
                int[][] gr = null;
                try {
                    if (kind == 1) gr = fxGroups(comp, scene, W, H, ap);
                    else o = fxCompute(kind, comp, scene, W, H, ap, lp);
                } catch (OutOfMemoryError e) { o = null; gr = null; }
                final int[] res = o;
                final int[][] groups = gr;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        busy.close();
                        if (canvas.getProject() != p || busy.cancel[0]) { fxClose(); return; }
                        if (kind == 1) { fxFinishLight(p, groups, W, H); return; }
                        if (res == null) { toast("Falta memoria para hacerlo en tamano real"); fxClose(); return; }
                        int role = kind == 1 ? Layer.ROLE_ATMOS : Layer.ROLE_LOOK;
                        canvas.recordStructUndo(kind == 1 ? "Luz y ambiente" : "Estilo");
                        Layer act = p.activeLayer();
                        for (int i = p.layers.size() - 1; i >= 0; i--) if (p.layers.get(i).role == role) p.layers.remove(i);
                        Layer l = new Layer(kind == 1 ? "✦ Luz" : "✦ Estilo", res);
                        l.role = role;
                        l.pack(W, H);
                        int at = p.layers.size();
                        if (kind == 1) {   // la luz va debajo del estilo
                            for (int i = 0; i < p.layers.size(); i++) if (p.layers.get(i).role == Layer.ROLE_LOOK) { at = i; break; }
                        }
                        p.layers.add(at, l);
                        if (kind == 1) for (Layer o2 : p.layers) if (o2.role == Layer.ROLE_LOOK && o2.visible) {
                            o2.visible = false;   // el estilo de antes ya no calza: se oculta (vuelve a aplicarlo)
                            canvas.showHud("Estilo ocultado: vuelve a aplicarlo encima de la luz nueva", 2500);
                        }
                        int ai = act == null ? -1 : p.layers.indexOf(act);
                        p.active = ai >= 0 ? ai : p.layers.indexOf(l);
                        canvas.layersChanged();
                        markDirty();
                        fxClose();
                        toast("Listo: una capa " + l.name + ". Su opacidad es la fuerza");
                    }
                });
            }
        }, "pz-fx-f").start();
    }

    /**
     * v8.53: Luz y ambiente deja capas que SOLO tienen el efecto; tu dibujo queda igual y nitido:
     * ✦ Fondo (debajo del personaje, si esta recortado), ✦ Tono (solo con foto), ✦ Sombra
     * (Multiplicar) y ✦ Luz (Pantalla). Se reemplazan las de antes. Su opacidad es la fuerza.
     */
    private void fxFinishLight(Project p, int[][] g, int W, int H) {
        if (g == null) { toast("Falta memoria para hacerlo en tamano real"); fxClose(); return; }
        for (Layer l : fxHiddenAtmos) l.visible = true;      // el deshacer las guarda como estaban
        fxHiddenAtmos.clear();
        canvas.recordStructUndo("Luz y ambiente");
        Layer act = p.activeLayer();
        for (int i = p.layers.size() - 1; i >= 0; i--) if (p.layers.get(i).role == Layer.ROLE_ATMOS) p.layers.remove(i);
        int made = 0;
        for (int k = 0; k < com.pacco.animecut.core.Atmos.G_N; k++) {
            if (g[k] == null) continue;
            Layer l = new Layer(com.pacco.animecut.core.Atmos.G_NAMES[k], g[k]);
            l.role = Layer.ROLE_ATMOS;
            l.mode = com.pacco.animecut.core.Atmos.layerMode(com.pacco.animecut.core.Atmos.G_MODES[k]);
            l.pack(W, H);
            if (l.isEmptyPacked()) continue;
            int at;
            if (k == com.pacco.animecut.core.Atmos.G_FONDO) {
                at = fxBg != null && p.layers.contains(fxBg) ? p.layers.indexOf(fxBg) + 1 : 0;
            } else {
                at = p.layers.size();
                for (int i = 0; i < p.layers.size(); i++) if (p.layers.get(i).role == Layer.ROLE_LOOK) { at = i; break; }
            }
            p.layers.add(at, l);
            made++;
        }
        for (Layer o2 : p.layers) if (o2.role == Layer.ROLE_LOOK && o2.visible) {
            o2.visible = false;   // el estilo de antes ya no calza: se oculta (vuelve a aplicarlo)
            canvas.showHud("Estilo ocultado: vuelve a aplicarlo encima de la luz nueva", 2500);
        }
        int ai = act == null ? -1 : p.layers.indexOf(act);
        p.active = ai >= 0 ? ai : Math.max(0, p.layers.size() - 1);
        canvas.layersChanged();
        markDirty();
        fxClose();
        toast(made == 0 ? "No quedo ningun efecto (sube Luz o Sombra)"
                : "Listo: tu dibujo no cambio. Luz, brillo y sombra quedaron en capas ✦ aparte");
    }

    private void fxClose() {
        canvas.removeCallbacks(fxRun);
        fxGen++;
        boolean was = fxKind != 0;
        if (fxKind == 1) canvas.setTapPick(null);
        fxKind = 0;
        if (fxCard != null && fxCard.getParent() instanceof ViewGroup) ((ViewGroup) fxCard.getParent()).removeView(fxCard);
        fxCard = null;
        fxComp = fxScene = fxCompS = fxSceneS = fxCompM = fxSceneM = null;
        fxBg = null;
        canvas.setPreviewOver(null);
        canvas.setPreviewEffects(null, null);
        fxRestoreOldAtmos();
        if (was) {
            if (layersOpen()) buildLayersPanel();
            updateUi();
        }
    }

    /** Boton icono que se ve prendido o apagado. */
    private ImageButton fxToggle(int icon, String what, boolean on, Runnable r) {
        ImageButton b = iconButton(icon, what, r);
        b.setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_cell);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    /** Fila: icono + deslizador (mantener pulsado el icono dice que es). */
    private View iconSlider(int icon, String what, int value, final IntConsumerCompat on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton ib = iconButton(icon, what, new Runnable() { public void run() { } });
        ib.setBackground(null);
        row.addView(ib, new LinearLayout.LayoutParams(dp(34), dp(34)));
        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(value);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) { if (u) on.accept(p); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(34), 1f));
        return row;
    }

    /** Deslizador con texto (lo usa la fuerza de Colorear facil). */
    private View atmosSlider(String name, int value, final IntConsumerCompat on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(12f);
        row.addView(t, new LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT));
        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(value);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) { if (u) on.accept(p); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(34), 1f));
        return row;
    }

    private TextView fxChip(String t, boolean on, final Runnable r) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(12.5f);
        b.setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_cell);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        return b;
    }

    /** La barra: arriba los estilos/ambientes + ✓ ✕; abajo iconos y deslizadores. Poco texto. */
    private void fxShowCard() {
        if (fxCard != null && fxCard.getParent() instanceof ViewGroup) ((ViewGroup) fxCard.getParent()).removeView(fxCard);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_panel);
        card.getBackground().setAlpha(225);
        card.setPadding(dp(6), dp(4), dp(6), dp(4));
        card.setClickable(true);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if (fxKind == 1) {
            if (fxSit == 2 && fxScenePreset != null)
                row.addView(fxChip("Foto", atmosP.preset == fxScenePreset, new Runnable() { public void run() {
                    atmosP.preset = fxScenePreset; atmosP.sunX = fxScenePos[0]; atmosP.sunY = fxScenePos[1];
                    fxShowCard(); fxSoon(0); }}));
            for (final com.pacco.animecut.core.Atmos.Preset pr : com.pacco.animecut.core.Atmos.PRESETS)
                row.addView(fxChip(pr.name, atmosP.preset == pr, new Runnable() { public void run() {
                    atmosP.preset = pr; fxShowCard(); fxSoon(0); }}));
        } else {
            for (final com.pacco.animecut.core.Looks.Look lk : com.pacco.animecut.core.Looks.LOOKS)
                row.addView(fxChip(lk.name, lookP.look == lk, new Runnable() { public void run() {
                    lookP.look = lk; fxShowCard(); fxSoon(0); }}));
        }
        hs.addView(row);
        head.addView(hs, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ImageButton ok = iconButton(R.drawable.ic_check, "Listo", new Runnable() { public void run() { fxFinish(); } });
        ok.setBackgroundResource(R.drawable.bg_save);
        head.addView(ok, new LinearLayout.LayoutParams(dp(38), dp(38)));
        ImageButton no = iconButton(R.drawable.ic_close, "Cancelar", new Runnable() { public void run() { fxClose(); } });
        no.setBackground(null);
        head.addView(no, new LinearLayout.LayoutParams(dp(36), dp(36)));
        card.addView(head);
        LinearLayout tg = new LinearLayout(this);
        tg.setOrientation(LinearLayout.HORIZONTAL);
        if (fxKind == 1) {
            tg.addView(fxToggle(R.drawable.ic_tone, "Blanco y negro (manga): solo luz y sombra", atmosP.mono, new Runnable() { public void run() {
                atmosP.mono = !atmosP.mono; fxShowCard(); fxSoon(0); }}));
            tg.addView(fxToggle(R.drawable.ic_redo, "Otras nubes y destellos", false, new Runnable() { public void run() {
                atmosP.seed = atmosP.seed * 31 + 17; fxSoon(0); }}));
            card.addView(tg);
            if (fxSit == 0) card.addView(iconSlider(R.drawable.ic_image, "Fondo: cielo, nubes, sol y rayos", atmosK[0], new IntConsumerCompat() {
                public void accept(int v) { atmosK[0] = v; fxSoon(0); } }));
            card.addView(iconSlider(R.drawable.ic_light, "Luz: del lado del sol, contraluz y brillo", atmosK[1], new IntConsumerCompat() {
                public void accept(int v) { atmosK[1] = v; fxSoon(0); } }));
            card.addView(iconSlider(R.drawable.ic_shadow, "Sombra: del otro lado, bordes y suelo", atmosK[2], new IntConsumerCompat() {
                public void accept(int v) { atmosK[2] = v; fxSoon(0); } }));
            if (fxSit == 0) card.addView(iconSlider(R.drawable.ic_mirror, "Reflejo en el agua", atmosK[3], new IntConsumerCompat() {
                public void accept(int v) { atmosK[3] = v; fxSoon(0); } }));
            TextView tip = new TextView(this);
            tip.setText("Toca el dibujo: ahi va la luz");
            tip.setTextColor(0xFF9FC6FF);
            tip.setTextSize(11.5f);
            card.addView(tip);
        } else {
            final com.pacco.animecut.core.Looks.Params P = lookP;
            tg.addView(fxToggle(R.drawable.ic_tone, "Grano", P.grain > 0, new Runnable() { public void run() {
                P.grain = P.grain > 0 ? 0 : 45; fxShowCard(); fxSoon(0); }}));
            tg.addView(fxToggle(R.drawable.ic_sparkle, "Particulas de luz", P.particles > 0, new Runnable() { public void run() {
                P.particles = P.particles > 0 ? 0 : 45; P.seed = P.seed * 31 + 7; fxShowCard(); fxSoon(0); }}));
            tg.addView(fxToggle(R.drawable.ic_hue, "Borde RGB", P.rgb > 0, new Runnable() { public void run() {
                P.rgb = P.rgb > 0 ? 0 : 35; fxShowCard(); fxSoon(0); }}));
            if (P.look.map) tg.addView(fxToggle(R.drawable.ic_color, "Lo pintado de color (ojos) se queda de color", P.keepColor, new Runnable() { public void run() {
                P.keepColor = !P.keepColor; fxShowCard(); fxSoon(0); }}));
            card.addView(tg);
            card.addView(iconSlider(R.drawable.ic_opacity, "Fuerza del estilo", P.strength, new IntConsumerCompat() {
                public void accept(int v) { P.strength = v; fxSoon(0); } }));
            card.addView(iconSlider(R.drawable.ic_light, "Brillo", P.glow, new IntConsumerCompat() {
                public void accept(int v) { P.glow = v; fxSoon(0); } }));
            card.addView(iconSlider(R.drawable.ic_shadow, "Bordes oscuros", P.vignette, new IntConsumerCompat() {
                public void accept(int v) { P.vignette = v; fxSoon(0); } }));
        }
        placeCard(card);
        fxCard = card;
    }

    private static int[] scalePx(int[] px, int w, int h, int nw, int nh) {
        Bitmap a = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
        Bitmap b = Bitmap.createScaledBitmap(a, nw, nh, true);
        a.recycle();
        int[] o = new int[nw * nh];
        b.getPixels(o, 0, nw, 0, 0, nw, nh);
        b.recycle();
        return o;
    }

    // ===================== v8.52: Toques suaves (rubor de Procreate, "dar vida" de Ibis) =====================
    private View softCard;
    private int softSel = CanvasView.SOFT_COLOR;
    private Layer softOver;
    private float softPrevSize = -1f, softPrevHard = -1f, softPrevOp = -1f;
    /** Colores de cada tipo. Color: la tecnica arcoiris (rojo mejillas, amarillo frente, azul menton...). */
    private static final int[][] SOFT_SWATCHES = {
            {0xFFFF5A6E, 0xFFFF8FA3, 0xFFFFB08A, 0xFFFFE07A, 0xFF7FD6C0, 0xFF6FB2FF, 0xFFB58CFF},
            {0xFF9A8FB8, 0xFF7C6FA8, 0xFF6F86B8, 0xFFB07A8A, 0xFF8A6A5A},
            {0xFFFFFFFF, 0xFFFFF2D6, 0xFFFFD27F, 0xFFFFB3C7, 0xFFBFE6FF}};
    private static final String[] SOFT_TIP = {
            "Mejillas rojo, frente amarillo, menton azul: se funden solos",
            "Sombra suave: pinta donde no llega la luz",
            "Luz: blanco o crema donde da la luz (da vida)"};

    /** kind = -1: el ultimo usado. */
    private void softOpen(int kind) {
        if (!needProject()) return;
        if (fxKind != 0) fxClose();
        if (canvas.hasFillPreview()) canvas.acceptFillPreview();
        if (canvas.isRayMode()) canvas.setRayMode(false);
        removeEasyCardView();
        Project p = canvas.getProject();
        Layer a = p.activeLayer();
        if (softCard == null) {
            softOver = a != null && a.role != Layer.ROLE_SOFT ? a : null;
            softPrevSize = canvas.getBrushSize();
            softPrevHard = canvas.getHardness();
            softPrevOp = canvas.getBrushOpacity();
            canvas.setBrushDynamics(0f, 0f, 0f, 0, 0f, 0.10f, 0f);   // brocha suave: sin punta fina ni grano
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            canvas.setSoftBlend(sp.getInt("soft_blend", 60));
            float big = Math.max(24f, Math.min(260f, Math.max(p.w, p.h) * 0.07f));
            canvas.setBrushSize(sp.getFloat("soft_size", big));
            canvas.setHardness(0.15f);
        }
        softSelect(kind < 0 ? getSharedPreferences("pz", MODE_PRIVATE).getInt("soft_kind", CanvasView.SOFT_COLOR) : kind);
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (!sp.getBoolean("soft_seen", false)) {
            sp.edit().putBoolean("soft_seen", true).apply();
            canvas.showHud("Pinta manchas grandes: al soltar se funden. La flecha las deja dentro del color", 3500);
        }
    }

    private void softSelect(int kind) {
        softSel = kind;
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("soft_kind", kind).apply();
        Layer l = canvas.softLayer(kind, softOver);
        if (l == null) return;
        int c = getSharedPreferences("pz", MODE_PRIVATE).getInt("soft_col" + kind, SOFT_SWATCHES[kind][0]);
        canvas.setColor(c | 0xFF000000);
        canvas.setBrushOpacity(1f);
        if (canvas.getMode() != CanvasView.MODE_ERASER) selectTool(CanvasView.MODE_PAINT);
        syncSlider();
        afterLayerOp();
        showSoftCard();
    }

    private Layer softLayerNow() {
        Project p = canvas.getProject();
        Layer a = p == null ? null : p.activeLayer();
        return a != null && a.role == Layer.ROLE_SOFT ? a : null;
    }

    private void softClose() {
        if (softCard != null && softCard.getParent() instanceof ViewGroup) ((ViewGroup) softCard.getParent()).removeView(softCard);
        boolean was = softCard != null;
        softCard = null;
        if (!was) return;
        getSharedPreferences("pz", MODE_PRIVATE).edit().putFloat("soft_size", canvas.getBrushSize()).apply();
        if (softPrevSize > 0f) canvas.setBrushSize(softPrevSize);
        if (softPrevHard > 0f) canvas.setHardness(softPrevHard);
        if (softPrevOp > 0f) canvas.setBrushOpacity(softPrevOp);
        softPrevSize = softPrevHard = softPrevOp = -1f;
        int bi = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset4", 0);
        applyBrushPreset(bi, false);   // vuelve la forma de trazo del pincel que tenias
        canvas.dropEmptySoftLayers();
        syncSlider();
        afterLayerOp();
    }

    private void showSoftCard() {
        if (softCard != null && softCard.getParent() instanceof ViewGroup) ((ViewGroup) softCard.getParent()).removeView(softCard);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_panel);
        card.getBackground().setAlpha(225);
        card.setPadding(dp(6), dp(4), dp(6), dp(4));
        card.setClickable(true);
        // fila 1: tipo (color / sombra / luz), mezclar todo, borrar, ✓
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        int[] icons = {R.drawable.ic_soft, R.drawable.ic_shadow, R.drawable.ic_light};
        String[] what = {"Color (rubor, piel natural)", "Sombra suave (Multiplicar)", "Luz: dar vida (Superponer)"};
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            head.addView(fxToggle(icons[k], what[k], softSel == k, new Runnable() { public void run() { softSelect(kk); } }));
        }
        final boolean erasing = canvas.getMode() == CanvasView.MODE_ERASER;
        head.addView(fxToggle(R.drawable.ic_eraser, "Goma suave", erasing, new Runnable() { public void run() {
            selectTool(erasing ? CanvasView.MODE_PAINT : CanvasView.MODE_ERASER);
            showSoftCard();
        }}));
        {   // v8.69: con su nombre a la vista ("la gota" no se entendia)
            ImageButton fb = fxToggle(R.drawable.ic_blur, "Fundir todo: difumina todos los toques de esta capa", false, new Runnable() { public void run() {
                Layer l = softLayerNow();
                if (l != null) { canvas.blurLayer(l, 25); afterLayerOp(); }
            }});
            LinearLayout fcol = new LinearLayout(this);
            fcol.setOrientation(LinearLayout.VERTICAL);
            fcol.setGravity(Gravity.CENTER_HORIZONTAL);
            fb.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(32)));
            fcol.addView(fb);
            TextView ft = new TextView(this);
            ft.setText("Fundir");
            ft.setTextSize(9);
            ft.setTextColor(0xFFDDE3EA);
            ft.setGravity(Gravity.CENTER);
            fcol.addView(ft, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            flp.setMargins(dp(2), 0, dp(2), 0);
            head.addView(fcol, flp);
        }
        head.addView(fxToggle(R.drawable.ic_trash, "Borrar estos toques", false, new Runnable() { public void run() {
            if (softLayerNow() != null) { canvas.clearActive(); afterLayerOp(); }
        }}));
        ImageButton ok = iconButton(R.drawable.ic_check, "Listo", new Runnable() { public void run() { softClose(); } });
        ok.setBackgroundResource(R.drawable.bg_save);
        head.addView(ok, new LinearLayout.LayoutParams(dp(40), dp(40)));
        card.addView(head);
        // fila 2: colores del tipo + mas colores
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout sw = new LinearLayout(this);
        sw.setOrientation(LinearLayout.HORIZONTAL);
        sw.setGravity(Gravity.CENTER_VERTICAL);
        int cur = canvas.getColor() | 0xFF000000;
        for (final int c : SOFT_SWATCHES[softSel]) sw.addView(softDot(c, cur == c));
        boolean custom = true;
        for (int c : SOFT_SWATCHES[softSel]) if (c == cur) custom = false;
        if (custom) sw.addView(softDot(cur, true));
        ImageButton more = iconButton(R.drawable.ic_add, "Otro color", new Runnable() { public void run() {
            colorDialog(new ColorPickTarget() { @Override public void onColor(int color) { softSetColor(color); } },
                    canvas.getColor(), "Color del toque");
        }});
        more.setBackground(null);
        sw.addView(more, new LinearLayout.LayoutParams(dp(36), dp(36)));
        hs.addView(sw);
        card.addView(hs);
        // fila 3 y 4: fundir y fuerza (opacidad de la capa)
        card.addView(iconSlider(R.drawable.ic_blur, "Fundir: cuanto se difumina cada trazo al soltar", canvas.getSoftBlend(), new IntConsumerCompat() {
            public void accept(int v) {
                canvas.setSoftBlend(v);
                getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("soft_blend", v).apply();
            } }));
        Layer l = softLayerNow();
        card.addView(iconSlider(R.drawable.ic_opacity, "Fuerza de los toques", l == null ? 60 : Math.round(l.opacity * 100f / 255f), new IntConsumerCompat() {
            public void accept(int v) {
                Layer t = softLayerNow();
                if (t == null) return;
                t.opacity = Math.max(3, Math.round(v * 2.55f));
                canvas.layersChangedAsync();
            } }));
        TextView tip = new TextView(this);
        tip.setText(SOFT_TIP[softSel]);
        tip.setTextColor(0xFF9FC6FF);
        tip.setTextSize(11.5f);
        card.addView(tip);
        placeCard(card);
        softCard = card;
    }

    private View softDot(final int c, boolean on) {
        View v = new View(this);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(c);
        g.setStroke(dp(on ? 3 : 1), on ? 0xFF64B5F6 : 0xFF55555C);
        v.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(32), dp(32));
        lp.setMargins(dp(3), dp(2), dp(3), dp(2));
        v.setLayoutParams(lp);
        v.setContentDescription(com.pacco.animecut.core.ColorTools.toHex(c));
        v.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { softSetColor(c); } });
        return v;
    }

    private void softSetColor(int c) {
        canvas.setColor(c | 0xFF000000);
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("soft_col" + softSel, c | 0xFF000000).apply();
        if (canvas.getMode() == CanvasView.MODE_ERASER) selectTool(CanvasView.MODE_PAINT);
        SharedPreferencesHolder.pushRecent(this, c);
        showSoftCard();
        updateUi();
    }

    // ===================== v8.43: Colorear facil (3 pasos) =====================
    private View easyCard;
    private int easyStep;
    /** Acabado elegido en el paso 2 (de entrada: Suave). */
    private int easyFinish = com.pacco.animecut.core.ZoneTone.SOFT;

    /** Entrada: prepara las capas sola (si hace falta), prende Color por zonas y muestra el paso 1. */
    private void easyColorStart() {
        if (!needProject()) return;
        if (softCard != null) softClose();
        Runnable go = new Runnable() {
            public void run() {
                canvas.setZoneMode(true);
                easyListen();                // v9.00
                selectColorBucket();
                easyResetTool();
                easyBase(canvas.getZoneStyle().base);
                easyStep = canvas.getProject().zones.isEmpty() ? 1 : 2;
                if (easyStep == 2) finishOpen();
                showEasyCard();
                updateUi();
                easyDemo(false);
            }
        };
        // v8.66: el color va en "Color zonas": no se crea el "Color base" (quedaba vacio encima)
        if (canvas.isMangaMode()) { canvas.repairMangaInk(); canvas.prepareManga(-1, false); go.run(); return; }
        int c = canvas.mangaInkCandidate();
        if (c == -2) { if (canvas.prepareManga(-1, false)) { afterMangaHook = go; afterMangaReady(); } return; }
        if (c >= 0) { if (canvas.prepareManga(c, false)) { afterMangaHook = go; afterMangaReady(); } return; }
        afterMangaHook = go;   // varias capas: se elige cual es el manga y luego sigue sola
        mangaNoBase = true;
        mangaEntry();
    }

    /** Paso 1: el color base elegido (sombra y luz salen solas; acabado plano). */
    private void easyBase(int color) {
        com.pacco.animecut.core.ZoneTone.Style st = com.pacco.animecut.core.ZoneTone.easyStyle(color,
                com.pacco.animecut.core.ZoneTone.MULTIPLY, canvas.getZoneStyle().copy());
        canvas.setColor(color | 0xFF000000);
        if (canvas.isRayMode()) canvas.setRayColor(color);
        setZoneStyleUi(st);
    }

    // ---------------- v8.44: paletas, rayar y retoques ----------------
    /** Paletas que vienen con la app: {nombre}, {parte, RRGGBB}... */
    private static final String[][][] EASY_PALETTES = {
            {{"Básica anime"}, {"Piel", "FFDFCC"}, {"Piel morena", "D9A07A"}, {"Pelo negro", "2B2D45"}, {"Castaño", "8B5E3C"},
                    {"Rubio", "E8C46A"}, {"Rosa", "E88AA8"}, {"Blanco", "F4F4F7"}, {"Rojo", "8E1F3F"}, {"Azul", "2F4A8C"},
                    {"Verde", "3F7A4A"}, {"Gris", "8A8D96"}, {"Negro", "2A2933"}, {"Marrón", "5A3A2A"}, {"Ojos", "B0303A"}},
            {{"Colegiala pelo negro"}, {"Pelo", "2B2D45"}, {"Piel", "FFDCC8"}, {"Ojos", "B0303A"}, {"Saco", "8E1F3F"}, {"Camisa", "F4F4F7"},
                    {"Moño", "2F4A8C"}, {"Falda", "F3F3F6"}, {"Medias", "2A2933"}, {"Zapatos", "5A3A2A"}},
            {{"Colegial pelo castaño"}, {"Pelo", "8B5E3C"}, {"Piel", "FFDCC8"}, {"Ojos", "7A4A2E"}, {"Saco", "8E1F3F"}, {"Camisa", "F4F4F7"},
                    {"Corbata", "2B3A6E"}, {"Pantalón", "3A3D4A"}, {"Zapatos", "2A201C"}},
            {{"Fondos y escenarios"}, {"Cielo", "9CC7EA"}, {"Pared", "EDE3D4"}, {"Piso", "F2E4D2"}, {"Madera", "8C6B4D"}, {"Árboles", "4C7A4A"},
                    {"Edificio", "D7D0C2"}, {"Metal", "C9CDD4"}, {"Noche", "2E3A5C"}}
    };

    /** Todas las paletas: las de la app y las guardadas por ti. */
    private List<String[][]> easyPalettes() {
        List<String[][]> out = new ArrayList<String[][]>();
        for (String[][] p : EASY_PALETTES) out.add(p);
        String saved = getSharedPreferences("pz", MODE_PRIVATE).getString("easy_palettes", "");
        for (String one : saved.split(";")) {
            if (one.isEmpty() || !one.contains("|")) continue;
            String[] np = one.split("\\|", 2);
            List<String[]> rows = new ArrayList<String[]>();
            rows.add(new String[]{np[0]});
            for (String it : np[1].split(",")) {
                String[] kv = it.split(":");
                if (kv.length == 2 && kv[1].matches("[0-9A-Fa-f]{6}")) rows.add(kv);
            }
            if (rows.size() > 1) out.add(rows.toArray(new String[0][]));
        }
        return out;
    }

    private String[][] easyPalette() {
        String want = getSharedPreferences("pz", MODE_PRIVATE).getString("easy_pal", "Básica anime");
        // v8.66: nombres nuevos (antes eran nombres de personajes)
        if (want.equals("Horikita")) want = "Colegiala pelo negro";
        else if (want.equals("Ayanokouji")) want = "Colegial pelo castaño";
        else if (want.equals("Fondos")) want = "Fondos y escenarios";
        List<String[][]> all = easyPalettes();
        for (String[][] p : all) if (p[0][0].equals(want)) return p;
        return all.get(0);
    }

    private void easyPaletteDialog() {
        final List<String[][]> all = easyPalettes();
        String[] names = new String[all.size()];
        for (int i = 0; i < names.length; i++) {
            // v8.66: se ve para que sirve cada una (las partes que trae)
            String[][] pl = all.get(i);
            StringBuilder parts = new StringBuilder();
            for (int k = 1; k < pl.length && k <= 6; k++) { if (k > 1) parts.append(", "); parts.append(pl[k][0].toLowerCase(Locale.ROOT)); }
            if (pl.length > 7) parts.append("...");
            names[i] = pl[0][0] + " (" + (pl.length - 1) + " colores)\n   " + parts;
        }
        new SheetBuilder(this).setTitle("Paletas: cambian los colores de la fila")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putString("easy_pal", all.get(i)[0][0]).apply();
                        showEasyCard();
                    }
                }).setNegativeButton("Cerrar", null).show();
    }

    /** Guarda los colores de esta obra (los de sus zonas) como una paleta con nombre. */
    private void easySavePalette() {
        Project p = canvas.getProject();
        if (p == null || p.zones.isEmpty()) { toast("Primero pinta algunas partes"); return; }
        final StringBuilder sb = new StringBuilder();
        java.util.LinkedHashSet<Integer> seen = new java.util.LinkedHashSet<Integer>();
        for (com.pacco.animecut.core.ZoneTone.Zone z : p.zones) seen.add(z.s.base | 0xFF000000);
        int k = 1;
        for (int c : seen) {
            if (k > 14) break;
            if (sb.length() > 0) sb.append(',');
            sb.append("Color ").append(k++).append(':').append(String.format(Locale.US, "%06X", c & 0xFFFFFF));
        }
        final EditText in = new EditText(this);
        in.setHint("Nombre (por ejemplo, el personaje)");
        new SheetBuilder(this).setTitle("Guardar paleta").setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String name = in.getText().toString().trim().replace(";", " ").replace("|", " ").replace(",", " ").replace(":", " ");
                        if (name.isEmpty()) name = "Mi paleta";
                        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
                        String old = sp.getString("easy_palettes", "");
                        sp.edit().putString("easy_palettes", (old.isEmpty() ? "" : old + ";") + name + "|" + sb)
                                .putString("easy_pal", name).apply();
                        toast("Paleta \"" + name + "\" guardada: la ves en Paletas");
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Capa para retocar encima del color (no se pisa al cambiar las sombras). */
    private void easyRetouchLayer(boolean shadow) {
        Project p = canvas.getProject();
        if (p == null) return;
        p.active = p.layers.size() - 1;     // arriba de todo
        canvas.addEmptyLayer();
        Layer nl = p.activeLayer();
        if (nl != null) {
            nl.name = shadow ? "sombra a mano" : "retoques";
            if (shadow) {
                canvas.setLayerMode(nl, Layer.MODE_MULTIPLY);
                nl.opacity = 140;
                canvas.setColor(0xFF9A8FB8);   // sombra lila suave
            }
        }
        canvas.setRayMode(false);
        selectTool(CanvasView.MODE_PAINT);
        afterLayerOp();
        canvas.showHud(shadow ? "Sombra a mano: pinta donde quieras mas sombra (Multiplicar, suave)"
                : "Retoques: rubor, brillos en ojos y pelo. Esta capa no se borra al cambiar sombras", 2800);
    }

    /** Barra de abajo en Rayar partes: color, no pintar, borrar rayas, borrar todo y ✓. */
    private void buildRayBar(LinearLayout bar) {
        View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
        lp.setMargins(dp(4), 0, dp(4), 0);
        sw.setLayoutParams(lp);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        int rc = canvas.getRayColor();
        g.setColor(rc == 0 ? 0xFF8A8A92 : rc);
        g.setStroke(dp(2), 0xFFFFFFFF);
        sw.setBackground(g);
        sw.setContentDescription("Color de los rayones");
        sw.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                colorDialog(new ColorPickTarget() { @Override public void onColor(int color) { easyBase(color); updateUi(); if (easyCard != null) showEasyCard(); } },
                        rc == 0 ? 0xFFFFDFCC : rc, "Color de los rayones");
            }
        });
        bar.addView(sw);
        ImageButton np = iconButton(R.drawable.ic_sub, "No pintar: lo rayado queda en B/N", new Runnable() {
            public void run() { canvas.setRayNoPaint(); updateUi(); if (easyCard != null) showEasyCard(); }
        });
        np.setBackgroundResource(canvas.isRayNoPaint() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(np);
        ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar rayones", new Runnable() {
            public void run() { canvas.setSubtract(!canvas.isSubtract()); updateUi(); }
        });
        sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
        bar.addView(sub);
        bar.addView(markerTrash());
        ImageButton ok = iconButton(R.drawable.ic_check, "Pintar las partes rayadas", new Runnable() {
            public void run() { canvas.rayToZones(easyFinish); }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        bar.addView(ok);
    }

    // v8.62: se quitaron easyRestyle y su barra de fuerza (el paso 2 viejo "Sombra"); el paso 2 es el Acabado.

    private void hideEasyCard() {
        if (finOpen()) finAccept();   // v8.60: cerrar deja el acabado puesto
        if (canvas != null && canvas.isRayMode()) { canvas.setRayMode(false); selectColorBucket(); }
        if (canvas != null && canvas.isWallMode()) selectColorBucket();     // v9.00
        if (canvas != null) easyResetTool();
        removeEasyCardView();
    }

    private void removeEasyCardView() {
        if (easyCard != null && easyCard.getParent() instanceof ViewGroup) ((ViewGroup) easyCard.getParent()).removeView(easyCard);
        easyCard = null;
    }

    private TextView easyButton(String t, boolean on, final Runnable r) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(13f);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_cell);
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        return b;
    }


    // ==================================================================
    // v8.60 ACABADO: paso 2 de Colorear. Un solo acabado (siempre el mismo), un sol que se arrastra,
    // Fuerza, Mas sombra / Mas luz (retocan el mapa de luz, nunca se salen de la zona), Quitar mancha,
    // Antes (mantener pulsado), Lineas de color, Cancelar y Aceptar. La vista previa ES el resultado:
    // la misma cuenta a tamano real, escrita en "Color zonas" (Cancelar la devuelve como estaba).
    // ==================================================================

    private com.pacco.animecut.core.Acabado.Session finSession;
    private final com.pacco.animecut.core.Acabado.Params finParams = new com.pacco.animecut.core.Acabado.Params();
    private int[] finOrig, finLast;
    private android.graphics.Rect finBox;
    private java.util.List<com.pacco.animecut.core.ZoneTone.Zone> finZones;
    private Project finProject;
    /** 0 Sol, 1 Mas sombra, 2 Mas luz, 3 Quitar mancha, 4 Brillante (v8.63), 5 Estampado (v8.63) */
    private int finTool = 0;
    /** v8.63: estampado elegido (Acabado.PATTERN_NAMES; 0 = quitar) */
    private int finPatType = 1;
    /** v8.63: luz elegida para mover y cambiar de tipo (0 = sol principal, 1.. = luces extra) */
    private int finSel = 0;
    /** v8.68: donde estaban las luces al bajar el dedo (para volver si era un zoom) */
    private float[] finSunUndo;

    /** v8.63: dibuja el sol principal y las luces extra en el lienzo. */
    private void finMarkers() {
        canvas.setSunMarker(finParams.sunX, finParams.sunY);
        canvas.setLightMarkers(finParams.lightType, finParams.exX, finParams.exY, finParams.exType, finParams.extraN, finSel);
    }
    private volatile int finGen;
    private boolean finPreparing, finShowingOriginal;
    private int finBrushZone = -1;
    private float finLastBX = Float.NaN, finLastBY;
    private final java.util.concurrent.ExecutorService finExec = java.util.concurrent.Executors.newSingleThreadExecutor();

    private boolean finOpen() { return finSession != null || finPreparing; }

    /** Abre el Acabado sobre las zonas pintadas (prepara lo pesado en otro hilo). */
    private void finishOpen() {
        final Project p = canvas.getProject();
        if (p == null) return;
        if (finOpen() && finProject == p) { finAttach(); return; }
        if (p.zones.isEmpty()) { toast("Primero pinta colores (paso 1)"); return; }
        if (canvas.finishToneLayer() == null) { toast("Primero pinta colores (paso 1)"); return; }
        final int[] ref = canvas.finishRef();
        if (ref == null) return;
        // v8.83: lo pintado a mano con el color de una zona tambien recibe el acabado
        final java.util.List<com.pacco.animecut.core.ZoneTone.Zone> allZ = new ArrayList<com.pacco.animecut.core.ZoneTone.Zone>(p.zones);
        try {
            allZ.addAll(com.pacco.animecut.core.ZoneTone.looseZones(canvas.finishToneLayer().px(), p.w, p.h, p.zones));
        } catch (OutOfMemoryError e) { /* sin memoria: solo las zonas */ }
        int x0 = p.w, y0 = p.h, x1 = 0, y1 = 0;
        for (com.pacco.animecut.core.ZoneTone.Zone z : allZ) {
            x0 = Math.min(x0, z.x); y0 = Math.min(y0, z.y);
            x1 = Math.max(x1, z.x + z.w); y1 = Math.max(y1, z.y + z.h);
        }
        x0 = Math.max(0, x0 - 6); y0 = Math.max(0, y0 - 6); x1 = Math.min(p.w, x1 + 6); y1 = Math.min(p.h, y1 + 6);
        if (x1 <= x0 || y1 <= y0) return;
        final android.graphics.Rect box = new android.graphics.Rect(x0, y0, x1, y1);
        final int[] orig;
        try { orig = canvas.finishCopy(box); } catch (OutOfMemoryError e) { toast("Falta memoria para el acabado"); return; }
        if (orig == null) return;
        final java.util.List<com.pacco.animecut.core.ZoneTone.Zone> zones = allZ;
        // sol y fuerza: los de la obra (si ya tenia acabado) o los ultimos usados
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        finParams.sunX = sp.getFloat("fin_sun_x", 0.15f);
        finParams.sunY = sp.getFloat("fin_sun_y", 0.05f);
        finParams.strength = sp.getInt("fin_strength", 60);
        finParams.colorLines = sp.getBoolean("fin_lines", true);
        finParams.lightType = Math.max(0, Math.min(com.pacco.animecut.core.Acabado.LIGHT_NAMES.length - 1, sp.getInt("fin_light", 0)));
        finParams.anime = sp.getBoolean("fin_anime", false);
        finParams.soft = !finParams.anime && sp.getBoolean("fin_soft", false);   // v9.01
        finParams.hairTip = 0;
        finParams.extraN = 0;
        for (com.pacco.animecut.core.ZoneTone.Zone z : zones)
            if (z.s.pro) {
                finParams.sunX = z.s.sunX / 1000f; finParams.sunY = z.s.sunY / 1000f;
                finParams.strength = z.s.strength; finParams.colorLines = z.s.colorLines;
                finParams.lightType = z.s.lightType;
                finParams.anime = z.s.anime;
                finParams.soft = z.s.soft;
                finParams.hairTip = z.s.hairTip;
                finParams.extraN = Math.min(com.pacco.animecut.core.Acabado.MAX_EXTRA, z.s.extraN);
                for (int j = 0; j < finParams.extraN; j++) {
                    finParams.exX[j] = z.s.exX[j] / 1000f; finParams.exY[j] = z.s.exY[j] / 1000f;
                    finParams.exType[j] = z.s.exType[j];
                }
                break;
            }
        finSel = 0;
        finProject = p;
        finOrig = orig;
        finLast = null;
        finBox = box;
        finZones = zones;
        finTool = 0;
        finPreparing = true;
        final int gen = ++finGen;
        canvas.showHud("Preparando el acabado...", 2500);
        finAttach();
        finExec.execute(new Runnable() {
            @Override public void run() {
                com.pacco.animecut.core.Acabado.Session s = null;
                String err = null;
                try {
                    s = new com.pacco.animecut.core.Acabado.Session(ref, p.w, p.h, zones, new com.pacco.animecut.core.Acabado.Cancel() {
                        public boolean cancelled() { return gen != finGen && !finPreparing; }
                    });
                } catch (com.pacco.animecut.core.Acabado.Cancelled c) {
                    s = null;
                } catch (OutOfMemoryError e) {
                    err = "Falta memoria para el acabado";
                } catch (RuntimeException e) {
                    err = "No se pudo preparar el acabado";
                }
                final com.pacco.animecut.core.Acabado.Session fs = s;
                final String ferr = err;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (!finPreparing || finProject != p || canvas.getProject() != p) return;
                        finPreparing = false;
                        if (fs == null) {
                            if (ferr != null) toast(ferr);
                            finDetach();
                            return;
                        }
                        finSession = fs;
                        finRender();
                        if (easyCard != null && easyStep == 2) showEasyCard();
                    }
                });
            }
        });
    }

    /** Conecta el sol y los retoques al lienzo. */
    private void finAttach() {
        selectToolNow(CanvasView.MODE_PAN);
        finMarkers();
        canvas.setFinishTouch(new CanvasView.FinishTouch() {
            @Override public void onFinishTouch(int action, float x, float y) { finTouch(action, x, y); }
        });
    }

    private void finDetach() {
        canvas.removeCallbacks(finFullRun);
        finGen++;
        finSession = null;
        finPreparing = false;
        finProject = null;
        finOrig = null;
        finLast = null;
        finZones = null;
        finShowingOriginal = false;
        canvas.setFinishTouch(null);
        canvas.setSunMarker(Float.NaN, Float.NaN);
        canvas.setLightMarkers(0, new float[0], new float[0], new int[0], 0, 0);
    }

    private void finRender() { finRender(false); }

    /** v8.61: al soltar el dedo (o quieto un momento) se pinta completo. */
    private final Runnable finFullRun = new Runnable() { public void run() { finRender(false); } };

    /** Rapido mientras se arrastra (sol, retoques, Fuerza); completo despues. */
    private void finRenderDraft() {
        finRender(true);
        canvas.removeCallbacks(finFullRun);
        canvas.postDelayed(finFullRun, 450);
    }

    /** Vuelve a calcular el acabado (lo viejo se salta o se corta) y lo muestra en la capa. */
    private void finRender(boolean draft) {
        final com.pacco.animecut.core.Acabado.Session s = finSession;
        if (s == null || finOrig == null) return;
        if (!draft) canvas.removeCallbacks(finFullRun);
        final int gen = ++finGen;
        final com.pacco.animecut.core.Acabado.Params prm = finParams.copy();
        prm.draft = draft;
        final int[] orig = finOrig;
        final android.graphics.Rect box = finBox;
        final Project p = finProject;
        finExec.execute(new Runnable() {
            @Override public void run() {
                if (gen != finGen) return;
                int[] buf;
                try {
                    buf = orig.clone();
                    s.render(prm, buf, box.left, box.top, box.width(), box.height(), new com.pacco.animecut.core.Acabado.Cancel() {
                        public boolean cancelled() { return gen != finGen; }
                    });
                } catch (com.pacco.animecut.core.Acabado.Cancelled c) {
                    return;
                } catch (OutOfMemoryError e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Falta memoria para el acabado"); } });
                    return;
                }
                final int[] fb = buf;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (gen != finGen || finSession != s || canvas.getProject() != p) return;
                        finLast = fb;
                        if (!finShowingOriginal) canvas.finishPut(fb, box);
                    }
                });
            }
        });
    }

    private void finTouch(int action, float x, float y) {
        Project p = canvas.getProject();
        if (p == null) return;
        if (finTool == 0) {
            if (action == 3) {
                // v8.68: se puso un 2do dedo (zoom): la luz vuelve a donde estaba
                if (finSunUndo != null) {
                    finParams.sunX = finSunUndo[0]; finParams.sunY = finSunUndo[1];
                    for (int j = 0; j < finParams.extraN && 2 + j * 2 + 1 < finSunUndo.length; j++) {
                        finParams.exX[j] = finSunUndo[2 + j * 2]; finParams.exY[j] = finSunUndo[3 + j * 2];
                    }
                    finSunUndo = null;
                    finMarkers();
                    finRender(false);
                }
                return;
            }
            if (action == 0) {
                finSunUndo = new float[2 + 2 * finParams.extraN];
                finSunUndo[0] = finParams.sunX; finSunUndo[1] = finParams.sunY;
                for (int j = 0; j < finParams.extraN; j++) { finSunUndo[2 + j * 2] = finParams.exX[j]; finSunUndo[3 + j * 2] = finParams.exY[j]; }
            }
            if (action == 2) finSunUndo = null;
            float fx = Math.max(-0.5f, Math.min(1.5f, x / p.w)), fy = Math.max(-0.5f, Math.min(1.5f, y / p.h));
            if (action == 0 && finParams.extraN > 0) {
                // v8.63: se agarra la luz mas cercana al dedo (si no hay ninguna cerca, se mueve la elegida)
                float best = 0.12f;
                int pick = -1;
                float d0 = (float) Math.hypot(fx - finParams.sunX, fy - finParams.sunY);
                if (d0 < best) { best = d0; pick = 0; }
                for (int j = 0; j < finParams.extraN; j++) {
                    float dj = (float) Math.hypot(fx - finParams.exX[j], fy - finParams.exY[j]);
                    if (dj < best) { best = dj; pick = j + 1; }
                }
                if (pick >= 0 && pick != finSel) { finSel = pick; showEasyCard(); }
            }
            if (finSel > 0 && finSel <= finParams.extraN) {
                finParams.exX[finSel - 1] = fx; finParams.exY[finSel - 1] = fy;
                finMarkers();
                if (action == 2) finRender(false); else finRenderDraft();
                return;
            }
            finParams.sunX = fx;
            finParams.sunY = fy;
            finMarkers();
            if (action == 2) {
                finRender(false);
                getSharedPreferences("pz", MODE_PRIVATE).edit()
                        .putFloat("fin_sun_x", finParams.sunX).putFloat("fin_sun_y", finParams.sunY).apply();
            } else {
                finRenderDraft();   // v8.61: fluido mientras arrastras
            }
            return;
        }
        final com.pacco.animecut.core.Acabado.Session s = finSession;
        if (s == null) { if (action == 0) canvas.showHud("Espera: preparando el acabado", 1200); return; }
        float rad = Math.max(p.w, p.h) * 0.035f;
        // v8.63: Brillante / Estampado: se toca una parte
        if (finTool == 4 || finTool == 5) {
            if (action != 2) return;
            int zi = s.zoneAt(Math.round(x), Math.round(y));
            if (zi < 0) { canvas.showHud("Toca dentro de una parte pintada", 1200); return; }
            s.pushUndo();
            if (finTool == 4) {
                int m = s.material(zi) == 1 ? 0 : 1;
                s.setMaterial(zi, m);
                canvas.showHud(m == 1 ? "Brillante (toca otra vez para quitar)" : "Brillo quitado", 1300);
            } else {
                int col = canvas.getColor() | 0xFF000000;
                s.setPattern(zi, finPatType, col);
                if (finPatType == 0) canvas.showHud("Estampado quitado", 1100);
                else if ((col & 0xFFFFFF) == (finZones.get(zi).s.base & 0xFFFFFF))
                    canvas.showHud("Es del mismo color: elige otro color en el pincel", 1800);
                else canvas.showHud(com.pacco.animecut.core.Acabado.PATTERN_NAMES[finPatType] + " (con el color del pincel)", 1300);
            }
            finRender();
            updateUi();
            return;
        }
        if (finTool == 3) {
            if (action != 2) return;
            s.pushUndo();
            if (s.removeSpot(Math.round(x), Math.round(y), finParams.copy())) {
                finRender();
                canvas.showHud("Mancha quitada", 900);
            } else {
                s.undo();
                canvas.showHud("Ahi no hay una mancha chica (toca la mancha)", 1500);
            }
            return;
        }
        float amt = finTool == 2 ? 0.30f : -0.30f;
        if (action == 0) {
            finBrushZone = s.zoneAt(Math.round(x), Math.round(y));
            if (finBrushZone < 0) { canvas.showHud("Toca dentro de una parte pintada", 1200); return; }
            s.pushUndo();
            s.brush(finBrushZone, x, y, rad, amt);
            finLastBX = x; finLastBY = y;
            canvas.setFinishRing(x, y, rad);
            finRender();
        } else if (action == 1) {
            if (finBrushZone < 0) return;
            float d = (float) Math.hypot(x - finLastBX, y - finLastBY);
            canvas.setFinishRing(x, y, rad);
            if (d < rad * 0.35f) return;
            s.brush(finBrushZone, x, y, rad, amt * 0.6f);
            finLastBX = x; finLastBY = y;
            finRenderDraft();
        } else {
            finBrushZone = -1;
            canvas.setFinishRing(Float.NaN, Float.NaN, 0f);
            finRender(false);
            if (s.canUndo()) updateUi();
        }
    }

    /** Aceptar: el acabado final (la misma cuenta) queda en la capa con UN paso de Deshacer. */
    private void finAccept() {
        if (finPreparing && finSession == null) { finCancel(); return; }
        final com.pacco.animecut.core.Acabado.Session s = finSession;
        if (s == null) { finDetach(); return; }
        final com.pacco.animecut.core.Acabado.Params prm = finParams.copy();
        prm.draft = false;
        canvas.removeCallbacks(finFullRun);
        final int[] orig = finOrig;
        final android.graphics.Rect box = finBox;
        final Project p = finProject;
        final java.util.List<com.pacco.animecut.core.ZoneTone.Zone> zs = finZones;
        finGen++;
        finSession = null;
        canvas.setFinishTouch(null);
        canvas.setSunMarker(Float.NaN, Float.NaN);
        canvas.setLightMarkers(0, new float[0], new float[0], new int[0], 0, 0);
        canvas.showHud("Aplicando el acabado...", 2000);
        finExec.execute(new Runnable() {
            @Override public void run() {
                int[] buf = null;
                try {
                    buf = orig.clone();
                    s.render(prm, buf, box.left, box.top, box.width(), box.height(), null);
                } catch (OutOfMemoryError e) {
                    buf = null;
                } catch (RuntimeException e) {
                    buf = null;
                }
                final int[] fb = buf;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (canvas.getProject() != p) { finDetach(); return; }
                        if (fb == null) {
                            canvas.finishPut(orig, box);
                            toast("No se pudo aplicar el acabado");
                            finDetach();
                            return;
                        }
                        java.util.List<com.pacco.animecut.core.ZoneTone.Zone> nz = new ArrayList<com.pacco.animecut.core.ZoneTone.Zone>();
                        for (com.pacco.animecut.core.ZoneTone.Zone z : p.zones) {
                            if (!zs.contains(z)) { nz.add(z); continue; }
                            com.pacco.animecut.core.ZoneTone.Style st = z.s.copy();
                            st.pro = true;
                            st.sunX = Math.round(prm.sunX * 1000f);
                            st.sunY = Math.round(prm.sunY * 1000f);
                            st.strength = prm.strength;
                            st.colorLines = prm.colorLines;
                            st.lightType = prm.lightType;
                            st.anime = prm.anime;
                            st.soft = prm.soft;
                            st.hairTip = prm.hairTip;
                            st.extraN = prm.extraN;
                            for (int j = 0; j < 2; j++) {
                                st.exX[j] = Math.round(prm.exX[j] * 1000f); st.exY[j] = Math.round(prm.exY[j] * 1000f);
                                st.exType[j] = prm.exType[j];
                            }
                            int[] ex = s.zoneExtras(z);
                            if (ex != null) { st.material = ex[0]; st.pattern = ex[1]; st.patColor = ex[2]; }
                            nz.add(z.withStyle(st));
                        }
                        // v8.83: las zonas que salieron de lo pintado a mano quedan guardadas como zonas
                        for (com.pacco.animecut.core.ZoneTone.Zone z : zs) {
                            if (p.zones.contains(z)) continue;
                            com.pacco.animecut.core.ZoneTone.Style st = z.s.copy();
                            st.pro = true;
                            st.sunX = Math.round(prm.sunX * 1000f);
                            st.sunY = Math.round(prm.sunY * 1000f);
                            st.strength = prm.strength;
                            st.colorLines = prm.colorLines;
                            st.lightType = prm.lightType;
                            st.anime = prm.anime;
                            st.soft = prm.soft;
                            st.hairTip = prm.hairTip;
                            st.extraN = prm.extraN;
                            for (int j = 0; j < 2; j++) {
                                st.exX[j] = Math.round(prm.exX[j] * 1000f); st.exY[j] = Math.round(prm.exY[j] * 1000f);
                                st.exType[j] = prm.exType[j];
                            }
                            nz.add(z.withStyle(st));
                        }
                        canvas.finishCommit(orig, fb, box, nz);
                        getSharedPreferences("pz", MODE_PRIVATE).edit()
                                .putFloat("fin_sun_x", prm.sunX).putFloat("fin_sun_y", prm.sunY)
                                .putInt("fin_strength", prm.strength).putBoolean("fin_lines", prm.colorLines)
                                .putBoolean("fin_anime", prm.anime).putBoolean("fin_soft", prm.soft).apply();
                        finDetach();
                        markDirty();
                        updateUi();
                        canvas.showHud("Acabado listo (Deshacer lo quita)", 1600);
                    }
                });
            }
        });
    }

    /** Cancelar: la capa vuelve exactamente a como estaba. */
    private void finCancel() {
        if (finOrig != null && finBox != null && canvas.getProject() == finProject) canvas.finishPut(finOrig, finBox);
        finDetach();
        updateUi();
    }

    /** Antes (mantener pulsado): muestra la capa sin acabado mientras el dedo esta encima. */
    private void finShowBefore(boolean before) {
        if (finOrig == null || finBox == null) return;
        finShowingOriginal = before;
        if (before) canvas.finishPut(finOrig, finBox);
        else if (finLast != null) canvas.finishPut(finLast, finBox);
    }

    /** v8.84: el Acabado abre SIMPLE (luz, estilo, fuerza). "Mas" muestra retoques y extras. */
    private boolean finMore;

    private TextView finLabel(String t) {
        TextView l = new TextView(this);
        l.setText(t);
        l.setTextColor(0xFFB8C0CC);
        l.setTextSize(11.5f);
        l.setPadding(dp(4), dp(4), dp(6), 0);
        return l;
    }

    private LinearLayout finRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    /**
     * Fila del paso 2 (Acabado) dentro de la tarjeta de Colorear.
     * v8.84: mas simple. Arriba dice que hacer; despues "Luz" (aqui estan sol, tarde y lunas),
     * "Estilo" y Fuerza. Los retoques con el dedo, el brillo, el estampado y la segunda luz
     * estan detras del boton "Mas".
     */
    // ---------------- v9.01 Acabado: miniaturas (se ve el efecto antes de tocar) ----------------

    /** Miniatura de una luz: el ambiente de fondo y una esfera de piel con su luz, su sombra y su borde. */
    private static final class LightThumb extends android.graphics.drawable.Drawable {
        private final int type;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        LightThumb(int type) { this.type = type; }

        private static int mul(int a, int b) {
            int r = ((a >> 16) & 255) * ((b >> 16) & 255) / 255, g = ((a >> 8) & 255) * ((b >> 8) & 255) / 255,
                    bb = (a & 255) * (b & 255) / 255;
            return 0xFF000000 | (r << 16) | (g << 8) | bb;
        }

        private static int dark(int c, float k) {
            return 0xFF000000 | (Math.round(((c >> 16) & 255) * k) << 16) | (Math.round(((c >> 8) & 255) * k) << 8) | Math.round((c & 255) * k);
        }

        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            float s = Math.min(b.width(), b.height()) / 100f;
            if (s <= 0f) return;
            int[] sw = com.pacco.animecut.core.Acabado.lightSwatch(type);     // luz, sombra, borde, arriba, abajo
            boolean night = type == 3 || type == 4 || type == 6;
            c.save();
            c.translate(b.exactCenterX(), b.exactCenterY());
            c.scale(s, s);
            // ambiente (arriba -> abajo)
            p.setShader(new android.graphics.LinearGradient(0f, -50f, 0f, 50f, dark(sw[3], night ? 0.45f : 0.62f),
                    dark(sw[4], night ? 0.40f : 0.55f), android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(new android.graphics.RectF(-50f, -50f, 50f, 50f), 16f, 16f, p);
            // esfera de piel: luz del lado del sol (arriba-izquierda), sombra tenida del otro lado
            int skin = 0xFFFFE1D2;
            int lit = mul(skin, 0xFF000000 | sw[0]), shade = mul(dark(skin, 0.80f), 0xFF000000 | sw[1]);
            if (night) shade = dark(shade, 0.85f);
            p.setShader(new android.graphics.RadialGradient(-12f, -10f, 44f, lit, shade, android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(4f, 8f, 30f, p);
            p.setShader(null);
            // luz de borde del lado contrario
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(3.5f);
            p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            p.setColor(0xDD000000 | sw[2]);
            c.drawArc(new android.graphics.RectF(-26f, -22f, 34f, 38f), 10f, 70f, false, p);
            p.setStyle(android.graphics.Paint.Style.FILL);
            // de donde viene la luz (arriba a la izquierda)
            int lc = 0xFF000000 | sw[0];
            if (type == 3 || type == 4) {                       // luna
                p.setColor(0xFFE6ECFF);
                c.drawCircle(-30f, -30f, 10f, p);
                p.setColor(dark(sw[3], 0.45f));
                c.drawCircle(-25f, -33f, 8.5f, p);
            } else if (type == 5) {                             // lampara
                p.setColor(0xFFFFD27A);
                c.drawCircle(-30f, -30f, 8f, p);
                p.setColor(0x55FFD27A);
                c.drawCircle(-30f, -30f, 14f, p);
            } else if (type == 6) {                             // neon: dos luces de color
                p.setColor(0xFFFF6FD8);
                c.drawCircle(-32f, -30f, 7f, p);
                p.setColor(0xFF5FE8FF);
                c.drawCircle(32f, -30f, 7f, p);
            } else {                                            // sol (con rayitos)
                p.setColor(type == 2 ? 0xFFFF8A5C : 0xFFFFC83D);
                c.drawCircle(-30f, -30f, 8f, p);
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(2.5f);
                p.setColor(lc);
                for (int k = 0; k < 8; k++) {
                    double a = Math.PI * k / 4;
                    float cx = (float) Math.cos(a), sy = (float) Math.sin(a);
                    c.drawLine(-30f + cx * 11f, -30f + sy * 11f, -30f + cx * 15f, -30f + sy * 15f, p);
                }
                p.setStyle(android.graphics.Paint.Style.FILL);
                if (type == 7) {                                // parque: pasto abajo
                    p.setColor(0xFF4C8A4A);
                    c.drawRoundRect(new android.graphics.RectF(-50f, 38f, 50f, 50f), 6f, 6f, p);
                }
            }
            c.restore();
        }

        @Override public void setAlpha(int a) { }

        @Override public void setColorFilter(android.graphics.ColorFilter cf) { }

        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    /** Miniatura de un estilo: 0 Manhwa, 1 Anime, 2 Suave (la misma esfera pintada distinto). */
    private static final class StyleThumb extends android.graphics.drawable.Drawable {
        private final int st;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        StyleThumb(int st) { this.st = st; }

        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            float s = Math.min(b.width(), b.height()) / 100f;
            if (s <= 0f) return;
            c.save();
            c.translate(b.exactCenterX(), b.exactCenterY());
            c.scale(s, s);
            p.setShader(null);
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(0xFF2E2E38);
            c.drawRoundRect(new android.graphics.RectF(-50f, -50f, 50f, 50f), 16f, 16f, p);
            android.graphics.RectF ball = new android.graphics.RectF(-32f, -32f, 32f, 32f);
            if (st == 1) {
                // Anime: dos tonos con borde duro
                p.setColor(0xFFFFE0CF);
                c.drawOval(ball, p);
                c.save();
                android.graphics.Path clip = new android.graphics.Path();
                clip.addOval(ball, android.graphics.Path.Direction.CW);
                c.clipPath(clip);
                p.setColor(0xFFD9A3A8);
                android.graphics.Path sh = new android.graphics.Path();
                sh.addCircle(-14f, -14f, 40f, android.graphics.Path.Direction.CW);
                sh.setFillType(android.graphics.Path.FillType.INVERSE_WINDING);
                c.drawPath(sh, p);
                c.restore();
                p.setColor(0xFFFFFFFF);
                c.drawOval(new android.graphics.RectF(-20f, -22f, -10f, -14f), p);
            } else if (st == 0) {
                // Manhwa: degradado suave, brillo blanco fuerte y halo
                p.setColor(0x33FFE6D0);
                c.drawCircle(0f, 0f, 44f, p);
                p.setShader(new android.graphics.RadialGradient(-12f, -12f, 50f, 0xFFFFEBDD, 0xFFB86F82, android.graphics.Shader.TileMode.CLAMP));
                c.drawOval(ball, p);
                p.setShader(null);
                p.setColor(0xFFFFFFFF);
                c.drawOval(new android.graphics.RectF(-22f, -24f, -4f, -14f), p);
                p.setColor(0xAAFFFFFF);
                c.drawCircle(-24f, -4f, 3f, p);
            } else {
                // Suave: pastel claro con rubor de rayitas
                p.setColor(0x26FFF0E6);
                c.drawCircle(0f, 0f, 46f, p);
                p.setShader(new android.graphics.RadialGradient(-10f, -10f, 56f, 0xFFFFF3EA, 0xFFE8B9B9, android.graphics.Shader.TileMode.CLAMP));
                c.drawOval(ball, p);
                p.setShader(null);
                p.setColor(0x66FF8F8F);
                c.drawOval(new android.graphics.RectF(-4f, 2f, 22f, 16f), p);
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(2.2f);
                p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
                p.setColor(0xCCE0566A);
                for (int k = 0; k < 3; k++) c.drawLine(3f + k * 6f, 5f, -1f + k * 6f, 13f, p);
            }
            c.restore();
        }

        @Override public void setAlpha(int a) { }

        @Override public void setColorFilter(android.graphics.ColorFilter cf) { }

        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    /** Boton con miniatura y su nombre debajo. */
    private LinearLayout thumbTile(android.graphics.drawable.Drawable d, String name, String help, boolean on, final Runnable r) {
        LinearLayout it = new LinearLayout(this);
        it.setOrientation(LinearLayout.VERTICAL);
        it.setGravity(Gravity.CENTER_HORIZONTAL);
        it.setPadding(dp(3), dp(3), dp(3), dp(2));
        it.setContentDescription(name + ": " + help);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(on ? 0xFF1F5E4C : 0x00000000);
        bg.setCornerRadius(dp(10));
        if (on) bg.setStroke(dp(2), 0xFF2EE6A6);
        it.setBackground(bg);
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(d);
        it.addView(iv, new LinearLayout.LayoutParams(dp(46), dp(46)));
        TextView t = new TextView(this);
        t.setText(on ? "✓ " + name : name);
        t.setTextSize(10.5f);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(on ? 0xFF2EE6A6 : 0xFFD0D0D8);
        it.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        it.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        return it;
    }

    /** Estilo del acabado: 0 Manhwa, 1 Anime, 2 Suave. */
    private int finStyle() { return finParams.anime ? 1 : finParams.soft ? 2 : 0; }

    private void finCardRows(LinearLayout card) {
        boolean extraSel = finSel > 0 && finSel <= finParams.extraN;
        TextView hint = finLabel(extraSel ? "Arrastra la luz elegida (anillo blanco) y elige abajo de que tipo es"
                : "Arrastra el ☀ sobre el dibujo: la luz viene de ahi");
        hint.setTextColor(0xFFFFE08A);
        card.addView(hint);
        // ---- v9.01 Luz: 6 miniaturas (Dia, Atardecer, Noche, Lampara, Neon, Parque)
        card.addView(finLabel(extraSel ? "Luz " + (finSel + 1) : "Luz"));
        android.widget.HorizontalScrollView lhs = new android.widget.HorizontalScrollView(this);
        lhs.setHorizontalScrollBarEnabled(false);
        LinearLayout lrow = new LinearLayout(this);
        lrow.setOrientation(LinearLayout.HORIZONTAL);
        final String[] ln = com.pacco.animecut.core.Acabado.LIGHT_NAMES;
        final String[] lh = com.pacco.animecut.core.Acabado.LIGHT_HELP;
        final int selType = finSel > 0 && finSel <= finParams.extraN ? finParams.exType[finSel - 1] : finParams.lightType;
        for (final int lt : com.pacco.animecut.core.Acabado.LIGHT_SHOWN) {
            lrow.addView(thumbTile(new LightThumb(lt), ln[lt], lh[lt], selType == lt, new Runnable() { public void run() {
                if (finSel > 0 && finSel <= finParams.extraN) {
                    finParams.exType[finSel - 1] = lt;      // tipo de la luz extra elegida
                } else {
                    finParams.lightType = lt;
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("fin_light", lt).apply();
                }
                canvas.showHud(ln[lt] + ": " + lh[lt], 1200);
                finMarkers();
                finRender(false);
                showEasyCard();
            }}), new LinearLayout.LayoutParams(dp(62), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        lhs.addView(lrow);
        card.addView(lhs);
        // ---- v9.01 Estilo: 3 miniaturas (Manhwa, Anime, Suave)
        card.addView(finLabel("Estilo"));
        LinearLayout srow = new LinearLayout(this);
        srow.setOrientation(LinearLayout.HORIZONTAL);
        final String[] sn = {"Manhwa", "Anime", "Suave"};
        final String[] sh = {"Sombras suaves y brillos fuertes", "Sombra de borde duro y contraluz", "Claro, calido y con rubor"};
        int cs = finStyle();
        for (int k = 0; k < 3; k++) {
            final int st = k;
            srow.addView(thumbTile(new StyleThumb(k), sn[k], sh[k], cs == k, new Runnable() { public void run() {
                if (finStyle() == st) return;
                finParams.anime = st == 1;
                finParams.soft = st == 2;
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("fin_anime", finParams.anime)
                        .putBoolean("fin_soft", finParams.soft).apply();
                canvas.showHud(sn[st] + ": " + sh[st], 1200);
                finRender(false);
                showEasyCard();
            }}), new LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        card.addView(srow);
        LinearLayout row;
        // ---- Fuerza
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(atmosSlider("Fuerza", finParams.strength, new IntConsumerCompat() {
            @Override public void accept(int v) { finParams.strength = v; finRenderDraft(); }
        }), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(row);
        if (finMore) finMoreRows(card);
        // ---- abajo: Antes · Mas · cancelar · aceptar
        row = finRow();
        TextView before = easyButton("Manten: antes", false, new Runnable() { public void run() { } });
        before.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) { finShowBefore(true); v.setPressed(true); }
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { finShowBefore(false); v.setPressed(false); }
                return true;
            }
        });
        row.addView(before);
        row.addView(easyButton(finMore ? "Menos ▴" : "Mas ▾", finMore, new Runnable() { public void run() {
            finMore = !finMore;
            if (!finMore && finTool != 0) {
                finTool = 0;                       // al cerrar "Mas" el dedo vuelve a mover el sol
                canvas.setFinishRing(Float.NaN, Float.NaN, 0f);
            }
            showEasyCard();
        }}));
        row.addView(easyButton("✕", false, new Runnable() { public void run() {
            finCancel();
            easyGo(1);
            canvas.showHud("Acabado cancelado", 1200);
        }}));
        TextView ok = easyButton("✓", true, new Runnable() { public void run() {
            finAccept();
            easyGo(3);
        }});
        ok.setBackgroundResource(R.drawable.bg_save);
        row.addView(ok);
        card.addView(row);
    }

    /** v8.84: lo avanzado del Acabado (solo con "Mas" abierto). */
    private void finMoreRows(LinearLayout card) {
        final LinearLayout lrow;
        LinearLayout row = finRow();
        // ---- retoques con el dedo
        card.addView(finLabel("Retocar con el dedo (toca uno y pasa el dedo por el dibujo)"));
        String[] tn = {"☀ Mover sol", "Sombra +", "Luz +", "Quitar mancha", "Brillante", "Estampado"};
        final String[] th = {"Arrastra el sol por la pantalla: la luz viene de ahi",
                "Pasa el dedo donde quieras MAS sombra (no sale de la parte)",
                "Pasa el dedo donde quieras MAS luz (no sale de la parte)",
                "Toca una manchita de sombra o de luz para quitarla",
                "Toca una parte (metal, cuero, tela de seda) para que brille",
                "Elige un dibujo y toca la ropa: usa el color del pincel"};
        for (int k = 0; k < 4; k++) {
            final int t = k;
            TextView b = easyButton(tn[k], finTool == k, new Runnable() { public void run() {
                finTool = t;
                canvas.setFinishRing(Float.NaN, Float.NaN, 0f);
                canvas.showHud(th[t], 1800);
                showEasyCard();
            }});
            b.setTextSize(12f);
            b.setPadding(dp(4), dp(7), dp(4), dp(7));
            row.addView(b);
        }
        row.addView(easyButton("↶", false, new Runnable() { public void run() {
            if (finSession != null && finSession.undo()) { finRender(); canvas.showHud("Retoque deshecho", 900); }
            else canvas.showHud("No hay retoques para deshacer", 1200);
        }}));
        card.addView(row);
        // ---- material de una parte
        row = finRow();
        row.addView(finLabel("Tela"));
        for (int k = 4; k < 6; k++) {
            final int t = k;
            TextView b = easyButton(tn[k], finTool == k, new Runnable() { public void run() {
                finTool = t;
                canvas.setFinishRing(Float.NaN, Float.NaN, 0f);
                canvas.showHud(th[t], 1800);
                showEasyCard();
            }});
            b.setTextSize(12f);
            b.setPadding(dp(4), dp(7), dp(4), dp(7));
            row.addView(b);
        }
        card.addView(row);
        // v8.63: dibujos del estampado (solo con la herramienta Estampado)
        if (finTool == 5) {
            android.widget.HorizontalScrollView phs = new android.widget.HorizontalScrollView(this);
            phs.setHorizontalScrollBarEnabled(false);
            LinearLayout prow = new LinearLayout(this);
            prow.setOrientation(LinearLayout.HORIZONTAL);
            final String[] pn = com.pacco.animecut.core.Acabado.PATTERN_NAMES;
            for (int k = 1; k <= pn.length; k++) {
                final int pt = k % pn.length;          // "Quitar" al final
                prow.addView(fxChip(pn[pt], finPatType == pt, new Runnable() { public void run() {
                    finPatType = pt;
                    canvas.showHud(pt == 0 ? "Toca la parte para quitarle el estampado" : "Ahora toca la ropa", 1300);
                    showEasyCard();
                }}));
            }
            phs.addView(prow);
            card.addView(phs);
        }
        // ---- extras: puntas del pelo, otra luz, lineas
        android.widget.HorizontalScrollView xhs = new android.widget.HorizontalScrollView(this);
        xhs.setHorizontalScrollBarEnabled(false);
        lrow = new LinearLayout(this);
        lrow.setOrientation(LinearLayout.HORIZONTAL);
        lrow.setGravity(Gravity.CENTER_VERTICAL);
        lrow.addView(finLabel("Extras"));
        lrow.addView(fxChip(finParams.hairTip != 0 ? "Puntas del pelo ✓" : "Puntas del pelo", finParams.hairTip != 0, new Runnable() { public void run() {
            if (finParams.hairTip != 0) {
                finParams.hairTip = 0;
                canvas.showHud("Puntas del pelo quitadas", 1100);
            } else {
                finParams.hairTip = canvas.getColor() | 0xFF000000;
                canvas.showHud("Puntas del pelo con el color del pincel", 1500);
            }
            finRender(false);
            showEasyCard();
        }}));
        if (finParams.extraN < com.pacco.animecut.core.Acabado.MAX_EXTRA) {
            lrow.addView(fxChip("＋ Otra luz", false, new Runnable() { public void run() {
                int j = finParams.extraN;
                finParams.exX[j] = Math.max(-0.2f, Math.min(1.2f, j == 0 ? 1f - finParams.sunX : finParams.sunX));
                finParams.exY[j] = Math.max(-0.2f, Math.min(1.2f, j == 0 ? 1f - finParams.sunY : 1f - finParams.sunY * 0.5f));
                int mt = finParams.lightType;   // v9.01: de dia: luna; de noche (o neon): atardecer
                finParams.exType[j] = mt == 3 || mt == 4 || mt == 6 ? 2 : 3;
                finParams.extraN = j + 1;
                finSel = j + 1;
                finTool = 0;
                finMarkers();
                canvas.showHud("Luz agregada: arrástrala y elige su tipo", 1800);
                finRender(false);
                showEasyCard();
            }}));
        }
        if (finSel > 0 && finSel <= finParams.extraN) {
            lrow.addView(fxChip("− Quitar esa luz", false, new Runnable() { public void run() {
                int j = finSel - 1;
                for (int i = j; i < finParams.extraN - 1; i++) {
                    finParams.exX[i] = finParams.exX[i + 1]; finParams.exY[i] = finParams.exY[i + 1];
                    finParams.exType[i] = finParams.exType[i + 1];
                }
                finParams.extraN--;
                finSel = 0;
                finMarkers();
                canvas.showHud("Luz quitada", 1000);
                finRender(false);
                showEasyCard();
            }}));
        }
        lrow.addView(fxChip(finParams.colorLines ? "Líneas: color" : "Líneas: negras", finParams.colorLines, new Runnable() { public void run() {
            finParams.colorLines = !finParams.colorLines;
            finRender();
            showEasyCard();
        }}));
        xhs.addView(lrow);
        card.addView(xhs);
    }

    /**
     * v8.45: barra COMPACTA de Colorear facil (antes tapaba medio dibujo): arriba los 3 pasos
     * (tocar un paso va a ese paso), ? = animacion de lo que hace, X = cerrar. Abajo, solo lo del paso.
     */
    // ---------------- v9.00 Colorear paso 1: herramientas con nombre ----------------
    // Pintar (balde), Rayar, Borrar (quita el color de una parte), Tomar (usa el color de una parte),
    // Separar (linea invisible que el balde no cruza) y Huecos (cuanto cierra los cortes de la linea).

    // v9.03: + Cambiar (un color en toda la obra) y Retocar (pincel que se suma a la parte)
    private static final int ET_PAINT = 0, ET_RAY = 1, ET_ERASE = 2, ET_PICK = 3, ET_SWAP = 4, ET_TOUCH = 5, ET_WALL = 6, ET_GAP = 7;
    private static final String[] ET_NAMES = {"Pintar", "Rayar", "Borrar", "Tomar", "Cambiar", "Retocar", "Separar", "Huecos"};
    private static final int[] ET_ICONS = {R.drawable.ic_bucket, R.drawable.ic_marker, R.drawable.ic_zone_erase,
            R.drawable.ic_picker, R.drawable.ic_zone_swap, R.drawable.ic_zone_touch, R.drawable.ic_zone_wall, R.drawable.ic_gap};
    private static final String[] ET_HELP = {
            "Toca una parte, o arrastra el dedo para pintar varias de una vez",
            "Raya cada parte con su color; al pasar a Acabado se pintan solas",
            "Arrastra el dedo para quitar el color. Protegido: no pasa la linea negra. Libre: borra todo por donde pasas. Un toque quita la parte entera",
            "Toca una parte pintada y su color queda elegido",
            "Elige el color nuevo abajo y toca una parte: todas las de ese color cambian",
            "Pinta con el dedo los pedacitos que faltan: se suman a la parte (no tapa otros colores)",
            "Dibuja una linea donde el color se sale: el balde ya no pasa. No sale al guardar",
            ""};
    private boolean easyNoBigAsk;

    /** Herramienta del paso 1 que esta puesta (sale del lienzo, asi nunca se desfasa). */
    private int easyTool() {
        if (canvas.isTouchUpMode()) return canvas.isTouchErase() ? ET_ERASE : ET_TOUCH;
        if (canvas.isWallMode()) return ET_WALL;
        if (canvas.isRayMode()) return ET_RAY;
        int t = canvas.getZoneTapTool();
        return t == CanvasView.ZT_ERASE ? ET_ERASE : t == CanvasView.ZT_PICK ? ET_PICK : t == CanvasView.ZT_SWAP ? ET_SWAP : ET_PAINT;
    }

    /** Cambia la herramienta del paso 1. Los rayones pendientes se pintan antes de cambiar. */
    private void easySetTool(int t) {
        if (canvas.isRayMode() && t != ET_RAY && canvas.hasRayMarks()) canvas.rayToZones(easyFinish);
        if (canvas.hasFillPreview()) canvas.cancelFillPreview();
        if (t == ET_RAY) {
            canvas.setRayMode(true);
            selectTool(CanvasView.MODE_MARKER);
            canvas.setSubtract(false);
            canvas.setRayColor(canvas.getZoneStyle().base);
        } else {
            canvas.setRayMode(false);
            canvas.setZoneMode(true);
            if (t == ET_WALL) {
                selectTool(CanvasView.MODE_MARKER);
                canvas.setWallMode(true);
            } else if (t == ET_TOUCH || t == ET_ERASE) {
                // v9.04: Borrar tambien es pincel: arrastrar quita el color por donde pasa el dedo
                selectTool(CanvasView.MODE_MARKER);
                canvas.setTouchUpMode(true);
                // v9.05: Borrar con 2 modos (Protegido no cruza la linea / Libre)
                canvas.setEraseSmart(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("zone_erase_smart", true));
                canvas.setTouchErase(t == ET_ERASE);
            } else {
                selectColorBucket();
                canvas.setZoneTapTool(t == ET_ERASE ? CanvasView.ZT_ERASE : t == ET_PICK ? CanvasView.ZT_PICK
                        : t == ET_SWAP ? CanvasView.ZT_SWAP : CanvasView.ZT_PAINT);
            }
        }
        canvas.showHud(ET_NAMES[t] + ": " + ET_HELP[t], 2200);
        showEasyCard();
        updateUi();
    }

    /** v9.05: Borrar Protegido (no cruza la linea negra) o Libre. Se recuerda. */
    private void easyEraseMode(boolean smart) {
        canvas.setEraseSmart(smart);
        getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("zone_erase_smart", smart).apply();
        canvas.showHud(smart ? "Borrar protegido: no pasa la linea negra" : "Borrar libre: borra todo por donde pasas", 1600);
        showEasyCard();
    }

    /** Fila de herramientas del paso 1 (icono + nombre debajo). */
    private View easyToolRow() {
        // v9.03: 8 herramientas; si no caben, la fila se desliza
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setFillViewport(true);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(row);
        int itemW = Math.max(dp(46), (getResources().getDisplayMetrics().widthPixels - dp(28)) / ET_NAMES.length);
        int cur = easyTool();
        for (int i = 0; i < ET_NAMES.length; i++) {
            final int k = i;
            boolean on = i == cur;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setContentDescription(ET_NAMES[i] + (ET_HELP[i].isEmpty() ? "" : ": " + ET_HELP[i]));
            if (on) {
                android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
                bg.setColor(0xFF1F5E4C);
                bg.setCornerRadius(dp(10));
                it.setBackground(bg);
            }
            ImageView ic = new ImageView(this);
            ic.setImageResource(ET_ICONS[i]);
            ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            it.addView(ic, new LinearLayout.LayoutParams(dp(24), dp(24)));
            TextView nm = new TextView(this);
            nm.setText(i == ET_GAP ? "Huecos: " + gapShort(canvas.getMangaGapLevel()) : ET_NAMES[i]);
            nm.setTextSize(i == ET_GAP ? 9f : 10f);
            nm.setSingleLine(true);
            nm.setGravity(Gravity.CENTER);
            nm.setTextColor(on ? 0xFF2EE6A6 : 0xFFC8C8D0);
            it.addView(nm, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            it.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (k == ET_GAP) easyGapDialog();
                    else easySetTool(k);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(itemW, dp(50));
            lp.setMargins(dp(1), 0, dp(1), 0);
            row.addView(it, lp);
        }
        // que la herramienta elegida quede a la vista
        final int sel = cur, w = itemW;
        hs.post(new Runnable() { @Override public void run() { hs.scrollTo(Math.max(0, (sel - 2) * w), 0); } });
        return hs;
    }

    private static String gapShort(int lv) {
        return lv <= 0 ? "No" : lv == 1 ? "Poco" : lv == 2 ? "Medio" : "Mucho";
    }

    /** Dibujito de "Cerrar huecos": un circulo con un corte; el color se escapa (No) o queda adentro. */
    private static final class GapIcon extends android.graphics.drawable.Drawable {
        private final int lv;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        GapIcon(int lv) { this.lv = lv; }

        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            float s = Math.min(b.width(), b.height()) / 100f;
            if (s <= 0f) return;
            c.save();
            c.translate(b.exactCenterX(), b.exactCenterY());
            c.scale(s, s);
            float gapDeg = 34f;
            // color de adentro (y afuera si no se cierra el hueco)
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(0xFFFF8FB0);
            c.drawCircle(-6f, 0f, 26f, p);
            if (lv == 0) {
                c.drawCircle(26f, 0f, 9f, p);
                c.drawCircle(40f, -6f, 6f, p);
                c.drawCircle(41f, 9f, 5f, p);
            }
            // linea del dibujo con el corte a la derecha
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            p.setStrokeWidth(7f);
            p.setColor(0xFFFFFFFF);
            c.drawArc(new android.graphics.RectF(-40f, -34f, 28f, 34f), gapDeg / 2f, 360f - gapDeg, false, p);
            // el balde "cose" el corte: mas puntos = cierra mas
            if (lv > 0) {
                p.setColor(0xFF2EE6A6);
                p.setStyle(android.graphics.Paint.Style.FILL);
                int dots = lv + 1;
                for (int i = 0; i < dots; i++) {
                    float t = dots == 1 ? 0.5f : i / (float) (dots - 1);
                    c.drawCircle(26.5f, -9f + 18f * t, 4.2f, p);
                }
            }
            c.restore();
        }

        @Override public void setAlpha(int a) { }

        @Override public void setColorFilter(android.graphics.ColorFilter cf) { }

        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private android.widget.PopupWindow gapPop;

    /** Elegir cuanto cierra los cortes de la linea, con dibujito y una frase cada uno. */
    private void easyGapDialog() {
        if (gapPop != null && gapPop.isShowing()) gapPop.dismiss();
        LinearLayout box = darkCard();
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        TextView title = new TextView(this);
        title.setText("Cerrar huecos de la linea");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(16f);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        box.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Si la linea tiene un cortecito, el color se escapa por ahi. Esto lo cierra.");
        sub.setTextColor(0xFF9A9AA6);
        sub.setTextSize(12f);
        sub.setPadding(0, dp(2), 0, dp(8));
        box.addView(sub);
        String[] names = {"No cerrar", "Poco", "Medio (recomendado)", "Mucho"};
        String[] what = {"Para lineas bien cerradas", "Cierra cortes chiquitos",
                "Cierra los cortes normales", "Cierra cortes grandes; puede no entrar en rincones finos"};
        int cur = canvas.getMangaGapLevel();
        for (int i = 0; i < 4; i++) {
            final int lv = i;
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(8), dp(6), dp(8), dp(6));
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(i == cur ? 0xFF1F5E4C : 0xFF2A2A32);
            bg.setCornerRadius(dp(10));
            r.setBackground(bg);
            ImageView ic = new ImageView(this);
            ic.setImageDrawable(new GapIcon(i));
            r.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
            LinearLayout tx = new LinearLayout(this);
            tx.setOrientation(LinearLayout.VERTICAL);
            tx.setPadding(dp(10), 0, 0, 0);
            TextView n = new TextView(this);
            n.setText(names[i]);
            n.setTextColor(i == cur ? 0xFF2EE6A6 : 0xFFFFFFFF);
            n.setTextSize(14f);
            tx.addView(n);
            TextView w = new TextView(this);
            w.setText(what[i]);
            w.setTextColor(0xFFB0B0BA);
            w.setTextSize(12f);
            tx.addView(w);
            r.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    canvas.setMangaGapLevel(lv);
                    saveMangaPrefs();
                    if (gapPop != null) gapPop.dismiss();
                    canvas.showHud("Cerrar huecos: " + gapShort(lv), 1200);
                    showEasyCard();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(3), 0, dp(3));
            box.addView(r, lp);
        }
        int w = Math.min(dp(360), getResources().getDisplayMetrics().widthPixels - dp(16));
        gapPop = showCardPop(box, box, null, w, 0.8f);
    }

    /** Avisos del lienzo en Colorear: tomar color y "el color se salio". */
    private void easyListen() {
        canvas.setZoneToolListener(new CanvasView.ZoneToolListener() {
            @Override public void onZonePicked(int color) {
                easyBase(color);
                canvas.setZoneTapTool(CanvasView.ZT_PAINT);
                canvas.showHud("Color tomado: ahora toca donde quieres pintar con el", 1800);
                if (easyCard != null) showEasyCard();
                updateUi();
            }

            @Override public void onZoneBig(int pct) {
                if (easyCard == null || easyNoBigAsk || destroyed) return;
                String[] items = {"Deshacer (quitar ese color)", "Deshacer y tapar el hueco con Separar",
                        "Esta bien asi", "Esta bien, no preguntar mas"};
                new SheetBuilder(MainActivity.this)
                        .setTitle("¿Se salio el color? Pinto el " + Math.min(100, pct) + "% del dibujo")
                        .setItems(items, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int i) {
                                if (i == 0 || i == 1) queueUndo(1);
                                if (i == 1) {
                                    easySetTool(ET_WALL);
                                    canvas.showHud("Dibuja una linea donde el color se escapo y vuelve a Pintar", 2600);
                                }
                                if (i == 3) easyNoBigAsk = true;
                            }
                        }).setNegativeButton("Cerrar", null).show();
            }
        });
    }

    /** Al salir del paso 1: el toque vuelve a pintar y Separar se apaga. */
    private void easyResetTool() {
        canvas.setWallMode(false);
        canvas.setZoneTapTool(CanvasView.ZT_PAINT);
    }

    private void showEasyCard() {
        removeEasyCardView();
        if (canvas.getProject() == null) return;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_panel);
        card.getBackground().setAlpha(225);
        card.setPadding(dp(6), dp(4), dp(6), dp(4));
        card.setClickable(true);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        String[] names = {"", "1 Color", "2 Acabado", "3 Final"};
        for (int k = 1; k <= 3; k++) {
            final int st = k;
            TextView b = easyButton(names[k], easyStep == k, new Runnable() { public void run() { easyGo(st); } });
            b.setPadding(dp(6), dp(5), dp(6), dp(5));
            head.addView(b);
        }
        ImageButton help = iconButton(R.drawable.ic_help, "Ver como se usa este paso", new Runnable() {
            public void run() { easyDemo(true); }
        });
        help.setBackground(null);
        head.addView(help, new LinearLayout.LayoutParams(dp(36), dp(36)));
        ImageButton close = iconButton(R.drawable.ic_close, "Cerrar Colorear facil", new Runnable() {
            public void run() { hideEasyCard(); updateUi(); }
        });
        close.setBackground(null);
        head.addView(close, new LinearLayout.LayoutParams(dp(36), dp(36)));
        card.addView(head);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        body.setGravity(Gravity.CENTER_VERTICAL);
        body.setPadding(0, dp(3), 0, 0);
        final Project p = canvas.getProject();
        if (easyStep == 1) {
            final boolean ray = canvas.isRayMode();
            // v9.00: fila de herramientas con nombre (antes un solo boton que cambiaba Tocar/Rayar)
            card.addView(easyToolRow());
            int tool = easyTool();
            if (tool == ET_ERASE) {
                // v9.05: 2 borradores, como en Borrar fondo
                final boolean smart = canvas.isEraseSmart();
                body.addView(easyButton("\uD83D\uDEE1 Protegido", smart, new Runnable() { public void run() {
                    easyEraseMode(true);
                }}));
                body.addView(easyButton("\u270B Libre", !smart, new Runnable() { public void run() {
                    easyEraseMode(false);
                }}));
                card.addView(body);
                TextView hint = new TextView(this);
                hint.setText(smart ? "No pasa la linea negra: solo borra la parte donde empiezas"
                        : "Borra justo por donde pasa el dedo, sin limites");
                hint.setTextColor(0xFFB8B8C2);
                hint.setTextSize(11.5f);
                hint.setGravity(Gravity.CENTER);
                hint.setPadding(dp(6), dp(1), dp(6), dp(2));
                card.addView(hint);
                placeCard(card);
                easyCard = card;
                return;
            }
            if (tool == ET_PICK || tool == ET_WALL) {
                TextView hint = new TextView(this);
                hint.setText(ET_HELP[tool]);
                hint.setTextColor(0xFFE0E0E6);
                hint.setTextSize(12.5f);
                hint.setPadding(dp(6), dp(4), dp(6), dp(4));
                body.addView(hint, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                if (tool == ET_WALL && canvas.hasZoneWalls()) {
                    TextView clr = softButton("Quitar lineas", false);
                    clr.setTextSize(12.5f);
                    clr.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            canvas.clearZoneWalls();
                            canvas.showHud("Lineas de Separar quitadas", 1200);
                            showEasyCard();
                        }
                    });
                    body.addView(clr, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));
                }
                card.addView(body);
                placeCard(card);
                easyCard = card;
                return;
            }
            ImageButton palB = iconButton(R.drawable.ic_color, "Paleta: " + easyPalette()[0][0], new Runnable() {
                public void run() { easyPaletteDialog(); }
            });
            body.addView(palB, new LinearLayout.LayoutParams(dp(40), dp(40)));
            android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout sw = new LinearLayout(this);
            sw.setOrientation(LinearLayout.HORIZONTAL);
            final String[][] pal = easyPalette();
            int cur = (ray ? canvas.getRayColor() : canvas.getZoneStyle().base) | 0xFF000000;
            if (ray) {
                TextView np = easyButton("No", canvas.isRayNoPaint(), new Runnable() { public void run() {
                    canvas.setRayNoPaint();
                    canvas.showHud("Raya lo que debe quedar sin color (fondo, ojos)", 1800);
                    showEasyCard();
                    updateUi();
                }});
                np.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(34)));
                np.setPadding(0, 0, 0, 0);
                sw.addView(np);
            }
            for (int k = 1; k < pal.length; k++) {
                final int c = (int) Long.parseLong(pal[k][1], 16) | 0xFF000000;
                final String nm = pal[k][0];
                View v = new View(this);
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setColor(c);
                g.setCornerRadius(dp(6));
                g.setStroke(dp(c == cur ? 3 : 1), c == cur ? 0xFF64B5F6 : 0xFF55555C);
                v.setBackground(g);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(32), dp(32));
                lp.setMargins(dp(2), 0, dp(2), 0);
                v.setLayoutParams(lp);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View x) { easyBase(c); canvas.showHud(nm, 900); showEasyCard(); }
                });
                sw.addView(v);
            }
            ImageButton more = iconButton(R.drawable.ic_add, "Mas colores", new Runnable() {
                public void run() {
                    colorDialog(new ColorPickTarget() { @Override public void onColor(int color) { easyBase(color); showEasyCard(); } },
                            canvas.getZoneStyle().base, "Color");
                }
            });
            sw.addView(more, new LinearLayout.LayoutParams(dp(36), dp(36)));
            ImageButton refB = iconButton(R.drawable.ic_ref_color, "Color de la referencia", new Runnable() {
                public void run() {
                    requestColorReference(new ColorPickTarget() { @Override public void onColor(int color) { easyBase(color); showEasyCard(); } });
                }
            });
            sw.addView(refB, new LinearLayout.LayoutParams(dp(36), dp(36)));
            hs.addView(sw);
            body.addView(hs, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        } else if (easyStep == 2) {
            // v8.60: Acabado (sol, fuerza, retoques, antes, aceptar)
            card.addView(body);
            finCardRows(card);
            placeCard(card);
            easyCard = card;
            return;
        } else {
            body.addView(easyIcon(R.drawable.ic_rimfx, "Brillo y fondo", new Runnable() { public void run() { zoneFxDialog(); } }));
            body.addView(easyIcon(R.drawable.ic_soft, "Toques: rubor, sombra y luz que se funden", new Runnable() { public void run() { softOpen(-1); } }));
            body.addView(easyIcon(R.drawable.ic_zone_list, "Cambiar una parte", new Runnable() { public void run() { zoneListDialog(); } }));
            body.addView(easyIcon(R.drawable.ic_save, "Guardar paleta", new Runnable() { public void run() { easySavePalette(); } }));
            ImageButton ok = easyIcon(R.drawable.ic_check, "Terminar", new Runnable() { public void run() {
                hideEasyCard();
                updateUi();
                canvas.showHud("¡Listo!", 1500);
            }});
            ok.setBackgroundResource(R.drawable.bg_save);
            body.addView(ok);
        }
        card.addView(body);
        placeCard(card);
        easyCard = card;
    }

    /**
     * v8.55: las tarjetas de Colorear, Toques y Luz/Estilo van ABAJO, encima de las herramientas, y
     * un poco transparentes: arriba y al centro se ve el dibujo y si el ajuste se aplica.
     */
    /** v8.59: tarjetas abiertas (Luz, Estilo, Colorear...). Nunca quedan encima de Capas o Herramientas. */
    private final java.util.List<java.lang.ref.WeakReference<View>> placedCards = new ArrayList<java.lang.ref.WeakReference<View>>();

    /** Esconde (o vuelve a mostrar) las tarjetas mientras esta abierto Capas o Herramientas. */
    private void hideCards(boolean hide) {
        for (int i = placedCards.size() - 1; i >= 0; i--) {
            View v = placedCards.get(i).get();
            if (v == null || v.getParent() == null) { placedCards.remove(i); continue; }
            v.setVisibility(hide ? View.GONE : View.VISIBLE);
        }
    }

    private void placeCard(View card) {
        // abrir una tarjeta cierra Capas y Herramientas (una cosa a la vez, sin taparse)
        if (findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE) closeLayers();
        if (findViewById(R.id.toolPanel).getVisibility() == View.VISIBLE) closeTools();
        placedCards.add(new java.lang.ref.WeakReference<View>(card));
        // v9.01: casi opaca (antes 205: se veian los textos de abajo a traves y parecian encimados)
        if (card.getBackground() != null) card.getBackground().setAlpha(238);
        watchBottomForCards();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        View bottom = findViewById(R.id.bottomPanel);
        lp.bottomMargin = (bottom != null && bottom.getHeight() > 0 ? bottom.getHeight() : dp(150)) + dp(4);
        lp.leftMargin = lp.rightMargin = dp(6);
        ((ViewGroup) findViewById(android.R.id.content)).addView(card, lp);
    }

    private boolean cardsWatchOn;

    /**
     * v9.01: si la barra de abajo cambia de alto (sale o se va una fila), las tarjetas suben o bajan
     * con ella. Antes quedaban donde estaban y tapaban la barra ("Antes" y "Mas" encima del texto).
     */
    private void watchBottomForCards() {
        if (cardsWatchOn) return;
        final View bottom = findViewById(R.id.bottomPanel);
        if (bottom == null) return;
        cardsWatchOn = true;
        bottom.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                if (b - t == ob - ot) return;
                int want = (v.getHeight() > 0 ? v.getHeight() : dp(150)) + dp(4);
                for (java.lang.ref.WeakReference<View> w : placedCards) {
                    View c = w.get();
                    if (c == null || !(c.getLayoutParams() instanceof FrameLayout.LayoutParams)) continue;
                    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) c.getLayoutParams();
                    if (lp.bottomMargin != want) {
                        lp.bottomMargin = want;
                        c.setLayoutParams(lp);
                    }
                }
            }
        });
    }

    private ImageButton easyIcon(int icon, String what, Runnable r) {
        ImageButton b = iconButton(icon, what, r);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(lp);
        return b;
    }

    /** Ir a un paso (al pasar del 1 al 2 se aplica lo pendiente y salen las sombras). */
    private void easyGo(int step) {
        if (step == easyStep) return;
        if (easyStep == 1 && step > 1) {
            if (canvas.isRayMode() && canvas.hasRayMarks()) canvas.rayToZones(easyFinish);
            if (canvas.hasFillPreview()) { canvas.acceptFillPreview(); updateUi(); }
            if (canvas.getProject().zones.isEmpty() && !canvas.isBusy()) {
                toast("Primero pinta alguna parte con el paso 1");
                return;
            }
        }
        // v8.60: salir del Acabado lo deja puesto (Aceptar); para quitarlo esta la X del Acabado
        if (easyStep == 2 && step != 2 && finOpen()) finAccept();
        if (easyStep == 1 && step != 1) easyResetTool();    // v9.00: Borrar/Tomar/Separar solo en el paso 1
        if (step == 1) {
            easyBase(canvas.getZoneStyle().base);
            if (!canvas.isRayMode()) selectColorBucket();   // el Acabado usa la mano: volver al balde
        } else if (canvas.isRayMode()) {
            canvas.setRayMode(false);
            selectColorBucket();
        }
        easyStep = step;
        if (step == 2) finishOpen();   // v8.60: el paso 2 es el Acabado (antes: sombras viejas)
        showEasyCard();
        updateUi();
        easyDemo(false);
    }

    /** Animacion de lo que hace el paso. force=false: solo la primera vez de cada paso. */
    private void easyDemo(boolean force) {
        // v8.59: sin animaciones automaticas al colorear (solo si se pide con "?")
        if (!force) return;
        int kind = easyStep == 1 ? (canvas.isRayMode() ? 1 : 0) : easyStep == 2 ? 2 : 3;
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        String key = "easy_demo_" + kind;
        if (!force && sp.getBoolean(key, false)) return;
        sp.edit().putBoolean(key, true).apply();
        String[] cap = {"Toca un color y luego la parte. ✓ abajo.", "Elige color y raya cada parte. ✓ abajo.",
                "Arrastra el sol. Sombra + y Luz + retocan. ✓ deja el acabado.", "Brillo, fondo y retoques."};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(4));
        root.addView(new com.pacco.animecut.view.EasyDemoView(this, kind), new LinearLayout.LayoutParams(dp(200), dp(200)));
        TextView t = new TextView(this);
        t.setText(cap[kind]);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(14f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(10), 0, 0);
        root.addView(t);
        new SheetBuilder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    /** Acciones del preset, agrupadas para no llenar la pantalla. */
    private void mangaMenu() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final List<String> items = new ArrayList<String>();
        // v8.54: el balde de colorear manga es una opcion aparte (el Relleno normal no cambia)
        items.add("Balde de colorear manga (por lineas)");
        items.add("Sombra rapida (toque suave)");
        items.add("Luz rapida (toque suave, dar vida)");
        items.add("Brillo encima (ojos)");
        items.add("Cambiar color de la capa elegida");
        if (p.hasSelection()) {
            items.add("Rellenar lo seleccionado con el color");
            items.add("Proteger lo seleccionado (No colorear)");
            items.add("Quitar proteccion de lo seleccionado");
        }
        if (canvas.hasProtectZones()) items.add("Borrar todas las zonas protegidas");
        items.add(canvas.isShowProtect() ? "Ver zonas protegidas: SI" : "Ver zonas protegidas: NO");
        items.add("Imagen de referencia");
        items.add("Paleta de la obra (" + p.swatches.size() + " colores)");
        items.add("Gotero: " + pickName(canvas.getPickSource()));
        items.add("Ajustes del balde manga");
        items.add("Salir de Colorear manga");
        new SheetBuilder(this)
                .setTitle("Colorear manga")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        runMangaItem(items.get(i));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void runMangaItem(String it) {
        if (it.startsWith("Balde de colorear")) {
            selectColorBucket();
            canvas.showHud("Balde de colorear: toca una zona del manga");
        } else if (it.startsWith("Sombra rapida")) {
            softOpen(CanvasView.SOFT_SHADOW);
        } else if (it.startsWith("Luz rapida")) {
            softOpen(CanvasView.SOFT_LIGHT);
        } else if (it.startsWith("Brillo encima")) {
            canvas.addShineLayer();
            afterLayerOp();
        } else if (it.startsWith("Cambiar color")) {
            Layer l = canvas.getProject().activeLayer();
            if (l == null) toast("Elige una capa en Capas");
            else changeColorDialog(l);
        } else if (it.startsWith("Rellenar lo seleccionado")) {
            canvas.fillSelectionWithColor();
        } else if (it.startsWith("Proteger lo seleccionado")) {
            canvas.protectSelection(true);
            updateUi();
        } else if (it.startsWith("Quitar proteccion")) {
            canvas.protectSelection(false);
            updateUi();
        } else if (it.startsWith("Borrar todas las zonas")) {
            canvas.clearProtect();
        } else if (it.startsWith("Ver zonas")) {
            canvas.setShowProtect(!canvas.isShowProtect());
            saveMangaPrefs();
        } else if (it.startsWith("Imagen de referencia")) {
            requestColorReference(paintColorTarget());
        } else if (it.startsWith("Paleta")) {
            paletteDialog();
        } else if (it.startsWith("Gotero")) {
            pickSourceDialog();
        } else if (it.startsWith("Ajustes del balde")) {
            mangaFillSettingsDialog();
        } else if (it.startsWith("Salir")) {
            new SheetBuilder(this)
                    .setTitle("Salir de Colorear manga")
                    .setMessage("El balde vuelve a ser el normal y la Tinta B/N se desbloquea. Tus capas de color se quedan.")
                    .setPositiveButton("Salir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.exitManga();
                            afterLayerOp();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        }
    }

    private static String pickName(int s) {
        return s == CanvasView.PICK_VISIBLE ? "Visible (lo que se ve)"
                : s == CanvasView.PICK_LAYER ? "Capa actual" : "Automatico (Capa actual en Multiplicar)";
    }

    private void pickSourceDialog() {
        final String[] items = {"Automatico: en capas Multiplicar toma de la capa; si no, lo visible",
                "Visible: el color que se ve (tinta + color)",
                "Capa actual: el color guardado en la capa elegida"};
        new SheetBuilder(this)
                .setTitle("¿De donde toma el color el gotero?")
                .setSingleChoiceItems(items, canvas.getPickSource(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        d.dismiss();
                        canvas.setPickSource(i);
                        saveMangaPrefs();
                        canvas.showHud("Gotero: " + pickName(i));
                        updateUi();
                    }
                })
                .show();
    }

    /** Ajustes del balde manga, todos en un solo lugar. */
    private void mangaFillSettingsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        final TextView inkT = smallText("");
        final SeekBar ink = new SeekBar(this);
        ink.setMax(160);
        ink.setProgress(canvas.getMangaInk() - 40);
        final Runnable inkLabel = new Runnable() {
            @Override public void run() {
                int v = ink.getProgress() + 40;
                inkT.setText("Que cuenta como linea: " + v + (v < 100 ? " (solo lo muy negro)" : v > 160 ? " (tambien grises)" : " (medio)"));
            }
        };
        inkLabel.run();
        ink.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { inkLabel.run(); }
        });
        root.addView(inkT);
        root.addView(ink);
        root.addView(optLabel("Cerrar huecos de lineas abiertas"));
        final RadioGroup gap = choiceRow(com.pacco.animecut.core.MangaFill.GAP_NAMES, canvas.getMangaGapLevel(), new IntConsumerCompat() { public void accept(int v) { } });
        root.addView(gap);
        final TextView expT = smallText("");
        final SeekBar exp = new SeekBar(this);
        exp.setMax(4);
        exp.setProgress(canvas.getMangaExpand());
        final Runnable expLabel = new Runnable() {
            @Override public void run() {
                expT.setText("Meter el color bajo la linea: " + exp.getProgress() + " px (evita bordes blancos)");
            }
        };
        expLabel.run();
        exp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { expLabel.run(); }
        });
        root.addView(expT);
        root.addView(exp);
        root.addView(optLabel("Modo trama (puntos de trama dentro de la zona)"));
        final RadioGroup tone = choiceRow(new String[]{"No", "Puntos", "Densa"}, canvas.getMangaToneLevel(),
                new IntConsumerCompat() { public void accept(int v) { } });
        root.addView(tone);
        root.addView(smallText("Densa: tambien entra hasta 24 px en la trama tupida pegada (puede tocar la trama de la zona de al lado: revisa la vista previa)."));
        final CheckBox prev = new CheckBox(this);
        prev.setText("Vista previa antes de pintar (Aceptar / Cancelar)");
        prev.setTextColor(0xFFFFFFFF);
        prev.setChecked(canvas.isFillPreview());
        root.addView(prev);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new SheetBuilder(this)
                .setTitle("Balde manga")
                .setView(sv)
                .setPositiveButton("Listo", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setMangaInk(ink.getProgress() + 40);
                        int g = 0;
                        for (int k = 0; k < gap.getChildCount(); k++)
                            if (((RadioButton) gap.getChildAt(k)).isChecked()) g = k;
                        canvas.setMangaGapLevel(g);
                        canvas.setMangaExpand(exp.getProgress());
                        int tl = 1;
                        for (int k = 0; k < tone.getChildCount(); k++)
                            if (((RadioButton) tone.getChildAt(k)).isChecked()) tl = k;
                        canvas.setMangaToneLevel(tl);
                        canvas.setFillPreview(prev.isChecked());
                        saveMangaPrefs();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }


    // ================================================================== v8.40 COLOR POR ZONAS
    // Dentro de "Colorear manga" (balde manga): un boton prende "Color por zonas". Flujo: tocar
    // zona(s) -> vista previa con el color de verdad -> trio (sombra/base/luz, de la referencia o
    // del selector) y acabado -> ✓. Cada zona queda guardada y se puede cambiar despues.

    private void addZoneToggle(LinearLayout bar) {
        ImageButton b = iconButton(R.drawable.ic_zone_grad, canvas.isZoneMode() ? "Color por zonas: SI" : "Color por zonas (sombra, base y luz por zona)", new Runnable() {
            public void run() {
                boolean on = !canvas.isZoneMode();
                canvas.setZoneMode(on);
                canvas.showHud(on ? "Color por zonas: toca una zona, elige el trio y ✓" : "Color por zonas apagado: balde manga normal", 2600);
                updateUi();
            }
        });
        b.setBackgroundResource(canvas.isZoneMode() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(b);
    }

    /** Barra del balde manga con Color por zonas prendido (pocos botones, nombre al mantener pulsado). */
    private void buildZoneBar(LinearLayout bar) {
        if (easyCard != null) {
            // v8.45: con Colorear facil abierto, abajo solo lo necesario: ✓ y X de la vista previa
            if (canvas.hasFillPreview()) {
                ImageButton ok = iconButton(R.drawable.ic_check, "Pintar esta parte", new Runnable() {
                    public void run() { canvas.acceptFillPreview(); updateUi(); }
                });
                ok.setBackgroundResource(R.drawable.bg_save);
                bar.addView(ok);
                bar.addView(iconButton(R.drawable.ic_close, "No pintar", new Runnable() {
                    public void run() { canvas.cancelFillPreview(); updateUi(); }
                }));
            } else {
                TextView tip = new TextView(this);
                tip.setText("Toca una parte del dibujo");
                tip.setTextColor(0xFFB0B8C4);
                tip.setTextSize(13f);
                tip.setPadding(dp(10), dp(8), dp(10), dp(8));
                bar.addView(tip);
            }
            return;
        }
        if (canvas.hasFillPreview()) {
            ImageButton ok = iconButton(R.drawable.ic_check, "Aplicar: colorear la zona con el trio y el acabado", new Runnable() {
                public void run() { canvas.acceptFillPreview(); updateUi(); }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
            bar.addView(iconButton(R.drawable.ic_similar, "Parecidas: sugerir zonas como esta (tu confirmas)", new Runnable() {
                public void run() { canvas.suggestSimilarZones(); }
            }));
            bar.addView(iconButton(R.drawable.ic_select, "Sumar lo seleccionado (Lazo / Varita) a la zona", new Runnable() {
                public void run() { canvas.addSelectionAsZone(); updateUi(); }
            }));
            bar.addView(iconButton(R.drawable.ic_close, "Cancelar: no pintar nada", new Runnable() {
                public void run() { canvas.cancelFillPreview(); updateUi(); }
            }));
            bar.addView(trioChip());
            bar.addView(finishChip());
            return;
        }
        addZoneToggle(bar);
        bar.addView(trioChip());
        bar.addView(finishChip());
        if (canvas.getZoneSel() >= 0) {
            bar.addView(iconButton(R.drawable.ic_redo, "Aplicar el trio y el acabado a la zona " + (canvas.getZoneSel() + 1), new Runnable() {
                public void run() {
                    int i = canvas.getZoneSel();
                    if (i < 0) return;
                    canvas.restyleZone(i, canvas.getZoneStyle());
                    canvas.showHud("Zona " + (i + 1) + " actualizada");
                }
            }));
        }
        bar.addView(iconButton(R.drawable.ic_select, "Usar lo seleccionado (Lazo / Varita) como zona", new Runnable() {
            public void run() { canvas.addSelectionAsZone(); updateUi(); }
        }));
        bar.addView(iconButton(R.drawable.ic_rimfx, "Luces y fondo (brillo de contorno, fondo degradado)", new Runnable() {
            public void run() { zoneFxDialog(); }
        }));
        bar.addView(iconButton(R.drawable.ic_zone_list, "Zonas pintadas (cambiar o borrar)", new Runnable() {
            public void run() { zoneListDialog(); }
        }));
        bar.addView(iconButton(R.drawable.ic_manga, "Colorear manga: mas opciones", new Runnable() {
            public void run() { mangaMenu(); }
        }));
    }

    /** Muestra del trio (sombra | base | luz). Tocar = elegir colores. */
    private View trioChip() {
        final com.pacco.animecut.core.ZoneTone.Style st = canvas.getZoneStyle();
        View v = new View(this) {
            final android.graphics.Paint pp = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(android.graphics.Canvas c) {
                int w = getWidth(), h = getHeight();
                int[] cs = {st.shadow, st.base, st.light};
                float pad = dp(5), cw = (w - 2 * pad) / 3f;
                for (int k = 0; k < 3; k++) {
                    pp.setStyle(android.graphics.Paint.Style.FILL);
                    pp.setColor(cs[k] | 0xFF000000);
                    c.drawRect(pad + k * cw, pad, pad + (k + 1) * cw, h - pad, pp);
                }
                pp.setStyle(android.graphics.Paint.Style.STROKE);
                pp.setStrokeWidth(dp(1));
                pp.setColor(0xFFFFFFFF);
                c.drawRect(pad, pad, w - pad, h - pad, pp);
            }
        };
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(50), dp(38));
        lp.setMargins(dp(2), 0, dp(2), 0);
        v.setLayoutParams(lp);
        v.setBackgroundResource(R.drawable.bg_tool);
        v.setContentDescription("Trio: sombra, base y luz");
        v.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View x) { zoneTrioDialog(); }
        });
        v.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View x) { toast("Trio: sombra, base y luz de la zona"); return true; }
        });
        return v;
    }

    private View finishChip() {
        final com.pacco.animecut.core.ZoneTone.Style st = canvas.getZoneStyle();
        TextView t = smallTextButton(com.pacco.animecut.core.ZoneTone.FINISH_SHORT[st.finish] + " " + st.intensity + "%");
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { zoneFinishDialog(); }
        });
        return t;
    }

    private void setZoneStyleUi(com.pacco.animecut.core.ZoneTone.Style st) {
        canvas.setZoneStyle(st);
        updateUi();
    }

    /** Sombra / Base / Luz: cada una se cambia con el selector; o todo desde un color o la referencia. */
    private void zoneTrioDialog() {
        final com.pacco.animecut.core.ZoneTone.Style st = canvas.getZoneStyle().copy();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(8), dp(14), dp(4));
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row);
        final AlertDialog[] dlg = new AlertDialog[1];
        final Runnable[] fill = new Runnable[1];
        final String[] names = {"Sombra", "Base", "Luz"};
        fill[0] = new Runnable() {
            @Override public void run() {
                row.removeAllViews();
                final int[] cs = {st.shadow, st.base, st.light};
                for (int k = 0; k < 3; k++) {
                    final int kk = k;
                    LinearLayout cell = new LinearLayout(MainActivity.this);
                    cell.setOrientation(LinearLayout.VERTICAL);
                    cell.setGravity(Gravity.CENTER_HORIZONTAL);
                    LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                    clp.setMargins(dp(3), 0, dp(3), 0);
                    View sw = new View(MainActivity.this);
                    android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                    g.setColor(cs[k] | 0xFF000000);
                    g.setCornerRadius(dp(6));
                    g.setStroke(dp(1), 0xFF9A9AA2);
                    sw.setBackground(g);
                    cell.addView(sw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
                    TextView t = smallText(names[k]);
                    t.setGravity(Gravity.CENTER);
                    cell.addView(t);
                    cell.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            colorDialog(new ColorPickTarget() {
                                @Override public void onColor(int c) {
                                    if (kk == 0) st.shadow = c; else if (kk == 1) st.base = c; else st.light = c;
                                    setZoneStyleUi(st.copy());
                                    fill[0].run();
                                }
                            }, cs[kk], names[kk]);
                        }
                    });
                    row.addView(cell, clp);
                }
            }
        };
        fill[0].run();
        root.addView(smallText("Toca un color para cambiarlo. La sombra y la luz se pueden proponer solas:"));
        String[] acts = {"Desde el color del pincel", "Tomar de la referencia (toca el lugar)", "Paleta de la referencia (8-12 grupos)",
                "Proponer sombra y luz desde la base"};
        for (int k = 0; k < acts.length; k++) {
            final int kk = k;
            TextView b = smallAction(acts[k]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
            lp.setMargins(0, dp(5), 0, 0);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (kk == 0) { com.pacco.animecut.core.ZoneTone.trioFrom(canvas.getColor(), st); setZoneStyleUi(st.copy()); fill[0].run(); }
                    else if (kk == 3) { com.pacco.animecut.core.ZoneTone.trioFrom(st.base, st); setZoneStyleUi(st.copy()); fill[0].run(); }
                    else if (kk == 1) {
                        if (dlg[0] != null) dlg[0].dismiss();
                        toast("Toca en la referencia la parte que quieres (pelo, piel...) y luego Usar");
                        requestColorReference(zoneRefTarget());
                    } else {
                        if (dlg[0] != null) dlg[0].dismiss();
                        zonePaletteDialog();
                    }
                }
            });
            root.addView(b, lp);
        }
        dlg[0] = new SheetBuilder(this).setTitle("Trio de la zona").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    /** "Usar" de la referencia en Color por zonas: sombra/base/luz de ESE lugar de la referencia. */
    private ColorPickTarget zoneRefTarget() {
        return new ColorPickTarget() {
            @Override public void onColor(int c) {
                com.pacco.animecut.core.ZoneTone.Style st = canvas.getZoneStyle().copy();
                Bitmap rb = colorRefBitmap;
                int x = colorRefView != null ? colorRefView.pickX : -1, y = colorRefView != null ? colorRefView.pickY : -1;
                int[] px = refPixels();
                if (px != null && rb != null && x >= 0 && y >= 0 && x < rb.getWidth() && y < rb.getHeight()) {
                    int sx = Math.min(refPxW - 1, Math.round(x * refPxScale)), sy = Math.min(refPxH - 1, Math.round(y * refPxScale));
                    com.pacco.animecut.core.ZoneTone.trioAt(px, refPxW, refPxH, sx, sy, 1, refGroups(), st);
                } else {
                    com.pacco.animecut.core.ZoneTone.trioFrom(c, st);
                }
                setZoneStyleUi(st);
                canvas.showHud("Trio tomado de la referencia: sombra, base y luz de esa parte");
            }
        };
    }

    private int[] refPixelsCache;
    private Bitmap refPixelsOf;
    private int refPxW, refPxH;
    private float refPxScale = 1f;
    private java.util.List<com.pacco.animecut.core.ZoneTone.Group> refGroupsCache;

    /** Pixeles de la referencia reducidos a 1024 px de lado (poca memoria). */
    private int[] refPixels() {
        Bitmap b = colorRefBitmap;
        if (b == null || b.isRecycled()) return null;
        if (refPixelsOf != b || refPixelsCache == null) {
            try {
                float sc = Math.min(1f, 1024f / Math.max(b.getWidth(), b.getHeight()));
                Bitmap s = sc < 1f ? Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)),
                        Math.max(1, Math.round(b.getHeight() * sc)), true) : b;
                int[] px = new int[s.getWidth() * s.getHeight()];
                s.getPixels(px, 0, s.getWidth(), 0, 0, s.getWidth(), s.getHeight());
                refPxW = s.getWidth();
                refPxH = s.getHeight();
                refPxScale = sc;
                if (s != b) s.recycle();
                refPixelsCache = px;
                refPixelsOf = b;
                refGroupsCache = null;
            } catch (OutOfMemoryError e) {
                return null;
            }
        }
        return refPixelsCache;
    }

    private java.util.List<com.pacco.animecut.core.ZoneTone.Group> refGroups() {
        int[] px = refPixels();
        if (px == null) return canvas.getProject() != null ? canvas.getProject().zonePalette : null;
        if (refGroupsCache == null) refGroupsCache = com.pacco.animecut.core.ZoneTone.groups(px, refPxW, refPxH, 10);
        return refGroupsCache;
    }

    /** Paleta mejorada: 8-12 grupos de la referencia, cada uno con sombra/base/luz. */
    private void zonePaletteDialog() {
        final Project p = canvas.getProject();
        if (p == null) return;
        if (colorRefBitmap == null && p.zonePalette.isEmpty()) {
            toast("Primero abre una imagen de referencia");
            requestColorReference(zoneRefTarget());
            return;
        }
        final java.util.List<com.pacco.animecut.core.ZoneTone.Group>[] gs = new java.util.List[1];
        runBusy("Sacando la paleta...", new Runnable() {
            @Override public void run() { gs[0] = refGroups(); }
        }, new Runnable() {
            @Override public void run() {
                if (gs[0] == null || gs[0].isEmpty()) { toast("No se encontraron colores"); return; }
                p.zonePalette = new java.util.ArrayList<com.pacco.animecut.core.ZoneTone.Group>(gs[0]);
                markDirty();
                LinearLayout root = new LinearLayout(MainActivity.this);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(14), dp(6), dp(14), dp(6));
                root.addView(smallText("Cada fila: sombra, base y luz que pinto el artista. Toca una para usarla."));
                final AlertDialog[] dlg = new AlertDialog[1];
                for (final com.pacco.animecut.core.ZoneTone.Group g : gs[0]) {
                    LinearLayout r = new LinearLayout(MainActivity.this);
                    r.setOrientation(LinearLayout.HORIZONTAL);
                    r.setPadding(0, dp(4), 0, dp(4));
                    for (int c : new int[]{g.shadow, g.base, g.light}) {
                        View v = new View(MainActivity.this);
                        v.setBackgroundColor(c | 0xFF000000);
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
                        lp.setMargins(dp(1), 0, dp(1), 0);
                        r.addView(v, lp);
                    }
                    r.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            com.pacco.animecut.core.ZoneTone.Style st = canvas.getZoneStyle().copy();
                            st.shadow = g.shadow; st.base = g.base; st.light = g.light;
                            setZoneStyleUi(st);
                            if (dlg[0] != null) dlg[0].dismiss();
                        }
                    });
                    root.addView(r);
                }
                ScrollView sv = new ScrollView(MainActivity.this);
                sv.addView(root);
                dlg[0] = new SheetBuilder(MainActivity.this).setTitle("Paleta de la referencia").setView(sv)
                        .setNegativeButton("Cerrar", null).show();
            }
        });
    }

    private static final String[] DIR_ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

    /** Fila de 8 flechas: de donde viene la luz. */
    private LinearLayout dirRow(final int[] dir, final Runnable changed) {
        final LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        final Runnable[] paint = new Runnable[1];
        paint[0] = new Runnable() {
            @Override public void run() {
                for (int k = 0; k < r.getChildCount(); k++)
                    r.getChildAt(k).setBackgroundResource(k == dir[0] ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            }
        };
        for (int k = 0; k < 8; k++) {
            final int kk = k;
            TextView t = smallTextButton(DIR_ARROWS[k]);
            t.setTextSize(16f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            lp.setMargins(dp(1), 0, dp(1), 0);
            t.setLayoutParams(lp);
            t.setContentDescription("Luz desde: " + com.pacco.animecut.core.ZoneTone.DIR_NAMES[k]);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dir[0] = kk; paint[0].run(); if (changed != null) changed.run(); }
            });
            r.addView(t);
        }
        paint[0].run();
        return r;
    }

    /** Acabado (Suave light novel, Anime 2 tonos, Pintado, Multiplicar, Mejorar color) e intensidad. */
    private void zoneFinishDialog() {
        final com.pacco.animecut.core.ZoneTone.Style st = canvas.getZoneStyle().copy();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(6), dp(14), dp(6));
        final Runnable live = new Runnable() { @Override public void run() { canvas.setZoneStyle(st.copy()); } };
        root.addView(optLabel("Acabado"));
        RadioGroup fin = new RadioGroup(this);
        fin.setOrientation(LinearLayout.VERTICAL);
        String[] tips = {" · degradado suave desde los grises", " · base y sombra con borde definido",
                " · sombra mas viva y luz ambiental", " · el de antes (color por encima del gris)", " · para imagenes que ya son a color"};
        for (int i = 0; i < com.pacco.animecut.core.ZoneTone.FINISH_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(com.pacco.animecut.core.ZoneTone.FINISH_NAMES[i] + tips[i]);
            rb.setTextColor(0xFFFFFFFF);
            rb.setTextSize(13f);
            rb.setId(2000 + i);
            fin.addView(rb);
        }
        fin.check(2000 + st.finish);
        fin.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int id) {
                st.finish = id - 2000;
                if (st.finish == com.pacco.animecut.core.ZoneTone.IMPROVE && st.intensity > 60) st.intensity = 50;
                live.run();
            }
        });
        root.addView(fin);
        final TextView it = optLabel("Intensidad: " + st.intensity + "%");
        root.addView(it);
        SeekBar ib = new SeekBar(this);
        ib.setMax(100);
        ib.setProgress(st.intensity);
        ib.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar b, int v, boolean u) { st.intensity = v; it.setText("Intensidad: " + v + "%"); }
            @Override public void onStopTrackingTouch(SeekBar b) { live.run(); }
        });
        root.addView(ib);
        final CheckBox tex = new CheckBox(this);
        tex.setText("Trama de puntitos: conservar su textura (si no, color liso)");
        tex.setTextColor(0xFFFFFFFF);
        tex.setChecked(st.keepTexture);
        root.addView(tex);
        final CheckBox blk = new CheckBox(this);
        blk.setText("Tenir lo negro (pelo negro, lineas) con la sombra");
        blk.setTextColor(0xFFFFFFFF);
        blk.setChecked(st.tintBlack);
        root.addView(blk);
        final CheckBox wht = new CheckBox(this);
        wht.setText("Brillos blancos de ojos y pelo siguen blancos");
        wht.setTextColor(0xFFFFFFFF);
        wht.setChecked(st.keepWhites);
        root.addView(wht);
        CompoundButton.OnCheckedChangeListener cl = new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                st.keepTexture = tex.isChecked(); st.tintBlack = blk.isChecked(); st.keepWhites = wht.isChecked();
                live.run();
            }
        };
        tex.setOnCheckedChangeListener(cl);
        blk.setOnCheckedChangeListener(cl);
        wht.setOnCheckedChangeListener(cl);
        root.addView(optLabel("Sombra por direccion de luz (para dibujos sin grises)"));
        root.addView(choiceRow(new String[]{"Auto", "Si", "No"}, st.lightShade, new IntConsumerCompat() {
            public void accept(int v) { st.lightShade = v; live.run(); }
        }));
        root.addView(smallText("Auto: solo en zonas sin grises (solo lineas). La sombra es inventada segun la luz."));
        root.addView(optLabel("La luz viene de"));
        final int[] dir = {st.lightDir};
        root.addView(dirRow(dir, new Runnable() { @Override public void run() { st.lightDir = dir[0]; live.run(); } }));
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new SheetBuilder(this).setTitle("Acabado de la zona").setView(sv)
                .setPositiveButton("Listo", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { setZoneStyleUi(st.copy()); }
                }).show();
    }

    /** Luces y fondo: brillo de contorno (lado de la luz) y fondo degradado de dos colores. */
    private void zoneFxDialog() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int[] fx = p.zoneFx.clone();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(6), dp(14), dp(6));
        final AlertDialog[] dlg = new AlertDialog[1];
        root.addView(optLabel("Brillo de contorno"));
        final View rimSw = colorCell(fx[0], "Color del brillo", new ColorPickTarget() {
            @Override public void onColor(int c) { fx[0] = c; }
        });
        root.addView(rimSw);
        root.addView(smallText("La luz viene de:"));
        final int[] dir = {fx[1]};
        root.addView(dirRow(dir, null));
        final TextView wt = smallText("Ancho: " + fx[2]);
        root.addView(wt);
        SeekBar wb = new SeekBar(this);
        wb.setMax(9);
        wb.setProgress(Math.max(0, fx[2] - 1));
        wb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar b, int v, boolean u) { fx[2] = v + 1; wt.setText("Ancho: " + fx[2]); }
        });
        root.addView(wb);
        LinearLayout rb = new LinearLayout(this);
        rb.setOrientation(LinearLayout.HORIZONTAL);
        TextView ra = smallAction("Aplicar brillo"), rq = smallAction("Quitar brillo");
        rb.addView(ra, new LinearLayout.LayoutParams(0, dp(40), 1f));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        qlp.setMargins(dp(6), 0, 0, 0);
        rb.addView(rq, qlp);
        root.addView(rb);
        ra.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (dlg[0] != null) dlg[0].dismiss(); canvas.applyRim(fx[0], dir[0], fx[2]); }
        });
        rq.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (dlg[0] != null) dlg[0].dismiss(); canvas.removeRoleLayer(Layer.ROLE_RIM); afterLayerOp(); }
        });
        root.addView(optLabel("Fondo degradado (en su capa; el fondo original no se borra)"));
        LinearLayout gr = new LinearLayout(this);
        gr.setOrientation(LinearLayout.HORIZONTAL);
        gr.addView(colorCell(fx[3], "Arriba", new ColorPickTarget() { @Override public void onColor(int c) { fx[3] = c; } }),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        gr.addView(colorCell(fx[4], "Abajo", new ColorPickTarget() { @Override public void onColor(int c) { fx[4] = c; } }),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(gr);
        LinearLayout gb = new LinearLayout(this);
        gb.setOrientation(LinearLayout.HORIZONTAL);
        TextView ga = smallAction("Aplicar fondo"), gq = smallAction("Quitar fondo");
        gb.addView(ga, new LinearLayout.LayoutParams(0, dp(40), 1f));
        LinearLayout.LayoutParams g2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        g2.setMargins(dp(6), 0, 0, 0);
        gb.addView(gq, g2);
        root.addView(gb);
        ga.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (dlg[0] != null) dlg[0].dismiss(); canvas.applyGradient(fx[3], fx[4]); }
        });
        gq.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (dlg[0] != null) dlg[0].dismiss(); canvas.removeRoleLayer(Layer.ROLE_GRAD); afterLayerOp(); }
        });
        root.addView(smallText("Brillo y fondo van en capas propias: se apagan con el ojo en Capas sin tocar tu dibujo."));
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dlg[0] = new SheetBuilder(this).setTitle("Luces y fondo").setView(sv).setNegativeButton("Cerrar", null).show();
    }

    /** Cuadro de color con su nombre: tocar abre el selector. */
    private View colorCell(final int initial, final String name, final ColorPickTarget to) {
        final LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.HORIZONTAL);
        cell.setGravity(Gravity.CENTER_VERTICAL);
        cell.setPadding(0, dp(4), dp(6), dp(4));
        final View sw = new View(this);
        sw.setBackgroundColor(initial | 0xFF000000);
        cell.addView(sw, new LinearLayout.LayoutParams(dp(44), dp(30)));
        TextView t = smallText("  " + name);
        cell.addView(t);
        cell.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                colorDialog(new ColorPickTarget() {
                    @Override public void onColor(int c) { sw.setBackgroundColor(c | 0xFF000000); to.onColor(c); }
                }, ((android.graphics.drawable.ColorDrawable) sw.getBackground()).getColor(), name);
            }
        });
        return cell;
    }

    /** Zonas pintadas: cambiar su trio/acabado/intensidad (sin repintar) o borrarlas. */
    private void zoneListDialog() {
        final java.util.List<com.pacco.animecut.core.ZoneTone.Zone> zs = canvas.zoneList();
        if (zs.isEmpty()) { toast("Todavia no hay zonas pintadas"); return; }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(6), dp(12), dp(6));
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < zs.size(); i++) {
            final int idx = i;
            final com.pacco.animecut.core.ZoneTone.Zone z = zs.get(i);
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(4), dp(5), dp(4), dp(5));
            r.setBackgroundResource(idx == canvas.getZoneSel() ? R.drawable.bg_row_on : R.drawable.bg_row);
            for (int c : new int[]{z.s.shadow, z.s.base, z.s.light}) {
                View v = new View(this);
                v.setBackgroundColor(c | 0xFF000000);
                r.addView(v, new LinearLayout.LayoutParams(dp(22), dp(28)));
            }
            TextView t = smallText("   Zona " + (idx + 1) + " · " + com.pacco.animecut.core.ZoneTone.FINISH_SHORT[z.s.finish] + " " + z.s.intensity + "%");
            r.addView(t);
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (dlg[0] != null) dlg[0].dismiss(); zoneOptions(idx); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(3), 0, dp(3));
            root.addView(r, lp);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dlg[0] = new SheetBuilder(this).setTitle("Zonas pintadas").setView(sv).setNegativeButton("Cerrar", null).show();
    }

    private void zoneOptions(final int idx) {
        final java.util.List<com.pacco.animecut.core.ZoneTone.Zone> zs = canvas.zoneList();
        if (idx < 0 || idx >= zs.size()) return;
        final com.pacco.animecut.core.ZoneTone.Zone z = zs.get(idx);
        final String[] items = {"Usar el trio y el acabado del panel", "Editar: cargar su estilo al panel",
                "Intensidad (" + z.s.intensity + "%)", "Borrar la zona"};
        new SheetBuilder(this).setTitle("Zona " + (idx + 1))
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (w == 0) canvas.restyleZone(idx, canvas.getZoneStyle());
                        else if (w == 1) {
                            canvas.setZoneSel(idx);
                            setZoneStyleUi(z.s.copy());
                            canvas.showHud("Estilo de la zona " + (idx + 1) + " en el panel: cambialo y toca ↻ para aplicar", 2600);
                        } else if (w == 2) {
                            final SeekBar sb = new SeekBar(MainActivity.this);
                            sb.setMax(100);
                            sb.setProgress(z.s.intensity);
                            LinearLayout box = new LinearLayout(MainActivity.this);
                            box.setPadding(dp(20), dp(16), dp(20), dp(4));
                            box.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                            new SheetBuilder(MainActivity.this).setTitle("Intensidad de la zona " + (idx + 1)).setView(box)
                                    .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                                        @Override public void onClick(DialogInterface d2, int w2) {
                                            com.pacco.animecut.core.ZoneTone.Style s2 = z.s.copy();
                                            s2.intensity = sb.getProgress();
                                            canvas.restyleZone(idx, s2);
                                        }
                                    }).setNegativeButton("Cancelar", null).show();
                        } else canvas.deleteZone(idx);
                        canvas.setZoneSel(idx);
                        updateUi();
                    }
                }).show();
    }

    /** Barra del balde en modo manga. Con vista previa pendiente: Aceptar / Parecidas / Cancelar. */
    private void buildMangaBucketBar(LinearLayout bar) {
        if (canvas.isZoneMode()) {
            buildZoneBar(bar);
            return;
        }
        if (!canvas.hasFillPreview()) addZoneToggle(bar);
        if (canvas.hasFillPreview()) {
            ImageButton ok = iconButton(R.drawable.ic_check, "Aceptar: pintar la vista previa", new Runnable() {
                public void run() {
                    canvas.acceptFillPreview();
                    updateUi();
                }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
            bar.addView(iconButton(R.drawable.ic_similar, "Parecidas: sugerir zonas como esta (tu confirmas)", new Runnable() {
                public void run() {
                    canvas.suggestSimilarZones();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_close, "Cancelar: no pintar nada", new Runnable() {
                public void run() {
                    canvas.cancelFillPreview();
                    updateUi();
                }
            }));
            TextView info = smallText(canvas.fillPreviewCount() == 1 ? "Toca otra zona para sumarla"
                    : canvas.fillPreviewCount() + " zonas. Toca una para quitarla");
            info.setPadding(dp(6), 0, dp(6), 0);
            bar.addView(info);
            return;
        }
        ImageButton tone = iconButton(R.drawable.ic_tone, "Modo trama: " + CanvasView.TONE_NAMES[canvas.getMangaToneLevel()], new Runnable() {
            public void run() {
                canvas.setMangaToneLevel((canvas.getMangaToneLevel() + 1) % 3);
                saveMangaPrefs();
                int lv = canvas.getMangaToneLevel();
                canvas.showHud(lv == 0 ? "Modo trama apagado: cada punto de trama corta la zona"
                        : lv == 1 ? "Modo trama: los puntitos sueltos no cortan la zona"
                        : "Trama densa: tambien entra en la trama tupida pegada (revisa la vista previa)");
                updateUi();
            }
        });
        tone.setBackgroundResource(canvas.getMangaToneLevel() > 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(tone);
        bar.addView(iconButton(R.drawable.ic_join, "Cerrar huecos: " + com.pacco.animecut.core.MangaFill.GAP_NAMES[canvas.getMangaGapLevel()],
                new Runnable() {
                    public void run() {
                        canvas.setMangaGapLevel((canvas.getMangaGapLevel() + 1) % 4);
                        saveMangaPrefs();
                        canvas.showHud("Cerrar huecos: " + com.pacco.animecut.core.MangaFill.GAP_NAMES[canvas.getMangaGapLevel()]);
                        updateUi();
                    }
                }));
        ImageButton exp = iconButton(R.drawable.ic_grow, "Color bajo la linea: " + canvas.getMangaExpand() + " px", new Runnable() {
            public void run() {
                canvas.setMangaExpand(canvas.getMangaExpand() > 0 ? 0 : 2);
                saveMangaPrefs();
                canvas.showHud(canvas.getMangaExpand() > 0 ? "Color bajo la linea: " + canvas.getMangaExpand() + " px"
                        : "Color bajo la linea: apagado");
                updateUi();
            }
        });
        exp.setBackgroundResource(canvas.getMangaExpand() > 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(exp);
        ImageButton pv = iconButton(R.drawable.ic_preview, canvas.isFillPreview() ? "Vista previa: SI" : "Vista previa: NO", new Runnable() {
            public void run() {
                canvas.setFillPreview(!canvas.isFillPreview());
                saveMangaPrefs();
                canvas.showHud(canvas.isFillPreview() ? "Vista previa antes de pintar" : "Pinta al tocar (sin vista previa)");
                updateUi();
            }
        });
        pv.setBackgroundResource(canvas.isFillPreview() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(pv);
        bar.addView(iconButton(R.drawable.ic_shield, "Zonas protegidas (No colorear)", new Runnable() {
            public void run() {
                protectMenu();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_manga, "Colorear manga: mas opciones", new Runnable() {
            public void run() {
                mangaMenu();
            }
        }));
    }

    private void protectMenu() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final List<String> items = new ArrayList<String>();
        if (p.hasSelection()) {
            items.add("Proteger lo seleccionado (No colorear)");
            items.add("Quitar proteccion de lo seleccionado");
        } else {
            items.add("Marcar zona con Lazo (luego vuelve aqui)");
        }
        if (canvas.hasProtectZones()) items.add("Borrar todas las zonas protegidas");
        items.add(canvas.isShowProtect() ? "Ver zonas protegidas: SI" : "Ver zonas protegidas: NO");
        new SheetBuilder(this)
                .setTitle("Zonas protegidas (globos, rayas de velocidad...)")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        String it = items.get(i);
                        if (it.startsWith("Marcar zona")) {
                            selectTool(CanvasView.MODE_LASSO);
                            toast("Rodea el globo o las rayas con el Lazo; al soltar elige Proteger");
                        } else {
                            runMangaItem(it);
                        }
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Al terminar un Lazo en modo manga: lo mas comun a mano. */
    private void mangaLassoDialog() {
        final String[] items = {"Rellenar con el color elegido", "Proteger esta zona (No colorear)",
                "Crear una capa con esta parte", "Nada por ahora (seguir marcando)"};
        new SheetBuilder(this)
                .setTitle("Zona marcada")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 0) canvas.fillSelectionWithColor();
                        else if (i == 1) canvas.protectSelection(true);
                        else if (i == 2) partFromSelectionDialog(false);
                        updateUi();
                    }
                })
                .show();
    }

    /** Barra del Lazo / Varita en modo manga. */
    private void buildMangaSelectionBar(LinearLayout bar) {
        bar.addView(iconButton(R.drawable.ic_bucket, "Rellenar lo seleccionado", new Runnable() {
            public void run() {
                canvas.fillSelectionWithColor();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_shield, "Proteger lo seleccionado (No colorear)", new Runnable() {
            public void run() {
                canvas.protectSelection(true);
                updateUi();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_grow, "Expandir o contraer lo seleccionado", new Runnable() {
            public void run() {
                expandDialog();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_manga, "Colorear manga: mas opciones", new Runnable() {
            public void run() {
                mangaMenu();
            }
        }));
    }

    /** "Cambiar color" de una capa: NO destructivo (se puede volver a 0 o fijar). */
    private void changeColorDialog(final Layer l) {
        final int[] prev = {l.hue, l.sat, l.lit};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        TextView info = smallText("Cambia el color de \"" + l.name + "\" sin repintar. La transparencia y la tinta no cambian. "
                + "Se guarda con la obra y se puede volver a 0.");
        root.addView(info);
        final TextView ht = smallText(""), st = smallText(""), lt = smallText("");
        final SeekBar hb = new SeekBar(this), sb = new SeekBar(this), lb = new SeekBar(this);
        hb.setMax(360);
        sb.setMax(200);
        lb.setMax(200);
        hb.setProgress(l.hue + 180);
        sb.setProgress(l.sat + 100);
        lb.setProgress(l.lit + 100);
        root.addView(ht); root.addView(hb);
        root.addView(st); root.addView(sb);
        root.addView(lt); root.addView(lb);
        final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable apply = new Runnable() {
            @Override public void run() {
                canvas.previewLayerAdjust(l, hb.getProgress() - 180, sb.getProgress() - 100, lb.getProgress() - 100);
            }
        };
        final Runnable labels = new Runnable() {
            @Override public void run() {
                ht.setText("Tono: " + signed(hb.getProgress() - 180) + " grados");
                st.setText("Saturacion: " + signed(sb.getProgress() - 100));
                lt.setText("Luminosidad: " + signed(lb.getProgress() - 100));
            }
        };
        labels.run();
        SimpleSeek seek = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
                labels.run();
                hd.removeCallbacks(apply);
                hd.postDelayed(apply, 60);
            }
        };
        hb.setOnSeekBarChangeListener(seek);
        sb.setOnSeekBarChangeListener(seek);
        lb.setOnSeekBarChangeListener(seek);
        final boolean hasSel = canvas.getProject() != null && canvas.getProject().hasSelection();
        AlertDialog.Builder b = new SheetBuilder(this)
                .setTitle("Cambiar color")
                .setView(root)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        hd.removeCallbacks(apply);
                        canvas.commitLayerAdjust(l, prev, hb.getProgress() - 180, sb.getProgress() - 100, lb.getProgress() - 100);
                        afterLayerOp();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        hd.removeCallbacks(apply);
                        canvas.previewLayerAdjust(l, prev[0], prev[1], prev[2]);
                    }
                });
        if (hasSel) {
            b.setNeutralButton("Solo lo azul", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) {
                    hd.removeCallbacks(apply);
                    int h0 = hb.getProgress() - 180, s0 = sb.getProgress() - 100, l0 = lb.getProgress() - 100;
                    canvas.previewLayerAdjust(l, prev[0], prev[1], prev[2]);
                    canvas.adjustSelectionColors(h0, s0, l0);
                    toast("Cambiado solo lo seleccionado (se puede deshacer)");
                }
            });
        }
        AlertDialog dlg = b.create();
        dlg.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override public void onCancel(DialogInterface d) {
                hd.removeCallbacks(apply);
                canvas.previewLayerAdjust(l, prev[0], prev[1], prev[2]);
            }
        });
        dlg.show();
    }

    // ---------------- paleta de la obra ----------------

    private static final String[] SWATCH_NAMES = {"Piel", "Sombra piel", "Cabello", "Ojos", "Ropa", "Luces"};

    private ColorPickTarget paintColorTarget() {
        return new ColorPickTarget() {
            @Override public void onColor(int color) {
                canvas.setColor(color | 0xFF000000);
                canvas.showHud(String.format(Locale.US, "Color #%06X", color & 0xFFFFFF));
                updateUi();
            }
        };
    }

    /** Guardar una muestra con nombre (en la obra y, si se quiere, en la paleta global). */
    private void saveSwatchDialog(final int color, final Runnable after) {
        final Project p = canvas.getProject();
        if (p == null) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        View sw = new View(this);
        sw.setBackgroundColor(color | 0xFF000000);
        root.addView(sw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Nombre");
        String sug = SWATCH_NAMES[Math.min(SWATCH_NAMES.length - 1, p.swatches.size() % SWATCH_NAMES.length)];
        name.setText(sug);
        root.addView(name);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(chips);
        for (final String s : SWATCH_NAMES) {
            TextView c = smallTextButton(s);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { name.setText(s); }
            });
            chips.addView(c);
        }
        root.addView(hs);
        final CheckBox global = new CheckBox(this);
        global.setText("Guardar tambien en la paleta global (para otras obras)");
        global.setTextColor(0xFFFFFFFF);
        root.addView(global);
        new SheetBuilder(this)
                .setTitle("Guardar muestra")
                .setView(root)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String n = name.getText().toString().trim();
                        if (n.isEmpty()) n = "Color";
                        p.swatches.add(new Project.Swatch(n, color | 0xFF000000));
                        if (global.isChecked()) addGlobalSwatch(n, color | 0xFF000000);
                        markDirty();
                        toast("Muestra \"" + n + "\" guardada en la obra");
                        if (after != null) after.run();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private List<Project.Swatch> globalSwatches() {
        List<Project.Swatch> out = new ArrayList<Project.Swatch>();
        String txt = getSharedPreferences("pz", MODE_PRIVATE).getString("global_palette", "");
        com.pacco.animecut.core.ProjectIO.parsePalette(txt, out);
        return out;
    }

    private void addGlobalSwatch(String n, int c) {
        List<Project.Swatch> g = globalSwatches();
        g.add(new Project.Swatch(n, c));
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putString("global_palette", com.pacco.animecut.core.ProjectIO.paletteText(g)).apply();
    }

    private void saveGlobal(List<Project.Swatch> g) {
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putString("global_palette", com.pacco.animecut.core.ProjectIO.paletteText(g)).apply();
    }

    /** Paleta de la obra + global: tocar = usar; mantener = renombrar / ajustar / borrar. */
    private void paletteDialog() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final List<Project.Swatch> global = globalSwatches();
        final List<Object[]> rows = new ArrayList<Object[]>();
        for (Project.Swatch s : p.swatches) rows.add(new Object[]{s, Boolean.FALSE});
        for (Project.Swatch s : global) rows.add(new Object[]{s, Boolean.TRUE});
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(8), dp(12), dp(4));
        if (rows.isEmpty()) root.addView(smallText("Todavia no hay muestras. En la Imagen de referencia toca un color y pulsa \"Guardar\"."));
        final AlertDialog[] dlg = new AlertDialog[1];
        boolean globalHeader = false;
        for (final Object[] r : rows) {
            final Project.Swatch s = (Project.Swatch) r[0];
            final boolean isGlobal = (Boolean) r[1];
            if (isGlobal && !globalHeader) {
                globalHeader = true;
                root.addView(optLabel("Paleta global"));
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(3), 0, dp(3));
            View sw = new View(this);
            sw.setBackgroundColor(s.color | 0xFF000000);
            row.addView(sw, new LinearLayout.LayoutParams(dp(40), dp(32)));
            TextView t = smallText("  " + s.name + String.format(Locale.US, "  #%06X", s.color & 0xFFFFFF));
            row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    canvas.setColor(s.color | 0xFF000000);
                    canvas.showHud("Color \"" + s.name + "\"");
                    updateUi();
                    if (dlg[0] != null) dlg[0].dismiss();
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    swatchActions(s, isGlobal, global);
                    return true;
                }
            });
            root.addView(row);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dlg[0] = new SheetBuilder(this)
                .setTitle("Paleta (tocar: usar · mantener: editar)")
                .setView(sv)
                .setPositiveButton("Guardar el color actual", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        saveSwatchDialog(canvas.getColor(), null);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void swatchActions(final Project.Swatch s, final boolean isGlobal, final List<Project.Swatch> global) {
        final Project p = canvas.getProject();
        final String[] items = isGlobal
                ? new String[]{"Copiar a la paleta de esta obra", "Borrar de la paleta global"}
                : new String[]{"Renombrar", "Ajustar tono / saturacion / brillo", "Borrar de la obra"};
        new SheetBuilder(this)
                .setTitle(s.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        if (isGlobal) {
                            if (i == 0) { p.swatches.add(new Project.Swatch(s.name, s.color)); markDirty(); }
                            else { global.remove(s); saveGlobal(global); }
                            return;
                        }
                        if (i == 0) {
                            final EditText e = new EditText(MainActivity.this);
                            e.setText(s.name);
                            new SheetBuilder(MainActivity.this).setTitle("Nombre").setView(e)
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override public void onClick(DialogInterface d2, int w) {
                                            s.name = e.getText().toString().trim();
                                            markDirty();
                                        }
                                    }).show();
                        } else if (i == 1) {
                            sampleAdjustDialog(s.color, new ColorPickTarget() {
                                @Override public void onColor(int c) { s.color = c; markDirty(); }
                            });
                        } else {
                            p.swatches.remove(s);
                            markDirty();
                        }
                    }
                })
                .show();
    }

    /** Ajusta una muestra (HSV y opacidad) sin tocar la imagen de referencia. */
    private void sampleAdjustDialog(final int color, final ColorPickTarget done) {
        final float[] hsv = new float[3];
        Color.colorToHSV(color | 0xFF000000, hsv);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        final View sw = new View(this);
        sw.setBackgroundColor(color | 0xFF000000);
        root.addView(sw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
        final TextView t = smallText("");
        root.addView(t);
        final SeekBar h = new SeekBar(this), s = new SeekBar(this), v = new SeekBar(this), a = new SeekBar(this);
        h.setMax(360); s.setMax(100); v.setMax(100); a.setMax(100);
        h.setProgress(Math.round(hsv[0])); s.setProgress(Math.round(hsv[1] * 100)); v.setProgress(Math.round(hsv[2] * 100));
        a.setProgress(Math.round((color >>> 24) * 100 / 255f));
        if (a.getProgress() == 0) a.setProgress(100);
        root.addView(optLabel("Tono")); root.addView(h);
        root.addView(optLabel("Saturacion")); root.addView(s);
        root.addView(optLabel("Brillo")); root.addView(v);
        root.addView(optLabel("Opacidad")); root.addView(a);
        final int[] out = {color | 0xFF000000};
        SimpleSeek k = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int val, boolean u) {
                int rgb = Color.HSVToColor(new float[]{h.getProgress(), s.getProgress() / 100f, v.getProgress() / 100f});
                int al = Math.max(3, Math.round(a.getProgress() * 255 / 100f));
                out[0] = (al << 24) | (rgb & 0xFFFFFF);
                sw.setBackgroundColor(rgb | 0xFF000000);
                t.setText(String.format(Locale.US, "#%06X  opacidad %d%%", rgb & 0xFFFFFF, a.getProgress()));
            }
        };
        h.setOnSeekBarChangeListener(k); s.setOnSeekBarChangeListener(k); v.setOnSeekBarChangeListener(k); a.setOnSeekBarChangeListener(k);
        k.onProgressChanged(h, 0, false);
        new SheetBuilder(this)
                .setTitle("Ajustar muestra")
                .setView(root)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { done.onColor(out[0]); }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ---------------- referencia guardada con la obra ----------------

    /** Copia compacta (lado max 1024) para guardar dentro de la obra. */
    private static byte[] compactReferencePng(Bitmap src) {
        if (src == null || src.isRecycled()) return null;
        int w = src.getWidth(), h = src.getHeight();
        float s = Math.min(1f, 1024f / Math.max(w, h));
        Bitmap b = s < 1f ? Bitmap.createScaledBitmap(src, Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s)), true) : src;
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, bo);
        if (b != src) b.recycle();
        return bo.toByteArray();
    }

    private boolean keepRefInProject() {
        return getSharedPreferences("pz", MODE_PRIVATE).getBoolean("ref_in_project", false);
    }

    private void setKeepRefInProject(boolean on) {
        getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("ref_in_project", on).apply();
        Project p = canvas.getProject();
        if (p == null) return;
        p.refImagePng = on ? compactReferencePng(colorRefBitmap) : null;
        markDirty();
        toast(on ? "La referencia (copia reducida) se guarda con la obra. No se exporta nunca."
                : "La referencia ya no se guarda con la obra");
    }

    /** Al abrir una obra con referencia guardada, se carga para poder sacar colores. */
    private void restoreProjectReference() {
        Project p = canvas.getProject();
        if (p == null || p.refImagePng == null) return;
        Bitmap b = BitmapFactory.decodeByteArray(p.refImagePng, 0, p.refImagePng.length);
        if (b == null) return;
        if (colorRefWindow != null) { try { colorRefWindow.dismiss(); } catch (Throwable ignored) {} }
        colorRefWindow = null;
        colorRefView = null;
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) colorRefBitmap.recycle();
        colorRefBitmap = b;
    }

    /**
     * Paleta automatica (corte por la mediana, determinista): se ignoran casi blancos
     * y casi negros, y se ordena por tono. NO reemplaza tomar colores a mano.
     */
    private int[] autoPaletteMedianCut(Bitmap bmp, int count) {
        if (bmp == null) return new int[0];
        int w = bmp.getWidth(), h = bmp.getHeight();
        int step = Math.max(1, (int) Math.sqrt((double) w * h / 40000.0));
        ArrayList<Integer> px = new ArrayList<Integer>();
        for (int y = 0; y < h; y += step) for (int x = 0; x < w; x += step) {
            int c = bmp.getPixel(x, y);
            if ((c >>> 24) < 128) continue;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int l = (r * 77 + g * 151 + b * 28) >> 8;
            if (l > 242 || l < 20) continue;
            px.add(c | 0xFF000000);
        }
        if (px.isEmpty()) return new int[0];
        List<List<Integer>> boxes = new ArrayList<List<Integer>>();
        boxes.add(px);
        while (boxes.size() < count) {
            int bi = -1, bestRange = -1, bestCh = 0;
            for (int k = 0; k < boxes.size(); k++) {
                List<Integer> bx = boxes.get(k);
                if (bx.size() < 2) continue;
                for (int ch = 0; ch < 3; ch++) {
                    int mn = 255, mx = 0;
                    for (int c : bx) { int v = (c >> (16 - 8 * ch)) & 255; if (v < mn) mn = v; if (v > mx) mx = v; }
                    if (mx - mn > bestRange) { bestRange = mx - mn; bi = k; bestCh = ch; }
                }
            }
            if (bi < 0 || bestRange < 12) break;
            final int sh = 16 - 8 * bestCh;
            List<Integer> bx = boxes.remove(bi);
            java.util.Collections.sort(bx, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) { return ((a >> sh) & 255) - ((b >> sh) & 255); }
            });
            int mid = bx.size() / 2;
            boxes.add(new ArrayList<Integer>(bx.subList(0, mid)));
            boxes.add(new ArrayList<Integer>(bx.subList(mid, bx.size())));
        }
        final float[][] hsvs = new float[boxes.size()][];
        int[] cols = new int[boxes.size()];
        for (int k = 0; k < boxes.size(); k++) {
            long r = 0, g = 0, b = 0;
            List<Integer> bx = boxes.get(k);
            for (int c : bx) { r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255; }
            int n = Math.max(1, bx.size());
            cols[k] = 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
        }
        Integer[] order = new Integer[cols.length];
        for (int k = 0; k < cols.length; k++) {
            order[k] = k;
            hsvs[k] = new float[3];
            Color.colorToHSV(cols[k], hsvs[k]);
        }
        java.util.Arrays.sort(order, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer a, Integer b) {
                float ha = hsvs[a][1] < .12f ? 400 : hsvs[a][0], hb = hsvs[b][1] < .12f ? 400 : hsvs[b][0];
                if (Math.abs(ha - hb) > 12) return Float.compare(ha, hb);
                return Float.compare(hsvs[b][2], hsvs[a][2]);
            }
        });
        int[] out = new int[cols.length];
        for (int k = 0; k < out.length; k++) out[k] = cols[order[k]];
        return out;
    }

    private void autoPaletteDialog() {
        final int[] cols = autoPaletteMedianCut(colorRefBitmap, 10);
        if (cols.length == 0) {
            toast("No encontre colores (la imagen es casi blanco y negro)");
            return;
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(6));
        final AlertDialog[] dlg = new AlertDialog[1];
        for (final int c : cols) {
            View sw = new View(this);
            sw.setBackgroundColor(c);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    saveSwatchDialog(c, null);
                }
            });
            row.addView(sw, lp);
        }
        dlg[0] = new SheetBuilder(this)
                .setTitle("Paleta automatica (toca uno para guardarlo)")
                .setView(row)
                .setNegativeButton("Cerrar", null)
                .show();
    }

    // ---------------- exportar imagen completa ----------------

    private boolean pendingFlatExport;

    /** v8.39: donde quedo lo guardado directo (para el aviso); null = lo eligio el usuario. */
    private String exportWhere;

    private String whereSuffix() {
        String w = exportWhere;
        exportWhere = null;
        return w == null ? "" : " en " + w;
    }

    /**
     * v8.39: crea el archivo DIRECTO en la carpeta de la app, sin la pantalla de elegir:
     * Imagenes (Pictures) > Paint Zeta, o Descargas > Paint Zeta para el ZIP. Aparece en la
     * galeria al momento. null si este Android (9 o menos) no lo permite: ahi se elige carpeta.
     */
    private Uri appFolderUri(String name, String mime, boolean download) {
        if (android.os.Build.VERSION.SDK_INT < 29) return null;
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                    (download ? android.os.Environment.DIRECTORY_DOWNLOADS : android.os.Environment.DIRECTORY_PICTURES) + "/Paint Zeta");
            Uri col = download ? android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    : android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            return getContentResolver().insert(col, cv);
        } catch (Throwable t) {
            return null;
        }
    }

    // ===================== v8.41/v8.42: Mejorar imagen (IA) =====================

    /** Ventana de avance con barra y Cancelar; cancel[0] queda en true si el usuario cancela. */
    private final class Busy {
        final AlertDialog dlg;
        final android.widget.ProgressBar bar;
        final TextView msg;
        final boolean[] cancel = new boolean[1];
        Runnable onCancel;

        Busy(String title) {
            LinearLayout root = new LinearLayout(MainActivity.this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(20), dp(12), dp(20), dp(4));
            msg = new TextView(MainActivity.this);
            msg.setTextColor(0xFFFFFFFF);
            msg.setText("Preparando...");
            bar = new android.widget.ProgressBar(MainActivity.this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(100);
            root.addView(msg);
            root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
            TextView tip = optLabel("Puedes dejar el telefono quieto; no cierres la app.");
            root.addView(tip);
            dlg = new SheetBuilder(MainActivity.this).setTitle(title).setView(root).setCancelable(false)
                    .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            cancel[0] = true;
                            if (onCancel != null) try { onCancel.run(); } catch (Throwable ignored) { }
                        }
                    }).show();
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        /** Desde cualquier hilo. */
        void set(final int pct, final String text) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (pct >= 0) bar.setProgress(Math.min(100, pct));
                    if (text != null) msg.setText(text);
                }
            });
        }

        /** En el hilo de la interfaz. */
        void close() {
            getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            try { dlg.dismiss(); } catch (Throwable ignored) { }
        }
    }

    private long availMemBytes() {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.availMem;
        } catch (Throwable t) {
            return 1L << 30;
        }
    }

    /** Copia el modelo de assets a la memoria interna una sola vez (ONNX lo lee de un archivo). */
    private File srModelFile(String asset) throws java.io.IOException {
        File dir = new File(getFilesDir(), "sr");
        if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("sin carpeta interna");
        File f = new File(dir, asset), ok = new File(dir, asset + ".ok-842");
        if (f.exists() && ok.exists()) return f;
        File tmp = new File(dir, asset + ".tmp");
        try (InputStream in = getAssets().open(asset); FileOutputStream out = new FileOutputStream(tmp)) {
            byte[] b = new byte[1 << 16];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            out.getFD().sync();
        }
        f.delete();
        if (!tmp.renameTo(f)) throw new java.io.IOException("no se pudo preparar el modelo");
        File[] old = dir.listFiles();   // v8.42: fuera copias viejas (el modelo de calidad ya no existe)
        if (old != null) for (File o : old) if (!o.equals(f)) o.delete();
        ok.createNewFile();
        return f;
    }

    /**
     * v8.42 Mejorar imagen: un solo modo (la IA rapida de anime), en la MISMA obra.
     * Igual = limpia sin agrandar; x2/x4 = toda la obra crece: las capas marcadas pasan por la
     * IA y las demas crecen normal (suave) para seguir calzando. Deshacer lo devuelve.
     */
    private void enhanceDialog() {
        if (!needProject()) return;
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        final Project p = canvas.getProject();
        final int n = p.layers.size();
        final boolean[] pick = new boolean[n];
        pick[Math.max(0, Math.min(n - 1, p.active))] = true;
        final int[] sc = {sp.getInt("sr_size", 1)};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(6), dp(18), dp(6));
        final TextView info = new TextView(this);
        info.setTextColor(0xFFFFFFFF);
        info.setTextSize(13f);
        info.setPadding(0, dp(10), 0, 0);
        final Runnable upd = new Runnable() {
            @Override public void run() {
                int s = sc[0] == 0 ? 1 : sc[0] == 1 ? 2 : 4;
                String t = s == 1 ? "Mismo tamano: limpia el JPEG y afina las lineas."
                        : "La obra queda de " + (p.w * s) + " x " + (p.h * s) + ". Las capas sin marcar crecen normal.";
                if (s > 1 && !enhanceFits(p, s, pick)) t += "\nMuy grande para la memoria de este telefono: elige un tamano menor.";
                info.setText(t);
            }
        };
        root.addView(optLabel("Tamano"));
        root.addView(choiceRow(new String[]{"Igual", "x2", "x4"}, sc[0], new IntConsumerCompat() {
            @Override public void accept(int v) { sc[0] = v; upd.run(); }
        }));
        root.addView(optLabel("Capas que mejora la IA"));
        for (int i = n - 1; i >= 0; i--) {   // como en el panel: la de arriba primero
            final int k = i;
            CheckBox cb = new CheckBox(this);
            Layer l = p.layers.get(i);
            cb.setText(l.name + (l.visible ? "" : " (oculta)"));
            cb.setTextColor(0xFFFFFFFF);
            cb.setChecked(pick[i]);
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) { pick[k] = on; upd.run(); }
            });
            root.addView(cb);
        }
        root.addView(info);
        upd.run();
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new SheetBuilder(this).setTitle("Mejorar imagen").setView(sv)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Mejorar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        int s = sc[0] == 0 ? 1 : sc[0] == 1 ? 2 : 4;
                        boolean any = false;
                        for (boolean b : pick) any |= b;
                        if (!any) { toast("Marca al menos una capa"); return; }
                        if (s > 1 && !enhanceFits(p, s, pick)) { toast("Muy grande para este telefono: elige un tamano menor"); return; }
                        sp.edit().putInt("sr_size", sc[0]).apply();
                        runEnhance(s, pick.clone());
                    }
                }).show();
    }

    /**
     * v8.43: despues de Mejorar, Antes / Despues con una linea en medio para comparar.
     * Las imagenes se arman a lo mas 2048 px de lado (solo para mirar).
     */
    private void showCompare(final int[] before, final int bw, final int bh, final Project p) {
        // v8.45: Antes/Despues en el MISMO lienzo (sin otra pantalla): una linea que se mueve y se
        // queda donde la dejas. La X de arriba la quita.
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap b1 = null;
                try {
                    float f = Math.min(1f, 2048f / Math.max(bw, bh));
                    int dw = Math.max(1, Math.round(bw * f)), dh = Math.max(1, Math.round(bh * f));
                    Bitmap o = Bitmap.createBitmap(before, bw, bh, Bitmap.Config.ARGB_8888);
                    b1 = dw == bw && dh == bh ? o : Bitmap.createScaledBitmap(o, dw, dh, true);
                    if (b1 != o) o.recycle();
                } catch (Throwable t) {
                    if (b1 != null) b1.recycle();
                    return;
                }
                final Bitmap fb = b1;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isFinishing() || canvas.getProject() != p) { fb.recycle(); return; }
                        canvas.startCompare(fb);
                        showCompareChip();
                    }
                });
            }
        }, "pz-comparar").start();
    }

    private View compareChip;

    private void showCompareChip() {
        hideCompareChip();
        TextView t = new TextView(this);
        t.setText("✕  Quitar antes/después");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(13f);
        t.setBackgroundResource(R.drawable.bg_tool_on);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { canvas.stopCompare(); hideCompareChip(); }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        View top = findViewById(R.id.topBar);
        lp.topMargin = (top != null ? top.getTop() : 0) + dp(14);
        ((ViewGroup) findViewById(android.R.id.content)).addView(t, lp);
        compareChip = t;
    }

    private void hideCompareChip() {
        if (compareChip != null && compareChip.getParent() instanceof ViewGroup) ((ViewGroup) compareChip.getParent()).removeView(compareChip);
        compareChip = null;
    }

    /**
     * v8.45: Blanco y negro de la capa elegida, NO destructivo (es el ajuste de saturacion de la
     * capa): se apaga y vuelve el color. Claridad a gusto. Sirve para recolorear un manga a color.
     */
    private PopupWindow bwPop;
    private Runnable bwCancel;

    private void bwDialog() {
        if (bwPop != null && bwPop.isShowing()) return;
        if (!needProject()) return;
        final Layer l = canvas.getProject().activeLayer();
        if (l == null) return;
        // v8.83: mismos ajustes que el B/N de Borrar fondo (de que color sale el gris, saturacion,
        // contraste y brillo), en un panel ABAJO: la imagen queda libre para mirar y hacer zoom.
        final int[] prev = {l.hue, l.sat, l.lit, l.con, l.gch};
        final boolean was = l.sat < 0;
        // {tono, sat, luz, contraste, canal}
        // canal: 4 = normal, 1 rojo, 2 verde, 3 azul (0 era el ajuste viejo: pasa a normal)
        final int[] cur = {l.hue, was ? l.sat : -100, was ? l.lit : 0, was ? l.con : 0, was && l.gch != 0 ? l.gch : 4};
        final int[] chVal = {4, 1, 2, 3};
        final boolean[] peek = {false};
        final Runnable show = new Runnable() {
            @Override public void run() {
                canvas.previewLayerBw(l, peek[0] ? new int[]{prev[0], was ? 0 : prev[1], was ? 0 : prev[2], 0, 0} : cur);
            }
        };
        show.run();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(6));
        android.graphics.drawable.GradientDrawable bgd = new android.graphics.drawable.GradientDrawable();
        bgd.setColor(0xE6202024);
        bgd.setCornerRadius(dp(14));
        box.setBackground(bgd);
        TextView title = new TextView(this);
        title.setText("Blanco y negro: " + l.name);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(13f);
        title.setSingleLine(true);
        box.addView(title);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER_VERTICAL);
        final TextView[] ch = new TextView[4];
        for (int k = 0; k < 4; k++) {
            final int which = k;
            ch[k] = smallTextButton(com.pacco.animecut.core.GrayView.CH_NAMES[k]);
            ch[k].setBackgroundResource(chVal[k] == cur[4] ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            ch[k].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    cur[4] = chVal[which];
                    for (int j = 0; j < 4; j++) ch[j].setBackgroundResource(j == which ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                    show.run();
                }
            });
            chips.addView(ch[k]);
        }
        box.addView(chips);
        final SeekBar sat = grayRow(box, "Saturacion", 100, 100 + cur[1]);
        final SeekBar con = grayRow(box, "Contraste", 200, cur[3] + 100);
        final SeekBar bri = grayRow(box, "Brillo", 200, cur[2] + 100);
        SeekBar.OnSeekBarChangeListener live = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean user) {
                cur[1] = Math.min(-1, sat.getProgress() - 100);    // siempre algo de gris: es Blanco y negro
                cur[3] = con.getProgress() - 100;
                cur[2] = bri.getProgress() - 100;
                show.run();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        };
        sat.setOnSeekBarChangeListener(live);
        con.setOnSeekBarChangeListener(live);
        bri.setOnSeekBarChangeListener(live);
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        final TextView pk = smallTextButton("Ver color");
        pk.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                peek[0] = !peek[0];
                pk.setText(peek[0] ? "Ver B/N" : "Ver color");
                pk.setBackgroundResource(peek[0] ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                show.run();
            }
        });
        TextView reset = smallTextButton("De fabrica");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                cur[1] = -100; cur[2] = 0; cur[3] = 0; cur[4] = 4;
                sat.setProgress(0);
                con.setProgress(100);
                bri.setProgress(100);
                for (int j = 0; j < 4; j++) ch[j].setBackgroundResource(j == 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                show.run();
            }
        });
        final Runnable close = new Runnable() {
            @Override public void run() {
                bwCancel = null;
                if (bwPop != null) bwPop.dismiss();
                bwPop = null;
                if (layersOpen()) buildLayersPanel();
            }
        };
        TextView off = smallTextButton("Apagar B/N");
        off.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                // vuelve el color (el ajuste de color que tuviera antes de ser B/N no se toca)
                canvas.commitLayerBw(l, prev, new int[]{prev[0], was ? 0 : prev[1], was ? 0 : prev[2], 0, 0});
                canvas.showHud("Color original");
                markDirty();
                close.run();
            }
        });
        TextView done = smallTextButton("Listo");
        done.setBackgroundResource(R.drawable.bg_tool_on);
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                canvas.commitLayerBw(l, prev, cur);
                markDirty();
                close.run();
            }
        });
        btns.addView(pk);
        btns.addView(reset);
        btns.addView(off);
        btns.addView(done);
        box.addView(btns);
        // Atras = cancelar: todo como estaba
        bwCancel = new Runnable() {
            @Override public void run() {
                canvas.previewLayerBw(l, prev);
                close.run();
            }
        };
        View bar = findViewById(R.id.optBar);
        int w = getResources().getDisplayMetrics().widthPixels - dp(16);
        bwPop = new PopupWindow(box, w, ViewGroup.LayoutParams.WRAP_CONTENT, false);
        bwPop.setOutsideTouchable(false);
        bwPop.setTouchable(true);
        int[] loc = new int[2];
        bar.getLocationInWindow(loc);
        int screenH = getWindow().getDecorView().getHeight();
        int y = Math.max(0, screenH - loc[1] + dp(4));
        try {
            bwPop.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, y);
        } catch (Throwable t) {
            bwCancel.run();
        }
    }

    /** Cabe en memoria y en el lienzo toda la obra agrandada. */
    private boolean enhanceFits(Project p, int s, boolean[] pick) {
        long nw = (long) p.w * s, nh = (long) p.h * s;
        if (!CanvasView.sizeOk(nw, nh)) return false;
        int layers = 0;
        for (Layer l : p.layers) if (!l.isEmptyPacked()) layers++;
        long need = nw * nh * 4L * (layers + 2);
        return need <= Runtime.getRuntime().maxMemory() / 2;
    }

    private void runEnhance(final int scale, final boolean[] pick) {
        if (!com.pacco.animecut.ai.AiSegmenter.available()) {
            toast("La IA no puede cargar en este telefono: " + com.pacco.animecut.ai.AiSegmenter.loadError());
            return;
        }
        final Project p = canvas.getProject();
        final Layer[] ls = p.layers.toArray(new Layer[0]);
        final int w = p.w, h = p.h;
        final int tile = availMemBytes() > 1_000_000_000L ? 192 : 128;
        final int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
        int ai = 0;
        for (int k = 0; k < ls.length; k++) if (pick[k] && !ls[k].isEmptyPacked()) ai++;
        final int aiLayers = Math.max(1, ai);
        final int perLayer = ((w + tile - 1) / tile) * ((h + tile - 1) / tile);
        final Busy busy = new Busy("Mejorando imagen");
        final com.pacco.animecut.ai.SrModel[] model = new com.pacco.animecut.ai.SrModel[1];
        busy.onCancel = new Runnable() {
            @Override public void run() {
                com.pacco.animecut.ai.SrModel m = model[0];
                if (m != null) m.cancel();
            }
        };
        final long t0 = android.os.SystemClock.uptimeMillis();
        final int[][] beforeFlat = new int[1][];
        new Thread(new Runnable() {
            @Override public void run() {
                int[][] out = new int[ls.length][];
                String err = null;
                boolean ok = false;
                try {
                    try { beforeFlat[0] = com.pacco.animecut.core.Compositor.flatten(p); } catch (Throwable ignored) { }
                    model[0] = new com.pacco.animecut.ai.SrModel(srModelFile("anime_rapido_x4.onnx"), threads);
                    int doneLayers = 0;
                    for (int k = 0; k < ls.length && !busy.cancel[0]; k++) {
                        if (ls[k].isEmptyPacked()) continue;              // vacia: sigue vacia
                        if (!pick[k] && scale == 1) continue;              // no se toca
                        int[] src = new int[w * h];
                        ls[k].copyTo(src, w, h);
                        if (!pick[k]) {
                            busy.set(-1, "Agrandando \"" + ls[k].name + "\"...");
                            out[k] = Upscaler.resizeSmooth(src, w, h, scale);
                            continue;
                        }
                        final int base = doneLayers * perLayer;
                        final String name = ls[k].name;
                        out[k] = Upscaler.upscale(src, w, h, scale, tile, Upscaler.PAD, model[0], new Upscaler.Progress() {
                            @Override public boolean step(int done, int total) {
                                if (busy.cancel[0]) return false;
                                int all = perLayer * aiLayers, d = base + done;
                                String eta = "";
                                if (d > 0) {
                                    long left = (android.os.SystemClock.uptimeMillis() - t0) * (all - d) / d / 1000;
                                    eta = left >= 60 ? " · faltan ~" + (left / 60 + 1) + " min" : " · faltan ~" + Math.max(1, left) + " s";
                                }
                                busy.set(d * 100 / Math.max(1, all), "\"" + name + "\": pedazo " + done + " de " + total + eta);
                                return true;
                            }
                        });
                        if (out[k] == null) break;
                        doneLayers++;
                    }
                    ok = !busy.cancel[0];
                } catch (OutOfMemoryError e) {
                    out = null;
                    err = "El telefono se quedo sin memoria. Prueba un tamano menor.";
                } catch (Throwable t) {
                    if (!busy.cancel[0]) err = "No se pudo mejorar: " + t.getMessage();
                } finally {
                    if (model[0] != null) model[0].close();
                }
                final int[][] res = ok ? out : null;
                final String e2 = err;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        busy.close();
                        if (e2 != null) { toast(e2); return; }
                        if (res == null) { toast("Cancelado: no cambio nada"); return; }
                        if (canvas.getProject() != p || p.layers.size() != ls.length) { toast("Cambiaste de obra: no se aplico"); return; }
                        try {
                            if (scale == 1) {
                                canvas.replaceLayersPixels(ls, res);
                            } else {
                                for (int k = 0; k < ls.length; k++)
                                    if (res[k] == null && !ls[k].isEmptyPacked()) { toast("Error interno: faltó una capa"); return; }
                                canvas.resizeProject(w * scale, h * scale, res);
                            }
                            markDirty();
                            updateUi();
                            long s = (android.os.SystemClock.uptimeMillis() - t0) / 1000;
                            toast("Listo en " + s + " s" + (scale > 1 ? ": obra de " + (w * scale) + "x" + (h * scale) : "")
                                    + ". Deshacer la devuelve como era");
                            if (beforeFlat[0] != null) showCompare(beforeFlat[0], w, h, p);
                        } catch (OutOfMemoryError oom) {
                            toast("El telefono se quedo sin memoria. Prueba un tamano menor.");
                        }
                    }
                });
            }
        }, "pz-mejorar").start();
    }

    private static String stampNow() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new java.util.Date());
    }

    /** Nombre de la obra para los archivos (o "PaintZeta"). */
    private String obraName() {
        String n = projectId == null ? null : ProjectStore.name(this, projectId);
        n = n == null || n.trim().isEmpty() ? "PaintZeta" : safeName(n.trim());
        return n.length() > 40 ? n.substring(0, 40) : n;
    }

    private void doExportFlat(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    Exporter.exportFlattened(getContentResolver(), p, uri, p.w, p.h);
                } catch (Throwable t) {
                    lastError = errText(t);
                    dropBroken(uri);
                }
            }
        }, new Runnable() {
            @Override public void run() {
                onBusy(false);
                toast(lastError != null ? "Error: " + lastError : "Imagen completa guardada (como se ve en pantalla)" + whereSuffix());
            }
        });
    }
}
