package com.pacco.animecut.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Animacion corta de "antes y despues" para las opciones del cuadro punteado
 * y para las herramientas nuevas. Dibuja un personaje simple (pelo, cara,
 * cuerpo y brazo con linea negra) y muestra que le pasa.
 */
public class SelDemoView extends View {

    public static final int COPY = 0, CUT = 1, DUP = 2, KEEP = 3, INVERT = 4, CLEAR = 5, GROW = 6,
            REFINE = 7, HOLES = 8, RANGE = 9, PATCH = 10, SCISSORS = 11, WAND_LINES = 12, SEPARATE = 13;

    private static final int BG = 0xFFDDE8D5, SKIN = 0xFFFFE0CC, HAIR = 0xFF8A3A3A, BODY = 0xFF5A7BD6,
            LINE = 0xFF151515, BLUE = 0x883D7BFF;

    private final int scene;
    private Bitmap before, after;
    private float t;
    private ValueAnimator anim;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float s;

    public SelDemoView(Context c, int scene) {
        super(c);
        this.scene = scene;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(LINE);
        text.setColor(0xFFFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (before != null) before.recycle();
        if (after != null) after.recycle();
        before = render(false, w, h);
        after = render(true, w, h);
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(3600);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (before == null) return;
        // 0-0.4 antes, 0.4-0.55 cambia, 0.55-1 despues
        float mix = t < 0.4f ? 0f : (t < 0.55f ? (t - 0.4f) / 0.15f : 1f);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        c.drawBitmap(before, 0, 0, p);
        p.setAlpha((int) (255 * mix));
        c.drawBitmap(after, 0, 0, p);
        // toque en el centro al momento del cambio
        if (t > 0.3f && t < 0.5f) {
            float k = (t - 0.3f) / 0.2f;
            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(getWidth() * 0.012f);
            ring.setColor(0xFFFFFFFF);
            ring.setAlpha((int) (255 * (1 - k)));
            c.drawCircle(getWidth() * 0.5f, getHeight() * 0.5f, getWidth() * (0.05f + 0.12f * k), ring);
        }
        text.setTextSize(getWidth() * 0.07f);
        Paint bg = new Paint();
        bg.setColor(0xAA000000);
        float bh = getHeight() * 0.11f;
        c.drawRect(0, getHeight() - bh, getWidth(), getHeight(), bg);
        c.drawText(mix < 0.5f ? "Antes" : "Despues", getWidth() * 0.5f, getHeight() - bh * 0.3f, text);
    }

    // ------------------------------------------------------------------
    // Dibujo
    // ------------------------------------------------------------------

    private float X(float v) {
        return v * s;
    }

    private Path head() {
        Path p = new Path();
        p.addCircle(X(0.5f), X(0.36f), X(0.16f), Path.Direction.CW);
        return p;
    }

    private Path hair() {
        Path p = new Path();
        p.moveTo(X(0.32f), X(0.40f));
        p.cubicTo(X(0.28f), X(0.12f), X(0.72f), X(0.12f), X(0.68f), X(0.40f));
        p.cubicTo(X(0.62f), X(0.28f), X(0.40f), X(0.28f), X(0.32f), X(0.40f));
        p.close();
        return p;
    }

    private Path body() {
        Path p = new Path();
        p.addRoundRect(new RectF(X(0.32f), X(0.52f), X(0.68f), X(0.86f)), X(0.06f), X(0.06f), Path.Direction.CW);
        return p;
    }

    private Path arm() {
        Path p = new Path();
        p.addRoundRect(new RectF(X(0.66f), X(0.55f), X(0.80f), X(0.84f)), X(0.05f), X(0.05f), Path.Direction.CW);
        return p;
    }

    private void checker(Canvas c, Path clip) {
        c.save();
        if (clip != null) c.clipPath(clip);
        Paint a = new Paint();
        float q = X(0.05f);
        for (int yy = 0; yy * q < getHeight(); yy++) {
            for (int xx = 0; xx * q < getWidth(); xx++) {
                a.setColor(((xx + yy) & 1) == 0 ? 0xFFFFFFFF : 0xFFCFCFCF);
                c.drawRect(xx * q, yy * q, (xx + 1) * q, (yy + 1) * q, a);
            }
        }
        c.restore();
    }

    private void part(Canvas c, Path p, int color) {
        fill.setColor(color);
        fill.setStyle(Paint.Style.FILL);
        c.drawPath(p, fill);
        stroke.setStrokeWidth(X(0.012f));
        c.drawPath(p, stroke);
    }

    private void blue(Canvas c, Path p) {
        fill.setColor(BLUE);
        fill.setStyle(Paint.Style.FILL);
        c.drawPath(p, fill);
    }

    private void figure(Canvas c, boolean withArm, boolean withRest) {
        if (withRest) {
            part(c, body(), BODY);
            part(c, head(), SKIN);
            part(c, hair(), HAIR);
        }
        if (withArm) part(c, arm(), SKIN);
    }

    /** Tarjetita "capa nueva" arriba a la derecha con lo que se saco. */
    private void layerCard(Canvas c, String label, boolean armOnly, float dy) {
        RectF r = new RectF(X(0.66f), X(0.04f + dy), X(0.96f), X(0.30f + dy));
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(0xFF232329);
        c.drawRoundRect(r, X(0.02f), X(0.02f), bg);
        Path clip = new Path();
        clip.addRect(new RectF(r.left + X(0.01f), r.top + X(0.01f), r.right - X(0.01f), r.bottom - X(0.06f)), Path.Direction.CW);
        checker(c, clip);
        c.save();
        c.clipPath(clip);
        c.translate(r.left - X(armOnly ? 0.57f : 0.06f), r.top - X(armOnly ? 0.53f : 0.03f));
        c.scale(armOnly ? 0.8f : 0.3f, armOnly ? 0.8f : 0.3f, 0, 0);
        if (armOnly) part(c, arm(), SKIN);
        else figure(c, true, true);
        c.restore();
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFFFFFFFF);
        tp.setTextSize(X(0.035f));
        tp.setTextAlign(Paint.Align.CENTER);
        c.drawText(label, r.centerX(), r.bottom - X(0.017f), tp);
    }

    private Bitmap render(boolean done, int w, int h) {
        s = Math.min(w, h);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(BG);
        Path all = new Path();
        all.addRect(0, 0, w, h, Path.Direction.CW);
        switch (scene) {
            case COPY:
                figure(c, true, true);
                if (!done) blue(c, arm());
                else layerCard(c, "capa nueva", true, 0);
                break;
            case CUT:
                figure(c, !done, true);
                if (!done) blue(c, arm());
                else {
                    checker(c, arm());
                    layerCard(c, "capa nueva", true, 0);
                }
                break;
            case DUP:
                figure(c, true, true);
                layerCard(c, "capa", false, 0);
                if (done) layerCard(c, "copia", false, 0.3f);
                break;
            case KEEP:
                if (!done) {
                    figure(c, true, true);
                    blue(c, head());
                } else {
                    checker(c, all);
                    part(c, head(), SKIN);
                }
                break;
            case INVERT: {
                figure(c, true, true);
                Path fig = new Path();
                fig.op(body(), Path.Op.UNION);
                fig.op(head(), Path.Op.UNION);
                fig.op(hair(), Path.Op.UNION);
                fig.op(arm(), Path.Op.UNION);
                if (!done) blue(c, fig);
                else {
                    Path bgp = new Path(all);
                    bgp.op(fig, Path.Op.DIFFERENCE);
                    blue(c, bgp);
                }
                break;
            }
            case CLEAR:
                figure(c, true, true);
                if (!done) blue(c, arm());
                break;
            case GROW: {
                figure(c, true, true);
                Path g = new Path();
                g.addCircle(X(0.5f), X(0.36f), X(done ? 0.21f : 0.12f), Path.Direction.CW);
                blue(c, g);
                break;
            }
            case REFINE: {
                figure(c, true, true);
                if (!done) {
                    Path box = new Path();
                    box.addRect(X(0.28f), X(0.12f), X(0.72f), X(0.44f), Path.Direction.CW);
                    blue(c, box);
                } else {
                    blue(c, hair());
                }
                break;
            }
            case HOLES: {
                figure(c, true, true);
                if (!done) {
                    Path sel = body();
                    for (int k = 0; k < 6; k++) {
                        Path dot = new Path();
                        dot.addCircle(X(0.40f + (k % 3) * 0.1f), X(0.62f + (k / 3) * 0.13f), X(0.022f), Path.Direction.CW);
                        sel.op(dot, Path.Op.DIFFERENCE);
                    }
                    blue(c, sel);
                } else {
                    blue(c, body());
                }
                break;
            }
            case RANGE: {
                figure(c, true, true);
                Path extra = new Path();
                extra.addRoundRect(new RectF(X(0.10f), X(0.60f), X(0.24f), X(0.74f)), X(0.03f), X(0.03f), Path.Direction.CW);
                part(c, extra, HAIR);
                if (!done) {
                    Path tap = new Path();
                    tap.addCircle(X(0.5f), X(0.22f), X(0.03f), Path.Direction.CW);
                    blue(c, tap);
                } else {
                    blue(c, hair());
                    blue(c, extra);
                }
                break;
            }
            case PATCH: {
                part(c, body(), BODY);
                part(c, head(), SKIN);
                part(c, hair(), HAIR);
                Path hole = new Path();
                hole.addRoundRect(new RectF(X(0.44f), X(0.60f), X(0.60f), X(0.80f)), X(0.03f), X(0.03f), Path.Direction.CW);
                if (!done) {
                    checker(c, hole);
                    blue(c, hole);
                } else {
                    // el color del cuerpo cubre el hueco y la linea sigue
                    fill.setColor(BODY);
                    fill.setStyle(Paint.Style.FILL);
                    c.drawPath(hole, fill);
                    stroke.setStrokeWidth(X(0.01f));
                    c.drawLine(X(0.44f), X(0.70f), X(0.60f), X(0.70f), stroke);
                }
                if (!done) {
                    stroke.setStrokeWidth(X(0.01f));
                    c.drawLine(X(0.33f), X(0.70f), X(0.44f), X(0.70f), stroke);
                    c.drawLine(X(0.60f), X(0.70f), X(0.67f), X(0.70f), stroke);
                } else {
                    c.drawLine(X(0.33f), X(0.70f), X(0.67f), X(0.70f), stroke);
                }
                break;
            }
            case SCISSORS: {
                figure(c, true, true);
                if (!done) {
                    Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);
                    dash.setStyle(Paint.Style.STROKE);
                    dash.setStrokeWidth(X(0.012f));
                    dash.setColor(0xFFFFFFFF);
                    dash.setPathEffect(new android.graphics.DashPathEffect(new float[]{X(0.03f), X(0.02f)}, 0));
                    RectF oval = new RectF(X(0.32f), X(0.18f), X(0.68f), X(0.54f));
                    Path open = new Path();
                    open.addArc(oval, 100, 300);
                    c.drawPath(open, dash);
                } else {
                    Path h2 = new Path(head());
                    h2.op(hair(), Path.Op.UNION);
                    blue(c, h2);
                }
                break;
            }
            case WAND_LINES: {
                // un circulo con un corte en la linea: la varita normal se escapa
                RectF o = new RectF(X(0.2f), X(0.15f), X(0.8f), X(0.75f));
                fill.setColor(SKIN);
                fill.setStyle(Paint.Style.FILL);
                c.drawOval(o, fill);
                stroke.setStrokeWidth(X(0.014f));
                Path ring = new Path();
                ring.addArc(o, 20, 330);
                c.drawPath(ring, stroke);
                if (!done) {
                    blue(c, all);
                } else {
                    Path in = new Path();
                    in.addOval(new RectF(o.left + X(0.01f), o.top + X(0.01f), o.right - X(0.01f), o.bottom - X(0.01f)),
                            Path.Direction.CW);
                    blue(c, in);
                }
                Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
                tp.setColor(0xFF000000);
                tp.setTextSize(X(0.045f));
                tp.setTextAlign(Paint.Align.CENTER);
                c.drawText(done ? "se queda adentro" : "se escapa por el corte", X(0.5f), X(0.85f), tp);
                break;
            }
            case SEPARATE: {
                figure(c, true, true);
                if (!done) {
                    Paint sc = new Paint(Paint.ANTI_ALIAS_FLAG);
                    sc.setStyle(Paint.Style.STROKE);
                    sc.setStrokeCap(Paint.Cap.ROUND);
                    sc.setStrokeWidth(X(0.025f));
                    sc.setColor(0xFFFF3B3B);
                    c.drawLine(X(0.42f), X(0.24f), X(0.58f), X(0.24f), sc);
                    sc.setColor(0xFF33CC55);
                    c.drawLine(X(0.42f), X(0.68f), X(0.58f), X(0.74f), sc);
                    sc.setColor(0xFFFFCC00);
                    c.drawLine(X(0.73f), X(0.62f), X(0.73f), X(0.78f), sc);
                    sc.setColor(0xFF888888);
                    c.drawLine(X(0.10f), X(0.12f), X(0.20f), X(0.30f), sc);
                } else {
                    fill.setStyle(Paint.Style.FILL);
                    fill.setColor(0x99FF3B3B);
                    c.drawPath(hair(), fill);
                    fill.setColor(0x9933CC55);
                    c.drawPath(body(), fill);
                    fill.setColor(0x99FFCC00);
                    c.drawPath(arm(), fill);
                    layerCard(c, "3 capas", false, 0);
                }
                break;
            }
            default:
                figure(c, true, true);
        }
        return b;
    }
}
