package com.pacco.animecut.core;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Corre lo pesado en segundo plano para que la app no se congele. */
public final class Task {

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** Para avisar en pantalla si algo de fondo fallo (por ejemplo, sin memoria). */
    public interface ErrorListener {
        void onError(Throwable t);
    }

    private static volatile ErrorListener listener;

    private Task() {
    }

    public static void setErrorListener(ErrorListener l) {
        listener = l;
    }

    public static void run(final Runnable background, final Runnable afterOnUi) {
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    background.run();
                } catch (final Throwable t) {
                    t.printStackTrace();
                    final ErrorListener l = listener;
                    if (l != null) {
                        MAIN.post(new Runnable() {
                            @Override
                            public void run() {
                                l.onError(t);
                            }
                        });
                    }
                }
                MAIN.post(afterOnUi);
            }
        });
    }
}
