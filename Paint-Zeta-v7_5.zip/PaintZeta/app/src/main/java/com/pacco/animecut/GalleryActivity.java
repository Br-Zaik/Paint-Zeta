package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.ProjectStore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Galeria de obras: la pantalla con la que arranca la app.
 * Muestra todo lo que has editado con su miniatura, como la galeria de Ibis.
 */
public class GalleryActivity extends AppCompatActivity {

    private GridView grid;
    private TextView empty;
    private List<ProjectStore.Entry> items;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_gallery);
        grid = findViewById(R.id.grid);
        empty = findViewById(R.id.empty);

        findViewById(R.id.btnNew).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(null);
            }
        });

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                open(items.get(pos).id);
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                options(items.get(pos));
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    /** Miniaturas en memoria: al volver a la galeria no se recargan ni parpadean. */
    private final android.util.LruCache<String, Bitmap> thumbs =
            new android.util.LruCache<String, Bitmap>(24 * 1024 * 1024) {
                @Override
                protected int sizeOf(String k, Bitmap b) {
                    return b.getByteCount();
                }
            };
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();
    private Adapter adapter;

    private void refresh() {
        items = ProjectStore.list(this);
        if (adapter == null) {
            adapter = new Adapter();
            grid.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void open(String id) {
        Intent i = new Intent(this, MainActivity.class);
        if (id != null) i.putExtra(MainActivity.EXTRA_PROJECT, id);
        startActivity(i);
        overridePendingTransition(R.anim.pz_fade_in, R.anim.pz_stay);
    }

    private void options(final ProjectStore.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Obra")
                .setItems(new String[]{"Abrir", "Renombrar", "Eliminar"},
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (which == 0) open(e.id);
                                else if (which == 1) rename(e);
                                else confirmDelete(e);
                            }
                        })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void rename(final ProjectStore.Entry e) {
        final android.widget.EditText in = new android.widget.EditText(this);
        String cur = ProjectStore.name(this, e.id);
        in.setText(cur == null ? "" : cur);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la obra")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        ProjectStore.setName(GalleryActivity.this, e.id, s);
                        refresh();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void confirmDelete(final ProjectStore.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar")
                .setMessage("Se borra esta obra con todas sus capas. No se puede recuperar.")
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        ProjectStore.delete(GalleryActivity.this, e.id);
                        Toast.makeText(GalleryActivity.this, "Obra eliminada", Toast.LENGTH_SHORT).show();
                        refresh();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private class Adapter extends BaseAdapter {

        private final SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm", Locale.US);

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int i) {
            return items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View reuse, ViewGroup parent) {
            Context c = GalleryActivity.this;
            LinearLayout root;
            if (reuse instanceof LinearLayout) {
                root = (LinearLayout) reuse;
            } else {
                root = (LinearLayout) getLayoutInflater().inflate(R.layout.item_gallery, parent, false);
            }
            ProjectStore.Entry e = items.get(pos);
            ImageView img = root.findViewById(R.id.thumb);
            TextView label = root.findViewById(R.id.label);

            final String key = e.thumb.getAbsolutePath() + ":" + e.thumb.lastModified();
            img.setTag(key);
            Bitmap bmp = thumbs.get(key);
            if (bmp != null) {
                img.setImageBitmap(bmp);
            } else if (!e.thumb.exists()) {
                img.setImageResource(R.drawable.ic_open);
            } else {
                img.setImageDrawable(null);
                final ImageView target = img;
                final String path = e.thumb.getAbsolutePath();
                io.execute(new Runnable() {
                    @Override
                    public void run() {
                        final Bitmap b = BitmapFactory.decodeFile(path);
                        if (b != null) thumbs.put(key, b);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (!key.equals(target.getTag())) return;
                                if (b != null) target.setImageBitmap(b);
                                else target.setImageResource(R.drawable.ic_open);
                            }
                        });
                    }
                });
            }

            String name = ProjectStore.name(GalleryActivity.this, e.id);
            String when = fmt.format(new Date(e.modified));
            label.setText(name == null || name.isEmpty() ? when : name + "\n" + when);
            return root;
        }
    }
}
