package com.pacco.animecut.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Mini animacion que muestra la herramienta trabajando: un dedo se mueve por
 * el dibujo y, por donde pasa, aparece el resultado. Se repite sola.
 */
public class ToolDemoView extends View {

    private final int mode;
    private final boolean sub;
    private Bitmap before, after;
    private float t = 0f;
    private ValueAnimator anim;
    private final Paint finger = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static final int KIND_BRUSH = 0, KIND_TAP = 1, KIND_TRACE = 2, KIND_FADE = 3;

    public ToolDemoView(Context c, int mode, boolean sub) {
        super(c);
        this.mode = mode;
        this.sub = sub;
        finger.setColor(0xDDFFFFFF);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(Color.WHITE);
        ring.setStrokeWidth(3f);
        frame.setStyle(Paint.Style.STROKE);
        frame.setColor(0x66FFFFFF);
        frame.setStrokeWidth(2f);
    }

    private int kind() {
        switch (mode) {
            case CanvasView.MODE_WAND:
            case CanvasView.MODE_BUCKET:
            case CanvasView.MODE_ZONE:
            case CanvasView.MODE_PICKER:
            case CanvasView.MODE_TONE:
                return KIND_TAP;
            case CanvasView.MODE_SCISSORS:
            case CanvasView.MODE_MAGNET:
            case CanvasView.MODE_LASSO:
                return KIND_TRACE;
            case CanvasView.MODE_MOVE:
            case CanvasView.MODE_PAN:
            case CanvasView.MODE_MARKER:
                return KIND_FADE;
            default:
                return KIND_BRUSH;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (before != null) before.recycle();
        if (after != null) after.recycle();
        before = ToolArt.panel(mode, sub, false, w, h);
        after = ToolArt.panel(mode, sub, true, w, h);
        start();
    }

    private void start() {
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(0f, 1.35f);
        anim.setDuration(3200);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    /** Recorrido del dedo para cada herramienta. */
    private Path route(float w, float h) {
        Path p = new Path();
        switch (mode) {
            case CanvasView.MODE_BGERASE:
                // borde del personaje, por afuera
                p.moveTo(w * 0.1f, h * 0.95f);
                p.lineTo(w * 0.12f, h * 0.2f);
                p.lineTo(w * 0.5f, h * 0.05f);
                p.lineTo(w * 0.88f, h * 0.2f);
                p.lineTo(w * 0.9f, h * 0.95f);
                break;
            case CanvasView.MODE_ERASER:
            case CanvasView.MODE_PAINT:
                p.moveTo(w * 0.25f, h * 0.85f);
                p.lineTo(w * 0.75f, h * 0.75f);
                p.lineTo(w * 0.3f, h * 0.95f);
                p.lineTo(w * 0.75f, h * 0.9f);
                break;
            case CanvasView.MODE_LINE:
                p.moveTo(w * 0.3f, h * 0.62f);
                p.cubicTo(w * 0.45f, h * 0.5f, w * 0.55f, h * 0.45f, w * 0.7f, h * 0.38f);
                break;
            default:
                // pasadas cortas sobre la zona de arriba (pelo y cara)
                p.moveTo(w * 0.3f, h * 0.2f);
                p.lineTo(w * 0.7f, h * 0.2f);
                p.lineTo(w * 0.3f, h * 0.35f);
                p.lineTo(w * 0.7f, h * 0.35f);
                p.lineTo(w * 0.35f, h * 0.52f);
                p.lineTo(w * 0.65f, h * 0.52f);
                p.lineTo(w * 0.5f, h * 0.8f);
                break;
        }
        return p;
    }

    private float[] tapPoint(float w, float h) {
        switch (mode) {
            case CanvasView.MODE_WAND:
                return new float[]{w * 0.5f, h * 0.2f};
            case CanvasView.MODE_TONE:
                return new float[]{w * 0.18f, h * 0.2f};
            default:
                return new float[]{w * 0.5f, h * 0.8f};
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (before == null || after == null) return;
        float w = getWidth(), h = getHeight();
        float p = Math.min(1f, t); // lo que pasa despues de 1 es la pausa con el resultado
        c.drawBitmap(before, 0, 0, null);

        switch (kind()) {
            case KIND_TAP: {
                float[] tp = tapPoint(w, h);
                float grow = p < 0.3f ? 0f : (p - 0.3f) / 0.7f;
                if (grow > 0f) {
                    Path clip = new Path();
                    clip.addCircle(tp[0], tp[1], grow * Math.max(w, h) * 1.2f, Path.Direction.CW);
                    c.save();
                    c.clipPath(clip);
                    c.drawBitmap(after, 0, 0, null);
                    c.restore();
                }
                if (t < 1f) {
                    float press = p < 0.3f ? p / 0.3f : 1f;
                    c.drawCircle(tp[0], tp[1], h * 0.05f * (1.4f - press * 0.4f), finger);
                    c.drawCircle(tp[0], tp[1], h * 0.09f * press, ring);
                }
                break;
            }
            case KIND_TRACE: {
                Path route = new Path();
                route.addCircle(w * 0.5f, h * 0.33f, h * 0.26f, Path.Direction.CW);
                PathMeasure pm = new PathMeasure(route, false);
                float len = pm.getLength();
                float drawn = Math.min(1f, p / 0.75f) * len;
                Path part = new Path();
                pm.getSegment(0, drawn, part, true);
                Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
                g.setStyle(Paint.Style.STROKE);
                g.setColor(0xFF32D74B);
                g.setStrokeWidth(h * 0.025f);
                if (p >= 0.8f) {
                    c.drawBitmap(after, 0, 0, null);
                } else {
                    c.drawPath(part, g);
                    float[] pos = new float[2];
                    pm.getPosTan(drawn, pos, null);
                    c.drawCircle(pos[0], pos[1], h * 0.045f, finger);
                }
                break;
            }
            case KIND_FADE: {
                Paint a = new Paint();
                a.setAlpha((int) (255 * Math.max(0f, Math.min(1f, (p - 0.35f) / 0.4f))));
                c.drawBitmap(after, 0, 0, a);
                if (t < 1f && p < 0.5f) {
                    float fx = w * (0.4f + p * 0.3f), fy = h * 0.5f;
                    c.drawCircle(fx, fy, h * 0.045f, finger);
                }
                break;
            }
            default: {
                // pincel: por donde pasa el dedo aparece el resultado
                Path route = route(w, h);
                PathMeasure pm = new PathMeasure(route, false);
                float len = pm.getLength();
                float drawn = p * len;
                float brush = h * 0.13f;
                Path reveal = new Path();
                float[] pos = new float[2];
                for (float d = 0; d <= drawn; d += brush * 0.35f) {
                    pm.getPosTan(d, pos, null);
                    reveal.addCircle(pos[0], pos[1], brush, Path.Direction.CW);
                }
                if (t >= 1f) {
                    c.drawBitmap(after, 0, 0, null);
                } else if (drawn > 0) {
                    c.save();
                    c.clipPath(reveal);
                    c.drawBitmap(after, 0, 0, null);
                    c.restore();
                    pm.getPosTan(drawn, pos, null);
                    c.drawCircle(pos[0], pos[1], brush, ring);
                    c.drawCircle(pos[0], pos[1], h * 0.035f, finger);
                }
                break;
            }
        }
        c.drawRect(new RectF(1, 1, w - 1, h - 1), frame);
    }
}
