package com.pacco.animecut.core;

/**
 * Encuentra la linea negra del dibujo sin que tengas que configurar nada.
 *
 * Una linea es lo que es oscuro Y mas oscuro que lo que tiene alrededor. Asi
 * el pelo negro o la ropa oscura no cuentan como linea (son oscuros, pero
 * parejos), y las lineas finas si.
 */
public final class AutoLines {

    private AutoLines() {
    }

    /** @return 255 donde hay linea, 0 donde no. */
    public static byte[] build(int[] px, int w, int h) {
        int n = w * h;
        byte[] lum = new byte[n];
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int l = (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
            // lo transparente cuenta como claro
            if ((c >>> 24) < 128) l = 255;
            lum[i] = (byte) l;
        }
        byte[] mean = lum.clone();
        MaskOps.feather(mean, w, h, 5);
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) {
            int l = lum[i] & 0xFF, m = mean[i] & 0xFF;
            if (l < 60 || (l < 120 && l < m - 22)) out[i] = (byte) 255;
        }
        return out;
    }
}
