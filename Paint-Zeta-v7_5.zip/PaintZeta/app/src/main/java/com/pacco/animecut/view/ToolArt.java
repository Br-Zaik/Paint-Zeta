package com.pacco.animecut.view;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/**
 * Dibujitos de "antes y despues" para explicar cada herramienta.
 * Un personaje simple (pelo, cara, cuerpo) sobre un fondo, y en cada caso
 * se muestra que le hace la herramienta.
 */
public final class ToolArt {

    private static final int SKIN = 0xFFF6D7C3, HAIR = 0xFF2B2B3A, SHIRT = 0xFF4F7FD9,
            BG = 0xFFB9E3F5, LINE = 0xFF111111, BLUE = 0x994DA3FF, RED = 0xFFE05A5A;

    private ToolArt() {
    }

    /** Devuelve un dibujo de antes y despues para esa herramienta. */
    public static Bitmap make(int mode, boolean sub, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(0xFF232329);
        float pad = h * 0.08f;
        float pw = (w - pad * 3 - h * 0.18f) / 2f;
        RectF left = new RectF(pad, pad, pad + pw, h - pad);
        RectF right = new RectF(w - pad - pw, pad, w - pad, h - pad);
        drawCase(c, left, mode, sub, false);
        drawCase(c, right, mode, sub, true);
        // flecha en el medio
        Paint a = paint(0xFFFFFFFF);
        a.setStyle(Paint.Style.STROKE);
        a.setStrokeWidth(h * 0.025f);
        a.setStrokeCap(Paint.Cap.ROUND);
        float mx = w / 2f, my = h / 2f, s = h * 0.06f;
        c.drawLine(mx - s, my, mx + s, my, a);
        c.drawLine(mx + s, my, mx + s * 0.3f, my - s * 0.7f, a);
        c.drawLine(mx + s, my, mx + s * 0.3f, my + s * 0.7f, a);
        return b;
    }

    /** Un solo cuadro: como se ve antes o despues de usar la herramienta. */
    public static Bitmap panel(int mode, boolean sub, boolean after, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        drawCase(c, new RectF(0, 0, w, h), mode, sub, after);
        return b;
    }

    private static void drawCase(Canvas c, RectF r, int mode, boolean sub, boolean after) {
        c.save();
        c.clipRect(r);
        switch (mode) {
            case CanvasView.MODE_BGERASE:
                background(c, r, after ? 0 : 1);
                character(c, r, SHIRT, true, true, true);
                if (!after) brushRing(c, r, r.left + r.width() * 0.78f, r.top + r.height() * 0.62f);
                break;
            case CanvasView.MODE_WAND:
                background(c, r, 1);
                character(c, r, SHIRT, true, true, true);
                if (after) overlayHair(c, r, BLUE);
                else tapDot(c, r, r.left + r.width() * 0.5f, r.top + r.height() * 0.2f);
                break;
            case CanvasView.MODE_BRUSH:
                background(c, r, 1);
                character(c, r, SHIRT, true, true, true);
                if (sub) {
                    overlayHead(c, r, BLUE);
                    if (!after) overlayHair(c, r, BLUE);
                    else brushRing(c, r, r.left + r.width() * 0.5f, r.top + r.height() * 0.2f);
                } else if (after) {
                    overlayHead(c, r, BLUE);
                    overlayHair(c, r, BLUE);
                } else {
                    brushRing(c, r, r.left + r.width() * 0.5f, r.top + r.height() * 0.35f);
                }
                break;
            case CanvasView.MODE_ERASER:
                background(c, r, 0);
                character(c, r, SHIRT, !after, true, true);
                if (!after) brushRing(c, r, r.left + r.width() * 0.5f, r.top + r.height() * 0.8f);
                break;
            case CanvasView.MODE_MARKER:
                background(c, r, after ? 0 : 1);
                if (!after) {
                    character(c, r, SHIRT, true, true, true);
                    scribble(c, r, 0.5f, 0.2f, 0xFFFF5A5F);
                    scribble(c, r, 0.5f, 0.42f, 0xFFFFC94A);
                    scribble(c, r, 0.5f, 0.8f, 0xFF1ED6A0);
                    scribble(c, r, 0.12f, 0.2f, 0xFF8A8A8A);
                } else {
                    // las partes separadas, un poco abiertas para que se note
                    c.save();
                    c.translate(0, -r.height() * 0.05f);
                    hair(c, r, HAIR);
                    c.restore();
                    head(c, r, SKIN);
                    c.save();
                    c.translate(0, r.height() * 0.05f);
                    body(c, r, SHIRT);
                    c.restore();
                }
                break;
            case CanvasView.MODE_SCISSORS:
            case CanvasView.MODE_MAGNET:
            case CanvasView.MODE_LASSO:
                background(c, r, 1);
                character(c, r, SHIRT, true, true, true);
                if (after) {
                    overlayHead(c, r, BLUE);
                    overlayHair(c, r, BLUE);
                } else {
                    Paint g = paint(0xFF32D74B);
                    g.setStyle(Paint.Style.STROKE);
                    g.setStrokeWidth(r.height() * 0.025f);
                    if (mode == CanvasView.MODE_LASSO) g.setPathEffect(new DashPathEffect(new float[]{8, 6}, 0));
                    c.drawCircle(r.centerX(), r.top + r.height() * 0.33f, r.height() * 0.24f, g);
                }
                break;
            case CanvasView.MODE_LINE:
                background(c, r, 2);
                Paint l = paint(LINE);
                l.setStyle(Paint.Style.STROKE);
                l.setStrokeWidth(r.height() * 0.035f);
                l.setStrokeCap(Paint.Cap.ROUND);
                Path p1 = new Path();
                p1.moveTo(r.left + r.width() * 0.1f, r.bottom - r.height() * 0.25f);
                p1.cubicTo(r.left + r.width() * 0.4f, r.bottom - r.height() * 0.35f,
                        r.left + r.width() * 0.6f, r.top + r.height() * 0.35f,
                        r.right - r.width() * 0.1f, r.top + r.height() * 0.25f);
                c.drawPath(p1, l);
                if (!after) {
                    Paint hole = paint(0xFF3A3A3F);
                    c.drawCircle(r.centerX(), r.centerY(), r.height() * 0.2f, hole);
                    dashedCircle(c, r.centerX(), r.centerY(), r.height() * 0.2f);
                }
                break;
            case CanvasView.MODE_ZONE:
            case CanvasView.MODE_PATCH:
            case CanvasView.MODE_HEAL:
            case CanvasView.MODE_CLONE:
                background(c, r, 1);
                body(c, r, SHIRT);
                stripes(c, r);
                head(c, r, SKIN);
                hair(c, r, HAIR);
                if (!after) {
                    Paint hole = paint(0xFF3A3A3F);
                    float cx = r.centerX(), cy = r.top + r.height() * 0.78f;
                    c.drawCircle(cx, cy, r.height() * 0.12f, hole);
                    dashedCircle(c, cx, cy, r.height() * 0.12f);
                    if (mode == CanvasView.MODE_PATCH) {
                        Paint gp = paint(0x8834C759);
                        c.drawCircle(r.left + r.width() * 0.25f, cy, r.height() * 0.1f, gp);
                    }
                    if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) {
                        cross(c, r.left + r.width() * 0.25f, cy, r.height() * 0.07f);
                    }
                    if (mode == CanvasView.MODE_ZONE) tapDot(c, r, cx, cy);
                }
                break;
            case CanvasView.MODE_TONE:
                background(c, r, 2);
                dots(c, r);
                if (!after) {
                    Paint hole = paint(0xFFFFFFFF);
                    c.drawCircle(r.centerX(), r.centerY(), r.height() * 0.2f, hole);
                    dashedCircle(c, r.centerX(), r.centerY(), r.height() * 0.2f);
                }
                break;
            case CanvasView.MODE_PAINT:
                background(c, r, 1);
                character(c, r, SHIRT, true, true, true);
                if (after) {
                    Paint pr = paint(RED);
                    pr.setStyle(Paint.Style.STROKE);
                    pr.setStrokeWidth(r.height() * 0.07f);
                    pr.setStrokeCap(Paint.Cap.ROUND);
                    c.drawLine(r.left + r.width() * 0.3f, r.top + r.height() * 0.8f,
                            r.left + r.width() * 0.7f, r.top + r.height() * 0.72f, pr);
                } else {
                    brushRing(c, r, r.left + r.width() * 0.3f, r.top + r.height() * 0.8f);
                }
                break;
            case CanvasView.MODE_BUCKET:
                background(c, r, 1);
                character(c, r, after ? RED : SHIRT, true, true, true);
                if (!after) tapDot(c, r, r.centerX(), r.top + r.height() * 0.8f);
                break;
            case CanvasView.MODE_PICKER:
                background(c, r, 1);
                character(c, r, SHIRT, true, true, true);
                if (after) {
                    Paint sw = paint(SHIRT);
                    RectF q = new RectF(r.right - r.width() * 0.3f, r.top + r.height() * 0.06f,
                            r.right - r.width() * 0.06f, r.top + r.height() * 0.3f);
                    c.drawRect(q, sw);
                    Paint e = paint(0xFFFFFFFF);
                    e.setStyle(Paint.Style.STROKE);
                    e.setStrokeWidth(3f);
                    c.drawRect(q, e);
                } else {
                    tapDot(c, r, r.centerX(), r.top + r.height() * 0.8f);
                }
                break;
            case CanvasView.MODE_MOVE:
                background(c, r, 1);
                character(c, r, SHIRT, true, true, true);
                c.save();
                if (after) c.translate(r.width() * 0.18f, 0);
                overlayHead(c, r, BLUE);
                c.restore();
                break;
            default:
                background(c, r, 1);
                c.save();
                if (after) {
                    c.translate(r.width() * 0.12f, r.height() * 0.05f);
                    c.scale(1.3f, 1.3f, r.centerX(), r.centerY());
                }
                character(c, r, SHIRT, true, true, true);
                c.restore();
                break;
        }
        c.restore();
        Paint frame = paint(0x66FFFFFF);
        frame.setStyle(Paint.Style.STROKE);
        frame.setStrokeWidth(2f);
        c.drawRect(r, frame);
    }

    // ---- piezas del dibujo ----

    private static Paint paint(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        return p;
    }

    /** kind 0 cuadros transparentes, 1 celeste, 2 blanco */
    private static void background(Canvas c, RectF r, int kind) {
        if (kind == 1) {
            c.drawRect(r, paint(BG));
        } else if (kind == 2) {
            c.drawRect(r, paint(0xFFFFFFFF));
        } else {
            Paint a = paint(0xFF55555C), b = paint(0xFF3A3A40);
            float s = r.height() / 10f;
            for (float y = r.top; y < r.bottom; y += s) {
                for (float x = r.left; x < r.right; x += s) {
                    boolean odd = (((int) ((x - r.left) / s) + (int) ((y - r.top) / s)) & 1) == 0;
                    c.drawRect(x, y, x + s, y + s, odd ? a : b);
                }
            }
        }
    }

    private static void character(Canvas c, RectF r, int shirt, boolean withBody, boolean withHead,
                                  boolean withHair) {
        if (withBody) body(c, r, shirt);
        if (withHead) head(c, r, SKIN);
        if (withHair) hair(c, r, HAIR);
    }

    private static void body(Canvas c, RectF r, int color) {
        RectF b = new RectF(r.left + r.width() * 0.22f, r.top + r.height() * 0.58f,
                r.right - r.width() * 0.22f, r.bottom + r.height() * 0.1f);
        c.drawRoundRect(b, r.width() * 0.2f, r.width() * 0.2f, paint(color));
        Paint o = outline(c);
        c.drawRoundRect(b, r.width() * 0.2f, r.width() * 0.2f, o);
    }

    private static void head(Canvas c, RectF r, int color) {
        float cx = r.centerX(), cy = r.top + r.height() * 0.38f, rad = r.height() * 0.2f;
        c.drawCircle(cx, cy, rad, paint(color));
        c.drawCircle(cx, cy, rad, outline(c));
        Paint eye = paint(LINE);
        c.drawCircle(cx - rad * 0.4f, cy + rad * 0.1f, rad * 0.1f, eye);
        c.drawCircle(cx + rad * 0.4f, cy + rad * 0.1f, rad * 0.1f, eye);
    }

    private static void hair(Canvas c, RectF r, int color) {
        float cx = r.centerX(), cy = r.top + r.height() * 0.33f, rad = r.height() * 0.23f;
        Path p = new Path();
        p.addArc(new RectF(cx - rad, cy - rad, cx + rad, cy + rad), 180, 180);
        p.lineTo(cx + rad * 0.9f, cy + rad * 0.2f);
        p.lineTo(cx - rad * 0.9f, cy + rad * 0.2f);
        p.close();
        c.drawPath(p, paint(color));
        c.drawPath(p, outline(c));
    }

    private static Paint outline(Canvas c) {
        Paint o = paint(LINE);
        o.setStyle(Paint.Style.STROKE);
        o.setStrokeWidth(Math.max(2f, c.getHeight() * 0.012f));
        return o;
    }

    private static void overlayHair(Canvas c, RectF r, int color) {
        hair(c, r, color);
    }

    private static void overlayHead(Canvas c, RectF r, int color) {
        float cx = r.centerX(), cy = r.top + r.height() * 0.38f, rad = r.height() * 0.2f;
        c.drawCircle(cx, cy, rad, paint(color));
    }

    private static void stripes(Canvas c, RectF r) {
        Paint s = paint(0xFF3A63B8);
        s.setStrokeWidth(r.height() * 0.03f);
        for (int k = 0; k < 5; k++) {
            float y = r.top + r.height() * (0.66f + k * 0.08f);
            c.drawLine(r.left + r.width() * 0.25f, y, r.right - r.width() * 0.25f, y, s);
        }
    }

    private static void dots(Canvas c, RectF r) {
        Paint d = paint(0xFF222222);
        float step = r.height() / 9f;
        for (float y = r.top + step / 2; y < r.bottom; y += step) {
            for (float x = r.left + step / 2; x < r.right; x += step) {
                c.drawCircle(x, y, step * 0.22f, d);
            }
        }
    }

    private static void scribble(Canvas c, RectF r, float fx, float fy, int color) {
        Paint p = paint(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r.height() * 0.05f);
        p.setStrokeCap(Paint.Cap.ROUND);
        float x = r.left + r.width() * fx, y = r.top + r.height() * fy, s = r.width() * 0.12f;
        Path z = new Path();
        z.moveTo(x - s, y);
        z.lineTo(x - s * 0.3f, y - s * 0.4f);
        z.lineTo(x + s * 0.3f, y + s * 0.3f);
        z.lineTo(x + s, y - s * 0.2f);
        c.drawPath(z, p);
    }

    private static void brushRing(Canvas c, RectF r, float x, float y) {
        Paint p = paint(0xFFFFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f);
        c.drawCircle(x, y, r.height() * 0.1f, p);
    }

    private static void tapDot(Canvas c, RectF r, float x, float y) {
        Paint p = paint(0xFFFFFFFF);
        c.drawCircle(x, y, r.height() * 0.035f, p);
        Paint q = paint(0x88FFFFFF);
        q.setStyle(Paint.Style.STROKE);
        q.setStrokeWidth(2.5f);
        c.drawCircle(x, y, r.height() * 0.08f, q);
    }

    private static void dashedCircle(Canvas c, float x, float y, float rad) {
        Paint p = paint(0xFFFF9F0A);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f);
        p.setPathEffect(new DashPathEffect(new float[]{6, 5}, 0));
        c.drawCircle(x, y, rad, p);
    }

    private static void cross(Canvas c, float x, float y, float s) {
        Paint p = paint(0xFFFF3B30);
        p.setStrokeWidth(3f);
        c.drawLine(x - s, y, x + s, y, p);
        c.drawLine(x, y - s, x, y + s, p);
    }
}
