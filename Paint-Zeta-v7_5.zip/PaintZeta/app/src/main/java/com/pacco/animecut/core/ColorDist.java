package com.pacco.animecut.core;

/**
 * Distancia entre colores. La varita compara con esto.
 *
 * RGB     : la diferencia del canal que mas se aleja. Rapida y literal.
 * COLOR   : pesa el tono por encima del brillo, asi una sombra del mismo
 *           color entra en la seleccion. Va en YCbCr.
 * PERCEPT : CIE Lab con distancia CIE76, que se parece mas a como el ojo
 *           ve la diferencia. Usa tablas para no calcular raices por pixel.
 *
 * Todas devuelven 0..255 para que la tolerancia signifique lo mismo.
 */
public final class ColorDist {

    public static final int RGB = 0;
    public static final int COLOR = 1;
    public static final int PERCEPT = 2;

    private static final float[] LIN = new float[256];
    private static final float[] CBRT = new float[4096];

    static {
        for (int i = 0; i < 256; i++) {
            float c = i / 255f;
            LIN[i] = c <= 0.04045f ? c / 12.92f : (float) Math.pow((c + 0.055f) / 1.055f, 2.4f);
        }
        for (int i = 0; i < CBRT.length; i++) {
            float t = i / (float) (CBRT.length - 1);
            CBRT[i] = t > 0.008856f ? (float) Math.cbrt(t) : (7.787f * t + 16f / 116f);
        }
    }

    private ColorDist() {
    }

    public static int dist(int a, int b, int mode) {
        int d;
        switch (mode) {
            case COLOR:
                d = chroma(a, b);
                break;
            case PERCEPT:
                d = lab(a, b);
                break;
            default:
                d = rgb(a, b);
                break;
        }
        // lo transparente no se parece a lo pintado aunque tenga el mismo color
        int da = Math.abs((a >>> 24) - (b >>> 24));
        return da > d ? da : d;
    }

    private static int rgb(int a, int b) {
        int dr = ((a >> 16) & 0xFF) - ((b >> 16) & 0xFF);
        int dg = ((a >> 8) & 0xFF) - ((b >> 8) & 0xFF);
        int db = (a & 0xFF) - (b & 0xFF);
        if (dr < 0) dr = -dr;
        if (dg < 0) dg = -dg;
        if (db < 0) db = -db;
        int m = dr > dg ? dr : dg;
        return db > m ? db : m;
    }

    /** El brillo pesa un cuarto; el tono manda. */
    private static int chroma(int a, int b) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;

        int ay = (ar * 77 + ag * 151 + ab * 28) >> 8;
        int by = (br * 77 + bg * 151 + bb * 28) >> 8;
        int acb = 128 + ((-43 * ar - 85 * ag + 128 * ab) >> 8);
        int bcb = 128 + ((-43 * br - 85 * bg + 128 * bb) >> 8);
        int acr = 128 + ((128 * ar - 107 * ag - 21 * ab) >> 8);
        int bcr = 128 + ((128 * br - 107 * bg - 21 * bb) >> 8);

        int dy = Math.abs(ay - by);
        int dcb = Math.abs(acb - bcb);
        int dcr = Math.abs(acr - bcr);
        int d = Math.max(dcb, dcr) + (dy >> 2);
        return d > 255 ? 255 : d;
    }

    private static int lab(int a, int b) {
        float[] la = toLab(a);
        float[] lb = toLab(b);
        float dl = la[0] - lb[0];
        float da = la[1] - lb[1];
        float db = la[2] - lb[2];
        float d = (float) Math.sqrt(dl * dl + da * da + db * db);
        // El maximo real de CIE76 ronda 100..150; se escala a 0..255.
        int v = (int) (d * 1.8f);
        return v > 255 ? 255 : v;
    }

    private static float[] toLab(int c) {
        float r = LIN[(c >> 16) & 0xFF];
        float g = LIN[(c >> 8) & 0xFF];
        float b = LIN[c & 0xFF];
        float x = (0.4124f * r + 0.3576f * g + 0.1805f * b) / 0.9505f;
        float y = (0.2126f * r + 0.7152f * g + 0.0722f * b);
        float z = (0.0193f * r + 0.1192f * g + 0.9505f * b) / 1.0890f;
        float fx = cbrt(x), fy = cbrt(y), fz = cbrt(z);
        return new float[]{116f * fy - 16f, 500f * (fx - fy), 200f * (fy - fz)};
    }

    private static float cbrt(float t) {
        if (t <= 0f) return CBRT[0];
        if (t >= 1f) return CBRT[CBRT.length - 1];
        return CBRT[(int) (t * (CBRT.length - 1))];
    }
}
