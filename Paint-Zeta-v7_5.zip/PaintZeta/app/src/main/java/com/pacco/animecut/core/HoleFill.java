package com.pacco.animecut.core;

import android.graphics.Rect;

import java.util.ArrayList;
import java.util.List;

/**
 * Tapa el hueco que deja una parte, pensado para anime:
 *
 * 1. Color plano: cada pixel del hueco toma el color de la zona plana mas
 *    cercana, sin contar la linea negra. Asi la piel o la ropa siguen lisas y
 *    no se forman manchas ni borrones.
 * 2. Linea: cada linea negra que entra al hueco se busca con la que sale del
 *    otro lado y se unen con una curva suave del mismo grosor y color.
 *
 * Solo se cambian pixeles dentro del hueco.
 */
public final class HoleFill {

    private HoleFill() {
    }

    private static boolean isLine(int c) {
        if ((c >>> 24) < 128) return false;
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        return (r * 299 + g * 587 + b * 114) / 1000 < 85;
    }

    /**
     * @param hole 1 byte por pixel, lo que hay que tapar (mas de 64 cuenta)
     * @return el rectangulo modificado, o null
     */
    public static Rect fill(final int[] px, final int w, int h, final byte[] hole, int grow) {
        Rect b = bounds(hole, w, h);
        if (b == null) return null;

        final byte[] mask = new byte[w * h];
        for (int i = 0; i < mask.length; i++) mask[i] = (byte) ((hole[i] & 0xFF) > 64 ? 255 : 0);
        if (grow > 0) MaskOps.dilate(mask, w, h, grow);

        Rect area = new Rect(b);
        area.inset(-(grow + 40), -(grow + 40));
        if (area.left < 0) area.left = 0;
        if (area.top < 0) area.top = 0;
        if (area.right > w) area.right = w;
        if (area.bottom > h) area.bottom = h;

        // 1) color plano: lo mas cercano que no sea linea
        DistanceTransform dt = DistanceTransform.build(w, h, area, new DistanceTransform.Source() {
            @Override
            public boolean isSource(int index) {
                return mask[index] == 0 && !isLine(px[index]);
            }
        }, true);
        if (dt == null) {
            dt = DistanceTransform.build(w, h, area, new DistanceTransform.Source() {
                @Override
                public boolean isSource(int index) {
                    return mask[index] == 0;
                }
            }, true);
        }
        if (dt == null) return null;
        for (int y = 0; y < dt.rh; y++) {
            int row = y * dt.rw;
            int base = (dt.rect.top + y) * w + dt.rect.left;
            for (int x = 0; x < dt.rw; x++) {
                int i = base + x;
                if (mask[i] == 0) continue;
                int src = dt.nearest[row + x];
                if (src >= 0) px[i] = px[src];
            }
        }

        // 2) lineas: puntas donde la linea toca el hueco
        joinLines(px, w, h, mask, area);
        return area;
    }

    private static final class End {
        float x, y, dx, dy, thick;
        int color;
        boolean used;
    }

    private static void joinLines(int[] px, int w, int h, byte[] mask, Rect area) {
        int aw = area.width(), ah = area.height();
        byte[] entry = new byte[aw * ah];
        int nEntries = 0;
        for (int y = area.top; y < area.bottom; y++) {
            for (int x = area.left; x < area.right; x++) {
                int i = y * w + x;
                if (mask[i] != 0 || !isLine(px[i])) continue;
                boolean touches = (x > 0 && mask[i - 1] != 0) || (x < w - 1 && mask[i + 1] != 0)
                        || (y > 0 && mask[i - w] != 0) || (y < h - 1 && mask[i + w] != 0);
                if (touches) {
                    entry[(y - area.top) * aw + (x - area.left)] = 1;
                    nEntries++;
                }
            }
        }
        if (nEntries < 2) return;
        // agrupar puntas vecinas
        List<End> ends = new ArrayList<End>();
        int[] stack = new int[nEntries + 8];
        for (int k = 0; k < entry.length; k++) {
            if (entry[k] != 1) continue;
            int sp = 0, n = 0;
            long sx = 0, sy = 0;
            stack[sp++] = k;
            entry[k] = 2;
            while (sp > 0) {
                int c = stack[--sp];
                int cx = c % aw, cy = c / aw;
                sx += cx;
                sy += cy;
                n++;
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dx = -2; dx <= 2; dx++) {
                        int nx = cx + dx, ny = cy + dy;
                        if (nx < 0 || ny < 0 || nx >= aw || ny >= ah) continue;
                        int q = ny * aw + nx;
                        if (entry[q] == 1) {
                            entry[q] = 2;
                            stack[sp++] = q;
                        }
                    }
                }
            }
            if (n < 1 || n > 60) continue;
            End e = new End();
            e.x = area.left + sx / (float) n;
            e.y = area.top + sy / (float) n;
            // direccion: de la linea de afuera hacia el hueco
            float vx = 0, vy = 0;
            long cr = 0, cg = 0, cb = 0;
            int cnt = 0;
            int R = 14;
            for (int yy = (int) e.y - R; yy <= (int) e.y + R; yy++) {
                for (int xx = (int) e.x - R; xx <= (int) e.x + R; xx++) {
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                    int i = yy * w + xx;
                    if (mask[i] != 0 || !isLine(px[i])) continue;
                    float ddx = xx - e.x, ddy = yy - e.y;
                    if (ddx * ddx + ddy * ddy > R * R) continue;
                    vx += ddx;
                    vy += ddy;
                    int c = px[i];
                    cr += (c >> 16) & 0xFF;
                    cg += (c >> 8) & 0xFF;
                    cb += c & 0xFF;
                    cnt++;
                }
            }
            float len = (float) Math.sqrt(vx * vx + vy * vy);
            if (cnt < 3 || len < 1e-3f) continue;
            e.dx = -vx / len;
            e.dy = -vy / len;
            e.thick = Math.max(1.2f, Math.min(9f, n * 0.9f));
            e.color = 0xFF000000 | ((int) (cr / cnt) << 16) | ((int) (cg / cnt) << 8) | (int) (cb / cnt);
            ends.add(e);
        }
        if (ends.size() < 2) return;

        // unir de a pares: las que se miran de frente y estan mas cerca
        float maxD = (float) Math.hypot(area.width(), area.height());
        while (true) {
            End bi = null, bj = null;
            float best = Float.MAX_VALUE;
            for (int i = 0; i < ends.size(); i++) {
                End a = ends.get(i);
                if (a.used) continue;
                for (int j = i + 1; j < ends.size(); j++) {
                    End c = ends.get(j);
                    if (c.used) continue;
                    float ux = c.x - a.x, uy = c.y - a.y;
                    float d = (float) Math.sqrt(ux * ux + uy * uy);
                    if (d < 3f || d > maxD) continue;
                    ux /= d;
                    uy /= d;
                    float ca = a.dx * ux + a.dy * uy;
                    float cc = -(c.dx * ux + c.dy * uy);
                    if (ca < 0.35f || cc < 0.35f) continue;
                    float score = d * (2.2f - ca - cc);
                    if (score < best) {
                        best = score;
                        bi = a;
                        bj = c;
                    }
                }
            }
            if (bi == null) break;
            bi.used = bj.used = true;
            drawCurve(px, w, h, mask, bi, bj);
        }
    }

    /** Curva suave entre dos puntas, con borde suave, solo dentro del hueco. */
    private static void drawCurve(int[] px, int w, int h, byte[] mask, End a, End b) {
        float d = (float) Math.hypot(b.x - a.x, b.y - a.y);
        float p1x = a.x + a.dx * d / 3f, p1y = a.y + a.dy * d / 3f;
        float p2x = b.x + b.dx * d / 3f, p2y = b.y + b.dy * d / 3f;
        int steps = Math.max(8, (int) (d * 2));
        float minX = Math.min(Math.min(a.x, b.x), Math.min(p1x, p2x)) - 12;
        float minY = Math.min(Math.min(a.y, b.y), Math.min(p1y, p2y)) - 12;
        float maxX = Math.max(Math.max(a.x, b.x), Math.max(p1x, p2x)) + 12;
        float maxY = Math.max(Math.max(a.y, b.y), Math.max(p1y, p2y)) + 12;
        int x0 = Math.max(0, (int) minX), y0 = Math.max(0, (int) minY);
        int x1 = Math.min(w, (int) maxX + 1), y1 = Math.min(h, (int) maxY + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int bw = x1 - x0, bh = y1 - y0;
        float[] cov = new float[bw * bh];
        for (int s = 0; s <= steps; s++) {
            float t = s / (float) steps, u = 1 - t;
            float x = u * u * u * a.x + 3 * u * u * t * p1x + 3 * u * t * t * p2x + t * t * t * b.x;
            float y = u * u * u * a.y + 3 * u * u * t * p1y + 3 * u * t * t * p2y + t * t * t * b.y;
            float r = (a.thick * u + b.thick * t) / 2f;
            int rx0 = Math.max(x0, (int) (x - r - 1)), rx1 = Math.min(x1 - 1, (int) (x + r + 1));
            int ry0 = Math.max(y0, (int) (y - r - 1)), ry1 = Math.min(y1 - 1, (int) (y + r + 1));
            for (int yy = ry0; yy <= ry1; yy++) {
                for (int xx = rx0; xx <= rx1; xx++) {
                    float dist = (float) Math.hypot(xx + 0.5f - x, yy + 0.5f - y);
                    float c = Math.max(0f, Math.min(1f, r + 0.5f - dist));
                    int k = (yy - y0) * bw + (xx - x0);
                    if (c > cov[k]) cov[k] = c;
                }
            }
        }
        for (int yy = y0; yy < y1; yy++) {
            for (int xx = x0; xx < x1; xx++) {
                float c = cov[(yy - y0) * bw + (xx - x0)];
                if (c <= 0f) continue;
                int i = yy * w + xx;
                if (mask[i] == 0) continue;
                float proj = (xx - a.x) * (b.x - a.x) + (yy - a.y) * (b.y - a.y);
                px[i] = mixT(px[i], a.color, b.color, proj, d, c);
            }
        }
    }

    private static int mixT(int base, int ca, int cb, float proj, float d, float t) {
        float f = d > 0 ? Math.max(0f, Math.min(1f, proj / (d * d))) : 0f;
        int lr = (int) (((ca >> 16) & 0xFF) * (1 - f) + ((cb >> 16) & 0xFF) * f);
        int lg = (int) (((ca >> 8) & 0xFF) * (1 - f) + ((cb >> 8) & 0xFF) * f);
        int lb = (int) ((ca & 0xFF) * (1 - f) + (cb & 0xFF) * f);
        int ba = base >>> 24;
        int r = (int) (((base >> 16) & 0xFF) * (1 - t) + lr * t);
        int g = (int) (((base >> 8) & 0xFF) * (1 - t) + lg * t);
        int bb = (int) ((base & 0xFF) * (1 - t) + lb * t);
        int al = (int) (ba * (1 - t) + 255 * t);
        return (al << 24) | (r << 16) | (g << 8) | bb;
    }

    public static Rect bounds(byte[] m, int w, int h) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if ((m[row + x] & 0xFF) <= 64) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }
}
