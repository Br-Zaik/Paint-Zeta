package com.pacco.animecut;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.pacco.animecut.core.SharePresets;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v8.92 Comprimir fotos: eliges fotos del telefono y "Para" (WhatsApp, Instagram, historias,
 * Facebook, correo, X...). Cada una sale en JPG con la medida y el peso de esa app, en
 * Imagenes > Paint Zeta > Comprimidas. Las fotos originales no se tocan. Se quitan los datos
 * ocultos de la foto (lugar, telefono). Todo pasa en el telefono, sin internet.
 */
final class CompressFlow {

    private final Activity act;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean cancel;
    private AlertDialog busyDlg;

    /** Medida mas grande que se arma (memoria): lado largo. */
    private static final int MAX_SIDE = 4096;

    CompressFlow(Activity a) { act = a; }

    private boolean gone() { return act.isFinishing() || act.isDestroyed(); }

    private int dp(float v) { return Math.round(v * act.getResources().getDisplayMetrics().density); }

    private void toast(String s) { if (!gone()) Toast.makeText(act, s, Toast.LENGTH_LONG).show(); }

    /** Paso 1: ya se eligieron las fotos: "Para que app?". */
    void start(final List<Uri> uris) {
        if (uris == null || uris.isEmpty() || gone()) return;
        final int n = SharePresets.count();
        String[] items = new String[n];
        for (int i = 0; i < n; i++) items[i] = SharePresets.NAMES[i] + "\n" + SharePresets.DESC[i];
        final int last = Math.max(0, Math.min(n - 1, act.getSharedPreferences("pz", Activity.MODE_PRIVATE).getInt("cmp_for", 0)));
        final int[] pick = {last};
        new AlertDialog.Builder(act)
                .setTitle(uris.size() == 1 ? "Comprimir 1 foto para..." : "Comprimir " + uris.size() + " fotos para...")
                .setSingleChoiceItems(items, last, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { pick[0] = which; }
                })
                .setPositiveButton("Comprimir", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        act.getSharedPreferences("pz", Activity.MODE_PRIVATE).edit().putInt("cmp_for", pick[0]).apply();
                        run(new ArrayList<Uri>(uris), pick[0]);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private static final class Result {
        int done, skipped, failed;
        long before, after;
        final ArrayList<Uri> out = new ArrayList<Uri>();
        String lastError;
    }

    /** Paso 2: una por una, en segundo plano, con barra de avance. */
    private void run(final List<Uri> uris, final int preset) {
        if (gone()) return;
        cancel = false;
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(12), dp(20), dp(4));
        final TextView msg = new TextView(act);
        msg.setText("Preparando...");
        root.addView(msg);
        final ProgressBar bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(uris.size());
        root.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(28)));
        busyDlg = new AlertDialog.Builder(act)
                .setTitle("Comprimiendo para " + SharePresets.NAMES[preset])
                .setView(root)
                .setCancelable(false)
                .setNegativeButton("Detener", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { cancel = true; }
                })
                .show();
        final ContentResolver cr = act.getApplicationContext().getContentResolver();
        final Result res = new Result();
        final String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new java.util.Date());
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                for (int i = 0; i < uris.size() && !cancel; i++) {
                    final int k = i;
                    main.post(new Runnable() {
                        @Override public void run() {
                            if (gone()) return;
                            msg.setText("Foto " + (k + 1) + " de " + uris.size());
                            bar.setProgress(k);
                        }
                    });
                    try {
                        one(cr, uris.get(i), preset, stamp + "_" + (i + 1), res);
                    } catch (OutOfMemoryError e) {
                        res.failed++;
                        res.lastError = "falta memoria";
                    } catch (Throwable e) {
                        res.failed++;
                        res.lastError = e.getMessage();
                    }
                }
                main.post(new Runnable() {
                    @Override public void run() { finish(res, preset); }
                });
            }
        }, "pz-comprimir");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        t.start();
    }

    private static long sizeOf(ContentResolver cr, Uri u) {
        try (android.content.res.AssetFileDescriptor fd = cr.openAssetFileDescriptor(u, "r")) {
            if (fd != null && fd.getLength() > 0) return fd.getLength();
        } catch (Throwable ignored) { }
        long n = 0;
        try (InputStream in = cr.openInputStream(u)) {
            if (in == null) return 0;
            byte[] b = new byte[1 << 16];
            for (int r; (r = in.read(b)) > 0; ) n += r;
        } catch (Throwable ignored) { }
        return n;
    }

    /** Una foto: leerla ya achicada, JPG con el peso pedido, guardar. */
    private void one(ContentResolver cr, Uri src, final int preset, String name, Result res) throws Exception {
        long before = sizeOf(cr, src);
        final int[] orig = new int[2];
        Bitmap b = android.graphics.ImageDecoder.decodeBitmap(android.graphics.ImageDecoder.createSource(cr, src),
                new android.graphics.ImageDecoder.OnHeaderDecodedListener() {
                    @Override public void onHeaderDecoded(android.graphics.ImageDecoder dec,
                                                          android.graphics.ImageDecoder.ImageInfo info,
                                                          android.graphics.ImageDecoder.Source s) {
                        int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                        orig[0] = w;
                        orig[1] = h;
                        int[] o = SharePresets.outSize(preset, w, h);
                        float k = Math.min(1f, MAX_SIDE / (float) Math.max(o[0], o[1]));
                        int tw = Math.max(1, Math.round(o[0] * k)), th = Math.max(1, Math.round(o[1] * k));
                        if (tw != w || th != h) dec.setTargetSize(tw, th);
                        dec.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                        dec.setTargetColorSpace(android.graphics.ColorSpace.get(android.graphics.ColorSpace.Named.SRGB));
                    }
                });
        byte[] jpg;
        try {
            if (b.hasAlpha()) {
                // JPG no tiene transparente: va sobre blanco
                Bitmap wb = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(wb);
                c.drawColor(0xFFFFFFFF);
                c.drawBitmap(b, 0, 0, null);
                b.recycle();
                b = wb;
            }
            jpg = encode(b, SharePresets.quality(preset), SharePresets.maxBytes(preset));
        } finally {
            b.recycle();
        }
        if (jpg == null) { res.failed++; res.lastError = "no se pudo llegar a ese peso"; return; }
        // si ya era mas liviana y no cambio de medida, no se guarda una copia mas pesada
        if (before > 0 && jpg.length >= before && SharePresets.outSize(preset, orig[0], orig[1])[0] == orig[0]) {
            res.skipped++;
            res.before += before;
            res.after += before;
            return;
        }
        Uri u = save(cr, "PZ_" + name + ".jpg", jpg);
        res.done++;
        res.before += before;
        res.after += jpg.length;
        res.out.add(u);
    }

    /** La mejor calidad que entra en maxBytes; si ni con poca calidad entra, se achica la medida. */
    private byte[] encode(Bitmap b, int q, long maxBytes) {
        Bitmap cur = b;
        try {
            for (int round = 0; round < 6 && !cancel; round++) {
                byte[] best = jpeg(cur, q);
                if (maxBytes <= 0 || best.length <= maxBytes) return best;
                byte[] low = jpeg(cur, 40);
                if (low.length <= maxBytes) {
                    int lo = 41, hi = q - 1;
                    byte[] ok = low;
                    while (lo <= hi) {
                        int mid = (lo + hi) >>> 1;
                        byte[] t = jpeg(cur, mid);
                        if (t.length <= maxBytes) { ok = t; lo = mid + 1; } else hi = mid - 1;
                    }
                    return ok;
                }
                float k = (float) Math.sqrt(maxBytes / (double) low.length) * 0.95f;
                k = Math.max(0.3f, Math.min(0.9f, k));
                Bitmap next = Bitmap.createScaledBitmap(cur, Math.max(1, Math.round(cur.getWidth() * k)),
                        Math.max(1, Math.round(cur.getHeight() * k)), true);
                if (cur != b) cur.recycle();
                cur = next;
            }
            return null;
        } finally {
            if (cur != b) cur.recycle();
        }
    }

    private static byte[] jpeg(Bitmap b, int q) {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 16);
        if (!b.compress(Bitmap.CompressFormat.JPEG, q, bo)) throw new IllegalStateException("no se pudo escribir");
        return bo.toByteArray();
    }

    /** Imagenes > Paint Zeta > Comprimidas (se ve en la galeria cuando ya esta completa). */
    private static Uri save(ContentResolver cr, String file, byte[] data) throws Exception {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, file);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/Paint Zeta/Comprimidas");
        cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri u = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (u == null) throw new IllegalStateException("no se pudo crear el archivo");
        try {
            OutputStream os = cr.openOutputStream(u);
            if (os == null) throw new IllegalStateException("no se pudo abrir el archivo");
            try { os.write(data); } finally { os.close(); }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, done, null, null);
            return u;
        } catch (Exception e) {
            try { cr.delete(u, null, null); } catch (Throwable ignored) { }
            throw e;
        }
    }

    private static String kb(long n) {
        return n >= 1_000_000L ? String.format(Locale.US, "%.1f MB", n / 1e6) : Math.max(1, Math.round(n / 1000.0)) + " kB";
    }

    /** Paso 3: cuanto se ahorro, y compartir. */
    private void finish(final Result r, int preset) {
        try { if (busyDlg != null) busyDlg.dismiss(); } catch (Throwable ignored) { }
        busyDlg = null;
        if (gone()) return;
        if (r.done == 0 && r.skipped == 0) {
            toast(cancel ? "Detenido" : "No se pudo comprimir" + (r.lastError != null ? ": " + r.lastError : ""));
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(r.done == 1 ? "1 foto lista" : r.done + " fotos listas").append(" para ").append(SharePresets.NAMES[preset]).append(".\n\n");
        if (r.before > 0) {
            int pct = (int) Math.round(100.0 * (r.before - r.after) / r.before);
            sb.append("Antes: ").append(kb(r.before)).append("\nAhora: ").append(kb(r.after));
            if (pct > 0) sb.append("  (").append(pct).append(" % menos)");
            sb.append("\n\n");
        }
        if (r.skipped > 0) sb.append(r.skipped == 1 ? "1 ya era liviana (no se copio).\n" : r.skipped + " ya eran livianas (no se copiaron).\n");
        if (r.failed > 0) sb.append(r.failed == 1 ? "1 no se pudo abrir.\n" : r.failed + " no se pudieron abrir.\n");
        if (cancel) sb.append("Detenido antes de terminar.\n");
        sb.append("Estan en Imagenes > Paint Zeta > Comprimidas. Las originales siguen igual. "
                + "Se quitaron los datos ocultos de la foto (lugar y telefono).");
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle("Listo")
                .setMessage(sb.toString())
                .setPositiveButton("Listo", null);
        if (!r.out.isEmpty()) b.setNeutralButton("Compartir", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int w) { share(r.out); }
        });
        b.show();
    }

    private void share(ArrayList<Uri> out) {
        try {
            Intent send;
            if (out.size() == 1) {
                send = new Intent(Intent.ACTION_SEND);
                send.putExtra(Intent.EXTRA_STREAM, out.get(0));
            } else {
                send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, out);
            }
            send.setType("image/jpeg");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.startActivity(Intent.createChooser(send, "Compartir"));
        } catch (Throwable t) {
            toast("No hay apps para compartir");
        }
    }

    void release() {
        cancel = true;
        try { if (busyDlg != null) busyDlg.dismiss(); } catch (Throwable ignored) { }
        busyDlg = null;
    }
}
