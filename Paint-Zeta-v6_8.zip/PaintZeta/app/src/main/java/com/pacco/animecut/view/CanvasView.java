package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.pacco.animecut.core.AutoLines;
import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Filters;
import com.pacco.animecut.core.FloodFill;
import com.pacco.animecut.core.GuidedFilter;
import com.pacco.animecut.core.HoleFill;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.LineArt;
import com.pacco.animecut.core.LineRepair;
import com.pacco.animecut.core.LiveWire;
import com.pacco.animecut.core.MaskOps;
import com.pacco.animecut.core.Membrane;
import com.pacco.animecut.core.PatchFill;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.ToneFill;
import com.pacco.animecut.core.UndoManager;
import com.pacco.animecut.core.Watershed;
import com.pacco.animecut.core.ZoneFill;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * El lienzo, trabajando igual que Ibis: capas de verdad con transparencia,
 * una capa de seleccion (lo azul), y dos dedos que solo mueven y hacen zoom.
 */
public class CanvasView extends View {

    public static final int MODE_PAN = 0;
    public static final int MODE_WAND = 1;
    public static final int MODE_BRUSH = 2;
    public static final int MODE_ERASER = 3;
    public static final int MODE_LASSO = 4;
    public static final int MODE_CLONE = 5;
    public static final int MODE_PAINT = 6;
    public static final int MODE_BUCKET = 7;
    public static final int MODE_PICKER = 8;
    public static final int MODE_SCISSORS = 9;
    public static final int MODE_MOVE = 10;
    public static final int MODE_BGERASE = 11;
    public static final int MODE_MARKER = 12;
    public static final int MODE_MAGNET = 13;
    public static final int MODE_LINE = 14;
    public static final int MODE_ZONE = 15;
    public static final int MODE_PATCH = 16;
    public static final int MODE_HEAL = 17;
    public static final int MODE_TONE = 18;

    public static final String[] LABEL_NAMES = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "fondo"};
    public static final int[] LABEL_COLORS = {
            0xFFFF5A5F, 0xFFFFC94A, 0xFF1ED6A0, 0xFF1A9BFF, 0xFFFF4FA3, 0xFFB9794A,
            0xFF8B5CF6, 0xFF3B82F6, 0xFFFB7A1B, 0xFF84CC16, 0xFFF9A8D4, 0xFF8A8A8A
    };
    public static final int BG_LABEL = 12;

    /** Fondos para mirar: cuadros claros, cuadros oscuros, blanco, negro, verde. */
    public static final int[][] VIEW_BG = {
            {0xFFFFFFFF, 0xFFD6D6D6}, {0xFF4A4A50, 0xFF33333A}, {0xFFFFFFFF, 0xFFFFFFFF},
            {0xFF1A1A1A, 0xFF000000}, {0xFF17C964, 0xFF0E9B4C}
    };

    public interface Callback {
        void onBusy(boolean busy);

        void onChanged();

        void onMessage(String msg);

        void onColorPicked(int color);

        void onUndoGesture();

        void onRedoGesture();
    }

    private Project project;
    private UndoManager undo;
    private Callback callback;

    // pantalla
    private Bitmap display;
    private float dispScale = 1f;
    private Bitmap overlay, markersOverlay, patchOverlay;
    private int ovScale = 1;
    private final Matrix view = new Matrix();
    private final Matrix inverse = new Matrix();
    private final float[] point = new float[2];
    private ScaleGestureDetector scaleDetector;
    private int insetTop, insetBottom;
    private int viewBg = 0;

    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ovPaint = new Paint();
    private final Paint lassoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wirePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint aimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePreview = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghostPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    // ajustes de herramienta
    private int mode = MODE_WAND;
    private float brushRadius = 20f;
    private float hardness = 0.7f;
    private float brushOpacity = 1f;
    private int paintColor = 0xFFE05A5A;
    private int tolerance = 28, softness = 24, colorMode = ColorDist.RGB;
    private float expansion = 1.5f;
    private boolean gapOn = false;
    private int gapRadius = 4;
    private boolean wandGlobal = false, useBarrier = false, subtract = false, smart = false;
    private float stabilizer = 0f;
    private boolean aimOn = false;
    private float aimDx = 0f, aimDy = -110f;
    private boolean bgOnce = true;
    private boolean bgBucket = true;
    private int bgLimit = 0;
    private int bgTolerance = 46, bgSoftness = 34;
    private boolean protectOn = false;
    private int protectColor = 0;
    private int markerLabel = 1, gapClose = 2;
    private boolean cloneMirror = false;
    private float cloneAngle = 0f;
    private boolean busy = false;

    // buffers que se reutilizan
    private byte[] scratch, selBackup, gapBarrier, gradient, markers, patchSource, repairLines;
    private int[] pxBackup;
    /** Cuanto se pinto ya cada pixel en este trazo, para que repasar no aclare. */
    private byte[] cov;

    // toque
    private final Handler handler = new Handler(Looper.getMainLooper());
    private float downX, downY, lastSX, lastSY;
    private long downTime, strokeStart;
    private boolean pendingStroke, pendingTap, multi, drawing, panning, midValid;
    private float tapX, tapY, lastMidX, lastMidY, lastAngle, lastPanX, lastPanY;
    private int gestureMax;
    private float gestureMoved;
    private float touchSlop;
    private final Runnable startPending = new Runnable() {
        @Override
        public void run() {
            if (pendingStroke && !multi) beginPending();
        }
    };

    // trazo
    private float lastX, lastY, smoothX, smoothY;
    private boolean smoothInit;
    private Rect strokeRect;
    private Layer strokeLayer;
    private boolean strokeOnSelection, strokeErase, selectionActive;
    private int painted, bgRef, refColor;
    private boolean showRing;
    private float ringX, ringY;

    // lazo, tijeras, magnetico, linea
    private final Path lasso = new Path();
    private LiveWire wire;
    private final Path wirePath = new Path();
    private int[] livePath;
    private int firstAnchor = -1;
    private boolean wireStarted;
    private final ArrayList<float[]> linePts = new ArrayList<float[]>();

    // clonar
    private boolean cloneSrcSet;
    private float cloneSrcX, cloneSrcY, cloneDestX, cloneDestY;

    // mover
    private int[] moveBackup;
    private byte[] moveSelBackup;
    private float moveFromX, moveFromY;
    private int moveDx, moveDy;
    private long lastMoveApply;

    // cuentagotas rapido
    private boolean quickPick, quickArmed;
    private float pickX, pickY;
    private int pickColor;
    private Runnable quickRunnable;

    // avisos
    private String hud;
    private long hudUntil;
    private boolean hintedHidden;
    private Rect lastFillRect;
    private byte[] previewBackup;

    public CanvasView(Context c) {
        super(c);
        init(c);
    }

    public CanvasView(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        float d = getResources().getDisplayMetrics().density;
        touchSlop = 7f * d;
        aimDy = -46f * d;
        ovPaint.setFilterBitmap(false);
        lassoPaint.setStyle(Paint.Style.STROKE);
        lassoPaint.setColor(0xFF3D7BFF);
        lassoPaint.setStrokeWidth(3f);
        markPaint.setStyle(Paint.Style.STROKE);
        markPaint.setColor(0xFFFF5252);
        markPaint.setStrokeWidth(3f);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(0xCC888888);
        ringPaint.setStrokeWidth(2f);
        hudBg.setColor(0xCC000000);
        hudText.setColor(Color.WHITE);
        hudText.setTextSize(d * 14f);
        hudText.setTextAlign(Paint.Align.CENTER);
        pinEdge.setColor(0xFFF0F0F0);
        wirePaint.setStyle(Paint.Style.STROKE);
        wirePaint.setColor(0xFF32D74B);
        wirePaint.setStrokeWidth(3f);
        loupeEdge.setStyle(Paint.Style.STROKE);
        loupeEdge.setColor(Color.WHITE);
        loupeEdge.setStrokeWidth(3f * d);
        aimPaint.setStyle(Paint.Style.STROKE);
        aimPaint.setColor(0xFFFF3B30);
        aimPaint.setStrokeWidth(2f * d);
        linePreview.setStyle(Paint.Style.STROKE);
        linePreview.setColor(0xFFFF9F0A);
        linePreview.setStrokeWidth(3f * d);
        linePreview.setStrokeCap(Paint.Cap.ROUND);
        ghostPaint.setAlpha(150);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector det) {
                float f = det.getScaleFactor();
                float cur = currentScale();
                if (cur * f < 0.03f || cur * f > 60f) return true;
                view.postScale(f, f, det.getFocusX(), det.getFocusY());
                showHud(Math.round(currentScale() * dispScale * 100f) + "%");
                return true;
            }
        });
    }

    // ==================================================================
    // Proyecto
    // ==================================================================

    public void setCallback(Callback cb) {
        callback = cb;
    }

    public void setProject(Project p) {
        dropDetail();
        project = p;
        undo = p == null ? null : new UndoManager(p);
        scratch = selBackup = gapBarrier = gradient = markers = patchSource = repairLines = null;
        pxBackup = null;
        wire = null;
        cloneSrcSet = false;
        subtract = false;
        hintedHidden = false;
        mode = MODE_WAND;
        lasso.reset();
        wirePath.reset();
        linePts.clear();
        if (markersOverlay != null) markersOverlay.recycle();
        if (patchOverlay != null) patchOverlay.recycle();
        markersOverlay = patchOverlay = null;
        if (p != null) {
            buildDisplay();
            buildOverlay();
            post(new Runnable() {
                @Override
                public void run() {
                    fit();
                }
            });
        }
        invalidate();
    }

    public Project getProject() {
        return project;
    }

    /** La capa donde se pinta, o null si esta activa la capa de seleccion. */
    private Layer target() {
        return project == null ? null : project.activeLayer();
    }

    private boolean paintsSelection() {
        return project != null && project.isSelectionLayerActive();
    }

    /** Revisa que haya una capa normal elegida y visible. */
    private Layer needLayer() {
        Layer t = target();
        if (t == null) {
            msg("Toca una capa en Capas: ahora esta elegida la capa de seleccion");
            return null;
        }
        if (!t.visible && !hintedHidden) {
            hintedHidden = true;
            showHud("Esa capa esta oculta: prendele el ojo en Capas");
        }
        return t;
    }

    // ==================================================================
    // Pantalla
    // ==================================================================

    private void buildDisplay() {
        Bitmap old = display;
        int max = Math.max(project.w, project.h);
        float s = max > 2048 ? max / 2048f : 1f;
        int dw = Math.max(1, Math.round(project.w / s)), dh = Math.max(1, Math.round(project.h / s));
        display = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        dispScale = (float) project.w / dw;
        composeRegion(0, 0, dw, dh);
        if (old != null && !old.isRecycled()) old.recycle();
        invalidateDetail();
        scheduleDetail();
    }

    public void refreshDisplay() {
        if (project == null) return;
        buildDisplay();
        invalidate();
    }

    /** Todas las capas visibles, una encima de otra, sobre el fondo de vista. */
    private void composeRegion(int x0, int y0, int x1, int y1) {
        if (display == null || project == null) return;
        int dw = display.getWidth(), dh = display.getHeight();
        x0 = Math.max(0, x0);
        y0 = Math.max(0, y0);
        x1 = Math.min(dw, x1);
        y1 = Math.min(dh, y1);
        if (x0 >= x1 || y0 >= y1) return;
        LayerSrc[] src = layerSources();
        int[] bg = VIEW_BG[viewBg];
        int w = project.w, h = project.h;
        int rw = x1 - x0;
        int[] row = new int[rw];
        int cs = 8;
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(h - 1, (int) (y * dispScale));
            for (int x = x0; x < x1; x++) {
                int sx = Math.min(w - 1, (int) (x * dispScale));
                int c = (((x / cs) + (y / cs)) & 1) == 0 ? bg[0] : bg[1];
                row[x - x0] = over(src, c, sx, sy, w);
            }
            display.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    /** Lo que se necesita para leer una capa rapido, dense o recortada. */
    private static final class LayerSrc {
        int[] dense;
        Layer.Packed packed;
        int op;
        int[] rowBuf;
        int rowY = Integer.MIN_VALUE;

        /** Pixel de una capa empacada: se lee de a una fila entera del Bitmap. */
        int get(int sx, int sy) {
            Layer.Packed p = packed;
            if (sy < p.y || sy >= p.y + p.h || sx < p.x || sx >= p.x + p.w) return 0;
            if (sy != rowY) {
                if (rowBuf == null) rowBuf = new int[p.w];
                p.row(sy, rowBuf);
                rowY = sy;
            }
            return rowBuf[sx - p.x];
        }
    }

    private LayerSrc[] layerSources() {
        ArrayList<LayerSrc> out = new ArrayList<LayerSrc>();
        for (Layer l : project.layers) {
            if (!l.visible || l.opacity <= 0) continue;
            LayerSrc s = new LayerSrc();
            s.op = l.opacity;
            int[] d = l.denseOrNull();
            if (d != null && d.length == project.w * project.h) s.dense = d;
            else {
                s.packed = l.packedOrNull();
                if (s.packed == null) {
                    d = l.denseOrNull();
                    if (d == null || d.length != project.w * project.h) continue;
                    s.dense = d;
                } else if (s.packed.empty()) continue;
            }
            out.add(s);
        }
        return out.toArray(new LayerSrc[0]);
    }

    private static int over(LayerSrc[] src, int c, int sx, int sy, int w) {
        int i = sy * w + sx;
        for (LayerSrc s : src) {
            int col = s.dense != null ? s.dense[i] : s.get(sx, sy);
            int a = ((col >>> 24) * s.op) / 255;
            if (a > 0) c = blendA(c, col, a);
        }
        return c;
    }

    // ------------------------------------------------------------------
    // Zoom con la resolucion original: al acercarse se dibuja la zona que se
    // ve directo de las capas, pixel por pixel, en vez de la vista reducida.
    // ------------------------------------------------------------------

    /** Maximo de pixeles del detalle (unos 22 MB). */
    private static final int DETAIL_MAX_PX = 5_500_000;
    private Bitmap detail;
    private Rect detailRect;
    private boolean detailValid, detailBuilding, smoothZoom = true;
    private int detailGen;
    private final Paint detailPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Runnable detailRunnable = new Runnable() {
        @Override
        public void run() {
            buildDetail();
        }
    };

    public void setSmoothZoom(boolean on) {
        smoothZoom = on;
        invalidate();
    }

    public boolean isSmoothZoom() {
        return smoothZoom;
    }

    /** Zona de la imagen que conviene tener en alta: lo visible y un margen. */
    private Rect wantedDetail() {
        if (project == null || dispScale <= 1.01f || getWidth() == 0) return null;
        float sc = currentScale();
        if (sc * dispScale < 1.1f) return null;
        if (!view.invert(inverse)) return null;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        float mx = v.width() * 0.12f, my = v.height() * 0.12f;
        Rect r = new Rect((int) Math.floor(v.left - mx), (int) Math.floor(v.top - my),
                (int) Math.ceil(v.right + mx), (int) Math.ceil(v.bottom + my));
        if (!r.intersect(0, 0, project.w, project.h)) return null;
        if ((long) r.width() * r.height() > DETAIL_MAX_PX) return null;
        return r;
    }

    private boolean visibleInside(Rect d) {
        if (d == null || !view.invert(inverse)) return false;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        RectF img = new RectF(0, 0, project.w, project.h);
        if (!v.intersect(img)) return true;
        return v.left >= d.left - 0.5f && v.top >= d.top - 0.5f && v.right <= d.right + 0.5f && v.bottom <= d.bottom + 0.5f;
    }

    private void scheduleDetail() {
        handler.removeCallbacks(detailRunnable);
        handler.postDelayed(detailRunnable, 90);
    }

    /** Algo cambio en todo el dibujo: el detalle se vuelve a armar. */
    private void invalidateDetail() {
        detailGen++;
        detailValid = false;
    }

    private void dropDetail() {
        handler.removeCallbacks(detailRunnable);
        detailGen++;
        detailValid = false;
        if (detail != null && !detail.isRecycled()) detail.recycle();
        detail = null;
        detailRect = null;
    }

    private void buildDetail() {
        if (project == null || busy || drawing) {
            if (project != null) scheduleDetail();
            return;
        }
        if (detailBuilding) return;
        final Rect r = wantedDetail();
        if (r == null) {
            if (detail != null) dropDetail();
            return;
        }
        if (detailValid && detailRect != null && detailRect.contains(r)) return;
        detailBuilding = true;
        final int gen = detailGen;
        final LayerSrc[] src = layerSources();
        final byte[] sel = project.selection;
        final int w = project.w, h = project.h;
        final int[] bg = VIEW_BG[viewBg];
        final float cs = 8f * dispScale;
        final Project owner = project;
        final Bitmap[] out = new Bitmap[1];
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap b = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888);
                    int[] row = new int[r.width()];
                    for (int y = r.top; y < r.bottom; y++) {
                        for (int x = r.left; x < r.right; x++) {
                            row[x - r.left] = detailPixel(src, sel, bg, cs, x, y, w);
                        }
                        b.setPixels(row, 0, row.length, 0, y - r.top, row.length, 1);
                    }
                    out[0] = b;
                } catch (Throwable t) {
                    out[0] = null;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                detailBuilding = false;
                Bitmap b = out[0];
                if (b == null) return;
                if (owner != project || gen != detailGen) {
                    b.recycle();
                    scheduleDetail();
                    return;
                }
                if (detail != null && !detail.isRecycled()) detail.recycle();
                detail = b;
                detailRect = r;
                detailValid = true;
                invalidate();
            }
        });
    }

    private static int detailPixel(LayerSrc[] src, byte[] sel, int[] bg, float cs, int x, int y, int w) {
        int c = ((((int) (x / cs)) + ((int) (y / cs))) & 1) == 0 ? bg[0] : bg[1];
        c = over(src, c, x, y, w);
        int a = sel[y * w + x] & 0xFF;
        if (a != 0) c = blendA(c, 0xFF3D7BFF, (a * 140) / 255);
        return c;
    }

    /** Actualiza al momento la parte del detalle que cambio (trazos, relleno chico). */
    private void updateDetail(Rect changed) {
        if (detail == null || detailRect == null || !detailValid || changed == null) return;
        Rect r = new Rect(changed);
        if (!r.intersect(detailRect)) return;
        if ((long) r.width() * r.height() > 1_200_000L) {
            invalidateDetail();
            scheduleDetail();
            return;
        }
        detailGen++;
        LayerSrc[] src = layerSources();
        int[] bg = VIEW_BG[viewBg];
        float cs = 8f * dispScale;
        int[] row = new int[r.width()];
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                row[x - r.left] = detailPixel(src, project.selection, bg, cs, x, y, project.w);
            }
            detail.setPixels(row, 0, row.length, r.left - detailRect.left, y - detailRect.top, row.length, 1);
        }
    }

    private static int blendA(int dst, int src, int a) {
        if (a >= 255) return src | 0xFF000000;
        int r = (((src >> 16) & 0xFF) * a + ((dst >> 16) & 0xFF) * (255 - a)) / 255;
        int g = (((src >> 8) & 0xFF) * a + ((dst >> 8) & 0xFF) * (255 - a)) / 255;
        int b = ((src & 0xFF) * a + (dst & 0xFF) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void updateDisplayRegion(Rect r) {
        if (display == null || r == null) return;
        composeRegion((int) (r.left / dispScale) - 1, (int) (r.top / dispScale) - 1,
                (int) Math.ceil(r.right / dispScale) + 1, (int) Math.ceil(r.bottom / dispScale) + 1);
        updateDetail(r);
        invalidate();
    }

    /** Despues de cambiar pixeles de una capa. */
    private void pixelsChanged(Rect r) {
        project.markDirty();
        wire = null;
        updateDisplayRegion(r);
        changed();
    }

    private void buildOverlay() {
        if (overlay != null) overlay.recycle();
        int max = Math.max(project.w, project.h);
        ovScale = max > 1440 ? (int) Math.ceil(max / 1440f) : 1;
        overlay = Bitmap.createBitmap(Math.max(1, project.w / ovScale), Math.max(1, project.h / ovScale),
                Bitmap.Config.ARGB_8888);
        paintOverlay(project.fullRect());
    }

    private void paintOverlay(Rect r) {
        if (overlay == null || project == null) return;
        int ow = overlay.getWidth(), oh = overlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int a = project.selection[sy * project.w + sx] & 0xFF;
                row[i] = a == 0 ? 0 : (((a * 140) / 255) << 24) | 0x3D7BFF;
            }
            overlay.setPixels(row, 0, rw, x0, y, rw, 1);
        }
        updateDetail(r);
    }

    public void refreshOverlay(Rect r) {
        if (project == null) return;
        paintOverlay(r == null ? project.fullRect() : r);
        invalidate();
    }

    public void setViewBg(int v) {
        viewBg = Math.max(0, Math.min(VIEW_BG.length - 1, v));
        refreshDisplay();
    }

    public int getViewBg() {
        return viewBg;
    }

    public void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
    }

    public void fit() {
        if (project == null || getWidth() == 0) return;
        int usable = getHeight() - insetTop - insetBottom;
        if (usable < 80) usable = getHeight();
        float s = Math.min((float) getWidth() / project.w, (float) usable / project.h) * 0.96f;
        view.reset();
        view.postScale(s, s);
        view.postTranslate((getWidth() - project.w * s) / 2f, insetTop + (usable - project.h * s) / 2f);
        invalidate();
    }

    private float currentScale() {
        float[] v = new float[9];
        view.getValues(v);
        return (float) Math.sqrt(v[Matrix.MSCALE_X] * v[Matrix.MSCALE_X] + v[Matrix.MSKEW_X] * v[Matrix.MSKEW_X]);
    }

    public void showHud(String text) {
        hud = text;
        hudUntil = System.currentTimeMillis() + 1400;
        invalidate();
        postInvalidateDelayed(1450);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(0xFF121214);
        if (project == null || display == null) return;
        bmpPaint.setFilterBitmap(smoothZoom || currentScale() * dispScale < 1f);
        detailPaint.setFilterBitmap(smoothZoom || currentScale() < 1f);

        c.save();
        c.concat(view);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, bmpPaint);
        c.restore();

        boolean useDetail = detail != null && !detail.isRecycled() && detailValid && detailRect != null;
        if (useDetail) {
            c.save();
            c.concat(view);
            c.drawBitmap(detail, detailRect.left, detailRect.top, detailPaint);
            c.restore();
        }
        Rect want = wantedDetail();
        if (want == null) {
            if (detail != null) handler.post(new Runnable() {
                @Override
                public void run() {
                    if (wantedDetail() == null) dropDetail();
                }
            });
        } else if (!useDetail || !visibleInside(detailRect)) {
            scheduleDetail();
        }

        if (overlay != null) {
            if (useDetail) {
                c.save();
                Path clip = new Path();
                clip.addRect(new RectF(detailRect), Path.Direction.CW);
                Path sp = new Path();
                clip.transform(view, sp);
                c.clipOutPath(sp);
                drawOv(c, overlay);
                c.restore();
            } else {
                drawOv(c, overlay);
            }
        }
        if (mode == MODE_MARKER && sepPreview != null && !sepPreview.isRecycled() && sepPreviewRect != null) {
            c.save();
            c.concat(view);
            c.drawBitmap(sepPreview, null, new RectF(sepPreviewRect), previewPaint);
            c.restore();
        }
        if (markersOverlay != null && mode == MODE_MARKER) drawOv(c, markersOverlay);
        if (patchOverlay != null && mode == MODE_PATCH) drawOv(c, patchOverlay);

        if (mode == MODE_LASSO && !lasso.isEmpty()) {
            Path sp = new Path();
            lasso.transform(view, sp);
            c.drawPath(sp, lassoPaint);
        }
        if (mode == MODE_SCISSORS || mode == MODE_MAGNET) drawWire(c);
        if (mode == MODE_LINE && linePts.size() > 1) {
            Path lp = new Path();
            for (int i = 0; i < linePts.size(); i++) {
                point[0] = linePts.get(i)[0];
                point[1] = linePts.get(i)[1];
                view.mapPoints(point);
                if (i == 0) lp.moveTo(point[0], point[1]);
                else lp.lineTo(point[0], point[1]);
            }
            c.drawPath(lp, linePreview);
        }
        if ((mode == MODE_CLONE || mode == MODE_HEAL) && cloneSrcSet) {
            point[0] = cloneSrcX;
            point[1] = cloneSrcY;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 22f, markPaint);
            c.drawLine(point[0] - 30, point[1], point[0] + 30, point[1], markPaint);
            c.drawLine(point[0], point[1] - 30, point[0], point[1] + 30, markPaint);
        }

        float rx = ringX + (usesAim() ? aimDx : 0f), ry = ringY + (usesAim() ? aimDy : 0f);
        if (showRing && usesBrush() && !quickPick) c.drawCircle(rx, ry, brushRadius * currentScale(), ringPaint);
        if ((mode == MODE_CLONE || mode == MODE_HEAL) && cloneSrcSet && drawing) drawCloneGhost(c, rx, ry);
        if (usesAim() && showRing && !quickPick) {
            float d = getResources().getDisplayMetrics().density;
            c.drawLine(rx - 10 * d, ry, rx + 10 * d, ry, aimPaint);
            c.drawLine(rx, ry - 10 * d, rx, ry + 10 * d, aimPaint);
            drawLoupe(c, rx, ry);
        }
        if (quickPick) drawPin(c);
        if (hud != null && System.currentTimeMillis() < hudUntil) {
            float pad = 14f * getResources().getDisplayMetrics().density;
            float tw = hudText.measureText(hud);
            float cx = getWidth() / 2f, top = insetTop + pad;
            c.drawRoundRect(new RectF(cx - tw / 2 - pad, top, cx + tw / 2 + pad, top + pad * 2.6f), 12f, 12f, hudBg);
            c.drawText(hud, cx, top + pad * 1.8f, hudText);
        }
    }

    private void drawOv(Canvas c, Bitmap b) {
        c.save();
        c.concat(view);
        c.scale(ovScale, ovScale);
        c.drawBitmap(b, 0, 0, ovPaint);
        c.restore();
    }

    private void drawWire(Canvas c) {
        Path sp = new Path();
        wirePath.transform(view, sp);
        c.drawPath(sp, wirePaint);
        if (livePath != null && livePath.length > 1) {
            Path p = new Path();
            for (int i = 0; i < livePath.length; i += 2) {
                int y = livePath[i] / project.w, x = livePath[i] - y * project.w;
                if (i == 0) p.moveTo(x, y);
                else p.lineTo(x, y);
            }
            Path q = new Path();
            p.transform(view, q);
            c.drawPath(q, wirePaint);
        }
        if (firstAnchor >= 0) {
            point[0] = firstAnchor % project.w;
            point[1] = firstAnchor / project.w;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 16f, wirePaint);
        }
    }

    private void drawLoupe(Canvas c, float sx, float sy) {
        if (display == null) return;
        float d = getResources().getDisplayMetrics().density;
        float r = 62f * d, margin = 12f * d;
        float cx = sx < getWidth() / 2f ? getWidth() - r - margin : r + margin;
        float cy = insetTop + r + margin;
        imagePoint(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float ix = point[0] / dispScale, iy = point[1] / dispScale;
        float zoom = Math.max(2.5f, currentScale() * dispScale * 3f);
        Path clip = new Path();
        clip.addCircle(cx, cy, r, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.drawColor(0xFF202024);
        c.translate(cx, cy);
        c.scale(zoom, zoom);
        c.translate(-ix, -iy);
        c.drawBitmap(display, 0, 0, ovPaint);
        if (overlay != null) {
            c.save();
            c.scale(ovScale / dispScale, ovScale / dispScale);
            c.drawBitmap(overlay, 0, 0, ovPaint);
            c.restore();
        }
        c.restore();
        c.drawCircle(cx, cy, r, loupeEdge);
        c.drawLine(cx - 9 * d, cy, cx + 9 * d, cy, aimPaint);
        c.drawLine(cx, cy - 9 * d, cx, cy + 9 * d, aimPaint);
    }

    private void drawPin(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float r = 34f * d, cx = pickX, cy = pickY - r * 1.8f;
        pinFill.setColor(pickColor);
        pinEdge.setStyle(Paint.Style.FILL);
        Path tip = new Path();
        tip.moveTo(cx - r * 0.42f, cy + r * 0.86f);
        tip.lineTo(cx, cy + r * 1.9f);
        tip.lineTo(cx + r * 0.42f, cy + r * 0.86f);
        tip.close();
        c.drawPath(tip, pinEdge);
        c.drawCircle(cx, cy, r, pinEdge);
        c.drawCircle(cx, cy, r - 4f * d, pinFill);
    }

    private void drawCloneGhost(Canvas c, float sx, float sy) {
        imagePoint(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float dxi = point[0], dyi = point[1];
        float ddx = dxi - cloneDestX, ddy = dyi - cloneDestY;
        if (cloneMirror) ddx = -ddx;
        double a = Math.toRadians(cloneAngle);
        float srcX = cloneSrcX + (float) (ddx * Math.cos(a) - ddy * Math.sin(a));
        float srcY = cloneSrcY + (float) (ddx * Math.sin(a) + ddy * Math.cos(a));
        Matrix m = new Matrix();
        m.setTranslate(-srcX, -srcY);
        m.postRotate(-cloneAngle);
        if (cloneMirror) m.postScale(-1f, 1f);
        m.postTranslate(dxi, dyi);
        m.postConcat(view);
        Path clip = new Path();
        clip.addCircle(sx, sy, Math.max(12f, brushRadius * currentScale()), Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.concat(m);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, ghostPaint);
        c.restore();
    }

    // ==================================================================
    // Toque: un dedo trabaja, dos dedos mueven y hacen zoom. Como Ibis.
    // ==================================================================

    private boolean usesBrush() {
        return mode == MODE_BRUSH || mode == MODE_ERASER || mode == MODE_CLONE || mode == MODE_PAINT
                || (mode == MODE_BGERASE && !bgBucket) || mode == MODE_MARKER || mode == MODE_PATCH
                || mode == MODE_HEAL;
    }

    private boolean isTapTool() {
        return mode == MODE_WAND || mode == MODE_BUCKET || mode == MODE_PICKER || mode == MODE_ZONE
                || mode == MODE_TONE || (mode == MODE_BGERASE && bgBucket);
    }

    private boolean usesAim() {
        return aimOn && mode != MODE_PAN && mode != MODE_MOVE;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (project == null || busy) return true;
        int action = e.getActionMasked();
        int pc = e.getPointerCount();
        scaleDetector.onTouchEvent(e);
        long now = System.currentTimeMillis();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                multi = false;
                midValid = false;
                gestureMax = 1;
                gestureMoved = 0f;
                downTime = now;
                downX = e.getX();
                downY = e.getY();
                lastSX = downX;
                lastSY = downY;
                ringX = downX;
                ringY = downY;
                pickX = downX;
                pickY = downY;
                showRing = usesBrush();
                armQuickPick();
                if (mode == MODE_PAN) {
                    panning = true;
                    lastPanX = downX;
                    lastPanY = downY;
                } else if (isTapTool()) {
                    pendingTap = true;
                    tapX = downX;
                    tapY = downY;
                    if (usesAim()) showRing = true;
                } else {
                    // el trazo no empieza todavia: si llega un segundo dedo, no se pinta nada
                    pendingStroke = true;
                    handler.postDelayed(startPending, 90);
                }
                invalidate();
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                multi = true;
                gestureMax = Math.max(gestureMax, pc);
                cancelQuickTimer();
                if (quickPick) endQuickPick(false);
                handler.removeCallbacks(startPending);
                pendingStroke = false;
                pendingTap = false;
                if (drawing) {
                    if (now - strokeStart < 400) cancelStroke();
                    else endStroke();
                }
                panning = false;
                showRing = false;
                if (pc >= 2) twoFingers(e);
                invalidate();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (multi) {
                    if (pc >= 2) twoFingers(e);
                    return true;
                }
                float mx = e.getX(), my = e.getY();
                gestureMoved += Math.abs(mx - lastSX) + Math.abs(my - lastSY);
                lastSX = mx;
                lastSY = my;
                ringX = mx;
                ringY = my;
                float moved = (float) Math.hypot(mx - downX, my - downY);
                if (quickPick) {
                    updateQuickPick(mx, my);
                    return true;
                }
                if (moved > touchSlop) cancelQuickTimer();
                if (panning) {
                    view.postTranslate(mx - lastPanX, my - lastPanY);
                    lastPanX = mx;
                    lastPanY = my;
                    invalidate();
                    return true;
                }
                if (pendingTap) {
                    if (moved > touchSlop) {
                        if (usesAim()) {
                            tapX = mx;
                            tapY = my;
                        } else {
                            pendingTap = false;
                        }
                    }
                    invalidate();
                    return true;
                }
                if (pendingStroke && moved > touchSlop) beginPending();
                if (drawing) moveStroke(mx, my);
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                if (pc >= 2) twoFingers(e);
                midValid = false;
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cancelQuickTimer();
                handler.removeCallbacks(startPending);
                boolean up = action == MotionEvent.ACTION_UP;
                if (quickPick) {
                    endQuickPick(up);
                } else if (!multi) {
                    if (pendingTap && up) {
                        runTapTool(tapX, tapY);
                    } else if (pendingStroke && up) {
                        beginPending();
                        if (drawing) endStroke();
                    } else if (drawing) {
                        endStroke();
                    }
                } else if (drawing) {
                    endStroke();
                }
                if (multi && up) checkTapGesture(now);
                pendingStroke = false;
                pendingTap = false;
                panning = false;
                multi = false;
                showRing = false;
                invalidate();
                return true;
        }
        return true;
    }

    private void beginPending() {
        pendingStroke = false;
        handler.removeCallbacks(startPending);
        strokeStart = System.currentTimeMillis();
        startStroke(downX, downY);
        if (drawing && (lastSX != downX || lastSY != downY)) moveStroke(lastSX, lastSY);
    }

    /** Dos dedos: tocar deshace, tres rehace. */
    private void checkTapGesture(long now) {
        if (callback == null) return;
        if (now - downTime > 280 || gestureMoved > 40f) return;
        if (gestureMax == 2) callback.onUndoGesture();
        else if (gestureMax >= 3) callback.onRedoGesture();
    }

    private void twoFingers(MotionEvent e) {
        float mx = (e.getX(0) + e.getX(1)) / 2f, my = (e.getY(0) + e.getY(1)) / 2f;
        float angle = (float) Math.toDegrees(Math.atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)));
        if (!midValid) {
            lastMidX = mx;
            lastMidY = my;
            lastAngle = angle;
            midValid = true;
            return;
        }
        float dx = mx - lastMidX, dy = my - lastMidY;
        view.postTranslate(dx, dy);
        float da = angle - lastAngle;
        while (da > 180f) da -= 360f;
        while (da < -180f) da += 360f;
        if (Math.abs(da) > 0.4f) view.postRotate(da, mx, my);
        gestureMoved += Math.abs(dx) + Math.abs(dy) + Math.abs(da);
        lastMidX = mx;
        lastMidY = my;
        lastAngle = angle;
        invalidate();
    }

    private void armQuickPick() {
        cancelQuickTimer();
        quickArmed = true;
        quickRunnable = new Runnable() {
            @Override
            public void run() {
                if (!quickArmed || project == null || multi) return;
                if (drawing) cancelStroke();
                pendingStroke = false;
                pendingTap = false;
                panning = false;
                quickPick = true;
                updateQuickPick(pickX, pickY);
            }
        };
        handler.postDelayed(quickRunnable, 600);
    }

    private void cancelQuickTimer() {
        quickArmed = false;
        if (quickRunnable != null) handler.removeCallbacks(quickRunnable);
    }

    private void updateQuickPick(float sx, float sy) {
        pickX = sx;
        pickY = sy;
        imagePoint(sx, sy);
        int x = (int) point[0], y = (int) point[1];
        if (x >= 0 && y >= 0 && x < project.w && y < project.h) {
            int c = project.ref()[y * project.w + x];
            pickColor = c | 0xFF000000;
        }
        invalidate();
    }

    private void endQuickPick(boolean apply) {
        quickPick = false;
        if (apply) {
            paintColor = pickColor;
            if (callback != null) callback.onColorPicked(paintColor);
        }
        invalidate();
    }

    /** Pantalla a imagen, sin el desplazamiento del cursor. */
    private void imagePoint(float x, float y) {
        view.invert(inverse);
        point[0] = x;
        point[1] = y;
        inverse.mapPoints(point);
    }

    /** Pantalla a imagen, contando el cursor desplazado si esta activo. */
    private void toImage(float x, float y) {
        if (usesAim() && !quickPick) {
            x += aimDx;
            y += aimDy;
        }
        imagePoint(x, y);
    }

    // ==================================================================
    // Herramientas de un toque
    // ==================================================================

    private void runTapTool(float sx, float sy) {
        toImage(sx, sy);
        int px = (int) point[0], py = (int) point[1];
        if (px < 0 || py < 0 || px >= project.w || py >= project.h) return;
        switch (mode) {
            case MODE_WAND:
                runWand(px, py);
                break;
            case MODE_BUCKET:
                if (paintsSelection()) runWand(px, py);
                else runBucket(px, py);
                break;
            case MODE_PICKER:
                paintColor = project.ref()[py * project.w + px] | 0xFF000000;
                if (callback != null) callback.onColorPicked(paintColor);
                break;
            case MODE_ZONE:
                runZoneFill(px, py);
                break;
            case MODE_TONE:
                runToneFill(px, py);
                break;
            case MODE_BGERASE:
                runBgBucket(px, py);
                break;
        }
    }

    // ==================================================================
    // Trazos
    // ==================================================================

    private void startStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0], iy = point[1];
        int px = (int) ix, py = (int) iy;
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;
        strokeRect = null;
        smoothInit = false;
        lastX = ix;
        lastY = iy;

        switch (mode) {
            case MODE_BRUSH:
                beginSelectionStroke(subtract, inside ? project.ref()[py * project.w + px] : 0);
                stamp(ix, iy);
                return;
            case MODE_PAINT:
            case MODE_ERASER:
                if (paintsSelection()) {
                    beginSelectionStroke(mode == MODE_ERASER, 0);
                } else {
                    if (!beginLayerStroke()) return;
                    strokeErase = mode == MODE_ERASER;
                    painted = 0;
                }
                stamp(ix, iy);
                return;
            case MODE_BGERASE:
                if (!beginLayerStroke()) return;
                // si empiezas sobre lo ya borrado, no pasa nada: toma el color
                // del fondo apenas el pincel llegue a algo que queda
                bgRefValid = inside && sampleBgRef(px, py);
                if (bgLimit == 2) ensureGradient(strokeLayer.px());
                stamp(ix, iy);
                return;
            case MODE_MARKER:
                ensureMarkers();
                drawing = true;
                stamp(ix, iy);
                return;
            case MODE_PATCH:
                ensurePatchSource();
                drawing = true;
                stamp(ix, iy);
                return;
            case MODE_CLONE:
            case MODE_HEAL:
                if (needLayer() == null) return;
                if (!cloneSrcSet) {
                    cloneSrcX = ix;
                    cloneSrcY = iy;
                    cloneSrcSet = true;
                    msg("Origen marcado con la cruz roja. Ahora pinta donde quieres copiar");
                    invalidate();
                    return;
                }
                if (!beginLayerStroke()) return;
                cloneDestX = ix;
                cloneDestY = iy;
                stamp(ix, iy);
                return;
            case MODE_LINE:
                linePts.clear();
                linePts.add(new float[]{ix, iy});
                drawing = true;
                invalidate();
                return;
            case MODE_LASSO:
                lasso.reset();
                lasso.moveTo(ix, iy);
                drawing = true;
                invalidate();
                return;
            case MODE_SCISSORS:
                if (!inside) return;
                drawing = true;
                if (!wireStarted) {
                    wireStarted = true;
                    firstAnchor = py * project.w + px;
                    wirePath.reset();
                    wirePath.moveTo(px, py);
                    setAnchorAsync(px, py);
                }
                return;
            case MODE_MAGNET:
                if (!inside) return;
                if (wire == null) wire = new LiveWire(project.ref(), project.w, project.h);
                wirePath.reset();
                wirePath.moveTo(px, py);
                firstAnchor = py * project.w + px;
                wireStarted = true;
                wire.setAnchor(px, py, 120);
                livePath = null;
                drawing = true;
                return;
            case MODE_MOVE:
                startMove(ix, iy);
                return;
        }
    }

    private void beginSelectionStroke(boolean erase, int ref) {
        int n = project.w * project.h;
        if (selBackup == null || selBackup.length != n) selBackup = new byte[n];
        System.arraycopy(project.selection, 0, selBackup, 0, n);
        strokeOnSelection = true;
        strokeErase = erase;
        refColor = ref;
        drawing = true;
    }

    /** Copia de la capa antes de pintar (para deshacer). Si no alcanza la memoria, avisa. */
    private boolean fillBackup(Layer t) {
        int n = project.w * project.h;
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                if (pxBackup == null || pxBackup.length != n) {
                    pxBackup = null;
                    pxBackup = new int[n];
                }
                System.arraycopy(t.px(), 0, pxBackup, 0, n);
                return true;
            } catch (OutOfMemoryError e) {
                pxBackup = null;
                handler.removeCallbacks(compactRunnable);
                try {
                    project.packInactive();
                } catch (OutOfMemoryError ignored) {
                }
                if (undo != null) undo.trimTo(0.3f);
                System.gc();
            }
        }
        msg("Ya no alcanza la memoria del telefono. Combina o borra alguna capa.");
        return false;
    }

    private boolean beginLayerStroke() {
        Layer t = needLayer();
        if (t == null) return false;
        int n = project.w * project.h;
        if (!fillBackup(t)) return false;
        try {
            if (cov == null || cov.length != n) cov = new byte[n];
            else Arrays.fill(cov, (byte) 0);
        } catch (OutOfMemoryError e) {
            msg("Ya no alcanza la memoria del telefono. Combina o borra alguna capa.");
            return false;
        }
        strokeLayer = t;
        strokeOnSelection = false;
        selectionActive = project.hasSelection();
        drawing = true;
        return true;
    }

    private void moveStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0], iy = point[1];
        switch (mode) {
            case MODE_LASSO:
                lasso.lineTo(ix, iy);
                invalidate();
                return;
            case MODE_LINE:
                float[] last = linePts.get(linePts.size() - 1);
                if (Math.hypot(ix - last[0], iy - last[1]) > 2f) linePts.add(new float[]{ix, iy});
                invalidate();
                return;
            case MODE_SCISSORS:
                if (wire != null && wire.hasAnchor()) {
                    livePath = wire.pathTo((int) ix, (int) iy);
                    invalidate();
                }
                return;
            case MODE_MAGNET:
                if (wire == null || !wire.hasAnchor()) return;
                livePath = wire.pathTo((int) ix, (int) iy);
                if (Math.hypot(ix - lastX, iy - lastY) > 36f && livePath != null && livePath.length > 1) {
                    appendLive();
                    wire.setAnchor((int) ix, (int) iy, 120);
                    lastX = ix;
                    lastY = iy;
                }
                invalidate();
                return;
            case MODE_MOVE:
                moveDx = Math.round(ix - moveFromX);
                moveDy = Math.round(iy - moveFromY);
                long now = System.currentTimeMillis();
                if (now - lastMoveApply > 45) {
                    lastMoveApply = now;
                    applyMove(false);
                }
                return;
        }
        if (stabilizer > 0f) {
            if (!smoothInit) {
                smoothX = ix;
                smoothY = iy;
                smoothInit = true;
            }
            smoothX = smoothX * stabilizer + ix * (1f - stabilizer);
            smoothY = smoothY * stabilizer + iy * (1f - stabilizer);
            ix = smoothX;
            iy = smoothY;
        }
        float dx = ix - lastX, dy = iy - lastY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float step = Math.max(0.6f, brushRadius * 0.3f);
        int n = (int) (dist / step);
        for (int i = 1; i <= n; i++) {
            float t = i / (float) n;
            stamp(lastX + dx * t, lastY + dy * t);
        }
        if (n > 0) {
            lastX = ix;
            lastY = iy;
        }
        invalidate();
    }

    private void stamp(float x, float y) {
        if (!drawing) return;
        switch (mode) {
            case MODE_BRUSH:
                stampSelection(x, y);
                break;
            case MODE_PAINT:
            case MODE_ERASER:
                if (strokeOnSelection) stampSelection(x, y);
                else if (strokeErase) stampErase(x, y);
                else stampPaint(x, y);
                break;
            case MODE_BGERASE:
                stampBgErase(x, y);
                break;
            case MODE_MARKER:
                stampMarker(x, y);
                break;
            case MODE_PATCH:
                stampPatchSource(x, y);
                break;
            case MODE_CLONE:
            case MODE_HEAL:
                stampClone(x, y);
                break;
        }
    }

    private void endStroke() {
        if (!drawing) return;
        drawing = false;
        smoothInit = false;
        switch (mode) {
            case MODE_LASSO: {
                Path closed = new Path(lasso);
                closed.close();
                lasso.reset();
                fillPathIntoSelection(closed, "Lazo");
                return;
            }
            case MODE_SCISSORS:
                commitWire();
                return;
            case MODE_MAGNET: {
                appendLive();
                Path closed = new Path(wirePath);
                closed.close();
                scissorsReset();
                fillPathIntoSelection(closed, "Magnetico");
                return;
            }
            case MODE_LINE:
                finishLine();
                return;
            case MODE_MOVE:
                finishMove();
                return;
            case MODE_MARKER:
                schedulePreview();
                return;
            case MODE_PATCH:
                return;
            case MODE_HEAL:
                if (strokeRect != null) finishHeal(strokeRect);
                strokeRect = null;
                return;
        }
        if (mode == MODE_BGERASE && strokeRect != null && strokeLayer != null) despeckle(strokeRect);
        if (strokeRect == null) return;
        if (strokeOnSelection) {
            undo.setLabel(strokeErase ? "Borrar azul" : "Marcar azul");
            undo.recordSelectionFromBackup(strokeRect, selBackup);
            changed();
        } else if (strokeLayer != null) {
            if (mode == MODE_PAINT && painted == 0 && selectionActive) {
                msg("Hay algo seleccionado: solo se pinta dentro de lo azul. Quita la seleccion para pintar libre");
            }
            undo.setLabel(mode == MODE_PAINT ? "Pincelada" : mode == MODE_ERASER ? "Goma"
                    : mode == MODE_BGERASE ? "Borrar fondo" : "Clonar");
            undo.recordLayerFromBackup(strokeLayer, strokeRect, pxBackup);
            project.markDirty();
            wire = null;
            changed();
        }
        strokeRect = null;
    }

    /** Deshace el trazo en curso sin tocar el historial (llego un segundo dedo). */
    private void cancelStroke() {
        if (!drawing) return;
        drawing = false;
        Rect r = strokeRect;
        strokeRect = null;
        lasso.reset();
        linePts.clear();
        if (mode == MODE_SCISSORS || mode == MODE_MAGNET) {
            livePath = null;
            if (mode == MODE_MAGNET) scissorsReset();
        }
        if (mode == MODE_MOVE && moveBackup != null) {
            Layer t = target();
            if (t != null) System.arraycopy(moveBackup, 0, t.px(), 0, moveBackup.length);
            if (moveSelBackup != null) System.arraycopy(moveSelBackup, 0, project.selection, 0, moveSelBackup.length);
            moveBackup = null;
            project.markDirty();
            refreshDisplay();
            refreshOverlay(null);
            return;
        }
        if (r == null) {
            invalidate();
            return;
        }
        int rw = r.width();
        if (strokeOnSelection && selBackup != null) {
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(selBackup, y * project.w + r.left, project.selection, y * project.w + r.left, rw);
            }
            paintOverlay(r);
        } else if (strokeLayer != null && pxBackup != null) {
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(pxBackup, y * project.w + r.left, strokeLayer.px(), y * project.w + r.left, rw);
            }
            project.markDirty();
            updateDisplayRegion(r);
        }
        invalidate();
    }

    private void grow(Rect r) {
        if (r == null) return;
        if (strokeRect == null) strokeRect = new Rect(r);
        else strokeRect.union(r);
    }

    private Rect disk(float cx, float cy) {
        int x0 = Math.max(0, (int) Math.floor(cx - brushRadius) - 1);
        int y0 = Math.max(0, (int) Math.floor(cy - brushRadius) - 1);
        int x1 = Math.min(project.w, (int) Math.ceil(cx + brushRadius) + 2);
        int y1 = Math.min(project.h, (int) Math.ceil(cy + brushRadius) + 2);
        if (x0 >= x1 || y0 >= y1) return null;
        return new Rect(x0, y0, x1, y1);
    }

    private float falloff(int x, int y, float cx, float cy) {
        float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d > brushRadius) return 0f;
        float inner = brushRadius * hardness;
        return d <= inner ? 1f : 1f - (d - inner) / Math.max(1f, brushRadius - inner);
    }

    /** Pincel sobre lo azul. Con "fino" solo agarra el color donde empezaste. */
    private void stampSelection(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        int[] ref = smart ? project.ref() : null;
        int limit = tolerance + softness;
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                if (a <= 0f) continue;
                int i = row + x;
                int cap = 255;
                if (smart && !strokeErase) {
                    if (useBarrier && project.barrier != null && project.barrier[i] != 0) continue;
                    int d = ColorDist.dist(ref[i], refColor, colorMode);
                    if (d > limit) continue;
                    if (d > tolerance && softness > 0) cap = 255 - ((d - tolerance) * 255) / softness;
                }
                int cur = project.selection[i] & 0xFF;
                if (strokeErase) {
                    int v = cur - (int) (a * 255f);
                    project.selection[i] = (byte) (v < 0 ? 0 : v);
                } else {
                    int v = (int) (a * cap);
                    if (v > cur) project.selection[i] = (byte) v;
                }
            }
        }
        grow(r);
        paintOverlay(r);
        invalidate();
    }

    /** Brocha: pinta el color encima de la capa. Pinta tambien en lo transparente. */
    private void stampPaint(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        int[] px = strokeLayer.px();
        int alphaColor = paintColor >>> 24;
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                int i = row + x;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                if (a <= 0f) continue;
                int sa = (int) (a * alphaColor);
                if (sa <= (cov[i] & 0xFF)) continue;
                cov[i] = (byte) sa;
                // se mezcla contra como estaba antes del trazo: repasar no oscurece de mas
                px[i] = Project.over(pxBackup[i], paintColor, sa);
                painted++;
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Goma: baja la transparencia de la capa. Con seleccion, solo dentro de lo azul. */
    private void stampErase(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        int[] px = strokeLayer.px();
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                int i = row + x;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (a <= 0f) continue;
                int orig = pxBackup[i] >>> 24;
                int want = (int) (orig * (1f - a));
                int cur = px[i] >>> 24;
                if (want < cur) px[i] = (want << 24) | (px[i] & 0x00FFFFFF);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    // ---- borrar fondo por color ----

    private void stampBgErase(float cx, float cy) {
        Layer t = strokeLayer;
        if (t == null) return;
        int w = project.w, h = project.h;
        int cxi = (int) cx, cyi = (int) cy;
        if (!bgRefValid) {
            if (cxi < 0 || cyi < 0 || cxi >= w || cyi >= h || !sampleBgRef(cxi, cyi)) return;
            bgRefValid = true;
        }
        if (!bgOnce && cxi >= 0 && cyi >= 0 && cxi < w && cyi < h && (pxBackup[cyi * w + cxi] >>> 24) > 32)
            bgRef = pxBackup[cyi * w + cxi];
        Rect r = disk(cx, cy);
        if (r == null) return;
        int bw = r.width(), bh = r.height();
        if (bgLimit == 1) {
            for (int y = r.top; y < r.bottom; y++) {
                for (int x = r.left; x < r.right; x++) {
                    float f = falloff(x, y, cx, cy);
                    if (f > 0f) applyBg(t, y * w + x, f);
                }
            }
        } else {
            if (cxi < r.left || cyi < r.top || cxi >= r.right || cyi >= r.bottom) return;
            if (colorAmount(cyi * w + cxi) <= 0f) return;
            boolean[] seen = new boolean[bw * bh];
            int[] st = new int[bw * bh];
            int sp = 0;
            int start = (cyi - r.top) * bw + (cxi - r.left);
            st[sp++] = start;
            seen[start] = true;
            while (sp > 0) {
                int li = st[--sp];
                int ly = li / bw, lx = li - ly * bw;
                int x = r.left + lx, y = r.top + ly, i = y * w + x;
                float f = falloff(x, y, cx, cy);
                if (f <= 0f) continue;
                applyBg(t, i, f);
                if (bgLimit == 2 && gradient != null && (gradient[i] & 0xFF) > 70) continue;
                if (lx > 0) sp = pushBg(st, sp, seen, li - 1, r.left + lx - 1, y);
                if (lx < bw - 1) sp = pushBg(st, sp, seen, li + 1, r.left + lx + 1, y);
                if (ly > 0) sp = pushBg(st, sp, seen, li - bw, x, y - 1);
                if (ly < bh - 1) sp = pushBg(st, sp, seen, li + bw, x, y + 1);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    private int pushBg(int[] st, int sp, boolean[] seen, int li, int x, int y) {
        if (seen[li]) return sp;
        seen[li] = true;
        if (colorAmount(y * project.w + x) <= 0f) return sp;
        st[sp++] = li;
        return sp;
    }

    /**
     * Busca el color del fondo cerca de donde tocaste, saltando lo que ya
     * esta borrado. Sin esto, al pasar de nuevo por una zona ya borrada la
     * herramienta tomaba lo transparente como referencia y no borraba nada.
     */
    private boolean bgRefValid;

    private boolean sampleBgRef(int cx, int cy) {
        int w = project.w, h = project.h;
        int r = (int) Math.max(2, brushRadius);
        for (int rad = 0; rad <= r; rad++) {
            for (int dy = -rad; dy <= rad; dy++) {
                for (int dx = -rad; dx <= rad; dx++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != rad) continue;
                    int x = cx + dx, y = cy + dy;
                    if (x < 0 || y < 0 || x >= w || y >= h) continue;
                    int c = pxBackup[y * w + x];
                    if ((c >>> 24) > 32) {
                        bgRef = c;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Cuanto hay que borrar este pixel. No cuenta la transparencia: lo ya
     * borrado se deja pasar para poder seguir por dentro de la zona.
     */
    private float colorAmount(int i) {
        int c = pxBackup[i];
        if ((c >>> 24) == 0) return 1f;
        int d = ColorDist.dist(c | 0xFF000000, bgRef | 0xFF000000, colorMode);
        if (d <= bgTolerance) return 1f;
        int band = Math.max(1, bgSoftness);
        if (d >= bgTolerance + band) return 0f;
        return 1f - (d - bgTolerance) / (float) band;
    }

    private void applyBg(Layer t, int i, float f) {
        float amt = colorAmount(i) * f * brushOpacity;
        if (amt <= 0f) return;
        if (protectOn && ColorDist.dist(pxBackup[i], protectColor, colorMode) <= Math.max(6, tolerance / 2)) return;
        if (selectionActive) amt *= (project.selection[i] & 0xFF) / 255f;
        int orig = pxBackup[i] >>> 24;
        int want = (int) (orig * (1f - amt));
        int cur = t.px()[i] >>> 24;
        if (want < cur) t.px()[i] = (want << 24) | (t.px()[i] & 0x00FFFFFF);
    }

    /** Quita los puntitos de fondo que quedan sueltos entre lo ya borrado. */
    private void despeckle(Rect r) {
        int w = project.w, h = project.h;
        int[] px = strokeLayer.px();
        int limit = bgTolerance * 2;
        ArrayList<Integer> kill = new ArrayList<Integer>();
        for (int y = Math.max(1, r.top); y < Math.min(h - 1, r.bottom); y++) {
            for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++) {
                int i = y * w + x;
                int a = px[i] >>> 24;
                if (a == 0) continue;
                if (ColorDist.dist(px[i] | 0xFF000000, bgRef | 0xFF000000, colorMode) > limit) continue;
                int empty = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        if ((px[i + dy * w + dx] >>> 24) < 40) empty++;
                    }
                }
                if (empty >= 5) kill.add(i);
            }
        }
        for (int i : kill) px[i] = px[i] & 0x00FFFFFF;
        if (!kill.isEmpty()) updateDisplayRegion(r);
    }

    /** Un toque borra todo el fondo pegado de ese color, como el balde de goma de Ibis. */
    private void runBgBucket(final int sx, final int sy) {
        final Layer t = needLayer();
        if (t == null) return;
        if (!fillBackup(t)) return;
        if (!sampleBgRef(sx, sy)) {
            // tocaste lo ya borrado: no se hace nada
            return;
        }
        final boolean useSel = project.hasSelection();
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.contiguous(t.px(), project.w, project.h, scratch,
                        useBarrier ? project.barrier : null, sx, sy, bgTolerance, bgSoftness, colorMode);
                if (lastFillRect != null && expansion != 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(Math.abs(expansion)) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                Rect r = lastFillRect;
                if (r == null) {
                    msg("No encontre fondo parecido ahi. Sube la tolerancia");
                    return;
                }
                undo.setLabel("Borrar fondo");
                undo.recordLayer(t, r);
                for (int y = r.top; y < r.bottom; y++) {
                    int off = y * project.w;
                    for (int x = r.left; x < r.right; x++) {
                        int i = off + x;
                        int a = scratch[i] & 0xFF;
                        if (a == 0) continue;
                        float f = a / 255f;
                        if (useSel) f *= (project.selection[i] & 0xFF) / 255f;
                        int cur = t.px()[i] >>> 24;
                        int want = (int) (cur * (1f - f));
                        if (want < cur) t.px()[i] = (want << 24) | (t.px()[i] & 0x00FFFFFF);
                    }
                }
                strokeLayer = t;
                despeckle(r);
                pixelsChanged(r);
                showHud("Fondo borrado");
            }
        });
    }

    private void ensureGradient(int[] px) {
        int w = project.w, h = project.h;
        gradient = new byte[w * h];
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                int gx = LineRepair.lum(px[i - w + 1]) + 2 * LineRepair.lum(px[i + 1]) + LineRepair.lum(px[i + w + 1])
                        - LineRepair.lum(px[i - w - 1]) - 2 * LineRepair.lum(px[i - 1]) - LineRepair.lum(px[i + w - 1]);
                int gy = LineRepair.lum(px[i + w - 1]) + 2 * LineRepair.lum(px[i + w]) + LineRepair.lum(px[i + w + 1])
                        - LineRepair.lum(px[i - w - 1]) - 2 * LineRepair.lum(px[i - w]) - LineRepair.lum(px[i - w + 1]);
                int m = (Math.abs(gx) + Math.abs(gy)) >> 2;
                gradient[i] = (byte) (m > 255 ? 255 : m);
            }
        }
    }

    // ---- clonar y corrector ----

    private int cloneSource(int x, int y) {
        float dx = x - cloneDestX, dy = y - cloneDestY;
        if (cloneMirror) dx = -dx;
        if (cloneAngle != 0f) {
            double a = Math.toRadians(cloneAngle);
            float c = (float) Math.cos(a), s = (float) Math.sin(a);
            float rx = dx * c - dy * s, ry = dx * s + dy * c;
            dx = rx;
            dy = ry;
        }
        int sx = Math.round(cloneSrcX + dx), sy = Math.round(cloneSrcY + dy);
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return -1;
        return sy * project.w + sx;
    }

    private void stampClone(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        int[] px = strokeLayer.px();
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                if (a <= 0f) continue;
                int src = cloneSource(x, y);
                if (src < 0) continue;
                int i = y * project.w + x;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                int ca = (int) (a * 255f);
                if (ca <= (cov[i] & 0xFF)) continue;
                cov[i] = (byte) ca;
                px[i] = mix(pxBackup[i], pxBackup[src], a);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Mezcla dos pixeles con alfa incluido. */
    private static int mix(int a, int b, float t) {
        int it = (int) (t * 256f);
        if (it <= 0) return a;
        if (it >= 256) return b;
        int aa = (((b >>> 24) * it) + ((a >>> 24) * (256 - it))) >> 8;
        int r = ((((b >> 16) & 0xFF) * it) + (((a >> 16) & 0xFF) * (256 - it))) >> 8;
        int g = ((((b >> 8) & 0xFF) * it) + (((a >> 8) & 0xFF) * (256 - it))) >> 8;
        int bl = (((b & 0xFF) * it) + ((a & 0xFF) * (256 - it))) >> 8;
        return (aa << 24) | (r << 16) | (g << 8) | bl;
    }

    private void finishHeal(final Rect r) {
        final Layer t = strokeLayer;
        final int left = r.left, top = r.top, right = r.right, bottom = r.bottom;
        final int rw = right - left, rh = bottom - top;
        final boolean[] region = new boolean[rw * rh];
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                int i = (top + y) * project.w + left + x;
                region[y * rw + x] = t.px()[i] != pxBackup[i];
            }
        }
        undo.setLabel("Corrector");
        undo.recordLayerFromBackup(t, r, pxBackup);
        final int[] orig = pxBackup.clone();
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                Membrane.heal(t.px(), orig, orig, project.w, project.h, region, left, top, right, bottom,
                        new Membrane.SourceMap() {
                            @Override
                            public int map(int x, int y) {
                                return cloneSource(x, y);
                            }
                        });
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                pixelsChanged(r);
            }
        });
    }

    public void resetCloneSource() {
        cloneSrcSet = false;
        invalidate();
        msg("Toca de donde quieres copiar");
    }

    // ---- lazo, tijeras, magnetico ----

    private void fillPathIntoSelection(Path closed, String label) {
        RectF b = new RectF();
        closed.computeBounds(b, true);
        Rect region = new Rect((int) Math.floor(b.left), (int) Math.floor(b.top),
                (int) Math.ceil(b.right) + 1, (int) Math.ceil(b.bottom) + 1);
        clamp(region);
        if (region.isEmpty()) {
            invalidate();
            return;
        }
        undo.setLabel(label);
        undo.recordSelection(region);
        int rw = region.width(), rh = region.height();
        Bitmap tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        c.translate(-region.left, -region.top);
        c.drawPath(closed, pt);
        int[] row = new int[rw];
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (region.top + y) * project.w + region.left;
            for (int x = 0; x < rw; x++) {
                int a = row[x] >>> 24;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        paintOverlay(region);
        invalidate();
        changed();
    }

    private void setAnchorAsync(final int x, final int y) {
        setBusy(true);
        final int[] ref = project.ref();
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (wire == null) wire = new LiveWire(ref, project.w, project.h);
                wire.setAnchor(x, y, 320);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                invalidate();
            }
        });
    }

    private void appendLive() {
        if (livePath == null || livePath.length < 2) return;
        for (int i = livePath.length - 1; i >= 0; i -= 2) {
            int y = livePath[i] / project.w, x = livePath[i] - y * project.w;
            wirePath.lineTo(x, y);
        }
        livePath = null;
    }

    private void commitWire() {
        if (livePath == null || livePath.length < 2) return;
        int last = livePath[0];
        appendLive();
        int ly = last / project.w, lx = last - ly * project.w;
        if (firstAnchor >= 0) {
            int fy = firstAnchor / project.w, fx = firstAnchor - fy * project.w;
            if (Math.hypot(lx - fx, ly - fy) < 24f) {
                scissorsClose();
                return;
            }
        }
        setAnchorAsync(lx, ly);
        invalidate();
    }

    public void scissorsClose() {
        if (project == null || !wireStarted) {
            msg("Primero traza el contorno con las tijeras");
            return;
        }
        Path closed = new Path(wirePath);
        closed.close();
        scissorsReset();
        fillPathIntoSelection(closed, "Tijeras");
    }

    public void scissorsReset() {
        wirePath.reset();
        livePath = null;
        firstAnchor = -1;
        wireStarted = false;
        invalidate();
    }

    // ---- mover capa o lo seleccionado ----

    private void startMove(float ix, float iy) {
        Layer t = needLayer();
        if (t == null) return;
        try {
            moveBackup = t.px().clone();
        } catch (OutOfMemoryError e) {
            moveBackup = null;
            if (undo != null) undo.trimTo(0.3f);
            System.gc();
            try {
                moveBackup = t.px().clone();
            } catch (OutOfMemoryError e2) {
                msg("Ya no alcanza la memoria para mover. Combina o borra alguna capa.");
                return;
            }
        }
        selectionActive = project.hasSelection();
        moveSelBackup = selectionActive ? project.selection.clone() : null;
        moveFromX = ix;
        moveFromY = iy;
        moveDx = moveDy = 0;
        drawing = true;
        lastMoveApply = 0;
    }

    /** Mueve la capa entera, o solo lo seleccionado si hay algo azul. */
    private void applyMove(boolean fin) {
        Layer t = target();
        if (t == null || moveBackup == null) return;
        int w = project.w, h = project.h;
        int[] px = t.px();
        int dx = moveDx, dy = moveDy;
        if (moveSelBackup == null) {
            Arrays.fill(px, 0);
            for (int y = 0; y < h; y++) {
                int ty = y + dy;
                if (ty < 0 || ty >= h) continue;
                int x0 = Math.max(0, -dx), x1 = Math.min(w, w - dx);
                if (x0 >= x1) continue;
                System.arraycopy(moveBackup, y * w + x0, px, ty * w + x0 + dx, x1 - x0);
            }
        } else {
            // lo de afuera queda; lo seleccionado se levanta y se pone en su nuevo lugar
            for (int i = 0; i < px.length; i++) {
                int s = moveSelBackup[i] & 0xFF;
                int c = moveBackup[i];
                int a = ((c >>> 24) * (255 - s)) / 255;
                px[i] = (a << 24) | (c & 0x00FFFFFF);
            }
            Arrays.fill(project.selection, (byte) 0);
            for (int y = 0; y < h; y++) {
                int ty = y + dy;
                if (ty < 0 || ty >= h) continue;
                for (int x = 0; x < w; x++) {
                    int tx = x + dx;
                    if (tx < 0 || tx >= w) continue;
                    int i = y * w + x;
                    int s = moveSelBackup[i] & 0xFF;
                    if (s == 0) continue;
                    int c = moveBackup[i];
                    int a = ((c >>> 24) * s) / 255;
                    int j = ty * w + tx;
                    if (a > 0) px[j] = Project.over(px[j], c, a);
                    project.selection[j] = (byte) s;
                }
            }
            paintOverlay(project.fullRect());
        }
        project.markDirty();
        buildDisplay();
        invalidate();
    }

    private void finishMove() {
        if (moveBackup == null) return;
        applyMove(true);
        Layer t = target();
        if ((moveDx != 0 || moveDy != 0) && t != null) {
            undo.setLabel("Mover");
            undo.begin();
            undo.recordLayerFromBackup(t, project.fullRect(), moveBackup);
            if (moveSelBackup != null) undo.recordSelectionFromBackup(project.fullRect(), moveSelBackup);
            undo.end();
            changed();
        }
        moveBackup = null;
        moveSelBackup = null;
    }

    // ==================================================================
    // Varita, balde, gama de colores
    // ==================================================================

    private void runWand(final int sx, final int sy) {
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int[] ref = project.ref();
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = wandGlobal
                        ? FloodFill.global(ref, project.w, project.h, scratch, sx, sy, tolerance, softness, colorMode)
                        : fillWithGaps(ref, sx, sy);
                if (lastFillRect != null && expansion != 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(Math.abs(expansion)) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Varita");
                    undo.recordSelection(r);
                    mergeScratch(r);
                    paintOverlay(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    /** Varita que no se escapa por los cortes de la linea (encendida por defecto). */
    private boolean autoLines = true;
    private byte[] autoBarrier;
    private int autoBarrierVer = Integer.MIN_VALUE;
    private Project autoBarrierOwner;

    public void setAutoLines(boolean on) {
        autoLines = on;
    }

    public boolean isAutoLines() {
        return autoLines;
    }

    private byte[] autoBarrier(int[] ref) {
        Project p = project;
        if (autoBarrier == null || autoBarrierOwner != p || autoBarrierVer != p.version
                || autoBarrier.length != p.w * p.h) {
            int ver = p.version;
            autoBarrier = null;
            autoBarrier = AutoLines.build(ref, p.w, p.h);
            autoBarrierVer = ver;
            autoBarrierOwner = p;
        }
        return autoBarrier;
    }

    /**
     * Relleno con "bola atrapada": la linea se engorda para tapar sus cortes,
     * se rellena, y despues lo relleno vuelve a crecer hasta tocar la linea.
     */
    private Rect fillWithGaps(int[] ref, int sx, int sy) {
        byte[] barrier = useBarrier ? project.barrier : null;
        boolean gaps = gapOn;
        int rad = gapRadius;
        if (barrier == null && autoLines) {
            barrier = autoBarrier(ref);
            gaps = true;
            rad = Math.max(3, gapRadius);
            // si tocaste justo sobre la linea, se usa la varita normal
            if (barrier[sy * project.w + sx] != 0) barrier = null;
        }
        if (!gaps || barrier == null) {
            return FloodFill.contiguous(ref, project.w, project.h, scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        if (gapBarrier == null || gapBarrier.length != barrier.length) gapBarrier = new byte[barrier.length];
        MaskOps.closeGapsBarrier(barrier, project.w, project.h, rad, gapBarrier);
        if (gapBarrier[sy * project.w + sx] != 0) {
            return FloodFill.contiguous(ref, project.w, project.h, scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        Rect r = FloodFill.contiguous(ref, project.w, project.h, scratch, gapBarrier, sx, sy, tolerance, softness, colorMode);
        if (r == null) return null;
        // vuelve a crecer solo hacia pixeles de color parecido al tocado
        int seed = ref[sy * project.w + sx];
        r.inset(-rad - 1, -rad - 1);
        clamp(r);
        growBack(ref, seed, barrier, r, rad);
        return r;
    }

    /** Crece lo relleno rad pixeles sin pasar la linea ni colores muy distintos. */
    private void growBack(int[] ref, int seed, byte[] barrier, Rect r, int rad) {
        int w = project.w;
        int lim = Math.max(tolerance * 2, 60);
        for (int pass = 0; pass < rad; pass++) {
            for (int y = Math.max(1, r.top); y < Math.min(project.h - 1, r.bottom); y++) {
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++) {
                    int i = y * w + x;
                    if (scratch[i] != 0 || barrier[i] != 0) continue;
                    int best = 0;
                    int a;
                    if ((a = scratch[i - 1] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i + 1] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i - w] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i + w] & 0xFF) > best && a != 253) best = a;
                    if (best < 200) continue;
                    if (ColorDist.dist(ref[i] | 0xFF000000, seed | 0xFF000000, colorMode) > lim) continue;
                    scratch[i] = (byte) 253;
                }
            }
            for (int y = Math.max(1, r.top); y < Math.min(project.h - 1, r.bottom); y++)
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++)
                    if (scratch[y * w + x] == (byte) 253) scratch[y * w + x] = (byte) 254;
        }
        for (int i = 0; i < scratch.length; i++) if (scratch[i] == (byte) 254) scratch[i] = (byte) 255;
    }

    private void mergeScratch(Rect r) {
        for (int y = r.top; y < r.bottom; y++) {
            int off = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                int a = scratch[off + x] & 0xFF;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
    }

    /** Relleno: pinta la zona tocada con el color, en la capa elegida. */
    private void runBucket(final int sx, final int sy) {
        final Layer t = needLayer();
        if (t == null) return;
        setBusy(true);
        ensureScratch();
        final boolean useSel = project.hasSelection();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int[] ref = project.ref();
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = fillWithGaps(ref, sx, sy);
                if (lastFillRect != null && expansion > 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(expansion) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Relleno");
                    undo.recordLayer(t, r);
                    int ca = paintColor >>> 24;
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * project.w;
                        for (int x = r.left; x < r.right; x++) {
                            int i = off + x;
                            int a = scratch[i] & 0xFF;
                            if (a == 0) continue;
                            float f = a / 255f * brushOpacity;
                            if (useSel) f *= (project.selection[i] & 0xFF) / 255f;
                            int sa = (int) (f * ca);
                            if (sa > 0) t.px()[i] = Project.over(t.px()[i], paintColor, sa);
                        }
                    }
                    pixelsChanged(r);
                }
                setBusy(false);
            }
        });
    }

    public void beginPreview() {
        if (project == null) return;
        previewBackup = project.selection.clone();
    }

    public void previewColorRange(final int color, final int tol, final boolean replace) {
        if (project == null || previewBackup == null || busy) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.globalColor(project.ref(), project.w, project.h, scratch, color, tol,
                        softness, colorMode);
            }
        }, new Runnable() {
            @Override
            public void run() {
                System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
                if (replace) project.clearSelection();
                if (lastFillRect != null) mergeScratch(lastFillRect);
                refreshOverlay(null);
                setBusy(false);
            }
        });
    }

    public void endPreview(boolean keep) {
        if (project == null || previewBackup == null) return;
        if (keep) {
            undo.setLabel("Gama de colores");
            undo.recordSelectionFromBackup(project.fullRect(), previewBackup);
        } else {
            System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
        }
        previewBackup = null;
        refreshOverlay(null);
        changed();
    }

    // ==================================================================
    // Separar partes con rayones
    // ==================================================================

    private void ensureMarkers() {
        int n = project.w * project.h;
        if (markers == null || markers.length != n) markers = new byte[n];
        if (markersOverlay == null && overlay != null) {
            markersOverlay = Bitmap.createBitmap(overlay.getWidth(), overlay.getHeight(), Bitmap.Config.ARGB_8888);
        }
    }

    private void stampMarker(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        float r2 = brushRadius * brushRadius;
        byte v = (byte) (subtract ? 0 : markerLabel);
        for (int y = r.top; y < r.bottom; y++) {
            float dy = y + 0.5f - cy;
            for (int x = r.left; x < r.right; x++) {
                float dx = x + 0.5f - cx;
                if (dx * dx + dy * dy <= r2) markers[y * project.w + x] = v;
            }
        }
        paintLabelOverlay(markersOverlay, markers, r, true);
        invalidate();
    }

    private void paintLabelOverlay(Bitmap ov, byte[] data, Rect r, boolean labels) {
        if (ov == null || data == null) return;
        int ow = ov.getWidth(), oh = ov.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int v = data[sy * project.w + sx] & 0xFF;
                if (labels) row[i] = v == 0 ? 0 : (0xB0000000 | (LABEL_COLORS[v - 1] & 0xFFFFFF));
                else row[i] = v == 0 ? 0 : (((v * 120) / 255) << 24) | 0x34C759;
            }
            ov.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    public void setMarkerLabel(int l) {
        markerLabel = Math.max(1, Math.min(LABEL_NAMES.length, l));
    }

    public int getMarkerLabel() {
        return markerLabel;
    }

    public void setGapClose(int g) {
        gapClose = Math.max(0, g);
    }

    public int getGapClose() {
        return gapClose;
    }

    public void clearMarkers() {
        if (markers != null) Arrays.fill(markers, (byte) 0);
        if (markersOverlay != null) markersOverlay.eraseColor(0);
        dropPreview();
        invalidate();
    }

    // ------------------------------------------------------------------
    // Vista previa en vivo de Separar / Quitar fondo: al soltar el dedo se
    // ve cada parte pintada de su color. Se calcula a la mitad del tamano.
    // ------------------------------------------------------------------

    private Bitmap sepPreview;
    private Rect sepPreviewRect;
    private int previewGen;
    private boolean previewBusy, previewAgain;
    private final Paint previewPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    private void dropPreview() {
        previewGen++;
        if (sepPreview != null && !sepPreview.isRecycled()) sepPreview.recycle();
        sepPreview = null;
        sepPreviewRect = null;
    }

    private boolean hasLabel(boolean bg) {
        if (markers == null) return false;
        for (byte b : markers) {
            int v = b & 0xFF;
            if (v == 0) continue;
            if (bg == (v == BG_LABEL)) return true;
        }
        return false;
    }

    /** Zona de trabajo: alrededor de las rayas, o todo si hay fondo marcado. */
    private Rect markerRegion(boolean whole) {
        int w = project.w, h = project.h;
        if (whole) return new Rect(0, 0, w, h);
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (markers[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        if (maxX < 0) return null;
        int mx = Math.max(48, (maxX - minX) / 3), my = Math.max(48, (maxY - minY) / 3);
        return new Rect(Math.max(0, minX - mx), Math.max(0, minY - my),
                Math.min(w, maxX + 1 + mx), Math.min(h, maxY + 1 + my));
    }

    private void schedulePreview() {
        if (project == null || markers == null) return;
        if (!hasLabel(false) && !hasLabel(true)) {
            dropPreview();
            invalidate();
            return;
        }
        if (previewBusy) {
            previewAgain = true;
            return;
        }
        final Rect cr = markerRegion(hasLabel(true));
        if (cr == null) return;
        final int W = project.w;
        final int cw = cr.width(), ch = cr.height();
        // paso: hasta ~1,5 millones de pixeles para que sea rapido
        int st = 1;
        while ((long) (cw / st) * (ch / st) > 1_500_000L) st++;
        final int step = st;
        final int sw = Math.max(1, cw / step), sh = Math.max(1, ch / step);
        final byte[] seeds = new byte[sw * sh];
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int v = 0;
                for (int dy = 0; dy < step && v == 0; dy++)
                    for (int dx = 0; dx < step; dx++) {
                        int sx = cr.left + x * step + dx, sy = cr.top + y * step + dy;
                        if (sx >= cr.right || sy >= cr.bottom) continue;
                        int m = markers[sy * W + sx] & 0xFF;
                        if (m != 0) {
                            v = m;
                            break;
                        }
                    }
                seeds[y * sw + x] = (byte) v;
            }
        }
        final int[] refAll = project.ref();
        final int gap = gapClose;
        final int gen = ++previewGen;
        final Bitmap[] out = new Bitmap[1];
        previewBusy = true;
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] lineAll = autoBarrier(refAll);
                int[] small = new int[sw * sh];
                byte[] lc = new byte[sw * sh];
                for (int y = 0; y < sh; y++) {
                    for (int x = 0; x < sw; x++) {
                        int sx = cr.left + x * step, sy = cr.top + y * step;
                        small[y * sw + x] = refAll[sy * W + sx];
                        byte l = 0;
                        for (int dy = 0; dy < step && l == 0; dy++)
                            for (int dx = 0; dx < step; dx++) {
                                int xx = sx + dx, yy = sy + dy;
                                if (xx >= cr.right || yy >= cr.bottom) continue;
                                if (lineAll[yy * W + xx] != 0) {
                                    l = (byte) 255;
                                    break;
                                }
                            }
                        lc[y * sw + x] = l;
                    }
                }
                byte[] lab = Watershed.run(small, sw, sh, seeds, Math.max(1, gap / step), BG_LABEL, lc);
                int[] col = new int[sw * sh];
                for (int i = 0; i < col.length; i++) {
                    int v = lab[i] & 0xFF;
                    if (v == 0) continue;
                    int c = LABEL_COLORS[Math.min(LABEL_COLORS.length, v) - 1];
                    int a = v == BG_LABEL ? 0x70 : 0x66;
                    if (v == BG_LABEL) c = 0xFF202020;
                    col[i] = (a << 24) | (c & 0x00FFFFFF);
                }
                Bitmap b = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
                b.setPixels(col, 0, sw, 0, 0, sw, sh);
                out[0] = b;
            }
        }, new Runnable() {
            @Override
            public void run() {
                previewBusy = false;
                if (out[0] != null) {
                    if (gen == previewGen && mode == MODE_MARKER) {
                        if (sepPreview != null && !sepPreview.isRecycled()) sepPreview.recycle();
                        sepPreview = out[0];
                        sepPreviewRect = cr;
                        invalidate();
                    } else {
                        out[0].recycle();
                    }
                }
                if (previewAgain) {
                    previewAgain = false;
                    schedulePreview();
                }
            }
        });
    }

    /**
     * Quitar fondo con toques, como en ibis: lo marcado con color se queda,
     * lo marcado en gris (fondo) se borra de la capa. Todo lo que no toca
     * ninguna raya de color cuenta como fondo.
     */
    public void removeBackgroundByMarks() {
        final Layer src = needLayer();
        if (src == null) return;
        if (!hasLabel(false)) {
            msg("Toca o raya el personaje con un color, y el fondo en gris");
            return;
        }
        final int W = project.w, H = project.h;
        final byte[] seeds = markers.clone();
        final int[] refAll = project.ref();
        final int gap = gapClose;
        final byte[] keep = new byte[W * H];
        setBusy(true);
        showHud("Quitando fondo...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] lineAll = autoBarrier(refAll);
                byte[] lab = Watershed.run(refAll, W, H, seeds, gap, BG_LABEL, lineAll);
                for (int i = 0; i < keep.length; i++) {
                    int v = lab[i] & 0xFF;
                    if (v != 0 && v != BG_LABEL) keep[i] = (byte) 255;
                }
                MaskOps.feather(keep, W, H, 1);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                undo.setLabel("Quitar fondo");
                undo.recordLayer(src, project.fullRect());
                int[] dp = src.px();
                for (int i = 0; i < dp.length; i++) {
                    int k = keep[i] & 0xFF;
                    if (k == 255) continue;
                    int c = dp[i];
                    int a = ((c >>> 24) * k) / 255;
                    dp[i] = (a << 24) | (c & 0x00FFFFFF);
                }
                clearMarkers();
                project.markDirty();
                refreshDisplay();
                changed();
                showHud("Fondo quitado");
            }
        });
    }

    private byte[] lastLabels;

    /** Cada parte rayada sale en su propia capa, cortada de la capa elegida. */
    public void separateParts() {
        final Layer src = needLayer();
        if (src == null) return;
        boolean any = false;
        if (markers != null) {
            for (byte b : markers) {
                int v = b & 0xFF;
                if (v != 0 && v != BG_LABEL) {
                    any = true;
                    break;
                }
            }
        }
        if (!any) {
            msg("Raya al menos una parte con color, y el fondo en gris");
            return;
        }
        // solo se trabaja alrededor de las rayas: mucho mas rapido y sin congelarse
        int w = project.w, h = project.h;
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (markers[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        int mx = Math.max(48, (maxX - minX) / 3), my = Math.max(48, (maxY - minY) / 3);
        final Rect cr = new Rect(Math.max(0, minX - mx), Math.max(0, minY - my),
                Math.min(w, maxX + 1 + mx), Math.min(h, maxY + 1 + my));
        setBusy(true);
        showHud("Separando...");
        final int cw = cr.width(), ch = cr.height();
        final byte[] seeds = new byte[cw * ch];
        for (int y = 0; y < ch; y++) System.arraycopy(markers, (cr.top + y) * w + cr.left, seeds, y * cw, cw);
        final int gap = gapClose;
        final ArrayList<Layer> made = new ArrayList<Layer>();
        final byte[] cutMask = new byte[cw * ch];
        final int[] refAll = project.ref();
        final int[] sp = src.px();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int W = project.w;
                int[] crop = new int[cw * ch];
                for (int y = 0; y < ch; y++) System.arraycopy(refAll, (cr.top + y) * W + cr.left, crop, y * cw, cw);
                byte[] lineAll = autoBarrier(refAll);
                byte[] lc = new byte[cw * ch];
                for (int y = 0; y < ch; y++) System.arraycopy(lineAll, (cr.top + y) * W + cr.left, lc, y * cw, cw);
                byte[] out = Watershed.run(crop, cw, ch, seeds, gap, BG_LABEL, lc);
                crop = null;
                boolean[] used = new boolean[256];
                for (byte b : seeds) used[b & 0xFF] = true;
                int n = cw * ch;
                for (int lab = 1; lab < BG_LABEL; lab++) {
                    if (!used[lab]) continue;
                    byte[] m = new byte[n];
                    boolean hit = false;
                    for (int i = 0; i < n; i++) {
                        if ((out[i] & 0xFF) == lab) {
                            m[i] = (byte) 255;
                            hit = true;
                        }
                    }
                    if (!hit) continue;
                    MaskOps.feather(m, cw, ch, 1);
                    int[] px = new int[n];
                    for (int y = 0; y < ch; y++) {
                        for (int x = 0; x < cw; x++) {
                            int i = y * cw + x;
                            int mv = m[i] & 0xFF;
                            if (mv == 0) continue;
                            int c = sp[(cr.top + y) * W + cr.left + x];
                            int a = ((c >>> 24) * mv) / 255;
                            if (a != 0) px[i] = (a << 24) | (c & 0x00FFFFFF);
                            if (mv > (cutMask[i] & 0xFF)) cutMask[i] = (byte) mv;
                        }
                    }
                    String nm = lab - 1 < LABEL_NAMES.length ? LABEL_NAMES[lab - 1] : "parte_" + lab;
                    made.add(Layer.fromCrop(nm, cr.left, cr.top, cw, ch, project.w, project.h, px));
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (made.isEmpty()) {
                    msg("No salio ninguna parte. Raya dentro de cada parte y el fondo en gris");
                    return;
                }
                // las partes se sacan de la capa original, que sigue visible con el resto
                undo.setLabel("Separar");
                undo.begin();
                undo.recordStruct();
                undo.recordLayer(src, cr);
                undo.end();
                int[] dp = src.px();
                int W = project.w;
                for (int y = 0; y < ch; y++) {
                    for (int x = 0; x < cw; x++) {
                        int mv = cutMask[y * cw + x] & 0xFF;
                        if (mv == 0) continue;
                        int i = (cr.top + y) * W + cr.left + x;
                        int c = dp[i];
                        int a = ((c >>> 24) * (255 - mv)) / 255;
                        dp[i] = (a << 24) | (c & 0x00FFFFFF);
                    }
                }
                int at = project.layers.indexOf(src) + 1;
                for (Layer l : made) project.layers.add(at++, l);
                project.active = at - 1;
                if (markers != null) java.util.Arrays.fill(markers, (byte) 0);
                if (markersOverlay != null) markersOverlay.eraseColor(0);
                dropPreview();
                project.markDirty();
                layersChanged();
                showHud(made.size() + (made.size() == 1 ? " parte separada" : " partes separadas")
                        + ". El resto sigue en la capa original");
            }
        });
    }

    // ==================================================================
    // Rehacer lo que queda detras (dentro de la seleccion)
    // ==================================================================

    /** Lo que hay que rehacer es lo azul, un poco agrandado. */
    private byte[] holeMask() {
        if (project == null || !project.hasSelection()) return null;
        byte[] m = new byte[project.w * project.h];
        for (int i = 0; i < m.length; i++) m[i] = (byte) ((project.selection[i] & 0xFF) > 64 ? 255 : 0);
        MaskOps.dilate(m, project.w, project.h, 2);
        return m;
    }

    private boolean needHole() {
        if (project.hasSelection()) return true;
        msg("Primero marca en azul lo que hay que rehacer (con la varita o el pincel)");
        return false;
    }

    /** Tapar hueco rapido: lo azul toma el color de alrededor. */
    public void fillHoleInSelection() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final Rect b = project.selectionBounds();
        final Rect area = new Rect(b);
        area.inset(-27, -27);
        clamp(area);
        undo.setLabel("Tapar hueco");
        undo.recordLayer(t, area);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                HoleFill.fill(t.px(), project.w, project.h, project.selection, 3);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                pixelsChanged(area);
                showHud("Hueco tapado");
            }
        });
    }

    private void runZoneFill(final int x, final int y) {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        undo.setLabel("Zona");
        undo.recordLayer(t, hb);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = ZoneFill.fill(t.px(), project.w, project.h, hole, repairLines, x, y);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect == null) msg("Toca dentro de lo azul");
                else pixelsChanged(lastFillRect);
            }
        });
    }

    private void runToneFill(final int x, final int y) {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        undo.setLabel("Trama");
        undo.recordLayer(t, hb);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = ToneFill.fill(t.px(), project.w, project.h, hole, x, y);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect == null) msg("Toca afuera de lo azul, sobre la trama que quieres seguir");
                else {
                    pixelsChanged(lastFillRect);
                    showHud("Trama continuada");
                }
            }
        });
    }

    private void ensureRepairLines() {
        int n = project.w * project.h;
        if (repairLines == null || repairLines.length != n) repairLines = new byte[n];
    }

    private void finishLine() {
        Layer t = needLayer();
        if (t == null || linePts.size() < 2) {
            linePts.clear();
            invalidate();
            return;
        }
        byte[] hole = holeMask();
        float[] a = linePts.get(0), b = linePts.get(linePts.size() - 1);
        float[] a2 = linePts.get(Math.min(linePts.size() - 1, 3)), b2 = linePts.get(Math.max(0, linePts.size() - 4));
        LineRepair.End ea = LineRepair.snap(t.px(), project.w, project.h, hole, a[0], a[1], a2[0] - a[0], a2[1] - a[1], 28);
        LineRepair.End eb = LineRepair.snap(t.px(), project.w, project.h, hole, b[0], b[1], b[0] - b2[0], b[1] - b2[1], 28);
        float[] xy = new float[linePts.size() * 2];
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -1, maxY = -1;
        for (int i = 0; i < linePts.size(); i++) {
            float[] q = linePts.get(i);
            xy[i * 2] = q[0];
            xy[i * 2 + 1] = q[1];
            minX = Math.min(minX, q[0]);
            minY = Math.min(minY, q[1]);
            maxX = Math.max(maxX, q[0]);
            maxY = Math.max(maxY, q[1]);
        }
        Rect guard = new Rect((int) Math.min(minX, Math.min(ea.x, eb.x)) - 40, (int) Math.min(minY, Math.min(ea.y, eb.y)) - 40,
                (int) Math.max(maxX, Math.max(ea.x, eb.x)) + 40, (int) Math.max(maxY, Math.max(ea.y, eb.y)) + 40);
        clamp(guard);
        linePts.clear();
        ensureRepairLines();
        undo.setLabel("Linea");
        undo.recordLayer(t, guard);
        Rect r = LineRepair.drawCurve(t.px(), project.w, project.h, repairLines, ea, eb, xy);
        if (r != null) pixelsChanged(r);
        showHud(ea.snapped && eb.snapped ? "Linea unida" : "Linea dibujada");
    }

    public void autoJoinLines() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        ensureRepairLines();
        final Rect guard = HoleFill.bounds(hole, project.w, project.h);
        if (guard == null) return;
        guard.inset(-12, -12);
        clamp(guard);
        undo.setLabel("Unir lineas");
        undo.recordLayer(t, guard);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = LineRepair.autoJoin(t.px(), project.w, project.h, hole, repairLines);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    pixelsChanged(lastFillRect);
                    showHud("Lineas unidas");
                } else {
                    showHud("No encontre lineas para unir: trazalas con el dedo");
                }
            }
        });
    }

    private void ensurePatchSource() {
        int n = project.w * project.h;
        if (patchSource == null || patchSource.length != n) patchSource = new byte[n];
        if (patchOverlay == null && overlay != null) {
            patchOverlay = Bitmap.createBitmap(overlay.getWidth(), overlay.getHeight(), Bitmap.Config.ARGB_8888);
        }
    }

    private void stampPatchSource(float cx, float cy) {
        Rect r = MaskOps.stamp(patchSource, project.w, project.h, cx, cy, brushRadius, 1f, subtract, 1f);
        if (r == null) return;
        paintLabelOverlay(patchOverlay, patchSource, r, false);
        invalidate();
    }

    public void clearPatchSource() {
        if (patchSource != null) Arrays.fill(patchSource, (byte) 0);
        if (patchOverlay != null) patchOverlay.eraseColor(0);
        invalidate();
    }

    public void runPatchFill() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        boolean anySrc = false;
        if (patchSource != null) for (byte b : patchSource) if (b != 0) {
            anySrc = true;
            break;
        }
        final byte[] src = anySrc ? patchSource : null;
        Rect guard = HoleFill.bounds(hole, project.w, project.h);
        if (guard == null) return;
        guard.inset(-50, -50);
        if (src != null) {
            Rect sb = HoleFill.bounds(src, project.w, project.h);
            if (sb != null) guard.union(sb);
        }
        clamp(guard);
        undo.setLabel("Copiar zona");
        undo.recordLayer(t, guard);
        setBusy(true);
        showHud("Rellenando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = PatchFill.fill(t.px(), project.w, project.h, hole, src);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    pixelsChanged(lastFillRect);
                    showHud("Relleno listo");
                } else {
                    msg("Pinta en verde una zona mas grande de donde copiar");
                }
            }
        });
    }

    // ==================================================================
    // Capas
    // ==================================================================

    public void layersChanged() {
        project.markDirty();
        wire = null;
        refreshDisplay();
        changed();
    }

    public void setActive(int i) {
        if (project == null) return;
        project.active = i;
        // empaca la anterior ya, asi al pintar en la nueva hay memoria
        handler.removeCallbacks(compactRunnable);
        compactRunnable.run();
        changed();
    }

    public void addEmptyLayer() {
        undo.setLabel("Capa nueva");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        project.layers.add(Math.min(at, project.layers.size()),
                new Layer(uniqueName("capa"), project.w, project.h));
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
    }

    /** Una imagen de afuera como capa nueva, centrada y ajustada al lienzo. */
    public void addImageLayer(Bitmap img) {
        if (!ensureMemory((long) project.w * project.h * 8)) return;
        int[] px = new int[project.w * project.h];
        float s = Math.min((float) project.w / img.getWidth(), (float) project.h / img.getHeight());
        int tw = Math.max(1, Math.round(img.getWidth() * s)), th = Math.max(1, Math.round(img.getHeight() * s));
        Bitmap sc = Bitmap.createScaledBitmap(img, tw, th, true);
        int ox = (project.w - tw) / 2, oy = (project.h - th) / 2;
        int[] row = new int[tw];
        for (int y = 0; y < th; y++) {
            sc.getPixels(row, 0, tw, 0, y, tw, 1);
            System.arraycopy(row, 0, px, (oy + y) * project.w + ox, tw);
        }
        if (sc != img) sc.recycle();
        undo.setLabel("Agregar imagen");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        Layer nl = new Layer(uniqueName("imagen"), px);
        nl.pack(project.w, project.h);
        project.layers.add(Math.min(at, project.layers.size()), nl);
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
    }

    public void duplicateActive() {
        Layer a = target();
        if (a == null) {
            msg("Toca una capa para duplicarla");
            return;
        }
        Layer copy;
        try {
            copy = a.copy(uniqueName(a.name), project.w, project.h);
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para duplicar. Combina o borra alguna capa.");
            return;
        }
        undo.setLabel("Duplicar");
        undo.recordStruct();
        project.layers.add(project.active + 1, copy);
        project.active++;
        layersChanged();
    }

    /** Lo seleccionado de la capa elegida pasa a una capa nueva. Con cortar, se quita de la original. */
    public void layerFromSelection(boolean cut) {
        Layer a = target();
        if (a == null) {
            msg("Toca en Capas la capa de donde quieres sacar la parte");
            return;
        }
        if (!project.hasSelection()) {
            msg("Primero marca en azul la parte");
            return;
        }
        Rect sb = selectionBoundsAny();
        if (sb == null || sb.isEmpty()) {
            msg("Primero marca en azul la parte");
            return;
        }
        if (!ensureMemory((long) sb.width() * sb.height() * 8)) return;
        int w = project.w;
        int cw = sb.width(), ch = sb.height();
        int[] crop;
        int[] apx;
        try {
            crop = new int[cw * ch];
            apx = a.px();
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para crear la capa. Combina o borra alguna capa.");
            return;
        }
        for (int y = 0; y < ch; y++) {
            for (int x = 0; x < cw; x++) {
                int i = (sb.top + y) * w + sb.left + x;
                int s = project.selection[i] & 0xFF;
                if (s == 0) continue;
                int c = apx[i];
                int al = ((c >>> 24) * s) / 255;
                if (al > 0) crop[y * cw + x] = (al << 24) | (c & 0x00FFFFFF);
            }
        }
        undo.setLabel(cut ? "Cortar a capa" : "Copiar a capa");
        undo.begin();
        undo.recordStruct();
        if (cut) {
            undo.recordLayer(a, sb);
            for (int y = sb.top; y < sb.bottom; y++) {
                for (int x = sb.left; x < sb.right; x++) {
                    int i = y * w + x;
                    int s = project.selection[i] & 0xFF;
                    if (s == 0) continue;
                    int c = apx[i];
                    int al = ((c >>> 24) * (255 - s)) / 255;
                    apx[i] = (al << 24) | (c & 0x00FFFFFF);
                }
            }
        }
        undo.end();
        project.layers.add(project.active + 1,
                Layer.fromCrop(uniqueName("parte"), sb.left, sb.top, cw, ch, project.w, project.h, crop));
        project.active++;
        layersChanged();
        showHud(cut ? "Cortado a una capa nueva" : "Copiado a una capa nueva");
    }

    /** Rectangulo de todo lo azul, incluido lo muy suave del borde. */
    private Rect selectionBoundsAny() {
        byte[] m = project.selection;
        int w = project.w, h = project.h;
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (m[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** Combina la capa elegida con la de abajo, como en Ibis. */
    public void mergeDown() {
        Layer a = target();
        int i = project.active;
        if (a == null || i <= 0) {
            msg("No hay capa abajo para combinar");
            return;
        }
        Layer below = project.layers.get(i - 1);
        Rect ab = a.bounds(project.w, project.h);
        if (!ensureMemory((long) project.w * project.h * 4)) return;
        try {
            below.px();
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para combinar. Borra alguna capa.");
            return;
        }
        undo.setLabel("Combinar");
        undo.begin();
        undo.recordStruct();
        if (ab != null) undo.recordLayer(below, ab);
        undo.end();
        if (ab != null) {
            int[] bp = below.px(), ap = a.px();
            int w = project.w;
            for (int y = ab.top; y < ab.bottom; y++) {
                for (int x = ab.left; x < ab.right; x++) {
                    int k = y * w + x;
                    int c = ap[k];
                    int sa = ((c >>> 24) * a.opacity) / 255;
                    if (sa > 0) bp[k] = Project.over(bp[k], c, sa);
                }
            }
        }
        project.layers.remove(i);
        a.pack(project.w, project.h);
        project.active = i - 1;
        layersChanged();
    }

    public void deleteActive() {
        if (target() == null) return;
        if (project.layers.size() <= 1) {
            msg("Tiene que quedar al menos una capa");
            return;
        }
        undo.setLabel("Eliminar capa");
        undo.recordStruct();
        Layer gone = project.layers.remove(project.active);
        gone.pack(project.w, project.h);
        project.active = Math.min(project.active, project.layers.size() - 1);
        layersChanged();
    }

    public void moveActive(int delta) {
        int i = project.active, t = i + delta;
        if (i < 0 || t < 0 || t >= project.layers.size()) return;
        undo.setLabel("Ordenar capas");
        undo.recordStruct();
        Layer a = project.layers.get(i);
        project.layers.set(i, project.layers.get(t));
        project.layers.set(t, a);
        project.active = t;
        layersChanged();
    }

    public void clearActive() {
        Layer t = needLayer();
        if (t == null) return;
        undo.setLabel("Limpiar capa");
        undo.recordLayer(t, project.fullRect());
        if (project.hasSelection()) {
            for (int i = 0; i < t.px().length; i++) {
                int s = project.selection[i] & 0xFF;
                int al = ((t.px()[i] >>> 24) * (255 - s)) / 255;
                t.px()[i] = (al << 24) | (t.px()[i] & 0x00FFFFFF);
            }
        } else {
            Arrays.fill(t.px(), 0);
        }
        layersChanged();
    }

    /** Borrar area: quita de la capa lo que esta en azul. */
    public void eraseSelectionFromLayer() {
        if (!project.hasSelection()) {
            msg("No hay nada en azul");
            return;
        }
        clearActive();
    }

    /** Dejar solo esto: en la capa queda solo lo azul. */
    public void keepSelectionInLayer() {
        Layer t = needLayer();
        if (t == null || !needHole()) return;
        undo.setLabel("Dejar solo esto");
        undo.recordLayer(t, project.fullRect());
        for (int i = 0; i < t.px().length; i++) {
            int s = project.selection[i] & 0xFF;
            int al = ((t.px()[i] >>> 24) * s) / 255;
            t.px()[i] = (al << 24) | (t.px()[i] & 0x00FFFFFF);
        }
        layersChanged();
    }

    private String uniqueName(String base) {
        int n = 1;
        while (true) {
            String cand = base + "_" + n;
            boolean clash = false;
            for (Layer l : project.layers) if (l.name.equals(cand)) {
                clash = true;
                break;
            }
            if (!clash) return cand;
            n++;
        }
    }

    // ==================================================================
    // Seleccion: acciones del menu
    // ==================================================================

    public void clearSelection() {
        if (project == null) return;
        undo.setLabel("Quitar seleccion");
        undo.recordSelection(project.fullRect());
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void invertSelection() {
        if (project == null) return;
        undo.setLabel("Invertir");
        undo.recordSelection(project.fullRect());
        MaskOps.invert(project.selection);
        refreshOverlay(null);
        changed();
    }

    /** kind: 0 expandir, 1 contraer, 2 suavizar, 3 endurecer, 4 cerrar puntos, 5 zonas encerradas */
    public void edgeOp(final int kind, final int radius) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Borde");
        undo.recordSelection(project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] s = project.selection;
                switch (kind) {
                    case 0:
                        MaskOps.dilate(s, project.w, project.h, radius);
                        break;
                    case 1:
                        MaskOps.erode(s, project.w, project.h, radius);
                        break;
                    case 2:
                        MaskOps.feather(s, project.w, project.h, radius);
                        break;
                    case 4:
                        MaskOps.closeHoles(s, project.w, project.h, radius);
                        break;
                    case 5:
                        MaskOps.fillEnclosed(s, project.w, project.h, radius <= 0 ? 0 : radius * 400);
                        break;
                    default:
                        MaskOps.threshold(s, 128);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void expandSelection(final float px) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Ampliar");
        undo.recordSelection(project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                MaskOps.expandSubpixel(project.selection, project.w, project.h, px, null);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void refineEdge(final int radius, final float eps) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Refinar borde");
        undo.recordSelection(project.fullRect());
        final Rect area = project.selectionBounds();
        Task.run(new Runnable() {
            @Override
            public void run() {
                GuidedFilter.refine(project.selection, project.ref(), project.w, project.h, radius, eps, area);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void buildBarrier(final int threshold, final int closeGap) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                project.barrier = LineArt.build(project.ref(), project.w, project.h, threshold, closeGap);
                gapBarrier = null;
            }
        }, new Runnable() {
            @Override
            public void run() {
                useBarrier = true;
                setBusy(false);
                showHud("Line art listo: la varita no se escapa por las lineas");
                changed();
            }
        });
    }

    /** kind: 0 mediana, 1 posterizar, 2 niveles, 3 extraer line art. Sobre la capa elegida. */
    public void applyFilter(final int kind, final int a, final int b, final int c) {
        final Layer t = needLayer();
        if (t == null) return;
        setBusy(true);
        undo.setLabel("Filtro");
        undo.recordLayer(t, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        Filters.median3(t.px(), project.w, project.h);
                        break;
                    case 1:
                        Filters.posterize(t.px(), a);
                        break;
                    case 2:
                        Filters.levels(t.px(), a, b, c / 100f);
                        break;
                    default:
                        Filters.extractLineArt(t.px(), project.w, project.h, a, b, c);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                layersChanged();
            }
        });
    }

    public void transform(final int kind) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (kind == 0) project.rotate90(true);
                else if (kind == 1) project.rotate90(false);
                else project.flip(kind == 2);
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.clear();
                scratch = selBackup = gapBarrier = gradient = markers = patchSource = repairLines = null;
                pxBackup = null;
                if (markersOverlay != null) markersOverlay.recycle();
                if (patchOverlay != null) patchOverlay.recycle();
                markersOverlay = patchOverlay = null;
                wire = null;
                scissorsReset();
                buildDisplay();
                buildOverlay();
                fit();
                setBusy(false);
                showHud("Listo. El historial se reinicia al girar");
                changed();
            }
        });
    }

    // ==================================================================
    // Deshacer
    // ==================================================================

    public void doUndo() {
        if (undo == null) return;
        Rect r = undo.undo();
        afterRestore(r, "Deshacer");
    }

    public void doRedo() {
        if (undo == null) return;
        Rect r = undo.redo();
        afterRestore(r, "Rehacer");
    }

    private void afterRestore(Rect r, String word) {
        if (r == null) {
            showHud(word.equals("Deshacer") ? "Nada que deshacer" : "Nada que rehacer");
            return;
        }
        wire = null;
        if (undo.lastWasStruct()) refreshDisplay();
        else updateDisplayRegion(r);
        paintOverlay(r);
        invalidate();
        String l = undo.lastLabel();
        showHud(l == null || l.isEmpty() ? word : word + ": " + l);
        changed();
    }

    // ==================================================================
    // Utilidades
    // ==================================================================

    private void ensureScratch() {
        int n = project.w * project.h;
        if (scratch == null || scratch.length != n) scratch = new byte[n];
    }

    private void clamp(Rect r) {
        if (r.left < 0) r.left = 0;
        if (r.top < 0) r.top = 0;
        if (r.right > project.w) r.right = project.w;
        if (r.bottom > project.h) r.bottom = project.h;
    }

    private void setBusy(boolean b) {
        busy = b;
        if (callback != null) callback.onBusy(b);
    }

    private void changed() {
        scheduleCompact();
        if (callback != null) callback.onChanged();
    }

    // ------------------------------------------------------------------
    // Memoria: las capas que no se usan se empacan (solo su recorte).
    // ------------------------------------------------------------------

    private final Runnable compactRunnable = new Runnable() {
        @Override
        public void run() {
            if (project == null) return;
            if (busy || drawing) {
                handler.postDelayed(this, 400);
                return;
            }
            try {
                project.packInactive();
            } catch (OutOfMemoryError e) {
                // se intenta la proxima vez
            }
        }
    };

    private void scheduleCompact() {
        handler.removeCallbacks(compactRunnable);
        handler.postDelayed(compactRunnable, 150);
    }

    /** Empaca ya todo lo que no se usa y avisa si igual no alcanza la memoria. */
    private boolean ensureMemory(long bytes) {
        if (project != null && !busy) {
            try {
                project.packInactive();
            } catch (OutOfMemoryError ignored) {
            }
        }
        // solo cuenta lo que va a la memoria de Java; las capas guardadas usan la del telefono
        if (freeMemory() > bytes + (8L << 20)) return true;
        if (undo != null) undo.trimTo(0.5f);
        pxBackup = null;
        System.gc();
        if (freeMemory() > bytes + (8L << 20)) return true;
        msg("Ya no alcanza la memoria para eso. Borra alguna capa o usa una imagen mas chica.");
        return false;
    }

    private static long freeMemory() {
        Runtime rt = Runtime.getRuntime();
        return rt.maxMemory() - (rt.totalMemory() - rt.freeMemory());
    }

    /** Memoria que gasta la obra ahora, para mostrar en Capas. */
    public String memoryInfo() {
        if (project == null) return "";
        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        return (used >> 20) + " de " + (rt.maxMemory() >> 20) + " MB";
    }

    private void msg(String s) {
        if (callback != null) callback.onMessage(s);
    }

    // ---- ajustes ----

    public void setMode(int m) {
        if ((mode == MODE_SCISSORS || mode == MODE_MAGNET) && m != mode) scissorsReset();
        mode = m;
        invalidate();
    }

    public int getMode() {
        return mode;
    }

    public void setTolerance(int t) {
        tolerance = t;
    }

    public int getTolerance() {
        return tolerance;
    }

    public void setSoftness(int s) {
        softness = Math.max(0, s);
    }

    public int getSoftness() {
        return softness;
    }

    public void setColorMode(int m) {
        colorMode = m;
    }

    public int getColorMode() {
        return colorMode;
    }

    public void setExpansion(float e) {
        expansion = e;
    }

    public float getExpansion() {
        return expansion;
    }

    public void setGap(boolean on, int r) {
        gapOn = on;
        gapRadius = Math.max(1, r);
        gapBarrier = null;
    }

    public boolean isGapOn() {
        return gapOn;
    }

    public int getGapRadius() {
        return gapRadius;
    }

    public void setBrushSize(float px) {
        brushRadius = Math.max(0.5f, px / 2f);
    }

    public float getHardness() {
        return hardness;
    }

    public float getBrushSize() {
        return brushRadius * 2f;
    }

    public void setHardness(float h) {
        hardness = Math.max(0.05f, Math.min(1f, h));
    }

    public void setBrushOpacity(float v) {
        brushOpacity = Math.max(0.02f, Math.min(1f, v));
    }

    public void setColor(int c) {
        paintColor = c;
    }

    public int getColor() {
        return paintColor;
    }

    public void setWandGlobal(boolean g) {
        wandGlobal = g;
    }

    public boolean isWandGlobal() {
        return wandGlobal;
    }

    public void setUseBarrier(boolean b) {
        useBarrier = b;
    }

    public boolean isUseBarrier() {
        return useBarrier;
    }

    public void setSubtract(boolean s) {
        subtract = s;
    }

    public boolean isSubtract() {
        return subtract;
    }

    public void setSmart(boolean s) {
        smart = s;
    }

    public boolean isSmart() {
        return smart;
    }

    public void setStabilizer(float v) {
        stabilizer = Math.max(0f, Math.min(0.92f, v));
    }

    public void setAim(boolean on) {
        aimOn = on;
        invalidate();
    }

    public boolean isAim() {
        return aimOn;
    }

    public void setBgOnce(boolean b) {
        bgOnce = b;
    }

    public boolean isBgOnce() {
        return bgOnce;
    }

    public void setBgBucket(boolean b) {
        bgBucket = b;
    }

    public boolean isBgBucket() {
        return bgBucket;
    }

    public void setBgTolerance(int t) {
        bgTolerance = Math.max(0, t);
        bgSoftness = Math.max(8, t * 3 / 4);
    }

    public int getBgTolerance() {
        return bgTolerance;
    }

    public void setBgLimit(int l) {
        bgLimit = Math.max(0, Math.min(2, l));
    }

    public int getBgLimit() {
        return bgLimit;
    }

    public void setProtect(boolean on) {
        protectOn = on;
        protectColor = paintColor;
    }

    public boolean isProtect() {
        return protectOn;
    }

    public void setCloneMirror(boolean m) {
        cloneMirror = m;
    }

    public boolean isCloneMirror() {
        return cloneMirror;
    }

    public void setCloneAngle(float a) {
        cloneAngle = a;
    }

    public float getCloneAngle() {
        return cloneAngle;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (project != null && ow == 0) fit();
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelQuickTimer();
        handler.removeCallbacks(startPending);
        super.onDetachedFromWindow();
    }
}
