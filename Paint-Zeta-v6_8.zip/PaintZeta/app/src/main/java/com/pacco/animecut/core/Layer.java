package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.Arrays;

/**
 * Una capa de verdad, como en Ibis: tiene sus propios pixeles con
 * transparencia. Los pixeles van en ARGB sin premultiplicar.
 *
 * Memoria: solo la capa elegida esta "abierta" como arreglo de Java para
 * pintar rapido. Las demas se guardan "empacadas": solo el rectangulo con
 * dibujo, dentro de un Bitmap. Desde Android 8 los Bitmap viven en la memoria
 * grande del telefono (no en la de Java, que es chica), asi que se pueden
 * tener muchas capas sin que la app se quede sin memoria.
 */
public class Layer {

    /** Recorte con contenido: rectangulo x,y,w,h dentro del lienzo pw x ph. Nunca se modifica. */
    public static final class Packed {
        public final int x, y, w, h, pw, ph;
        /** null si la capa esta vacia. No premultiplicado. */
        public final Bitmap bmp;

        Packed(int x, int y, int w, int h, int pw, int ph, Bitmap bmp) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.pw = pw;
            this.ph = ph;
            this.bmp = bmp;
        }

        public boolean empty() {
            return bmp == null || w <= 0 || h <= 0;
        }

        /** Pixel suelto (lento: solo para miniaturas). */
        public int at(int sx, int sy) {
            if (empty()) return 0;
            int lx = sx - x, ly = sy - y;
            if (lx < 0 || ly < 0 || lx >= w || ly >= h) return 0;
            return bmp.getPixel(lx, ly);
        }

        /** Llena buf[0..w) con la fila sy de la imagen (sy dentro del recorte). */
        public void row(int sy, int[] buf) {
            bmp.getPixels(buf, 0, w, 0, sy - y, w, 1);
        }
    }

    public String name;
    public boolean visible = true;
    /** 0 a 255. */
    public int opacity = 255;

    private volatile int[] dense;
    private volatile Packed packed;

    public Layer(String name, int[] px) {
        this.name = name;
        this.dense = px;
    }

    /** Capa vacia que no gasta memoria hasta que se pinta. */
    public Layer(String name, int w, int h) {
        this.name = name;
        this.packed = new Packed(0, 0, 0, 0, w, h, null);
    }

    private Layer(String name, Packed p) {
        this.name = name;
        this.packed = p;
    }

    /** Capa creada desde un recorte en arreglo (copiar a capa, separar). */
    public static Layer fromCrop(String name, int x, int y, int w, int h, int pw, int ph, int[] crop) {
        if (w <= 0 || h <= 0) return new Layer(name, pw, ph);
        Bitmap b = newBitmap(w, h);
        b.setPixels(crop, 0, w, 0, 0, w, h);
        return new Layer(name, new Packed(x, y, w, h, pw, ph, b));
    }

    /** Capa creada desde un Bitmap ya recortado (al abrir obras). Debe estar sin premultiplicar. */
    public static Layer fromBitmap(String name, int x, int y, Bitmap b, int pw, int ph) {
        return new Layer(name, new Packed(x, y, b.getWidth(), b.getHeight(), pw, ph, b));
    }

    static Bitmap newBitmap(int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        b.setPremultiplied(false);
        return b;
    }

    /** Los pixeles de todo el lienzo para editar. Si estaba empacada, la abre. */
    public int[] px() {
        int[] d = dense;
        if (d != null) return d;
        synchronized (this) {
            d = dense;
            if (d != null) return d;
            Packed p = packed;
            d = new int[p.pw * p.ph];
            if (!p.empty()) p.bmp.getPixels(d, p.y * p.pw + p.x, p.pw, 0, 0, p.w, p.h);
            dense = d;
            packed = null;
            return d;
        }
    }

    /** Reemplaza todos los pixeles (girar, voltear). */
    public synchronized void setPx(int[] px) {
        dense = px;
        packed = null;
    }

    public boolean isPacked() {
        return dense == null;
    }

    /** Empaca la capa: pasa solo el rectangulo con dibujo a un Bitmap. */
    public synchronized void pack(int w, int h) {
        int[] d = dense;
        if (d == null || d.length != w * h) return;
        Packed p = crop(d, w, h);
        packed = p;
        dense = null;
    }

    private static Packed crop(int[] d, int w, int h) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w, first = -1, last = -1;
            for (int x = 0; x < w; x++) {
                if ((d[row + x] >>> 24) != 0) {
                    first = x;
                    break;
                }
            }
            if (first < 0) continue;
            for (int x = w - 1; x >= first; x--) {
                if ((d[row + x] >>> 24) != 0) {
                    last = x;
                    break;
                }
            }
            if (first < minX) minX = first;
            if (last > maxX) maxX = last;
            if (y < minY) minY = y;
            maxY = y;
        }
        if (maxX < 0) return new Packed(0, 0, 0, 0, w, h, null);
        int cw = maxX - minX + 1, ch = maxY - minY + 1;
        Bitmap b = newBitmap(cw, ch);
        b.setPixels(d, minY * w + minX, w, 0, 0, cw, ch);
        return new Packed(minX, minY, cw, ch, w, h, b);
    }

    /**
     * Foto del contenido para leer sin cambiar la capa (sirve desde otro hilo,
     * por ejemplo al guardar). Si la capa esta abierta, hace un recorte nuevo.
     */
    public Packed snapshot(int w, int h) {
        int[] d = dense;
        if (d != null && d.length == w * h) return crop(d, w, h);
        Packed p = packed;
        if (p != null) return p;
        d = dense;
        if (d != null && d.length == w * h) return crop(d, w, h);
        return new Packed(0, 0, 0, 0, w, h, null);
    }

    public int[] denseOrNull() {
        return dense;
    }

    public Packed packedOrNull() {
        return packed;
    }

    /** Lee un pixel sin abrir la capa (lento si esta empacada). */
    public int at(int x, int y, int w) {
        int[] d = dense;
        if (d != null) return d[y * w + x];
        Packed p = packed;
        if (p != null) return p.at(x, y);
        d = dense;
        return d == null ? 0 : d[y * w + x];
    }

    /** Copia el rectangulo (rx,ry,rw,rh) del lienzo a out, sin abrir la capa. */
    public void read(int rx, int ry, int rw, int rh, int[] out, int w, int h) {
        int[] d = dense;
        if (d != null && d.length == w * h) {
            for (int yy = 0; yy < rh; yy++) System.arraycopy(d, (ry + yy) * w + rx, out, yy * rw, rw);
            return;
        }
        Arrays.fill(out, 0, rw * rh, 0);
        Packed p = snapshot(w, h);
        if (p.empty()) return;
        int ix0 = Math.max(rx, p.x), iy0 = Math.max(ry, p.y);
        int ix1 = Math.min(rx + rw, p.x + p.w), iy1 = Math.min(ry + rh, p.y + p.h);
        if (ix0 >= ix1 || iy0 >= iy1) return;
        p.bmp.getPixels(out, (iy0 - ry) * rw + (ix0 - rx), rw, ix0 - p.x, iy0 - p.y, ix1 - ix0, iy1 - iy0);
    }

    /** Copia todo el lienzo a out (tamano w*h) sin abrir la capa. */
    public void copyTo(int[] out, int w, int h) {
        read(0, 0, w, h, out, w, h);
    }

    /** Rectangulo con contenido (null si esta vacia). */
    public Rect bounds(int w, int h) {
        Packed p = snapshot(w, h);
        if (p.empty()) return null;
        return new Rect(p.x, p.y, p.x + p.w, p.y + p.h);
    }

    /** Memoria de Java que ocupa ahora (la de Bitmap no cuenta aca). */
    public long javaMemory() {
        int[] d = dense;
        return d == null ? 0 : (long) d.length * 4;
    }

    /** Copia empacada: comparte el recorte, casi no gasta memoria. */
    public Layer copy(String newName, int w, int h) {
        Layer l = new Layer(newName, snapshot(w, h));
        l.visible = visible;
        l.opacity = opacity;
        return l;
    }
}
