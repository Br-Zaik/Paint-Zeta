# Paint Zeta v8 · Cambios verificados en el código

Base: v7.2. Se conservan el package, iconos Paint Zeta, y el proyecto editable.

- Capas: panel oscuro, filas más compactas, miniaturas visibles y selección azul; botones identificables **α** y **B/N**, visibilidad, opacidad, duplicar, ordenar, combinar y eliminar (motor previo conservado).
- Capa de selección arriba: miniatura de la máscara, ojo para ocultar/mostrar solo el azul, invertir y limpiar. Copiar una pieza ya **no limpia automáticamente** el azul.
- Visualización: fondo de vista elegible BLANCO / CUADROS CLAROS / CUADROS OSCUROS / GRIS, sin cambiar los PNG exportados ni los píxeles del dibujo.
- Herramientas: barra izquierda compacta; barra contextual inferior sin segunda fila fija repetida de varita. Al usar varita aparecen COPIAR A CAPA / CORTAR A CAPA / VARITA ajustes / GLOBAL / RESTAR / LÍNEAS / INVERTIR / LIMPIAR / BORDE.
- Cortar a capa: copia selección como capa y quita la zona del origen con alfa transparente, mantiene selección azul y permite Deshacer sobre el origen.
- Varita: ajuste de referencia Imagen original / Capa actual / Lienzo visible; conserva tolerancia, suavidad, expansión, detección de huecos, modos RGB/tono/Lab y global/contiguo existentes.
- Pincel y borrador: ventana contextual de estilos básicos conectados a dureza, tamaño y opacidad reales; tamaños/opacidades ajustables abajo, como antes.
- Vista de selección/capas puede ocultarse sin destruir la máscara; miniaturas previamente recortaban al contenido relevante.

## Alcance honesto
No se añadieron capas vectoriales, carpetas, modos de fusión sofisticados ni cientos de brochas. Tampoco se ha ejecutado una compilación Android dentro de este entorno: GitHub Actions debe compilarlo y la prueba táctil real corresponde al dispositivo. Se validó XML y la integridad del ZIP; una comprobación con javac local no puede resolver android.* sin el SDK.

## GitHub Actions
Mantén solamente un ZIP de proyecto en la raíz para evitar elegir una versión vieja. El workflow externo `.github/workflows/build-apk.yml` debe seguir en el repositorio. El ZIP contiene su propio ejemplo `.github/workflows/build.yml` bajo la carpeta del proyecto y no sustituye el workflow externo.
