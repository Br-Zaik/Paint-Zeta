# Paint Zeta v8.23 — Mejoras de herramientas (sin IA)

Versión 8.23 (versionCode 61). Se trabajó por etapas, midiendo antes de cambiar. Cada número de este documento sale de una prueba que se puede repetir (`sh tests/run_jvm_tests.sh full`). Resultados completos: `docs/RESULTADOS_PRUEBAS_8_23.txt`. Comparación visual: `docs/comparacion_v8_22_vs_v8_23.png`.

Importante sobre las pruebas:
- Las pruebas usan el `CanvasView` real de la app dentro de un Android **simulado** en la computadora (`tests/androidsim`). No son un teléfono.
- Los tiempos son de la CPU del servidor de pruebas. Un teléfono económico puede ser de 3 a 8 veces más lento.
- No se probó en un teléfono real ni se generó el APK (ver "Compilación").

## Lo que NO se tocó

- **Especial**: su motor (`LiquifyField`, `LiquifyFalloff`, `LiquifyStroke`, `LiquifySource`, `LiquifyRaster`, `LiquifySession`) es idéntico byte a byte a v8.22, y también todos los métodos de Especial en `CanvasView` (16, comparados uno por uno). Sus pruebas siguen pasando.
- **Malla, Puntos de anclaje y Transformar**: los 45 métodos son idénticos a v8.22. Sus toques van por su propio manejador (`onTransformTouch`), que tampoco cambió.
- Sistema de capas, formato de obra (`.acut`) y exportación de capas en modo Normal.

## Etapa 1 — Difuminar

- **ERROR CONFIRMADO**: mezclaba colores sin alfa premultiplicado. Al difuminar junto a lo transparente entraba el negro de los píxeles vacíos (halo oscuro). Medido: 4169 píxeles contaminados en v8.22, 0 en v8.23.
- **ERROR CONFIRMADO**: leía la imagen desplazada medio píxel.
- Arreglo: interpolación premultiplicada (`core/PremulColor`) y coordenada corregida.
- Probado con rojo, amarillo claro y azul oscuro sobre transparente, y rojo al 40 %: 0 píxeles contaminados.

## Etapa 2 — Navegar con dos dedos

- **MEJORA NECESARIA**: el gesto se calcula desde el inicio (posición absoluta), no sumando pequeños cambios. Cada dedo se sigue por su número de puntero.
- Girar solo empieza al pasar 10° (un temblor de 3° no gira) y sin salto. Imán a 0°, 90°, 180° y 270°. Se puede apagar en el menú ("Girar con dos dedos").
- Menú: "Restablecer vista" y "Voltear vista" (espejo, solo visual: no cambia la imagen).
- Medido: punto entre los dedos desplazado 0,000 px; levantar un dedo no salta; en 10 herramientas, dos dedos no dejan trazos, puntos ni selecciones; pintar sobre el lienzo girado 90° cae en su sitio (2875 de 2875 píxeles).

## Etapa 3 — Brocha, Goma y estabilizador

- **MEJORA NECESARIA**: recorrido nuevo (`core/StrokeEngine`): estampas a distancia constante, curva Catmull-Rom centrípeta entre puntos y estabilizador que **termina el trazo donde levantaste el dedo**.
- Círculo rápido (15 eventos): v8.22 dejaba 283 píxeles fuera del anillo (forma de polígono); v8.23, 0.
- Estabilizador fuerte: v8.22 terminaba en x=446 con el dedo en 460; v8.23 en 462.
- Opacidad 50 %: el cruce queda igual que el resto (127 y 127).
- **HIPÓTESIS DESCARTADA en parte**: "los pinceles de 1 px salen dentados". Medido: variación de grosor 7,5–8,4 % en v8.22 y 6,2–7,2 % en v8.23. Mejora pequeña, no era un defecto grave.
- Goma: solo cambia el alfa (RGB intacto), borde suave, sin acumular en cruces, y sobre mechones finos de 1,5 px borra 86 de 86 en el trazo sin tocar lo de al lado.

## Etapa 4 — Relleno y coloreado de manga

- **ERROR CONFIRMADO**: el relleno aclaraba las líneas finas. Píxeles de línea aclarados con líneas de 1, 2 y 3 px: 372, 964 y 1164 en v8.22; 0 en v8.23. Franja blanca: 0. Fugas: 0.
- "Hasta la línea": avanza hasta el píxel más oscuro de la línea, sin cruzarla.
- Nuevo botón "Colorear sin tapar líneas" (barra de Relleno): el color va a una capa "Color" en modo Multiplicar, el dibujo original no cambia (0 píxeles). Deshacer y Rehacer correctos.
- Exportar: un PNG no guarda el modo Multiplicar, por eso esa capa se exporta ya mezclada (diferencia con lo que se ve: 0 niveles). Las capas en modo Normal se exportan igual que antes.
- Cerrar cortes de la línea: ya existía (automático). Ahora su tamaño se ajusta en el cuadro de Tolerancia. Medido: el nivel N cierra cortes de hasta unos 2N px (nivel 4 cierra 9 px y deja pasar 12 px).
- El relleno se calcula en segundo plano.

## Etapa 5 — Borrar fondo

- Ya usaba un relleno por líneas (scanline) de 4 vecinos: no se escapa por diagonales. No se reemplazó.
- **ERROR CONFIRMADO**: la tolerancia dejaba el filo del personaje casi opaco con el color del fondo (franja blanca en el cabello). Sobre fondo oscuro, píxeles del filo con halo claro: 758 de 1050 en v8.22, 0 en v8.23. Error medio del filo: 66,1 niveles → 0,2.
- Arreglo (en el `BackgroundEraseAlpha` existente, sin duplicar): cada píxel del filo se compara con el color sólido del personaje más cercano (o con sus colores principales si es un mechón fino) y recibe el alfa y el color correctos. En el borrado con pincel se hace en vivo, así que lo que ves con el dedo abajo es lo que queda.
- Fondo de color (naranja sobre verde): halo 50 → 0 (toque) y 82 → 0 (pincel); error medio 28,9 → 15,2.
- Protecciones medidas: personaje dañado 0 píxeles; piel clara sobre blanco con ruido tipo JPEG: 0 píxeles adelgazados; sin motas de fondo.
- Se puede apagar: casilla "Limpiar el filo" en el cuadro de Suavidad (prendida por defecto).
- Tiempos en 2000×2000 (servidor): relleno 52 ms, alfa 35 ms, limpieza del filo 41 ms, fuera del hilo de la interfaz.

## Etapa 6 — Borrosidad

- **ERROR CONFIRMADO**: dependía de la velocidad. El mismo trazo dejaba 59 % de contraste rápido y 11 % lento (4 s).
- Ahora: original del trazo + original desenfocado (premultiplicado), mezclados según la cobertura máxima × Fuerza. Medido: 55 %, 55 % y 55 % a 150 ms, 1 s y 4 s. Fuerza 25 % / 100 %: 77 % / 10 %.
- Transparencias: 0 píxeles contaminados. Deshacer exacto.
- CPU de un trazo de 1000 px: 28 / 77 / 197 ms con pincel 30 / 120 / 300 (v8.22 con trazo rápido: 16 / 50 / 251 ms). Cuesta algo más con pinceles chicos porque ahora el efecto es parejo; el desenfoque se calcula una sola vez por bloque.

## Etapa 7 — Lazo, Curva y Polilínea

- **ERROR CONFIRMADO**: "Cortar a capa" con borde suave dejaba una línea visible alrededor de la parte, aun sin moverla (420 píxeles, hasta 64 niveles). Ahora lo que queda en la capa original se calcula para que parte + resto = original exacto (0 píxeles distintos). La parte conserva su posición. Deshacer correcto.
- **ERROR CONFIRMADO (leve)**: con puntos a distancias muy distintas, la Curva hacía un gancho de 10,3 px. Ahora usa la misma curva centrípeta de la Brocha: 3,1 px (curvatura normal, sin lazos).
- Polilínea y Curva al 50 %: uniones y cruces sin oscurecer (127 en todo). Dos dedos no agregan ni mueven puntos.
- El trazado del Lazo lo dibuja Android. El simulador no puede dibujarlo, así que esa parte no se probó aquí.

## Etapa 8 — Ajustes y funciones existentes

Ya visibles, no se duplicaron: bloquear transparencia, dureza (Brocha y Goma), estabilizador, cuentagotas, expandir y contraer selección.

Se mostró lo oculto dentro de cuadros que ya existían, sin botones nuevos:
- Tamaño de "Cerrar cortes de la línea" (cuadro de Tolerancia de Relleno).
- "Limpiar el filo" (cuadro de Suavidad de Borrar fondo).

Las 3 mejoras nuevas permitidas:
- **Voltear vista** (menú).
- **Extraer líneas** (botón "Líneas" en Capas, icono propio): crea encima una capa con el papel transparente y las líneas intactas. El original no cambia. El color pintado en una capa de abajo no tapa las líneas (medido: 0 píxeles tapados). El papel queda 100 % transparente y el negro 100 % opaco. Sobre blanco se ve igual, salvo grises muy pálidos (diferencia máxima 15 niveles, quitando ruido del papel).
- **Estabilizador que completa el trazo** (Etapa 3).

## Etapa 9 — Compatibilidad y regresiones

- Obras antiguas (sin modos de capa guardados) abren con todas las capas en Normal. Formato de guardado sin cambios.
- Guardar y abrir: capas, nombres, modos, bloqueo y píxeles iguales (0 distintos).
- PNG transparente exportado: igual a la capa (0 píxeles distintos).
- Capas: nueva, duplicar, mover, bloquear transparencia, eliminar, Deshacer y Rehacer correctos.
- 7 cambios de herramienta con el dedo abajo (incluida Especial): sin errores y Deshacer deja la imagen original.
- Zoom 100 %, 200 % y 400 %: el trazo cae donde va el dedo (0 píxeles fuera).
- 37 grupos de pruebas de comportamiento + 21 comprobaciones del código: todas pasan.

## Compilación

- **Hecho**: todo el código Java de la app (45 archivos, 428 clases) compila **sin errores contra el `android.jar` oficial de Android 34**, también con la biblioteca Java de Android (detecta métodos de Java que el teléfono no tiene). Script: `tests/sdkcheck/compile_with_android_jar.sh`.
- Los 119 XML de recursos están bien formados y no hay referencias rotas.
- **No se pudo generar el APK.** Este entorno no tiene Android SDK completo ni acceso a Google Maven, así que faltan Gradle con el plugin de Android, aapt2, d8 y AndroidX. Para compilar se usaron sustitutos mínimos de las 5 clases de AndroidX que usa la app (`tests/sdkcheck/androidx_stubs`), solo para la comprobación. No van en la app.
- Falta: compilar en Android Studio y probar en un teléfono.

## Archivos

Modificados:
- `view/CanvasView.java`
- `MainActivity.java`
- `core/BackgroundEraseAlpha.java`
- `core/Defringe.java`
- `core/Exporter.java`
- `core/LineArt.java` (solo se agregó "Extraer líneas")
- `app/build.gradle` (8.23)
- `tests/run_jvm_tests.sh`
- `tests/test_regressions.py`
- simulador de pruebas (`tests/androidsim`: PNG real y gestos con varios dedos)

Nuevos:
- `core/PremulColor.java`
- `core/StrokeEngine.java`
- `core/LineFill.java`
- `res/drawable/ic_color_under.xml`
- `res/drawable/ic_lines_layer.xml`
- `tests/SimKit.java`
- `tests/ToolsSimTest.java`
- `tests/StrokeEngineTest.java`
- `tests/sdkcheck/`
- `docs/RESULTADOS_PRUEBAS_8_23.txt`
- `docs/comparacion_v8_22_vs_v8_23.png`

## Pendiente y riesgos

- Probar en un teléfono económico real: fluidez de Borrosidad con pincel grande y del relleno en imágenes muy grandes.
- Borrar fondo con fondos con degradado: la limpieza del filo supone un fondo de un solo color cerca del borde. Con degradados fuertes ayuda menos (se puede apagar).
- "Colorear sin tapar líneas" protege líneas más oscuras que la zona. Una línea del mismo tono que el relleno no se protege.
- Mejora opcional, no hecha: aceleración por GPU (OpenGL). No se agregó sin poder medirla en un teléfono.
