# Paint Zeta v8.26 — Colorear manga B/N (Multiplicar, sombras, luces, tramas y referencia de color)

Versión 8.26 (versionCode 64), hecha sobre la 8.25 Marioneta (la más reciente). Sin IA ni internet. No se quitó nada de lo anterior: balde normal, brocha, goma, lazo, capas, Especial, Transformar, Malla, Puntos y Marioneta siguen igual (todas sus pruebas pasan).

Todas las cifras de este documento salen de `sh tests/run_jvm_tests.sh`. La salida completa está en `docs/RESULTADOS_PRUEBAS_8_26.txt`. Las imágenes están en `docs/manga_antes_despues.png` y `docs/manga_detalles_pruebas.png`.

Antes de leer los resultados, hay que saber cómo se probó:
- Las pruebas usan el `CanvasView` real de la app dentro de un Android **simulado** en una computadora. **No es un teléfono.**
- Los tiempos son de una computadora. En un teléfono económico serán más lentos.
- La parte de pantallas (menús, botones, ventana de referencia) **solo se compiló**: no se pudo tocar en un teléfono.
- No se pudo generar el APK.
- El manga real usado es tu imagen del chico con chaqueta (1024x1536, tiene tramas en la chaqueta y el pelo). Va guardada en `tests/assets/manga_chaqueta.png`.

## El flujo para ti

1. Abres el manga (PNG o JPG).
2. Menú (tres puntos) > **Colorear manga (preparar capas)**.
3. La app prepara las capas, sin cambiar tu manga:
   - Tu capa pasa a llamarse **Tinta B/N** y queda **bloqueada del todo**: no se puede pintar, borrar, rellenar, mover ni deformar.
   - Sus líneas marcan los límites del balde.
   - Encima se crea **Color base** en **Multiplicar** al 100 %, y queda elegida.
   - Si vuelves a tocar «Colorear manga», no se duplica nada: se abren las opciones.
4. Eliges un color: el selector de siempre, la paleta de la obra o la imagen de referencia.
5. Tocas una zona con el **balde**. Primero ves una **vista previa** (color transparente con borde punteado), con tres botones:
   - ✓ **Aceptar**: pinta.
   - **Parecidas**: sugiere otras zonas iguales, como el cuello o la otra mano.
   - ✕ **Cancelar**: no se pinta nada.
   - Si tocas otra zona, se suma a la vista previa. Si tocas una zona ya sumada, se quita.
6. Donde el contorno está abierto, usas el **Lazo**. Al soltar, la app pregunta: Rellenar, Proteger, Crear capa o Nada.
7. Sombras y luces: en la barra de la Brocha aparecen dos botones (o están en Menú > Colorear manga):
   - **Sombra rápida**: capa recortada, Multiplicar 40 %.
   - **Luz rápida**: capa recortada, Pantalla 60 %.
8. **Cambiar color** (tono, saturación, luz) de una capa, sin repintar. Si no te gusta, se vuelve a 0.
9. Guardas la obra. Para sacar la imagen final: Exportar > **Imagen completa** (un PNG con todo junto, igual que en pantalla).

La app **no reconoce** qué es piel, ropa u ojos. Tú eliges la zona y la app la rellena siguiendo las líneas.

## Paso 0: Multiplicar revisado (antes de todo)

- Toda la mezcla de capas en la app es **Java píxel por píxel**: no usa `PorterDuff` ni `BlendMode` de Android. Por eso **no depende de la versión de Android** (8 a 9 o 10+).
  - Esto aplica a la pantalla, el zoom nítido, las miniaturas, la galería, la exportación y el combinar capas.
  - El riesgo del informe (Multiplicar que deja huecos transparentes) no aplica.
- Prueba numérica (pide error ≤ 1):
  - blanco × (200,100,50) = (200,100,50)
  - negro × color = negro
  - gris 128 × (200,100,50) = (100,50,25)
  - color con alfa 0 = el fondo exacto, sin hueco
  - opacidad 50 % = (255,127,127)
  - alfa 128: error 1
- Lo mismo en el CanvasView real:
  - diferencia pantalla vs cálculo = 0
  - miniatura = 0
  - PNG «Imagen completa» = 0
  - PNG por capa (Multiplicar ya mezclado) + tinta = 0
- **Corregido**: al exportar una capa en Multiplicar, lo de abajo se juntaba sin respetar el recorte de las capas de abajo. Ahora usa la misma regla que la pantalla.

## Balde para manga (cómo funciona, sin IA)

El balde normal busca colores parecidos. El balde manga busca **líneas**:

- Todo lo que no es tinta (papel, grises, antialias, puntitos de trama) es la misma zona hasta chocar con una línea.
- La chaqueta con trama y brillos se rellena de un toque. Como el color va en Multiplicar, la trama y los grises se siguen viendo.

Controles en la barra del balde (botones chicos):
- **Trama** (toca para cambiar):
  - No.
  - **Puntos** (de fábrica): los puntitos sueltos no cortan la zona.
  - Densa (experimental, ver límites).
- **Cerrar huecos**: No, Pequeño, **Medio** (de fábrica) o Grande. Se cambia tocando.
- **Color bajo la línea**: 2 px de fábrica. El color entra un poco dentro de la tinta, solo hasta su centro, para que no quede borde blanco al hacer zoom.
- **Vista previa**: SÍ o NO.
- **Zonas protegidas**: el escudo.
- **Más opciones**: el libro, abre el menú Colorear manga.

Otros detalles:
- Para el JPEG escaneado no se cambia nada del original: el mapa de tinta se calcula aparte, en memoria, y se quitan las motas de 1 a 2 px. Tu manga nunca se modifica.
- **Zonas protegidas («No colorear»)**:
  - Marcas el globo o las rayas de velocidad con el Lazo y eliges «Proteger».
  - El balde y «Rellenar selección» no las tocan.
  - Se ven rayadas en rojo y se guardan con la obra.
- **Rellenar selección**: rellena lo azul del Lazo con el color elegido, en la capa de color.
- **Parecidas**: busca cerca zonas de tamaño y tono parecidos. No pinta: las muestra rayadas y tú quitas las que no quieras antes de Aceptar. Nunca pinta todos los blancos de la página.
- **Deshacer, Rehacer y Cancelar**:
  - Con la vista previa abierta, «Deshacer» la cancela.
  - Todo lo nuevo se deshace, incluido el preset entero.

## Sombras, luces y color

- **Sombra rápida**:
  - Crea «Sombras»: recortada al color base, en Multiplicar, al 40 %.
  - Elige la Brocha y sugiere un color: el color base mezclado con un violeta frío. Ejemplo: piel #FFDCC4 da malva #B79EA6. Se puede cambiar.
- **Luz rápida**: crea «Luces», recortada, en Pantalla, al 60 %. Sugiere el color base más claro y cálido: piel da #FFE8CD.
- **Brillo encima**: una capa Normal arriba de todo, para los blancos de los ojos que deben tapar la tinta.
- **Cambiar color**: tono (-180 a 180), saturación y luminosidad (-100 a 100).
  - No es destructivo: los píxeles no cambian y se guarda con la obra.
  - «Fijar» lo pasa a los píxeles.
  - «Solo lo azul» cambia solo la selección (eso sí cambia píxeles, y se puede deshacer).
- **Modo de mezcla «Color»** (nuevo, norma W3C): toma el tono de la capa y la luz de lo de abajo. Tiñe grises y tramas sin oscurecerlos. Los modos que ya existían no cambiaron.
- **Bloquear alfa** y **Recorte** ya existían. Ahora también se pueden deshacer (antes no).

## Imagen de referencia (ventana flotante) y paleta

Son dos cosas distintas:
- «Imagen de referencia»: solo para mirar y sacar colores. **Nunca se exporta.**
- «Agregar una imagen como capa»: sí entra en la obra.

Lo nuevo de la ventana:
- **Plegar y desplegar**: la ventana queda en una barrita.
- **Lupa**: al mantener el dedo aparece una lupa de 11x11 píxeles con una cruz. Mueves el dedo para afinar y al soltar se toma ese píxel.
- **3x3**: promedia los 9 píxeles, pero ignora los muy distintos (el negro de una línea o el ruido del JPEG). Se puede apagar.
- Tocar solo **toma la muestra**. **«Usar»** la manda a la brocha y al balde. Así no se pinta por accidente.
- **«Guardar»**: guarda la muestra con nombre (Piel, Sombra piel, Cabello, Ojos, Ropa, Luces o el que escribas).
  - Queda en la **paleta de la obra**, que se guarda con la obra.
  - Opcionalmente también va a la **paleta global**.
- **«Ajustar»**: tono, saturación, brillo y opacidad de la muestra. La imagen de referencia no cambia.
- Menú «…»:
  - Cambiar imagen.
  - Volver a encuadrar.
  - **Paleta automática**: corte por la mediana, sin casi blancos ni casi negros, ordenada por tono.
  - **Guardar copia reducida con la obra** (lado máximo 1024 px).
  - Quitar referencia: no borra la foto del teléfono.
- **Gotero**: Automático, Visible o Capa actual. En una capa Multiplicar, el automático toma de la capa, para no copiar un tono ya oscurecido y multiplicarlo dos veces.

## Resultados de las pruebas P1 a P20

Cómo leer cada resultado:
- «Simulado» = CanvasView real en un Android simulado.
- «Unitaria» = cálculo directo.
- **Ninguna prueba se hizo en un teléfono.**

- **P1 Manga real PNG (simulado)**:
  - 8 toques, cada uno con vista previa y Aceptar.
  - Zonas obtenidas:
    - cara y cuello: 127.175 px
    - mano: 117.734 px
    - manga izquierda: 61.948 px
    - solapa: 45.646 px
    - chaqueta derecha: 26.292 px
    - camisa: 68.154 px
    - cuello de la camisa: 18.732 px
    - pelo derecho: 26.198 px
  - Nada se escribió antes de Aceptar.
  - Píxeles que se aclararon: 0. El resultado es exactamente original × color (error 0).
  - Negro puro: cambio máximo de 16 niveles. Es lo que da multiplicar un gris casi negro por la piel.
  - Promedio de 132 ms por toque (computadora).
  - Quedan 2.219 píxeles claros sin color pegados al color. Casi todos son franjas blancas entre dos líneas (doble contorno, ribetes): el programa las trata como otra zona.
- **P2 El mismo manga en JPEG calidad 60 (simulado)**:
  - Las 7 primeras zonas salen casi iguales que en el PNG (diferencias de 0,2 % a 6 %).
  - **El pelo derecho se escapa al fondo**: 263.159 px en vez de 26.198. Ahí el dibujo tiene líneas abiertas. Se ve en la vista previa, se cancela y se usa el Lazo.
- **P3 Trama**:
  - En el manga real, un toque en la manga izquierda pinta:
    - sin modo trama: 10.628 px
    - con Puntos: 61.948 px (6 veces más)
  - En la solapa con trama: sin modo trama 0 px (el toque cae en un punto), con Puntos 45.646 px.
  - Con Densa la manga sube a 69.007 px (+8.499).
  - En la prueba sintética (puntos sueltos dentro de un cuadro): 1 toque, 100 % cubierto, 0 px fuera.
- **P4 Cortes de 2, 4, 8 y 12 px (unitaria)**:
  - Pequeño y Medio cierran 2 y 4 px (derrame de 0 % a 0,4 %).
  - Grande cierra también 8 y 12 px (derrame de 0,1 % a 1,8 %).
  - Un corte más ancho que el nivel elegido deja pasar el color.
- **P5 Iris (simulado)**:
  - Iris 100 % coloreado.
  - Pupila, pestañas y contorno: cambio máximo de 7 niveles.
  - Brillo blanco del ojo: 0 píxeles tocados.
- **P6 Cara, cuello y dos manos (simulado)**:
  - Sin Parecidas: 4 toques.
  - Con Parecidas: 1 toque + Parecidas + Aceptar. Salieron las 4 zonas correctas y 0 píxeles fuera de la piel. La chaqueta con trama de al lado no se sugirió.
- **P7 Mechones finos (unitaria)**:
  - Sin cerrar huecos, un toque se mete en los 8 mechones.
  - Con Pequeño, Medio o Grande, solo en el tocado (cubierto al 100 %).
- **P8 Página con globo y rayas (simulado)**:
  - Fondo al 100 %.
  - Globo protegido: 0 px pintados. Rayas: 0 px.
  - Tocar dentro del globo no hace nada.
  - El globo lo marca el usuario: **no hay detector automático de globos**.
- **P9 Multiplicar (unitaria y simulado)**: ver «Paso 0». Error 0 a 1 por canal en todas las rutas.
- **P10 Sombras, luces y Cambiar color (simulado)**:
  - Sombra pintada a lo ancho: 0 px cambiados fuera del color base (el recorte funciona) y 5.952 px oscurecidos dentro.
  - Cambiar color (tono +120): los píxeles guardados quedan iguales, 14.624 px cambian de color y 0 px cambian fuera (sin halo).
  - Deshacer vuelve al tono 0.
- **P11 Gotero sobre gris con Multiplicar (simulado)**:
  - Visible da #998475, que es gris × piel exacto.
  - Capa actual da #FFDCC4, la piel guardada.
  - Automático en Multiplicar da #FFDCC4.
- **P12 Muestra, guardar y abrir (unitaria)**:
  - El promedio 3x3 con un píxel negro al lado da piel sin el negro.
  - 3 muestras guardadas y reabiertas, con nombres y colores idénticos.
- **P13 Quitar la referencia (simulado)**:
  - El PNG exportado es idéntico píxel a píxel con referencia, sin referencia y después de quitarla.
  - La referencia no es una capa.
  - La copia reducida se guarda y se abre.
- **P14 Contorno con una abertura de 30 px**:
  - Balde con Grande: 97,7 % cubierto, 64 px fuera.
  - Lazo + Rellenar selección: 100 %.
  - Ojo: en la simulación el dibujo del Lazo se reconstruye con el mismo polígono, porque Android simulado no dibuja trazados.
- **P15 Guardar y abrir (simulado)**:
  - Se conservan modos, opacidad, recorte, bloqueo total, alfa bloqueado, referencia, Cambiar color, modo manga, zonas protegidas y paleta.
  - Imagen idéntica píxel a píxel.
  - Las obras viejas abren igual: su prueba pasa.
- **P16 Deshacer y Rehacer propiedades (simulado)**:
  - Opacidad, bloqueo, recorte y modo se deshacen uno por uno.
  - El preset completo se deshace: vuelve a 1 capa «imagen» sin bloqueo.
  - Rehacer funciona.
- **P17 Borde al hacer zoom (simulado)**:
  - Con color bajo la línea en 0 px, 48 de 120 rayos tienen un píxel claro sin color antes de la línea.
  - Con 2 px: 0 de 120.
- **P18 Página A4 (2480x3508) con 6 capas**:
  - Solo se midió en la computadora: mapa de tinta 32 ms, zona 7 ms, unos 64 MB usados.
  - **Falta medir en un teléfono de 2 a 3 GB.**
- **P19 Dos dedos con la vista previa abierta (simulado)**:
  - 30 gestos: la vista previa sigue igual y la capa no cambia.
  - Cancelar no deja nada.
- **P20 Exportar vs pantalla**: el manga real con Multiplicar da diferencia 0 con la pantalla y 0 con la composición.
- **Bloqueo y herramientas de siempre (simulado)**:
  - Brocha, goma, mover y limpiar sobre la Tinta: queda intacta.
  - En «Color base» la brocha pinta normal.
  - Todas las pruebas anteriores (balde normal, brocha, goma, capas, Especial, Marioneta, Malla) pasan.

## Qué quedó hecho, a medias y pendiente

Implementado y probado:
- Multiplicar revisado en todas las rutas, y modo «Color».
- Preset Colorear manga: Tinta B/N con bloqueo total y referencia, y Color base en Multiplicar. Sin duplicados, se puede deshacer y se puede salir.
- Bloqueo total de capa: también en Opciones de capa, y se guarda con la obra.
- Balde manga por líneas, con vista previa (Aceptar, sumar o quitar zonas, Cancelar).
- Color bajo la línea, Cerrar huecos en niveles y trama Puntos.
- Zonas protegidas, Rellenar selección y Parecidas con confirmación.
- Sombra rápida, Luz rápida y Brillo encima.
- Cambiar color no destructivo, con «Fijar» y «Solo lo azul».
- Deshacer de propiedades de capa (modo, recorte, bloqueos, opacidad, ojo).
- Gotero Visible / Capa actual / Automático.
- Paleta de la obra y paleta global, guardar muestra con nombre, promedio 3x3.
- Copia reducida de la referencia guardada en la obra.
- Exportar «Imagen completa».

Parcial:
- **Trama Densa** (experimental, apagada de fábrica):
  - Entra hasta 24 px en la trama tupida pegada a la zona.
  - Deja un corte recto donde se detiene.
  - Puede meterse en la trama de la zona de al lado.
  - Por eso queda apagada y hay que mirar la vista previa.
- **Interfaz** (menús, barras, ventana de referencia con lupa, plegar, Usar, Guardar, Ajustar, paleta automática): está programada y compila contra Android 34, pero **no se probó tocándola en un teléfono**.

Pendiente:
- Detector automático de globos de texto (no se hizo; los marcas tú con el Lazo).
- Medir memoria y velocidad en un teléfono real de 2 a 3 GB.
- APK: hay que compilar en Android Studio.

## Archivos cambiados

Nuevos:
- `core/MangaFill.java`: mapa de tinta (`lineMap`), trama tupida (`textureMap`), zona (`compute`), color bajo la línea y Parecidas (`similarSeeds`).
- `core/Compositor.java`: una sola forma de juntar capas para exportar, comparar y el gotero.
- `core/ColorAdjust.java`: Cambiar color (HSL) con caché.
- `tests/MangaTest.java` (P1 a P20).
- Iconos: `ic_manga`, `ic_shield`, `ic_shadow`, `ic_light`, `ic_similar`, `ic_hue`, `ic_preview`.

Cambiados:
- `core/Layer.java`: `locked`, `role`, `hue`/`sat`/`lit`, modo `MODE_COLOR`.
- `core/Project.java`:
  - `protect`, `mangaMode`, `swatches`, `refImagePng`, `geomVersion`
  - `colorBlend` (modo Color)
  - Cambiar color también en la composición y en las miniaturas.
- `core/Exporter.java`: el Multiplicar ya mezclado respeta los recortes; `exportFlattened` y `writeFlattened`; Cambiar color también se exporta.
- `core/ProjectIO.java`: guarda bloqueo, papel, HSL, modo manga, `proteger.bin`, `paleta.txt` y `referencia.png`. Las obras viejas abren igual.
- `core/UndoManager.java`: deshacer de propiedades (PROPS) y de zonas protegidas (PROTECT).
- `core/BucketFill.java`: dos funciones internas ahora se comparten con MangaFill. El balde normal no cambió.
- `view/CanvasView.java`:
  - preset (`prepareManga`, `exitManga`)
  - balde manga con vista previa (`runMangaBucket`, `acceptFillPreview`, `cancelFillPreview`, `suggestSimilarZones`)
  - zonas protegidas, `fillSelectionWithColor`, `addQuickShadeLayer`, `addShineLayer`
  - Cambiar color (`previewLayerAdjust`, `commitLayerAdjust`, `bakeLayerAdjust`, `adjustSelectionColors`)
  - gotero (`pickColorAt`), bloqueo total (`refuseLocked` en todo lo que edita) y deshacer de propiedades
- `view/ReferenceImageView.java`: lupa, 3x3 y muestra sin aplicar.
- `MainActivity.java`:
  - menú Colorear manga, barras del balde, Lazo y Gotero en modo manga
  - Opciones de capa (bloqueo total, Cambiar color, Fijar) y modo Color
  - ventana de referencia renovada, paleta y exportar Imagen completa
- `tests/androidsim/android/view/View.java` (`setBackgroundColor`), `tests/run_jvm_tests.sh`, `tests/test_regressions.py`.

## Límites (honestos)

- Sin IA no hay reconocimiento: la app no sabe qué es un brazo o un ojo. Solo ve zonas entre líneas.
- Donde el dibujo tiene líneas abiertas (pelo suelto, rayas de velocidad), el color se puede escapar. La vista previa lo muestra antes de pintar: entonces se usa el Lazo o un nivel de «Cerrar huecos» mayor.
- La trama muy tupida (puntos que se tocan y forman una red) corta la zona en pedazos. «Puntos» no lo arregla, y «Densa» lo arregla solo en parte.
- Franjas blancas entre dos líneas (ribetes, doble contorno) son otra zona: se tocan aparte.
- Multiplicar oscurece los colores sobre las tramas. Es lo normal: para no oscurecer se puede usar el modo «Color».
- Las cifras de tiempo y memoria son de una computadora, no de un teléfono.

## Cómo probarlo en tu teléfono

1. Compila en Android Studio (Build > Build APK) e instala.
2. Abre un manga. Menú > Colorear manga > Preparar.
3. Elige un color de piel y toca la cara. Mira la vista previa: ✓ pinta, ✕ cancela.
4. Prueba Parecidas para cuello y manos.
5. Haz zoom al 400 % en el borde de la cara: no debe haber franja blanca.
6. Marca un globo con el Lazo > Proteger. Luego rellena el fondo: el globo debe quedar blanco.
7. Brocha > Sombra rápida, y pinta sobre la piel y fuera de ella: fuera no se debe ver.
8. Capas > Más > Opciones de «Color base» > Cambiar color.
9. Abre una imagen de referencia (Capas > Imagen color). Mantén el dedo para ver la lupa, luego «Guardar» la muestra y «Usar».
10. Guarda, cierra y vuelve a abrir la obra: todo debe seguir igual.
11. Exportar > Imagen completa: debe verse igual que en pantalla.
