import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Sim;
import android.view.MotionEvent;
import com.pacco.animecut.core.ColorAdjust;
import com.pacco.animecut.core.Compositor;
import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.MangaFill;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.view.CanvasView;
import com.pacco.animecut.view.ReferenceImageView;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Arrays;
import javax.imageio.ImageIO;

/**
 * v8.26 COLOREAR MANGA: pruebas P1-P20 con el CanvasView REAL en el Android simulado
 * (tests/androidsim). NO es un telefono: las medidas de tiempo y memoria son de la JVM
 * de escritorio. Todas las cifras que imprime salen de esta ejecucion.
 *
 * Uso: java MangaTest tests/assets/manga_chaqueta.png [carpetaSalidaImagenes]
 */
public final class MangaTest {
    static String OUT = null;
    static int fails = 0;

    static void log(String s) { System.out.println(s); }

    static void check(boolean ok, String m) {
        if (ok) return;
        fails++;
        System.out.println("     FALLA: " + m);
    }

    static int lum(int c) {
        return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
    }

    static int maxCh(int a, int b) {
        return Math.max(Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)),
                Math.max(Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)), Math.abs((a & 255) - (b & 255))));
    }

    static int mul(int b, int s) {
        int r = ((b >> 16) & 255) * ((s >> 16) & 255) / 255, g = ((b >> 8) & 255) * ((s >> 8) & 255) / 255,
                bl = (b & 255) * (s & 255) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    static int[] readPng(String path, int[] wh) throws Exception {
        BufferedImage bi = ImageIO.read(new File(path));
        wh[0] = bi.getWidth();
        wh[1] = bi.getHeight();
        int[] px = bi.getRGB(0, 0, wh[0], wh[1], null, 0, wh[0]);
        for (int i = 0; i < px.length; i++) px[i] |= 0xFF000000;
        return px;
    }

    static int[] jpegRoundTrip(int[] px, int w, int h, float q) throws Exception {
        BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        bi.setRGB(0, 0, w, h, px, 0, w);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        javax.imageio.ImageWriter wr = ImageIO.getImageWritersByFormatName("jpg").next();
        javax.imageio.ImageWriteParam pr = wr.getDefaultWriteParam();
        pr.setCompressionMode(javax.imageio.ImageWriteParam.MODE_EXPLICIT);
        pr.setCompressionQuality(q);
        wr.setOutput(ImageIO.createImageOutputStream(bo));
        wr.write(null, new javax.imageio.IIOImage(bi, null, null), pr);
        wr.dispose();
        BufferedImage back = ImageIO.read(new ByteArrayInputStream(bo.toByteArray()));
        int[] out = back.getRGB(0, 0, w, h, null, 0, w);
        for (int i = 0; i < out.length; i++) out[i] |= 0xFF000000;
        return out;
    }

    static void save(int[] px, int w, int h, String name) throws Exception {
        if (OUT == null) return;
        BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        bi.setRGB(0, 0, w, h, px, 0, w);
        ImageIO.write(bi, "png", new File(OUT, name));
    }

    static int[] crop(int[] px, int w, int x0, int y0, int cw, int ch, int zoom) {
        int[] o = new int[cw * zoom * ch * zoom];
        for (int y = 0; y < ch * zoom; y++)
            for (int x = 0; x < cw * zoom; x++) o[y * cw * zoom + x] = px[(y0 + y / zoom) * w + x0 + x / zoom];
        return o;
    }

    static void waitIdle(SimKit k) {
        long end = System.currentTimeMillis() + 60000;
        Sim.pump(20);
        while (((Boolean) k.get("busy")).booleanValue()) {
            Sim.pump(10);
            if (System.currentTimeMillis() > end) throw new AssertionError("tiempo agotado");
        }
        Sim.pump(20);
    }

    /** Toca con el balde y espera; devuelve ms desde el toque hasta la vista previa (JVM). */
    static long tapFill(SimKit k, int x, int y) {
        long t0 = System.nanoTime();
        float[] s = k.screen(x + .5f, y + .5f);
        k.touch(MotionEvent.ACTION_DOWN, s);
        Sim.pump(30);
        k.touch(MotionEvent.ACTION_UP, s);
        waitIdle(k);
        return (System.nanoTime() - t0) / 1_000_000L;
    }

    // ------------------------------------------------------------------
    // dibujos sinteticos (con respuesta conocida)
    // ------------------------------------------------------------------

    static void disk(int[] p, int w, int h, float cx, float cy, float r, int c) {
        for (int y = (int) Math.max(0, cy - r - 2); y < Math.min(h, cy + r + 2); y++)
            for (int x = (int) Math.max(0, cx - r - 2); x < Math.min(w, cx + r + 2); x++) {
                float d = (float) Math.hypot(x + .5 - cx, y + .5 - cy);
                float a = Math.max(0, Math.min(1, r + .5f - d));
                if (a > 0) p[y * w + x] = BucketTest.mix(p[y * w + x], c, a);
            }
    }

    static void ring(int[] p, int w, int h, float cx, float cy, float r, float th, int c) {
        for (int y = (int) Math.max(0, cy - r - th - 2); y < Math.min(h, cy + r + th + 2); y++)
            for (int x = (int) Math.max(0, cx - r - th - 2); x < Math.min(w, cx + r + th + 2); x++) {
                float d = Math.abs((float) Math.hypot(x + .5 - cx, y + .5 - cy) - r);
                float a = Math.max(0, Math.min(1, th / 2f + .5f - d));
                if (a > 0) p[y * w + x] = BucketTest.mix(p[y * w + x], c, a);
            }
    }

    static int[] white(int w, int h) {
        int[] p = new int[w * h];
        Arrays.fill(p, 0xFFFFFFFF);
        return p;
    }

    /** Trama de puntos (2x2 cada 'step' px) dentro de una mascara. */
    static void dots(int[] p, int w, int h, boolean[] in, int step, int size) {
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                if (in[y * w + x] && (x % step) < size && (y % step) < size) p[y * w + x] = 0xFF101010;
    }

    // ------------------------------------------------------------------

    public static void main(String[] a) throws Exception {
        REAL = a[0];
        if (a.length > 1) {
            OUT = a[1];
            new File(OUT).mkdirs();
        }
        Sim.main = Thread.currentThread();
        String only = System.getProperty("only", "");
        if (!only.isEmpty()) {
            for (String t : only.split(",")) MangaTest.class.getDeclaredMethod(t).invoke(null);
            log(fails == 0 ? "OK (parcial)" : "FALLAS: " + fails);
            System.exit(fails == 0 ? 0 : 1);
        }
        p9multiply();
        realManga(a[0]);
        p3tone();
        p4gaps();
        p5eye();
        p6similar();
        p7strands();
        p8page();
        p10shadeLight();
        p11picker();
        p12palette();
        p13reference();
        p14lasso();
        p15p16saveUndo();
        p17zoom();
        p19multitouch();
        lockAndTools();
        p18memory();
        log(fails == 0 ? "OK Colorear manga (Android simulado)" : "FALLAS: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }

    // ------------------------------------------------------------------
    // P9 / P20: MULTIPLICAR correcto en todas las rutas
    // ------------------------------------------------------------------

    static void p9multiply() throws Exception {
        log("== P9 Multiplicar (formula W3C) en pantalla, miniatura, union y PNG ==");
        int w = 6, h = 1;
        int[] base = {0xFFFFFFFF, 0xFF000000, 0xFF808080, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF808080};
        int[] top = {0xFFC86432, 0xFF33AA77, 0xFFC86432, 0x00C86432, 0xFFFF0000, 0x80C86432};
        Project p = new Project(w, h);
        p.layers.add(new Layer("base", base.clone()));
        Layer m = new Layer("mult", top.clone());
        m.mode = Layer.MODE_MULTIPLY;
        p.layers.add(m);
        int[] exp = {0xFFC86432, 0xFF000000, 0xFF643219, 0xFFFFFFFF, 0, 0};
        int[] flat = Compositor.flatten(p);
        String[] names = {"blanco x (200,100,50)", "negro x color", "gris 128 x (200,100,50)", "alfa 0 del color"};
        for (int i = 0; i < 4; i++) {
            log(String.format("   %-24s -> %06X (esperado %06X), alfa %d", names[i], flat[i] & 0xFFFFFF, exp[i] & 0xFFFFFF, flat[i] >>> 24));
            check(maxCh(flat[i], exp[i]) <= 1 && (flat[i] >>> 24) == 255, "multiplicar " + names[i]);
        }
        // opacidad de capa 50 %: rojo sobre blanco -> (255,128,128)
        Project p2 = new Project(1, 1);
        p2.layers.add(new Layer("b", new int[]{0xFFFFFFFF}));
        Layer r = new Layer("r", new int[]{0xFFFF0000});
        r.mode = Layer.MODE_MULTIPLY;
        r.opacity = 128;
        p2.layers.add(r);
        int o50 = Compositor.flatten(p2)[0];
        log(String.format("   opacidad 50%% rojo sobre blanco -> %06X (esperado FF8080 +-1)", o50 & 0xFFFFFF));
        check(maxCh(o50, 0xFFFF7F7F) <= 1, "opacidad 50%");
        // alfa parcial del pixel (128) sobre gris: mezcla entre gris y gris*color
        int g = flat[5];
        int want = BucketTest.mix(0xFF808080, mul(0xFF808080, 0xFFC86432), 128 / 255f);
        log(String.format("   alfa 128 del pixel sobre gris -> %06X (esperado %06X)", g & 0xFFFFFF, want & 0xFFFFFF));
        check(maxCh(g, want) <= 1, "alfa parcial");

        // la misma prueba en el CanvasView real: pantalla (vista), miniatura (galeria), PNG
        int W = 64, H = 32;
        int[] img = new int[W * H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) img[y * W + x] = x < 16 ? 0xFFFFFFFF : x < 32 ? 0xFF000000 : x < 48 ? 0xFF808080 : 0xFFB0B0B0;
        SimKit k = new SimKit(W, H, img);
        Layer col = new Layer("col", W, H);
        int[] cp = col.px();
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) cp[y * W + x] = y < 16 ? 0xFFC86432 : (y < 24 ? 0x80C86432 : 0);
        col.mode = Layer.MODE_MULTIPLY;
        k.project.layers.add(col);
        k.cv.layersChanged();
        Sim.pump(200);
        Bitmap disp = (Bitmap) k.get("display");
        int[] fl = Compositor.flatten(k.project);
        int[][] bg = CanvasView.VIEW_BG;
        int maxView = 0, maxThumb = 0;
        Bitmap thumb = k.project.previewBitmap(64);
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int checker = (((x / 8) + (y / 8)) & 1) == 0 ? bg[0][0] : bg[0][1];
                int e = Compositor.overOpaque(checker, fl[y * W + x]);
                maxView = Math.max(maxView, maxCh(e, disp.getPixel(x, y)));
                maxThumb = Math.max(maxThumb, maxCh(Compositor.overOpaque(0xFFFFFFFF, fl[y * W + x]), thumb.getPixel(x, y)));
            }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        Exporter.writeFlattened(k.project, W, H, bo);
        BufferedImage png = ImageIO.read(new ByteArrayInputStream(bo.toByteArray()));
        int maxPng = 0;
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) maxPng = Math.max(maxPng, maxCh(png.getRGB(x, y), fl[y * W + x]));
        // capa suelta exportada (ya mezclada) + tinta en Normal = lo mismo que se ve
        ByteArrayOutputStream lo = new ByteArrayOutputStream();
        Exporter.writeLayerPng(k.project, col, 0, lo);
        BufferedImage lpng = ImageIO.read(new ByteArrayInputStream(lo.toByteArray()));
        int maxLayer = 0;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int c = lpng.getRGB(x, y);
                int comp = (c >>> 24) == 0 ? img[y * W + x] : Project.over(img[y * W + x], c, c >>> 24);
                maxLayer = Math.max(maxLayer, maxCh(comp, fl[y * W + x]));
            }
        log("   CanvasView real: diferencia maxima por canal pantalla=" + maxView + ", miniatura=" + maxThumb
                + ", PNG imagen completa=" + maxPng + ", PNG por capa (Multiplicar ya mezclado) + tinta=" + maxLayer);
        check(maxView <= 1 && maxThumb <= 1 && maxPng <= 1 && maxLayer <= 1, "rutas de Multiplicar");
        // modo Color (W3C SetLum): gris 128 + rojo => rojo con la luminosidad del gris
        int cb = Project.colorBlend(128, 128, 128, 255, 0, 0);
        int lc = (int) Math.round(0.3 * ((cb >> 16) & 255) + 0.59 * ((cb >> 8) & 255) + 0.11 * (cb & 255));
        log(String.format("   Modo Color: gris 128 + rojo -> %06X, luminosidad %d (la del gris: 128)", cb, lc));
        check(Math.abs(lc - 128) <= 1 && ((cb >> 16) & 255) > ((cb >> 8) & 255), "modo Color");
        log("   Nota: la mezcla es Java pixel por pixel (no usa PorterDuff ni BlendMode de Android):");
        log("   no depende de la version de Android (26-28 o 29+). No se probo en un telefono real.");
    }

    // ------------------------------------------------------------------
    // P1 / P2 / P17 (real) y P20 con el manga real
    // ------------------------------------------------------------------

    static final int SKIN = 0xFFFFDCC4, HAIR = 0xFF8A5A3C, JACKET = 0xFF4A6FB0, SHIRT = 0xFFF2F4FF, TIE = 0xFF9E2B3A;

    static void realManga() throws Exception { realManga(REAL); }

    static String REAL = "tests/assets/manga_chaqueta.png";

    static void realManga(String path) throws Exception {
        int[] wh = new int[2];
        int[] png = readPng(path, wh);
        int w = wh[0], h = wh[1];
        // zonas que se tocan (las elige el usuario: el programa no sabe que es piel)
        int[][] taps = {{560, 480, SKIN}, {250, 1300, SKIN}, {150, 900, JACKET}, {420, 1000, JACKET}, {860, 1100, JACKET},
                {620, 1200, SHIRT}, {380, 690, SHIRT}, {880, 300, HAIR}};
        String[] tapNames = {"cara+cuello", "mano", "manga izq.", "solapa", "chaqueta der.", "camisa", "cuello camisa", "pelo der. (lineas abiertas)"};
        for (int variant = 0; variant < 2; variant++) {
            boolean jpeg = variant == 1;
            int[] src = jpeg ? jpegRoundTrip(png, w, h, 0.6f) : png;
            log(jpeg ? "== P2 Mismo manga guardado como JPEG (calidad 60) ==" : "== P1 Manga real PNG (" + w + "x" + h + ", tramas en chaqueta y pelo) ==");
            SimKit k = new SimKit(w, h, src.clone());
            int before = k.project.layers.size();
            boolean ok = k.cv.prepareManga(0);
            Sim.pump(50);
            Layer ink = k.project.layers.get(0), base = k.project.layers.get(1);
            if (!jpeg) {
                log("   Preset: capas " + before + " -> " + k.project.layers.size() + "; [0] \"" + ink.name + "\" bloqueada=" + ink.locked
                        + " referencia=" + ink.reference + "; [1] \"" + base.name + "\" " + Layer.MODE_NAMES[base.mode] + " " + base.opacity * 100 / 255
                        + "%; capa elegida=" + k.project.active);
                check(ok && k.project.layers.size() == 2 && ink.locked && ink.reference && base.mode == Layer.MODE_MULTIPLY
                        && k.project.active == 1 && k.project.mangaMode, "preset manga");
                k.cv.prepareManga(0);
                log("   Tocar \"Colorear manga\" otra vez: capas=" + k.project.layers.size() + " (sin duplicados)");
                check(k.project.layers.size() == 2, "sin duplicados");
                check(Arrays.equals(ink.px(), png), "la tinta no cambio al preparar");
            }
            k.cv.setMode(CanvasView.MODE_BUCKET);
            int totalTaps = 0;
            long sumMs = 0;
            StringBuilder sb = new StringBuilder();
            for (int ti = 0; ti < taps.length; ti++) {
                int[] t = taps[ti];
                k.cv.setColor(t[2]);
                int[] beforeBase = base.px().clone();
                long ms = tapFill(k, t[0], t[1]);
                totalTaps++;
                sumMs += ms;
                int pend = k.cv.fillPreviewArea();
                boolean untouched = Arrays.equals(beforeBase, base.px());
                k.cv.acceptFillPreview();
                Sim.pump(30);
                MangaFill.Result r = k.cv.lastManga;
                sb.append(String.format("   %-28s (%d,%d): %7d px (bajo la linea +%d, cierre r=%d), vista previa %d ms (JVM), nada escrito antes de Aceptar=%s%n",
                        tapNames[ti], t[0], t[1], r == null ? 0 : r.area, r == null ? 0 : r.expanded, r == null ? 0 : r.gapUsed, ms, untouched));
                check(untouched && pend > 0, "vista previa sin escribir");
            }
            log(sb.toString().replaceAll("\n$", ""));
            int[] out = Compositor.flatten(k.project);
            // tinta: negros puros sin cambio; nada se aclara; formula exacta
            int blackMax = 0, lighter = 0, formulaMax = 0, colored = 0;
            int[] bp = base.px();
            for (int i = 0; i < out.length; i++) {
                int o = src[i];
                if (lum(o) <= 16) blackMax = Math.max(blackMax, maxCh(out[i], o));
                if (lum(out[i]) > lum(o) + 1) lighter++;
                if ((bp[i] >>> 24) == 255) {
                    colored++;
                    formulaMax = Math.max(formulaMax, maxCh(out[i], mul(o, bp[i])));
                }
            }
            log("   Pixeles coloreados=" + colored + "; negro puro (brillo<=16): cambio maximo " + blackMax + " niveles; "
                    + "pixeles que se aclararon=" + lighter + "; resultado = original x color (error max " + formulaMax + ")");
            check(blackMax <= 16 && lighter == 0 && formulaMax <= 1, "tinta conservada");
            // franja clara sin color pegada al color (lo que se ve al hacer zoom)
            int fringe = 0, specks = 0;
            for (int y = 1; y < h - 1; y++)
                for (int x = 1; x < w - 1; x++) {
                    int i = y * w + x;
                    if ((bp[i] >>> 24) != 0) continue;
                    int nb = ((bp[i - 1] >>> 24) != 0 ? 1 : 0) + ((bp[i + 1] >>> 24) != 0 ? 1 : 0)
                            + ((bp[i - w] >>> 24) != 0 ? 1 : 0) + ((bp[i + w] >>> 24) != 0 ? 1 : 0);
                    if (nb == 0) continue;
                    if (lum(src[i]) > 200 && nb >= 1) fringe++;
                    if (nb == 4 && lum(src[i]) > 128) specks++;
                }
            log("   Borde: pixeles claros (brillo>200) sin color tocando el color=" + fringe + "; motas claras encerradas sin color=" + specks
                    + "; toques=" + totalTaps + ", promedio " + (sumMs / totalTaps) + " ms por toque (JVM)");
            if (!jpeg) {
                save(out, w, h, "P1_manga_coloreado.png");
                int[] both = new int[w * 2 * h];
                for (int y = 0; y < h; y++) {
                    System.arraycopy(src, y * w, both, y * 2 * w, w);
                    System.arraycopy(out, y * w, both, y * 2 * w + w, w);
                }
                save(both, w * 2, h, "P1_antes_despues.png");
                save(crop(out, w, 600, 610, 60, 45, 8), 480, 360, "P17_zoom800_cara_cuello.png");
                save(crop(src, w, 600, 610, 60, 45, 8), 480, 360, "P17_zoom800_original.png");
                // P20 con el manga real
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                Exporter.writeFlattened(k.project, w, h, bo);
                BufferedImage pi = ImageIO.read(new ByteArrayInputStream(bo.toByteArray()));
                Bitmap disp = (Bitmap) k.get("display");
                k.cv.layersChanged();
                Sim.pump(300);
                disp = (Bitmap) k.get("display");
                int maxD = 0, maxV = 0;
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++) {
                        maxD = Math.max(maxD, maxCh(pi.getRGB(x, y), out[y * w + x]));
                        maxV = Math.max(maxV, maxCh(pi.getRGB(x, y), disp.getPixel(x, y)));
                    }
                log("== P20 PNG \"Imagen completa\" del manga real: diferencia con la composicion=" + maxD + ", con la pantalla=" + maxV + " (por canal)");
                check(maxD <= 1 && maxV <= 1, "P20 exportacion vs vista");
            } else {
                save(out, w, h, "P2_manga_jpeg_coloreado.png");
            }
        }
    }

    // ------------------------------------------------------------------
    // P3 trama densa: toques necesarios con modo trama apagado / prendido
    // ------------------------------------------------------------------

    static void p3tone() throws Exception {
        log("== P3 Trama de puntos dentro de un contorno (respuesta conocida) ==");
        int W = 300, H = 240;
        int[] img = white(W, H);
        boolean[] in = new boolean[W * H];
        for (int y = 40; y < 200; y++) for (int x = 40; x < 260; x++) in[y * W + x] = true;
        dots(img, W, H, in, 5, 2);
        for (int x = 36; x < 264; x++) for (int t = 0; t < 4; t++) { img[(36 + t) * W + x] = 0xFF000000; img[(200 + t) * W + x] = 0xFF000000; }
        for (int y = 36; y < 204; y++) for (int t = 0; t < 4; t++) { img[y * W + 36 + t] = 0xFF000000; img[y * W + 260 + t] = 0xFF000000; }
        int light = 0;
        for (int i = 0; i < in.length; i++) if (in[i] && lum(img[i]) > 128) light++;
        for (int mode = 0; mode < 2; mode++) {
            SimKit k = new SimKit(W, H, img.clone());
            k.cv.prepareManga(0);
            k.cv.setMangaTone(mode == 1);
            k.cv.setFillPreview(false);
            k.cv.setMode(CanvasView.MODE_BUCKET);
            k.cv.setColor(JACKET);
            Layer base = k.project.layers.get(1);
            int taps = 0;
            int cov = 0;
            while (taps < 60) {
                int[] bp = base.px();
                int sx = -1, sy = -1;
                cov = 0;
                for (int i = 0; i < in.length; i++) if (in[i] && lum(img[i]) > 128 && (bp[i] >>> 24) != 0) cov++;
                if (cov >= light * .95) break;
                outer:
                for (int y = 40; y < 200; y++)
                    for (int x = 40; x < 260; x++) {
                        int i = y * W + x;
                        if (lum(img[i]) > 128 && (bp[i] >>> 24) == 0) { sx = x; sy = y; break outer; }
                    }
                if (sx < 0) break;
                tapFill(k, sx, sy);
                taps++;
            }
            int[] bp = base.px();
            int spill = 0;
            for (int i = 0; i < in.length; i++) if (!in[i] && (bp[i] >>> 24) != 0 && lum(img[i]) > 128) spill++;
            log(String.format("   Modo trama %s: %d toques para cubrir %.1f%% del papel dentro (tope 60 toques), derrame afuera=%d px",
                    mode == 1 ? "SI" : "NO", taps, 100f * cov / light, spill));
            if (mode == 1) check(taps == 1 && cov >= light * .99 && spill == 0, "modo trama: un toque");
            if (mode == 1) save(Compositor.flatten(k.project), W, H, "P3_trama_un_toque.png");
        }
        // trama real del manga: un toque en la manga izquierda con trama No / Puntos / Densa
        {
            int[] wh0 = new int[2];
            int[] png0 = readPng(REAL, wh0);
            int W0 = wh0[0], H0 = wh0[1];
            int[] prev = null;
            for (int lv = 0; lv < 3; lv++) {
                SimKit k = new SimKit(W0, H0, png0.clone());
                k.cv.prepareManga(0);
                k.cv.setMangaToneLevel(lv);
                k.cv.setFillPreview(false);
                k.cv.setMode(CanvasView.MODE_BUCKET);
                k.cv.setColor(JACKET);
                tapFill(k, 150, 900);
                int n = 0;
                for (int c : k.project.layers.get(1).px()) if ((c >>> 24) != 0) n++;
                log("   Manga real, manga izquierda (150,900), trama " + CanvasView.TONE_NAMES[lv] + ": un toque pinta " + n + " px"
                        + (k.cv.lastManga != null && k.cv.lastManga.dense > 0 ? " (+" + k.cv.lastManga.dense + " px de trama tupida)" : ""));
                int[] o = Compositor.flatten(k.project);
                if (lv == 1) prev = o;
                if (lv == 2 && prev != null) {
                    int[] both = new int[2 * 420 * 520];
                    for (int y = 0; y < 520; y++)
                        for (int x = 0; x < 420; x++) {
                            both[y * 840 + x] = prev[(700 + y) * W0 + x];
                            both[y * 840 + 420 + x] = o[(700 + y) * W0 + x];
                        }
                    save(both, 840, 520, "P3_trama_puntos_vs_densa.png");
                }
            }
        }
        // trama real (chaqueta del manga): area de un toque con y sin modo trama
        int[] wh = new int[2];
        int[] png = readPng(REAL, wh);
        MangaFill.Params p = new MangaFill.Params();
        for (int mode = 0; mode < 2; mode++) {
            p.tone = mode == 1;
            byte[] line = MangaFill.lineMap(png, wh[0], wh[1], p);
            byte[] out = new byte[png.length];
            MangaFill.Result r = MangaFill.compute(png, line, wh[0], wh[1], 420, 1000, p, out);
            log("   Manga real, solapa con trama (420,1000), trama " + (mode == 1 ? "Puntos" : "No") + ": un toque cubre " + (r == null ? 0 : r.area) + " px");
        }
    }

    // ------------------------------------------------------------------
    // P4 lineas abiertas de 2, 4, 8, 12 px
    // ------------------------------------------------------------------

    static void p4gaps() throws Exception {
        log("== P4 Linea con un corte de 2/4/8/12 px entre dos zonas (toco la izquierda) ==");
        int W = 260, H = 200;
        int[] gaps = {2, 4, 8, 12};
        for (int lv = 1; lv <= 3; lv++) {
            StringBuilder sb = new StringBuilder("   Cerrar huecos " + MangaFill.GAP_NAMES[lv] + ":");
            for (int g : gaps) {
                int[] img = white(W, H);
                for (int y = 10; y < H - 10; y++) for (int x = 126; x < 130; x++) img[y * W + x] = 0xFF000000;
                for (int x = 10; x < W - 10; x++) for (int t = 0; t < 3; t++) { img[(10 + t) * W + x] = 0xFF000000; img[(H - 13 + t) * W + x] = 0xFF000000; }
                for (int y = 10; y < H - 10; y++) for (int t = 0; t < 3; t++) { img[y * W + 10 + t] = 0xFF000000; img[y * W + W - 13 + t] = 0xFF000000; }
                for (int y = 100 - g / 2; y < 100 - g / 2 + g; y++) for (int x = 126; x < 130; x++) img[y * W + x] = 0xFFFFFFFF;
                MangaFill.Params p = new MangaFill.Params();
                p.gap = MangaFill.GAP_LEVELS[lv];
                byte[] line = MangaFill.lineMap(img, W, H, p);
                byte[] out = new byte[W * H];
                MangaFill.compute(img, line, W, H, 60, 100, p, out);
                int right = 0, rightTotal = 0, left = 0, leftTotal = 0;
                for (int y = 13; y < H - 13; y++)
                    for (int x = 13; x < W - 13; x++) {
                        if (x >= 126 && x < 130) continue;
                        if (x > 130) { rightTotal++; if (out[y * W + x] != 0) right++; }
                        if (x < 126) { leftTotal++; if (out[y * W + x] != 0) left++; }
                    }
                sb.append(String.format("  corte %dpx: izq %.1f%%, derrame der %.1f%%;", g, 100f * left / leftTotal, 100f * right / rightTotal));
                if (lv == 2 && g <= 4) check(right < rightTotal * .02, "medio cierra " + g);
            }
            log(sb.toString());
        }
        log("   (Un corte mas ancho que el nivel elegido deja pasar el color: se usa Lazo o un nivel mayor)");
    }

    // ------------------------------------------------------------------
    // P5 ojo: iris sin tapar pupila ni pestanas
    // ------------------------------------------------------------------

    static void p5eye() throws Exception {
        log("== P5 Iris: pupila, brillo y pestanas negras ==");
        int W = 200, H = 160;
        int[] img = white(W, H);
        ring(img, W, H, 100, 80, 40, 3, 0xFF000000);
        disk(img, W, H, 100, 80, 14, 0xFF000000);
        disk(img, W, H, 96, 76, 4, 0xFFFFFFFF); // brillo blanco del ojo (dentro de la pupila)
        for (int k2 = 0; k2 < 7; k2++) BucketTest.stroke(img, W, H, 60 + k2 * 12, 42, 55 + k2 * 13, 14, 1.4f, 0xFF000000);
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(0xFF2E8B57);
        tapFill(k, 100, 108);
        k.cv.acceptFillPreview();
        Sim.pump(30);
        int[] out = Compositor.flatten(k.project);
        int pupilMax = 0, irisLight = 0, irisCol = 0, shine = 0;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                double d = Math.hypot(x + .5 - 100, y + .5 - 80);
                if (lum(img[i]) <= 8) pupilMax = Math.max(pupilMax, maxCh(out[i], img[i]));
                if (d > 18 && d < 36 && lum(img[i]) > 200) { irisLight++; if (out[i] != img[i]) irisCol++; }
                if (Math.hypot(x + .5 - 96, y + .5 - 76) < 2.5) shine += out[i] == img[i] ? 0 : 1;
            }
        log(String.format("   Iris coloreado %.1f%%; negro puro (pupila, pestanas, contorno) cambio maximo %d niveles; brillo blanco del ojo tocado=%d px",
                100f * irisCol / irisLight, pupilMax, shine));
        check(irisCol >= irisLight * .98 && pupilMax <= 8 && shine == 0, "iris");
        save(crop(out, W, 40, 20, 120, 120, 3), 360, 360, "P5_iris.png");
    }

    // ------------------------------------------------------------------
    // P6 cara, cuello y manos separadas: toques con y sin "Parecidas"
    // ------------------------------------------------------------------

    static int[] skinScene(int W, int H, boolean[][] gt) {
        int[] img = white(W, H);
        float[][] parts = {{150, 110, 60}, {150, 205, 22}, {60, 260, 26}, {245, 262, 26}}; // cara, cuello, manos
        for (int k = 0; k < parts.length; k++) {
            gt[k] = new boolean[W * H];
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) gt[k][y * W + x] = Math.hypot(x + .5 - parts[k][0], y + .5 - parts[k][1]) < parts[k][2] - 2;
            ring(img, W, H, parts[k][0], parts[k][1], parts[k][2], 3, 0xFF000000);
        }
        // chaqueta con trama entre medio (no debe sugerirse: es mas oscura)
        boolean[] jk = new boolean[W * H];
        for (int y = 235; y < 300; y++) for (int x = 95; x < 205; x++) jk[y * W + x] = true;
        dots(img, W, H, jk, 3, 2);
        for (int x = 93; x < 207; x++) for (int t = 0; t < 2; t++) { img[(233 + t) * W + x] = 0xFF000000; img[(300 + t) * W + x] = 0xFF000000; }
        for (int y = 233; y < 302; y++) for (int t = 0; t < 2; t++) { img[y * W + 93 + t] = 0xFF000000; img[y * W + 205 + t] = 0xFF000000; }
        return img;
    }

    static void p6similar() throws Exception {
        log("== P6 Cara, cuello y dos manos separadas ==");
        int W = 320, H = 310;
        boolean[][] gt = new boolean[4][];
        int[] img = skinScene(W, H, gt);
        // sin Parecidas: un toque por zona
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(SKIN);
        int[][] seeds = {{150, 110}, {150, 205}, {60, 260}, {245, 262}};
        long t0 = System.nanoTime();
        for (int[] s : seeds) tapFill(k, s[0], s[1]);
        k.cv.acceptFillPreview();
        long ms1 = (System.nanoTime() - t0) / 1_000_000L;
        log("   Sin \"Parecidas\": " + seeds.length + " toques + Aceptar (" + ms1 + " ms JVM)");
        // con Parecidas: un toque + Parecidas + Aceptar
        SimKit k2 = new SimKit(W, H, img.clone());
        k2.cv.prepareManga(0);
        k2.cv.setMode(CanvasView.MODE_BUCKET);
        k2.cv.setColor(SKIN);
        t0 = System.nanoTime();
        tapFill(k2, 150, 110);
        k2.cv.suggestSimilarZones();
        waitIdle(k2);
        int zones = k2.cv.fillPreviewCount();
        Sim.pump(20);
        k2.cv.acceptFillPreview();
        long ms2 = (System.nanoTime() - t0) / 1_000_000L;
        int[] bp = k2.project.layers.get(1).px();
        int hits = 0, wrong = 0;
        for (int z = 0; z < 4; z++) {
            int n = 0, c = 0;
            for (int i = 0; i < bp.length; i++) if (gt[z][i]) { n++; if ((bp[i] >>> 24) != 0) c++; }
            if (c > n * .9) hits++;
        }
        for (int i = 0; i < bp.length; i++) {
            boolean any = gt[0][i] || gt[1][i] || gt[2][i] || gt[3][i];
            if (!any && (bp[i] >>> 24) != 0 && lum(img[i]) > 200) {
                // fuera de las 4 zonas (sin contar el borde bajo la linea)
                int x = i % W, y = i / W;
                boolean nearLine = false;
                for (int dy = -3; dy <= 3 && !nearLine; dy++) for (int dx = -3; dx <= 3; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx >= 0 && yy >= 0 && xx < W && yy < H && lum(img[yy * W + xx]) < 128) { nearLine = true; break; }
                }
                if (!nearLine) wrong++;
            }
        }
        log("   Con \"Parecidas\": 1 toque + Parecidas + Aceptar -> " + zones + " zonas en la vista previa; zonas de piel correctas "
                + hits + " de 4; pixeles pintados fuera de la piel=" + wrong + " (" + ms2 + " ms JVM)");
        check(hits == 4 && wrong == 0, "parecidas");
        save(Compositor.flatten(k2.project), W, H, "P6_parecidas.png");
    }

    // ------------------------------------------------------------------
    // P7 mechones finos
    // ------------------------------------------------------------------

    static void p7strands() throws Exception {
        log("== P7 Mechones: 8 mechones separados por lineas de 2 px, que se juntan en la punta ==");
        int W = 260, H = 220;
        int[] img = white(W, H);
        // contorno del pelo (arco) y 7 divisiones que bajan y se cortan antes de la punta
        for (int x = 20; x < 240; x++) for (int t = 0; t < 3; t++) img[(20 + t) * W + x] = 0xFF000000;
        for (int k = 0; k <= 8; k++) {
            float x0 = 20 + k * 27.5f;
            BucketTest.stroke(img, W, H, x0, 22, x0 + (k - 4) * 3, 190, k == 0 || k == 8 ? 2f : 1f, 0xFF000000);
        }
        for (int x = 20; x < 240; x++) for (int t = 0; t < 3; t++) img[(195 + t) * W + x] = 0xFF000000;
        // huecos de 3 px en la mitad de las divisiones (como un pelo dibujado suelto)
        for (int k = 1; k < 8; k++) {
            float x0 = 20 + k * 27.5f + (k - 4) * 3 * (100 - 22) / 168f;
            for (int y = 99; y < 102; y++) for (int x = (int) x0 - 3; x <= (int) x0 + 3; x++) img[y * W + x] = 0xFFFFFFFF;
        }
        for (int lv = 0; lv <= 3; lv++) {
            MangaFill.Params p = new MangaFill.Params();
            p.gap = MangaFill.GAP_LEVELS[lv];
            byte[] line = MangaFill.lineMap(img, W, H, p);
            byte[] out = new byte[W * H];
            // toco el mechon 4 (entre la division 3 y 4)
            int sx = (int) (20 + 3.5f * 27.5f), sy = 60;
            MangaFill.compute(img, line, W, H, sx, sy, p, out);
            int strands = 0;
            for (int s = 0; s < 8; s++) {
                int cx = (int) (20 + (s + .5f) * 27.5f);
                if (out[60 * W + cx] != 0 || out[150 * W + cx + (s - 4) * 3] != 0) strands++;
            }
            int own = 0, ownTot = 0;
            for (int y = 25; y < 190; y++) {
                int x = (int) (20 + 3.5f * 27.5f + (y - 22) * (-.5f * 3) / 168f);
                ownTot++;
                if (out[y * W + x] != 0) own++;
            }
            log(String.format("   Cerrar huecos %-8s: un toque llega a %d mechon(es) de 8; el mechon tocado queda cubierto %.0f%% en su centro",
                    MangaFill.GAP_NAMES[lv], strands, 100f * own / ownTot));
            if (lv >= 2) check(strands == 1, "mechones separados");
        }
    }

    // ------------------------------------------------------------------
    // P8 pagina con personajes, globo y rayas de velocidad: zonas protegidas
    // ------------------------------------------------------------------

    static void p8page() throws Exception {
        log("== P8 Pagina: 2 personajes, globo de texto y rayas de velocidad; fondo rellenado ==");
        int W = 400, H = 300;
        int[] img = white(W, H);
        ring(img, W, H, 110, 170, 60, 3, 0xFF000000);
        ring(img, W, H, 290, 180, 55, 3, 0xFF000000);
        // globo con "texto"
        boolean[] bubble = new boolean[W * H];
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            double e = Math.pow((x - 200) / 80.0, 2) + Math.pow((y - 50) / 32.0, 2);
            if (e < 1.18) bubble[y * W + x] = true;
            if (Math.abs(e - 1) < .06) img[y * W + x] = 0xFF000000;
        }
        for (int r = 0; r < 2; r++) for (int c = 0; c < 8; c++) disk(img, W, H, 160 + c * 11, 44 + r * 14, 3, 0xFF000000);
        // rayas de velocidad abajo a la derecha
        boolean[] speed = new boolean[W * H];
        for (int k = 0; k < 14; k++) BucketTest.stroke(img, W, H, 330, 250 + k * 3, 398, 230 + k * 5, .8f, 0xFF000000);
        for (int y = 240; y < H; y++) for (int x = 325; x < W; x++) speed[y * W + x] = true;
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        // proteger globo y rayas con una seleccion (como con el Lazo)
        for (int i = 0; i < W * H; i++) k.project.selection[i] = (byte) (bubble[i] || speed[i] ? 255 : 0);
        k.cv.protectSelection(true);
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(0xFFB8D8F0);
        tapFill(k, 20, 20);
        tapFill(k, 200, 50);
        boolean refusedBubble = k.cv.fillPreviewCount() == 1;
        k.cv.acceptFillPreview();
        Sim.pump(30);
        int[] bp = k.project.layers.get(1).px();
        int inBubble = 0, inSpeed = 0, bg = 0, bgTot = 0;
        for (int i = 0; i < bp.length; i++) {
            if (bubble[i] && (bp[i] >>> 24) != 0) inBubble++;
            if (speed[i] && (bp[i] >>> 24) != 0) inSpeed++;
            int x = i % W, y = i / W;
            boolean inChar = Math.hypot(x - 110, y - 170) < 64 || Math.hypot(x - 290, y - 180) < 59;
            if (!bubble[i] && !speed[i] && !inChar && lum(img[i]) > 200) { bgTot++; if ((bp[i] >>> 24) != 0) bg++; }
        }
        log(String.format("   Fondo coloreado %.1f%%; pixeles pintados dentro del globo=%d y de las rayas=%d; tocar dentro del globo no agrega nada=%s",
                100f * bg / bgTot, inBubble, inSpeed, refusedBubble));
        log("   (El globo y las rayas los marca el usuario con Lazo: no hay detector automatico de globos)");
        check(inBubble == 0 && inSpeed == 0 && refusedBubble && bg > bgTot * .95, "zonas protegidas");
        save(Compositor.flatten(k.project), W, H, "P8_globo_protegido.png");
    }

    // ------------------------------------------------------------------
    // P10 sombras, luces y cambio de color
    // ------------------------------------------------------------------

    static void p10shadeLight() throws Exception {
        log("== P10 Sombra rapida, Luz rapida y Cambiar color (recorte sin halos) ==");
        int W = 240, H = 200;
        int[] img = white(W, H);
        ring(img, W, H, 120, 100, 70, 3, 0xFF000000);
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(SKIN);
        k.cv.setFillPreview(false);
        tapFill(k, 120, 100);
        Layer base = k.project.layers.get(1);
        Layer sh = k.cv.addQuickShadeLayer(true);
        Sim.pump(30);
        log("   Sombra: \"" + sh.name + "\" " + Layer.MODE_NAMES[sh.mode] + " " + Math.round(sh.opacity * 100 / 255f) + "%, recorte=" + sh.clip
                + ", posicion " + k.project.layers.indexOf(sh) + ", color sugerido " + String.format("#%06X", k.cv.getColor() & 0xFFFFFF)
                + " (piel #FFDCC4), herramienta=" + (k.cv.getMode() == CanvasView.MODE_PAINT ? "Brocha" : "otra"));
        check(sh.clip && sh.mode == Layer.MODE_MULTIPLY && Math.abs(sh.opacity - 102) <= 1 && k.project.layers.indexOf(sh) == 2, "sombra rapida");
        // pintar la sombra a lo ancho (sale del circulo): fuera del color base no se ve
        int[] sp = sh.px();
        for (int y = 30; y < 90; y++) for (int x = 0; x < W; x++) sp[y * W + x] = k.cv.getColor() | 0xFF000000;
        k.cv.layersChanged();
        int[] out = Compositor.flatten(k.project);
        int outside = 0, inside = 0;
        int[] bp = base.px();
        for (int y = 30; y < 90; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                if ((bp[i] >>> 24) == 0 && out[i] != img[i]) outside++;
                if ((bp[i] >>> 24) != 0 && lum(img[i]) > 200 && lum(out[i]) < lum(mul(img[i], bp[i])) - 5) inside++;
            }
        log("   Sombra pintada a lo ancho: pixeles cambiados fuera del color base=" + outside + "; oscurecidos dentro=" + inside);
        check(outside == 0 && inside > 0, "recorte de sombra");
        Layer li = k.cv.addQuickShadeLayer(false);
        Sim.pump(20);
        log("   Luz: \"" + li.name + "\" " + Layer.MODE_NAMES[li.mode] + " " + Math.round(li.opacity * 100 / 255f) + "%, recorte=" + li.clip
                + ", color sugerido " + String.format("#%06X", k.cv.getColor() & 0xFFFFFF));
        check(li.clip && li.mode == Layer.MODE_SCREEN && Math.abs(li.opacity - 153) <= 1, "luz rapida");
        // cambiar color del color base: girar el tono (no destructivo)
        int[] pxBefore = base.px().clone();
        k.cv.commitLayerAdjust(base, new int[]{0, 0, 0}, 120, 10, 0);
        int[] out2 = Compositor.flatten(k.project);
        int changedBase = 0, halo = 0;
        for (int i = 0; i < out2.length; i++) {
            if ((bp[i] >>> 24) != 0 && lum(img[i]) > 200 && out2[i] != out[i]) changedBase++;
            if ((bp[i] >>> 24) == 0 && out2[i] != out[i]) halo++;
        }
        log("   Cambiar color (tono +120, sat +10): pixeles guardados de la capa iguales=" + Arrays.equals(pxBefore, base.px())
                + "; pixeles que cambian de color=" + changedBase + "; cambios fuera del color base (halo)=" + halo);
        check(Arrays.equals(pxBefore, base.px()) && changedBase > 0 && halo == 0, "cambiar color no destructivo");
        int c1 = ColorAdjust.adjustRgb(0xFFDCC4, 120, 10, 0);
        log(String.format("   Ejemplo: piel #FFDCC4 con tono +120 -> #%06X", c1));
        k.cv.doUndo();
        Sim.pump(30);
        log("   Deshacer: tono de la capa vuelve a " + base.hue);
        check(base.hue == 0, "deshacer cambiar color");
        save(out2, W, H, "P10_sombra_luz_tono.png");
    }

    // ------------------------------------------------------------------
    // P11 gotero Visible / Capa actual
    // ------------------------------------------------------------------

    static void p11picker() {
        log("== P11 Gotero sobre una trama gris con color en Multiplicar ==");
        int W = 40, H = 40;
        int[] img = new int[W * H];
        Arrays.fill(img, 0xFF999999);
        SimKit k = new SimKit(W, H, img);
        k.cv.prepareManga(0);
        Layer base = k.project.layers.get(1);
        Arrays.fill(base.px(), 0xFFFFDCC4);
        k.cv.layersChanged();
        k.cv.setPickSource(CanvasView.PICK_VISIBLE);
        int vis = k.cv.pickColorAt(10, 10);
        k.cv.setPickSource(CanvasView.PICK_LAYER);
        int lay = k.cv.pickColorAt(10, 10);
        k.cv.setPickSource(CanvasView.PICK_AUTO);
        int auto = k.cv.pickColorAt(10, 10);
        log(String.format("   Visible=#%06X (gris 99 x piel = #%06X), Capa actual=#%06X (la piel guardada), Automatico en Multiplicar=#%06X",
                vis & 0xFFFFFF, mul(0xFF999999, 0xFFFFDCC4) & 0xFFFFFF, lay & 0xFFFFFF, auto & 0xFFFFFF));
        check(maxCh(vis, mul(0xFF999999, 0xFFFFDCC4)) <= 1 && lay == 0xFFFFDCC4 && auto == 0xFFFFDCC4, "gotero");
        log("   Repintar con el color Visible oscureceria dos veces: #" + String.format("%06X", mul(0xFF999999, vis) & 0xFFFFFF));
    }

    // ------------------------------------------------------------------
    // P12 referencia -> muestra -> guardar -> reabrir
    // ------------------------------------------------------------------

    static void p12palette() throws Exception {
        log("== P12 Muestra de la referencia -> paleta de la obra -> guardar -> abrir ==");
        // promedio 3x3: 8 pixeles piel + 1 negro (borde de una linea)
        int[] cs = new int[9], ls = new int[9];
        for (int i = 0; i < 9; i++) { cs[i] = i == 4 ? 0xFF000000 : 0xFFF0C8A8 + (i % 3); ls[i] = lum(cs[i]); }
        int avg = ReferenceImageView.average(cs, ls, 9);
        log(String.format("   Promedio 3x3 con un pixel negro al lado: #%06X (sin el negro; piel #F0C8A8)", avg & 0xFFFFFF));
        check(maxCh(avg, 0xFFF0C8A9) <= 1, "promedio 3x3");
        Project p = new Project(8, 8);
        p.layers.add(new Layer("a", 8, 8));
        p.swatches.add(new Project.Swatch("Piel", 0xFFF0C8A9));
        p.swatches.add(new Project.Swatch("Sombra piel", 0xFFC89A88));
        p.swatches.add(new Project.Swatch("Cabello", 0x80223344));
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ProjectIO.save(bo, p, 0xFF112233);
        Project q = ProjectIO.load(new ByteArrayInputStream(bo.toByteArray())).project;
        boolean same = q.swatches.size() == 3;
        for (int i = 0; same && i < 3; i++) same = q.swatches.get(i).color == p.swatches.get(i).color && q.swatches.get(i).name.equals(p.swatches.get(i).name);
        log("   Paleta despues de guardar y abrir: " + q.swatches.size() + " muestras, nombres y colores identicos=" + same
                + " (incluye una con opacidad 50%)");
        check(same, "paleta");
    }

    // ------------------------------------------------------------------
    // P13 quitar la referencia: la exportacion no cambia
    // ------------------------------------------------------------------

    static void p13reference() throws Exception {
        log("== P13 Referencia guardada con la obra vs sin referencia ==");
        int W = 50, H = 40;
        int[] img = white(W, H);
        ring(img, W, H, 25, 20, 12, 2, 0xFF000000);
        SimKit k = new SimKit(W, H, img);
        k.cv.prepareManga(0);
        Arrays.fill(k.project.layers.get(1).px(), 0, 400, 0xFFFF8080);
        ByteArrayOutputStream a = new ByteArrayOutputStream();
        Exporter.writeFlattened(k.project, W, H, a);
        BufferedImage ref = new BufferedImage(30, 20, BufferedImage.TYPE_INT_ARGB);
        ByteArrayOutputStream rp = new ByteArrayOutputStream();
        ImageIO.write(ref, "png", rp);
        k.project.refImagePng = rp.toByteArray();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        Exporter.writeFlattened(k.project, W, H, b);
        int layers = k.project.layers.size();
        ByteArrayOutputStream pf = new ByteArrayOutputStream();
        ProjectIO.save(pf, k.project, 0);
        Project q = ProjectIO.load(new ByteArrayInputStream(pf.toByteArray())).project;
        k.project.refImagePng = null;
        ByteArrayOutputStream c = new ByteArrayOutputStream();
        Exporter.writeFlattened(k.project, W, H, c);
        int[] ia = ImageIO.read(new ByteArrayInputStream(a.toByteArray())).getRGB(0, 0, W, H, null, 0, W);
        int[] ib = ImageIO.read(new ByteArrayInputStream(b.toByteArray())).getRGB(0, 0, W, H, null, 0, W);
        int[] ic = ImageIO.read(new ByteArrayInputStream(c.toByteArray())).getRGB(0, 0, W, H, null, 0, W);
        log("   PNG sin referencia = con referencia: " + Arrays.equals(ia, ib) + "; despues de quitarla: " + Arrays.equals(ia, ic)
                + "; capas=" + layers + " (la referencia no es capa); copia reducida guardada y reabierta: "
                + (q.refImagePng != null && q.refImagePng.length == rp.size()));
        check(Arrays.equals(ia, ib) && Arrays.equals(ia, ic) && layers == 2 && q.refImagePng != null, "referencia");
    }

    // ------------------------------------------------------------------
    // P14 lazo vs balde en una linea abierta
    // ------------------------------------------------------------------

    static void p14lasso() throws Exception {
        log("== P14 Contorno con una abertura de 30 px: balde vs Lazo + Rellenar seleccion ==");
        int W = 260, H = 200;
        int[] img = white(W, H);
        ring(img, W, H, 120, 100, 60, 3, 0xFF000000);
        for (int y = 30; y < 75; y++) for (int x = 170; x < 200; x++) img[y * W + x] = 0xFFFFFFFF; // abertura
        boolean[] gt = new boolean[W * H];
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) gt[y * W + x] = Math.hypot(x + .5 - 120, y + .5 - 100) < 58;
        int gtN = 0;
        for (boolean b : gt) if (b) gtN++;
        // balde
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(SKIN);
        k.cv.setMangaGapLevel(3);
        long t0 = System.nanoTime();
        tapFill(k, 120, 100);
        k.cv.acceptFillPreview();
        long tb = (System.nanoTime() - t0) / 1_000_000L;
        int[] bp = k.project.layers.get(1).px();
        int in = 0, out = 0;
        for (int i = 0; i < bp.length; i++) if ((bp[i] >>> 24) != 0) { if (gt[i]) in++; else if (lum(img[i]) > 200) out++; }
        log(String.format("   Balde (cerrar huecos Grande): cubre %.1f%%, derrame fuera=%d px, %d ms", 100f * in / gtN, out, tb));
        // lazo: un trazo alrededor del circulo
        SimKit k2 = new SimKit(W, H, img.clone());
        k2.cv.prepareManga(0);
        k2.cv.setMode(CanvasView.MODE_LASSO);
        float[][] pts = new float[49][];
        for (int i = 0; i <= 48; i++) {
            double a = i * Math.PI * 2 / 48;
            pts[i] = new float[]{(float) (120 + 60 * Math.cos(a)), (float) (100 + 60 * Math.sin(a))};
        }
        t0 = System.nanoTime();
        k2.stroke(pts, 600, 2);
        // La simulacion no dibuja Path (Canvas vacio): la seleccion del Lazo se arma aqui con
        // el mismo poligono y antialias 4x4, como lo haria Android.
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int c = 0;
                for (int sy = 0; sy < 4; sy++) for (int sx = 0; sx < 4; sx++)
                    if (inPoly(pts, x + (sx + .5f) / 4f, y + (sy + .5f) / 4f)) c++;
                k2.project.selection[y * W + x] = (byte) Math.min(255, c * 16);
            }
        k2.cv.setColor(SKIN);
        k2.cv.fillSelectionWithColor();
        long tl = (System.nanoTime() - t0) / 1_000_000L;
        bp = k2.project.layers.get(1).px();
        in = 0;
        out = 0;
        for (int i = 0; i < bp.length; i++) if ((bp[i] >>> 24) != 0) { if (gt[i]) in++; else if (lum(img[i]) > 200) out++; }
        log(String.format("   Lazo + Rellenar seleccion: cubre %.1f%%, derrame fuera=%d px (lo que dibuja el dedo), trazo simulado de 600 ms", 100f * in / gtN, out));
        check(in > gtN * .97, "lazo cubre");
    }

    static boolean inPoly(float[][] p, float x, float y) {
        boolean in = false;
        for (int i = 0, j = p.length - 1; i < p.length; j = i++)
            if ((p[i][1] > y) != (p[j][1] > y) && x < (p[j][0] - p[i][0]) * (y - p[i][1]) / (p[j][1] - p[i][1]) + p[i][0]) in = !in;
        return in;
    }

    // ------------------------------------------------------------------
    // P15 guardar/abrir y P16 deshacer/rehacer propiedades
    // ------------------------------------------------------------------

    static void p15p16saveUndo() throws Exception {
        log("== P15 Guardar y abrir la obra ==");
        int W = 80, H = 60;
        int[] img = white(W, H);
        ring(img, W, H, 40, 30, 20, 2, 0xFF000000);
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        Layer base = k.project.layers.get(1);
        Arrays.fill(base.px(), 0, 1200, 0xFF80C0FF);
        Layer sh = k.cv.addQuickShadeLayer(true);
        Arrays.fill(sh.px(), 600, 1600, 0xFF404080);
        sh.alphaLock = true;
        base.hue = 30;
        base.sat = -20;
        base.lit = 5;
        k.project.protect = new byte[W * H];
        k.project.protect[5] = 1;
        k.project.swatches.add(new Project.Swatch("Piel", 0xFFFFDCC4));
        int[] before = Compositor.flatten(k.project);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ProjectIO.save(bo, k.project, 0xFF00FF00);
        Project q = ProjectIO.load(new ByteArrayInputStream(bo.toByteArray())).project;
        boolean ok = q.layers.size() == 3 && q.mangaMode;
        String[] what = new String[3];
        for (int i = 0; ok && i < 3; i++) {
            Layer x = k.project.layers.get(i), y = q.layers.get(i);
            ok = x.name.equals(y.name) && x.mode == y.mode && x.opacity == y.opacity && x.clip == y.clip && x.alphaLock == y.alphaLock
                    && x.reference == y.reference && x.locked == y.locked && x.role == y.role && x.hue == y.hue && x.sat == y.sat && x.lit == y.lit;
            what[i] = y.name + " " + Layer.MODE_NAMES[y.mode] + " " + y.opacity + (y.clip ? " recorte" : "") + (y.locked ? " bloqueada" : "")
                    + (y.alphaLock ? " alfa" : "") + (y.reference ? " ref" : "") + (y.hasAdjust() ? " HSL(" + y.hue + "," + y.sat + "," + y.lit + ")" : "");
        }
        int[] after = Compositor.flatten(q);
        log("   Capas al abrir: " + Arrays.toString(what) + "; modo manga=" + q.mangaMode + "; zona protegida=" + (q.protect != null && q.protect[5] == 1)
                + "; paleta=" + q.swatches.size() + "; imagen identica pixel a pixel=" + Arrays.equals(before, after));
        check(ok && Arrays.equals(before, after) && q.protect != null && q.protect[5] == 1, "guardar/abrir");

        log("== P16 Deshacer / Rehacer propiedades de capa y el preset ==");
        SimKit u = new SimKit(W, H, img.clone());
        u.cv.prepareManga(0);
        Layer b2 = u.project.layers.get(1);
        u.cv.setLayerMode(b2, Layer.MODE_COLOR);
        u.cv.setLayerClip(b2, true);
        u.cv.setLayerLocked(b2, true);
        u.cv.recordPropsUndo("Opacidad");
        b2.opacity = 77;
        boolean s1 = b2.mode == Layer.MODE_COLOR && b2.clip && b2.locked && b2.opacity == 77;
        u.cv.doUndo(); Sim.pump(20);
        boolean o1 = b2.opacity == 255 && b2.locked;
        u.cv.doUndo(); Sim.pump(20);
        boolean l1 = !b2.locked && b2.clip;
        u.cv.doUndo(); Sim.pump(20);
        boolean c1 = !b2.clip && b2.mode == Layer.MODE_COLOR;
        u.cv.doUndo(); Sim.pump(20);
        boolean m1 = b2.mode == Layer.MODE_MULTIPLY;
        u.cv.doUndo(); Sim.pump(20);
        boolean p1 = u.project.layers.size() == 1 && !u.project.layers.get(0).locked && u.project.layers.get(0).name.equals("imagen") && !u.project.mangaMode;
        u.cv.doRedo(); Sim.pump(20);
        boolean r1 = u.project.layers.size() == 2 && u.project.layers.get(0).locked && u.project.mangaMode;
        u.cv.doRedo(); Sim.pump(20);
        u.cv.doRedo(); Sim.pump(20);
        boolean r2 = b2.mode == Layer.MODE_COLOR && b2.clip;
        log("   Opacidad=" + o1 + ", bloqueo=" + l1 + ", recorte=" + c1 + ", modo=" + m1 + ", preset deshecho (1 capa \"imagen\" sin bloqueo)=" + p1
                + ", rehacer preset=" + r1 + ", rehacer modo+recorte=" + r2);
        check(s1 && o1 && l1 && c1 && m1 && p1 && r1 && r2, "deshacer propiedades");
    }

    // ------------------------------------------------------------------
    // P17 zoom 400-800 %: franja clara entre color y linea
    // ------------------------------------------------------------------

    static void p17zoom() throws Exception {
        log("== P17 Borde entre color y linea antialias (como al hacer zoom 800%) ==");
        int W = 200, H = 200;
        int[] img = white(W, H);
        ring(img, W, H, 100, 100, 70, 2.2f, 0xFF000000);
        for (int ex = 0; ex <= 2; ex += 2) {
            SimKit k = new SimKit(W, H, img.clone());
            k.cv.prepareManga(0);
            k.cv.setMangaExpand(ex);
            k.cv.setFillPreview(false);
            k.cv.setMode(CanvasView.MODE_BUCKET);
            k.cv.setColor(0xFFE05050);
            tapFill(k, 100, 100);
            int[] out = Compositor.flatten(k.project);
            int[] bp = k.project.layers.get(1).px();
            // de adentro hacia el centro de la linea: pixeles "claros sin color" antes del centro
            int light = 0, rays = 0;
            for (int a = 0; a < 360; a += 3) {
                double rad = Math.toRadians(a);
                for (double r = 60; r <= 70; r += .5) {
                    int x = (int) (100 + r * Math.cos(rad)), y = (int) (100 + r * Math.sin(rad));
                    int i = y * W + x;
                    if (lum(img[i]) < 40) break; // llego al centro oscuro
                    if ((bp[i] >>> 24) == 0 && lum(img[i]) > 60) { light++; break; }
                }
                rays++;
            }
            log("   Color bajo la linea " + ex + " px: rayos (de " + rays + ") con un pixel sin color antes del centro de la linea=" + light);
            if (ex == 2) check(light == 0, "sin franja clara");
            if (ex == 2) save(crop(out, W, 155, 85, 30, 30, 12), 360, 360, "P17_zoom1200_borde.png");
        }
    }

    // ------------------------------------------------------------------
    // P19 dos dedos durante la vista previa
    // ------------------------------------------------------------------

    static void p19multitouch() throws Exception {
        log("== P19 Dos dedos (mover/zoom) con la vista previa abierta ==");
        int W = 200, H = 160;
        int[] img = white(W, H);
        ring(img, W, H, 100, 80, 50, 3, 0xFF000000);
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(SKIN);
        tapFill(k, 100, 80);
        int zones = k.cv.fillPreviewCount();
        int[] base0 = k.project.layers.get(1).px().clone();
        for (int rep = 0; rep < 30; rep++) {
            float[] a1 = k.screen(20, 20), b1 = k.screen(180, 140);
            k.touch(MotionEvent.ACTION_DOWN, a1);
            Sim.pump(5);
            k.cv.onTouchEvent(new MotionEvent(MotionEvent.ACTION_POINTER_DOWN, new float[]{a1[0], b1[0]}, new float[]{a1[1], b1[1]}, null, null, null,
                    android.os.SystemClock.uptimeMillis()).withPointers(new int[]{0, 1}, 1));
            for (int s = 0; s < 6; s++) {
                Sim.pump(16);
                k.cv.onTouchEvent(new MotionEvent(MotionEvent.ACTION_MOVE, new float[]{a1[0] + s * 4, b1[0] + s * 7}, new float[]{a1[1] + s * 3, b1[1] - s * 2},
                        null, null, null, android.os.SystemClock.uptimeMillis()).withPointers(new int[]{0, 1}, 0));
            }
            k.cv.onTouchEvent(new MotionEvent(MotionEvent.ACTION_POINTER_UP, new float[]{a1[0], b1[0]}, new float[]{a1[1], b1[1]}, null, null, null,
                    android.os.SystemClock.uptimeMillis()).withPointers(new int[]{0, 1}, 1));
            k.touch(MotionEvent.ACTION_UP, a1);
            waitIdle(k);
        }
        boolean same = Arrays.equals(base0, k.project.layers.get(1).px());
        log("   30 gestos de dos dedos: zonas en la vista previa " + zones + " -> " + k.cv.fillPreviewCount() + "; capa sin cambios=" + same);
        check(same && k.cv.fillPreviewCount() == zones, "multitoque");
        k.cv.cancelFillPreview();
        log("   Cancelar: zonas=" + k.cv.fillPreviewCount() + ", capa sin cambios=" + Arrays.equals(base0, k.project.layers.get(1).px()));
        check(k.cv.fillPreviewCount() == 0 && Arrays.equals(base0, k.project.layers.get(1).px()), "cancelar");
    }

    // ------------------------------------------------------------------
    // Bloqueo total y que las demas herramientas sigan igual
    // ------------------------------------------------------------------

    static void lockAndTools() throws Exception {
        log("== Bloqueo total de la Tinta y herramientas de siempre ==");
        int W = 160, H = 120;
        int[] img = white(W, H);
        ring(img, W, H, 80, 60, 40, 3, 0xFF000000);
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.prepareManga(0);
        k.cv.setActive(0);
        k.cv.setMode(CanvasView.MODE_PAINT);
        k.cv.setColor(0xFFFF0000);
        k.stroke(new float[][]{{10, 10}, {150, 110}}, 300, 2);
        boolean inkSame = Arrays.equals(img, k.project.layers.get(0).px());
        k.cv.setMode(CanvasView.MODE_ERASER);
        k.stroke(new float[][]{{10, 110}, {150, 10}}, 300, 2);
        inkSame &= Arrays.equals(img, k.project.layers.get(0).px());
        k.cv.setMode(CanvasView.MODE_MOVE);
        k.stroke(new float[][]{{60, 60}, {90, 70}}, 300, 2);
        inkSame &= Arrays.equals(img, k.project.layers.get(0).px());
        k.cv.clearActive();
        inkSame &= Arrays.equals(img, k.project.layers.get(0).px());
        log("   Brocha, goma, mover y limpiar sobre la Tinta bloqueada: tinta intacta=" + inkSame);
        check(inkSame, "bloqueo total");
        // en el Color base la brocha pinta normal
        k.cv.setActive(1);
        k.cv.setMode(CanvasView.MODE_PAINT);
        k.stroke(new float[][]{{20, 60}, {140, 60}}, 300, 2);
        int painted = 0;
        for (int c : k.project.layers.get(1).px()) if ((c >>> 24) != 0) painted++;
        log("   Brocha en \"Color base\": pixeles pintados=" + painted);
        check(painted > 100, "brocha en color base");
        // balde normal fuera del preset no cambia
        k.cv.exitManga();
        log("   Salir del preset: modo manga=" + k.project.mangaMode + ", tinta bloqueada=" + k.project.layers.get(0).locked);
        check(!k.project.mangaMode && !k.project.layers.get(0).locked, "salir");
    }

    // ------------------------------------------------------------------
    // P18 pagina grande (solo JVM)
    // ------------------------------------------------------------------

    static void p18memory() {
        log("== P18 Pagina A4 300 ppp (2480x3508) con 6 capas: memoria en la JVM (NO es un telefono) ==");
        int W = 2480, H = 3508;
        Runtime rt = Runtime.getRuntime();
        System.gc();
        long m0 = rt.totalMemory() - rt.freeMemory();
        int[] img = white(W, H);
        for (int k = 0; k < 40; k++) ring(img, W, H, 200 + (k % 8) * 280, 300 + (k / 8) * 650, 120, 4, 0xFF000000);
        Project p = new Project(W, H);
        p.layers.add(new Layer("tinta", img));
        for (int i = 0; i < 5; i++) {
            Layer l = new Layer("c" + i, W, H);
            l.mode = Layer.MODE_MULTIPLY;
            p.layers.add(l);
        }
        MangaFill.Params pr = new MangaFill.Params();
        long t0 = System.nanoTime();
        byte[] line = MangaFill.lineMap(img, W, H, pr);
        long t1 = System.nanoTime();
        byte[] out = new byte[W * H];
        MangaFill.Result r = MangaFill.compute(img, line, W, H, 200, 300, pr, out);
        long t2 = System.nanoTime();
        long m1 = rt.totalMemory() - rt.freeMemory();
        log(String.format("   Mapa de tinta %d ms, zona %d ms (%d px), memoria usada en la prueba ~%d MB (imagen 35 MB + mapa 9 MB + mascara 9 MB)",
                (t1 - t0) / 1_000_000, (t2 - t1) / 1_000_000, r == null ? 0 : r.area, (m1 - m0) >> 20));
        log("   Pendiente: medir en un telefono de 2-3 GB (Android Studio Profiler); aqui no hay telefono.");
    }
}
