package android.view;
/** MotionEvent construible para pruebas: puntero(s) actuales + historial del puntero 0. */
public final class MotionEvent { public static final int ACTION_DOWN=0,ACTION_UP=1,ACTION_MOVE=2,ACTION_CANCEL=3,ACTION_POINTER_DOWN=5,ACTION_POINTER_UP=6,ACTION_MASK=255,ACTION_HOVER_MOVE=7,TOOL_TYPE_STYLUS=2,TOOL_TYPE_FINGER=1;
  final int action; final float[] xs, ys; final float[] hx, hy; final long[] ht; final long time; int[] ids; int actionIndex;
  /** Simulacion: ids de puntero y dedo que cambia (POINTER_DOWN/UP). */
  public MotionEvent withPointers(int[] ids, int actionIndex){ this.ids=ids; this.actionIndex=actionIndex; return this; }
  public MotionEvent(int action, float[] xs, float[] ys, float[] hx, float[] hy, long[] ht, long time){this.action=action;this.xs=xs;this.ys=ys;this.hx=hx==null?new float[0]:hx;this.hy=hy==null?new float[0]:hy;this.ht=ht==null?new long[0]:ht;this.time=time;}
  public int getAction(){return action;} public int getActionMasked(){return action&255;} public int getActionIndex(){return actionIndex;} public int getPointerCount(){return xs.length;} public int getPointerId(int i){return ids==null?i:ids[i];} public int findPointerIndex(int id){ if(ids==null) return id<xs.length?id:-1; for(int i=0;i<ids.length;i++) if(ids[i]==id) return i; return -1;}
  public float getX(){return xs[0];} public float getY(){return ys[0];} public float getX(int i){return xs[i];} public float getY(int i){return ys[i];} public float getRawX(){return xs[0];} public float getRawY(){return ys[0];}
  public int getHistorySize(){return hx.length;} public float getHistoricalX(int p,int h){return hx[h];} public float getHistoricalY(int p,int h){return hy[h];} public float getHistoricalX(int h){return hx[h];} public float getHistoricalY(int h){return hy[h];} public long getHistoricalEventTime(int h){return ht[h];}
  public long getEventTime(){return time;} public long getDownTime(){return 0;} public float getPressure(){return 1;} public float getPressure(int i){return 1;} public int getToolType(int i){return 1;} public float getHistoricalPressure(int p,int h){return 1;} }
