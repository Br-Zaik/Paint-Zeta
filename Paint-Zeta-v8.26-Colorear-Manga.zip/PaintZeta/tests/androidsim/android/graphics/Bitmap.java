package android.graphics;
/** Bitmap funcional respaldado por int[] (solo pruebas JVM). */
public final class Bitmap {
  public enum Config {ARGB_8888, ALPHA_8, RGB_565, ARGB_4444, HARDWARE}
  public enum CompressFormat {PNG, JPEG, WEBP}
  final int w, h; final int[] px; boolean recycled; Config cfg;
  Bitmap(int w,int h,Config c){this.w=w;this.h=h;this.px=new int[Math.max(1,w*h)];cfg=c;}
  public static Bitmap createBitmap(int w,int h,Config c){return new Bitmap(w,h,c);}
  public static Bitmap createBitmap(Bitmap b){Bitmap r=new Bitmap(b.w,b.h,b.cfg);System.arraycopy(b.px,0,r.px,0,b.px.length);return r;}
  public static Bitmap createBitmap(Bitmap b,int x,int y,int w,int h){Bitmap r=new Bitmap(w,h,b.cfg);for(int j=0;j<h;j++)System.arraycopy(b.px,(y+j)*b.w+x,r.px,j*w,w);return r;}
  public static Bitmap createBitmap(int[] c,int w,int h,Config cf){Bitmap r=new Bitmap(w,h,cf);System.arraycopy(c,0,r.px,0,w*h);return r;}
  public static Bitmap createBitmap(int[] c,int o,int s,int w,int h,Config cf){Bitmap r=new Bitmap(w,h,cf);for(int j=0;j<h;j++)System.arraycopy(c,o+j*s,r.px,j*w,w);return r;}
  public static Bitmap createBitmap(Bitmap b,int x,int y,int w,int h,Matrix m,boolean f){return createBitmap(b,x,y,w,h);}
  public static Bitmap createScaledBitmap(Bitmap b,int w,int h,boolean f){Bitmap r=new Bitmap(w,h,b.cfg);for(int j=0;j<h;j++)for(int i=0;i<w;i++)r.px[j*w+i]=b.px[Math.min(b.h-1,j*b.h/h)*b.w+Math.min(b.w-1,i*b.w/w)];return r;}
  public int getWidth(){return w;} public int getHeight(){return h;} public void recycle(){recycled=true;} public boolean isRecycled(){return recycled;}
  public void setPixels(int[] p,int o,int s,int x,int y,int ww,int hh){for(int j=0;j<hh;j++)System.arraycopy(p,o+j*s,px,(y+j)*w+x,ww);}
  public void getPixels(int[] p,int o,int s,int x,int y,int ww,int hh){for(int j=0;j<hh;j++)System.arraycopy(px,(y+j)*w+x,p,o+j*s,ww);}
  public int getPixel(int x,int y){return px[y*w+x];} public void setPixel(int x,int y,int c){px[y*w+x]=c;} public void eraseColor(int c){java.util.Arrays.fill(px,c);} public void setPremultiplied(boolean p){} public boolean isPremultiplied(){return false;}
  public Bitmap copy(Config c,boolean m){return createBitmap(this);} public Config getConfig(){return cfg;} public boolean compress(CompressFormat f,int q,java.io.OutputStream o){
    // PNG real con el codec de Java (para probar guardar/abrir/exportar en JVM)
    try { java.awt.image.BufferedImage bi=new java.awt.image.BufferedImage(w,h,java.awt.image.BufferedImage.TYPE_INT_ARGB); bi.setRGB(0,0,w,h,px,0,w);
      return javax.imageio.ImageIO.write(bi,"png",o); } catch(java.io.IOException e){return false;} }
  public boolean hasAlpha(){return true;} public void setHasAlpha(boolean b){} public int getByteCount(){return w*h*4;} public int getAllocationByteCount(){return w*h*4;} public boolean isMutable(){return true;} public int getRowBytes(){return w*4;}
  public void copyPixelsToBuffer(java.nio.Buffer b){} public void copyPixelsFromBuffer(java.nio.Buffer b){} public Bitmap extractAlpha(){return createBitmap(this);}
}
