package android.graphics;
public class BitmapFactory {
  public static class Options { public boolean inJustDecodeBounds, inMutable, inPremultiplied; public int outWidth, outHeight, inSampleSize; public Bitmap.Config inPreferredConfig; }
  public static Bitmap decodeStream(java.io.InputStream s){ try { java.awt.image.BufferedImage bi=javax.imageio.ImageIO.read(s); if(bi==null)return null; int w=bi.getWidth(),h=bi.getHeight(); int[] p=new int[w*h]; bi.getRGB(0,0,w,h,p,0,w); return Bitmap.createBitmap(p,w,h,Bitmap.Config.ARGB_8888);} catch(java.io.IOException e){return null;} } public static Bitmap decodeStream(java.io.InputStream s, Rect r, Options o){return null;}
  public static Bitmap decodeFile(String f){return null;} public static Bitmap decodeFile(String f, Options o){return null;}
  public static Bitmap decodeByteArray(byte[] b,int o,int l){return decodeStream(new java.io.ByteArrayInputStream(b,o,l));} public static Bitmap decodeByteArray(byte[] b,int o,int l, Options op){Bitmap r=decodeByteArray(b,o,l); if(op!=null&&r!=null){op.outWidth=r.getWidth();op.outHeight=r.getHeight();} return op!=null&&op.inJustDecodeBounds?null:r;}
}
