import android.os.Sim;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.view.CanvasView;

/**
 * Pruebas del BALDE (v8.24) con el CanvasView real en Android simulado.
 * Cada prueba imprime numeros; con -Dnoassert=1 se puede correr sobre versiones
 * anteriores para comparar. Con -Ddump=carpeta guarda las imagenes resultantes.
 */
public final class BucketTest {
    static void log(String s) { System.out.println(s); }

    static int lum(int c) {
        int a = c >>> 24;
        if (a < 255) {
            int r = (((c >> 16) & 255) * a + 255 * (255 - a)) / 255, g = (((c >> 8) & 255) * a + 255 * (255 - a)) / 255, b = ((c & 255) * a + 255 * (255 - a)) / 255;
            c = (r << 16) | (g << 8) | b;
        }
        return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
    }

    // ---------------- imagenes ----------------

    /** Trazo de pincel (capsula) con antialias del color ink sobre lo que haya. */
    static void stroke(int[] px, int w, int h, float ax, float ay, float bx, float by, float r, int ink) {
        int x0 = (int) Math.max(0, Math.min(ax, bx) - r - 2), x1 = (int) Math.min(w - 1, Math.max(ax, bx) + r + 2);
        int y0 = (int) Math.max(0, Math.min(ay, by) - r - 2), y1 = (int) Math.min(h - 1, Math.max(ay, by) + r + 2);
        float vx = bx - ax, vy = by - ay, l2 = Math.max(1e-6f, vx * vx + vy * vy);
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
            float t = Math.max(0, Math.min(1, ((x + .5f - ax) * vx + (y + .5f - ay) * vy) / l2));
            float d = (float) Math.hypot(x + .5f - ax - vx * t, y + .5f - ay - vy * t);
            float c = Math.max(0, Math.min(1, r + .5f - d));
            if (c <= 0) continue;
            px[y * w + x] = mix(px[y * w + x], ink, c);
        }
    }

    static int mix(int a, int b, float t) {
        int aa = a >>> 24, ba = b >>> 24;
        float al = aa * (1 - t) + ba * t;
        if (al <= 0) return 0;
        float wa = aa * (1 - t) / al, wb = ba * t / al;
        int r = Math.round(((a >> 16) & 255) * wa + ((b >> 16) & 255) * wb);
        int g = Math.round(((a >> 8) & 255) * wa + ((b >> 8) & 255) * wb);
        int bl = Math.round((a & 255) * wa + (b & 255) * wb);
        return (Math.round(al) << 24) | (r << 16) | (g << 8) | bl;
    }

    static final int W = 360, H = 300;

    /** Como la captura 1: trazos gruesos de pincel tipo kanji, rincones agudos y huecos de 2 a 7 px. */
    static int[] kanji() {
        int[] p = new int[W * H];
        java.util.Arrays.fill(p, 0xFFFFFFFF);
        int k = 0xFF000000;
        stroke(p, W, H, 20, 150, 110, 40, 9, k);
        stroke(p, W, H, 60, 120, 60, 280, 8, k);
        stroke(p, W, H, 15, 175, 125, 160, 8, k);
        stroke(p, W, H, 45, 200, 10, 260, 7, k);
        stroke(p, W, H, 75, 200, 120, 245, 7, k);
        stroke(p, W, H, 180, 30, 180, 120, 8, k);
        stroke(p, W, H, 140, 60, 250, 52, 8, k);
        stroke(p, W, H, 145, 80, 145, 150, 8, k);
        stroke(p, W, H, 145, 150, 240, 150, 8, k);
        stroke(p, W, H, 240, 85, 240, 150, 8, k);
        stroke(p, W, H, 152, 85, 233, 85, 7, k);
        stroke(p, W, H, 152, 118, 233, 118, 7, k);
        stroke(p, W, H, 160, 175, 230, 230, 8, k);
        stroke(p, W, H, 252, 168, 300, 200, 8, k);
        stroke(p, W, H, 100, 270, 330, 250, 9, k);
        return p;
    }

    /** Anime ya coloreado: piel con sombra suave, pelo oscuro, camisa de color parecido sin linea, contorno marron. */
    static int[] anime() {
        int[] p = new int[W * H];
        java.util.Arrays.fill(p, 0xFFD8E8F8);                                   // fondo celeste
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            float d = (float) Math.hypot(x + .5 - 170, y + .5 - 130);
            if (d < 90) {
                int skin = 0xFFF8D8C0, shadow = 0xFFD8A890;
                float t = Math.max(0, Math.min(1, (x + .5f - 190) / 1.5f + .5f)); // sombra a la derecha, borde de 1,5 px (cel)
                p[y * W + x] = mix(skin, shadow, t);
            }
            if (d < 90 && y < 75) p[y * W + x] = 0xFF303860;                    // pelo
            if (y >= 232 && x > 60 && x < 300) p[y * W + x] = 0xFFF0E4D8;      // camisa (parecida a la piel)
        }
        int ink = 0xFF402010;
        for (int a = 0; a < 360; a += 2) {
            double r0 = Math.toRadians(a), r1 = Math.toRadians(a + 2);
            stroke(p, W, H, (float) (170 + 90 * Math.cos(r0)), (float) (130 + 90 * Math.sin(r0)),
                    (float) (170 + 90 * Math.cos(r1)), (float) (130 + 90 * Math.sin(r1)), 1.1f, ink);
        }
        stroke(p, W, H, 95, 75, 245, 75, 1.0f, ink);                            // linea pelo/piel
        return p;
    }

    static int[] jpeg(int[] px, float q) throws Exception {
        java.awt.image.BufferedImage bi = new java.awt.image.BufferedImage(W, H, java.awt.image.BufferedImage.TYPE_INT_RGB);
        bi.setRGB(0, 0, W, H, px, 0, W);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        javax.imageio.ImageWriter wr = javax.imageio.ImageIO.getImageWritersByFormatName("jpeg").next();
        javax.imageio.ImageWriteParam pr = wr.getDefaultWriteParam();
        pr.setCompressionMode(javax.imageio.ImageWriteParam.MODE_EXPLICIT);
        pr.setCompressionQuality(q);
        wr.setOutput(new javax.imageio.stream.MemoryCacheImageOutputStream(bo));
        wr.write(null, new javax.imageio.IIOImage(bi, null, null), pr);
        java.awt.image.BufferedImage r = javax.imageio.ImageIO.read(new java.io.ByteArrayInputStream(bo.toByteArray()));
        int[] out = new int[W * H];
        r.getRGB(0, 0, W, H, out, 0, W);
        for (int i = 0; i < out.length; i++) out[i] |= 0xFF000000;
        return out;
    }

    static void dump(int[] px, String name) {
        String d = System.getProperty("dump");
        if (d == null) return;
        java.awt.image.BufferedImage bi = new java.awt.image.BufferedImage(W, H, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        bi.setRGB(0, 0, W, H, px, 0, W);
        try { javax.imageio.ImageIO.write(bi, "png", new java.io.File(d, name + ".png")); } catch (Exception e) { }
    }

    // ---------------- medidas ----------------

    /** Papel sin pintar en manchas chicas (menos de 150 px) pegadas a lo pintado: rincones/motas blancas. */
    static int smallUnpainted(int[] orig, int[] after) {
        int n = orig.length, bad = 0;
        byte[] seen = new byte[n];
        int[] st = new int[n];
        for (int s = 0; s < n; s++) {
            if (seen[s] != 0 || !(lum(orig[s]) > 180 && after[s] == orig[s])) continue;
            int sp = 0, cnt = 0;
            boolean touches = false;
            st[sp++] = s; seen[s] = 1;
            java.util.ArrayList<Integer> comp = new java.util.ArrayList<>();
            while (sp > 0) {
                int i = st[--sp]; cnt++;
                int x = i % W, y = i / W;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
                    int j = yy * W + xx;
                    if (after[j] != orig[j] && lum(orig[j]) > 180) touches = true;
                    if (Math.abs(dx) + Math.abs(dy) != 1) continue;
                    if (seen[j] == 0 && lum(orig[j]) > 180 && after[j] == orig[j]) { seen[j] = 1; st[sp++] = j; }
                }
            }
            if (cnt < 150 && touches) bad += cnt;
        }
        return bad;
    }

    /** Pixeles de linea (oscuros) que quedaron mas claros: linea tapada o adelgazada. */
    static int lineLightened(int[] orig, int[] after) {
        int n = 0;
        for (int i = 0; i < orig.length; i++) if (lum(orig[i]) < 80 && lum(after[i]) > lum(orig[i]) + 25) n++;
        return n;
    }

    static SimKit kit(int[] img) {
        SimKit k = new SimKit(W, H, img.clone());
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setFillTolerance(Integer.parseInt(System.getProperty("tol", "20")));
        k.cv.setFillAllLayers(true);
        k.cv.setFillToLine(true);
        k.cv.setFillExpansion(2f);
        k.cv.setColor(0xFF5BA860);
        tryCall(k, "setFillColorLayer", false); // estas pruebas miran la capa tocada
        return k;
    }

    static void tryCall(SimKit k, String m, Object... a) { try { k.call(m, a); } catch (RuntimeException e) { } }

    // ---------------- pruebas ----------------

    static void thick() throws Exception {
        for (int jp = 0; jp < 2; jp++) {
            int[] img = jp == 0 ? kanji() : jpeg(kanji(), .5f);
            SimKit k = kit(img);
            k.tap(330, 20);
            int[] after = k.project.ref();
            dump(after, "kanji" + (jp == 0 ? "" : "_jpg"));
            int small = smallUnpainted(img, after), light = lineLightened(img, after);
            log("   Trazos gruesos tipo kanji" + (jp == 0 ? "" : " (JPEG)") + ": papel sin pintar en rincones/motas=" + small + " px, linea aclarada=" + light);
            SimKit.check(small <= 4 && light == 0, "rincones blancos o lineas tapadas con trazos gruesos");
        }
    }

    static void colored() throws Exception {
        for (int jp = 0; jp < 2; jp++) {
            int[] img = jp == 0 ? anime() : jpeg(anime(), .6f);
            // plano
            SimKit k = kit(img);
            k.cv.setColor(0xFFE05050);
            k.tap(150, 130);   // piel iluminada
            int[] a = k.project.ref();
            dump(a, "anime_plano" + (jp == 0 ? "" : "_jpg"));
            int shirt = 0, hair = 0, sky = 0, flat = 0, inner = 0, seam = 0, light = lineLightened(img, a);
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                int i = y * W + x;
                double d = Math.hypot(x + .5 - 170, y + .5 - 130);
                if (y >= 236 && x > 64 && x < 296 && a[i] != img[i]) shirt++;
                if (d < 86 && y < 71 && a[i] != img[i]) hair++;
                if (d > 95 && y < 228 && a[i] != img[i]) sky++;
                if (d < 84 && y > 80 && x < 184) { inner++; if (a[i] == 0xFFE05050) flat++; }
                if (d < 84 && y > 80 && x >= 186 && x <= 193 && lum(a[i]) > 190) seam++;
            }
            log("   Anime coloreado" + (jp == 0 ? "" : " (JPEG)") + ", relleno plano en la piel: color exacto en " + flat + " de " + inner
                    + ", franja clara junto a la sombra=" + seam + ", camisa parecida tocada=" + shirt + ", pelo tocado=" + hair + ", fondo tocado=" + sky + ", contorno aclarado=" + light);
            SimKit.check(shirt == 0 && hair == 0 && sky == 0 && light == 0, "el relleno plano invadio otra zona o tapo el contorno");
            SimKit.check(seam == 0, "queda una franja clara entre el relleno y la sombra");
            SimKit.check(flat >= inner * (jp == 0 ? .99 : .97), "el relleno plano no es uniforme");
            // conservar sombras
            SimKit k2 = kit(img);
            tryCall(k2, "setFillShade", true);
            k2.cv.setColor(0xFFE05050);
            k2.tap(150, 130);
            int[] b = k2.project.ref();
            dump(b, "anime_sombras" + (jp == 0 ? "" : "_jpg"));
            long litL = 0, shL = 0; int litN = 0, shN = 0, shRed = 0;
            int shirt2 = 0;
            for (int y = 90; y < 200; y++) for (int x = 0; x < W; x++) {
                int i = y * W + x;
                double d = Math.hypot(x + .5 - 170, y + .5 - 130);
                if (d > 84) continue;
                if (x < 180) { litL += lum(b[i]); litN++; }
                if (x > 205) { shL += lum(b[i]); shN++; if (b[i] != img[i]) shRed++; }
            }
            for (int y = 236; y < H; y++) for (int x = 64; x < 296; x++) if (b[y * W + x] != img[y * W + x]) shirt2++;
            float lit = litL / (float) litN, sh = shL / (float) shN;
            log(String.format("   Conservar sombras: brillo zona iluminada %.0f, zona en sombra %.0f (sigue mas oscura), sombra recoloreada %d de %d, camisa tocada=%d",
                    lit, sh, shRed, shN, shirt2));
            SimKit.check(sh < lit - 15 && shRed > shN * .95 && shirt2 == 0, "conservar sombras no funciona");
        }
    }

    static void transparent() {
        int[] img = new int[W * H];
        for (int a = 0; a < 360; a += 2) {
            double r0 = Math.toRadians(a), r1 = Math.toRadians(a + 2);
            stroke(img, W, H, (float) (180 + 80 * Math.cos(r0)), (float) (150 + 80 * Math.sin(r0)),
                    (float) (180 + 80 * Math.cos(r1)), (float) (150 + 80 * Math.sin(r1)), 1.5f, 0xFF000000);
        }
        SimKit k = kit(img);
        k.cv.setFillAllLayers(false);
        k.tap(180, 150);
        int[] L = k.layer();
        int inside = 0, insideOk = 0, outside = 0, lineAlpha = 0;
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            int i = y * W + x;
            double d = Math.hypot(x + .5 - 180, y + .5 - 150);
            if (d < 76) { inside++; if (L[i] == 0xFF5BA860) insideOk++; }
            if (d > 84 && L[i] != img[i]) outside++;
            if ((img[i] >>> 24) > 200 && (L[i] >>> 24) < (img[i] >>> 24)) lineAlpha++;
        }
        log("   Capa transparente con un circulo: dentro pintado " + insideOk + " de " + inside + ", fuera tocado=" + outside + ", linea con alfa bajado=" + lineAlpha);
        SimKit.check(insideOk == inside && outside == 0 && lineAlpha == 0, "relleno en capa transparente incorrecto");
        // con transparencia bloqueada no se pinta lo transparente
        SimKit k2 = kit(img);
        k2.cv.setFillAllLayers(false);
        k2.cv.setLayerAlphaLock(k2.project.activeLayer(), true);
        k2.tap(180, 150);
        int changedAlpha = 0;
        for (int i = 0; i < img.length; i++) if ((k2.layer()[i] >>> 24) != (img[i] >>> 24)) changedAlpha++;
        log("   Con transparencia bloqueada: pixeles con alfa cambiado=" + changedAlpha);
        SimKit.check(changedAlpha == 0, "el balde ignoro el bloqueo de transparencia");
    }

    static void layers() {
        int[] img = kanji();
        // lineas en la capa 0, se pinta en una capa nueva encima
        SimKit k = kit(img);
        k.cv.addEmptyLayer(); Sim.pump(20);
        k.tap(330, 20);
        int[] comp = k.project.ref();
        int l0changed = SimKit.diff(k.layer(0), img);
        int small = smallUnpainted(img, comp), light = lineLightened(img, comp);
        log("   Varias capas (pintar en capa nueva): capa del dibujo cambiada=" + l0changed + ", rincones sin pintar=" + small + ", linea aclarada=" + light);
        SimKit.check(l0changed == 0 && small <= 4 && light == 0, "el relleno en otra capa fallo");
        // De fabrica (capa aparte): se crea "Color" encima y el original no se toca
        SimKit kd = new SimKit(W, H, img.clone());
        kd.cv.setMode(CanvasView.MODE_BUCKET);
        kd.cv.setFillTolerance(20);
        kd.cv.setColor(0xFF5BA860);
        int before = kd.project.layers.size();
        kd.tap(330, 20);
        int[] cd = kd.project.ref();
        log("   De fabrica: capas " + before + " -> " + kd.project.layers.size() + " (" + kd.project.activeLayer().name + "), original cambiado="
                + SimKit.diff(kd.layer(0), img) + ", rincones sin pintar=" + smallUnpainted(img, cd) + ", linea aclarada=" + lineLightened(img, cd));
        // Deshacer / Rehacer
        int[] after = k.layer(1).clone();
        k.cv.doUndo(); Sim.pump(30);
        boolean undoOk = SimKit.diff(k.layer(1), new int[W * H]) == 0;
        k.cv.doRedo(); Sim.pump(30);
        boolean redoOk = SimKit.diff(k.layer(1), after) == 0;
        log("   Deshacer deja la capa vacia=" + undoOk + ", Rehacer repone el relleno=" + redoOk);
        SimKit.check(undoOk && redoOk, "Deshacer/Rehacer del balde");
        // capa de referencia: las lineas en una capa marcada; abajo manchas de color que no deben frenar el relleno
        int[] blobs = new int[W * H];
        java.util.Arrays.fill(blobs, 0xFFFFFFFF);
        for (int y = 20; y < 120; y++) for (int x = 250; x < 350; x++) blobs[y * W + x] = 0xFF90C0F0;
        int[] linesOnly = new int[W * H];
        for (int i = 0; i < img.length; i++) if (lum(img[i]) < 250) linesOnly[i] = ((255 - lum(img[i])) << 24);
        SimKit kr = new SimKit(W, H, blobs);
        kr.project.layers.add(new Layer("lineas", linesOnly));
        kr.cv.addEmptyLayer(); Sim.pump(20);
        boolean refApi = true;
        Layer lineL = null;
        for (Layer l : kr.project.layers) if ("lineas".equals(l.name)) lineL = l;
        try { Layer.class.getField("reference").set(lineL, true); } catch (Exception e) { refApi = false; }
        kr.project.active = kr.project.layers.size() - 1;
        Layer paintL = kr.project.layers.get(kr.project.active);
        if (paintL == lineL) { kr.project.active--; paintL = kr.project.layers.get(kr.project.active); }
        kr.cv.setMode(CanvasView.MODE_BUCKET);
        kr.cv.setFillTolerance(20);
        kr.cv.setFillAllLayers(true);
        kr.cv.setColor(0xFF5BA860);
        tryCall(kr, "setFillColorLayer", false);
        kr.tap(20, 20);
        int crossed = 0;
        int[] pl = paintL.px();
        for (int y = 20; y < 120; y++) for (int x = 250; x < 350; x++) if (pl[y * W + x] != 0) crossed++;
        log("   Capa de referencia (solo lineas marcadas" + (refApi ? "" : ", NO EXISTE en esta version") + "): la mancha de color de abajo tambien se pinto en " + crossed + " de 10000 px");
        if (refApi) SimKit.check(crossed > 9000, "la capa de referencia no se uso");
    }

    static void consecutive() {
        int[] img = kanji();
        SimKit k = kit(img);
        k.cv.setColor(0xFFE03030);
        k.tap(330, 20);
        k.cv.setColor(0xFF3050E0);
        k.tap(330, 20);
        int[] a = k.project.ref();
        dump(a, "doble");
        int reddish = 0;
        for (int c : a) { int r = (c >> 16) & 255, b = c & 255; if (r > b + 30) reddish++; }
        log("   Dos rellenos seguidos (rojo y luego azul): pixeles con resto de rojo=" + reddish + ", linea aclarada=" + lineLightened(img, a));
        SimKit.check(reddish == 0 && lineLightened(img, a) == 0, "quedan restos del color anterior");
    }

    static void smallRegion() {
        int[] img = new int[W * H];
        java.util.Arrays.fill(img, 0xFFFFFFFF);
        for (int a = 0; a < 360; a += 5) {
            double r0 = Math.toRadians(a), r1 = Math.toRadians(a + 5);
            stroke(img, W, H, (float) (100 + 6 * Math.cos(r0)), (float) (100 + 6 * Math.sin(r0)),
                    (float) (100 + 6 * Math.cos(r1)), (float) (100 + 6 * Math.sin(r1)), 1.0f, 0xFF000000);
        }
        SimKit k = kit(img);
        k.tap(100, 100);
        int[] a = k.project.ref();
        int inside = 0, ok = 0, out = 0;
        for (int y = 80; y < 120; y++) for (int x = 80; x < 120; x++) {
            double d = Math.hypot(x + .5 - 100, y + .5 - 100);
            int i = y * W + x;
            if (d < 4) { inside++; if (a[i] == 0xFF5BA860) ok++; }
            if (d > 8.5 && a[i] != img[i]) out++;
        }
        log("   Zona chica (circulo de 12 px): interior pintado " + ok + " de " + inside + ", fuga=" + out);
        SimKit.check(ok == inside && out == 0, "zona chica mal rellenada");
    }

    /** Tiempo del motor en una pagina grande (CPU del servidor de pruebas, NO un telefono). */
    static void timing() {
        try { Class.forName("com.pacco.animecut.core.BucketFill"); } catch (Exception e) { log("   (sin BucketFill en esta version)"); return; }
        int w = 2000, h = 2000;
        int[] img = new int[w * h];
        java.util.Arrays.fill(img, 0xFFFFFFFF);
        java.util.Random rnd = new java.util.Random(3);
        for (int k = 0; k < 120; k++) {
            float ax = rnd.nextInt(w), ay = rnd.nextInt(h);
            float ang = rnd.nextFloat() * 6.28f, len = 100 + rnd.nextInt(500);
            int[] tmp = img;
            strokeBig(tmp, w, h, ax, ay, ax + (float) Math.cos(ang) * len, ay + (float) Math.sin(ang) * len, 1.5f + rnd.nextInt(8));
        }
        com.pacco.animecut.core.BucketFill.Params p = new com.pacco.animecut.core.BucketFill.Params();
        long t0 = System.nanoTime();
        p.barrier = com.pacco.animecut.core.AutoLines.build(img, w, h);
        long t1 = System.nanoTime();
        byte[] out = new byte[w * h];
        int sx = 5, sy = 5;
        while (lum(img[sy * w + sx]) < 200) sx++;
        com.pacco.animecut.core.BucketFill.Result r = com.pacco.animecut.core.BucketFill.compute(img, w, h, sx, sy, p, out);
        long t2 = System.nanoTime();
        int big = r.area;
        // zona chica
        java.util.Arrays.fill(out, (byte) 0);
        long t3 = System.nanoTime();
        com.pacco.animecut.core.BucketFill.Result r2 = com.pacco.animecut.core.BucketFill.compute(img, w, h, 1000, 1000, p, out);
        long t4 = System.nanoTime();
        log(String.format("   Tiempo en 2000x2000 (servidor, no telefono): detectar lineas %d ms (una vez por version), zona de %d px en %d ms, zona de %d px en %d ms",
                (t1 - t0) / 1000000, big, (t2 - t1) / 1000000, r2 == null ? 0 : r2.area, (t4 - t3) / 1000000));
    }

    static void strokeBig(int[] px, int w, int h, float ax, float ay, float bx, float by, float r) {
        int x0 = (int) Math.max(0, Math.min(ax, bx) - r - 2), x1 = (int) Math.min(w - 1, Math.max(ax, bx) + r + 2);
        int y0 = (int) Math.max(0, Math.min(ay, by) - r - 2), y1 = (int) Math.min(h - 1, Math.max(ay, by) + r + 2);
        float vx = bx - ax, vy = by - ay, l2 = Math.max(1e-6f, vx * vx + vy * vy);
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
            float t = Math.max(0, Math.min(1, ((x + .5f - ax) * vx + (y + .5f - ay) * vy) / l2));
            float d = (float) Math.hypot(x + .5f - ax - vx * t, y + .5f - ay - vy * t);
            float c = Math.max(0, Math.min(1, r + .5f - d));
            if (c > 0) px[y * w + x] = mix(px[y * w + x], 0xFF000000, c);
        }
    }

    public static void main(String[] a) throws Exception {
        try {
            thick();
            colored();
            transparent();
            layers();
            consecutive();
            smallRegion();
            timing();
            log("OK Balde: zonas completas, sin rincones blancos, sin fugas, lineas intactas, plano o con sombras, capas y referencia");
        } catch (Throwable e) { e.printStackTrace(System.out); System.exit(1); }
        System.exit(0);
    }
}
