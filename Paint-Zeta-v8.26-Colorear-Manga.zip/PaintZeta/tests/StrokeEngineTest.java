import com.pacco.animecut.core.StrokeEngine;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Pruebas del recorrido de Brocha/Goma (JVM, sin Android). */
public final class StrokeEngineTest {
    static void check(boolean ok, String m) { if (!ok) throw new AssertionError(m); }

    static List<float[]> run(float[][] pts, float spacing, float stab, boolean curve) {
        final List<float[]> out = new ArrayList<float[]>();
        final float sp = spacing;
        StrokeEngine e = new StrokeEngine();
        e.setCurve(curve);
        StrokeEngine.Sink s = new StrokeEngine.Sink() {
            public float spacing(float arc) { return sp; }
            public void stamp(float x, float y, float arc) { out.add(new float[]{x, y}); }
        };
        e.begin(pts[0][0], pts[0][1], stab);
        out.add(new float[]{pts[0][0], pts[0][1]});
        for (int i = 1; i < pts.length; i++) e.add(pts[i][0], pts[i][1], s);
        e.finish(s);
        return out;
    }

    static float[][] circle(int n, float r) {
        float[][] p = new float[n + 1][];
        for (int i = 0; i <= n; i++) {
            double a = i * Math.PI * 1.5 / n;
            p[i] = new float[]{(float) (200 + r * Math.cos(a)), (float) (200 + r * Math.sin(a))};
        }
        return p;
    }

    static float maxErr(List<float[]> st) {
        float e = 0;
        for (int i = st.size() / 10; i < st.size() * 9 / 10; i++) {
            float[] p = st.get(i);
            e = Math.max(e, Math.abs((float) Math.hypot(p[0] - 200, p[1] - 200) - 150));
        }
        return e;
    }

    public static void main(String[] a) {
        // 1) Un tramo de 100 px en 1 evento o en 100 eventos: mismas estampas
        List<float[]> one = run(new float[][]{{0, 0}, {100, 0}}, 3f, 0f, true);
        float[][] many = new float[101][];
        for (int i = 0; i <= 100; i++) many[i] = new float[]{i, 0};
        List<float[]> hundred = run(many, 3f, 0f, true);
        float worst = 0f;
        check(one.size() == hundred.size(), "distinta cantidad de estampas: " + one.size() + " vs " + hundred.size());
        for (int i = 0; i < one.size(); i++)
            worst = Math.max(worst, Math.abs(one.get(i)[0] - hundred.get(i)[0]) + Math.abs(one.get(i)[1] - hundred.get(i)[1]));
        System.out.printf("   1 evento vs 100 eventos: %d estampas cada uno, diferencia maxima %.4f px%n", one.size(), worst);
        check(worst < 1e-3f, "las estampas dependen de los eventos");

        // 2) Espaciado constante entre eventos (antes variaba entre 1x y 2x)
        Random rnd = new Random(5);
        List<float[]> pts = new ArrayList<float[]>();
        float x = 0;
        pts.add(new float[]{0, 0});
        while (x < 300) { x += .5f + rnd.nextFloat() * 9f; pts.add(new float[]{x, 0}); }
        List<float[]> st = run(pts.toArray(new float[0][]), 4f, 0f, true);
        float mn = 99, mx = 0;
        for (int i = 2; i < st.size() - 1; i++) { float d = Math.abs(st.get(i)[0] - st.get(i - 1)[0]); mn = Math.min(mn, d); mx = Math.max(mx, d); }
        System.out.printf("   Eventos irregulares: distancia entre estampas %.3f a %.3f px (objetivo 4)%n", mn, mx);
        check(mx - mn < .01f, "espaciado irregular");

        // 3) Curva: circulo muestreado a 60 Hz (pocos puntos) -> estampas cerca del circulo real
        for (int n : new int[]{12, 24, 96}) {
            // Se mide en el 80 % central: en los extremos no hay vecino que indique la curvatura.
            float errC = maxErr(run(circle(n, 150), 2f, 0f, true)), errL = maxErr(run(circle(n, 150), 2f, 0f, false));
            System.out.printf("   Arco de 270 grados con %3d puntos: error maximo curva %.2f px, recto (antes) %.2f px%n", n, errC, errL);
            check(errC < errL * .25f || errC < .2f, "la curva no mejora el trazo");
        }

        // 4) Estabilizador: suaviza el temblor y termina EXACTAMENTE en el dedo
        float[][] shaky = new float[200][];
        for (int i = 0; i < 200; i++) shaky[i] = new float[]{i * 2f, (float) (rnd.nextGaussian() * 3)};
        for (float s : new float[]{0f, .5f, .9f}) {
            List<float[]> r = run(shaky, 2f, s, true);
            float[] last = r.get(r.size() - 1);
            double dev = 0;
            for (float[] p : r) dev += p[1] * p[1];
            dev = Math.sqrt(dev / r.size());
            System.out.printf("   Estabilizador %.1f (ventana %d): temblor %.2f px, final a %.3f px del dedo%n",
                    s, StrokeEngine.windowFor(s), dev, Math.hypot(last[0] - shaky[199][0], last[1] - shaky[199][1]));
            check(Math.hypot(last[0] - shaky[199][0], last[1] - shaky[199][1]) < 1.01, "el trazo no llego al dedo");
        }
        System.out.println("OK Recorrido de pinceles: espaciado continuo, curva centripeta y estabilizador que llega al dedo");
    }
}
