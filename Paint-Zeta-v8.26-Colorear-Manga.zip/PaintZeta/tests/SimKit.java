import android.graphics.Matrix;
import android.os.Sim;
import android.os.SystemClock;
import android.view.MotionEvent;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.view.CanvasView;
import java.lang.reflect.Field;

/** Utilidades para manejar el CanvasView REAL dentro del Android simulado (tests/androidsim). */
public final class SimKit {
    public CanvasView cv;
    public Project project;
    public final int w, h;

    public SimKit(int w, int h, int[] pixels) {
        Sim.main = Thread.currentThread();
        this.w = w; this.h = h;
        project = new Project(w, h);
        project.layers.add(new Layer("imagen", pixels));
        project.active = 0;
        cv = new CanvasView(new android.content.Context() { });
        cv.setProject(project);
        Sim.pump(40);
    }

    public static void check(boolean ok, String m) {
        if (ok) return;
        if (System.getProperty("noassert") != null) { System.out.println("     FALLA: " + m); return; }
        throw new AssertionError(m);
    }

    public Object get(String name) {
        try {
            Field f = CanvasView.class.getDeclaredField(name);
            f.setAccessible(true);
            return f.get(cv);
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    /** Llama a un metodo publico por nombre (permite ejecutar las pruebas sobre versiones antiguas). */
    public Object call(String name, Object... args) {
        try {
            for (java.lang.reflect.Method m : CanvasView.class.getMethods())
                if (m.getName().equals(name) && m.getParameterCount() == args.length) return m.invoke(cv, args);
            throw new NoSuchMethodException(name);
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    public float rot() { return (Float) call("getViewRotation"); }
    public void resetView() { call("resetView"); }

    public int[] layer() { return project.activeLayer().px(); }
    public int[] layer(int i) { return project.layers.get(i).px(); }

    public float[] screen(float ix, float iy) {
        Matrix m = (Matrix) get("view");
        float[] p = {ix, iy};
        m.mapPoints(p);
        return p;
    }

    public float[] image(float sx, float sy) {
        Matrix m = (Matrix) get("view"), inv = new Matrix();
        m.invert(inv);
        float[] p = {sx, sy};
        inv.mapPoints(p);
        return p;
    }

    public void touch(int action, float[]... pts) {
        float[] xs = new float[pts.length], ys = new float[pts.length];
        for (int i = 0; i < pts.length; i++) { xs[i] = pts[i][0]; ys[i] = pts[i][1]; }
        cv.onTouchEvent(new MotionEvent(action, xs, ys, null, null, null, SystemClock.uptimeMillis()));
    }

    /** Un dedo sobre puntos de IMAGEN; eventsPerFrame historicos por evento (lotes de Android). */
    public void stroke(float[][] imgPts, long durationMs, int histPerEvent) {
        float[] s0 = screen(imgPts[0][0], imgPts[0][1]);
        touch(MotionEvent.ACTION_DOWN, s0);
        int frames = Math.max(2, (int) (durationMs / 16));
        for (int f = 1; f <= frames; f++) {
            Sim.pump(16);
            float[] hx = new float[histPerEvent], hy = new float[histPerEvent];
            long[] ht = new long[histPerEvent];
            long now = SystemClock.uptimeMillis();
            for (int k = 0; k < histPerEvent; k++) {
                float t = (f - 1 + (k + 1f) / (histPerEvent + 1f)) / frames;
                float[] a = at(imgPts, t), sa = screen(a[0], a[1]);
                hx[k] = sa[0]; hy[k] = sa[1]; ht[k] = now - 16 + 16 * (k + 1) / (histPerEvent + 1);
            }
            float[] b = at(imgPts, f / (float) frames), sb = screen(b[0], b[1]);
            cv.onTouchEvent(new MotionEvent(MotionEvent.ACTION_MOVE, new float[]{sb[0]}, new float[]{sb[1]}, hx, hy, ht, now));
        }
        float[] e = imgPts[imgPts.length - 1];
        touch(MotionEvent.ACTION_UP, screen(e[0], e[1]));
        Sim.pump(200);
    }

    public void tap(float ix, float iy) {
        float[] s = screen(ix, iy);
        touch(MotionEvent.ACTION_DOWN, s);
        Sim.pump(30);
        touch(MotionEvent.ACTION_UP, s);
        Sim.pump(300);
    }

    public static float[] at(float[][] pts, float t) {
        t = Math.max(0f, Math.min(1f, t));
        float x = t * (pts.length - 1);
        int i = Math.min(pts.length - 2, (int) x);
        float f = x - i;
        return new float[]{pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f};
    }

    public static int diff(int[] a, int[] b) { int n = 0; for (int i = 0; i < a.length; i++) if (a[i] != b[i]) n++; return n; }
}
