package androidx.activity.result.contract;
import android.net.Uri;
public final class ActivityResultContracts {
  public static class GetContent extends ActivityResultContract<String, Uri> {}
  public static class CreateDocument extends ActivityResultContract<String, Uri> { public CreateDocument(String mime) {} }
  public static class OpenDocumentTree extends ActivityResultContract<Uri, Uri> {}
  public static class OpenDocument extends ActivityResultContract<String[], Uri> {}
}
