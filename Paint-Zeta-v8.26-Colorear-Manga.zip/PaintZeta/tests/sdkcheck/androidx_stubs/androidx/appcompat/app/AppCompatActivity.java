package androidx.appcompat.app;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContract;
public class AppCompatActivity extends android.app.Activity {
  public final <I, O> ActivityResultLauncher<I> registerForActivityResult(ActivityResultContract<I, O> c, ActivityResultCallback<O> cb) { return null; }
}
