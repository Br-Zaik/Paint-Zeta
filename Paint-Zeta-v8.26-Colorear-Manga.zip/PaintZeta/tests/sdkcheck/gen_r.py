"""Genera un R.java a partir de app/src/main/res (solo para compilar sin Gradle)."""
import os, re, sys
res, out_dir = sys.argv[1], sys.argv[2]
types = {}
def add(t, n): types.setdefault(t, set()).add(n.replace('.', '_'))
for d in os.listdir(res):
    t = d.split('-')[0]
    for f in os.listdir(os.path.join(res, d)):
        path = os.path.join(res, d, f)
        if t == 'values':
            s = open(path, encoding='utf-8').read()
            for m in re.finditer(r'<(string|color|dimen|style|integer|bool|array|string-array|integer-array|attr)\s+[^>]*name="([^"]+)"', s):
                add({'string-array': 'array', 'integer-array': 'array'}.get(m.group(1), m.group(1)), m.group(2))
        else:
            add(t, os.path.splitext(f)[0])
            if f.endswith('.xml'):
                for m in re.finditer(r'@\+id/(\w+)', open(path, encoding='utf-8').read()): add('id', m.group(1))
os.makedirs(os.path.join(out_dir, 'com/pacco/animecut'), exist_ok=True)
lines, i = ['package com.pacco.animecut;', 'public final class R {'], 0x7f000001
for t, ns in sorted(types.items()):
    lines.append('  public static final class %s {' % t)
    for n in sorted(ns):
        lines.append('    public static final int %s = %d;' % (n, i)); i += 1
    lines.append('  }')
lines.append('}')
open(os.path.join(out_dir, 'com/pacco/animecut/R.java'), 'w').write('\n'.join(lines))
