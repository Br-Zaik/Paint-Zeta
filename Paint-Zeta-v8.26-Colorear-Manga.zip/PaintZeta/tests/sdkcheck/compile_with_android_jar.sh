#!/bin/sh
# Compila TODO el codigo Java de la app contra el android.jar REAL (API 34) sin Gradle.
# Uso: sh tests/sdkcheck/compile_with_android_jar.sh /ruta/android.jar
# Limitacion: AndroidX (AppCompatActivity, ActivityResult...) viene de Google Maven; aqui se
# usan sustitutos minimos (androidx_stubs) solo para las 5 clases que usa la app.
# NO genera APK (faltan aapt2, d8 y la firma). Sirve para detectar errores de compilacion.
set -eu
JAR="$1"
ROOT="$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
python3 "$ROOT/tests/sdkcheck/gen_r.py" "$ROOT/app/src/main/res" "$OUT/gen"
# 1) contra la biblioteca java.* de ANDROID (bootclasspath): detecta APIs de Java que el telefono no tiene
javac -nowarn -source 8 -target 8 -bootclasspath "$JAR" -d "$OUT/c1" \
  $(find "$ROOT/tests/sdkcheck/androidx_stubs" -name '*.java') "$OUT/gen/com/pacco/animecut/R.java" \
  $(find "$ROOT/app/src/main/java" -name '*.java')
# 2) con Java 17 (como build.gradle)
javac -nowarn --release 17 -cp "$JAR" -d "$OUT/c2" \
  $(find "$ROOT/tests/sdkcheck/androidx_stubs" -name '*.java') "$OUT/gen/com/pacco/animecut/R.java" \
  $(find "$ROOT/app/src/main/java" -name '*.java')
echo "OK: $(find "$OUT/c2" -name '*.class' | wc -l) clases compiladas contra $(basename "$JAR") sin errores"
