import android.os.Sim;
import com.pacco.animecut.view.CanvasView;

/**
 * Pruebas de COMPORTAMIENTO de las herramientas con el CanvasView real en un Android
 * simulado (no es un telefono real). Cada prueba imprime numeros medidos.
 * Uso: java ToolsSimTest [nombre...]  (sin argumentos ejecuta todas)
 */
public final class ToolsSimTest {
    static void log(String s) { System.out.println(s); }
    static boolean want(String[] a, String n) {
        if (a.length == 0) return true;
        for (String s : a) if (s.equals(n)) return true;
        return false;
    }

    /** Disco rojo opaco con borde antialias sobre fondo transparente. */
    static int[] redDisc(int w, int h, float cx, float cy, float r) {
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            float d = (float) Math.hypot(x + .5f - cx, y + .5f - cy);
            float a = Math.max(0f, Math.min(1f, r + .5f - d));
            if (a > 0f) px[y * w + x] = ((int) (a * 255 + .5f) << 24) | 0xFF0000;
        }
        return px;
    }

    /** Pixeles visibles cuyo color dejo de ser rojo puro (halo/contaminacion). */
    static int dirtyRed(int[] px) {
        int n = 0;
        for (int c : px) {
            if ((c >>> 24) < 3) continue;
            int r = (c >>> 16) & 255, g = (c >>> 8) & 255, b = c & 255;
            if (r < 250 || g > 5 || b > 5) n++;
        }
        return n;
    }

    static void smudge() {
        int w = 300, h = 220;
        SimKit k = new SimKit(w, h, redDisc(w, h, 150, 110, 60));
        k.cv.setMode(CanvasView.MODE_SMUDGE);
        k.cv.setBrushSize(50);
        k.cv.setEffectStrength(.8f);
        // Arrastres repetidos cruzando el borde rojo/transparente
        for (int rep = 0; rep < 4; rep++) {
            k.stroke(new float[][]{{150, 110}, {260, 110}}, 400, 2);
            k.stroke(new float[][]{{150, 110}, {150, 210}}, 400, 2);
            k.stroke(new float[][]{{100, 60}, {40, 20}}, 300, 2);
        }
        int[] L = k.layer();
        int dirty = dirtyRed(L), visible = 0;
        for (int c : L) if ((c >>> 24) >= 3) visible++;
        log("   Difuminar rojo sobre transparente (12 trazos): pixeles visibles=" + visible + ", pixeles contaminados/oscuros=" + dirty);
        SimKit.check(dirty == 0, "Difuminar oscurecio bordes: " + dirty);
        // Semitransparente: rojo al 40 % sobre transparente
        int[] semi = redDisc(w, h, 150, 110, 60);
        for (int i = 0; i < semi.length; i++) if (semi[i] != 0) semi[i] = (((semi[i] >>> 24) * 102 / 255) << 24) | 0xFF0000;
        SimKit k2 = new SimKit(w, h, semi);
        k2.cv.setMode(CanvasView.MODE_SMUDGE);
        k2.cv.setBrushSize(40);
        k2.cv.setEffectStrength(1f);
        for (int rep = 0; rep < 3; rep++) k2.stroke(new float[][]{{100, 110}, {280, 110}}, 400, 2);
        int dirty2 = dirtyRed(k2.layer()), maxA = 0;
        for (int c : k2.layer()) maxA = Math.max(maxA, c >>> 24);
        log("   Difuminar rojo al 40 %: pixeles contaminados=" + dirty2 + ", alfa maximo=" + maxA + " (original 102)");
        SimKit.check(dirty2 == 0 && maxA <= 102, "Difuminar semitransparente: contaminado o alfa aumentado");
        log("OK Difuminar: sin halos oscuros ni colores contaminados en transparencias");
    }

    // ---------------- gestos ----------------

    static android.view.MotionEvent ev(int action, float[][] pts, int[] ids, int idx) {
        float[] xs = new float[pts.length], ys = new float[pts.length];
        for (int i = 0; i < pts.length; i++) { xs[i] = pts[i][0]; ys[i] = pts[i][1]; }
        return new android.view.MotionEvent(action, xs, ys, null, null, null, android.os.SystemClock.uptimeMillis()).withPointers(ids, idx);
    }

    /** Dos dedos: A baja, B baja, ambos se mueven en 'steps' pasos, B se levanta, A se mueve, A se levanta. */
    static void twoFinger(SimKit k, float[] a0, float[] b0, float[] a1, float[] b1, int steps, boolean swapOrder, boolean upBAfter) {
        k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_DOWN, new float[][]{a0}, new int[]{0}, 0));
        Sim.pump(25);
        k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_POINTER_DOWN, new float[][]{a0, b0}, new int[]{0, 1}, 1));
        for (int i = 1; i <= steps; i++) {
            Sim.pump(16);
            float t = i / (float) steps;
            float[] a = {a0[0] + (a1[0] - a0[0]) * t, a0[1] + (a1[1] - a0[1]) * t};
            float[] b = {b0[0] + (b1[0] - b0[0]) * t, b0[1] + (b1[1] - b0[1]) * t};
            if (swapOrder && (i & 1) == 1)   // Android puede cambiar el orden (indices) de los dedos
                k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{b, a}, new int[]{1, 0}, 0));
            else
                k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{a, b}, new int[]{0, 1}, 0));
        }
        if (upBAfter) {
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_POINTER_UP, new float[][]{a1, b1}, new int[]{0, 1}, 1));
            for (int i = 1; i <= 6; i++) {   // el dedo que queda sigue moviendose
                Sim.pump(16);
                k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{{a1[0] + i * 9, a1[1] - i * 7}}, new int[]{0}, 0));
            }
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_UP, new float[][]{{a1[0] + 54, a1[1] - 42}}, new int[]{0}, 0));
        }
        Sim.pump(200);
    }

    /** Giro real de dos dedos alrededor de un centro (distancia constante). */
    static void rotateFingers(SimKit k, float cx, float cy, float r, float deg, int steps, boolean upBAfter) {
        float[] a0 = {cx - r, cy}, b0 = {cx + r, cy};
        k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_DOWN, new float[][]{a0}, new int[]{0}, 0));
        Sim.pump(25);
        k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_POINTER_DOWN, new float[][]{a0, b0}, new int[]{0, 1}, 1));
        float[] a = a0, b = b0;
        for (int i = 1; i <= steps; i++) {
            Sim.pump(16);
            double t = Math.toRadians(deg * i / steps);
            a = new float[]{(float) (cx - r * Math.cos(t)), (float) (cy - r * Math.sin(t))};
            b = new float[]{(float) (cx + r * Math.cos(t)), (float) (cy + r * Math.sin(t))};
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{a, b}, new int[]{0, 1}, 0));
        }
        if (upBAfter) {
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_POINTER_UP, new float[][]{a, b}, new int[]{0, 1}, 1));
            for (int i = 1; i <= 6; i++) { Sim.pump(16); k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{{a[0] + i * 9, a[1] - i * 7}}, new int[]{0}, 0)); }
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_UP, new float[][]{{a[0] + 54, a[1] - 42}}, new int[]{0}, 0));
        } else {
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_POINTER_UP, new float[][]{a, b}, new int[]{0, 1}, 1));
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_UP, new float[][]{a}, new int[]{0}, 0));
        }
        Sim.pump(200);
    }

    static void gestures() {
        int w = 600, h = 400;
        int[] img = LiquifyEngineTest.mangaImage(w, h, false);
        SimKit k = new SimKit(w, h, img.clone());
        k.cv.setMode(CanvasView.MODE_PAINT);
        // 1) mover + zoom: el punto bajo el centro de los dedos se queda bajo los dedos
        float[] a0 = {400, 900}, b0 = {700, 1000};
        float[] mid0 = k.image(550, 950);
        float[] a1 = {330, 820}, b1 = {830, 1060};    // separa (zoom) y desplaza, casi sin giro
        twoFinger(k, a0, b0, a1, b1, 12, true, false);
        float[] midNowScreen = k.screen(mid0[0], mid0[1]);
        float err = (float) Math.hypot(midNowScreen[0] - (a1[0] + b1[0]) / 2, midNowScreen[1] - (a1[1] + b1[1]) / 2);
        float rot = k.rot();
        log(String.format("   Mover+zoom (dedos con indices cambiados): punto bajo el centro se desplazo %.3f px; giro %.2f grados", err, rot));
        SimKit.check(err < .5f, "el zoom cambio de centro");
        // separacion 316->547 px cambia el angulo ~3.8 grados: por debajo del umbral, no gira
        SimKit.check(Math.abs(rot) < 1e-3f, "giro accidental al hacer zoom");
        SimKit.check(SimKit.diff(k.layer(), img) == 0, "navegar modifico la imagen");

        // 2) giro pequeno (temblor) no gira; giro de 40 grados gira 30 sin salto
        k.resetView(); Sim.pump(20);
        float cx = 540, cy = 960, r = 200;
        float[] p1 = {cx - r, cy}, p2 = {cx + r, cy};
        double t3 = Math.toRadians(3);
        rotateFingers(k, cx, cy, r, 3f, 8, false);
        float rSmall = k.rot();
        double t40 = Math.toRadians(40);
        rotateFingers(k, cx, cy, r, 40f, 20, false);
        float rBig = k.rot();
        log(String.format("   Girar dedos 3 grados -> lienzo %.2f ; girar 40 grados -> lienzo %.2f (umbral 10)", rSmall, rBig));
        SimKit.check(Math.abs(rSmall) < 1e-3f, "temblor de 3 grados giro el lienzo");
        SimKit.check(Math.abs(rBig - 30f) < .6f, "giro esperado 30: " + rBig);

        // 3) iman a 90 grados
        k.resetView(); Sim.pump(20);
        double t96 = Math.toRadians(96 + 10 - 0);   // 106 dedos -> 96 lienzo -> iman a 90? (96 esta a 6: no)
        double t103 = Math.toRadians(103);          // 103 dedos -> 93 lienzo -> iman a 90
        rotateFingers(k, cx, cy, r, 103f, 30, false);
        float snap = k.rot();
        log(String.format("   Girar 103 grados -> lienzo %.2f (iman a 90)", snap));
        SimKit.check(Math.abs(Math.abs(snap) - 90f) < .01f, "no se iman a 90: " + snap);

        // 4) pintar sobre lienzo girado: un trazo horizontal en pantalla sigue al dedo en la imagen
        int[] before = k.layer().clone();
        float[] s0 = {300, 700}, s1 = {800, 700};
        float[] i0 = k.image(s0[0], s0[1]), i1 = k.image(s1[0], s1[1]);
        k.cv.setColor(0xFFFF0000);
        k.cv.setBrushSize(10);
        k.stroke(new float[][]{i0, i1}, 300, 2);
        int[] L = k.layer();
        int red = 0, onLine = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = L[y * w + x];
            if (c == before[y * w + x]) continue;
            red++;
            // distancia al segmento i0-i1
            double vx = i1[0] - i0[0], vy = i1[1] - i0[1], ux = x + .5 - i0[0], uy = y + .5 - i0[1];
            double t = Math.max(0, Math.min(1, (ux * vx + uy * vy) / (vx * vx + vy * vy)));
            if (Math.hypot(ux - vx * t, uy - vy * t) <= 6.5) onLine++;
        }
        log(String.format("   Trazo sobre lienzo girado 90: %d pixeles pintados, %d sobre la linea esperada", red, onLine));
        SimKit.check(red > 100 && onLine == red, "el trazo no sigue al dedo con el lienzo girado");
        k.cv.doUndo();

        // 5) rotacion desactivada
        k.resetView(); k.call("setRotateEnabled", false); Sim.pump(20);
        rotateFingers(k, cx, cy, r, 40f, 20, false);
        SimKit.check(Math.abs(k.rot()) < 1e-3f, "giro con la opcion desactivada");
        k.call("setRotateEnabled", true);
        log("OK Girar: umbral contra temblores, sin salto, iman a 90, desactivable, y se pinta bien girado");

        // 6) levantar un dedo: el otro no mueve ni pinta; zoom 4x + giro
        k.resetView(); Sim.pump(20);
        twoFinger(k, new float[]{450, 950}, new float[]{630, 950}, new float[]{300, 950}, new float[]{780, 950}, 15, false, false);
        float[] probe = k.image(540, 960);
        rotateFingers(k, cx, cy, r, 40f, 20, true);
        float[] after = k.screen(probe[0], probe[1]);
        float drift = (float) Math.hypot(after[0] - 540, after[1] - 960);
        log(String.format("   Zoom x%.1f y giro de 30 grados, luego se levanta un dedo y el otro sigue: centro desplazado %.3f px",
                ((float) Math.hypot(k.screen(1, 0)[0] - k.screen(0, 0)[0], k.screen(1, 0)[1] - k.screen(0, 0)[1])), drift));
        SimKit.check(drift < .6f, "el lienzo salto o se movio con el dedo restante");

        // 7) en cada herramienta: un dedo y enseguida el segundo (gesto de navegacion) no cambia nada
        int[] modes = {CanvasView.MODE_PAINT, CanvasView.MODE_ERASER, CanvasView.MODE_BGERASE, CanvasView.MODE_BUCKET,
                CanvasView.MODE_SMUDGE, CanvasView.MODE_BLUR, CanvasView.MODE_LASSO, CanvasView.MODE_CURVE,
                CanvasView.MODE_POLY, CanvasView.MODE_LIQUIFY};
        String[] names = {"Brocha", "Goma", "Borrar fondo", "Relleno", "Difuminar", "Borrosidad", "Lazo", "Curva", "Polilinea", "Especial"};
        int[] base = k.layer().clone();
        byte[] selBefore = k.project.selection.clone();
        for (int m = 0; m < modes.length; m++) {
            k.cv.setMode(modes[m]);
            Sim.pump(20);
            // el primer dedo se mueve 60 px antes de que llegue el segundo (peor caso)
            float[] f0 = {300, 800};
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_DOWN, new float[][]{f0}, new int[]{0}, 0));
            for (int i = 1; i <= 3; i++) { Sim.pump(16); k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{{300 + i * 20, 800}}, new int[]{0}, 0)); }
            float[] fa = {360, 800}, fb = {600, 900};
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_POINTER_DOWN, new float[][]{fa, fb}, new int[]{0, 1}, 1));
            for (int i = 1; i <= 10; i++) { Sim.pump(16); k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{{360 - i * 10, 800 - i * 5}, {600 + i * 12, 900 + i * 8}}, new int[]{0, 1}, 0)); }
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_POINTER_UP, new float[][]{{260, 750}, {720, 980}}, new int[]{0, 1}, 1));
            Sim.pump(16);
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_MOVE, new float[][]{{200, 700}}, new int[]{0}, 0));
            k.cv.onTouchEvent(ev(android.view.MotionEvent.ACTION_UP, new float[][]{{200, 700}}, new int[]{0}, 0));
            Sim.pump(250);
            int changed = SimKit.diff(k.layer(), base);
            int shapes = k.cv.shapeCount();
            boolean selChanged = !java.util.Arrays.equals(selBefore, k.project.selection);
            log(String.format("   %-13s: pixeles cambiados=%d, puntos de forma=%d, seleccion cambiada=%s", names[m], changed, shapes, selChanged));
            SimKit.check(changed == 0 && shapes == 0 && !selChanged, "navegar en " + names[m] + " modifico algo");
        }
        log("OK Navegar con dos dedos en 10 herramientas: sin trazos, puntos ni selecciones accidentales");
    }

    // ---------------- brocha / goma ----------------

    /** Alfa a lo largo de la linea central del trazo (de p0 a p1), en el tramo interior. */
    static float[] centerline(int[] px, int w, float[] p0, float[] p1, float margin) {
        float len = (float) Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
        float mn = 999, mx = 0;
        for (float s = margin; s <= len - margin; s += .5f) {
            float x = p0[0] + (p1[0] - p0[0]) * s / len, y = p0[1] + (p1[1] - p0[1]) * s / len;
            int c = px[(int) y * w + (int) x];
            float aa = c >>> 24;
            mn = Math.min(mn, aa); mx = Math.max(mx, aa);
        }
        return new float[]{mn, mx};
    }

    /** "Tinta" (suma de alfa) por unidad de largo en franjas perpendiculares: uniformidad del grosor. */
    static float inkVariation(int[] px, int w, int h, float[] p0, float[] p1, float halfWidth, float margin) {
        float len = (float) Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
        float ux = (p1[0] - p0[0]) / len, uy = (p1[1] - p0[1]) / len;
        final float BIN = 16f; // franjas de 16 px: menos ruido por cuantizacion de pixeles
        int bins = (int) ((len - 2 * margin) / BIN);
        double[] ink = new double[bins];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = px[y * w + x];
            if ((c >>> 24) == 0) continue;
            float rx = x + .5f - p0[0], ry = y + .5f - p0[1];
            float along = rx * ux + ry * uy, across = -rx * uy + ry * ux;
            if (Math.abs(across) > halfWidth + 3 || along < margin || along >= len - margin) continue;
            int b = (int) ((along - margin) / BIN);
            if (b >= 0 && b < bins) ink[b] += (c >>> 24) / 255.0;
        }
        double mn = 1e9, mx = 0;
        for (double v : ink) { mn = Math.min(mn, v); mx = Math.max(mx, v); }
        return (float) ((mx - mn) / Math.max(1e-9, mx));
    }

    static void brush() {
        int w = 500, h = 400;
        float[] p0 = {40, 50}, p1 = {460, 350};
        log("   Brocha (trazo diagonal, capa transparente):");
        for (float size : new float[]{1, 2, 3, 20, 50, 100}) {
            for (float hard : new float[]{1f, .2f}) {
                for (int speed = 0; speed < 2; speed++) {
                    SimKit k = new SimKit(w, h, new int[w * h]);
                    k.cv.setMode(CanvasView.MODE_PAINT);
                    k.cv.setColor(0xFF1040C0);
                    k.cv.setBrushOpacity(1f);
                    k.cv.setHardness(hard);
                    k.cv.setBrushSize(size);
                    k.stroke(new float[][]{p0, p1}, speed == 0 ? 1600 : 120, speed == 0 ? 3 : 1);
                    float margin = Math.max(6, size);
                    float[] cl = centerline(k.layer(), w, p0, p1, margin);
                    float var = inkVariation(k.layer(), w, h, p0, p1, size / 2f, margin);
                    log(String.format("     %3.0f px dureza %.1f %-6s: alfa en el centro %3.0f..%3.0f, variacion de grosor %4.1f %%",
                            size, hard, speed == 0 ? "lento" : "rapido", cl[0], cl[1], var * 100));
                    if (size >= 20) SimKit.check(cl[0] >= cl[1] * .97f, "huecos/cuentas en el trazo");
                    SimKit.check(var < (size <= 3 ? .08f : .04f), "grosor irregular");
                }
            }
        }
        // Curva rapida: un circulo dibujado en 0,25 s (pocos eventos) debe salir redondo
        for (int pass = 0; pass < 1; pass++) {
            SimKit kc = new SimKit(w, h, new int[w * h]);
            kc.cv.setMode(CanvasView.MODE_PAINT);
            kc.cv.setColor(0xFF1040C0);
            kc.cv.setBrushOpacity(1f);
            kc.cv.setHardness(1f);
            kc.cv.setBrushSize(8);
            float[][] circ = new float[121][];
            for (int i = 0; i <= 120; i++) { double t = i * Math.PI * 2 * .9 / 120; circ[i] = new float[]{(float) (250 + 140 * Math.cos(t)), (float) (200 + 140 * Math.sin(t))}; }
            kc.stroke(circ, 250, 0);   // 15 eventos para todo el circulo, sin historial
            int outside = 0, total = 0;
            int[] L = kc.layer();
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                if ((L[y * w + x] >>> 24) < 128) continue;
                total++;
                float d = Math.abs((float) Math.hypot(x + .5 - 250, y + .5 - 200) - 140);
                if (d > 4f + 1.5f) outside++;
            }
            log(String.format("   Circulo rapido (15 eventos): %d pixeles pintados, %d fuera del anillo ideal (forma poligonal)", total, outside));
            SimKit.check(outside < total * .02f, "la curva rapida sale poligonal");
        }
        // Estabilizador alto: el trazo debe llegar hasta donde se levanto el dedo
        SimKit ks = new SimKit(w, h, new int[w * h]);
        ks.cv.setMode(CanvasView.MODE_PAINT);
        ks.cv.setColor(0xFF1040C0);
        ks.cv.setBrushOpacity(1f);
        ks.cv.setHardness(1f);
        ks.cv.setBrushSize(10);
        ks.cv.setStabilizer(.8f);
        ks.stroke(new float[][]{{40, 200}, {460, 200}}, 500, 2);
        int reach = 0;
        for (int x = 40; x < w; x++) if ((ks.layer()[200 * w + x] >>> 24) > 128) reach = x;
        log("   Estabilizador 0,8: el trazo llega hasta x=" + reach + " (el dedo se levanto en x=460)");
        SimKit.check(reach >= 458, "el estabilizador deja el trazo atras");
        // Opacidad 50 % que se cruza a si misma: el cruce no se oscurece
        SimKit k = new SimKit(w, h, new int[w * h]);
        k.cv.setMode(CanvasView.MODE_PAINT);
        k.cv.setColor(0xFF1040C0);
        k.cv.setBrushOpacity(.5f);
        k.cv.setHardness(1f);
        k.cv.setBrushSize(30);
        k.stroke(new float[][]{{50, 200}, {450, 200}, {450, 60}, {250, 60}, {250, 350}}, 1500, 2);
        int aCross = k.layer()[200 * w + 250] >>> 24, aLine = k.layer()[200 * w + 120] >>> 24;
        log("   Opacidad 50 %: alfa en el cruce " + aCross + ", fuera del cruce " + aLine);
        SimKit.check(aCross == aLine, "el cruce se oscurecio");
        log("OK Brocha: 1 a 100 px continua, sin cuentas, grosor parejo, lenta y rapida, sin acumulacion en cruces");
    }

    static void eraser() {
        int w = 400, h = 300;
        int[] img = new int[w * h];
        java.util.Arrays.fill(img, 0xFFE0A030);
        SimKit k = new SimKit(w, h, img.clone());
        k.cv.setMode(CanvasView.MODE_ERASER);
        k.cv.setBrushOpacity(1f);
        k.cv.setHardness(.3f);
        k.cv.setBrushSize(40);
        k.stroke(new float[][]{{30, 150}, {370, 150}}, 150, 1);
        int[] L = k.layer();
        int colorChanged = 0;
        for (int i = 0; i < L.length; i++) if ((L[i] & 0xFFFFFF) != 0xE0A030) colorChanged++;
        // borde suave: el alfa sube de forma monotona desde el centro del trazo hacia afuera
        boolean mono = true;
        int prev = -1;
        for (int y = 150; y < 190; y++) { int al = L[y * w + 200] >>> 24; if (al < prev) mono = false; prev = al; }
        float[] cl = centerline(L, w, new float[]{30, 150}, new float[]{370, 150}, 25);
        log(String.format("   Goma 40 px dureza 0,3 rapida: alfa en el centro %.0f..%.0f, borde monotono=%s, pixeles con RGB alterado=%d", cl[0], cl[1], mono, colorChanged));
        SimKit.check(cl[1] == 0 && mono && colorChanged == 0, "goma con huecos, borde irregular o color contaminado");
        // borrado parcial (opacidad 40 %)
        SimKit k2 = new SimKit(w, h, img.clone());
        k2.cv.setMode(CanvasView.MODE_ERASER);
        k2.cv.setBrushOpacity(.4f);
        k2.cv.setHardness(1f);
        k2.cv.setBrushSize(30);
        k2.stroke(new float[][]{{30, 100}, {370, 100}, {370, 200}, {30, 200}, {200, 30}, {200, 280}}, 1200, 2);
        int aMid = k2.layer()[100 * w + 200] >>> 24, aCross = k2.layer()[200 * w + 200] >>> 24;
        log("   Goma al 40 %: alfa " + aMid + " en el trazo y " + aCross + " en un cruce (debe ser igual)");
        SimKit.check(aMid == aCross && Math.abs(aMid - 153) <= 2, "borrado parcial irregular");
        log("OK Goma: continua, bordes suaves, solo cambia el alfa, sin acumulacion en cruces");
    }

    // ---------------- relleno ----------------

    /** Manga: fondo blanco, circulo con linea antialias de 'lw' px y un cuadrado; opcional hueco. */
    static int[] mangaShapes(int w, int h, float lw, int gapPx) {
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            float d = Math.abs((float) Math.hypot(x + .5 - 150, y + .5 - 150) - 90);
            float cov = Math.max(0f, Math.min(1f, lw / 2f + .5f - d));
            // hueco arriba del circulo
            if (gapPx > 0 && Math.abs(x + .5 - 150) < gapPx / 2f && y < 150) cov = 0f;
            float d2 = Math.max(Math.abs(x + .5f - 400) - 70, Math.abs(y + .5f - 150) - 70);
            float cov2 = Math.max(0f, Math.min(1f, lw / 2f + .5f - Math.abs(d2)));
            cov = Math.max(cov, cov2);
            int v = (int) (255 * (1 - cov) + .5f);
            px[y * w + x] = 0xFF000000 | (v << 16) | (v << 8) | v;
        }
        return px;
    }

    static int lum(int c) { return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8; }

    /** Mide el relleno de la zona interior del circulo (radio 90 en 150,150). */
    static String fillReport(int[] before, int[] after, int w, int h, float lw, int[] out) {
        int stripes = 0, lighter = 0, leak = 0, inside = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int i = y * w + x;
            float d = (float) Math.hypot(x + .5 - 150, y + .5 - 150) - 90;
            int b = before[i], c = after[i];
            if (lum(b) < 200 && lum(c) > lum(b) + 2) lighter++;               // linea aclarada/tapada
            if (d > lw / 2f + 2f && c != b && (x < 300)) leak++;               // fuga fuera del circulo
            if (d < -lw / 2f - .5f && d > -lw / 2f - 4f) {                     // franja junto a la linea, dentro
                inside++;
                int r = (c >> 16) & 255, g = (c >> 8) & 255;
                if (r > 200 && g > 200) stripes++;                              // quedo blanco
            }
        }
        out[0] = stripes; out[1] = lighter; out[2] = leak;
        return String.format("franja blanca=%d de %d, pixeles de linea aclarados=%d, fuga=%d", stripes, inside, lighter, leak);
    }

    static void fill() {
        int w = 520, h = 300;
        for (float lw : new float[]{1, 2, 3}) {
            int[] img = mangaShapes(w, h, lw, 0);
            SimKit k = new SimKit(w, h, img.clone());
            k.cv.setMode(CanvasView.MODE_BUCKET);
            k.cv.setFillColorLayer(false); // esta prueba mira la misma capa
            k.cv.setColor(0xFFE02020);
            k.cv.setBrushOpacity(1f);
            k.tap(150, 150);
            int[] o = new int[3];
            log(String.format("   Relleno en la misma capa, linea de %.0f px: %s", lw, fillReport(img, k.layer(), w, h, lw, o)));
            if (System.getProperty("dumpfill") != null) {
                java.awt.image.BufferedImage bi = new java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_ARGB);
                bi.setRGB(0, 0, w, h, k.layer(), 0, w);
                try { javax.imageio.ImageIO.write(bi, "png", new java.io.File(System.getProperty("dumpfill") + "_" + (int) lw + ".png")); } catch (Exception e) { }
                int minx = w, miny = h, maxx = 0, maxy = 0, n = 0;
                for (int y = 0; y < h; y++) for (int x = 0; x < 300; x++) {
                    float d = (float) Math.hypot(x + .5 - 150, y + .5 - 150) - 90;
                    if (d > lw / 2f + 2f && k.layer()[y * w + x] != img[y * w + x]) { n++; minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); }
                }
                log("     fuga en " + minx + "," + miny + " - " + maxx + "," + maxy);
            }
            SimKit.check(o[0] == 0 && o[1] == 0 && o[2] == 0, "relleno con franja blanca, linea tapada o fuga");
        }
        // Hueco de 3 px en la linea: no debe escaparse el color
        int[] img = mangaShapes(w, h, 2, 3);
        SimKit k = new SimKit(w, h, img.clone());
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setFillColorLayer(false); // esta prueba mira la misma capa
        k.cv.setColor(0xFFE02020);
        k.tap(150, 150);
        int outsideChanged = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < 300; x++) {
            float d = (float) Math.hypot(x + .5 - 150, y + .5 - 150) - 90;
            if (d > 6 && k.layer()[y * w + x] != img[y * w + x]) outsideChanged++;
        }
        log("   Linea con un hueco de 3 px: pixeles pintados mas de 6 px fuera del circulo=" + outsideChanged + " (solo el tapon del hueco; el fondo no se rellena)");
        if (System.getProperty("dumpfill") != null) {
            java.awt.image.BufferedImage bi = new java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_ARGB);
            bi.setRGB(0, 0, w, h, k.layer(), 0, w);
            try { javax.imageio.ImageIO.write(bi, "png", new java.io.File(System.getProperty("dumpfill") + "_gap.png")); } catch (Exception e) { }
        }
        SimKit.check(outsideChanged <= 12, "el relleno se escapo por el hueco");
        // Imagen a color: rellenar una zona de color plano da EXACTAMENTE el color elegido
        int[] col = new int[w * h];
        java.util.Arrays.fill(col, 0xFFF0E0C0);
        for (int y = 60; y < 240; y++) for (int x = 60; x < 240; x++) col[y * w + x] = 0xFF3060A0;
        for (int y = 58; y < 242; y++) for (int x = 58; x < 242; x++) if (x < 60 || y < 60 || x >= 240 || y >= 240) col[y * w + x] = 0xFF101010;
        SimKit kc = new SimKit(w, h, col.clone());
        kc.cv.setMode(CanvasView.MODE_BUCKET);
        kc.cv.setFillColorLayer(false); // esta prueba mira la misma capa
        kc.cv.setColor(0xFF30C060);
        kc.tap(150, 150);
        int exact = 0, inner = 0;
        for (int y = 64; y < 236; y++) for (int x = 64; x < 236; x++) { inner++; if (kc.layer()[y * w + x] == 0xFF30C060) exact++; }
        int outsideCol = 0;
        for (int i = 0; i < col.length; i++) { int x = i % w, y = i / w; if ((x < 56 || y < 56 || x >= 244 || y >= 244) && kc.layer()[i] != col[i]) outsideCol++; }
        log("   Imagen a color: " + exact + " de " + inner + " pixeles interiores con el color exacto; cambios fuera del contorno=" + outsideCol);
        SimKit.check(exact == inner && outsideCol == 0, "relleno en imagen a color incorrecto");
        log("OK Relleno: sin franjas blancas, lineas de 1 a 3 px intactas, sin fugas (incluido hueco de 3 px)");
    }

    static void fillColorLayer() {
        int w = 520, h = 300;
        int[] img = mangaShapes(w, h, 2, 0);
        SimKit k = new SimKit(w, h, img.clone());
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(0xFFE02020);
        k.call("setFillColorLayer", true);
        int layersBefore = k.project.layers.size();
        k.tap(150, 150);
        k.tap(400, 150);
        int layersAfter = k.project.layers.size();
        int[] orig = k.layer(0);
        int[] comp = k.project.ref();
        int[] o = new int[3];
        String rep = fillReport(img, comp, w, h, 2, o);
        int origChanged = SimKit.diff(orig, img);
        com.pacco.animecut.core.Layer cl = k.project.layers.get(1);
        log("   Colorear en capa aparte (de fabrica): capas " + layersBefore + " -> " + layersAfter + " (modo de la nueva=" + cl.mode
                + ", nombre=" + cl.name + "), dibujo original cambiado=" + origChanged + " pixeles; resultado visible: " + rep);
        SimKit.check(layersAfter == layersBefore + 1 && cl.name.startsWith("Color"), "no se creo una sola capa Color");
        SimKit.check(origChanged == 0, "se modifico el dibujo original");
        SimKit.check(o[0] == 0 && o[1] == 0 && o[2] == 0, "el resultado visible tiene franjas, lineas tapadas o fugas");
        // Deshacer dos veces: vuelve todo
        k.cv.doUndo(); k.cv.doUndo(); Sim.pump(50);
        SimKit.check(k.project.layers.size() == layersBefore && SimKit.diff(k.layer(0), img) == 0, "Deshacer no quito la capa Color");
        k.cv.doRedo(); k.cv.doRedo(); Sim.pump(50);
        SimKit.check(k.project.layers.size() == layersBefore + 1 && SimKit.diff(k.project.ref(), comp) == 0, "Rehacer no repuso la capa Color");
        // Exportacion: la capa Color (Normal) + el dibujo = lo que se ve
        com.pacco.animecut.core.Layer colorL = k.project.layers.get(1);
        int worst = 0;
        int[] base = k.layer(0), cp = colorL.px();
        for (int i = 0; i < cp.length; i++) {
            int sa = cp[i] >>> 24;
            int c = sa == 0 ? base[i] : com.pacco.animecut.core.Project.over(base[i], cp[i], sa);
            int d = Math.max(Math.abs(((c >> 16) & 255) - ((comp[i] >> 16) & 255)), Math.max(Math.abs(((c >> 8) & 255) - ((comp[i] >> 8) & 255)), Math.abs((c & 255) - (comp[i] & 255))));
            worst = Math.max(worst, d);
        }
        log("   Exportar: capa Color + dibujo vs lo que se ve en la app: diferencia maxima " + worst + " niveles");
        SimKit.check(worst <= 2, "la exportacion de la capa Color no coincide con lo que se ve");
        log("OK Colorear en capa aparte: original intacto, Deshacer/Rehacer y exportacion correctos");
    }

    // ---------------- borrar fondo ----------------

    /** Personaje (disco + 5 mechones finos) con borde antialias sobre un fondo liso. cov[] = cobertura real. */
    static int[] character(int w, int h, int fg, int bg, float[] cov) {
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            float c = 0f;
            for (int sy = 0; sy < 4; sy++) for (int sx = 0; sx < 4; sx++) {
                float fx = x + (sx + .5f) / 4f, fy = y + (sy + .5f) / 4f;
                boolean in = Math.hypot(fx - 150, fy - 160) < 70;
                for (int k = 0; k < 5 && !in; k++) {
                    // mechon: linea de 1,5 px desde el disco hacia arriba, inclinada
                    float ax = 110 + k * 20, ay = 110, bx = ax + (k - 2) * 14, by = 30;
                    float vx = bx - ax, vy = by - ay, l2 = vx * vx + vy * vy;
                    float t = Math.max(0, Math.min(1, ((fx - ax) * vx + (fy - ay) * vy) / l2));
                    if (Math.hypot(fx - ax - vx * t, fy - ay - vy * t) < .75f) in = true;
                }
                if (in) c += 1f / 16f;
            }
            cov[y * w + x] = c;
            int r = Math.round(((fg >> 16) & 255) * c + ((bg >> 16) & 255) * (1 - c));
            int g = Math.round(((fg >> 8) & 255) * c + ((bg >> 8) & 255) * (1 - c));
            int b = Math.round((fg & 255) * c + (bg & 255) * (1 - c));
            px[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
        }
        return px;
    }

    /** {fondo que quedo, personaje danado, halo claro sobre negro, error medio del borde sobre negro} */
    static float[] bgReport(int[] out, float[] cov, int fg) {
        int left = 0, damaged = 0, halo = 0, edges = 0;
        double err = 0;
        int fl = lum(fg);
        for (int i = 0; i < out.length; i++) {
            int a = out[i] >>> 24;
            float c = cov[i];
            if (c == 0f && a > 8) left++;
            if (c == 1f && out[i] != (0xFF000000 | fg)) {
                // dentro del personaje puro solo cuenta si cambio de verdad
                if (a < 250 || Math.abs(lum(out[i]) - fl) > 8) { damaged++; if (System.getProperty("bgdbg") != null && damaged <= 6) log(String.format("      dano (%d,%d) a=%d rgb=%06X", i % 300, i / 300, a, out[i] & 0xFFFFFF)); }
            }
            if (c > 0f && c < 1f) {
                edges++;
                float seen = a / 255f * lum(out[i]);        // sobre negro
                float ideal = c * fl;
                err += Math.abs(seen - ideal);
                if (seen > ideal + 24) { halo++; if (System.getProperty("bgdbg") != null && halo <= 12) log(String.format("      halo i=%d (%d,%d) cov=%.2f a=%d rgb=%06X", i, i % 300, i / 300, c, a, out[i] & 0xFFFFFF)); }
                else if (System.getProperty("bgdbg") != null && Math.abs(seen - ideal) > 25 && edges % 7 == 0) log(String.format("      err (%d,%d) cov=%.2f a=%d rgb=%06X", i % 300, i / 300, c, a, out[i] & 0xFFFFFF));
            }
        }
        return new float[]{left, damaged, halo, (float) (err / Math.max(1, edges)), edges};
    }

    // ---------------- borrosidad ----------------

    /** Contraste que queda (%) en la franja central de rayas de 4 px. */
    static float stripeContrast(int[] px, int w, int x0, int x1, int y0, int y1) {
        double s = 0; int n = 0;
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) { s += Math.abs(lum(px[y * w + x]) - 127.5); n++; }
        return (float) (s / n / 127.5 * 100);
    }

    static void blur() {
        int w = 400, h = 200;
        int[] img = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) img[y * w + x] = ((x / 4) % 2 == 0) ? 0xFF000000 : 0xFFFFFFFF;
        float[] res = new float[3];
        long[] durs = {150, 1000, 4000};
        for (int q = 0; q < 3; q++) {
            SimKit k = new SimKit(w, h, img.clone());
            k.cv.setMode(CanvasView.MODE_BLUR);
            k.cv.setBrushSize(30);
            k.call("setEffectStrength", .5f);
            k.stroke(new float[][]{{40, 100}, {360, 100}}, durs[q], 1);
            res[q] = stripeContrast(k.layer(), w, 120, 280, 96, 104);
            if (System.getProperty("dumpdir") != null) dump(k.layer(), w, h, "blur" + q);
        }
        log(String.format("   Borrosidad, mismo trazo en 150 ms / 1 s / 4 s: contraste que queda %.0f%% / %.0f%% / %.0f%% (debe ser casi igual)", res[0], res[1], res[2]));
        SimKit.check(Math.abs(res[0] - res[2]) <= 6 && Math.abs(res[0] - res[1]) <= 6, "la borrosidad depende de la velocidad");
        SimKit.check(res[0] < 70, "la borrosidad casi no hace efecto");
        // Fuerza: 25 % blurs less than 100 %
        float[] byStr = new float[2];
        float[] strs = {.25f, 1f};
        for (int q = 0; q < 2; q++) {
            SimKit k = new SimKit(w, h, img.clone());
            k.cv.setMode(CanvasView.MODE_BLUR);
            k.cv.setBrushSize(30);
            k.call("setEffectStrength", strs[q]);
            k.stroke(new float[][]{{40, 100}, {360, 100}}, 600, 1);
            byStr[q] = stripeContrast(k.layer(), w, 120, 280, 96, 104);
        }
        log(String.format("   Fuerza 25%% / 100%%: contraste que queda %.0f%% / %.0f%%", byStr[0], byStr[1]));
        SimKit.check(byStr[0] > byStr[1] + 15, "la fuerza no cambia la borrosidad");
        // Transparencia: borde rojo sobre transparente sin halo oscuro
        int[] disc = redDisc(300, 220, 150, 110, 60);
        SimKit kd = new SimKit(300, 220, disc.clone());
        kd.cv.setMode(CanvasView.MODE_BLUR);
        kd.cv.setBrushSize(40);
        kd.call("setEffectStrength", 1f);
        kd.stroke(new float[][]{{40, 110}, {150, 30}, {260, 110}, {150, 190}, {40, 110}}, 1500, 2);
        int edgeA = 0;
        for (int c : kd.layer()) { int a = c >>> 24; if (a > 0 && a < 255) edgeA++; }
        log("   Borrosidad sobre el borde de un disco rojo transparente: pixeles contaminados=" + dirtyRed(kd.layer()) + ", pixeles semitransparentes en el borde=" + edgeA);
        SimKit.check(dirtyRed(kd.layer()) == 0, "la borrosidad oscurece los bordes transparentes");
        kd.cv.doUndo(); Sim.pump(50);
        SimKit.check(SimKit.diff(kd.layer(), disc) == 0, "Deshacer de Borrosidad no devuelve el original");
        // Tiempo por trazo (CPU del servidor de pruebas, NO un telefono)
        for (int size : new int[]{30, 120, 300}) {
            int W = 1200, H = 900;
            int[] im = new int[W * H];
            for (int i = 0; i < im.length; i++) im[i] = ((i % W / 4) % 2 == 0) ? 0xFF203040 : 0xFFF0E0D0;
            SimKit kt = new SimKit(W, H, im);
            kt.cv.setMode(CanvasView.MODE_BLUR);
            kt.cv.setBrushSize(size);
            long t0 = System.nanoTime();
            long cpu0 = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            kt.stroke(new float[][]{{100, 450}, {1100, 450}}, 1000, 1);
            long cpu = (java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime() - cpu0) / 1000000;
            log("   Borrosidad pincel " + size + ", trazo de 1000 px en 1200x900: " + cpu + " ms de CPU del hilo de interfaz en total (servidor de pruebas, no telefono)");
        }
        log("OK Borrosidad");
    }

    // ---------------- curva y polilinea ----------------

    /** Cuenta cruces de la linea consigo misma (segmentos no vecinos). */
    static int selfCross(float[] f) {
        int n = f.length / 2 - 1, c = 0;
        for (int i = 0; i < n; i++) for (int j = i + 2; j < n; j++) {
            float ax = f[2 * i], ay = f[2 * i + 1], bx = f[2 * i + 2], by = f[2 * i + 3];
            float cx = f[2 * j], cy = f[2 * j + 1], dx = f[2 * j + 2], dy = f[2 * j + 3];
            float d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax), d2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax);
            float d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx), d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx);
            if (((d1 > 0) != (d2 > 0)) && ((d3 > 0) != (d4 > 0)) && d1 != 0 && d2 != 0 && d3 != 0 && d4 != 0) c++;
        }
        return c;
    }

    static float[] shapeFlat(SimKit k, boolean closed) {
        try {
            java.lang.reflect.Method m = CanvasView.class.getDeclaredMethod("shapeFlat", boolean.class);
            m.setAccessible(true);
            return (float[]) m.invoke(k.cv, closed);
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    static void shapes() {
        int w = 400, h = 300;
        // Polilinea al 50 %: las esquinas no deben quedar mas oscuras
        SimKit k = new SimKit(w, h, new int[w * h]);
        k.cv.setMode(CanvasView.MODE_POLY);
        k.cv.setColor(0xFF000000);
        k.cv.setBrushOpacity(.5f);
        k.cv.setBrushSize(12);
        float[][] pts = {{50, 250}, {200, 50}, {350, 250}, {60, 240}};
        for (float[] p : pts) k.tap(p[0], p[1]);
        k.cv.commitShape(); Sim.pump(50);
        int maxA = 0, segA = k.layer()[150 * w + (int) (50 + (200 - 50) * (100 / 200f))] >>> 24;
        for (int c : k.layer()) maxA = Math.max(maxA, c >>> 24);
        log("   Polilinea al 50 % con esquinas y cruce: alfa en el tramo=" + segA + ", alfa maximo (esquinas y cruce)=" + maxA);
        SimKit.check(maxA <= 129, "la polilinea se oscurece en las uniones");
        k.cv.doUndo(); Sim.pump(50);
        SimKit.check(SimKit.diff(k.layer(), new int[w * h]) == 0, "Deshacer de Polilinea no devuelve el original");
        // Curva con puntos a distancias muy distintas: no debe formar lazos ni ganchos
        SimKit kc = new SimKit(w, h, new int[w * h]);
        kc.cv.setMode(CanvasView.MODE_CURVE);
        float[][] cp = {{100, 200}, {106, 120}, {300, 110}, {306, 200}, {200, 280}};
        for (float[] p : cp) kc.tap(p[0], p[1]);
        float[] f = shapeFlat(kc, false);
        float minX = 1e9f;
        for (int i = 0; i < f.length; i += 2) minX = Math.min(minX, f[i]);
        int cross = selfCross(f);
        log(String.format("   Curva con puntos desparejos: cruces de la linea consigo misma=%d, se sale a la izquierda de los puntos %.1f px", cross, Math.max(0, 100 - minX)));
        SimKit.check(cross == 0 && minX > 94, "la curva forma un lazo o un gancho");
        kc.cv.setBrushOpacity(.5f);
        kc.cv.setBrushSize(10);
        kc.cv.commitShape(); Sim.pump(50);
        int maxC = 0;
        for (int c : kc.layer()) maxC = Math.max(maxC, c >>> 24);
        log("   Curva al 50 %: alfa maximo=" + maxC + " (sin zonas mas oscuras)");
        SimKit.check(maxC <= 129, "la curva al 50 % tiene zonas mas oscuras");
        log("OK Curva y Polilinea");
    }

    // ---------------- lazo: copiar / cortar a capa ----------------

    static void lassoCut() {
        int w = 300, h = 240;
        for (int variant = 0; variant < 2; variant++) {
            int[] img = new int[w * h];
            // dibujo: fondo de rayas de colores (opaco o semitransparente)
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++)
                img[y * w + x] = ((variant == 0 ? 255 : 150) << 24) | (((x / 6) % 2 == 0) ? 0x3060C0 : 0xE0A040);
            SimKit k = new SimKit(w, h, img.clone());
            byte[] sel = k.project.selection;
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                float d = (float) Math.hypot(x + .5f - 150, y + .5f - 120);
                float a = Math.max(0f, Math.min(1f, 70.5f - d));   // seleccion con borde antialias
                sel[y * w + x] = (byte) Math.round(a * 255);
            }
            int[] before = k.project.ref().clone();
            int layers = k.project.layers.size();
            k.cv.layerFromSelection(true, 0, "brazo");
            Sim.pump(50);
            int[] after = k.project.ref();
            if (System.getProperty("dumpdir") != null && variant == 0) dump(after, w, h, "cut");
            int worst = 0, seam = 0;
            for (int i = 0; i < before.length; i++) {
                int da = Math.abs((before[i] >>> 24) - (after[i] >>> 24));
                int dc = 0;
                for (int sh = 0; sh <= 16; sh += 8) dc = Math.max(dc, Math.abs(((before[i] >> sh) & 255) - ((after[i] >> sh) & 255)));
                int d = Math.max(da, (before[i] >>> 24) > 0 ? dc : 0);
                worst = Math.max(worst, d);
                if (d > 3) seam++;
            }
            com.pacco.animecut.core.Layer part = k.project.layers.get(1);
            // Residuo al mover la parte: lo que queda en la capa de abajo donde la seleccion era mayoria
            int ghost = 0, ghostMax = 0, partSoft = 0;
            for (int i = 0; i < img.length; i++) {
                int sv = sel[i] & 255, a = k.layer(0)[i] >>> 24, pa = part.px()[i] >>> 24;
                if (sv >= 128 && sv < 255) { if (a > 96) ghost++; ghostMax = Math.max(ghostMax, a); }
                if (pa > 0 && pa < (img[i] >>> 24) - 8) partSoft++;
            }
            log("     al mover la parte: borde que queda en la capa de abajo con alfa > 96 = " + ghost + " px (alfa maximo " + ghostMax
                    + "); borde suave de la parte = " + partSoft + " px");
            SimKit.check(ghost == 0, "al mover la parte queda su contorno en la capa de abajo");
            SimKit.check(partSoft > 100, "la parte perdio el borde suave");
            log("   Cortar a capa (" + (variant == 0 ? "dibujo opaco" : "dibujo semitransparente") + ", borde de seleccion suave): capas " + layers + " -> " + k.project.layers.size()
                    + ", parte en " + part.name + "; sin mover la parte, pixeles distintos al original=" + seam + " (diferencia maxima " + worst + " niveles)");
            SimKit.check(seam == 0, "al cortar queda una linea visible alrededor de la parte");
            // la parte conserva la posicion: su pixel central es el del original
            SimKit.check(part.px()[120 * w + 150] == img[120 * w + 150], "la parte no conserva la posicion");
            k.cv.doUndo(); Sim.pump(50);
            SimKit.check(k.project.layers.size() == layers && SimKit.diff(k.layer(0), img) == 0, "Deshacer de Cortar a capa no devuelve el original");
        }
        log("OK Cortar a capa");
    }

    static void gapLevels() {
        int w = 520, h = 300;
        for (int lvl : new int[]{3, 4, 6, 8, 12}) {
            StringBuilder sb = new StringBuilder();
            for (int gap : new int[]{3, 6, 9, 12, 16, 20}) {
                int[] img = mangaShapes(w, h, 2, gap);
                SimKit k = new SimKit(w, h, img.clone());
                k.cv.setMode(CanvasView.MODE_BUCKET);
                k.cv.setFillColorLayer(false); // esta prueba mira la misma capa
                k.cv.setColor(0xFFE02020);
                k.cv.setGap(k.cv.isGapOn(), lvl);
                k.tap(150, 150);
                int out = 0;
                for (int y = 0; y < h; y++) for (int x = 0; x < 300; x++) {
                    float d = (float) Math.hypot(x + .5 - 150, y + .5 - 150) - 90;
                    if (d > 6 && k.layer()[y * w + x] != img[y * w + x]) out++;
                }
                sb.append(" corte ").append(gap).append(" px:").append(out > 200 ? "SE ESCAPA" : "cerrado");
            }
            log("   Nivel " + lvl + ":" + sb);
        }
    }

    // ---------------- capas, guardar, abrir, exportar, extraer lineas ----------------

    static int[] readPng(byte[] png, int[] wh) throws Exception {
        java.awt.image.BufferedImage bi = javax.imageio.ImageIO.read(new java.io.ByteArrayInputStream(png));
        wh[0] = bi.getWidth(); wh[1] = bi.getHeight();
        int[] p = new int[wh[0] * wh[1]];
        bi.getRGB(0, 0, wh[0], wh[1], p, 0, wh[0]);
        return p;
    }

    static void layers() throws Exception {
        int w = 520, h = 300;
        int[] img = mangaShapes(w, h, 2, 0);
        SimKit k = new SimKit(w, h, img.clone());
        // 1. Extraer lineas
        com.pacco.animecut.core.LineArt.Extract ex = new com.pacco.animecut.core.LineArt.Extract();
        k.cv.extractLinesLayer(ex, false);
        Sim.pump(400);
        SimKit.check(k.project.layers.size() == 2, "Extraer lineas no creo la capa");
        com.pacco.animecut.core.Layer ln = k.project.layers.get(1);
        int[] L = ln.px();
        int paper = 0, paperClear = 0, worst = 0, lineOpaque = 0, lineN = 0;
        for (int i = 0; i < L.length; i++) {
            int o = img[i], a = L[i] >>> 24;
            if (lum(o) >= 250) { paper++; if (a == 0) paperClear++; }
            if (lum(o) < 4) { lineN++; if (a >= 250) lineOpaque++; }
            // lineas sobre blanco = original
            int c = com.pacco.animecut.core.Project.over(0xFFFFFFFF, L[i], a);
            worst = Math.max(worst, Math.abs(lum(c) - lum(o)));
        }
        log("   Extraer lineas: papel transparente " + paperClear + " de " + paper + ", linea negra opaca " + lineOpaque + " de " + lineN
                + ", lineas sobre blanco vs original: diferencia maxima " + worst + " niveles; original intacto=" + (SimKit.diff(k.layer(0), img) == 0));
        SimKit.check(paperClear == paper && lineOpaque == lineN && worst <= 16 && SimKit.diff(k.layer(0), img) == 0, "Extraer lineas incorrecto");
        // Colorear debajo de las lineas: Relleno en la capa original con Lineas encima
        k.project.active = 0;
        k.cv.setMode(CanvasView.MODE_BUCKET);
        k.cv.setColor(0xFF3080E0);
        k.tap(150, 150);
        int[] comp = k.project.ref();
        int covered = 0;
        for (int i = 0; i < comp.length; i++) if (lum(img[i]) < 60 && lum(comp[i]) > lum(img[i]) + 10) covered++;
        log("   Relleno debajo de la capa Lineas: pixeles de linea tapados=" + covered);
        SimKit.check(covered == 0, "el color tapo las lineas");
        k.cv.doUndo(); Sim.pump(50);
        k.cv.doUndo(); Sim.pump(50);
        SimKit.check(k.project.layers.size() == 1 && SimKit.diff(k.layer(0), img) == 0, "Deshacer de Extraer lineas no vuelve atras");
        // 2. Capas: nueva, duplicar, mover, bloquear transparencia, eliminar, deshacer/rehacer
        k.cv.addEmptyLayer(); Sim.pump(20);
        int n1 = k.project.layers.size();
        com.pacco.animecut.core.Layer empty = k.project.activeLayer();
        k.cv.duplicateActive(); Sim.pump(20);
        k.cv.moveActive(-1); Sim.pump(20);
        int n2 = k.project.layers.size();
        // bloquear transparencia en la capa de dibujo: pintar solo cambia lo que ya tenia alfa
        int[] disc = redDisc(w, h, 260, 150, 50);
        SimKit kl = new SimKit(w, h, disc.clone());
        kl.cv.setLayerAlphaLock(kl.project.activeLayer(), true);
        kl.cv.setMode(CanvasView.MODE_PAINT);
        kl.cv.setColor(0xFF0000FF);
        kl.cv.setBrushSize(40);
        kl.cv.setBrushOpacity(1f);
        kl.stroke(new float[][]{{100, 150}, {420, 150}}, 400, 1);
        int outside = 0, alphaChanged = 0, inside = 0;
        for (int i = 0; i < disc.length; i++) {
            int b = kl.layer()[i];
            if ((disc[i] >>> 24) == 0 && b != 0) outside++;
            if ((disc[i] >>> 24) != (b >>> 24)) alphaChanged++;
            if ((disc[i] >>> 24) == 255 && (b & 0xFFFFFF) == 0x0000FF) inside++;
        }
        log("   Bloquear transparencia: pintado fuera del dibujo=" + outside + ", alfa cambiado=" + alphaChanged + ", pintado dentro=" + inside);
        SimKit.check(outside == 0 && alphaChanged == 0 && inside > 1000, "bloquear transparencia no funciona");
        // seleccionar y ocultar: la capa oculta no se ve ni cuenta para el balde
        k.cv.setActive(0); Sim.pump(20);
        boolean selOk = k.project.active == 0;
        com.pacco.animecut.core.Layer top = k.project.layers.get(k.project.layers.size() - 1);
        int[] topPx = top.px();
        java.util.Arrays.fill(topPx, 0xFFFF00FF);
        k.project.markDirty();
        boolean visibleSeen = (k.project.ref()[0] & 0xFFFFFF) == 0xFF00FF;
        top.visible = false; k.project.markDirty();
        boolean hiddenGone = (k.project.ref()[0] & 0xFFFFFF) != 0xFF00FF;
        top.visible = true; java.util.Arrays.fill(topPx, 0); k.project.markDirty();
        log("   Seleccionar capa=" + selOk + ", capa visible se ve=" + visibleSeen + ", oculta no se ve=" + hiddenGone);
        SimKit.check(selOk && visibleSeen && hiddenGone, "seleccionar u ocultar capas falla");
        k.project.active = k.project.layers.size() - 1;
        k.cv.deleteActive(); Sim.pump(20);
        int n3 = k.project.layers.size();
        log("   Capas: nueva -> " + n1 + ", duplicar y mover -> " + n2 + ", eliminar -> " + n3);
        SimKit.check(n1 == 2 && n2 == 3 && n3 == 2, "operaciones de capas incorrectas");
        for (int u = 0; u < 4; u++) { k.cv.doUndo(); Sim.pump(20); }
        SimKit.check(k.project.layers.size() == 1, "Deshacer de capas incorrecto");
        for (int u = 0; u < 4; u++) { k.cv.doRedo(); Sim.pump(20); }
        SimKit.check(k.project.layers.size() == 2, "Rehacer de capas incorrecto");
        // 3. Guardar y abrir (con capa Color en Multiplicar y transparencia bloqueada)
        SimKit ks = new SimKit(w, h, img.clone());
        ks.cv.setMode(CanvasView.MODE_BUCKET);
        ks.cv.setColor(0xFFE02020);
        ks.call("setFillColorLayer", true);
        ks.tap(150, 150);
        ks.cv.setLayerAlphaLock(ks.project.layers.get(0), true);
        ks.project.layers.get(0).reference = true; // v8.24: referencia del balde
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        com.pacco.animecut.core.ProjectIO.save(bo, ks.project, 0xFF123456);
        com.pacco.animecut.core.ProjectIO.Loaded ld = com.pacco.animecut.core.ProjectIO.load(new java.io.ByteArrayInputStream(bo.toByteArray()));
        com.pacco.animecut.core.Project q = ld.project;
        boolean same = q.layers.size() == ks.project.layers.size();
        int pxDiff = 0;
        for (int i = 0; same && i < q.layers.size(); i++) {
            com.pacco.animecut.core.Layer x = q.layers.get(i), y = ks.project.layers.get(i);
            same = x.name.equals(y.name) && x.mode == y.mode && x.alphaLock == y.alphaLock && x.visible == y.visible
                    && x.reference == y.reference;
            pxDiff += SimKit.diff(x.px(), y.px());
        }
        log("   Guardar y abrir: " + q.layers.size() + " capas, nombres/modos/bloqueo/referencia iguales=" + same + ", pixeles distintos=" + pxDiff + " (" + bo.size() / 1024 + " KB)");
        SimKit.check(same && pxDiff == 0, "guardar/abrir pierde informacion");
        // 4. Obra antigua sin la linea "fx" (versiones anteriores): todas las capas en Normal
        java.util.zip.ZipInputStream zi = new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(bo.toByteArray()));
        java.io.ByteArrayOutputStream old = new java.io.ByteArrayOutputStream();
        java.util.zip.ZipOutputStream zo = new java.util.zip.ZipOutputStream(old);
        java.util.zip.ZipEntry e;
        while ((e = zi.getNextEntry()) != null) {
            byte[] data = zi.readAllBytes();
            if (e.getName().equals("meta.txt")) {
                StringBuilder sb = new StringBuilder();
                for (String line : new String(data, "UTF-8").split("\n")) if (!line.startsWith("fx")) sb.append(line).append('\n');
                data = sb.toString().getBytes("UTF-8");
            }
            zo.putNextEntry(new java.util.zip.ZipEntry(e.getName()));
            zo.write(data);
            zo.closeEntry();
        }
        zo.close();
        com.pacco.animecut.core.Project qo = com.pacco.animecut.core.ProjectIO.load(new java.io.ByteArrayInputStream(old.toByteArray())).project;
        boolean allNormal = true;
        for (com.pacco.animecut.core.Layer x : qo.layers) if (x.mode != com.pacco.animecut.core.Layer.MODE_NORMAL || x.alphaLock) allNormal = false;
        log("   Obra antigua (sin modos guardados): abre con " + qo.layers.size() + " capas, todas en Normal=" + allNormal);
        SimKit.check(qo.layers.size() == 2 && allNormal, "una obra antigua no abre bien");
        // 5. Exportar PNG transparente (capa del disco rojo) y la capa Color mezclada
        final java.io.ByteArrayOutputStream[] sink = new java.io.ByteArrayOutputStream[1];
        android.content.ContentResolver cr = new android.content.ContentResolver() {
            @Override public java.io.OutputStream openOutputStream(android.net.Uri u) { sink[0] = new java.io.ByteArrayOutputStream(); return sink[0]; }
        };
        com.pacco.animecut.core.Exporter.exportLayer(cr, kl.project, kl.project.layers.get(0), null, 0);
        int[] wh = new int[2];
        int[] png = readPng(sink[0].toByteArray(), wh);
        com.pacco.animecut.core.Layer src = kl.project.layers.get(0);
        android.graphics.Rect bb = src.bounds(w, h);
        int bad = 0, trans = 0;
        for (int y = 0; y < wh[1]; y++) for (int x = 0; x < wh[0]; x++) {
            int ox = wh[0] == w ? 0 : bb.left, oy = wh[1] == h ? 0 : bb.top;
            int a = png[y * wh[0] + x], b = src.px()[(y + oy) * w + x + ox];
            if ((a >>> 24) == 0) trans++;
            if ((a >>> 24) != (b >>> 24) || ((a >>> 24) > 0 && (a & 0xFFFFFF) != (b & 0xFFFFFF))) bad++;
        }
        log("   Exportar PNG transparente: " + wh[0] + "x" + wh[1] + ", pixeles transparentes=" + trans + ", pixeles distintos a la capa=" + bad);
        SimKit.check(bad == 0 && trans > 0, "el PNG exportado no coincide con la capa");
        log("OK Capas, guardar, abrir obras antiguas, exportar PNG y extraer lineas");
    }

    // ---------------- pruebas adicionales pedidas ----------------

    static int[] colorDisc(int w, int h, float cx, float cy, float r, int rgb) {
        int[] px = redDisc(w, h, cx, cy, r);
        for (int i = 0; i < px.length; i++) if (px[i] != 0) px[i] = (px[i] & 0xFF000000) | rgb;
        return px;
    }

    /** Pixeles visibles cuyo RGB se aparto mas de 6 niveles del color del disco. */
    static int dirtyColor(int[] px, int rgb) {
        int n = 0;
        for (int c : px) {
            if ((c >>> 24) < 3) continue;
            int d = Math.max(Math.abs(((c >> 16) & 255) - ((rgb >> 16) & 255)), Math.max(Math.abs(((c >> 8) & 255) - ((rgb >> 8) & 255)), Math.abs((c & 255) - (rgb & 255))));
            if (d > 6) n++;
        }
        return n;
    }

    static void extras() {
        int w = 300, h = 220;
        // Difuminar con color claro y oscuro sobre transparente
        for (int rgb : new int[]{0xFFF080, 0x202060}) {
            SimKit k = new SimKit(w, h, colorDisc(w, h, 150, 110, 60, rgb));
            k.cv.setMode(CanvasView.MODE_SMUDGE);
            k.cv.setBrushSize(50);
            k.cv.setEffectStrength(.8f);
            for (int rep = 0; rep < 3; rep++) {
                k.stroke(new float[][]{{150, 110}, {260, 110}}, 400, 2);
                k.stroke(new float[][]{{150, 110}, {150, 210}}, 400, 2);
            }
            int d = dirtyColor(k.layer(), rgb);
            log(String.format("   Difuminar color %s #%06X sobre transparente: pixeles con color contaminado (halo)=%d", rgb == 0xFFF080 ? "claro" : "oscuro", rgb, d));
            SimKit.check(d == 0, "Difuminar contamina un color " + Integer.toHexString(rgb));
        }
        // Goma sobre cabello fino (mechones de 1,5 px con antialias)
        {
            int W = 300, H = 260;
            float[] cov = new float[W * H];
            int[] hair = character(W, H, 0xFF1A2A6A, 0xFFFFFFFF, cov);
            for (int i = 0; i < hair.length; i++) hair[i] = cov[i] == 0 ? 0 : ((Math.round(cov[i] * 255) << 24) | 0x1A2A6A);
            SimKit k = new SimKit(W, H, hair.clone());
            k.cv.setMode(CanvasView.MODE_ERASER);
            k.cv.setBrushSize(16);
            k.cv.setHardness(.5f);
            k.cv.setBrushOpacity(1f);
            k.stroke(new float[][]{{60, 60}, {240, 60}}, 300, 1);
            int rgbChanged = 0, alphaUp = 0, farChanged = 0, erasedOnLine = 0, onLine = 0;
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                int i = y * W + x, o = hair[i], c = k.layer()[i];
                if ((c >>> 24) > 0 && (c & 0xFFFFFF) != (o & 0xFFFFFF)) rgbChanged++;
                if ((c >>> 24) > (o >>> 24)) alphaUp++;
                if (Math.abs(y - 60) > 12 && c != o) farChanged++;
                if (Math.abs(y - 60) <= 3 && (o >>> 24) > 0) { onLine++; if ((c >>> 24) == 0) erasedOnLine++; }
            }
            log("   Goma 16 px sobre mechones finos: borrados en el centro del trazo " + erasedOnLine + " de " + onLine + ", RGB alterado=" + rgbChanged + ", alfa aumentado=" + alphaUp + ", cambios lejos del trazo=" + farChanged);
            SimKit.check(erasedOnLine == onLine && rgbChanged == 0 && alphaUp == 0 && farChanged == 0, "Goma sobre cabello fino incorrecta");
        }
        // Pintar con zoom al 100 %, 200 % y 400 %: el trazo cae donde va el dedo
        for (float z : new float[]{1f, 2f, 4f}) {
            SimKit k = new SimKit(400, 300, new int[400 * 300]);
            android.graphics.Matrix m = (android.graphics.Matrix) k.get("view");
            m.reset();
            m.postScale(z, z);
            m.postTranslate(-100 * z + 200, -150 * z + 300);
            k.cv.setMode(CanvasView.MODE_PAINT);
            k.cv.setColor(0xFF000000);
            k.cv.setBrushSize(6);
            k.stroke(new float[][]{{80, 130}, {120, 170}}, 300, 1);
            int painted = 0, off = 0;
            for (int y = 0; y < 300; y++) for (int x = 0; x < 400; x++) {
                if ((k.layer()[y * 400 + x] >>> 24) == 0) continue;
                painted++;
                float t = Math.max(0, Math.min(1, ((x + .5f - 80) * 40 + (y + .5f - 130) * 40) / 3200f));
                if (Math.hypot(x + .5f - 80 - 40 * t, y + .5f - 130 - 40 * t) > 4.5) off++;
            }
            log(String.format("   Zoom %.0f%%: %d pixeles pintados, %d fuera de la linea esperada", z * 100, painted, off));
            SimKit.check(painted > 150 && off == 0, "pintar con zoom no cae donde va el dedo");
        }
        // Cambiar de herramienta rapido, incluso con el dedo abajo: nada a medias y Deshacer limpio
        {
            int[] img = new int[300 * 220];
            java.util.Arrays.fill(img, 0xFFE0C090);
            SimKit k = new SimKit(300, 220, img.clone());
            int[] modes = {CanvasView.MODE_PAINT, CanvasView.MODE_BLUR, CanvasView.MODE_ERASER, CanvasView.MODE_SMUDGE,
                    CanvasView.MODE_BGERASE, CanvasView.MODE_LIQUIFY, CanvasView.MODE_PAINT};
            int strokes = 0;
            for (int q = 0; q < modes.length; q++) {
                k.cv.setMode(modes[q]);
                float[] a0 = k.screen(40 + q * 30, 50), a1 = k.screen(60 + q * 30, 150);
                k.touch(android.view.MotionEvent.ACTION_DOWN, a0);
                Sim.pump(16);
                k.touch(android.view.MotionEvent.ACTION_MOVE, a1);
                Sim.pump(16);
                k.cv.setMode(modes[(q + 1) % modes.length]);   // cambio con el dedo abajo
                Sim.pump(16);
                k.touch(android.view.MotionEvent.ACTION_UP, a1);
                Sim.pump(300);
                strokes++;
            }
            for (int u = 0; u < 20; u++) { k.cv.doUndo(); Sim.pump(30); }
            int left = SimKit.diff(k.layer(), img);
            log("   " + strokes + " cambios de herramienta con el dedo abajo: sin errores; tras Deshacer todo, pixeles distintos al original=" + left);
            SimKit.check(left == 0, "cambiar de herramienta deja cambios que Deshacer no quita");
        }
        log("OK Pruebas adicionales: Difuminar claro/oscuro, Goma en cabello, zoom 100-400 %, cambio rapido de herramienta");
    }

    static void dump(int[] px, int w, int h, String name) {
        java.awt.image.BufferedImage bi = new java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        bi.setRGB(0, 0, w, h, px, 0, w);
        try { javax.imageio.ImageIO.write(bi, "png", new java.io.File(System.getProperty("dumpdir"), name + ".png")); } catch (Exception e) { }
    }

    // ---------------- Lineas en imagen a color ----------------

    static void linesColor() throws Exception {
        int W = BucketTest.W, H = BucketTest.H;
        com.pacco.animecut.core.LineArt.Extract bw = new com.pacco.animecut.core.LineArt.Extract();
        com.pacco.animecut.core.LineArt.Extract col = new com.pacco.animecut.core.LineArt.Extract();
        col.colored = true;
        boolean c1 = com.pacco.animecut.core.LineArt.isColored(BucketTest.anime());
        boolean c2 = com.pacco.animecut.core.LineArt.isColored(BucketTest.kanji());
        log("   Deteccion de imagen a color: anime=" + c1 + ", manga blanco y negro=" + c2);
        SimKit.check(c1 && !c2, "no distingue imagen a color de blanco y negro");
        for (int jp = 0; jp < 2; jp++) {
            int[] img = jp == 0 ? BucketTest.anime() : BucketTest.jpeg(BucketTest.anime(), .6f);
            int[][] res = {com.pacco.animecut.core.LineArt.extract(img, W, H, bw), com.pacco.animecut.core.LineArt.extract(img, W, H, col)};
            String[] nm = {"solo brillo (como v8.23)", "a color (trazos finos)"};
            for (int m = 0; m < 2; m++) {
                int[] L = res[m];
                int ring = 0, ringOk = 0, hair = 0, shadow = 0, skin = 0, sky = 0;
                for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                    int i = y * W + x, a = L[i] >>> 24;
                    double d = Math.hypot(x + .5 - 170, y + .5 - 130);
                    if (Math.abs(d - 90) < .6 && y > 80) { ring++; if (a >= 128) ringOk++; }
                    if (d < 80 && y < 68 && a > 40) hair++;
                    if (d < 80 && y > 85 && x > 196 && a > 40) shadow++;
                    if (d < 80 && y > 85 && x < 184 && a > 40) skin++;
                    if (d > 96 && y < 228 && a > 40) sky++;
                }
                log("   Lineas " + nm[m] + (jp == 1 ? " JPEG" : "") + ": contorno detectado " + ringOk + " de " + ring
                        + "; tomado como linea por error: pelo=" + hair + ", sombra=" + shadow + ", piel=" + skin + ", fondo=" + sky + " px");
                if (m == 1) SimKit.check(ringOk >= ring * .9 && hair == 0 && shadow == 0 && skin == 0 && sky == 0,
                        "Lineas a color confunde zonas con lineas");
            }
        }
        log("OK Lineas: en imagenes a color separa solo los trazos, no pelo, sombras ni colores");
    }

    // ---------------- brocha cerca de lineas ----------------

    static void brushLines() {
        int w = 520, h = 300;
        int[] img = mangaShapes(w, h, 2, 0);  // circulo con linea de 2 px en (150,150) r=90
        for (int variant = 0; variant < 2; variant++) {
            for (int prot = 0; prot < 2; prot++) {
                SimKit k = new SimKit(w, h, img.clone());
                if (variant == 1) { k.cv.addEmptyLayer(); Sim.pump(20); }
                k.cv.setMode(CanvasView.MODE_PAINT);
                k.cv.setColor(0xFF3070E0);
                k.cv.setBrushOpacity(1f);
                k.cv.setBrushSize(30);
                k.call("setLineStop", prot == 1);
                Sim.pump(300);
                // trazo pegado por dentro de la linea, que se pasa un poco afuera
                java.util.ArrayList<float[]> pts = new java.util.ArrayList<>();
                for (int a = 200; a <= 340; a += 4) {
                    double r = Math.toRadians(a);
                    pts.add(new float[]{(float) (150 + 84 * Math.cos(r)), (float) (150 + 84 * Math.sin(r))});
                }
                k.stroke(pts.toArray(new float[0][]), 900, 2);
                int[] c = k.project.ref();
                int lighter = 0, crossed = 0, gaps = 0, gapArea = 0;
                for (int y = 0; y < h; y++) for (int x = 0; x < 300; x++) {
                    int i = y * w + x;
                    double d = Math.hypot(x + .5 - 150, y + .5 - 150) - 90;
                    double ang = Math.toDegrees(Math.atan2(y + .5 - 150, x + .5 - 150));
                    if (ang < 0) ang += 360;
                    boolean inArc = ang > 210 && ang < 330;
                    if (lum(img[i]) < 80 && lum(c[i]) > lum(img[i]) + 25) lighter++;
                    if (d > 2.5 && c[i] != img[i]) crossed++;
                    if (inArc && d < -1.5 && d > -6) { gapArea++; if (lum(c[i]) > 200) gaps++; }
                }
                String nm = (variant == 0 ? "misma capa" : "capa nueva") + (prot == 1 ? ", NO pasar la linea" : ", pincel libre");
                log("   Brocha 30 px junto a la linea (" + nm + "): linea aclarada/tapada=" + lighter + ", pintado del otro lado=" + crossed
                        + ", huecos blancos junto a la linea=" + gaps + " de " + gapArea);
                if (prot == 1) SimKit.check(lighter == 0 && crossed == 0 && gaps == 0, "la proteccion de lineas falla: " + nm);
                else SimKit.check(crossed > 100, "el pincel libre deberia pasar la linea");
            }
        }
        log("OK Brocha cerca de lineas: con proteccion no tapa ni cruza la linea y no deja huecos; libre, pinta normal");
    }

    static boolean k0Available() {
        try { com.pacco.animecut.core.BackgroundEraseAlpha.class.getMethod("refineEdges", int[].class, int.class, int.class, int.class, int.class, int.class, int.class, byte[].class, byte[].class, byte[].class, int.class, int.class, int.class, int.class); return true; }
        catch (Exception e) { return false; }
    }

    static void bgErase() {
        int w = 300, h = 260;
        int[][] cases = {{0xFF1A2A6A, 0xFFFFFFFF}, {0xFFE07020, 0xFF8CD88C}};
        String[] names = {"azul oscuro sobre blanco", "naranja sobre verde claro"};
        for (int ci = 0; ci < 2; ci++) {
            int fg = cases[ci][0] & 0xFFFFFF, bg = cases[ci][1];
            float[] cov = new float[w * h];
            int[] img = character(w, h, cases[ci][0], bg, cov);
            for (int pass = 0; pass < 2; pass++) {
                SimKit k = new SimKit(w, h, img.clone());
                k.cv.setMode(CanvasView.MODE_BGERASE);
                k.cv.setBgBucket(pass == 0);
                k.cv.setBrushOpacity(1f);
                if (pass == 0) k.tap(20, 240);
                else {
                    k.cv.setBrushSize(60);
                    // recorrer todo el fondo con el pincel (zigzag)
                    java.util.ArrayList<float[]> pts = new java.util.ArrayList<>();
                    for (int y = 10; y < h; y += 22) { pts.add(new float[]{5, y}); pts.add(new float[]{w - 5, y}); }
                    k.stroke(pts.toArray(new float[0][]), 4000, 3);
                }
                float[] r = bgReport(k.layer(), cov, fg);
                if (System.getProperty("dumpdir") != null && ci == 0 && pass == 0) dump(k.layer(), w, h, "bg");
                log(String.format("   Borrar fondo %s (%s): fondo que quedo=%.0f px, personaje danado=%.0f px, halo claro en el borde sobre negro=%.0f de %.0f, error medio del borde=%.1f niveles",
                        pass == 0 ? "toque" : "pincel", names[ci], r[0], r[1], r[2], r[4], r[3]));
                SimKit.check(r[1] == 0, "Borrar fondo dano el personaje");
                k.cv.doUndo(); Sim.pump(50);
                int undoDiff = SimKit.diff(k.layer(), img);
                if (undoDiff != 0) log("     Deshacer dejo " + undoDiff + " pixeles distintos");
                SimKit.check(undoDiff == 0, "Deshacer de Borrar fondo no devuelve el original");
                SimKit.check(r[2] <= r[4] * .05f, "Borrar fondo deja halo claro en el borde");
            }
        }
        // Fondo con ruido (como JPEG) y piel clara sobre blanco: sin motas recuperadas ni piel comida
        {
            float[] cov = new float[w * h];
            int[] img = character(w, h, 0xFFF6DCC8, 0xFFFFFFFF, cov);
            java.util.Random rnd = new java.util.Random(7);
            for (int i = 0; i < img.length; i++) {
                int n = rnd.nextInt(13) - 6, c = img[i];
                int r = Math.max(0, Math.min(255, ((c >> 16) & 255) + n)), g = Math.max(0, Math.min(255, ((c >> 8) & 255) + n)), b = Math.max(0, Math.min(255, (c & 255) + n));
                img[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
            for (int dec = 0; dec < 2; dec++) {
                SimKit k = new SimKit(w, h, img.clone());
                k.cv.setMode(CanvasView.MODE_BGERASE);
                k.cv.setBgBucket(true);
                k.cv.setBgTolerance(10);
                k.cv.setBgSoftness(12);
                try { k.call("setBgDecontam", dec == 1); } catch (RuntimeException e) { if (dec == 0) continue; }
                k.tap(20, 240);
                int[] o = k.layer();
                int specks = 0, skinLost = 0, skin = 0, minA = 255;
                for (int i = 0; i < o.length; i++) {
                    if (cov[i] == 0f && (o[i] >>> 24) > 8) specks++;
                    if (cov[i] == 1f) { skin++; if ((o[i] >>> 24) < 250) skinLost++; minA = Math.min(minA, o[i] >>> 24); }
                }
                log("   Piel clara sobre blanco con ruido, tolerancia 10 (" + (dec == 1 ? "con" : "sin") + " limpieza de filo): motas de fondo que quedan=" + specks + ", piel pura con alfa bajado=" + skinLost + " de " + skin + " (alfa minimo " + minA + ")");
                if (dec == 1) SimKit.check(specks <= 20 && minA >= 200, "la limpieza del filo deja motas o adelgaza la piel");
            }
        }
        // Tiempo del trabajo de fondo (sin la espera simulada): relleno + alfa + filo en 2000x2000
        if (k0Available()) {
            int W2 = 2000, H2 = 2000;
            int[] im = new int[W2 * H2];
            for (int y = 0; y < H2; y++) for (int x = 0; x < W2; x++) {
                float d = 1e9f;
                for (int q = 0; q < 9; q++) d = Math.min(d, (float) Math.hypot(x + .5 - (300 + (q % 3) * 700), y + .5 - (300 + (q / 3) * 700)) - 200);
                float cv2 = Math.max(0f, Math.min(1f, .5f - d));
                int v = (int) (255 - 220 * cv2);
                im[y * W2 + x] = 0xFF000000 | (v << 16) | (v << 8) | Math.min(255, v + 30);
            }
            byte[] m = new byte[W2 * H2];
            long t1 = System.nanoTime();
            android.graphics.Rect rr = com.pacco.animecut.core.FloodFill.contiguous(im, W2, H2, m, null, 5, 5, 46, 42, 0);
            long t2 = System.nanoTime();
            byte[] al = com.pacco.animecut.core.BackgroundEraseAlpha.prepare(im, W2, H2, rr.left, rr.top, rr.right, rr.bottom, m, null, im[5 * W2 + 5], 46, 0);
            long t3 = System.nanoTime();
            int[] pr;
            try {
                pr = (int[]) com.pacco.animecut.core.BackgroundEraseAlpha.class.getMethod("refineEdges", int[].class, int.class, int.class, int.class, int.class, int.class, int.class, byte[].class, byte[].class, byte[].class, int.class, int.class, int.class, int.class)
                        .invoke(null, im, W2, H2, rr.left, rr.top, rr.right, rr.bottom, al, m, null, im[5 * W2 + 5], 46, 42, 0);
            } catch (Exception e) { throw new RuntimeException(e); }
            long t4 = System.nanoTime();
            log(String.format("   Tiempos en 2000x2000 con 9 discos (CPU del servidor, NO telefono): relleno %d ms, alfa %d ms, limpieza de filo %d ms (%d pixeles de filo)",
                    (t2 - t1) / 1000000, (t3 - t2) / 1000000, (t4 - t3) / 1000000, pr.length / 2));
        }
        // Rendimiento: imagen grande (CPU del servidor de pruebas, no telefono)
        int W = 2000, H = 2000;
        int[] big = new int[W * H];
        java.util.Arrays.fill(big, 0xFFFFFFFF);
        for (int y = 400; y < 1600; y++) for (int x = 400; x < 1600; x++) big[y * W + x] = 0xFF203040;
        SimKit kb = new SimKit(W, H, big);
        kb.cv.setMode(CanvasView.MODE_BGERASE);
        kb.cv.setBgBucket(true);
        kb.tap(10, 10);
        int clear = 0;
        for (int y = 0; y < 400; y++) for (int x = 0; x < W; x++) if ((kb.layer()[y * W + x] >>> 24) == 0) clear++;
        log("   Borrar fondo de un toque en 2000x2000 (CanvasView completo): fondo borrado arriba=" + clear + " de " + (400 * W));
        SimKit.check(clear == 400 * W, "Borrar fondo no borro todo el fondo en imagen grande");
        log("OK Borrar fondo");
    }

    public static void main(String[] a) throws Exception {
        try { run(a); } catch (Throwable e) { e.printStackTrace(System.out); System.exit(1); }
        System.exit(0);
    }

    static void run(String[] a) throws Exception {
        if (want(a, "fill")) fill();
        if (want(a, "fillcolor")) fillColorLayer();
        if (want(a, "brush")) brush();
        if (want(a, "eraser")) eraser();
        if (want(a, "gestures")) gestures();
        if (want(a, "smudge")) smudge();
        if (want(a, "bgerase")) bgErase();
        if (want(a, "blur")) blur();
        if (want(a, "shapes")) shapes();
        if (want(a, "lassocut")) lassoCut();
        if (want(a, "layers")) layers();
        if (want(a, "extras")) extras();
        if (want(a, "linescolor")) linesColor();
        if (want(a, "brushlines")) brushLines();
        if (a.length > 0 && want(a, "gaps")) gapLevels();
        log("PRUEBAS DE HERRAMIENTAS TERMINADAS");
    }
}
