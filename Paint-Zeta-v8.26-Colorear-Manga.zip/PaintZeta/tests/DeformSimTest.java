import android.graphics.Bitmap;
import android.graphics.RectF;
import android.os.Sim;
import android.view.MotionEvent;
import com.pacco.animecut.core.PuppetMesh;
import com.pacco.animecut.core.PuppetSession;
import com.pacco.animecut.view.CanvasView;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * v8.25 DEFORMAR con el CanvasView REAL en el Android simulado (no es un telefono).
 * Caso principal: el PNG del personaje inclinado (tests/assets/personaje_inclinado.png).
 * Uso: java DeformSimTest [carpetaSalidaImagenes]
 */
public final class DeformSimTest {
    static void log(String s) { System.out.println(s); }
    static String OUT = null;

    static int[] readPng(String path, int[] wh) throws Exception {
        BufferedImage bi = ImageIO.read(new File(path));
        wh[0] = bi.getWidth(); wh[1] = bi.getHeight();
        return bi.getRGB(0, 0, wh[0], wh[1], null, 0, wh[0]);
    }

    static void savePng(int[] px, int w, int h, String name) throws Exception {
        if (OUT == null) return;
        BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        bi.setRGB(0, 0, w, h, px, 0, w);
        ImageIO.write(bi, "png", new File(OUT, name));
    }

    static android.view.MotionEvent ev(int action, float[][] pts, int[] ids, int idx) {
        float[] xs = new float[pts.length], ys = new float[pts.length];
        for (int i = 0; i < pts.length; i++) { xs[i] = pts[i][0]; ys[i] = pts[i][1]; }
        return new MotionEvent(action, xs, ys, null, null, null, android.os.SystemClock.uptimeMillis()).withPointers(ids, idx);
    }

    /** Un pixel con alfa 0 es transparente aunque guarde RGB (el PNG original los trae asi). */
    static int cn(int c) { return (c >>> 24) == 0 ? 0 : c; }

    static PuppetSession ps(SimKit k) { return (PuppetSession) k.get("puppet"); }

    static void waitFor(SimKit k, java.util.function.BooleanSupplier cond, long maxMs, String what) {
        long end = System.currentTimeMillis() + maxMs;
        while (!cond.getAsBoolean()) {
            Sim.pump(20);
            if (System.currentTimeMillis() > end) throw new AssertionError("tiempo agotado: " + what);
        }
    }

    static void waitPreview(SimKit k) {
        waitFor(k, () -> {
            com.pacco.animecut.core.LatestWorker w = (com.pacco.animecut.core.LatestWorker) k.get("puppetWorker");
            return (w == null || !w.isBusy()) && ((Integer) k.get("puppetShownSeq")).intValue() == ((Integer) k.get("puppetSeq")).intValue();
        }, 20000, "vista previa " + k.get("puppetShownSeq") + "/" + k.get("puppetSeq") + " busy=" + (k.get("puppetWorker") == null ? "-" : ((com.pacco.animecut.core.LatestWorker) k.get("puppetWorker")).isBusy()));
    }

    static void waitApplied(SimKit k) {
        waitFor(k, () -> !(Boolean) k.get("transformApplying") && !(Boolean) k.get("busy"), 30000, "aplicar");
    }

    /** Arrastra con un dedo desde (fx,fy) hasta (tx,ty) en coordenadas de IMAGEN. */
    static void drag(SimKit k, float fx, float fy, float tx, float ty, int steps) {
        k.touch(MotionEvent.ACTION_DOWN, k.screen(fx, fy));
        Sim.pump(16);
        for (int s = 1; s <= steps; s++) {
            float t = s / (float) steps;
            k.touch(MotionEvent.ACTION_MOVE, k.screen(fx + (tx - fx) * t, fy + (ty - fy) * t));
            Sim.pump(16);
        }
        k.touch(MotionEvent.ACTION_UP, k.screen(tx, ty));
        Sim.pump(30);
    }

    static float[] pinXY(SimKit k, int i) {
        PuppetSession.Pin p = ps(k).pin(i);
        return new float[]{p.x, p.y};
    }

    public static void main(String[] a) throws Exception {
        if (a.length > 0) { OUT = a[0]; new File(OUT).mkdirs(); }
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> { e.printStackTrace(); System.exit(1); });
        String root = System.getProperty("pz.root", ".");
        int[] wh = new int[2];
        int[] png = readPng(root + "/tests/assets/personaje_inclinado.png", wh);
        mainPng(png, wh[0], wh[1]);
        tieByParts(png, wh[0], wh[1]);
        anchorsRestored();
        mesh();
        selectionScene();
        log("OK Deformar (Android simulado)");
        System.exit(0);
    }

    // ------------------------------------------------------------------
    // Caso principal: PNG inclinado
    // ------------------------------------------------------------------
    static void mainPng(int[] png, int w0, int h0) throws Exception {
        log("== Marioneta con el PNG del personaje inclinado (" + w0 + "x" + h0 + ") ==");
        int alpha0 = 0, semi = 0;
        for (int c : png) { if ((c >>> 24) == 0) alpha0++; else if ((c >>> 24) < 255) semi++; }
        log("   PNG: transparentes=" + alpha0 + " semitransparentes=" + semi);

        // 1. Importar y ampliar el lienzo arriba (al enderezarse queda mas alto)
        SimKit k = new SimKit(w0, h0, png.clone());
        final int TOP = 220;
        k.call("enlargeCanvas", 0, TOP, 0, 0);
        waitFor(k, () -> !(Boolean) k.get("busy") && k.project.h == h0 + TOP, 10000, "ampliar lienzo");
        int W = k.project.w, H = k.project.h;
        int[] original = k.layer().clone();
        int moved = 0;
        for (int y = 0; y < h0; y++) for (int x = 0; x < w0; x++) if (original[(y + TOP) * W + x] != png[y * w0 + x]) moved++;
        log("   Ampliar lienzo +" + TOP + " px arriba: " + W + "x" + H + ", pixeles del dibujo distintos=" + moved);
        SimKit.check(moved == 0, "ampliar lienzo cambio el dibujo");

        // 2. Deformar > Marioneta
        k.cv.setMode(CanvasView.MODE_PUPPET);
        SimKit.check(k.cv.getMode() == CanvasView.MODE_PUPPET, "getMode no devuelve MARIONETA");
        k.call("setTransformType", 4);
        long t0 = System.nanoTime();
        waitFor(k, () -> (Boolean) k.call("isPuppetReady"), 20000, "malla");
        PuppetMesh m = ps(k).mesh();
        log(String.format("   Malla de silueta: %d vertices, %d triangulos, celda %d px, %d partes conexas, creada en %.0f ms (servidor)",
                m.vertCount, m.triCount, m.spacing, m.compCount, ps(k).lastBuildNanos / 1e6));
        waitPreview(k);

        // 3. Puntos: pies, rodilla, cadera (fijos) y pecho, hombro, cuello, cabeza, corbata (moviles)
        float[][] fixedPts = {{520, 1490}, {770, 1460}, {690, 1040}};
        float[] hipPt = {710, 720}; // cadera: punto naranja que se deja quieto (puede doblarse)
        float[][] movePts = {{690, 400}, {610, 290}, {430, 290}, {300, 150}, {475, 630}};
        int nf = fixedPts.length;
        for (float[] p : fixedPts) {
            k.tap(p[0], p[1] + TOP);
            k.call("togglePuppetFixed");
        }
        k.tap(hipPt[0], hipPt[1] + TOP);
        for (float[] p : movePts) k.tap(p[0], p[1] + TOP);
        int pins = ps(k).pinCount();
        log("   Puntos puestos tocando: " + pins + " (" + nf + " fijos azules: pies y rodilla; cadera naranja quieta)");
        int mv0 = nf + 1;
        SimKit.check(pins == fixedPts.length + 1 + movePts.length, "no se pusieron todos los puntos");
        for (int i = 0; i < nf; i++) SimKit.check(ps(k).pin(i).fixed, "un pie no quedo fijo");

        // Un punto fijo NO se mueve al arrastrarlo
        float[] f0 = pinXY(k, 0);
        drag(k, f0[0], f0[1], f0[0] + 80, f0[1] - 60, 6);
        float[] f1 = pinXY(k, 0);
        log("   Arrastrar el pie fijo 100 px: se movio " + Math.hypot(f1[0] - f0[0], f1[1] - f0[1]) + " px");
        SimKit.check(f1[0] == f0[0] && f1[1] == f0[1], "el punto fijo se movio");

        // 4. Enderezar progresivamente: 8 rondas, cada punto movil se arrastra con el dedo
        double px0 = 700, py0 = 690 + TOP, phi = Math.toRadians(32);
        int rounds = 8;
        float[][] target = new float[movePts.length][2];
        float[][][] roundT = new float[rounds + 1][movePts.length][2];
        int maxInv = 0;
        long dragNs = 0; int dragMoves = 0;
        for (int r = 1; r <= rounds; r++) {
            double f = phi * r / rounds, c = Math.cos(f), s = Math.sin(f);
            for (int j = 0; j < movePts.length; j++) {
                double x = movePts[j][0], y = movePts[j][1] + TOP;
                double dx = x - px0, dy = y - py0;
                double rx = px0 + dx * c - dy * s, ry = py0 + dx * s + dy * c;
                if (j == 4) {
                    // corbata: cuelga recta desde el nudo girado
                    double kx = 440 - px0, ky = 330 + TOP - py0;
                    double nx = px0 + kx * c - ky * s, ny = py0 + kx * s + ky * c;
                    double hx = nx + 300 * Math.sin(Math.toRadians(-6)), hy = ny + 300 * Math.cos(Math.toRadians(-6));
                    double t = r / (double) rounds;
                    rx = rx + (hx - rx) * t; ry = ry + (hy - ry) * t;
                }
                target[j][0] = (float) rx; target[j][1] = (float) ry;
                roundT[r][j][0] = (float) rx; roundT[r][j][1] = (float) ry;
                float[] cur = pinXY(k, mv0 + j);
                long a0 = System.nanoTime();
                drag(k, cur[0], cur[1], target[j][0], target[j][1], 5);
                dragNs += System.nanoTime() - a0; dragMoves += 5;
                maxInv = Math.max(maxInv, ps(k).invertedCount());
            }
        }
        double maxErr = 0;
        for (int j = 0; j < movePts.length; j++) {
            float[] p = pinXY(k, mv0 + j);
            maxErr = Math.max(maxErr, Math.hypot(p[0] - target[j][0], p[1] - target[j][1]));
        }
        log(String.format("   Enderezado en %d rondas (40 arrastres): triangulos invertidos max=%d final=%d, error max de los puntos=%.2f px",
                rounds, maxInv, ps(k).invertedCount(), maxErr));
        log(String.format("   Resolver ARAP por movimiento: %.2f ms; factorizar: %.1f ms (servidor)",
                ps(k).lastSolveNanos() / 1e6, ps(k).lastFactorNanos() / 1e6));
        SimKit.check(ps(k).invertedCount() == 0, "quedaron triangulos invertidos");
        SimKit.check(maxErr < 1.0, "los puntos no llegaron a su destino");

        // Angulo del eje cadera -> cabeza (antes y despues), con puntos de la malla
        double before = Math.toDegrees(Math.atan2(300 - 710, -((150 + TOP) - (720 + TOP))));
        float[] head = pinXY(k, mv0 + 3), hip = pinXY(k, nf);
        double after = Math.toDegrees(Math.atan2(head[0] - hip[0], -(head[1] - hip[1])));
        log(String.format("   Inclinacion cadera->cabeza respecto a la vertical: antes %.1f grados, despues %.1f grados", before, after));

        // Distorsion por triangulo (zonas: torso/cabeza vs cadera)
        float[] loc = ps(k).localPositionsCopy();
        float[] sv = new float[m.triCount * 2];
        PuppetSession.singularValues(m, loc, sv);
        double worstHead = 1, worstTorso = 1, worstAll = 1;
        int over13 = 0, solvedTris = 0;
        for (int t = 0; t < m.triCount; t++) {
            float cy = 0, cx = 0;
            for (int q = 0; q < 3; q++) { cx += m.rest[m.tri[t * 3 + q] * 2] / 3f; cy += m.rest[m.tri[t * 3 + q] * 2 + 1] / 3f; }
            double ratio = sv[t * 2] / Math.max(1e-6, Math.abs(sv[t * 2 + 1]));
            if (Math.abs(sv[t * 2] - 1) < 1e-6 && Math.abs(sv[t * 2 + 1] - 1) < 1e-6) continue;
            solvedTris++;
            worstAll = Math.max(worstAll, ratio);
            if (ratio > 1.3) over13++;
            float iy = cy - TOP;
            if (iy < 260 && cx < 470) worstHead = Math.max(worstHead, ratio);
            else if (iy >= 260 && iy < 600) worstTorso = Math.max(worstTorso, ratio);
        }
        log(String.format("   Estiramiento (sigma max/min) peor: cabeza %.2f, torso %.2f, todo %.2f; triangulos con >1,3: %d de %d",
                worstHead, worstTorso, worstAll, over13, solvedTris));

        // 5. Vista previa = resultado final
        float[] dbg = ps(k).deformedBounds();
        log("   (bbox deformado " + java.util.Arrays.toString(dbg) + ")");
        waitPreview(k);
        RectF pr = new RectF();
        Bitmap prev = (Bitmap) k.call("getPuppetPreviewForTest", pr);
        int pw = prev.getWidth(), ph = prev.getHeight();
        int[] prevPx = new int[pw * ph];
        prev.getPixels(prevPx, 0, pw, 0, 0, pw, ph);
        boolean fullScale = Math.abs((pr.right - pr.left) - pw) < .5f;
        log("   Vista previa: " + pw + "x" + ph + (fullScale ? " a escala 1" : " reducida"));

        // 6. Aplicar
        long ta = System.nanoTime();
        k.cv.applyTransform();
        waitApplied(k);
        log(String.format("   Aplicar (render final por bloques): %.0f ms (servidor)", (System.nanoTime() - ta) / 1e6));
        int[] result = k.layer().clone();
        int prevDiff = 0, prevMax = 0, outsideDiff = 0;
        if (fullScale) {
            int l = Math.round(pr.left), t = Math.round(pr.top);
            for (int y = 0; y < ph; y++) for (int x = 0; x < pw; x++) {
                int gx = l + x, gy = t + y;
                if (gx < 0 || gy < 0 || gx >= W || gy >= H) continue;
                int pa = cn(prevPx[y * pw + x]), ra = cn(result[gy * W + gx]);
                if (pa != ra) {
                    prevDiff++;
                    for (int sh = 0; sh < 32; sh += 8) prevMax = Math.max(prevMax, Math.abs(((pa >>> sh) & 255) - ((ra >>> sh) & 255)));
                }
            }
            // fuera del rectangulo de la vista previa la capa debe quedar vacia
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++)
                if ((x < l || y < t || x >= l + pw || y >= t + ph) && cn(result[y * W + x]) != 0) outsideDiff++;
        }
        log("   Vista previa vs resultado aplicado: pixeles distintos=" + prevDiff + " (max " + prevMax + " niveles), fuera del rectangulo=" + outsideDiff);
        SimKit.check(!fullScale || prevDiff == 0, "la vista previa no coincide con el resultado");

        // Pies inmoviles (B): 20 px alrededor de cada pie fijo y toda la zona de zapatos
        int footDiff = 0, footMax = 0, footN = 0;
        for (int y = 1400 + TOP; y < H; y++) for (int x = 0; x < W; x++) {
            int o = cn(original[y * W + x]), n = cn(result[y * W + x]);
            if (o == 0 && n == 0) continue;
            footN++;
            if (o != n) {
                footDiff++;
                for (int sh = 0; sh < 32; sh += 8) footMax = Math.max(footMax, Math.abs(((o >>> sh) & 255) - ((n >>> sh) & 255)));
            }
        }
        int ringDiff = 0, ringN = 0;
        for (int f = 0; f < 2; f++) {
            int fx = Math.round(fixedPts[f][0]), fy = Math.round(fixedPts[f][1] + TOP);
            for (int y = fy - 20; y <= fy + 20; y++) for (int x = fx - 20; x <= fx + 20; x++) {
                if (x < 0 || y < 0 || x >= W || y >= H || (x - fx) * (x - fx) + (y - fy) * (y - fy) > 400) continue;
                ringN++;
                if (cn(original[y * W + x]) != cn(result[y * W + x])) ringDiff++;
            }
        }
        log("   Circulo de 20 px alrededor de cada pie fijo: pixeles distintos=" + ringDiff + " de " + ringN);
        SimKit.check(ringDiff == 0, "los pies fijos cambiaron");
        log("   Zapatos y tobillos (y>1400): pixeles distintos=" + footDiff + " de " + footN + ", diferencia max=" + footMax + " niveles");

        // Transparencia (G): sin alfa fantasma; halos (J)
        int ghost = 0, visible = 0;
        long asum0 = 0, asum1 = 0;
        for (int c : original) asum0 += c >>> 24;
        int ghostOrig = 0;
        for (int c : original) if ((c >>> 24) == 0 && c != 0) ghostOrig++;
        for (int c : result) { asum1 += c >>> 24; if ((c >>> 24) > 0) visible++; }
        // basura NUEVA: transparentes con RGB que antes eran 0 en el original
        for (int i = 0; i < result.length; i++) if ((result[i] >>> 24) == 0 && result[i] != 0 && result[i] != original[i]) ghost++;
        log("   (El PNG original ya traia " + ghostOrig + " pixeles con alfa 0 y RGB distinto de 0: son invisibles)");
        log(String.format("   Transparencia: pixeles transparentes con color basura=%d; alfa total %.1f%% del original", ghost, 100.0 * asum1 / asum0));
        SimKit.check(ghost == 0, "aparecieron transparentes con basura");

        // 7. Exportar PNG transparente (N)
        final java.io.ByteArrayOutputStream[] sink = new java.io.ByteArrayOutputStream[1];
        android.content.ContentResolver cr = new android.content.ContentResolver() {
            @Override public java.io.OutputStream openOutputStream(android.net.Uri u) { sink[0] = new java.io.ByteArrayOutputStream(); return sink[0]; }
        };
        com.pacco.animecut.core.Exporter.exportLayer(cr, k.project, k.project.layers.get(0), null, 0);
        BufferedImage ex = ImageIO.read(new java.io.ByteArrayInputStream(sink[0].toByteArray()));
        int ew = ex.getWidth(), eh = ex.getHeight();
        int[] epx = ex.getRGB(0, 0, ew, eh, null, 0, ew);
        android.graphics.Rect bb = k.project.layers.get(0).bounds(W, H);
        int ox = ew == W ? 0 : bb.left, oy = eh == H ? 0 : bb.top;
        int expDiff = 0;
        for (int y = 0; y < eh; y++) for (int x = 0; x < ew; x++) {
            int e = epx[y * ew + x], r = result[(y + oy) * W + x + ox];
            if ((e >>> 24) != (r >>> 24) || ((e >>> 24) > 0 && (e & 0xFFFFFF) != (r & 0xFFFFFF))) expDiff++;
        }
        log("   PNG exportado " + ew + "x" + eh + " vs capa: pixeles distintos=" + expDiff);
        SimKit.check(expDiff == 0, "el PNG exportado no coincide");
        savePng(epx, ew, eh, "marioneta_png_exportado.png");

        // 8. Deshacer / Rehacer de la obra (K)
        k.cv.setMode(CanvasView.MODE_PAINT);
        k.cv.doUndo(); Sim.pump(60);
        int undoDiff = SimKit.diff(k.layer(), original);
        k.cv.doRedo(); Sim.pump(60);
        int redoDiff = SimKit.diff(k.layer(), result);
        log("   Deshacer -> original: distintos=" + undoDiff + "; Rehacer -> resultado: distintos=" + redoDiff);
        SimKit.check(undoDiff == 0 && redoDiff == 0, "deshacer/rehacer de la deformacion");

        // 9. Cancelar no destruye (K) + deshacer interno de puntos + dos dedos (L)
        k.cv.setMode(CanvasView.MODE_PUPPET);
        k.call("setTransformType", 4);
        waitFor(k, () -> (Boolean) k.call("isPuppetReady"), 20000, "malla 2");
        k.tap(520, 1490 + TOP); k.call("togglePuppetFixed");
        k.tap(700, 700 + TOP);
        int before2 = ps(k).pinCount();
        float[] hp = pinXY(k, 1);
        drag(k, hp[0], hp[1], hp[0] - 60, hp[1] + 30, 5);
        float[] hp2 = pinXY(k, 1);
        k.cv.doUndo(); Sim.pump(30);
        float[] hp3 = pinXY(k, 1);
        k.cv.doRedo(); Sim.pump(30);
        float[] hp4 = pinXY(k, 1);
        log(String.format("   Deshacer interno: punto movido %.0f px; Deshacer vuelve a %.2f px del inicio; Rehacer a %.2f px del final",
                Math.hypot(hp2[0] - hp[0], hp2[1] - hp[1]), Math.hypot(hp3[0] - hp[0], hp3[1] - hp[1]), Math.hypot(hp4[0] - hp2[0], hp4[1] - hp2[1])));
        SimKit.check(Math.hypot(hp3[0] - hp[0], hp3[1] - hp[1]) < .01 && Math.hypot(hp4[0] - hp2[0], hp4[1] - hp2[1]) < .01, "deshacer interno");
        SimKit.check(before2 == 2, "puntos de la segunda sesion");

        // Dos dedos (L): 100 pellizcos empezando ENCIMA de un punto, que alcanza a moverse
        PuppetSession.Snap snap = ps(k).snapshot();
        float scale0 = k.screen(1, 0)[0] - k.screen(0, 0)[0];
        for (int g = 0; g < 100; g++) {
            float[] p = pinXY(k, 1);
            float[] a0 = k.screen(p[0], p[1]);
            k.cv.onTouchEvent(ev(MotionEvent.ACTION_DOWN, new float[][]{a0}, new int[]{0}, 0));
            float[] a1 = {a0[0] + 14, a0[1] + 9};
            k.cv.onTouchEvent(ev(MotionEvent.ACTION_MOVE, new float[][]{a1}, new int[]{0}, 0)); // el punto alcanza a moverse
            float[] b0 = {a1[0] + 200, a1[1] + 120};
            k.cv.onTouchEvent(ev(MotionEvent.ACTION_POINTER_DOWN, new float[][]{a1, b0}, new int[]{0, 1}, 1));
            for (int st = 1; st <= 4; st++) {
                float[] aa = {a1[0] - 6 * st, a1[1] - 3 * st}, bb2 = {b0[0] + 6 * st, b0[1] + 3 * st};
                k.cv.onTouchEvent(ev(MotionEvent.ACTION_MOVE, new float[][]{aa, bb2}, new int[]{0, 1}, 0));
            }
            k.cv.onTouchEvent(ev(MotionEvent.ACTION_POINTER_UP, new float[][]{{a1[0] - 24, a1[1] - 12}, {b0[0] + 24, b0[1] + 12}}, new int[]{0, 1}, 1));
            k.cv.onTouchEvent(ev(MotionEvent.ACTION_UP, new float[][]{{a1[0] - 24, a1[1] - 12}}, new int[]{0}, 0));
            Sim.pump(2);
        }
        Sim.pump(100);
        PuppetSession.Snap snap2 = ps(k).snapshot();
        double pinShift = 0;
        for (int i = 0; i < snap.size(); i++) pinShift = Math.max(pinShift, Math.hypot(snap.pin(i).x - snap2.pin(i).x, snap.pin(i).y - snap2.pin(i).y));
        log("   100 gestos de dos dedos (empezando sobre un punto): puntos=" + snap2.size() + " (antes " + snap.size()
                + "), desplazamiento max=" + pinShift + " px");
        SimKit.check(snap2.size() == snap.size() && pinShift == 0, "dos dedos movieron o agregaron puntos");
        k.cv.resetView(); k.cv.fit();

        k.cv.cancelTransform();
        Sim.pump(100);
        int cancelDiff = SimKit.diff(k.layer(), result);
        log("   Cancelar: la capa vuelve exacta, pixeles distintos=" + cancelDiff);
        SimKit.check(cancelDiff == 0, "cancelar cambio la imagen");

        // Imagenes antes / despues
        if (OUT != null) {
            savePng(original, W, H, "marioneta_antes.png");
            savePng(result, W, H, "marioneta_despues.png");
            // malla sobre el original y sobre el resultado
            writeMeshOverlay(original, W, H, m, null, 0, TOP, fixedPts, movePts, null, "marioneta_malla_antes.png");
            float[] pos = new float[m.vertCount * 2];
            for (int i = 0; i < pos.length; i += 2) { pos[i] = loc[i]; pos[i + 1] = loc[i + 1]; }
            writeMeshOverlay(result, W, H, m, pos, 0, 0, fixedPts, movePts, target, "marioneta_malla_despues.png");
        }

        // 10. Sin ampliar el lienzo: el mismo enderezado se sale por arriba (limite honesto)
        SimKit k2 = new SimKit(w0, h0, png.clone());
        k2.cv.setMode(CanvasView.MODE_PUPPET);
        k2.call("setTransformType", 4);
        waitFor(k2, () -> (Boolean) k2.call("isPuppetReady"), 20000, "malla 3");
        for (float[] p : fixedPts) { k2.tap(p[0], p[1]); k2.call("togglePuppetFixed"); }
        k2.tap(hipPt[0], hipPt[1]);
        for (float[] p : movePts) k2.tap(p[0], p[1]);
        for (int r = 1; r <= rounds; r++)
            for (int j = 0; j < movePts.length; j++) {
                float[] cur = pinXY(k2, nf + 1 + j);
                drag(k2, cur[0], cur[1], roundT[r][j][0], roundT[r][j][1] - TOP, 5);
            }
        float[] bbx = ps(k2).deformedBounds();
        k2.cv.applyTransform();
        waitApplied(k2);
        int[] cut = k2.layer();
        long lostAlpha = 0, keptAlpha = 0;
        for (int c : cut) keptAlpha += c >>> 24;
        for (int c : png) lostAlpha += c >>> 24;
        log(String.format("   Sin ampliar el lienzo (%dx%d): la malla deformada llega a y=%.0f (fuera del lienzo); alfa conservado %.1f%%",
                w0, h0, bbx[1], 100.0 * keptAlpha / lostAlpha));
        if (OUT != null) savePng(cut, w0, h0, "marioneta_sin_ampliar.png");
    }

    static void writeMeshOverlay(int[] img, int W, int H, PuppetMesh m, float[] pos, int dx, int dy,
            float[][] fixedPts, float[][] movePts, float[][] targets, String name) throws Exception {
        BufferedImage bi = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g = bi.createGraphics();
        g.setColor(java.awt.Color.WHITE); g.fillRect(0, 0, W, H);
        BufferedImage src = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        src.setRGB(0, 0, W, H, img, 0, W);
        g.drawImage(src, 0, 0, null);
        g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new java.awt.Color(40, 120, 255, 110));
        g.setStroke(new java.awt.BasicStroke(1f));
        float[] p = pos != null ? pos : m.rest;
        int ox = pos != null ? 0 : dx, oy = pos != null ? 0 : dy;
        int[] compSize = new int[m.compCount];
        for (int v = 0; v < m.vertCount; v++) compSize[m.vertComp[v]]++;
        for (int t = 0; t < m.triCount; t++) {
            int a = m.tri[t * 3], b = m.tri[t * 3 + 1], c = m.tri[t * 3 + 2];
            if (compSize[m.vertComp[a]] < 30) continue; // igual que en la app
            int[] xs = {Math.round(p[a * 2] + ox), Math.round(p[b * 2] + ox), Math.round(p[c * 2] + ox)};
            int[] ys = {Math.round(p[a * 2 + 1] + oy), Math.round(p[b * 2 + 1] + oy), Math.round(p[c * 2 + 1] + oy)};
            g.drawPolygon(xs, ys, 3);
        }
        for (float[] f : fixedPts) { g.setColor(new java.awt.Color(0x42A5F5)); g.fillOval(Math.round(f[0]) - 9, Math.round(f[1] + 220) - 9, 18, 18); }
        for (int j = 0; j < movePts.length; j++) {
            float x = targets != null ? targets[j][0] : movePts[j][0], y = targets != null ? targets[j][1] : movePts[j][1] + 220;
            g.setColor(new java.awt.Color(0xFFA726)); g.fillOval(Math.round(x) - 9, Math.round(y) - 9, 18, 18);
        }
        g.dispose();
        ImageIO.write(bi, "png", new File(OUT, name));
    }

    // ------------------------------------------------------------------
    // Malla mejorada
    // ------------------------------------------------------------------
    static void mesh() {
        log("== Malla mejorada ==");
        int w = 400, h = 400;
        int[] px = new int[w * h];
        for (int y = 100; y < 300; y++) for (int x = 100; x < 300; x++) px[y * w + x] = ((x / 20 + y / 20) & 1) == 0 ? 0xFF2050C0 : 0xFFF0E0A0;
        SimKit k = new SimKit(w, h, px.clone());
        k.cv.setMode(CanvasView.MODE_TRANSFORM);
        k.call("setTransformType", 2);
        Sim.pump(200);
        SimKit.check((Boolean) k.call("isTransformActive"), "Malla no empezo");
        float[] v = ((float[]) k.get("transformVerts")).clone();
        int node = 2 * 5 + 2;
        // a) No salta al dedo: se toca 12 px al lado del nodo y se arrastra 30 px
        drag(k, v[node * 2] + 12, v[node * 2 + 1], v[node * 2] + 42, v[node * 2 + 1], 6);
        float[] vj = (float[]) k.get("transformVerts");
        log(String.format("   Tocar 12 px al lado del nodo y arrastrar 30 px: el nodo se movio %.1f px (sin salto)", vj[node * 2] - v[node * 2]));
        SimKit.check(Math.abs(vj[node * 2] - v[node * 2] - 30) < .6f, "el nodo salto al dedo");
        k.cv.doUndo(); Sim.pump(20);
        // b) Movimiento amplio: girar toda la cuadricula 110 grados (en 11 rondas, nodo por nodo).
        //    v8.24 obligaba a cada nodo a quedar entre sus vecinos: el orden de una fila no podia invertirse.
        float cx = 200, cy = 200;
        double ang = Math.toRadians(110);
        int rounds = 11;
        for (int r = 1; r <= rounds; r++) {
            double a = ang * r / rounds, c = Math.cos(a), sn = Math.sin(a);
            for (int n = 0; n < 25; n++) {
                float[] cur = (float[]) k.get("transformVerts");
                float ox = v[n * 2] - cx, oy = v[n * 2 + 1] - cy;
                float tx = (float) (cx + ox * c - oy * sn), ty = (float) (cy + ox * sn + oy * c);
                drag(k, cur[n * 2], cur[n * 2 + 1], tx, ty, 3);
            }
        }
        float[] vr = (float[]) k.get("transformVerts");
        double err = 0;
        double cA = Math.cos(ang), sA = Math.sin(ang);
        for (int n = 0; n < 25; n++) {
            float ox = v[n * 2] - cx, oy = v[n * 2 + 1] - cy;
            err = Math.max(err, Math.hypot(vr[n * 2] - (cx + ox * cA - oy * sA), vr[n * 2 + 1] - (cy + ox * sA + oy * cA)));
        }
        int folds = (Integer) callPriv(k, "countMeshFolds");
        // en una fila, x del primer nodo > x del ultimo: imposible con el limite de vecinos de v8.24
        boolean reversed = vr[0] > vr[4 * 2];
        log(String.format("   Girar la cuadricula 110 grados nodo por nodo: error max %.2f px, pliegues=%d, fila invertida=%s (v8.24 no lo permitia)",
                err, folds, reversed));
        SimKit.check(err < 1.0 && folds == 0 && reversed, "la malla no permite girar ampliamente");
        k.cv.cancelTransform(); Sim.pump(50);
        k.call("setTransformType", 2); Sim.pump(200);
        v = ((float[]) k.get("transformVerts")).clone();
        // No salta al dedo: se toco 3 px al costado y conserva esa distancia
        // Arrastre exagerado: se detiene antes de doblarse
        float[] v3 = ((float[]) k.get("transformVerts")).clone();
        drag(k, v3[node * 2], v3[node * 2 + 1], v3[node * 2] + 400, v3[node * 2 + 1], 20);
        float[] v4 = (float[]) k.get("transformVerts");
        folds = (Integer) callPriv(k, "countMeshFolds");
        log(String.format("   Arrastre exagerado de 400 px: el nodo llego a +%.1f px y se detuvo; pliegues=%d", v4[node * 2] - v3[node * 2], folds));
        SimKit.check(folds == 0, "la malla quedo plegada");
        // Deshacer interno
        k.cv.doUndo(); Sim.pump(20);
        float[] v5 = (float[]) k.get("transformVerts");
        log("   Deshacer dentro de Malla: nodo vuelve a " + (v5[node * 2] - v3[node * 2]) + " px del paso anterior");
        SimKit.check(Math.abs(v5[node * 2] - v3[node * 2]) < 1e-3, "deshacer de malla");
        // dos dedos empezando sobre un nodo: no deforma
        float[] before = ((float[]) k.get("transformVerts")).clone();
        float[] a0 = k.screen(before[node * 2], before[node * 2 + 1]);
        k.cv.onTouchEvent(ev(MotionEvent.ACTION_DOWN, new float[][]{a0}, new int[]{0}, 0));
        k.cv.onTouchEvent(ev(MotionEvent.ACTION_MOVE, new float[][]{{a0[0] + 20, a0[1]}}, new int[]{0}, 0));
        k.cv.onTouchEvent(ev(MotionEvent.ACTION_POINTER_DOWN, new float[][]{{a0[0] + 20, a0[1]}, {a0[0] + 220, a0[1] + 100}}, new int[]{0, 1}, 1));
        k.cv.onTouchEvent(ev(MotionEvent.ACTION_MOVE, new float[][]{{a0[0], a0[1]}, {a0[0] + 260, a0[1] + 120}}, new int[]{0, 1}, 0));
        k.cv.onTouchEvent(ev(MotionEvent.ACTION_POINTER_UP, new float[][]{{a0[0], a0[1]}, {a0[0] + 260, a0[1] + 120}}, new int[]{0, 1}, 1));
        k.cv.onTouchEvent(ev(MotionEvent.ACTION_UP, new float[][]{{a0[0], a0[1]}}, new int[]{0}, 0));
        int nodeDiff = 0;
        float[] after = (float[]) k.get("transformVerts");
        for (int i = 0; i < before.length; i++) if (before[i] != after[i]) nodeDiff++;
        log("   Dos dedos empezando sobre un nodo: coordenadas de nodos cambiadas=" + nodeDiff);
        SimKit.check(nodeDiff == 0, "dos dedos deformaron la malla");
        k.cv.resetView(); k.cv.fit();
        // Aplicar: ahora el resultado final se calcula en la CPU (antes dependia del Canvas)
        k.cv.applyTransform();
        waitApplied(k);
        int[] L = k.layer();
        int vis = 0, ghost = 0, wrong = 0;
        for (int c : L) { if ((c >>> 24) > 0) vis++; if ((c >>> 24) == 0 && c != 0) ghost++; }
        // color: los pixeles opacos deben ser mezclas de los dos colores del tablero
        for (int c : L) {
            if ((c >>> 24) < 255) continue;
            int r = (c >>> 16) & 255, b = c & 255;
            if (r < 0x20 - 2 || r > 0xF0 + 2 || b < 0xA0 - 2 || b > 0xC0 + 2) wrong++;
        }
        log("   Malla aplicada: pixeles visibles=" + vis + " (cuadro original 40000), transparentes con basura=" + ghost + ", colores fuera de rango=" + wrong);
        SimKit.check(vis > 30000 && ghost == 0 && wrong == 0, "resultado de malla");
        k.cv.doUndo(); Sim.pump(40);
        SimKit.check(SimKit.diff(k.layer(), px) == 0, "deshacer malla aplicada");
        log("   Deshacer tras aplicar Malla: imagen original exacta");
    }

    // Por partes: un punto en la corbata mueve SOLO la corbata
    static void tieByParts(int[] png, int w, int h) {
        log("== Por partes: un solo punto en la corbata ==");
        for (boolean parts : new boolean[]{true, false}) {
            SimKit k = new SimKit(w, h, png.clone());
            k.cv.setMode(CanvasView.MODE_PUPPET);
            k.call("setPuppetByParts", parts);
            k.call("setTransformType", 4);
            waitFor(k, () -> (Boolean) k.call("isPuppetReady"), 20000, "malla corbata");
            int[] before = png;
            k.tap(475, 625);
            SimKit.check(ps(k).pinCount() == 1, "no se puso el punto en la corbata");
            drag(k, 475, 625, 560, 575, 10);
            k.cv.applyTransform();
            waitApplied(k);
            int[] after = k.layer();
            int legs = 0, tie = 0;
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                if (cn(before[y * w + x]) == cn(after[y * w + x])) continue;
                if (y > 760) legs++;
                if (x > 430 && x < 620 && y > 380 && y < 680) tie++;
            }
            log("   " + (parts ? "Por partes (por defecto)" : "Todo junto") + ": pixeles cambiados en la zona de la corbata=" + tie
                    + ", en las piernas=" + legs);
            if (parts) SimKit.check(legs == 0 && tie > 2000, "por partes: la corbata no se movio sola");
            else SimKit.check(legs > 10000, "todo junto deberia mover el cuerpo entero");
        }
    }

    // Puntos de anclaje volvieron a Transformar, como antes
    @SuppressWarnings("unchecked")
    static void anchorsRestored() {
        log("== Transformar > Puntos de anclaje (restaurado) ==");
        int w = 300, h = 300;
        int[] px = new int[w * h];
        for (int y = 80; y < 220; y++) for (int x = 80; x < 220; x++) px[y * w + x] = 0xFF3070D0;
        SimKit k = new SimKit(w, h, px.clone());
        k.cv.setMode(CanvasView.MODE_TRANSFORM);
        SimKit.check(k.cv.getMode() == CanvasView.MODE_TRANSFORM, "Transformar");
        k.call("setTransformType", 3);
        Sim.pump(200);
        k.call("setTransformAnchorAddMode", 0);
        k.tap(100, 100);
        k.call("setTransformAnchorAddMode", 1);
        k.tap(200, 200);
        drag(k, 200, 200, 240, 230, 6);
        int n = (Integer) k.call("getTransformAnchorCount");
        k.cv.doUndo(); Sim.pump(20);
        float[] an = ((java.util.ArrayList<float[]>) k.get("transformAnchors")).get(1);
        log("   Puntos: " + n + "; Deshacer devuelve el punto movil a (" + an[2] + "," + an[3] + ")");
        SimKit.check(n == 2 && Math.abs(an[2] - 200) < .01 && Math.abs(an[3] - 200) < .01, "deshacer de puntos");
        k.cv.doRedo(); Sim.pump(20);
        k.cv.applyTransform();
        waitApplied(k);
        int[] L = k.layer();
        int vis = 0, outsideSquare = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if ((L[y * w + x] >>> 24) > 0) { vis++; if (x >= 222 || y >= 222) outsideSquare++; }
        log("   Aplicado (render final en CPU): pixeles visibles=" + vis + ", estirados fuera del cuadro original=" + outsideSquare);
        SimKit.check(vis > 15000 && outsideSquare > 100, "Puntos de anclaje no deformo");
    }

    static Object callPriv(SimKit k, String name) {
        try {
            java.lang.reflect.Method m = CanvasView.class.getDeclaredMethod(name);
            m.setAccessible(true);
            return m.invoke(k.cv);
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    // ------------------------------------------------------------------
    // H: parte seleccionada de una escena con fondo
    // ------------------------------------------------------------------
    static void selectionScene() {
        log("== Seleccion dentro de una escena (H) ==");
        int w = 500, h = 400;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) px[y * w + x] = 0xFF000000 | ((x * 255 / w) << 16) | ((y * 255 / h) << 8) | 0x60;
        // "personaje": barra vertical roja
        for (int y = 120; y < 330; y++) for (int x = 220; x < 260; x++) px[y * w + x] = 0xFFD02020;
        SimKit k = new SimKit(w, h, px.clone());
        // seleccion: rectangulo alrededor de la barra
        for (int y = 100; y < 340; y++) for (int x = 200; x < 280; x++) k.project.selection[y * w + x] = (byte) 255;
        k.cv.setMode(CanvasView.MODE_PUPPET);
        k.call("setTransformType", 4);
        waitFor(k, () -> (Boolean) k.call("isPuppetReady"), 20000, "malla seleccion");
        k.tap(240, 320); k.call("togglePuppetFixed");
        k.tap(240, 140);
        float[] p = pinXY(k, 1);
        drag(k, p[0], p[1], p[0] + 30, p[1], 6);
        float[] db = ps(k).deformedBounds();
        int bl = (int) Math.floor(Math.min(200, db[0])) - 2, bt = (int) Math.floor(Math.min(100, db[1])) - 2;
        int br = (int) Math.ceil(Math.max(280, db[2])) + 2, bbm = (int) Math.ceil(Math.max(340, db[3])) + 2;
        k.cv.applyTransform();
        waitApplied(k);
        int[] L = k.layer();
        int outside = 0, inside = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            boolean near = x >= bl && x < br && y >= bt && y < bbm;
            if (L[y * w + x] != px[y * w + x]) { if (near) inside++; else outside++; }
        }
        log("   Zona seleccionada + su forma deformada: [" + bl + "," + bt + "]-[" + br + "," + bbm + "], pixeles cambiados ahi=" + inside
                + "; fuera=" + outside + " (debe ser 0). El hueco que deja la parte NO se inventa: se retoca con Clonar / Copiar zona");
        SimKit.check(outside == 0, "se modifico fuera de la seleccion");
    }
}
