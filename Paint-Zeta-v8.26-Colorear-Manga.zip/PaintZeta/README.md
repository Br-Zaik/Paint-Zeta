# Paint Zeta v8.26 — Colorear manga B/N (código fuente)

- Menú > **Colorear manga**: protege el original como «Tinta B/N» (bloqueo total) y crea «Color base» en Multiplicar. La tinta, los grises y las tramas siguen visibles.
- **Balde por líneas** con **vista previa** (Aceptar, Parecidas, Cancelar), modo trama, cerrar huecos, color bajo la línea y **zonas protegidas** (globos, rayas).
- **Sombra rápida**, **Luz rápida**, **Brillo encima**, **Cambiar color** no destructivo y modo de mezcla **Color**.
- Ventana de **referencia de colores** con lupa, promedio 3x3, Usar, Guardar muestra con nombre, paleta de la obra y global, y copia reducida guardada en la obra. Gotero Visible / Capa actual.
- Exportar > **Imagen completa** (igual que en pantalla).
- Detalle, resultados P1-P20 y límites: `CAMBIOS_8_26_COLOREAR_MANGA.md`. Pruebas: `sh tests/run_jvm_tests.sh` (Android simulado, no es un teléfono).
- No se generó APK en este entorno: hay que compilar en Android Studio.

# Paint Zeta v8.25 — Marioneta (herramienta nueva) + Malla mejorada (código fuente)

- Nueva herramienta **Marioneta** con su propio botón: malla de silueta + ARAP en dos pasos, con modo **Por partes** (un punto en la corbata mueve solo la corbata).
- **Transformar** sigue como antes: Mover, Perspectiva, Malla (ahora sin límite de vecinos, con control real de pliegues) y Puntos de anclaje.
- Nuevo **Menú > Ampliar lienzo**.
- Detalle, números y límites: `CAMBIOS_8_25_DEFORMAR.md`. Pruebas: `sh tests/run_jvm_tests.sh` (Android simulado, no es un teléfono).
- No se generó APK en este entorno: hay que compilar en Android Studio.

# Paint Zeta v8.24 — Balde, coloreado, Brocha, Líneas y capas (código fuente)

Balde con motor nuevo (`core/BucketFill`): sin rincones blancos, sin fugas por tolerancia, cortes cerrados en el punto real, línea intacta con su antialias, plano o "Conservar sombras", capas de referencia y, de fábrica, el color en una capa aparte sin tocar el original. La Brocha con "No pasar la línea" ya no tapa la línea. "Líneas" unificada con vista previa y modo para imágenes a color. Panel de capas con 6 botones (incluido "Imagen color") y menú "Más". Curva sin línea punteada. Al cortar partes ya no queda su contorno. Sin IA.
**Especial, Malla y Puntos de anclaje no cambiaron.**

Cambios, mediciones y límites: `CAMBIOS_8_24_BALDE_Y_COLOREADO.md`.
Pruebas: `sh tests/run_jvm_tests.sh` (Android simulado, no un teléfono).
**El código compila contra el android.jar oficial (API 34), pero no se generó el APK ni se probó en un teléfono.**

---

# Paint Zeta v8.23 — Mejoras de herramientas (código fuente)

Difuminar sin halos, navegación con dos dedos estable (girar con umbral, imán, voltear y restablecer vista), Brocha/Goma con recorrido continuo y estabilizador que llega al dedo, Relleno que no tapa las líneas (y "Colorear sin tapar líneas"), Borrar fondo con filo limpio, Borrosidad igual a cualquier velocidad, Cortar a capa sin línea en el corte, Curva sin ganchos y "Extraer líneas". Sin IA.
**Especial, Malla y Puntos de anclaje no cambiaron.**

Cambios, mediciones y límites: `CAMBIOS_8_23_MEJORAS_HERRAMIENTAS.md`.
Pruebas: `sh tests/run_jvm_tests.sh` (Android simulado, no un teléfono).
**El código compila contra el android.jar oficial (API 34), pero no se generó el APK ni se probó en un teléfono.**

---

# Paint Zeta v8.20 — Especial reconstruido (código fuente)

Nuevo motor de **remapeo inverso** para Especial, menos cálculos por píxel,
protección contra pliegues, navegación de dos dedos sin rotación involuntaria,
y nuevo icono diferenciado para **Suavizar bordes**.
**Malla/Puntos, Curva, Polilínea y Lazo se mantienen.**

Cambios y límites: `CAMBIOS_8_20_MOTOR_ESPECIAL.md`.
Pruebas Java: `sh tests/run_jvm_tests.sh`.
**Sin APK compilado ni pruebas físicas de FPS en Android en este entorno**.

---

# Paint Zeta v8.19.1 — Curva y Polilínea restauradas

Se restauraron **Curva** y **Polilínea** en el grupo **PINTAR Y RETOCAR**, sin recuperar herramientas dependientes de la selección azul. Consulta `CAMBIOS_8_19_1_RESTAURAR_CURVA_POLILINEA.md`.

**Sin compilación APK ni pruebas en Android en este entorno.**

---

# Paint Zeta v8.19 — optimización dirigida a fluidez

Se conserva el proyecto Android Studio. Cambios de motor y límites descritos en `CAMBIOS_8_19_OPTIMIZACION.md`.

**No hay APK compilado ni validación de rendimiento en teléfono en este entorno.**

---

# Paint Zeta v8.18 — Flujo práctico para preparar personajes

Correcciones de Lazo, Especial, exportación PNG para animación, guardado con respaldo y transparencias.

Detalles y limitaciones: `CAMBIOS_8_18_FLUJO_ESTABILIDAD.md`.

**Proyecto fuente para Android Studio, no APK. Todavía requiere compilación y pruebas en teléfono.**

---

# Paint Zeta v8.16 — Especial: motor protegido y render unificado

- **Protección geométrica real** contra inversión de celdas y pliegues: detector de áreas firmadas y reducción automática de incrementos inseguros.
- **Vista previa y resultado final con un único sampler** inverso por píxel. Eliminada la vista previa de malla que producía geometrías diferentes.
- Más precisión en el campo, bordes y controles táctiles; conservación de la fuente estable.
- Pruebas numéricas y estáticas en `tests/`. **No compilado ni probado en Android** (pendiente comprobación de APK en dispositivo).
- Detalles: `CAMBIOS_8_16_ESPECIAL.md`.

# Paint Zeta v8.15 — Reparacion de Brocha y Especial

- **CRASH AL PINTAR:** corregido un `NullPointerException` reproducible al elegir Brocha y tocar el lienzo. `stampPaint()` necesita `cov[i]` pero `beginLayerStroke()` dejaba `cov = null` para `MODE_PAINT`. Ahora se inicializa el buffer cuando la herramienta lo requiere; se valida su presencia antes de usarlo. Este fallo se aprecia al final del segundo video, justo despues de activar Brocha.
- **Especial:** los cinco modos estan directamente disponibles en una barra compacta. Las fichas animadas ya no tapan el dibujo al seleccionar cada modo; se pueden abrir manteniendo pulsado un icono.
- **Fortaleza visible:** el segundo control es Fortaleza en Especial y Opacidad en las demas herramientas. Sus valores se conservan por separado al cambiar de modo, y los botones +/- siguen funcionando.
- **Movimiento y precision:** malla de deformacion ligeramente mas fina, mas muestras interpoladas en movimientos rapidos, vista previa con mas nodos y remapeo inverso final de 3 iteraciones para reducir saltos en bordes. Interpolacion en los bordes del lienzo sin franjas artificiales.
- **Seguridad:** al cambiar subherramienta durante un trazo, finaliza el trazo anterior antes de cambiar; se conservan las funciones fuera de Especial.
- `versionCode 52`, `versionName 8.15`.

**Nota:** esta revision de codigo no sustituye la prueba real con un APK en el dispositivo: no se incluye un registro `logcat` del cierre. La causa concreta del fallo de Brocha estaba presente en el codigo.

# Paint Zeta v8.14

## v8.14 — Especial/Malla/Anclajes

- Especial: preview en tiempo real con `drawBitmapMesh` sobre la fuente estable. Ya no pinta bloques 4x4/6x6 durante el gesto. El remapeo de alta calidad se hace al levantar el dedo.
- Anclajes: motor interno reducido y basado en la misma malla de Transformar para bajar lag y evitar el aspecto excesivamente filtrado.
- El punto seleccionado queda seleccionado al levantar el dedo; el tacho elimina exactamente ese punto.
- Solo el punto móvil seleccionado muestra su línea de desplazamiento.
- Transformar usa botones compactos; Cancelar y ✓ quedan dentro de la pantalla. Las opciones menos frecuentes de Anclajes pasan al menú de tres puntos.
- Malla/Anclajes conservan: 1 dedo edita nodos/puntos; 2 dedos siempre mueven el lienzo y hacen zoom.
- versionCode 51 / versionName 8.14.


Cambios principales de esta version:
- Especial/Licuar: preview mucho mas ligero, campo menos denso y sin crecimiento gigante del ROI durante el arrastre.
- Malla/Perspectiva: 1 dedo deforma; 2 dedos siempre mueven y hacen zoom del lienzo.
- Nueva deformacion por Puntos/Anclajes: puntos fijos azules y moviles naranjas con radio de influencia.
- Referencia de color: panel mas compacto, redimensionable y con carga de imagen de mayor resolucion.

# Paint Zeta 8.11

### v8.11 — Licuar por campo de deformación + malla suave + referencia flotante

- **Especial/Licuar rehecho desde el núcleo:** ya no vuelve a usar la imagen deformada como fuente en cada movimiento. Mantiene una fuente estable por bloques y un campo de desplazamiento.
- **Remapeo inverso + bilinear premultiplicado:** evita huecos, dientes acumulativos y halos oscuros en bordes transparentes.
- Modos correctos: **Arrastrar, Contraer, Expandir, Suavizar y Restaurar**. Suavizar actúa sobre la deformación, no aplica blur a la imagen.
- **Malla instantánea:** la cuadrícula aparece antes de preparar el bitmap pesado; además usa una malla interna más densa con suavidad Catmull-Rom y evita que nodos interiores crucen a sus vecinos.
- **Suavidad de malla** ajustable desde la barra de Transformar.
- **Referencia de color flotante:** permanece abierta, se puede mover, hacer zoom con dos dedos, desplazar la imagen y tomar varios colores sin cerrarse ni exportarse con el dibujo.
- versionCode 48 / versionName 8.11.

---

## Paint Zeta 8.7


### v8.7 — estabilidad, selección y flujo para Alight Motion

- Brocha, Goma, Borrar fondo, Clonar, Curva/Polilínea y la selección azul usan Deshacer por bloques de 64 px: ya no duplican toda la capa o toda la máscara por cada trazo.
- Corrector libera su respaldo grande en cuanto lo entrega al proceso de reparación; menos memoria retenida después de usarlo.
- La fila **Selección** queda visible en Capas y se puede activar/limpiar sin perder la capa normal de origen.
- **De lo azul / Copiar / Cortar** permite elegir nombre de pieza y 0–12 px de solapamiento para brazos, piernas, cabeza o cabello, evitando huecos al rotar en Alight Motion.
- Separar partes deja más margen alrededor de marcas pequeñas y, si no marcas el fondo gris, usa el borde del área como fondo automático.
- Exportación PNG limpia solo la región ocupada por cada pieza y usa defringe desde el interior para reducir halos negros, conservando el lienzo completo y la alineación.
- El historial calcula mejor la memoria de capas retenidas y se reajusta después de agregar, borrar o reordenar capas.
- Al cerrar el editor se cancelan callbacks, miniaturas y temporales para evitar acumulación de RAM al abrir varios trabajos.
- Corregido el arrastre de capas para que la fila Selección no entre en el orden normal.
- GitHub Actions elige versiones con orden natural (`v8_10` después de `v8_9`) y escucha el workflow correcto.
- Se conservan las animaciones de ayuda de Borrosidad, Difuminar y los cinco modos de Especial añadidas en v8.6.

### v8.6 — Borrosidad fluida + Especial que deforma de verdad

- Borrosidad optimizada para pinceles grandes: menos trabajo repetido por pixel y menos stamps superpuestos.
- Difuminar, Borrosidad y Especial ya no copian la capa completa al empezar cada trazo; Deshacer guarda solo bloques tocados.
- Especial/Arrastrar mueve los pixeles con mucha mas claridad y conserva el detalle en vez de parecer Borrosidad.
- Contraer, Expandir y Remolino tienen deformacion visible, progresiva y con borde suave independiente de la fuerza.
- Restaurar mantiene el estado base por bloques y el trazo se puede deshacer sin duplicar toda la capa.
- Animaciones nuevas para Borrosidad, Difuminar y los cinco modos de Especial; al cambiar un modo de Especial se muestra como funciona.

### v8.5 — Transformar preciso + Especial suave

- Transformar libre queda separado de Perspectiva y Malla: perspectiva/malla ya no desplazan toda la imagen por accidente al arrastrar fuera de un nodo.
- Malla ajustable por filas y columnas de 2 a 12 para trabajar con cuadros mas pequeños donde haga falta.
- Especial/Licuar rehecho para deformacion localizada y progresiva: limita saltos largos, usa mas muestras cortas y reduce el estiramiento destructivo.
- Nuevo control independiente de Suavidad para Especial, ademas de Fuerza y Tamaño.
- Arrastrar, Contraer, Expandir y Remolino usan deformaciones menores y acumulativas para conservar mejor el detalle.
- La copia completa usada por Restaurar se crea solo cuando se selecciona Restaurar, reduciendo memoria al usar los otros modos de Especial.


### v8.4 — estabilidad de Transformar y Borrar fondo

- Transformar ya no crea una copia completa extra del lienzo al iniciar.
- Corregido el Bitmap de Transformar para que sea compatible con Canvas premultiplicado.
- Aplicacion de Transformar por bloques de 512 px en segundo plano para evitar ANR y picos de RAM.
- Deshacer de Transformar guarda solo origen y zonas nuevas del destino.
- Borrar fondo agrega Suavidad independiente, conserva Tolerancia y Borde, y reutiliza buffers durante el trazo.
- Eliminado el limite fijo de 4096 px al importar; el ajuste ahora depende de la memoria real del dispositivo.

- Transformar: mover/escalar/girar, perspectiva y malla deformable con aplicar/cancelar.
- Difuminar, Borrosidad y Especial/Licuar por regiones para reducir carga.
- Especial: Arrastrar, Contraer, Expandir, Suavizar y Restaurar.
- Selector de color HSV con rueda, HEX, RGB y opacidad.
- Boton de pintura para crear una capa `Superposicion` en modo Overlay.
- La previsualizacion de Transformar no se guarda durante el autoguardado hasta confirmar.
# Paint Zeta

App Android para extraer partes de dibujos anime y manga por capas, y exportarlas
como PNG transparentes listos para animar en Alight Motion.

Todo funciona sin internet. No usa modelos de IA ni librerias nativas pesadas.

---

## Como compilar el APK

1. Sube esta carpeta completa a un repositorio de GitHub.
2. Entra a la pestana Actions del repositorio.
3. El workflow "Compilar APK" arranca solo con cada push. Si no, toca
   "Run workflow" a mano.
4. Cuando termine, abre la ejecucion y descarga el artefacto `PaintZeta-debug`.
5. Dentro viene el APK. Descomprime e instala.

No hace falta `gradle-wrapper.jar`: el workflow instala Gradle 8.7 por su cuenta.

---

## Como se usa

1. Toca **Abrir** y elige la imagen. Ya no hay un tope fijo de 4096 px: se conserva
   la mayor resolucion que la memoria real del telefono permita sin cerrar Android.
2. Elige una herramienta abajo y selecciona la parte que quieres sacar.
3. Toca **Crear capa**. Eso guarda la seleccion como una capa y limpia el lienzo
   para seguir con la siguiente parte.
4. Repite por cada parte: pelo, cara, brazo, ropa, fondo.
5. Ordena las capas desde el menu Capas, con Subir y Bajar. El orden decide el
   numero del PNG y en animacion eso importa: el brazo va delante o detras del
   torso segun el movimiento.
6. Toca **Exportar** y elige el tamano.

Todos los PNG salen del mismo tamano de lienzo, tanto a resolucion original como
reducidos, asi que al importarlos en Alight Motion entran ya alineados y no hay
que reposicionar nada.

Al exportar puedes elegir original, mitad, lado largo 1920 o lado largo 1280.
Para un video de 1080p no tiene sentido cargar capas de 3000 px: pesan mucho y
ponen lento Alight Motion.

**Alight Motion no abre ZIP.** Descomprime primero con ZArchiver o similar y
despues importa los PNG.

---

## Herramientas

**Varita** — Toca una zona y selecciona todo el color parecido que este pegado.
El slider de tolerancia decide cuanto se parece: bajo para colores planos,
alto si hay sombras o degradado.

**Global** — Con esto activado la varita selecciona ese color en TODA la imagen,
no solo la mancha que tocaste. Util para sacar todo el pelo de un color de golpe.

**Line art** — Convierte las lineas oscuras del dibujo en una barrera. La varita
deja de escaparse por los huecos de la linea. Es lo que hace que funcione bien
en manga blanco y negro. Puedes elegir que tan oscura cuenta como linea y cuantos
pixeles engordarla para cerrar huecos.

**Pincel / Borrador** — Pinta o borra la seleccion a mano, con borde suave.
Para arreglar lo que la varita no agarro bien.

**Lazo** — Rodea una zona con el dedo y se selecciona al soltar.

**Restar** — Con esto activado, la varita, el lazo y el pincel quitan de la
seleccion en vez de agregar.

**Borde** — Expandir, contraer, suavizar o endurecer el borde de la seleccion.
En manga conviene expandir 1 o 2 px para no cortar la linea negra por la mitad.

**Clonar** — Primer toque fija el origen (sale una cruz roja). Despues arrastras
y copia esa zona donde pases el dedo. Sirve para tapar el hueco que queda al sacar
una parte, o para rellenar copiando un trozo del propio dibujo.

**Pintar** — Pincel de color normal. Si hay una seleccion activa, solo pinta
dentro de ella, igual que en Ibis Paint. Con **Fino** activado no pisa las lineas
del dibujo, asi que puedes pintar rapido por encima sin borrar el contorno.

**Balde** — Rellena de color toda la zona parecida que toques. Usa la misma
tolerancia que la varita y respeta el line art.

**Color de la imagen** — Cuentagotas. Toca cualquier punto y ese color pasa a ser
el color de pintar.

**Color** — Abre la paleta: 24 colores listos, tres barras de rojo, verde y azul
para cualquier tono, y un boton para tomar el color de la imagen. El boton se tine
del color actual para que veas cual tienes cargado.

**Fino** — Modo de deteccion. En el pincel de seleccion solo agarra el color que
tocaste al empezar el trazo y se detiene en las lineas, asi que puedes pasar el dedo
rapido sin salirte de la figura. En el pincel de pintar, protege las lineas.

**Dureza** — Que tan suave es el borde del pincel, de 20% a 100%.

**Girar** — Gira 90 grados a un lado o al otro, o voltea la imagen. Gira todo junto:
imagen, seleccion, line art y cada capa, asi que nada se desalinea. El historial de
deshacer se reinicia al girar.

**Invertir / Limpiar** — Invierte la seleccion o la borra entera.

**Capas** — Lista de capas creadas. Cada una se puede ocultar, renombrar, eliminar,
exportar sola, o cargar de vuelta a la seleccion para seguir editandola.

**Proyecto** — Guarda el trabajo completo en un archivo `.acut`: la imagen, la
seleccion, el line art y todas las capas con sus nombres. Desde ahi tambien se abre
un proyecto guardado.

**Encuadrar** — Devuelve la imagen al centro de la pantalla si te perdiste con el zoom.

**Mano** — Mueve la imagen con un dedo. Con dos dedos puedes mover y hacer zoom
en cualquier herramienta.

---

## Lo que trae el ZIP

- Un PNG por cada capa visible, numerado: `01_capa_1.png`, `02_capa_2.png`...
- Un `99_fondo_restante.png` con lo que queda de la imagen al quitar todas las capas.
  Sirve como fondo del video.

---

## El trabajo no se pierde

La app guarda sola dentro de su almacenamiento cada vez que creas una capa y
cada vez que sales. Si entra una llamada o Android cierra la app, al volver a
abrirla te pregunta si quieres recuperar el proyecto.

Para algo mas seguro, usa **Proyecto > Guardar proyecto en un archivo** y guardalo
donde tu quieras. Ese archivo se puede copiar, respaldar o mover a otro telefono.

Dos avisos:

- El autoguardado corre en segundo plano. Si el telefono mata la app justo en
  ese momento, puede quedar a medias. El guardado manual es el seguro.
- Antes de crear la capa, tapa con **Clonar** el hueco que deja la parte que
  sacaste. Si no, en el video se vera el agujero cuando esa parte se mueva.

---

## Notas tecnicas

- Las capas se guardan como mascaras de 1 byte por pixel, no como imagenes
  completas. Ocupan 4 veces menos memoria.
- Deshacer guarda solo el rectangulo que cambio, con un tope de 32 MB.
- La imagen se dibuja en pantalla desde una copia reducida para ir fluido, pero
  todas las operaciones se aplican sobre los pixeles reales.
- El relleno usa un algoritmo por lineas (scanline), no recursivo, para que no
  se desborde la pila en imagenes grandes.
- Al pintar o clonar solo se actualiza el trozo de pantalla que cambio, no la
  imagen entera, para que el trazo no se trabe.
- Al acercar mas alla del 100% el filtrado se apaga solo: el pixel se ve nitido
  para trabajar fino en vez de borroso.
- No pide permisos: usa el selector del sistema para abrir y guardar.
- El proyecto `.acut` es un ZIP por dentro. Las mascaras son casi todo ceros y
  doscientos cincuenta y cinco, asi que se comprimen muchisimo.
- Al exportar reducido, cada pixel de salida es el promedio del bloque que le
  toca, pesado por el alfa, para que el borde no arrastre color de lo transparente.

---

## Siguientes versiones

- v2: click-to-segment con MobileSAM (tocar una parte y que la recorte sola),
  suavizado de bordes tipo pelo, recorte de fondo con modelo descargable.
- v3: relleno inteligente del hueco con IA.


## Identidad visual

Nombre visible en Android: **Paint Zeta**. Icono HD para launchers cuadrados y circulares, y adaptive icon Android 8+ con zona segura central. Fuentes PNG de 1024 × 1024 en `branding/`. El identificador de instalacion `com.pacco.animecut` se conserva para no romper las actualizaciones de la misma app.


---

## Novedades de esta version

### Se acabaron los cuadraditos blancos del borde

El contorno de un dibujo no pasa de negro a color de golpe: tiene una franja
de pixeles intermedios por el antialias, mas el ruido del JPEG. La varita los
dejaba fuera y quedaba el escaloncito.

Tres cosas nuevas lo arreglan:

**Suavidad del borde.** La seleccion ya no es si o no. Los pixeles del filo
entran a medias segun cuanto se parecen. El borde sale suave, no escalonado.

**Expansion con decimales.** La seleccion se engorda 1.5 px por defecto, que es
justo lo que mide el antialias. Es el mismo valor que usa Ibis. Se ajusta de
-3 a +5 px en pasos de 0.1.

**Limpieza del borde al exportar.** A cada pixel del filo se le devuelve el
color de adentro y se le quita el color del fondo que se le habia pegado.
Esto es lo que evita el halo blanco al poner la capa sobre otro fondo en
Alight Motion.

### Ajustes de la varita

En el menu, "Ajustes de la varita":

- **Fuerza**: hasta que diferencia de color sigue seleccionando
- **Suavidad del borde**: franja donde el pixel entra a medias
- **Expansion**: la de arriba, con decimales
- **Reconocimiento de huecos**: engorda la linea para tapar los cortes,
  rellena dentro, y devuelve el relleno a su sitio. Asi no se escapa por una
  linea abierta
- **Como compara el color**: exacto, por tono ignorando sombras, o como lo ve
  el ojo. El de tono sirve cuando una zona tiene sombreado del mismo color

### Galeria de obras

La app arranca en la galeria. Ahi estan todas tus obras con su miniatura,
ordenadas por la ultima vez que las tocaste. Se guardan solas al crear una
capa y al salir. Mantener pulsada una obra la abre o la elimina.

### Gestos

- **Dos dedos, toque**: deshacer
- **Tres dedos, toque**: rehacer
- **Dos dedos arrastrando**: mover y hacer zoom
- **Dos dedos en circulo**: girar el lienzo
- **Mantener pulsado**: gotero rapido, sale una burbuja con el color antes de
  soltar

### Otras

- **Gama de colores**: selecciona un color en toda la imagen, con margen
- **Copiar, cortar y pegar** la seleccion
- **Aviso flotante** con el porcentaje de zoom y con lo que se deshizo

---

## Notas tecnicas de lo nuevo

- La expansion con decimales usa una transformada de distancia exacta
  (Felzenszwalb y Huttenlocher). Coste lineal, sin importar cuanto expandas.
- La morfologia pasa a van Herk y Gil-Werman: tres comparaciones por pixel sin
  importar el radio. Expandir y contraer ya no se pone lento con radios grandes.
- La transformada de distancia guarda tambien cual es el pixel opaco mas
  cercano, y con eso el defringe sabe de donde tomar el color.
- La limpieza del fondo despeja la mezcla: el pixel visto es
  C = a*F + (1-a)*B, asi que el color real es F = (C - (1-a)*B) / a.
- Todo se calcula solo dentro del rectangulo que hace falta, no sobre la
  imagen entera, para no reservar decenas de MB.
- El cierre de huecos es una version del metodo de la bola atrapada que se usa
  para colorear line art.


---

## Segunda tanda: lo que faltaba

### Tijeras inteligentes

La herramienta nueva de la columna. Arrastras siguiendo el contorno y la
linea se pega sola al borde del dibujo. Al soltar se fija ese tramo y sigues
con el siguiente. Cuando vuelves al punto verde del principio, la figura se
cierra y se convierte en seleccion.

Por dentro busca el camino mas barato desde el ultimo punto fijado hasta tu
dedo, donde pasar por un borde cuesta barato y pasar por una zona plana cuesta
caro. El calculo se hace en una ventana de 320 px alrededor del punto fijado,
no en toda la imagen, para que responda al instante.

Es la funcion que Ibis no tiene y la que mas tiempo ahorra para sacar un
personaje completo.

### Mover seleccion

Si la varita agarro bien la forma pero esta corrida, arrastras y la mueves
sin volver a seleccionar.

### Refinar borde

Hace que el alfa siga el borde real del dibujo. Es para pelo y bordes finos,
donde una mascara de si o no siempre queda mal. Tres intensidades.

### Rellenar zonas sin pintar

Rellena los huecos que quedaron encerrados dentro de la seleccion. A
diferencia de cerrar huecos, este no deforma el contorno de afuera: busca los
huecos de verdad, los que no salen al exterior.

### Filtros de limpieza

Aplicar uno antes de seleccionar hace que la varita agarre mucho mejor:

- **Quitar ruido de JPEG**: mediana de 3x3. Se come el ruido de bloque sin
  desdibujar las lineas
- **Aplanar tonos**: reduce la cantidad de colores, aplana el degradado
- **Niveles**: mas contraste
- **Extraer line art**: con sus tres controles, blanco, negro y medio

### Estabilizador del trazo

Corrige el pulso al dibujar. Cuatro niveles.

### Gama de colores con vista previa

Ahora ves la seleccion actualizarse en el lienzo mientras mueves el margen,
en vez de aplicar a ciegas.

### Aviso de que se deshizo

Dice "Deshacer: Varita", "Deshacer: Pincelada", y asi con cada cosa.

### Renombrar obras

En la galeria, manten pulsada una obra para abrirla, renombrarla o borrarla.

---

## Lo que sigue sin estar, y por que

- **Capa de referencia** y **Debajo de la linea de borde** de Ibis: necesitan
  que el line art viva en una capa aparte. Nosotros trabajamos sobre una sola
  imagen con mascaras, asi que no aplican tal cual.
- **Capas de dibujo de verdad**, con modos de fusion y clipping. Las nuestras
  son mascaras de recorte, que es lo que hace falta para exportar a Alight
  Motion. Meter capas pintables seria rehacer el motor entero.
- **Transformar libre** con escalar y rotar la seleccion. Solo esta mover.
- **Carpetas** en la galeria.


---

## Lo basico, en corto

La app trabaja con dos cosas distintas y es lo que mas confunde al principio:

**SELECCION** es la mancha azul. No es pintura. Es lo que tienes marcado para
convertirlo en capa. La hacen la varita, el pincel, el borrador, el lazo y las
tijeras.

**COLOR** es pintura de verdad. La ponen el rodillo y el balde, con el color
del circulo de abajo.

Por eso, si eliges un color y pintas con el pincel, no pasa nada de color: el
pincel pinta seleccion, no color. El que pinta color es el rodillo.

Y si tienes algo azul seleccionado, el rodillo solo pinta dentro de lo azul.
Para pintar libre, limpia la seleccion primero.

## Panel de capas

El boton de los rombos abre un panel de verdad, no una lista de texto:

- Miniatura de cada capa, con cuadros grises donde es transparente
- Arriba del todo, la fila de la Seleccion actual
- Ojo para mostrar u ocultar
- Opacidad por capa, de 0 a 100%
- Flechas para subir y bajar el orden
- Papelera para eliminar
- Tocar la miniatura devuelve esa capa a la seleccion para seguir editandola
- Tocar el nombre lo cambia

## Que hace cada boton

Manten pulsado cualquier boton, de la barra o del panel de capas, y te dice
como se llama.


---

## Version 2.0: modo despiece

La app se reordeno alrededor de una sola tarea: sacar partes rapido para
animar.

**Dos modos.** El boton de arriba a la derecha cambia entre RECORTAR y
RETOCAR. Recortar muestra solo lo que sirve para sacar partes: varita,
tijeras, lazo, pincel, borrador, mover. Retocar muestra rodillo, balde,
gotero y clonar, para tapar huecos o pintar.

**Agregar y quitar.** Abajo, el verde + agrega a la seleccion y el rojo -
quita. Funciona con la varita, el lazo, las tijeras y el pincel. Antes habia
un boton "restar" que no se entendia.

**Guardar parte, en un toque.** El boton azul grande de abajo. Te sale la
lista de nombres (pelo, cara, ojo izquierdo, boca, brazo...) y eliges uno. Si
ya existe, se numera solo. Sin escribir nada.

**Lo guardado se ve en verde.** Asi sabes que ya sacaste y que te falta.

**No agarrar lo ya guardado.** En el menu. Con esto activo, la varita y el
pincel no vuelven a seleccionar lo que ya es una parte. Util para ir pieza por
pieza sin pisarte.

**Menu ordenado por texto.** Agregar opciones ya no descuadra nada.

**versionCode 11**, para que se instale encima de la version anterior.


---

## Version 3.0: funciona como Ibis

La app ahora trabaja igual que Ibis Paint, con capas de verdad:

- La pantalla muestra la imagen y las capas recortadas sobre cuadros grises.
- **Duplicar** (en el panel de capas) copia la imagen a una capa nueva y oculta
  la original. Despues borras con la **Goma** lo que sobra.
- Si usas la Goma sin tener capa, la app duplica la imagen sola.
- Con algo seleccionado, la Goma solo borra dentro de lo azul, como en Ibis.
- **Cuadro punteado de arriba**: menu de seleccion con iconos. Guardar parte,
  Borrar area, Dejar solo esto, Invertir, Quitar, Ampliar, Refinar, Tapar
  huecos, Gama de color, Cerrar tijeras.
- **Barra de abajo**: herramienta actual, tamano del pincel, color, guardar
  parte, capas con su numero, exportar.
- **Dos sliders** de tamano y opacidad con botones - y + para ajustar fino.
- **Tipos de pincel** tocando el circulo del tamano: pluma suave, pluma fuerte,
  rotulador, lapiz difuminado, aerografo.
- **Panel de capas**: tocar una capa la activa (se marca en azul), ojo para
  mostrar u ocultar, la imagen original abajo con su propio ojo. Abajo del
  panel: duplicar, capa de lo seleccionado, subir, bajar, opacidad, eliminar.
  Mantener pulsada una capa la renombra.
- Se quito el texto de estado de abajo. Los avisos salen flotando un momento.

versionCode 12.


---

## Version 4.0: herramientas para sacar partes rapido

**Borrar fondo** (como el Background Eraser de Photoshop). Toma el color que
queda bajo la cruz y borra solo ese color dentro del pincel. Pasas un pincel
grueso por el borde del pelo y se va el fondo, no el pelo. Opciones:
- Una vez / todo el rato: si el color se toma al tocar o sigue al pincel
- Contiguo / disperso / bordes: disperso limpia tambien entre mechones;
  bordes deja el contorno nitido
- Candado: protege el color cargado para que nunca se borre
- Tolerancia: cuanto se tiene que parecer el color

**Separar partes** (como la Colorize Mask de Krita). Rayas cada parte con su
color, sin cuidado, y el fondo en gris. El check verde separa todo de una vez:
cada parte sale en su capa, cortada justo en la linea negra. Si no rayas el
fondo, se toma el borde de la imagen como fondo. Si lo vuelves a correr,
reemplaza las capas de la vez anterior.

**Magnetico**. Arrastras por el contorno y el trazo se pega solo a la linea.
Al soltar se cierra y queda seleccionado.

**Tapar hueco**. Tocas una parte en Capas (por ejemplo el ojo) y el boton del
cuadro con circulo. La parte guarda su imagen, y debajo el hueco se rellena
con el color de alrededor. Al mover el ojo en Alight Motion hay piel debajo,
no un agujero.

**Cursor desplazado y lupa**. La mira de arriba. El punto que trabaja queda
separado del dedo, y una lupa en la esquina muestra el borde ampliado.

versionCode 13.


---

## Version 5.0: reconstruir lo que queda detras de una parte

Cuando sacas un ojo, la boca, un mechon, una mano o un brazo para animarlo,
detras queda un hueco. Estas herramientas lo reconstruyen para que se vea
natural y del mismo estilo del dibujo.

**Como se usa:** en Capas toca la parte que sacaste. Al elegir una
herramienta de reconstruir, la parte guarda su imagen, el hueco se tapa en
bruto y la parte se oculta para que veas lo de atras. Despues:

1. **Continuar linea.** Traza con el dedo por donde seguia la linea cortada.
   La punta se engancha a la linea original y la curva sale y llega con su
   misma direccion, grosor y color. El boton de unir intenta hacerlo solo
   con las puntas que se miran de frente.
2. **Rellenar zona.** Toca cada zona del hueco: queda con el color plano de
   esa zona afuera del hueco, hasta las lineas. Tambien para cada tono de
   sombra.
3. **Copiar zona.** Pinta en verde de donde copiar (por ejemplo del torso) y
   toca el check. Rellena con trocitos de ahi que encajan con lo de alrededor
   (PatchMatch, el principio del relleno segun contenido). Si no pintas nada,
   copia de alrededor del hueco. Con huecos grandes trabaja en una copia
   reducida para no tardar.
4. **Corrector.** Como clonar, pero al soltar funde el color con el borde
   para que no se vea el escalon de tono.
5. **Trama manga.** Toca la trama de al lado del hueco: mide cada cuanto se
   repite y la continua alineada.

**Clonar mejorado:** muestra transparente lo que vas a copiar bajo el pincel,
espejo del origen para copiar el lado simetrico, y giro del origen.

**Regla de Live2D:** lo reconstruido pasa 3 px mas alla del borde de la
parte, para que al moverla en Alight Motion no aparezca un filo sin pintar.

**Orden recomendado:** primero cierra las lineas, despues rellena las zonas,
y al final corrige sombras y texturas con copiar zona o el corrector.

versionCode 14.


---

## Version 5.1: mas simple

- **Panel de herramientas chico**, abajo a la izquierda como en Ibis. Tocar
  fuera lo cierra. Agrupado por lo que hace: SACAR, REHACER LO DE ATRAS,
  PINTAR, MOVER.
- **Borrar imagen y borrar azul son herramientas distintas y con su nombre.**
  "Marcar azul" selecciona a mano, "Borrar azul" quita la seleccion, y
  "Borrar imagen" borra de la capa.
- **Guardar parte en un toque**, sin lista de nombres. Se llama capa_1,
  capa_2... Manten pulsada la capa para ponerle el nombre que quieras.
- **Separar partes** tambien crea parte_1, parte_2... sin nombres puestos.
- **El panel de capas ya no queda tapado**: al abrirlo se esconden los
  sliders y las barras de opciones.

versionCode 15.


---

## Version 5.2

- **Fichas con dibujo.** Manten pulsada cualquier herramienta y sale su
  ficha: un dibujo de antes y despues, para que sirve, como se usa y con que
  se combina. La primera vez que eliges una herramienta, la ficha sale sola.
- **Tutorial con dibujos** de 4 pasos al abrir la primera imagen, y en el
  menu.
- **Panel mas corto.** Se ven las herramientas basicas. Las demas estan en
  "Mas herramientas".
- **Ya no se cambia nada solo.** Elegir una herramienta de reconstruir no
  oculta tu capa ni muestra la imagen original. La goma borra en la capa que
  elegiste; si la imagen original tapa, te avisa en vez de ocultarla.
- **Ver sobre blanco, negro, gris o verde** en el panel de capas, para
  revisar que el recorte quedo limpio. No se exporta.
- **Imagen nueva limpia:** vuelve a la Varita, sin restos de la herramienta
  anterior.

versionCode 16.


---

## Version 5.3

- **Arreglado: el boton de herramientas no abria nada.** El panel se habia
  metido por error dentro del boton del tamano. Ahora esta una sola vez, arriba
  de todo.
- **Mini animacion de cada herramienta.** La primera vez que eliges una, sale
  su ficha con la animacion: un dedo se mueve por un dibujo y, por donde pasa,
  aparece el resultado. Las siguientes veces sale un cuadrito arriba a la
  izquierda con la animacion unos segundos; tocalo para cerrarlo. Se apaga en
  el menu.
- El tutorial de 4 pasos tambien es animado.

versionCode 17.


---

## Version 6.0: capas de verdad, como Ibis

Se rehizo la base de la app.

**Capas de verdad.** Cada capa tiene su propio dibujo con transparencia. Se
puede pintar en cualquier lado, tambien donde es transparente, y dibujar
partes nuevas. Al abrir una imagen queda en la capa "imagen".

**Panel de capas como Ibis.** Arriba, el fondo para mirar: cuadros claros,
cuadros oscuros, blanco, negro o verde. Debajo, la capa de seleccion y todas
las capas con miniatura y ojo. Abajo, botones con nombre: Nueva, Duplicar,
De lo azul, Combinar, Subir, Bajar, Opacidad, Imagen, Limpiar, Eliminar.
Manten pulsada una capa para cambiarle el nombre o exportarla sola.

**Capa de seleccion como Ibis.** Toca "Capa de seleccion" en el panel y la
brocha y la goma pintan lo azul.

**Toque como Ibis.** El trazo no empieza hasta que el dedo se mueve un poco o
pasa un instante. Si llega un segundo dedo, no se pinta nada: dos dedos solo
mueven, giran y hacen zoom. Tocar con dos dedos deshace, con tres rehace.

**Relleno normal.** Rellena donde tocas, en la capa elegida.

**Rehacer lo de atras** trabaja sobre lo azul: marcas lo que hay que rehacer
y usas Zona, Tapar hueco, Linea, Copiar zona o Trama.

**Nada se congela.** Lo que tarda corre aparte.

**Se quito** el verde de partes guardadas y los botones de arriba que no se
entendian. Arriba quedan deshacer, rehacer, seleccion y menu.

Las obras de la version anterior se abren y se convierten solas.

versionCode 18.


---

## Version 6.1

- **Negro y verde tambien con cuadros**, como los claros. El verde plano
  molestaba para mirar.
- **Borrar fondo arreglado.** El error era que, al volver a pasar por una zona
  ya borrada, tomaba lo transparente como color de referencia y no borraba
  nada. Ahora busca el fondo que todavia queda cerca de donde tocaste.
- **Un toque borra todo el fondo pegado** (el balde de goma de Ibis). Se
  enciende y apaga en la barra de la herramienta. Apagado, borra con el pincel.
- **Tolerancia propia** de Borrar fondo, aparte de la de la varita, y mas alta
  por defecto para que agarre de una.
- **Se limpian los puntitos** de fondo que quedaban sueltos entre lo borrado.

versionCode 19.

---

## Novedades v6.2

- Capas livianas: las capas que no se usan guardan solo el recorte con dibujo.
  Se pueden tener muchas capas en imagenes de hasta 4096 px.
- Duplicar, copiar a capa, cortar a capa y separar partes gastan solo lo que
  ocupa la parte.
- Antes de duplicar, crear, combinar, pintar o mover se revisa la memoria. Si no
  alcanza, la app avisa en vez de cerrarse.
- Al abrir una imagen de mas de 4096 px se ajusta a 4096 (maximo de Alight Motion).
- Guardado mas rapido: cada capa se guarda con su recorte. Las obras viejas se
  siguen abriendo.
- Zoom con resolucion original. Menu: "Zoom suave" SI/NO.

## Novedades v6.3

- Capas guardadas en la memoria grande del telefono (Bitmap), no en la de Java.
  Ya no sale "no alcanza la memoria" con pocas capas.
- Guardado automatico a los pocos segundos de cada cambio y cada 30 segundos.
  Guardado rapido: solo se vuelve a comprimir la capa que cambio.
- Exportar como PNG sueltos en una carpeta (01_pelo.png, 02_brazo.png...) o ZIP.
- La lista de pinceles marca con borde azul el que esta en uso.
- Tapar hueco nuevo para anime: rellena con el color plano de al lado sin
  borrones y une las lineas negras que cruzan el hueco con una curva suave.

## Novedades v6.4

- Arreglo: 6 herramientas solo mostraban texto y no dejaban elegir la opcion
  (Refinar borde, Rellenar zonas sin pintar, filtros antes de seleccionar,
  Estabilizador, borde de antialias, puntitos de trama).
- Borrador de fondo: si empiezas sobre lo ya borrado, no sale ningun aviso y
  sigues borrando apenas el pincel llega al fondo que queda.

## Novedades v6.5

- Varita que no se escapa: encuentra sola la linea negra (sin contar pelo o
  ropa oscura) y tapa sus cortes chicos. Menu: "Varita no se escapa por la
  linea" SI/NO. Si activas "Line art" manual, se usa ese.
- Separar partes con rayones mejorado (estilo LazyBrush): el limite entre
  partes cae sobre la linea negra, cruza los cortes de la linea y tambien
  respeta cambios fuertes de color donde no hay linea.

## Novedades v6.6

- Animaciones de antes y despues para las 12 opciones del cuadro punteado:
  manten presionado un boton para ver que hace.
- Animacion nueva para Separar partes y para la varita que no se escapa.

## Novedades v6.7

- Separar partes ya no congela: solo trabaja alrededor de las rayas.
- La capa original ya no se oculta: las partes se sacan de ella y el resto
  sigue visible. Si no rayas fondo gris, lo que esta lejos de las rayas cuenta
  como fondo.

## Novedades v6.8 (Separar y quitar fondo)

- Vista previa en vivo: al soltar el dedo se ve cada parte pintada de su
  color (calculada a menor tamano para que sea rapida).
- Rayas sin cuidado: lo que cae sobre la linea negra no cuenta.
- Boton Fondo: cambia rapido a gris para marcar el fondo y vuelve al color.
- Boton borrador: quita el fondo de la capa y deja lo marcado con color,
  como el quitar fondo de ibis pero sin IA. Sirve con toques sueltos.
- La linea negra se calcula una sola vez mientras no cambie la imagen.
- Las zonas sin raya toman el color de la parte vecina.

## Novedades v6.9

- Zoom nitido mucho mas rapido: se arma en su propio hilo (ya no espera al
  guardado automatico), repartido en varios nucleos, y primero solo lo que
  se ve en pantalla. Despues se agranda el margen para que al moverte ya
  este listo.

## Novedades v7.0

- Ya no sale "no alcanza la memoria" al agregar imagenes, duplicar o crear
  capas: la imagen agregada va directo a la memoria grande del telefono.
- Cerrar puntos, Rellenar zonas y Ampliar avisan si no hay nada en azul y
  dicen si encontraron huequitos.
- Ver la linea: al elegir "Que tan oscura es la linea" o prender la varita
  automatica, se pinta en rojo unos segundos lo que cuenta como linea.
  Tambien en el menu: "Ver en rojo la linea que usa la varita".

## Novedades v7.1

- Panel de la varita como ibis (boton de ajustes junto a la varita):
  Intensidad en %, Dilatacion, Llenado continuo, Hasta la linea,
  Reconocimiento de zonas sin pintar, Reconocimiento de huecos, y como
  compara el color. Se guarda para la proxima vez.
- "Hasta la linea" (prendido): lo elegido crece hasta tocar la linea negra y
  se come el borde blanco que quedaba al quitar el fondo. Solo crece cerca
  de la linea, no se mete en sombras.
- Pinceles: queda marcado el ultimo que elegiste aunque cambies el tamano.

## Novedades v7.2

- Panel de la varita chico, como ibis: Intensidad, Dilatacion y 4
  interruptores. Se aplica al momento, sin boton Aplicar.

## Novedades v7.3

- El panel de la varita ya no repite la Intensidad (se cambia con la barra de abajo).

## Novedades v7.4

- Capas: barra de Opacidad arriba de la lista, se ve al momento.
- Se quito la "Capa de seleccion" de la lista (lo azul se sigue usando igual).
- Mover capa fluido: la capa se arrastra como imagen y se aplica al soltar.
- Al mover la barra de tamano se ve el circulo del pincel en el centro.
- La lista de pinceles siempre marca uno (el elegido o el mas parecido).
- Guardar: "Elegir capas y guardar en Pictures/PaintZeta" crea la carpeta
  sola y guarda todas las capas marcadas como PNG transparente de una vez.


## v8.12
- Especial/Licuar: preview limitada a ~30 fps, remapeo de baja resolucion durante gesto y commit final por tiles.
- Menos stamps por MotionEvent y fuente temporal reutilizada para reducir llamadas por pixel.
- Referencia de color redimensionable/movible, tamaño persistente y carga de mayor resolucion (hasta ~2200 px de lado).

## v8.21 — Especial (vista previa asincrona)

La edicion v8.21 mueve la rasterizacion de la vista previa de Especial fuera del hilo de gestos, usa snapshots y evita que resultados de previews antiguas sobrescriban un trazo confirmado. No altera Malla ni las otras herramientas. Detalles y limitaciones: `CAMBIOS_8_21_ESPECIAL_ASINCRONO.md`. Pruebas sin Android: `sh tests/run_jvm_tests.sh`.

## v8.22 — Especial (motor nuevo)

Especial se reconstruyo por completo:
- campo de deformacion inverso **compuesto** (cada arrastre respeta lo ya deformado);
- rejilla fina evaluada con B-spline;
- sub-estampas limitadas para no plegar la imagen, con un verificador del mapa real;
- antialiasing al contraer;
- motor en su propio hilo; vista previa y resultado final identicos;
- confirmacion al soltar el dedo sin congelar la interfaz.

Malla y las demas herramientas no cambiaron. Detalles, pruebas y limitaciones en `CAMBIOS_8_22_ESPECIAL_MOTOR_NUEVO.md`. Pruebas sin Android: `sh tests/run_jvm_tests.sh`.
