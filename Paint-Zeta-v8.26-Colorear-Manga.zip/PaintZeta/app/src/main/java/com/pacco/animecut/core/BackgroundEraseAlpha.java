package com.pacco.animecut.core;

/**
 * Prepara la transparencia del borrador mágico sin mutar la capa.
 * No usa clases Android: comprobable con javac en pruebas de JVM.
 */
public final class BackgroundEraseAlpha {
    private BackgroundEraseAlpha() {}

    /** Devuelve (right-left)*(bottom-top) bytes de alfa ya descontaminada.
     * El llamante conserva los RGB originales y confirma el resultado en UI.
     */
    public static byte[] prepare(int[] px, int w, int h, int left, int top,
                                 int right, int bottom, byte[] mask, byte[] selection,
                                 int bgRef, int tolerance, int colorMode) {
        if (px == null || mask == null || left < 0 || top < 0 || right > w || bottom > h
                || left >= right || top >= bottom) throw new IllegalArgumentException("ROI");
        int rw = right - left, rh = bottom - top;
        byte[] alpha = new byte[rw * rh];
        for (int y = top; y < bottom; y++) {
            int src = y * w + left, dst = (y - top) * rw;
            for (int x = 0; x < rw; x++) {
                int i = src + x;
                int a = mask[i] & 255;
                int orig = px[i] >>> 24;
                float f = a / 255f;
                if (selection != null) f *= (selection[i] & 255) / 255f;
                alpha[dst + x] = (byte) (a == 0 ? orig : (int) (orig * (1f - f)));
            }
        }
        // Eliminar motas sin dependencia del orden de visita: igual que el
        // despeckle anterior, todos los vecinos usan alfa ANTES de esta fase.
        byte[] remove = null;
        int limit = tolerance * 2;
        for (int y = Math.max(1, top); y < Math.min(h - 1, bottom); y++) {
            int row = (y - top) * rw;
            for (int x = Math.max(1, left); x < Math.min(w - 1, right); x++) {
                int j = row + x - left;
                if ((alpha[j] & 255) == 0) continue;
                int i = y * w + x;
                if (ColorDist.dist(px[i] | 0xFF000000, bgRef | 0xFF000000, colorMode) > limit) continue;
                int empty = 0;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int xx = x + dx, yy = y + dy;
                    int na = xx >= left && xx < right && yy >= top && yy < bottom
                            ? alpha[(yy - top) * rw + xx - left] & 255
                            : px[yy * w + xx] >>> 24;
                    if (na < 40) empty++;
                }
                if (empty >= 5) {
                    if (remove == null) remove = new byte[alpha.length];
                    remove[j] = 1;
                }
            }
        }
        if (remove != null) {
            for (int i = 0; i < alpha.length; i++) if (remove[i] != 0) alpha[i] = 0;
        }
        return alpha;
    }

    /**
     * v8.23: borde limpio. Los pixeles del filo son mezcla C = a*F + (1-a)*B del
     * personaje F y del fondo B. La tolerancia sola los dejaba casi opacos con el
     * color claro del fondo (franja blanca al ponerlos sobre otro fondo).
     *
     * Para cada pixel a 2 px o menos del fondo ya borrado:
     *  1. Busca el pixel SOLIDO del personaje mas cercano (radio 5) y proyecta:
     *     a = (C-B)·(F-B) / |F-B|^2. El color que queda es el del personaje.
     *  2. Si no hay uno cerca (mechon fino) o el pixel no es mezcla de esos dos
     *     colores, usa "color a alfa": el alfa minimo que explica C con fondo B.
     * Solo BAJA el alfa que dejo la tolerancia; los pixeles solidos no cambian.
     *
     * @param alpha  salida de prepare() (se modifica)
     * @param mask   mascara del relleno (&gt;= 250 = fondo borrado del todo)
     * @return pares (indice de imagen, color RGB) para los pixeles del filo
     */
    public static int[] refineEdges(int[] px, int w, int h, int left, int top, int right, int bottom,
                                    byte[] alpha, byte[] mask, byte[] selection, int bgRef, int tolerance,
                                    int softness, int colorMode) {
        int rw = right - left, rh = bottom - top;
        int br = (bgRef >> 16) & 255, bgg = (bgRef >> 8) & 255, bb = bgRef & 255;
        int solidLimit = tolerance + softness;
        // distancia (chebyshev, hasta 2) al fondo borrado del todo
        byte[] near = new byte[rw * rh];
        boolean any = false;
        for (int y = top; y < bottom; y++) for (int x = left; x < right; x++) {
            int i0 = y * w + x;
            if ((mask[i0] & 255) < 250) continue;
            any = true;
            // solo el borde del fondo borrado marca la franja (el interior no aporta)
            if (x > 0 && x < w - 1 && y > 0 && y < h - 1
                    && (mask[i0 - 1] & 255) >= 250 && (mask[i0 + 1] & 255) >= 250
                    && (mask[i0 - w] & 255) >= 250 && (mask[i0 + w] & 255) >= 250
                    && (mask[i0 - w - 1] & 255) >= 250 && (mask[i0 - w + 1] & 255) >= 250
                    && (mask[i0 + w - 1] & 255) >= 250 && (mask[i0 + w + 1] & 255) >= 250) continue;
            for (int dy = -2; dy <= 2; dy++) {
                int yy = y + dy;
                if (yy < top || yy >= bottom) continue;
                for (int dx = -2; dx <= 2; dx++) {
                    int xx = x + dx;
                    if (xx < left || xx >= right) continue;
                    near[(yy - top) * rw + xx - left] = 1;
                }
            }
        }
        if (!any) return new int[0];
        int[] palette = palette(px, w, left, top, right, bottom, mask, near, bgRef, solidLimit, colorMode);
        int[] out = new int[64];
        int n = 0;
        for (int y = top; y < bottom; y++) for (int x = left; x < right; x++) {
            int j = (y - top) * rw + x - left, i = y * w + x;
            if (near[j] == 0) continue;
            int c = px[i], oa = c >>> 24;
            if (oa == 0) continue;
            int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
            float ur = cr - br, ug = cg - bgg, ub = cb - bb;
            float u2 = ur * ur + ug * ug + ub * ub;
            if (u2 < 4f) continue; // es fondo puro: lo decide la tolerancia
            // Borrado del todo por la tolerancia pero pegado al personaje y con algo de
            // su color: es el filo fino (mechon). Puede recuperar su parte, nunca mas.
            boolean erased = (mask[i] & 255) >= 250;
            if (erased && (u2 < 400f || !touchesCharacter(px, w, h, x, y, mask))) continue;
            if (!erased && (alpha[j] & 255) == 0) continue;
            float a = -1f;
            int rgb = 0;
            // Candidatos al color real del personaje, en orden de confianza:
            //  1) el pixel solido mas cercano (radio 5) que no toca el fondo,
            //  2) los colores principales del personaje en la zona (paleta),
            //  3) el pixel mas "puro" a 2 px o menos, incluido este.
            int f1 = nearestSolid(px, w, h, x, y, left, top, right, bottom, rw, mask, near, bgRef, solidLimit, colorMode);
            int f3 = purest(px, w, h, x, y, mask, bgRef, solidLimit, colorMode);
            int cand = (f1 != -1 ? 1 : 0) + (palette.length) + (f3 != -1 ? 1 : 0);
            for (int k = 0; k < cand && a < 0f; k++) {
                int f;
                if (f1 != -1 && k == 0) f = f1;
                else {
                    int pk = k - (f1 != -1 ? 1 : 0);
                    f = pk < palette.length ? palette[pk] : f3;
                }
                float vr = ((f >> 16) & 255) - br, vg = ((f >> 8) & 255) - bgg, vb = (f & 255) - bb;
                float v2 = vr * vr + vg * vg + vb * vb;
                if (v2 < 900f) continue;
                float t = (ur * vr + ug * vg + ub * vb) / v2;
                float tc = Math.max(0f, Math.min(1f, t));
                float er = ur - tc * vr, eg = ug - tc * vg, eb = ub - tc * vb;
                // el pixel debe ser (casi) mezcla de ese color con el fondo
                if (er * er + eg * eg + eb * eb > Math.max(400f, v2 * .04f)) continue;
                // Tan puro como el personaje: no se toca. Margen de ~20 niveles para el
                // ruido tipo JPEG entre dos pixeles (mas ancho cuando el personaje se
                // parece al fondo, por ejemplo piel clara sobre blanco).
                if (t >= 1f - Math.max(.02f, 20f / (float) Math.sqrt(v2))) { a = 1f; break; }
                a = tc;
                rgb = a >= .5f ? unmix(cr, cg, cb, br, bgg, bb, a) : f & 0xFFFFFF;
            }
            if (a < 0f && erased) continue;
            if (a < 0f) {
                // 4) color a alfa: alfa minimo con el color real dentro de 0..255
                a = Math.max(chA(cr, br), Math.max(chA(cg, bgg), chA(cb, bb)));
                rgb = a <= 0f ? c & 0xFFFFFF : unmix(cr, cg, cb, br, bgg, bb, a);
            }
            if (a >= 1f) continue;
            if (selection != null) {
                float s = (selection[i] & 255) / 255f;
                a = 1f - (1f - a) * s;
            }
            int na = Math.round(oa * a);
            if (erased) {
                if (a < .1f || na <= (alpha[j] & 255)) continue;
            } else if (na >= (alpha[j] & 255)) continue;
            alpha[j] = (byte) na;
            if (n + 2 > out.length) out = java.util.Arrays.copyOf(out, out.length * 2);
            out[n++] = i;
            out[n++] = rgb;
        }
        return java.util.Arrays.copyOf(out, n);
    }

    /** Hay personaje sin borrar a 1 px (incluidas diagonales). */
    private static boolean touchesCharacter(int[] px, int w, int h, int x, int y, byte[] mask) {
        for (int dy = -1; dy <= 1; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= h) continue;
            for (int dx = -1; dx <= 1; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= w || (dx == 0 && dy == 0)) continue;
                int q = yy * w + xx;
                if ((mask[q] & 255) == 0 && (px[q] >>> 24) >= 128) return true;
            }
        }
        return false;
    }

    private static boolean solid(int[] px, byte[] mask, int q, int bgRef, int solidLimit, int colorMode) {
        return (px[q] >>> 24) >= 250 && (mask[q] & 255) == 0
                && ColorDist.dist(px[q] | 0xFF000000, bgRef | 0xFF000000, colorMode) > solidLimit;
    }

    private static int nearestSolid(int[] px, int w, int h, int x, int y, int left, int top, int right, int bottom,
                                    int rw, byte[] mask, byte[] near, int bgRef, int solidLimit, int colorMode) {
        for (int rad = 1; rad <= 5; rad++) {
            for (int dy = -rad; dy <= rad; dy++) {
                int yy = y + dy;
                if (yy < top || yy >= bottom) continue;
                int step = (dy == -rad || dy == rad) ? 1 : 2 * rad;
                for (int dx = -rad; dx <= rad; dx += step) {
                    int xx = x + dx;
                    if (xx < left || xx >= right) continue;
                    if (near[(yy - top) * rw + xx - left] != 0) continue;
                    int q = yy * w + xx;
                    if (solid(px, mask, q, bgRef, solidLimit, colorMode)) return px[q];
                }
            }
        }
        return -1;
    }

    private static int purest(int[] px, int w, int h, int x, int y, byte[] mask, int bgRef, int solidLimit, int colorMode) {
        int best = solidLimit, f = -1;
        for (int dy = -2; dy <= 2; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= h) continue;
            for (int dx = -2; dx <= 2; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= w) continue;
                int q = yy * w + xx;
                if ((px[q] >>> 24) < 250 || (mask[q] & 255) >= 250) continue;
                int d = ColorDist.dist(px[q] | 0xFF000000, bgRef | 0xFF000000, colorMode);
                if (d > best) { best = d; f = px[q]; }
            }
        }
        return f;
    }

    /** Hasta 12 colores principales del personaje (pixeles solidos que no tocan el fondo). */
    private static int[] palette(int[] px, int w, int left, int top, int right, int bottom, byte[] mask,
                                 byte[] near, int bgRef, int solidLimit, int colorMode) {
        int rw = right - left;
        int[] cnt = new int[4096];
        long[] sr = new long[4096], sg = new long[4096], sb = new long[4096];
        int total = 0;
        for (int y = top; y < bottom; y++) for (int x = left; x < right; x++) {
            if (near[(y - top) * rw + x - left] != 0) continue;
            int q = y * w + x;
            if ((mask[q] & 255) != 0 || (px[q] >>> 24) < 250) continue;
            int c = px[q];
            int bin = ((c >> 20) & 15) << 8 | ((c >> 12) & 15) << 4 | ((c >> 4) & 15);
            if (cnt[bin] == 0 && ColorDist.dist(c | 0xFF000000, bgRef | 0xFF000000, colorMode) <= solidLimit) continue;
            cnt[bin]++;
            sr[bin] += (c >> 16) & 255; sg[bin] += (c >> 8) & 255; sb[bin] += c & 255;
            total++;
        }
        int minCount = Math.max(8, total / 400);
        int[] out = new int[12];
        int n = 0;
        while (n < out.length) {
            int best = -1;
            for (int k = 0; k < 4096; k++) if (cnt[k] >= minCount && (best < 0 || cnt[k] > cnt[best])) best = k;
            if (best < 0) break;
            int c = cnt[best];
            out[n++] = 0xFF000000 | (int) (sr[best] / c) << 16 | (int) (sg[best] / c) << 8 | (int) (sb[best] / c);
            cnt[best] = 0;
        }
        return java.util.Arrays.copyOf(out, n);
    }

    private static float chA(int c, int b) {
        if (c < b) return (b - c) / (float) b;
        if (c > b) return (c - b) / (float) (255 - b);
        return 0f;
    }

    private static int unmix(int cr, int cg, int cb, int br, int bg, int bb, float a) {
        float k = 1f / Math.max(.02f, a);
        int r = clamp(br + (cr - br) * k), g = clamp(bg + (cg - bg) * k), b = clamp(bb + (cb - bb) * k);
        return (r << 16) | (g << 8) | b;
    }

    private static int clamp(float v) { return v < 0 ? 0 : v > 255 ? 255 : (int) (v + .5f); }
}
