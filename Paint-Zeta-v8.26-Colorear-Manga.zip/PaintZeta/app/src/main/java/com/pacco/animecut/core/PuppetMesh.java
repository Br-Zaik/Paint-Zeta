package com.pacco.animecut.core;

import java.util.Arrays;

/**
 * Malla triangular de Marioneta ajustada a la silueta (alfa) de la imagen.
 *
 * Como se construye (sin IA):
 * 1. Mascara = pixeles con alfa &gt; 0, dilatada "Expansion" pixeles.
 * 2. La imagen se divide en celdas de lado {@code spacing} (la Densidad).
 * 3. Dentro de cada celda se separan las partes de la mascara que NO se tocan
 *    (componentes conexas, 8 vecinos). Cada parte es un cuadro propio de la
 *    malla con sus propias esquinas.
 * 4. Dos cuadros vecinos comparten esquinas SOLO si sus pixeles se tocan de
 *    verdad. Asi un brazo separado del torso por un hueco transparente queda
 *    con su propia malla aunque este a pocos pixeles: mover el brazo no
 *    arrastra el torso. Es la "conectividad" que pide ARAP.
 * 5. Cada cuadro se parte en dos triangulos (diagonal alterna).
 *
 * Todo pixel con alfa &gt; 0 queda dentro de algun triangulo: deformar con la
 * malla en reposo devuelve la imagen exacta.
 *
 * Coordenadas: locales a la imagen fuente (0..w, 0..h). El centro del pixel i
 * esta en i + 0.5.
 */
public final class PuppetMesh {
    public final int w, h, spacing, expansion;
    public final int cellsX, cellsY;

    // Vertices
    public int vertCount;
    public float[] rest;          // x, y por vertice (locales)
    public int[] vertComp;        // componente conexa de la malla

    // Triangulos (orientacion positiva en reposo)
    public int triCount;
    public int[] tri;             // 3 indices por triangulo
    public int[] triPiece;        // parte (cuadro) de cada triangulo

    // Partes (un cuadro por componente de mascara dentro de una celda)
    public int pieceCount;
    public int[] pieceCell;       // celda de la parte
    public byte[] pieceLabel;     // etiqueta local dentro de la ventana de la celda
    public int[] pieceVerts;      // 4 por parte: tl, tr, bl, br

    /** Por celda: null si tiene 0 o 1 parte; si no, etiquetas de su ventana (s+2)^2. */
    public byte[][] cellLabels;
    public int[] cellFirstPiece, cellPieceCount;

    public int compCount;
    /** Pixeles de mascara (para estadisticas). */
    public long maskPixels;

    private PuppetMesh(int w, int h, int spacing, int expansion) {
        this.w = w;
        this.h = h;
        this.spacing = spacing;
        this.expansion = expansion;
        this.cellsX = (w + spacing - 1) / spacing;
        this.cellsY = (h + spacing - 1) / spacing;
    }

    /** Lado de celda recomendado para la densidad 0 (menos), 1 (normal), 2 (mas). */
    public static int spacingFor(int silhouetteW, int silhouetteH, int density) {
        int side = Math.max(silhouetteW, silhouetteH);
        int div = density <= 0 ? 25 : density == 1 ? 40 : 60;
        return Math.max(6, Math.min(240, Math.round(side / (float) div)));
    }

    /** Ventana de una celda: [cx*s-1, cx*s+s] (s+2 pixeles por lado). */
    public int windowSize() {
        return spacing + 2;
    }

    // ------------------------------------------------------------------
    // Construccion
    // ------------------------------------------------------------------

    public static PuppetMesh build(PixelTiles src, int spacing, int expansion) {
        PuppetMesh m = new PuppetMesh(src.width, src.height, Math.max(4, spacing), Math.max(0, Math.min(40, expansion)));
        m.construct(src);
        return m;
    }

    /** Buffers reutilizados por celda. */
    private int[] alphaBuf, distBuf, stack;
    private boolean[] maskBuf;
    private byte[] labBuf;
    private int padN;

    /** Calcula la mascara dilatada de la ventana de (cx,cy) en maskBuf (W*W). */
    private void windowMask(PixelTiles src, int cx, int cy) {
        final int s = spacing, W = s + 2, e = expansion;
        final int P = W + 2 * e;
        final int ox = cx * s - 1 - e, oy = cy * s - 1 - e;
        if (alphaBuf == null || alphaBuf.length < P * P) {
            alphaBuf = new int[P * P];
            distBuf = new int[P * P];
        }
        if (maskBuf == null || maskBuf.length < W * W) maskBuf = new boolean[W * W];
        boolean any = false;
        for (int y = 0; y < P; y++) {
            int gy = oy + y;
            for (int x = 0; x < P; x++) {
                int a = src.alpha(ox + x, gy);
                alphaBuf[y * P + x] = a;
                if (a != 0) any = true;
            }
        }
        if (!any) {
            Arrays.fill(maskBuf, 0, W * W, false);
            return;
        }
        if (e == 0) {
            for (int y = 0; y < W; y++)
                for (int x = 0; x < W; x++) maskBuf[y * W + x] = alphaBuf[(y) * P + x] != 0;
            return;
        }
        // Distancia chamfer 3-4 a la mascara (dilatacion casi circular).
        final int INF = 1 << 28;
        for (int i = 0; i < P * P; i++) distBuf[i] = alphaBuf[i] != 0 ? 0 : INF;
        for (int y = 0; y < P; y++) {
            for (int x = 0; x < P; x++) {
                int i = y * P + x, d = distBuf[i];
                if (d == 0) continue;
                if (x > 0) d = Math.min(d, distBuf[i - 1] + 3);
                if (y > 0) {
                    d = Math.min(d, distBuf[i - P] + 3);
                    if (x > 0) d = Math.min(d, distBuf[i - P - 1] + 4);
                    if (x < P - 1) d = Math.min(d, distBuf[i - P + 1] + 4);
                }
                distBuf[i] = d;
            }
        }
        for (int y = P - 1; y >= 0; y--) {
            for (int x = P - 1; x >= 0; x--) {
                int i = y * P + x, d = distBuf[i];
                if (d == 0) continue;
                if (x < P - 1) d = Math.min(d, distBuf[i + 1] + 3);
                if (y < P - 1) {
                    d = Math.min(d, distBuf[i + P] + 3);
                    if (x < P - 1) d = Math.min(d, distBuf[i + P + 1] + 4);
                    if (x > 0) d = Math.min(d, distBuf[i + P - 1] + 4);
                }
                distBuf[i] = d;
            }
        }
        int lim = 3 * e;
        for (int y = 0; y < W; y++) {
            int gy = cy * s - 1 + y;
            for (int x = 0; x < W; x++) {
                int gx = cx * s - 1 + x;
                boolean inside = gx >= 0 && gy >= 0 && gx < w && gy < h;
                maskBuf[y * W + x] = inside && distBuf[(y + e) * P + (x + e)] <= lim;
            }
        }
    }

    /** Etiqueta componentes (8 vecinos) de maskBuf en labBuf. Devuelve cuantas. */
    private int labelWindow() {
        final int W = spacing + 2;
        if (labBuf == null || labBuf.length < W * W) labBuf = new byte[W * W];
        if (stack == null || stack.length < W * W) stack = new int[W * W];
        Arrays.fill(labBuf, 0, W * W, (byte) 0);
        int n = 0;
        for (int i = 0; i < W * W; i++) {
            if (!maskBuf[i] || labBuf[i] != 0) continue;
            int lab = n < 254 ? ++n : 254;
            int sp = 0;
            stack[sp++] = i;
            labBuf[i] = (byte) lab;
            while (sp > 0) {
                int p = stack[--sp];
                int px = p % W, py = p / W;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = py + dy;
                    if (yy < 0 || yy >= W) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = px + dx;
                        if (xx < 0 || xx >= W || (dx == 0 && dy == 0)) continue;
                        int q = yy * W + xx;
                        if (maskBuf[q] && labBuf[q] == 0) {
                            labBuf[q] = (byte) lab;
                            stack[sp++] = q;
                        }
                    }
                }
            }
        }
        return n;
    }

    private void construct(PixelTiles src) {
        final int s = spacing, W = s + 2;
        final int cells = cellsX * cellsY;
        cellLabels = new byte[cells][];
        cellFirstPiece = new int[cells];
        cellPieceCount = new int[cells];
        int[] pCell = new int[1024];
        byte[] pLab = new byte[1024];
        int np = 0;
        boolean[] hasCore = new boolean[256];

        // Paso 1: partes de cada celda.
        for (int cy = 0; cy < cellsY; cy++) {
            for (int cx = 0; cx < cellsX; cx++) {
                int c = cy * cellsX + cx;
                cellFirstPiece[c] = np;
                windowMask(src, cx, cy);
                int nl = labelWindow();
                if (nl == 0) continue;
                Arrays.fill(hasCore, false);
                int count = 0;
                for (int y = 1; y <= s; y++) {
                    for (int x = 1; x <= s; x++) {
                        int l = labBuf[y * W + x] & 255;
                        if (l != 0) {
                            maskPixels++;
                            if (!hasCore[l]) { hasCore[l] = true; count++; }
                        }
                    }
                }
                if (count == 0) continue;
                for (int l = 1; l <= nl; l++) {
                    if (!hasCore[l]) continue;
                    if (np == pCell.length) {
                        pCell = Arrays.copyOf(pCell, np * 2);
                        pLab = Arrays.copyOf(pLab, np * 2);
                    }
                    pCell[np] = c;
                    pLab[np] = (byte) l;
                    np++;
                }
                cellPieceCount[c] = count;
                if (count > 1) cellLabels[c] = Arrays.copyOf(labBuf, W * W);
            }
        }
        pieceCount = np;
        pieceCell = Arrays.copyOf(pCell, np);
        pieceLabel = Arrays.copyOf(pLab, np);

        // Paso 2: unir esquinas de partes vecinas que se tocan.
        int[] parent = new int[np * 4];
        for (int i = 0; i < parent.length; i++) parent[i] = i;
        for (int c = 0; c < cells; c++) {
            if (cellPieceCount[c] == 0) continue;
            int cx = c % cellsX, cy = c / cellsX;
            windowMask(src, cx, cy);
            labelWindow();
            int first = cellFirstPiece[c], cnt = cellPieceCount[c];
            for (int y = 0; y < W; y++) {
                for (int x = 0; x < W; x++) {
                    boolean ring = x == 0 || y == 0 || x == W - 1 || y == W - 1;
                    if (!ring) continue;
                    int l = labBuf[y * W + x] & 255;
                    if (l == 0) continue;
                    int mine = -1;
                    for (int k = 0; k < cnt; k++) if ((pieceLabel[first + k] & 255) == l) { mine = first + k; break; }
                    if (mine < 0) continue; // componente de la orilla que no es de esta celda
                    int gx = cx * s - 1 + x, gy = cy * s - 1 + y;
                    int nx = Math.floorDiv(gx, s), ny = Math.floorDiv(gy, s);
                    if (nx < 0 || ny < 0 || nx >= cellsX || ny >= cellsY) continue;
                    int other = pieceAtPixel(ny * cellsX + nx, gx, gy);
                    if (other < 0) continue;
                    int dx = nx - cx, dy = ny - cy;
                    for (int k = 0; k < 4; k++) {
                        int kx = k & 1, ky = k >> 1;
                        int ox = kx - dx, oy = ky - dy;
                        if (ox < 0 || ox > 1 || oy < 0 || oy > 1) continue;
                        union(parent, mine * 4 + k, other * 4 + oy * 2 + ox);
                    }
                }
            }
        }

        // Vertices: una raiz por grupo de esquinas unidas.
        int[] rootId = new int[np * 4];
        Arrays.fill(rootId, -1);
        int nv = 0;
        long[] order = new long[np * 4];
        int[] roots = new int[np * 4];
        for (int i = 0; i < np * 4; i++) {
            int r = find(parent, i);
            if (rootId[r] == -1) { rootId[r] = -2; roots[nv++] = r; }
        }
        // Orden por (y, x): matrices con banda estrecha.
        for (int i = 0; i < nv; i++) {
            int r = roots[i];
            int piece = r >> 2, k = r & 3;
            int c = pieceCell[piece];
            long vx = (c % cellsX) + (k & 1), vy = (c / cellsX) + (k >> 1);
            order[i] = ((vy * (cellsX + 2) + vx) << 24) | i;
        }
        Arrays.sort(order, 0, nv);
        vertCount = nv;
        rest = new float[nv * 2];
        for (int o = 0; o < nv; o++) {
            int i = (int) (order[o] & 0xFFFFFF);
            int r = roots[i];
            rootId[r] = o;
            int piece = r >> 2, k = r & 3;
            int c = pieceCell[piece];
            rest[o * 2] = ((c % cellsX) + (k & 1)) * s;
            rest[o * 2 + 1] = ((c / cellsX) + (k >> 1)) * s;
        }
        pieceVerts = new int[np * 4];
        for (int p = 0; p < np; p++)
            for (int k = 0; k < 4; k++) pieceVerts[p * 4 + k] = rootId[find(parent, p * 4 + k)];

        triCount = np * 2;
        tri = new int[triCount * 3];
        triPiece = new int[triCount];
        for (int p = 0; p < np; p++) {
            int c = pieceCell[p];
            int v00 = pieceVerts[p * 4], v10 = pieceVerts[p * 4 + 1], v01 = pieceVerts[p * 4 + 2], v11 = pieceVerts[p * 4 + 3];
            int t = p * 2;
            if ((((c % cellsX) + (c / cellsX)) & 1) == 0) {
                setTri(t, v00, v10, v11);
                setTri(t + 1, v00, v11, v01);
            } else {
                setTri(t, v00, v10, v01);
                setTri(t + 1, v10, v11, v01);
            }
            triPiece[t] = triPiece[t + 1] = p;
        }

        // Componentes conexas de la malla.
        int[] vp = new int[nv];
        for (int i = 0; i < nv; i++) vp[i] = i;
        for (int t = 0; t < triCount; t++) {
            union(vp, tri[t * 3], tri[t * 3 + 1]);
            union(vp, tri[t * 3], tri[t * 3 + 2]);
        }
        vertComp = new int[nv];
        int[] cid = new int[nv];
        Arrays.fill(cid, -1);
        int nc = 0;
        for (int i = 0; i < nv; i++) {
            int r = find(vp, i);
            if (cid[r] < 0) cid[r] = nc++;
            vertComp[i] = cid[r];
        }
        compCount = nc;
        alphaBuf = distBuf = stack = null;
        maskBuf = null;
        labBuf = null;
    }

    private void setTri(int t, int a, int b, int c) {
        tri[t * 3] = a;
        tri[t * 3 + 1] = b;
        tri[t * 3 + 2] = c;
    }

    private static int find(int[] p, int i) {
        while (p[i] != i) {
            p[i] = p[p[i]];
            i = p[i];
        }
        return i;
    }

    private static void union(int[] p, int a, int b) {
        a = find(p, a);
        b = find(p, b);
        if (a != b) {
            if (a < b) p[b] = a; else p[a] = b;
        }
    }

    // ------------------------------------------------------------------
    // Consultas
    // ------------------------------------------------------------------

    /** Etiqueta local del pixel global (gx,gy) en la ventana de la celda c (0 = fuera de mascara o desconocido). */
    public int labelAt(int c, int gx, int gy) {
        byte[] lab = cellLabels[c];
        if (lab == null) return -1;
        int W = spacing + 2;
        int x = gx - (c % cellsX) * spacing + 1, y = gy - (c / cellsX) * spacing + 1;
        if (x < 0 || y < 0 || x >= W || y >= W) return -1;
        return lab[y * W + x] & 255;
    }

    /**
     * Parte de la celda c a la que pertenece el pixel (debe estar en el nucleo
     * de la celda). -1 si la celda no tiene partes o el pixel no es mascara
     * (solo se sabe en celdas con varias partes).
     */
    public int pieceAtPixel(int c, int gx, int gy) {
        int cnt = cellPieceCount[c];
        if (cnt == 0) return -1;
        int first = cellFirstPiece[c];
        if (cnt == 1) return first;
        int l = labelAt(c, gx, gy);
        if (l <= 0) return -1;
        for (int k = 0; k < cnt; k++) if ((pieceLabel[first + k] & 255) == l) return first + k;
        return -1;
    }

    /**
     * Parte para poner un punto en (x,y) locales: la del pixel, o la mas cercana
     * de la misma celda o de las vecinas (hasta {@code reach} pixeles).
     */
    public int pieceForPoint(float x, float y, float reach) {
        int gx = (int) Math.floor(x), gy = (int) Math.floor(y);
        int cx = Math.floorDiv(gx, spacing), cy = Math.floorDiv(gy, spacing);
        if (cx >= 0 && cy >= 0 && cx < cellsX && cy < cellsY) {
            int c = cy * cellsX + cx;
            int p = pieceAtPixel(c, gx, gy);
            if (p >= 0) return p;
        }
        // Busca la parte mas cercana por el centro de sus cuadros.
        int best = -1;
        float bd = reach * reach;
        int r = (int) Math.ceil(reach / spacing) + 1;
        for (int yy = cy - r; yy <= cy + r; yy++) {
            if (yy < 0 || yy >= cellsY) continue;
            for (int xx = cx - r; xx <= cx + r; xx++) {
                if (xx < 0 || xx >= cellsX) continue;
                int c = yy * cellsX + xx;
                int cnt = cellPieceCount[c];
                if (cnt == 0) continue;
                // Distancia al cuadro de la celda (0 si el punto esta dentro).
                float qx = Math.max(xx * spacing, Math.min((xx + 1) * spacing, x));
                float qy = Math.max(yy * spacing, Math.min((yy + 1) * spacing, y));
                float d = (qx - x) * (qx - x) + (qy - y) * (qy - y);
                if (d <= bd) {
                    int p = cellFirstPiece[c];
                    if (cnt > 1) {
                        // celda con varias partes: la del pixel de mascara mas cercano
                        p = nearestLabeledPiece(c, x, y);
                        if (p < 0) continue;
                    }
                    bd = d;
                    best = p;
                }
            }
        }
        return best;
    }

    private int nearestLabeledPiece(int c, float x, float y) {
        byte[] lab = cellLabels[c];
        int W = spacing + 2, ox = (c % cellsX) * spacing - 1, oy = (c / cellsX) * spacing - 1;
        int first = cellFirstPiece[c], cnt = cellPieceCount[c];
        float bd = Float.MAX_VALUE;
        int best = -1;
        for (int j = 1; j <= spacing; j++) {
            for (int i = 1; i <= spacing; i++) {
                int l = lab[j * W + i] & 255;
                if (l == 0) continue;
                float dx = ox + i + .5f - x, dy = oy + j + .5f - y, d = dx * dx + dy * dy;
                if (d < bd) {
                    for (int k = 0; k < cnt; k++)
                        if ((pieceLabel[first + k] & 255) == l) { bd = d; best = first + k; break; }
                }
            }
        }
        return best;
    }

    /**
     * Triangulo de la parte p que contiene (x,y) en reposo y sus baricentricas
     * en out[0..2]. Siempre devuelve uno de los dos (recorta al mas cercano).
     */
    public int locateInPiece(int p, float x, float y, float[] out) {
        int bestT = -1;
        float bestMin = -Float.MAX_VALUE;
        float[] tmp = new float[3];
        for (int t = p * 2; t <= p * 2 + 1; t++) {
            bary(rest, t, x, y, tmp);
            float mn = Math.min(tmp[0], Math.min(tmp[1], tmp[2]));
            if (mn > bestMin) {
                bestMin = mn;
                bestT = t;
                out[0] = tmp[0]; out[1] = tmp[1]; out[2] = tmp[2];
            }
        }
        if (bestMin < 0) {
            // Fuera del cuadro: se recorta a las baricentricas validas.
            float a = Math.max(0, out[0]), b = Math.max(0, out[1]), c = Math.max(0, out[2]);
            float sum = a + b + c;
            if (sum <= 0) { a = b = c = 1f / 3f; sum = 1; }
            out[0] = a / sum; out[1] = b / sum; out[2] = c / sum;
        }
        return bestT;
    }

    /** Baricentricas de (x,y) en el triangulo t usando las posiciones pos. */
    public void bary(float[] pos, int t, float x, float y, float[] out) {
        int a = tri[t * 3], b = tri[t * 3 + 1], c = tri[t * 3 + 2];
        double ax = pos[a * 2], ay = pos[a * 2 + 1];
        double bx = pos[b * 2] - ax, by = pos[b * 2 + 1] - ay;
        double cx = pos[c * 2] - ax, cy = pos[c * 2 + 1] - ay;
        double px = x - ax, py = y - ay;
        double den = bx * cy - by * cx;
        if (Math.abs(den) < 1e-12) { out[0] = 1; out[1] = out[2] = 0; return; }
        double l1 = (px * cy - py * cx) / den;
        double l2 = (bx * py - by * px) / den;
        out[1] = (float) l1;
        out[2] = (float) l2;
        out[0] = (float) (1 - l1 - l2);
    }

    /** Triangulo (en la posicion deformada pos) que contiene el punto, o -1. */
    public int locateDeformed(float[] pos, float x, float y, float[] outBary) {
        float[] tmp = new float[3];
        int best = -1;
        float bestMin = -0.02f;
        for (int t = 0; t < triCount; t++) {
            int a = tri[t * 3], b = tri[t * 3 + 1], c = tri[t * 3 + 2];
            float minX = Math.min(pos[a * 2], Math.min(pos[b * 2], pos[c * 2]));
            float maxX = Math.max(pos[a * 2], Math.max(pos[b * 2], pos[c * 2]));
            if (x < minX - 1 || x > maxX + 1) continue;
            float minY = Math.min(pos[a * 2 + 1], Math.min(pos[b * 2 + 1], pos[c * 2 + 1]));
            float maxY = Math.max(pos[a * 2 + 1], Math.max(pos[b * 2 + 1], pos[c * 2 + 1]));
            if (y < minY - 1 || y > maxY + 1) continue;
            bary(pos, t, x, y, tmp);
            float mn = Math.min(tmp[0], Math.min(tmp[1], tmp[2]));
            if (mn > bestMin) {
                bestMin = mn;
                best = t;
                outBary[0] = tmp[0]; outBary[1] = tmp[1]; outBary[2] = tmp[2];
                if (mn >= 0) break;
            }
        }
        return best;
    }

    /** Numero de triangulos invertidos o aplastados en las posiciones pos. */
    public int invertedCount(float[] pos) {
        int n = 0;
        for (int t = 0; t < triCount; t++) if (signedArea(pos, t) <= 1e-4f) n++;
        return n;
    }

    public float signedArea(float[] pos, int t) {
        int a = tri[t * 3], b = tri[t * 3 + 1], c = tri[t * 3 + 2];
        float bx = pos[b * 2] - pos[a * 2], by = pos[b * 2 + 1] - pos[a * 2 + 1];
        float cx = pos[c * 2] - pos[a * 2], cy = pos[c * 2 + 1] - pos[a * 2 + 1];
        return .5f * (bx * cy - by * cx);
    }

    /** Bytes aproximados que ocupa la malla. */
    public long approxBytes() {
        long b = (long) rest.length * 4 + (long) tri.length * 4 + (long) triPiece.length * 4 + (long) pieceVerts.length * 4;
        for (byte[] l : cellLabels) if (l != null) b += l.length;
        return b;
    }
}
