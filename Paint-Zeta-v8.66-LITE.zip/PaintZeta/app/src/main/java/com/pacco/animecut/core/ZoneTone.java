package com.pacco.animecut.core;

import java.util.ArrayList;
import java.util.List;

/**
 * v8.40 "Color por zonas" (Java puro, sin Android: se prueba en PC con las imagenes reales).
 *
 * Idea (la de los coloristas profesionales): en una zona del dibujo B/N (pelo, piel, saco...)
 * cada GRIS del original se cambia por un color de un MAPA DE DEGRADADO de la zona:
 *     tinta -> SOMBRA -> BASE -> LUZ -> blanco
 * La posicion de cada tono sale de los grises de la propia zona (percentiles 10, 50 y 90): lo
 * oscuro de esa zona es sombra, lo tipico es base y lo claro es luz. Asi se conservan volumen,
 * pliegues, mechones y lineas, y la sombra tiene SU color (no un gris). La mezcla es en OKLab
 * (los tonos intermedios no se ensucian). Todo se resume en una tabla de 256 colores (rapido).
 *
 * Acabados: Suave light novel, Anime 2 tonos (cel, umbral de Otsu), Pintado (sombra mas
 * saturada y fria, luz tibia, luz ambiental suave), Multiplicar (el de siempre, para comparar) y
 * Mejorar color (imagenes ya a color: se acercan sus tonos a la referencia).
 *
 * Trama de manga: si la zona tiene puntitos, los tonos se calculan con una version SUAVIZADA
 * (solo para medir la luz) y despues se devuelve el detalle de la trama encima. Nunca se
 * desenfoca la obra: el original no se toca.
 *
 * Zonas sin grises (manga de solo lineas): sombra de 2 tonos segun una direccion de luz.
 */
public final class ZoneTone {
    private ZoneTone() { }

    public static final int SOFT = 0, CEL = 1, PAINTED = 2, MULTIPLY = 3, IMPROVE = 4;
    public static final String[] FINISH_NAMES = {"Suave light novel", "Anime 2 tonos", "Pintado", "Multiplicar", "Mejorar color"};
    public static final String[] FINISH_SHORT = {"Suave", "2 tonos", "Pintado", "Multiplicar", "Mejorar"};
    /** De donde VIENE la luz: 0 arriba, 1 arriba-derecha, 2 derecha ... 7 arriba-izquierda. */
    public static final String[] DIR_NAMES = {"Arriba", "Arriba-der.", "Derecha", "Abajo-der.", "Abajo", "Abajo-izq.", "Izquierda", "Arriba-izq."};
    private static final int[] DX = {0, 1, 1, 1, 0, -1, -1, -1}, DY = {-1, -1, 0, 1, 1, 1, 0, -1};

    // ------------------------------------------------------------------ estilo y zona
    public static final class Style {
        public int shadow = 0xFFB0647A, base = 0xFFE9A9B8, light = 0xFFFFE3EA;
        public int finish = SOFT;
        /** 0..100: cuanto color (0 = el gris original). */
        public int intensity = 100;
        /** Trama: true = se conserva su textura encima del color (de fabrica). */
        public boolean keepTexture = true;
        /** Tenir tambien lo negro (pelo negro, lineas) con la sombra. De fabrica no. */
        public boolean tintBlack = false;
        /** Sombra por direccion de luz: 0 automatica (solo zonas sin grises), 1 siempre, 2 nunca. */
        public int lightShade = 0;
        public int lightDir = 7;
        /** Los blancos (brillo de ojos y pelo) siguen blancos. */
        public boolean keepWhites = true;
        /**
         * v8.45 "limpio" (Colorear facil): el sombreado sale de los grises SUAVIZADOS (sin el ruido
         * del JPEG ni la trama) y con zona muerta: sin puntitos ni manchas. Las lineas se conservan.
         */
        public boolean clean = false;
        /** v8.47 (limpio): fuerza de sombra y luz 0..100 (50 = normal). */
        public int power = 50;
        /** v8.47 (limpio): sombra automatica (lado contrario a la luz + sombra que echan otras partes: pelo sobre la cara, menton). */
        public boolean autoShade = false;
        /** v8.47 (limpio): brillo de pelo (anillo de luz) en esta zona. */
        public boolean shine = false;
        /** v8.60: la zona lleva el ACABADO (ver Acabado). sol en milesimas (0..1000 = 0..1) y fuerza. */
        public boolean pro = false;
        public int sunX = 150, sunY = 50, strength = 60;
        public boolean colorLines = true;
        /** v8.61: tipo de luz del acabado (Acabado.LIGHT_NAMES). */
        public int lightType = 0;
        /** v8.63: estilo Anime (si no, Manhwa), puntas del pelo, material brillante y estampado. */
        public boolean anime = false;
        public int hairTip = 0, material = 0, pattern = 0, patColor = 0;
        /** v8.63: luces extra del acabado (lugar x1000 y tipo). */
        public int extraN = 0;
        public int[] exX = new int[2], exY = new int[2], exType = new int[2];

        public Style copy() {
            Style s = new Style();
            s.shadow = shadow; s.base = base; s.light = light; s.finish = finish; s.intensity = intensity;
            s.keepTexture = keepTexture; s.tintBlack = tintBlack; s.lightShade = lightShade; s.lightDir = lightDir;
            s.keepWhites = keepWhites;
            s.clean = clean;
            s.power = power; s.autoShade = autoShade; s.shine = shine;
            s.pro = pro; s.sunX = sunX; s.sunY = sunY; s.strength = strength; s.colorLines = colorLines; s.lightType = lightType;
            s.anime = anime; s.hairTip = hairTip; s.material = material; s.pattern = pattern; s.patColor = patColor;
            s.extraN = extraN; s.exX = exX.clone(); s.exY = exY.clone(); s.exType = exType.clone();
            return s;
        }

        public int[] pack() {
            return new int[]{shadow, base, light, finish, intensity, keepTexture ? 1 : 0, tintBlack ? 1 : 0,
                    lightShade, lightDir, keepWhites ? 1 : 0, clean ? 1 : 0, power, autoShade ? 1 : 0, shine ? 1 : 0,
                    pro ? 1 : 0, sunX, sunY, strength, colorLines ? 1 : 0, lightType,
                    anime ? 1 : 0, hairTip, material, pattern, patColor,
                    extraN, exX[0], exY[0], exType[0], exX[1], exY[1], exType[1]};
        }

        public static Style unpack(int[] v) {
            Style s = new Style();
            if (v == null || v.length < 10) return s;
            s.shadow = v[0]; s.base = v[1]; s.light = v[2];
            s.finish = clamp(v[3], 0, IMPROVE); s.intensity = clamp(v[4], 0, 100);
            s.keepTexture = v[5] != 0; s.tintBlack = v[6] != 0; s.lightShade = clamp(v[7], 0, 2);
            s.lightDir = clamp(v[8], 0, 7); s.keepWhites = v[9] != 0;
            s.clean = v.length > 10 && v[10] != 0;
            s.power = v.length > 11 ? clamp(v[11], 0, 100) : 50;
            s.autoShade = v.length > 12 && v[12] != 0;
            s.shine = v.length > 13 && v[13] != 0;
            // v8.60: acabado (las obras viejas no lo traen: queda apagado)
            s.pro = v.length > 14 && v[14] != 0;
            if (v.length > 17) { s.sunX = clamp(v[15], -1000, 2000); s.sunY = clamp(v[16], -1000, 2000); s.strength = clamp(v[17], 0, 100); }
            s.colorLines = v.length <= 18 || v[18] != 0;
            s.lightType = v.length > 19 ? clamp(v[19], 0, 5) : 0;
            // v8.63 (obras viejas: todo apagado)
            s.anime = v.length > 20 && v[20] != 0;
            s.hairTip = v.length > 21 ? v[21] : 0;
            s.material = v.length > 22 ? clamp(v[22], 0, 1) : 0;
            s.pattern = v.length > 23 ? clamp(v[23], 0, 5) : 0;
            s.patColor = v.length > 24 ? v[24] : 0;
            if (v.length > 31) {
                s.extraN = clamp(v[25], 0, 2);
                for (int j = 0; j < 2; j++) {
                    s.exX[j] = clamp(v[26 + j * 3], -1000, 2000); s.exY[j] = clamp(v[27 + j * 3], -1000, 2000);
                    s.exType[j] = clamp(v[28 + j * 3], 0, 5);
                }
            }
            return s;
        }
    }

    /** Una zona aplicada: recuadro (x,y,w,h) + mascara 0..255 + su estilo. Inmutable de hecho. */
    public static final class Zone {
        public final int x, y, w, h;
        public final byte[] m;
        public final Style s;

        public Zone(int x, int y, int w, int h, byte[] m, Style s) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.m = m; this.s = s;
        }

        public Zone withStyle(Style ns) { return new Zone(x, y, w, h, m, ns); }

        public int area() {
            int n = 0;
            for (byte b : m) if ((b & 0xFF) >= 128) n++;
            return n;
        }

        public boolean has(int px, int py) {
            px -= x; py -= y;
            return px >= 0 && py >= 0 && px < w && py < h && (m[py * w + px] & 0xFF) >= 128;
        }
    }

    /** Recorta una mascara del lienzo (w*h) a su recuadro. null si esta vacia. */
    public static Zone fromMask(byte[] full, int W, int H, Style s) {
        int x0 = W, y0 = H, x1 = -1, y1 = -1;
        for (int y = 0; y < H; y++) {
            int o = y * W;
            for (int x = 0; x < W; x++) {
                if (full[o + x] == 0) continue;
                if (x < x0) x0 = x;
                if (x > x1) x1 = x;
                if (y < y0) y0 = y;
                if (y > y1) y1 = y;
            }
        }
        if (x1 < 0) return null;
        int w = x1 - x0 + 1, h = y1 - y0 + 1;
        byte[] m = new byte[w * h];
        for (int y = 0; y < h; y++) System.arraycopy(full, (y + y0) * W + x0, m, y * w, w);
        return new Zone(x0, y0, w, h, m, s);
    }

    // ------------------------------------------------------------------ lectura del original
    /** Brillo 0..255 del pixel sobre papel blanco (lo transparente cuenta como papel). */
    public static int lum(int c) {
        int a = c >>> 24;
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        if (a < 255) {
            r = (r * a + 255 * (255 - a)) / 255;
            g = (g * a + 255 * (255 - a)) / 255;
            b = (b * a + 255 * (255 - a)) / 255;
        }
        return (r * 77 + g * 151 + b * 28) >> 8;
    }

    private static int sat(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        return Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
    }

    /**
     * Borde suave de 1 px para la mascara de una zona (0/255 -> 0..255): sin escalones al hacer
     * zoom donde la zona toca una parte sin colorear. El interior sigue en 255.
     */
    public static void feather(byte[] full, int W, int H) {
        byte[] src = full.clone();
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                int c = src[i] & 0xFF;
                boolean edge = false;
                int sum = 0, n = 0;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) {
                        int sx = x + dx, sy = y + dy;
                        if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
                        int v = src[sy * W + sx] & 0xFF;
                        if (v != c) edge = true;
                        sum += v; n++;
                    }
                if (!edge) continue;
                int avg = sum / n;
                // dentro baja poco (minimo 200), fuera sube poco (maximo 110): suave, sin halo
                full[i] = (byte) (c > 0 ? Math.max(200, Math.max(avg, c == 255 ? 200 : c)) : Math.min(110, avg));
            }
    }

    // ------------------------------------------------------------------ estadistica de la zona
    public static final class Stats {
        public int n, p02, p10, p25, p50, p75, p90, p98;
        /** Energia de alta frecuencia (0..255): alta = trama de puntitos. */
        public float tone;
        public boolean screentone, colored, flat;
        /** Brillo del papel (percentil 98 del original sin suavizar). */
        public int paper = 255;
        /** Brillo SUAVIZADO por pixel de la zona (solo con trama), en el recuadro. */
        public short[] smooth;
    }

    public static final float TONE_THR = 11f;

    public static Stats stats(int[] src, int W, Zone z) {
        Stats st = new Stats();
        int[] hist = new int[256];
        long satSum = 0, hf = 0;
        int hfN = 0;
        int zw = z.w, zh = z.h;
        for (int y = 0; y < zh; y++) {
            for (int x = 0; x < zw; x++) {
                if ((z.m[y * zw + x] & 0xFF) < 128) continue;
                int c = src[(y + z.y) * W + x + z.x];
                int v = lum(c);
                hist[v]++;
                st.n++;
                satSum += sat(c);
                // energia: diferencia con el promedio de los 4 vecinos de la misma zona
                if (x > 0 && y > 0 && x < zw - 1 && y < zh - 1
                        && (z.m[y * zw + x - 1] & 0xFF) >= 128 && (z.m[y * zw + x + 1] & 0xFF) >= 128
                        && (z.m[(y - 1) * zw + x] & 0xFF) >= 128 && (z.m[(y + 1) * zw + x] & 0xFF) >= 128) {
                    int i = (y + z.y) * W + x + z.x;
                    int a = lum(src[i - 1]) + lum(src[i + 1]) + lum(src[i - W]) + lum(src[i + W]);
                    hf += Math.abs(v * 4 - a);
                    hfN++;
                }
            }
        }
        if (st.n == 0) return st;
        st.tone = hfN == 0 ? 0f : hf / (4f * hfN);
        st.colored = satSum / st.n > 28;
        st.screentone = !st.colored && st.tone > TONE_THR;
        st.paper = Math.max(1, pct(hist, st.n, 0.98f));
        if (st.screentone) {
            st.smooth = smoothLum(src, W, z);
            hist = new int[256];
            for (int i = 0; i < zw * zh; i++) if ((z.m[i] & 0xFF) >= 128) hist[st.smooth[i]]++;
        }
        st.p02 = pct(hist, st.n, 0.02f);
        st.p10 = pct(hist, st.n, 0.10f);
        st.p25 = pct(hist, st.n, 0.25f);
        st.p50 = pct(hist, st.n, 0.50f);
        st.p75 = pct(hist, st.n, 0.75f);
        st.p90 = pct(hist, st.n, 0.90f);
        st.p98 = pct(hist, st.n, 0.98f);
        // sin grises utiles: la mitad central de la zona casi del mismo gris (las lineas y su
        // antialias, que quedan en los extremos, no cuentan)
        st.flat = st.p75 - st.p25 < 10;
        return st;
    }

    private static int pct(int[] hist, int n, float q) {
        long want = Math.max(1, Math.round(n * q));
        long acc = 0;
        for (int v = 0; v < 256; v++) {
            acc += hist[v];
            if (acc >= want) return v;
        }
        return 255;
    }

    /**
     * Brillo suavizado SOLO dentro de la zona (promedio de una caja, dos pasadas ~ Gauss), para
     * medir la luz debajo de la trama. Las lineas (fuera de la zona) no se mezclan.
     */
    static short[] smoothLum(int[] src, int W, Zone z) {
        int zw = z.w, zh = z.h, n = zw * zh;
        float[] v = new float[n], wt = new float[n];
        for (int y = 0; y < zh; y++)
            for (int x = 0; x < zw; x++) {
                int i = y * zw + x;
                if ((z.m[i] & 0xFF) < 128) continue;
                v[i] = lum(src[(y + z.y) * W + x + z.x]);
                wt[i] = 1f;
            }
        int r = 3;
        for (int pass = 0; pass < 2; pass++) {
            box(v, zw, zh, r);
            box(wt, zw, zh, r);
            for (int i = 0; i < n; i++) {
                if ((z.m[i] & 0xFF) < 128) { v[i] = 0; wt[i] = 0; continue; }
                v[i] = wt[i] > 1e-4f ? v[i] / wt[i] : 0;
                wt[i] = 1f;
            }
        }
        short[] out = new short[n];
        for (int i = 0; i < n; i++) out[i] = (short) Math.max(0, Math.min(255, Math.round(v[i])));
        return out;
    }

    /** Promedio de caja (2r+1)^2 separable, en el lugar. */
    static void box(float[] a, int w, int h, int r) {
        float[] row = new float[Math.max(w, h)];
        float inv = 1f / (2 * r + 1);
        for (int y = 0; y < h; y++) {
            float s = 0;
            int o = y * w;
            for (int x = -r; x <= r; x++) s += a[o + clamp(x, 0, w - 1)];
            for (int x = 0; x < w; x++) {
                row[x] = s * inv;
                s += a[o + clamp(x + r + 1, 0, w - 1)] - a[o + clamp(x - r, 0, w - 1)];
            }
            System.arraycopy(row, 0, a, o, w);
        }
        for (int x = 0; x < w; x++) {
            float s = 0;
            for (int y = -r; y <= r; y++) s += a[clamp(y, 0, h - 1) * w + x];
            for (int y = 0; y < h; y++) {
                row[y] = s * inv;
                s += a[clamp(y + r + 1, 0, h - 1) * w + x] - a[clamp(y - r, 0, h - 1) * w + x];
            }
            for (int y = 0; y < h; y++) a[y * w + x] = row[y];
        }
    }

    // ------------------------------------------------------------------ OKLab
    private static final float[] LIN = new float[256];

    static {
        for (int i = 0; i < 256; i++) {
            float c = i / 255f;
            LIN[i] = c <= 0.04045f ? c / 12.92f : (float) Math.pow((c + 0.055f) / 1.055f, 2.4);
        }
    }

    private static int toSrgb(float l) {
        l = Math.max(0f, Math.min(1f, l));
        float c = l <= 0.0031308f ? l * 12.92f : 1.055f * (float) Math.pow(l, 1 / 2.4) - 0.055f;
        return Math.max(0, Math.min(255, Math.round(c * 255f)));
    }

    /** {L, a, b} */
    public static float[] oklab(int c) {
        float r = LIN[(c >> 16) & 255], g = LIN[(c >> 8) & 255], b = LIN[c & 255];
        float l = (float) Math.cbrt(0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b);
        float m = (float) Math.cbrt(0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b);
        float s = (float) Math.cbrt(0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b);
        return new float[]{
                0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s,
                1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s,
                0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s};
    }

    public static int fromOklab(float L, float A, float B) {
        float l = L + 0.3963377774f * A + 0.2158037573f * B;
        float m = L - 0.1055613458f * A - 0.0638541728f * B;
        float s = L - 0.0894841775f * A - 1.2914855480f * B;
        l = l * l * l; m = m * m * m; s = s * s * s;
        float r = 4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s;
        float g = -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s;
        float b = -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s;
        return 0xFF000000 | (toSrgb(r) << 16) | (toSrgb(g) << 8) | toSrgb(b);
    }

    private static float[] mixLab(float[] a, float[] b, float t) {
        return new float[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t};
    }

    /** Cambia L (suma), croma (multiplica) y tono (grados) en OKLab. */
    public static int adjust(int c, float dL, float chroma, float hueDeg) {
        float[] k = oklab(c);
        float C = (float) Math.hypot(k[1], k[2]) * chroma;
        float h = (float) Math.atan2(k[2], k[1]) + (float) Math.toRadians(hueDeg);
        return fromOklab(Math.max(0f, Math.min(1f, k[0] + dL)), C * (float) Math.cos(h), C * (float) Math.sin(h));
    }

    // ------------------------------------------------------------------ trio desde un color
    /**
     * Sin referencia: SOMBRA y LUZ propuestas desde un color base (editables despues). Sombra:
     * mas oscura, un poco mas saturada y girada hacia azul/violeta (en la piel, hacia rojo/rosa);
     * luz: mas clara y un poco tibia.
     */
    public static Style trioFrom(int base, Style into) {
        Style s = into == null ? new Style() : into;
        float[] k = oklab(base);
        float hue = (float) Math.toDegrees(Math.atan2(k[2], k[1]));
        float C = (float) Math.hypot(k[1], k[2]);
        boolean skin = C > 0.02f && C < 0.13f && hue > 25f && hue < 85f && k[0] > 0.6f;
        float shHue;
        if (C < 0.02f) shHue = 0f;                         // gris/blanco: sombra neutra apenas fria
        else if (skin) shHue = -18f;                       // piel: sombra hacia rojo/rosa
        else shHue = towardBlue(hue, 15f);
        float dark = k[0] > 0.85f ? -0.22f : -0.17f;
        s.base = base | 0xFF000000;
        s.shadow = adjust(base, dark, C < 0.02f ? 1f : 1.18f, shHue);
        if (C < 0.02f) {                                    // blanco/gris: sombra gris azulada
            float[] t = oklab(s.shadow);
            s.shadow = fromOklab(t[0], t[1] - 0.005f, t[2] - 0.02f);
        }
        float lift = Math.min(0.10f, (1f - k[0]) * 0.6f + 0.02f);
        s.light = adjust(base, lift, 0.85f, C < 0.02f ? 0f : towardYellow(hue, 7f));
        return s;
    }

    /**
     * v8.44 Colorear facil: trio desde un color con los ajustes que dan buen resultado en B/N:
     * - en la piel lo blanco del dibujo TAMBIEN toma color (antes la cara quedaba blanca);
     * - ropa clara (camisa, falda blanca) lisa: sin las manchitas de la trama;
     * - colores muy oscuros (pelo negro) tinen tambien lo negro.
     */
    public static Style easyStyle(int color, int finish, Style into) {
        Style s = trioFrom(color | 0xFF000000, into);
        s.finish = finish;
        s.intensity = 100;
        s.clean = true;
        int l = lum(color);
        float[] k = oklab(color | 0xFF000000);
        float hue = (float) Math.toDegrees(Math.atan2(k[2], k[1]));
        float C = (float) Math.hypot(k[1], k[2]);
        boolean skin = C > 0.02f && C < 0.13f && hue > 25f && hue < 85f && k[0] > 0.6f;
        // la piel (y lo muy claro) toma color tambien en lo blanco; en ropa de color los blancos
        // son bordes y vivos (el borde blanco del saco) y se quedan blancos
        s.keepWhites = !(skin || l >= 200);
        s.keepTexture = l < 200;
        s.tintBlack = l < 70;
        return s;
    }

    private static float towardBlue(float hue, float amt) {
        // azul-violeta en OKLab ~ -100 grados (260)
        float target = -95f, d = target - hue;
        while (d > 180f) d -= 360f;
        while (d < -180f) d += 360f;
        return Math.signum(d) * Math.min(Math.abs(d), amt);
    }

    private static float towardYellow(float hue, float amt) {
        float target = 95f, d = target - hue;
        while (d > 180f) d -= 360f;
        while (d < -180f) d += 360f;
        return Math.signum(d) * Math.min(Math.abs(d), amt);
    }

    // ------------------------------------------------------------------ tabla de colores
    /**
     * Tabla de 256 colores (opacos) para el brillo 0..255 de esta zona. 'shadowBase' = version
     * en sombra (para la sombra por direccion de luz): la base pasa a sombra.
     */
    public static int[] lut(Style s, Stats st, boolean shadowVersion) {
        int sh = s.shadow, ba = s.base, li = s.light;
        if (s.finish == PAINTED) {
            sh = adjust(sh, -0.02f, 1.3f, -8f);
            li = adjust(li, 0.01f, 1.05f, 6f);
        }
        if (shadowVersion) {
            int d = adjust(sh, -0.10f, 1.05f, -4f);
            li = ba; ba = sh; sh = d;
        }
        int[] out = new int[256];
        if (s.finish == MULTIPLY) {
            for (int v = 0; v < 256; v++) {
                int r = ((ba >> 16) & 255) * v / 255, g = ((ba >> 8) & 255) * v / 255, b = (ba & 255) * v / 255;
                out[v] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
            return out;
        }
        float[] kS = oklab(sh), kB = oklab(ba), kL = oklab(li);
        float[] kInk = s.tintBlack ? new float[]{Math.min(kS[0] * 0.30f, 0.22f), kS[1] * 0.6f, kS[2] * 0.6f}
                : new float[]{0.06f, 0f, 0f};
        float[] kW = s.keepWhites ? mixLab(kL, new float[]{1f, 0f, 0f}, 0.85f) : kL;
        int pS, pB, pL;
        if (st.flat) {
            pB = Math.max(40, st.p50); pS = pB - 70; pL = Math.min(254, pB + 10);
        } else {
            pS = st.p10; pB = st.p50; pL = st.p90;
        }
        // Limite de contraste: si la zona tiene pocos grises (rango chico) y el trio va de muy
        // oscuro a muy claro, estirar todo amplificaria el ruido del JPEG (manchas). La ganancia
        // maxima es 2,4: la zona llega solo hasta media sombra / media luz.
        if (!st.flat) {
            float spanL = Math.abs(kL[0] - kS[0]) * 255f;
            float need = spanL / 2.4f;
            if (pL - pS < need && pL > pS) {
                float sc = need / (pL - pS);
                int nS = Math.round(pB - (pB - pS) * sc), nL = Math.round(pB + (pL - pB) * sc);
                pS = Math.max(4, nS);
                pL = Math.min(254, nL);
            }
        }
        int pI = Math.min(Math.max(8, st.p02 / 2), 70);
        if (pS < pI + 6) pS = pI + 6;
        if (pB < pS + 8) pB = pS + 8;
        if (pL < pB + 8) pL = pB + 8;
        if (pL > 252) pL = 252;
        if (pB > pL - 4) pB = pL - 4;
        if (pS > pB - 4) pS = pB - 4;
        if (s.finish == CEL) {
            int t = otsu(st, pS, pL);
            for (int v = 0; v < 256; v++) {
                float[] k;
                if (v < pI) k = mixLab(kInk, kS, ease(v / (float) pI));
                else if (v < t - 3) k = kS;
                else if (v <= t + 3) k = mixLab(kS, kB, (v - (t - 3)) / 6f);
                else if (s.keepWhites && v >= Math.max(pL, 236)) k = mixLab(kB, kW, Math.min(1f, (v - Math.max(pL, 236)) / 8f));
                else k = kB;
                out[v] = fromOklab(k[0], k[1], k[2]);
            }
            return out;
        }
        for (int v = 0; v < 256; v++) {
            float[] k;
            if (v <= pS) {
                // mas oscuro que la sombra tipica (lineas, mechones, pliegues): la sombra se oscurece
                // EN PROPORCION al gris original (como Multiplicar). Antes iba casi a negro y dejaba
                // manchas oscuras en el pelo y las pestanas.
                float f = (float) Math.pow(Math.max(0f, v) / (float) pS, 0.85);
                k = new float[]{kS[0] * f, kS[1] * f, kS[2] * f};
                if (v < pI) k = mixLab(k, kInk, (1f - v / (float) pI) * 0.6f);
            }
            else if (v <= pB) k = mixLab(kS, kB, ease((v - pS) / (float) (pB - pS)));
            else if (v <= pL) k = mixLab(kB, kL, ease((v - pB) / (float) (pL - pB)));
            else k = mixLab(kL, kW, (v - pL) / (float) Math.max(1, 255 - pL));
            if (s.finish == PAINTED) {
                // luz ambiental discreta: los tonos medios y claros se acercan un poco a la luz
                float amb = 0.10f * Math.max(0f, Math.min(1f, (v - pS) / (float) Math.max(1, pL - pS)));
                k = mixLab(k, kL, amb);
            }
            out[v] = fromOklab(k[0], k[1], k[2]);
        }
        return out;
    }

    private static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    /** Umbral de Otsu entre lo/hi con el histograma aproximado por percentiles. */
    private static int otsu(Stats st, int lo, int hi) {
        // con solo percentiles: el punto medio entre sombra tipica y base tipica
        int t = (st.p10 + st.p50) / 2 + (st.p50 - st.p10) / 6;
        return Math.max(lo + 4, Math.min(hi - 4, t));
    }

    // ------------------------------------------------------------------ dibujar una zona
    /**
     * Dibuja la zona en dst (la capa de color, w*h del lienzo) leyendo el original src. Solo
     * escribe donde la mascara > 0 y (si onlyIn != null) donde onlyIn != 0. No toca nada mas.
     * @return cantidad de pixeles escritos
     */
    public static int render(int[] src, int W, int H, Zone z, int[] dst, byte[] onlyIn) {
        int[] loc = renderLocal(src, W, H, z);
        if (loc == null) return 0;
        return paste(loc, z, W, H, dst, onlyIn);
    }

    /** Pone el resultado local (renderLocal) en la capa: color con el alfa de la mascara. */
    public static int paste(int[] loc, Zone z, int W, int H, int[] dst, byte[] onlyIn) {
        int n = 0;
        for (int y = 0; y < z.h; y++) {
            int gy = y + z.y;
            if (gy < 0 || gy >= H) continue;
            for (int x = 0; x < z.w; x++) {
                int c = loc[y * z.w + x];
                int a = c >>> 24;
                if (a == 0) continue;
                int gx = x + z.x;
                if (gx < 0 || gx >= W) continue;
                int i = gy * W + gx;
                if (onlyIn != null && onlyIn[i] == 0) continue;
                dst[i] = a >= 255 ? c : over(dst[i], c, a);
                n++;
            }
        }
        return n;
    }

    /**
     * El color de la zona en su recuadro (z.w*z.h), con alfa = mascara. Se puede calcular en
     * otro hilo (no toca la capa). null si la zona no tiene pixeles.
     */
    public static int[] renderLocal(int[] src, int W, int H, Zone z) {
        return renderLocal(src, W, H, z, null);
    }

    /** v8.47: 'all' = todas las zonas de la obra (para la sombra que echan unas sobre otras). */
    public static int[] renderLocal(int[] src, int W, int H, Zone z, List<Zone> all) {
        Style s = z.s;
        // v8.60: zona con Acabado: la misma cuenta que la pantalla de Acabado
        if (s.pro) {
            try { return Acabado.renderZoneLocal(src, W, H, z, all); }
            catch (RuntimeException e) { /* si falla, como antes */ }
        }
        if (s.clean && s.finish != IMPROVE) return renderClean(src, W, H, z, all);
        Stats st = stats(src, W, z);
        if (st.n == 0) return null;
        int[] lut = lut(s, st, false);
        boolean dirShade = s.finish != MULTIPLY && s.finish != IMPROVE
                && (s.lightShade == 1 || (s.lightShade == 0 && st.flat));
        int[] lutSh = dirShade ? lut(s, st, true) : null;
        byte[] shade = dirShade ? dirShadow(z, s.lightDir) : null;
        float inten = s.intensity / 100f;
        boolean improve = s.finish == IMPROVE;
        int zw = z.w, zh = z.h;
        int[] out = new int[zw * zh];
        for (int y = 0; y < zh; y++) {
            int gy = y + z.y;
            if (gy < 0 || gy >= H) continue;
            for (int x = 0; x < zw; x++) {
                int mi = y * zw + x;
                int a = z.m[mi] & 0xFF;
                if (a == 0) continue;
                int gx = x + z.x;
                if (gx < 0 || gx >= W) continue;
                int c = src[gy * W + gx];
                int v = lum(c);
                int sv = st.smooth != null ? st.smooth[mi] : v;
                int col = lut[sv];
                if (shade != null && shade[mi] != 0) col = mixRgb(col, lutSh[sv], (shade[mi] & 0xFF) / 255f);
                if (st.smooth != null && s.keepTexture) col = detail(col, v, st.paper);
                int o;
                if (improve) o = improve(c, col, inten);
                else if (inten < 0.999f) o = mixRgb(0xFF000000 | (v << 16) | (v << 8) | v, col, inten);
                else o = col;
                out[mi] = (o & 0x00FFFFFF) | (a << 24);
            }
        }
        return out;
    }

    /**
     * v8.45 sombreado LIMPIO. Por que antes salian puntos y manchas: cada zona se "estiraba" de su
     * gris mas oscuro a su gris mas claro; en una cara casi blanca, el ruido del JPEG (2-10 grises)
     * se volvia sombra. Ahora:
     *  1) la luz de la zona se mide con los grises SUAVIZADOS (promedio solo dentro de la zona y
     *     sin contar las lineas negras): sin ruido, sin cuadritos del JPEG, sin trama;
     *  2) sombra = cuanto MAS OSCURO que el papel es ese gris (medida fija, no estirada), con zona
     *     muerta: lo casi blanco queda color base, liso;
     *  3) 2 tonos: sombra de borde definido y sin islitas (manchas chicas fuera);
     *  4) las lineas se ponen encima como en Multiplicar (con su antialias), del color oscuro;
     *  5) zonas casi negras (pelo negro): de negro -> color oscuro, blanco -> luz (brillos del pelo).
     */
    static int[] renderClean(int[] src, int W, int H, Zone z, List<Zone> all) {
        Style s = z.s;
        int zw = z.w, zh = z.h, n = zw * zh;
        int[] hist = new int[256];
        int cnt = 0;
        short[] v = new short[n];
        for (int y = 0; y < zh; y++)
            for (int x = 0; x < zw; x++) {
                int i = y * zw + x;
                if ((z.m[i] & 0xFF) == 0) continue;
                int gx = x + z.x, gy = y + z.y;
                if (gx < 0 || gy < 0 || gx >= W || gy >= H) continue;
                int c = src[gy * W + gx];
                int l = (c >>> 24) < 128 ? 255 : lum(c);
                v[i] = (short) l;
                if ((z.m[i] & 0xFF) >= 128) { hist[l]++; cnt++; }
            }
        if (cnt == 0) return null;
        int paper = Math.max(60, pct(hist, cnt, 0.97f));
        int p50 = pct(hist, cnt, 0.50f);
        float[] kS = oklab(s.shadow), kB = oklab(s.base), kL = oklab(s.light);
        if (s.finish == PAINTED) { kS = oklab(adjust(s.shadow, -0.02f, 1.3f, -8f)); kL = oklab(adjust(s.light, 0.01f, 1.05f, 6f)); }
        float[] kDeep = new float[]{kS[0] * 0.78f, kS[1] * 1.05f, kS[2] * 1.05f};
        float[] kInk = s.tintBlack ? new float[]{Math.min(kS[0] * 0.32f, 0.24f), kS[1] * 0.6f, kS[2] * 0.6f} : new float[]{0.05f, 0f, 0f};
        int[] out = new int[n];
        boolean darkZone = p50 < 95 && kB[0] < 0.8f;   // pelo negro, medias, corbata (con color claro, lo negro sigue siendo tinta)
        if (darkZone) {
            // de negro a color oscuro, de gris a base y de blanco a luz (brillos), un poco suavizado
            float[] kDark = new float[]{kB[0] * 0.55f, kB[1] * 0.9f, kB[2] * 0.9f};
            float[] f = new float[n];
            for (int i = 0; i < n; i++) f[i] = v[i];
            box(f, zw, zh, 1);
            float[] shD = s.shine && s.finish != MULTIPLY ? shineBand(z, s.lightDir) : null;
            for (int i = 0; i < n; i++) {
                int a = z.m[i] & 0xFF;
                if (a == 0) continue;
                float t = Math.min(1f, Math.max(0f, f[i] / paper));
                float[] k = t < 0.55f ? mixLab(kDark, kB, ease(t / 0.55f)) : mixLab(kB, kL, ease((t - 0.55f) / 0.45f));
                if (s.finish == MULTIPLY) k = t < 0.5f ? mixLab(kDark, kB, ease(t / 0.5f)) : kB;
                if (shD != null && shD[i] > 0f) k = mixLab(k, mixLab(kL, new float[]{0.97f, 0f, 0f}, 0.5f), Math.min(1f, shD[i] * 0.95f));
                out[i] = (fromOklab(k[0], k[1], k[2]) & 0x00FFFFFF) | (a << 24);
            }
            return out;
        }
        // 1) grises suavizados sin lineas
        int inkThr = Math.max(40, Math.min(115, paper - 95));
        // tono tipico de la zona (sin lineas): la base. En ropa gris (saco) la base es ese gris, no
        // el blanco del papel; los vivos blancos (borde del saco) no cuentan y siguen blancos.
        int[] h2 = new int[256];
        int c2 = 0;
        for (int i = 0; i < n; i++) if ((z.m[i] & 0xFF) >= 128 && v[i] >= inkThr) { h2[v[i]]++; c2++; }
        int rough = c2 > 0 ? pct(h2, c2, 0.6f) : paper;
        // v8.66: color claro (piel, blanco) en Multiplicar: la base es lo CLARO del dibujo y lo gris es
        // su sombra (el cuello con la sombra del menton). Antes la base era el gris de en medio: lo
        // claro quedaba como "borde blanco" y la sombra se perdia.
        final boolean lightMul = s.finish == MULTIPLY && !s.keepWhites;
        if (lightMul && c2 > 0) rough = Math.max(rough, pct(h2, c2, 0.9f));
        boolean whiteTrim = !lightMul && rough < paper - 45;
        float[] val = new float[n], wt = new float[n];
        for (int i = 0; i < n; i++) {
            if ((z.m[i] & 0xFF) < 128 || v[i] < inkThr) continue;
            if (whiteTrim && v[i] > paper - 30) continue;
            val[i] = v[i];
            wt[i] = 1f;
        }
        int r = Math.max(3, Math.min(8, Math.max(W, H) / 260));
        for (int pass = 0; pass < 3; pass++) { box(val, zw, zh, r); box(wt, zw, zh, r); }
        float[] sm = new float[n];
        for (int i = 0; i < n; i++) sm[i] = wt[i] > 0.02f ? val[i] / wt[i] : rough;
        int[] h3 = new int[256];
        int c3 = 0;
        for (int i = 0; i < n; i++) if (wt[i] > 0.02f && (z.m[i] & 0xFF) >= 128) { h3[Math.max(0, Math.min(255, Math.round(sm[i])))]++; c3++; }
        final int refL = Math.max(inkThr + 20, c3 > 0 ? pct(h3, c3, lightMul ? 0.9f : 0.6f) : rough);
        // 2) cuanto mas oscuro que la base (medida fija con zona muerta: sin estirar el ruido)
        float[] t = new float[n], up = new float[n];
        for (int i = 0; i < n; i++) { t[i] = Math.max(0f, refL - sm[i]); up[i] = Math.max(0f, sm[i] - refL); }
        // v8.47: fuerza (50 = normal) y sombra automatica (para dibujos sin grises)
        float pk = s.power / 50f;
        for (int i = 0; i < n; i++) { t[i] *= pk; up[i] *= pk; }
        if (s.autoShade && s.finish != MULTIPLY && (long) cnt * 10 < (long) W * H * 3) {   // el fondo enorme no
            byte[] ds = dirShadow(z, s.lightDir);
            float[] cast = castShadow(z, all, W, H);
            float lvl = s.finish == CEL ? 60f : 55f;     // en "grises" equivale a una sombra media
            for (int i = 0; i < n; i++) {
                float a = Math.max((ds[i] & 0xFF) / 255f * 0.85f, cast == null ? 0f : cast[i]);
                if (a > 0f) t[i] = Math.max(t[i], a * lvl * Math.max(0.6f, pk));
            }
        }
        if (s.finish == CEL) {
            boolean[] on = new boolean[n];
            for (int i = 0; i < n; i++) on[i] = (z.m[i] & 0xFF) >= 128 && t[i] > 30f;
            int minA = Math.max(40, cnt / 300);
            dropIslands(on, z.m, zw, zh, minA, true);    // manchitas de sombra fuera
            dropIslands(on, z.m, zw, zh, minA, false);   // huequitos de luz dentro de la sombra fuera
            float[] b = new float[n];
            for (int i = 0; i < n; i++) b[i] = on[i] ? 1f : 0f;
            box(b, zw, zh, 1);                            // borde con antialias de 1 px
            for (int i = 0; i < n; i++) t[i] = b[i];
        } else if (s.finish == MULTIPLY) {
            // v8.66: el color plano RESPETA las sombras grises que ya trae el dibujo (como pintar en
            // Multiplicar): antes las borraba y quedaba todo liso. Sin grises (solo lineas) = liso igual.
            for (int i = 0; i < n; i++) {
                float d = t[i];
                t[i] = 0.9f * ease((d - 10f) / 55f) + 0.5f * ease((d - 90f) / 70f);
            }
        } else {
            for (int i = 0; i < n; i++) {
                float d = t[i];
                t[i] = ease((d - 8f) / 50f) + 0.6f * ease((d - 90f) / 70f);   // sombra + sombra profunda
            }
        }
        float[] shineA = s.shine && s.finish != MULTIPLY ? shineBand(z, s.lightDir) : null;
        for (int i = 0; i < n; i++) {
            int a = z.m[i] & 0xFF;
            if (a == 0) continue;
            float tt = t[i];
            float[] k = tt <= 1f ? mixLab(kB, kS, Math.min(1f, tt)) : mixLab(kS, kDeep, Math.min(1f, tt - 1f));
            if (s.finish != MULTIPLY && s.finish != CEL) k = mixLab(k, kL, 0.8f * ease((up[i] - 8f) / 50f));   // luces
            if (s.finish == CEL && up[i] > 40f) k = mixLab(k, kL, 0.7f);
            // v8.66: en Multiplicar tambien se respetan los brillos dibujados (pelo)
            if (s.finish == MULTIPLY && !lightMul) k = mixLab(k, kL, 0.6f * ease((up[i] - 12f) / 50f));
            if (whiteTrim && s.keepWhites && v[i] > paper - 30) k = mixLab(k, new float[]{Math.max(kL[0], 0.97f), 0f, 0f}, ease((v[i] - (paper - 30)) / 18f));
            if (kB[0] < 0.42f && s.finish != MULTIPLY) {
                // color oscuro (pelo negro, medias): lo blanco del dibujo es brillo -> luz
                k = mixLab(k, kL, 0.75f * ease((v[i] - (paper - 25f)) / 20f) * (1f - Math.min(1f, tt)));
            }
            if (s.finish == PAINTED) {
                float lit = ease((up[i] - 4f) / 30f);   // lo mas claro, un toque de luz
                k = mixLab(k, kL, 0.35f * lit * (1f - Math.min(1f, tt)));
            }
            // 4) lineas encima (como Multiplicar, con zona muerta para que no salga grano)
            float local = Math.max(inkThr, Math.min(sm[i], refL + 40f));
            float d = local - v[i];
            if (d > 14f) {
                float f = Math.max(0f, 1f - (d - 14f) / Math.max(1f, local - 14f));
                k = mixLab(kInk, k, f);
            }
            if (shineA != null && shineA[i] > 0f)   // anillo de brillo del pelo (tambien sobre lo negro)
                k = mixLab(k, mixLab(kL, new float[]{0.97f, 0f, 0f}, kB[0] < 0.4f ? 0.5f : 0.45f), Math.min(1f, shineA[i] * 0.95f));
            out[i] = (fromOklab(k[0], k[1], k[2]) & 0x00FFFFFF) | (a << 24);
        }
        return out;
    }

    /**
     * v8.47: sombra que ECHAN otras zonas sobre esta (pelo sobre la frente, cara sobre el cuello,
     * cuello de la camisa...): un pixel queda en sombra si, mirando HACIA la luz, a poca distancia
     * hay otra zona. Las zonas enormes (el fondo) no cuentan. 0..1 por pixel del recuadro.
     */
    static float[] castShadow(Zone z, List<Zone> all, int W, int H) {
        if (all == null || all.size() < 2) return null;
        int zw = z.w, zh = z.h, n = zw * zh;
        int d = Math.max(4, Math.round(Math.min(W, H) * 0.022f));
        int dir = z.s.lightDir & 7;
        int lx = DX[dir], ly = DY[dir];                 // hacia donde esta la luz
        float norm = (lx != 0 && ly != 0) ? 0.7071f : 1f;
        float[] out = new float[n];
        long big = (long) W * H * 35 / 100;
        boolean any = false;
        for (Zone o : all) {
            if (o == z || o.m == z.m) continue;
            if ((long) o.area() > big) continue;
            if (o.x > z.x + zw + d || o.y > z.y + zh + d || o.x + o.w < z.x - d || o.y + o.h < z.y - d) continue;
            for (int y = 0; y < zh; y++)
                for (int x = 0; x < zw; x++) {
                    int i = y * zw + x;
                    if ((z.m[i] & 0xFF) < 128 || out[i] >= 1f) continue;
                    int gx = x + z.x, gy = y + z.y;
                    int hit = 0;
                    for (int k = 1; k <= 3; k++) {
                        int sx = gx + Math.round(lx * d * k / 3f * norm) - o.x, sy = gy + Math.round(ly * d * k / 3f * norm) - o.y;
                        if (sx >= 0 && sy >= 0 && sx < o.w && sy < o.h && (o.m[sy * o.w + sx] & 0xFF) >= 128) hit++;
                    }
                    if (hit > 0) { out[i] = Math.max(out[i], hit >= 2 ? 1f : 0.55f); any = true; }
                }
        }
        if (!any) return null;
        box(out, zw, zh, 1);
        return out;
    }

    /** v8.47: anillo de brillo del pelo: una banda cerca de la parte de arriba de cada columna, con puntas. */
    static float[] shineBand(Zone z, int lightDir) {
        int zw = z.w, zh = z.h, n = zw * zh;
        int[] top = new int[zw], bot = new int[zw];
        java.util.Arrays.fill(top, -1);
        for (int x = 0; x < zw; x++)
            for (int y = 0; y < zh; y++)
                if ((z.m[y * zw + x] & 0xFF) >= 128) { if (top[x] < 0) top[x] = y; bot[x] = y; }
        float[] out = new float[n];
        float per = Math.max(6f, zw / 16f);
        float side = DX[lightDir & 7];                 // mas brillo del lado de la luz
        for (int x = 0; x < zw; x++) {
            if (top[x] < 0) continue;
            int hc = bot[x] - top[x];
            if (hc < 8) continue;
            float c = top[x] + hc * 0.24f, w = Math.max(3f, hc * 0.06f);
            float ph = (x % per) / per;
            float spike = 1f - Math.abs(ph - 0.5f) * 2f;       // puntas hacia abajo
            float sideK = 0.65f + 0.35f * side * ((x / (float) zw) * 2f - 1f);
            for (int y = Math.max(0, (int) (c - w * 2)); y < Math.min(zh, (int) (c + w * 2.5f)); y++) {
                int i = y * zw + x;
                if ((z.m[i] & 0xFF) < 128) continue;
                float dy = (y - c) / (w * (0.6f + spike));
                float v = 1f - Math.abs(dy);
                if (v <= 0f) continue;
                out[i] = Math.max(out[i], ease(v * 1.6f) * Math.max(0.2f, Math.min(1f, sideK)));
            }
        }
        box(out, zw, zh, 1);
        return out;
    }

    /** Quita grupos de 'on' (o de 'off' si islandsOfOn=false) mas chicos que minA, dentro de la mascara. */
    private static void dropIslands(boolean[] on, byte[] m, int w, int h, int minA, boolean islandsOfOn) {
        int n = w * h;
        boolean[] seen = new boolean[n];
        int[] q = new int[n];
        for (int s0 = 0; s0 < n; s0++) {
            if (seen[s0] || (m[s0] & 0xFF) < 128 || on[s0] != islandsOfOn) continue;
            int qh = 0, qt = 0;
            q[qt++] = s0;
            seen[s0] = true;
            while (qh < qt) {
                int i = q[qh++], x = i % w, y = i / w;
                for (int d = 0; d < 4; d++) {
                    int j = d == 0 ? (x > 0 ? i - 1 : -1) : d == 1 ? (x < w - 1 ? i + 1 : -1) : d == 2 ? (y > 0 ? i - w : -1) : (y < h - 1 ? i + w : -1);
                    if (j < 0 || seen[j] || (m[j] & 0xFF) < 128 || on[j] != islandsOfOn) continue;
                    seen[j] = true;
                    q[qt++] = j;
                }
            }
            if (qt < minA) for (int k = 0; k < qt; k++) on[q[k]] = !islandsOfOn;
        }
    }

    /**
     * Devuelve el detalle de la trama como en Multiplicar: el papel entre puntos queda del color
     * y los puntos lo oscurecen (con fuerza 0,65 para que la zona no quede sucia ni oscura).
     */
    private static int detail(int col, int v, int paper) {
        float f = Math.min(1f, v / (float) Math.max(1, paper));
        f = 1f - 0.65f * (1f - f);
        int r = Math.round(((col >> 16) & 255) * f), g = Math.round(((col >> 8) & 255) * f), b = Math.round((col & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Mejorar color: se conserva la luz del original y se acercan sus colores al degradado. */
    private static int improve(int src, int mapped, float t) {
        int sc = src | 0xFF000000;
        if ((src >>> 24) < 255) sc = paperOf(src);
        float[] a = oklab(sc), b = oklab(mapped);
        float L = a[0] + (b[0] - a[0]) * t * 0.45f;
        return fromOklab(L, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t);
    }

    private static int paperOf(int c) {
        int a = c >>> 24;
        int r = (((c >> 16) & 255) * a + 255 * (255 - a)) / 255;
        int g = (((c >> 8) & 255) * a + 255 * (255 - a)) / 255;
        int b = ((c & 255) * a + 255 * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public static int mixRgb(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Igual que Project.over (sin premultiplicar), copiado para que esto sea Java puro. */
    public static int over(int dst, int src, int sa) {
        if (sa >= 255) return (src & 0x00FFFFFF) | 0xFF000000;
        int da = dst >>> 24;
        if (da == 0) return (src & 0x00FFFFFF) | (sa << 24);
        int oa = sa + (da * (255 - sa)) / 255;
        if (oa == 0) return 0;
        int dw = (da * (255 - sa)) / 255;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * dw) / oa;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * dw) / oa;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * dw) / oa;
        return (oa << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Sombra de 2 tonos por direccion de luz (zonas sin grises): un pixel queda en sombra si al
     * moverse en la direccion en que VIAJA la luz (a 1/2 y a 1 ancho) sale de su zona. Borde suave.
     */
    static byte[] dirShadow(Zone z, int dir) {
        int zw = z.w, zh = z.h;
        byte[] out = new byte[zw * zh];
        int area = Math.max(1, z.area());
        int d = clamp(Math.round(0.11f * (float) Math.sqrt(area)), 3, 60);
        int tx = -DX[dir & 7], ty = -DY[dir & 7];
        float norm = (tx != 0 && ty != 0) ? 0.7071f : 1f;
        int[] steps = {d / 2, d, d + d / 4};
        for (int y = 0; y < zh; y++)
            for (int x = 0; x < zw; x++) {
                int i = y * zw + x;
                if ((z.m[i] & 0xFF) < 128) continue;
                int hit = 0;
                for (int k : steps) {
                    int sx = x + Math.round(tx * k * norm), sy = y + Math.round(ty * k * norm);
                    boolean in = sx >= 0 && sy >= 0 && sx < zw && sy < zh && (z.m[sy * zw + sx] & 0xFF) >= 128;
                    if (!in) hit++;
                }
                if (hit >= 2) out[i] = (byte) 255;
                else if (hit == 1) out[i] = (byte) 110;
            }
        return out;
    }

    // ------------------------------------------------------------------ silueta, brillo y fondo
    /** Union de las zonas en el lienzo (0/1). */
    public static byte[] union(List<Zone> zones, int W, int H) {
        byte[] u = new byte[W * H];
        for (Zone z : zones)
            for (int y = 0; y < z.h; y++)
                for (int x = 0; x < z.w; x++) {
                    if ((z.m[y * z.w + x] & 0xFF) < 128) continue;
                    int gx = x + z.x, gy = y + z.y;
                    if (gx >= 0 && gy >= 0 && gx < W && gy < H) u[gy * W + gx] = 1;
                }
        return u;
    }

    /**
     * Silueta del personaje: la union de zonas con las lineas de entre medio cerradas (cierre
     * morfologico de radio r). Asi el brillo de contorno no aparece en lineas internas, ojos o
     * pliegues. Si 'alpha' != null (personaje recortado), se usa su alfa.
     */
    public static byte[] silhouette(byte[] union, int[] alphaSrc, int W, int H, int r) {
        byte[] s = new byte[W * H];
        if (alphaSrc != null) {
            boolean anyClear = false;
            for (int i = 0; i < W * H; i += 7) if ((alphaSrc[i] >>> 24) < 128) { anyClear = true; break; }
            if (anyClear) {
                for (int i = 0; i < W * H; i++) s[i] = (byte) ((alphaSrc[i] >>> 24) >= 128 ? 1 : 0);
                return s;
            }
        }
        System.arraycopy(union, 0, s, 0, s.length);
        dilate(s, W, H, r);
        erode(s, W, H, r);
        return s;
    }

    /** Dilatacion cuadrada (2r+1) de una mascara 0/1, en el lugar. */
    public static void dilate(byte[] m, int W, int H, int r) {
        int[] cnt = new int[Math.max(W, H)];
        byte[] t = new byte[W * H];
        for (int y = 0; y < H; y++) {
            int o = y * W, c = 0;
            for (int x = 0; x <= Math.min(r, W - 1); x++) c += m[o + x];
            for (int x = 0; x < W; x++) {
                t[o + x] = (byte) (c > 0 ? 1 : 0);
                int add = x + r + 1, rem = x - r;
                if (add < W) c += m[o + add];
                if (rem >= 0) c -= m[o + rem];
            }
        }
        for (int x = 0; x < W; x++) {
            int c = 0;
            for (int y = 0; y <= Math.min(r, H - 1); y++) c += t[y * W + x];
            for (int y = 0; y < H; y++) {
                m[y * W + x] = (byte) (c > 0 ? 1 : 0);
                int add = y + r + 1, rem = y - r;
                if (add < H) c += t[add * W + x];
                if (rem >= 0) c -= t[rem * W + x];
            }
        }
    }

    public static void erode(byte[] m, int W, int H, int r) {
        for (int i = 0; i < m.length; i++) m[i] = (byte) (m[i] != 0 ? 0 : 1);
        dilate(m, W, H, r);
        for (int i = 0; i < m.length; i++) m[i] = (byte) (m[i] != 0 ? 0 : 1);
    }

    /**
     * Brillo de contorno: franja de 'width' px en el borde de la silueta, solo del lado de donde
     * VIENE la luz (al moverse hacia la luz se sale de la silueta). Alfa 0..255 suave.
     */
    public static byte[] rim(byte[] sil, int W, int H, int dir, int width) {
        byte[] out = new byte[W * H];
        int lx = DX[dir & 7], ly = DY[dir & 7];
        float norm = (lx != 0 && ly != 0) ? 0.7071f : 1f;
        width = Math.max(1, width);
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                if (sil[i] == 0) continue;
                int k;
                for (k = 1; k <= width; k++) {
                    int sx = x + Math.round(lx * k * norm), sy = y + Math.round(ly * k * norm);
                    if (sx < 0 || sy < 0 || sx >= W || sy >= H || sil[sy * W + sx] == 0) break;
                }
                if (k > width) continue;
                float f = 1f - (k - 1) / (float) width;
                out[i] = (byte) Math.round(255 * f * f);
            }
        // suavizado de 1 px
        int[] tmp = new int[W * H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int s = 0, c = 0;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) {
                        int sx = x + dx, sy = y + dy;
                        if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
                        s += out[sy * W + sx] & 0xFF; c++;
                    }
                tmp[y * W + x] = sil[y * W + x] == 0 ? 0 : s / c;
            }
        for (int i = 0; i < out.length; i++) out[i] = (byte) tmp[i];
        return out;
    }

    /** Fondo degradado vertical de dos colores (top -> bottom); outside != null: solo fuera de la silueta. */
    public static void gradient(int[] dst, int W, int H, int top, int bottom, byte[] outsideOf) {
        float[] a = oklab(top), b = oklab(bottom);
        int[] row = new int[H];
        for (int y = 0; y < H; y++) {
            float t = H <= 1 ? 0 : y / (float) (H - 1);
            float[] k = mixLab(a, b, ease(t));
            row[y] = fromOklab(k[0], k[1], k[2]);
        }
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                if (outsideOf != null && outsideOf[i] != 0) { dst[i] = 0; continue; }
                dst[i] = row[y];
            }
    }

    // ------------------------------------------------------------------ paleta de la referencia
    /** Un grupo de la referencia: sombra, base, luz y cuantos pixeles tiene. */
    public static final class Group {
        public int shadow, base, light, count;
    }

    /**
     * Paleta mejorada: k-medias en OKLab (k grupos, 8..12) sobre una muestra reducida de lo opaco
     * de la referencia. Cada grupo da SOMBRA (percentil 15 de L), BASE (mediana) y LUZ (percentil
     * 85), tomados de los propios pixeles del grupo (la sombra del artista, no un gris).
     * Determinista. Ordenado por cantidad.
     */
    public static List<Group> groups(int[] px, int W, int H, int k) {
        k = clamp(k, 2, 16);
        int step = Math.max(1, (int) Math.sqrt(W * (double) H / 22000.0));
        List<float[]> pts = new ArrayList<float[]>();
        List<Integer> cols = new ArrayList<Integer>();
        for (int y = step / 2; y < H; y += step)
            for (int x = step / 2; x < W; x += step) {
                int c = px[y * W + x];
                if ((c >>> 24) < 160) continue;
                pts.add(oklab(c));
                cols.add(c | 0xFF000000);
            }
        int n = pts.size();
        List<Group> res = new ArrayList<Group>();
        if (n == 0) return res;
        k = Math.min(k, n);
        // inicio k-medias++ determinista: el primero el mas central (mediana de L), luego el mas lejano
        float[][] cen = new float[k][];
        float[] dmin = new float[n];
        java.util.Arrays.fill(dmin, Float.MAX_VALUE);
        cen[0] = pts.get(n / 2).clone();
        for (int c = 1; c < k; c++) {
            int best = 0;
            float bd = -1;
            for (int i = 0; i < n; i++) {
                float d = d2(pts.get(i), cen[c - 1]);
                if (d < dmin[i]) dmin[i] = d;
                if (dmin[i] > bd) { bd = dmin[i]; best = i; }
            }
            cen[c] = pts.get(best).clone();
        }
        int[] asg = new int[n];
        for (int it = 0; it < 14; it++) {
            float[][] sum = new float[k][3];
            int[] cnt = new int[k];
            for (int i = 0; i < n; i++) {
                float[] p = pts.get(i);
                int bi = 0;
                float bd = Float.MAX_VALUE;
                for (int c = 0; c < k; c++) {
                    float d = d2(p, cen[c]);
                    if (d < bd) { bd = d; bi = c; }
                }
                asg[i] = bi;
                cnt[bi]++;
                sum[bi][0] += p[0]; sum[bi][1] += p[1]; sum[bi][2] += p[2];
            }
            for (int c = 0; c < k; c++)
                if (cnt[c] > 0) cen[c] = new float[]{sum[c][0] / cnt[c], sum[c][1] / cnt[c], sum[c][2] / cnt[c]};
        }
        for (int c = 0; c < k; c++) {
            List<float[]> mem = new ArrayList<float[]>();
            for (int i = 0; i < n; i++) if (asg[i] == c) mem.add(pts.get(i));
            if (mem.size() < Math.max(3, n / 400)) continue;
            mem.sort((p, q) -> Float.compare(p[0], q[0]));
            Group g = new Group();
            g.count = mem.size();
            g.shadow = avgLab(mem, 0.08f, 0.22f);
            g.base = avgLab(mem, 0.40f, 0.60f);
            g.light = avgLab(mem, 0.78f, 0.92f);
            res.add(g);
        }
        res.sort((p, q) -> Integer.compare(q.count, p.count));
        return res;
    }

    private static int avgLab(List<float[]> sorted, float a, float b) {
        int n = sorted.size();
        int i0 = Math.min(n - 1, (int) (n * a)), i1 = Math.max(i0 + 1, Math.min(n, (int) Math.ceil(n * b)));
        float L = 0, A = 0, B = 0;
        for (int i = i0; i < i1; i++) { float[] p = sorted.get(i); L += p[0]; A += p[1]; B += p[2]; }
        int c = i1 - i0;
        return fromOklab(L / c, A / c, B / c);
    }

    private static float d2(float[] a, float[] b) {
        // la luminosidad pesa poco: un grupo = un material con su sombra y su luz
        float dl = (a[0] - b[0]) * 0.45f, da = a[1] - b[1], db = a[2] - b[2];
        return dl * dl + da * da + db * db;
    }

    /** El grupo cuyo color esta mas cerca de c (para "gotero en la referencia -> trio"). */
    public static Group nearest(List<Group> gs, int c) {
        if (gs == null || gs.isEmpty()) return null;
        float[] k = oklab(c);
        Group best = null;
        float bd = Float.MAX_VALUE;
        for (Group g : gs) {
            float d = Math.min(d2(k, oklab(g.base)), Math.min(d2(k, oklab(g.shadow)), d2(k, oklab(g.light))));
            if (d < bd) { bd = d; best = g; }
        }
        return best;
    }

    /**
     * Trio desde la referencia alrededor de un punto (gotero "con referencia"): se toma el color
     * del punto (promedio de un circulo de radio r) y su grupo; despues se juntan los pixeles
     * CERCANOS (radio ~6 % de la imagen) que son del mismo material (mismo grupo) y de ellos salen
     * SOMBRA (percentil 12 de luminosidad), BASE (mediana) y LUZ (percentil 88): la sombra y la luz
     * que el artista pinto en esa parte. Si hay muy pocos, se usa el grupo entero o el color solo.
     */
    public static Style trioAt(int[] ref, int W, int H, int cx, int cy, int r, List<Group> gs, Style into) {
        long R = 0, G = 0, B = 0;
        int n = 0;
        for (int y = Math.max(0, cy - r); y <= Math.min(H - 1, cy + r); y++)
            for (int x = Math.max(0, cx - r); x <= Math.min(W - 1, cx + r); x++) {
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) > r * r) continue;
                int c = ref[y * W + x];
                if ((c >>> 24) < 128) continue;
                R += (c >> 16) & 255; G += (c >> 8) & 255; B += c & 255; n++;
            }
        Style s = into == null ? new Style() : into;
        if (n == 0) return s;
        int med = 0xFF000000 | ((int) (R / n) << 16) | ((int) (G / n) << 8) | (int) (B / n);
        float[] km = oklab(med);
        // casi sin color (negro, blanco, gris): el tono no separa materiales (corbata negra y
        // camisa blanca), asi que la luminosidad tiene que ser parecida
        float lumTol = Math.hypot(km[1], km[2]) < 0.04f ? 0.15f : 0.32f;
        int big = Math.max(12, Math.round(Math.max(W, H) * 0.06f));
        List<float[]> mem = new ArrayList<float[]>();
        int step = Math.max(1, big / 40);
        for (int y = Math.max(0, cy - big); y <= Math.min(H - 1, cy + big); y += step)
            for (int x = Math.max(0, cx - big); x <= Math.min(W - 1, cx + big); x += step) {
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) > big * big) continue;
                int c = ref[y * W + x];
                if ((c >>> 24) < 128) continue;
                float[] k = oklab(c);
                // mismo material: tono y croma parecidos (la luminosidad puede variar: es la sombra/luz)
                float da = k[1] - km[1], db = k[2] - km[2], dl = k[0] - km[0];
                if (da * da + db * db > 0.045f * 0.045f || Math.abs(dl) > lumTol) continue;
                mem.add(k);
            }
        if (mem.size() >= 30) {
            mem.sort((p, q) -> Float.compare(p[0], q[0]));
            s.shadow = avgLab(mem, 0.06f, 0.18f);
            s.base = avgLab(mem, 0.42f, 0.58f);
            s.light = avgLab(mem, 0.82f, 0.94f);
            // si la referencia casi no tiene sombra ahi, se completa como sin referencia
            float[] a = oklab(s.shadow), b = oklab(s.light);
            if (b[0] - a[0] < 0.08f) {
                Style t = trioFrom(s.base, null);
                if (b[0] - a[0] < 0.04f) { s.shadow = t.shadow; s.light = t.light; }
                else { s.shadow = mixRgb(s.shadow, t.shadow, 0.5f); s.light = mixRgb(s.light, t.light, 0.5f); }
            }
            return s;
        }
        Group g = nearest(gs, med);
        if (g != null && Math.sqrt(d2(km, oklab(g.base))) < 0.07f) {
            s.shadow = g.shadow; s.base = g.base; s.light = g.light;
            return s;
        }
        return trioFrom(med, s);
    }

    // ------------------------------------------------------------------ lineas suaves (light novel)
    /**
     * Lineas de ilustraciones con grises suaves (light novel): ahi las lineas son GRISES finos,
     * no negro, y el balde por umbral se escapa por todo el dibujo. Linea = pixel mas oscuro que
     * su entorno (promedio de ~7 px) por mas de 'delta', o mas oscuro que darkThr. Un degradado
     * de sombra no cuenta (cambia despacio). Se quitan motas de 1-3 px (ruido JPEG).
     * Se SUMA al mapa de tinta del balde manga (que sigue igual para el manga normal).
     */
    public static byte[] softLines(int[] ref, int W, int H, int delta, int darkThr) {
        // v8.63: las lineas se buscan a un tamano fijo (~1000 px de lado). Antes la ventana era de
        // 7 px siempre: en fotos grandes la linea gris es mas gruesa que la ventana, no se veia y el
        // color se escapaba (tocar la cara pintaba pelo y fondo).
        int f = (int) Math.ceil(Math.max(W, H) / 1000.0);
        if (f >= 2) return softLinesScaled(ref, W, H, delta, darkThr, f);
        int n = W * H;
        float[] l = new float[n];
        for (int i = 0; i < n; i++) l[i] = lum(ref[i]);
        float[] b = l.clone();
        box(b, W, H, 3);
        box(b, W, H, 3);
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) if (l[i] < darkThr || b[i] - l[i] > delta) out[i] = 1;
        // motas sueltas: pixel de linea sin vecinos de linea (8 vecinos) o con uno solo
        byte[] o2 = out.clone();
        for (int y = 1; y < H - 1; y++)
            for (int x = 1; x < W - 1; x++) {
                int i = y * W + x;
                if (out[i] == 0 || l[i] < darkThr) continue;
                int c = out[i - 1] + out[i + 1] + out[i - W] + out[i + W] + out[i - W - 1] + out[i - W + 1] + out[i + W - 1] + out[i + W + 1];
                if (c <= 1) o2[i] = 0;
            }
        return o2;
    }

    /**
     * v8.63: "paredes de tono". En dibujos de grises (o a color) dos partes se separan muchas veces
     * solo por el tono, sin linea negra entera (cara clara junto al pelo gris). Un salto fuerte de
     * brillo (>= step) cuenta como pared, del lado oscuro. Se mide a ~1000 px de lado (no depende del
     * tamano de la foto). Los brillos del pelo (salto chico) no cortan.
     */
    public static byte[] toneWalls(int[] ref, int W, int H, int step) {
        int f = Math.max(1, (int) Math.ceil(Math.max(W, H) / 1000.0));
        int w2 = (W + f - 1) / f, h2 = (H + f - 1) / f;
        int[] L = new int[w2 * h2];
        boolean[] opaque = new boolean[w2 * h2];
        for (int y2 = 0; y2 < h2; y2++)
            for (int x2 = 0; x2 < w2; x2++) {
                int sum = 0, cnt = 0, al = 0;
                for (int y = y2 * f; y < Math.min(H, y2 * f + f); y++)
                    for (int x = x2 * f; x < Math.min(W, x2 * f + f); x++) {
                        int c = ref[y * W + x];
                        sum += lum(c); al += c >>> 24; cnt++;
                    }
                L[y2 * w2 + x2] = sum / cnt;
                opaque[y2 * w2 + x2] = al / cnt >= 128;
            }
        // por celda: el medio del salto (si hay salto fuerte); -1 = sin pared
        int[] mid = new int[w2 * h2];
        java.util.Arrays.fill(mid, -1);
        for (int y = 2; y < h2 - 2; y++)
            for (int x = 2; x < w2 - 2; x++) {
                int i = y * w2 + x;
                if (!opaque[i]) continue;
                int best = 0, m = 0;
                int a = L[i - 2], b = L[i + 2];
                if (Math.abs(a - b) > best) { best = Math.abs(a - b); m = (a + b) / 2; }
                a = L[i - 2 * w2]; b = L[i + 2 * w2];
                if (Math.abs(a - b) > best) { best = Math.abs(a - b); m = (a + b) / 2; }
                a = L[i - 2 * w2 - 2]; b = L[i + 2 * w2 + 2];
                if (Math.abs(a - b) * 0.8f > best) { best = Math.round(Math.abs(a - b) * 0.8f); m = (a + b) / 2; }
                a = L[i - 2 * w2 + 2]; b = L[i + 2 * w2 - 2];
                if (Math.abs(a - b) * 0.8f > best) { best = Math.round(Math.abs(a - b) * 0.8f); m = (a + b) / 2; }
                if (best >= step && L[i] <= m) mid[i] = m;
            }
        byte[] out = new byte[W * H];
        for (int y = 0; y < H; y++) {
            int y2 = Math.min(h2 - 1, y / f);
            for (int x = 0; x < W; x++) {
                int m = mid[y2 * w2 + Math.min(w2 - 1, x / f)];
                if (m >= 0 && lum(ref[y * W + x]) <= m + 4) out[y * W + x] = 1;
            }
        }
        return out;
    }

    /** softLines en una copia reducida (promedio f x f); se vuelve a tamano real afinando con el pixel. */
    static byte[] softLinesScaled(int[] ref, int W, int H, int delta, int darkThr, int f) {
        int w2 = (W + f - 1) / f, h2 = (H + f - 1) / f;
        int[] small = new int[w2 * h2];
        for (int y2 = 0; y2 < h2; y2++)
            for (int x2 = 0; x2 < w2; x2++) {
                int sum = 0, cnt = 0, al = 0;
                for (int y = y2 * f; y < Math.min(H, y2 * f + f); y++)
                    for (int x = x2 * f; x < Math.min(W, x2 * f + f); x++) {
                        int c = ref[y * W + x];
                        sum += lum(c); al += c >>> 24; cnt++;
                    }
                int v = sum / cnt, a = al / cnt;
                small[y2 * w2 + x2] = (a << 24) | (v << 16) | (v << 8) | v;
            }
        byte[] lo = softLines(small, w2, h2, delta, darkThr);
        // fondo local (para afinar): promedio alrededor en la copia chica
        float[] b = new float[w2 * h2];
        for (int i = 0; i < b.length; i++) b[i] = small[i] & 0xFF;
        box(b, w2, h2, 3);
        box(b, w2, h2, 3);
        byte[] out = new byte[W * H];
        for (int y = 0; y < H; y++) {
            int y2 = y / f;
            for (int x = 0; x < W; x++) {
                int k = y2 * w2 + x / f;
                int v = lum(ref[y * W + x]);
                if (v < darkThr) { out[y * W + x] = 1; continue; }
                // en la celda hay linea: cuenta el pixel si es mas oscuro que su alrededor
                if (lo[k] != 0 && v < b[k] - delta * 0.4f) out[y * W + x] = 1;
            }
        }
        return out;
    }

    /**
     * Toque sobre un puntito de trama o una linea: el pixel libre (no tinta) mas cercano, hasta
     * r px. Asi tocar una zona con trama no falla por caer justo en un punto. null si no hay.
     */
    public static int[] nearestFree(byte[] line, int W, int H, int x, int y, int r) {
        if (x < 0 || y < 0 || x >= W || y >= H) return null;
        if (line[y * W + x] == 0) return new int[]{x, y};
        int[] best = null;
        int bd = Integer.MAX_VALUE;
        for (int dy = -r; dy <= r; dy++)
            for (int dx = -r; dx <= r; dx++) {
                int sx = x + dx, sy = y + dy, d = dx * dx + dy * dy;
                if (d > r * r || d >= bd || sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
                if (line[sy * W + sx] != 0) continue;
                bd = d;
                best = new int[]{sx, sy};
            }
        return best;
    }

    /** Lo transparente (fondo ya borrado) cuenta como pared: el color no se escapa al fondo. */
    public static void addAlphaWalls(int[] ref, int width, byte[] line) {
        boolean any = false;
        for (int i = 0; i < ref.length; i += 13) if ((ref[i] >>> 24) < 128) { any = true; break; }
        if (!any) return;
        // el borde blanco de "pegatina" que deja el recorte tambien cuenta (3 px): si no, el color
        // da la vuelta al personaje por ese borde y entra en otra zona
        int W = width, H = ref.length / Math.max(1, width);
        byte[] t = new byte[ref.length];
        for (int i = 0; i < ref.length; i++) if ((ref[i] >>> 24) < 128) t[i] = 1;
        dilate(t, W, H, 3);
        for (int i = 0; i < ref.length; i++) if (t[i] != 0 && (lum(ref[i]) > 200 || (ref[i] >>> 24) < 128)) line[i] = 1;
    }

    // ------------------------------------------------------------------ tipo de dibujo
    public static final int KIND_SOFT = 0, KIND_TONE = 1, KIND_LINES = 2, KIND_COLOR = 3;
    public static final String[] KIND_NAMES = {"grises suaves (light novel)", "trama de puntitos", "solo lineas", "a color"};

    /** Que tipo de dibujo es (muestra del lienzo, sin la tinta). */
    public static int kind(int[] src, int W, int H) {
        int step = Math.max(1, (int) Math.sqrt(W * (double) H / 160000.0));
        long satSum = 0, hf = 0;
        int n = 0, gray = 0, hfN = 0;
        for (int y = step; y < H - step; y += step)
            for (int x = step; x < W - step; x += step) {
                int i = y * W + x;
                int c = src[i];
                if ((c >>> 24) < 128) continue;
                int v = lum(c);
                n++;
                satSum += sat(c);
                if (v > 60 && v < 225) gray++;
                if (v > 40) {
                    int a = lum(src[i - 1]) + lum(src[i + 1]) + lum(src[i - W]) + lum(src[i + W]);
                    hf += Math.abs(v * 4 - a);
                    hfN++;
                }
            }
        if (n == 0) return KIND_LINES;
        if (satSum / n > 28) return KIND_COLOR;
        float tone = hfN == 0 ? 0 : hf / (4f * hfN);
        if (tone > TONE_THR + 3) return KIND_TONE;
        if (gray < n * 0.06f) return KIND_LINES;
        return KIND_SOFT;
    }

    static int clamp(int v, int a, int b) { return v < a ? a : v > b ? b : v; }

    // ------------------------------------------------------------------ guardar
    /** Zonas a bytes (formato propio: version, estilo actual, zonas con mascara RLE). */
    public static byte[] encode(List<Zone> zones, Style current, List<Group> palette) {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        java.io.DataOutputStream o = new java.io.DataOutputStream(bo);
        try {
            o.writeInt(0x5A4E3031);           // "ZN01"
            writeStyle(o, current == null ? new Style() : current);
            o.writeInt(palette == null ? 0 : palette.size());
            if (palette != null) for (Group g : palette) { o.writeInt(g.shadow); o.writeInt(g.base); o.writeInt(g.light); o.writeInt(g.count); }
            o.writeInt(zones.size());
            for (Zone z : zones) {
                o.writeInt(z.x); o.writeInt(z.y); o.writeInt(z.w); o.writeInt(z.h);
                writeStyle(o, z.s);
                // RLE: (valor, cantidad hasta 65535)
                java.io.ByteArrayOutputStream rb = new java.io.ByteArrayOutputStream();
                int i = 0, n = z.m.length;
                while (i < n) {
                    byte v = z.m[i];
                    int j = i;
                    while (j < n && z.m[j] == v && j - i < 65535) j++;
                    rb.write(v);
                    rb.write((j - i) >> 8);
                    rb.write((j - i) & 255);
                    i = j;
                }
                byte[] r = rb.toByteArray();
                o.writeInt(r.length);
                o.write(r);
            }
            o.flush();
        } catch (java.io.IOException e) {
            return null;
        }
        return bo.toByteArray();
    }

    private static void writeStyle(java.io.DataOutputStream o, Style s) throws java.io.IOException {
        int[] v = s.pack();
        o.writeInt(v.length);
        for (int x : v) o.writeInt(x);
    }

    private static Style readStyle(java.io.DataInputStream in) throws java.io.IOException {
        int n = in.readInt();
        if (n < 0 || n > 64) throw new java.io.IOException("estilo");
        int[] v = new int[n];
        for (int i = 0; i < n; i++) v[i] = in.readInt();
        return Style.unpack(v);
    }

    /** Resultado de decode. */
    public static final class Saved {
        public final List<Zone> zones = new ArrayList<Zone>();
        public Style current = new Style();
        public final List<Group> palette = new ArrayList<Group>();
    }

    public static Saved decode(byte[] data, int W, int H) {
        Saved sv = new Saved();
        if (data == null) return sv;
        try {
            java.io.DataInputStream in = new java.io.DataInputStream(new java.io.ByteArrayInputStream(data));
            if (in.readInt() != 0x5A4E3031) return sv;
            sv.current = readStyle(in);
            int np = in.readInt();
            if (np < 0 || np > 64) return sv;
            for (int i = 0; i < np; i++) {
                Group g = new Group();
                g.shadow = in.readInt(); g.base = in.readInt(); g.light = in.readInt(); g.count = in.readInt();
                sv.palette.add(g);
            }
            int nz = in.readInt();
            if (nz < 0 || nz > 10000) return sv;
            for (int k = 0; k < nz; k++) {
                int x = in.readInt(), y = in.readInt(), w = in.readInt(), h = in.readInt();
                Style s = readStyle(in);
                int len = in.readInt();
                if (w <= 0 || h <= 0 || (long) w * h > (long) W * H || len < 0 || len > 3L * w * h + 3) throw new java.io.IOException("zona");
                byte[] r = new byte[len];
                in.readFully(r);
                byte[] m = new byte[w * h];
                int p = 0;
                for (int i = 0; i + 2 < len; i += 3) {
                    int cnt = ((r[i + 1] & 0xFF) << 8) | (r[i + 2] & 0xFF);
                    for (int j = 0; j < cnt && p < m.length; j++) m[p++] = r[i];
                }
                sv.zones.add(new Zone(x, y, w, h, m, s));
            }
        } catch (java.io.IOException e) {
            // lo que se pudo leer queda
        }
        return sv;
    }
}
