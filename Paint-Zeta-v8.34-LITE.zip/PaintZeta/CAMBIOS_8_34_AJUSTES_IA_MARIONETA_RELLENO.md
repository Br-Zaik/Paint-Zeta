# Paint Zeta v8.34 — Arreglos de tus 5 capturas (sobre la v8.33)

## 1. Editor de la IA (captura 1)

- **Toque con 2 dedos = Deshacer; toque con 3 dedos = Rehacer.** Es igual que en la pantalla principal: un toque corto, sin arrastrar.
- **Fuerza del pincel** (nueva barra de abajo, icono de opacidad):
  - Quitar o Anadir con menos fuerza lo hace a medias; por ejemplo, al 50 % deja la mitad.
  - Repasar en el mismo trazo no suma mas que esa fuerza.
  - Se recuerda para la proxima vez.
- **Ver lo quitado** (boton de opacidad arriba): cambia entre oculto, 30 % y 60 %.
  - Lo que borraste se ve tenue y rojizo; asi sabes que devolver con Anadir.
  - Es solo para ver: no se exporta.

## 2. Barra de Borrar fondo (captura 2)

- **El boton de la IA ya no queda marcado.**
  - Es un boton que abre el recorte, no una herramienta.
  - Ahora tiene el mismo fondo gris que los demas, y una rayita lo separa de las herramientas manuales.
  - Lo marcado en azul es solo la herramienta manual que estas usando: Balde, Pincel protegido, Borrador o Restaurar.
- **Para trabajar a mano** tocas esas herramientas como siempre. La IA solo corre cuando tocas su boton.

## 3. Marioneta (captura 3)

- **La malla se ve de fabrica**: los triangulos que se mueven y se estiran.
  - El boton del ojo de la barra la sigue ocultando o mostrando.
  - Antes venia oculta y parecia que no habia malla.
- **Menos lag al arrastrar.** Mientras mueves un punto, la vista previa usa una muestra por pixel y la mitad de la resolucion de pantalla. Al soltar se vuelve a pintar con la calidad completa, que es la misma del resultado final.
  - Medido en este PC con tu recorte de 2 personajes (1048 puntos de malla):
    - vista previa por cuadro: de 204 ms a 16 ms;
    - mover un punto: 1,2 ms, que no cambio.
- **La capa "Recorte IA" ya no guarda bruma invisible** (alfa 1-2) en todo el lienzo. Queda con su tamano real, y Marioneta, Mover y el guardado no cargan con la imagen entera.

## 4 y 5. Relleno sobre la capa recortada (capturas 4 y 5)

- **Que pasaba**: al rellenar el emblema blanco de la carta, el filo "seguia la linea" hasta 4 px aunque alrededor no hubiera una linea, sino el gris de la carta con su sombra diagonal. Esos pixeles grises recibian algo de rojo y quedaba un halo rojizo "encima" de la carta.
  - Se reprodujo en el PC con tu misma imagen y en el mismo punto.
- **Arreglo** (en `core/BucketFill.java`): el filo solo avanza mientras el color baja de verdad, es decir, en la rampa del antialias. En un fondo con degradado suave se detiene.
  - Resultado: borde limpio, sin halo.
  - Contra una linea negra el antialias se conserva igual que antes (comprobado a 800 %).
- Imagen: `docs/qa834/relleno_carta_antes_despues.png`.

## Archivos cambiados

- `ai/AiCutSession.java`: fuerza del pincel; exportar sin bruma.
- `view/AiCutView.java`: toques de 2 y 3 dedos; ver lo quitado.
- `AiCutFlow.java`: barra de Fuerza, boton Ver lo quitado, Deshacer/Rehacer con dedos.
- `MainActivity.java`: boton IA sin marcar, separador.
- `view/CanvasView.java`: malla visible de fabrica; vista previa rapida de Marioneta.
- `core/TriWarp.java` y `core/PuppetSession.java`: render rapido para el arrastre.
- `core/BucketFill.java`: filo del relleno.
- `app/build.gradle`: version 8.34 (72).
- `.github` sin cambios.

## Pruebas (PC, no telefono)

- **P11 sesion de la IA**: 13 de 13 OK. Incluye la prueba nueva "fuerza 50 %: alfa 127" y "exportar = vista previa".
- **P1 imagen a**: las barras se quitan y los personajes quedan intactos, igual que en la v8.33.
- **Marioneta**: se midio el rendimiento en el PC (cifras arriba). El cambio de malla y el gesto en la pantalla no se pudieron probar en un telefono.
- **Relleno**: emblema de la carta antes y despues, mas la cara con linea negra a 800 %, sin cambio.
- **Compila** la app entera contra android.jar: 728 clases.
- **No se probo en un telefono.**
