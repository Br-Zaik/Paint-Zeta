package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Operaciones sobre mascaras de 1 byte por pixel.
 * Todo separable (primero horizontal, luego vertical) para no morir
 * de lentitud en imagenes grandes.
 */
public final class MaskOps {

    private MaskOps() {
    }

    /** Expandir el borde. */
    public static void dilate(byte[] m, int w, int h, int r) {
        if (r <= 0) return;
        maxFilter(m, w, h, r);
    }

    /** Contraer el borde. */
    public static void erode(byte[] m, int w, int h, int r) {
        if (r <= 0) return;
        invert(m);
        maxFilter(m, w, h, r);
        invert(m);
    }

    /** Suavizar el borde (feather). Deja alfa intermedio, no escalonado. */
    public static void feather(byte[] m, int w, int h, int r) {
        if (r <= 0) return;
        boxBlur(m, w, h, r);
        boxBlur(m, w, h, r);
    }

    public static void invert(byte[] m) {
        for (int i = 0; i < m.length; i++) {
            m[i] = (byte) (255 - (m[i] & 0xFF));
        }
    }

    /** Corta los valores intermedios: todo o nada. */
    public static void threshold(byte[] m, int level) {
        for (int i = 0; i < m.length; i++) {
            m[i] = (byte) ((m[i] & 0xFF) >= level ? 255 : 0);
        }
    }

    public static void copyInto(byte[] dst, byte[] src) {
        System.arraycopy(src, 0, dst, 0, src.length);
    }

    /**
     * Pincel circular con borde suave. Devuelve el rectangulo tocado.
     * value 255 = pintar seleccion, 0 = borrar.
     */
    public static Rect stamp(byte[] m, int w, int h, float cx, float cy, float radius,
                             float hardness, boolean erase) {
        int x0 = (int) Math.floor(cx - radius) - 1;
        int y0 = (int) Math.floor(cy - radius) - 1;
        int x1 = (int) Math.ceil(cx + radius) + 1;
        int y1 = (int) Math.ceil(cy + radius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return null;

        float inner = radius * hardness;
        float band = Math.max(1f, radius - inner);

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > radius) continue;
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (a <= 0f) continue;
                int cur = m[row + x] & 0xFF;
                int add = (int) (a * 255f);
                if (erase) {
                    int v = cur - add;
                    m[row + x] = (byte) (v < 0 ? 0 : v);
                } else {
                    if (add > cur) m[row + x] = (byte) add;
                }
            }
        }
        return new Rect(x0, y0, x1, y1);
    }

    private static void maxFilter(byte[] m, int w, int h, int r) {
        byte[] tmp = new byte[m.length];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int a = x - r < 0 ? 0 : x - r;
                int b = x + r >= w ? w - 1 : x + r;
                int max = 0;
                for (int i = a; i <= b; i++) {
                    int v = m[row + i] & 0xFF;
                    if (v > max) max = v;
                }
                tmp[row + x] = (byte) max;
            }
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int a = y - r < 0 ? 0 : y - r;
                int b = y + r >= h ? h - 1 : y + r;
                int max = 0;
                for (int i = a; i <= b; i++) {
                    int v = tmp[i * w + x] & 0xFF;
                    if (v > max) max = v;
                }
                m[y * w + x] = (byte) max;
            }
        }
    }

    private static void boxBlur(byte[] m, int w, int h, int r) {
        byte[] tmp = new byte[m.length];
        int win = r * 2 + 1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            int sum = 0;
            for (int i = -r; i <= r; i++) {
                sum += m[row + clamp(i, w)] & 0xFF;
            }
            for (int x = 0; x < w; x++) {
                tmp[row + x] = (byte) (sum / win);
                sum -= m[row + clamp(x - r, w)] & 0xFF;
                sum += m[row + clamp(x + r + 1, w)] & 0xFF;
            }
        }
        for (int x = 0; x < w; x++) {
            int sum = 0;
            for (int i = -r; i <= r; i++) {
                sum += tmp[clamp(i, h) * w + x] & 0xFF;
            }
            for (int y = 0; y < h; y++) {
                m[y * w + x] = (byte) (sum / win);
                sum -= tmp[clamp(y - r, h) * w + x] & 0xFF;
                sum += tmp[clamp(y + r + 1, h) * w + x] & 0xFF;
            }
        }
    }

    private static int clamp(int v, int max) {
        if (v < 0) return 0;
        if (v >= max) return max - 1;
        return v;
    }
}
