package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.view.CanvasView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements CanvasView.Callback {

    private static final int[] PALETTE = {
            0xFF000000, 0xFF444444, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF, 0xFF7A4A2B,
            0xFFE05A5A, 0xFFFF7A45, 0xFFFFB03A, 0xFFFFE05C, 0xFFB5E05A, 0xFF4FC66B,
            0xFF3DD6C0, 0xFF4DA3FF, 0xFF3D6BFF, 0xFF7B5CFF, 0xFFB558FF, 0xFFFF6FC3,
            0xFFFFE0C4, 0xFFF5C9A6, 0xFFD9A377, 0xFF9C6B4A, 0xFF2B2B3A, 0xFF1B3358
    };

    private CanvasView canvas;
    private TextView status;
    private TextView sliderLabel;
    private SeekBar slider;

    private ActivityResultLauncher<String> openImage;
    private ActivityResultLauncher<String> createZip;
    private ActivityResultLauncher<String> createPng;
    private ActivityResultLauncher<String> createProject;
    private ActivityResultLauncher<String[]> openProject;

    private static final String AUTOSAVE = "autoguardado.acut";

    private byte[] pendingPngMask;
    private String lastError;
    private int lastExportCount;
    private int outW, outH;
    private boolean saving = false;
    private ProjectIO.Loaded loaded;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        canvas = findViewById(R.id.canvas);
        status = findViewById(R.id.status);
        sliderLabel = findViewById(R.id.sliderLabel);
        slider = findViewById(R.id.slider);
        canvas.setCallback(this);

        openImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) loadImage(uri);
                    }
                });

        createZip = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/zip"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportZip(uri);
                    }
                });

        createPng = registerForActivityResult(new ActivityResultContracts.CreateDocument("image/png"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportPng(uri);
                    }
                });

        createProject = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) saveProjectTo(uri);
                    }
                });

        openProject = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) openProjectFrom(uri);
                    }
                });

        tool(R.id.btnWand, CanvasView.MODE_WAND);
        tool(R.id.btnBrush, CanvasView.MODE_BRUSH);
        tool(R.id.btnEraser, CanvasView.MODE_ERASER);
        tool(R.id.btnLasso, CanvasView.MODE_LASSO);
        tool(R.id.btnClone, CanvasView.MODE_CLONE);
        tool(R.id.btnPaint, CanvasView.MODE_PAINT);
        tool(R.id.btnBucket, CanvasView.MODE_BUCKET);
        tool(R.id.btnPicker, CanvasView.MODE_PICKER);
        tool(R.id.btnPan, CanvasView.MODE_PAN);

        click(R.id.btnOpen, new Runnable() {
            public void run() {
                openImage.launch("image/*");
            }
        });
        click(R.id.btnProject, new Runnable() {
            public void run() {
                projectDialog();
            }
        });
        click(R.id.btnFit, new Runnable() {
            public void run() {
                if (needProject()) canvas.fit();
            }
        });
        click(R.id.btnUndo, new Runnable() {
            public void run() {
                canvas.doUndo();
                updateUi();
            }
        });
        click(R.id.btnRedo, new Runnable() {
            public void run() {
                canvas.doRedo();
                updateUi();
            }
        });
        click(R.id.btnColor, new Runnable() {
            public void run() {
                colorDialog();
            }
        });
        click(R.id.btnSmart, new Runnable() {
            public void run() {
                canvas.setSmart(!canvas.isSmart());
                toast(canvas.isSmart()
                        ? "Pincel fino: se queda en el color que tocas y respeta la linea"
                        : "Pincel normal");
                updateUi();
            }
        });
        click(R.id.btnHard, new Runnable() {
            public void run() {
                hardnessDialog();
            }
        });
        click(R.id.btnRotate, new Runnable() {
            public void run() {
                rotateDialog();
            }
        });
        click(R.id.btnLineart, new Runnable() {
            public void run() {
                lineArtDialog();
            }
        });
        click(R.id.btnGlobal, new Runnable() {
            public void run() {
                canvas.setWandGlobal(!canvas.isWandGlobal());
                updateUi();
            }
        });
        click(R.id.btnSub, new Runnable() {
            public void run() {
                canvas.setSubtract(!canvas.isSubtract());
                updateUi();
            }
        });
        click(R.id.btnEdge, new Runnable() {
            public void run() {
                edgeDialog();
            }
        });
        click(R.id.btnInvert, new Runnable() {
            public void run() {
                if (needProject()) canvas.invertSelection();
            }
        });
        click(R.id.btnClear, new Runnable() {
            public void run() {
                if (needProject()) canvas.clearSelection();
            }
        });
        click(R.id.btnLayerAdd, new Runnable() {
            public void run() {
                addLayerFromSelection();
            }
        });
        click(R.id.btnLayers, new Runnable() {
            public void run() {
                layersDialog();
            }
        });
        click(R.id.btnExport, new Runnable() {
            public void run() {
                exportDialog();
            }
        });

        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                applySlider(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });

        updateUi();
        offerRecovery();
    }

    @Override
    protected void onPause() {
        super.onPause();
        autosave(false);
    }

    private void tool(int id, final int mode) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canvas.setMode(mode);
                if (mode == CanvasView.MODE_CLONE) canvas.resetCloneSource();
                if (mode == CanvasView.MODE_PICKER) toast("Toca la imagen para tomar ese color");
                syncSlider();
                updateUi();
            }
        });
    }

    private void click(int id, final Runnable r) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
    }

    // ------------------------------------------------------------------
    // Imagen
    // ------------------------------------------------------------------

    private void loadImage(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            if (bmp == null) {
                toast("No se pudo leer la imagen");
                return;
            }
            canvas.setProject(new Project(bmp));
            toast("Cargada a " + bmp.getWidth() + " x " + bmp.getHeight());
            updateUi();
        } catch (OutOfMemoryError err) {
            toast("La imagen es demasiado grande para la memoria del telefono");
        } catch (Exception ex) {
            toast("Error al abrir: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // Capas
    // ------------------------------------------------------------------

    private void addLayerFromSelection() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        if (!p.hasSelection()) {
            toast("Primero selecciona una parte");
            return;
        }
        byte[] mask = new byte[p.selection.length];
        System.arraycopy(p.selection, 0, mask, 0, mask.length);
        p.layers.add(new Layer(p.nextLayerName(), mask));
        canvas.clearSelection();
        toast("Capa creada: " + p.layers.get(p.layers.size() - 1).name);
        updateUi();
        autosave(false);
    }

    private void layersDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        if (p.layers.isEmpty()) {
            toast("Todavia no hay capas");
            return;
        }
        final String[] items = new String[p.layers.size()];
        for (int i = 0; i < items.length; i++) {
            Layer l = p.layers.get(i);
            items[i] = (l.visible ? "[visible] " : "[oculta]  ") + l.name;
        }
        new AlertDialog.Builder(this)
                .setTitle("Capas (" + items.length + ")")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        layerOptions(which);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void layerOptions(final int index) {
        final Project p = canvas.getProject();
        final Layer l = p.layers.get(index);
        final String[] opts = {
                l.visible ? "Ocultar" : "Mostrar",
                "Subir (va mas adelante)",
                "Bajar (va mas atras)",
                "Cargar a la seleccion",
                "Renombrar",
                "Exportar solo esta capa",
                "Eliminar"
        };
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(opts, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                l.visible = !l.visible;
                                updateUi();
                                break;
                            case 1:
                                move(index, -1);
                                break;
                            case 2:
                                move(index, 1);
                                break;
                            case 3:
                                canvas.loadSelection(l.mask);
                                toast("Capa cargada en la seleccion");
                                break;
                            case 4:
                                renameDialog(l);
                                break;
                            case 5:
                                pendingPngMask = l.mask;
                                createPng.launch(l.name + ".png");
                                break;
                            default:
                                p.layers.remove(index);
                                toast("Capa eliminada");
                                updateUi();
                                break;
                        }
                    }
                })
                .show();
    }

    /** Cambia el orden de la capa. El orden manda en el numero del PNG exportado. */
    private void move(int index, int delta) {
        Project p = canvas.getProject();
        int target = index + delta;
        if (target < 0 || target >= p.layers.size()) {
            toast("Ya esta en el extremo");
            return;
        }
        Layer a = p.layers.get(index);
        p.layers.set(index, p.layers.get(target));
        p.layers.set(target, a);
        toast("Orden cambiado");
        layersDialog();
    }

    private void renameDialog(final Layer l) {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        in.setText(l.name);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la capa")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        if (!s.isEmpty()) l.name = s;
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Color
    // ------------------------------------------------------------------

    private void colorDialog() {
        final int[] chosen = {canvas.getColor()};

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final View preview = new View(this);
        LinearLayout.LayoutParams pvp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        pvp.bottomMargin = dp(10);
        preview.setLayoutParams(pvp);
        preview.setBackgroundColor(chosen[0]);
        root.addView(preview);

        final SeekBar sr = new SeekBar(this);
        final SeekBar sg = new SeekBar(this);
        final SeekBar sb = new SeekBar(this);
        sr.setMax(255);
        sg.setMax(255);
        sb.setMax(255);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        root.addView(grid);

        LinearLayout row = null;
        for (int i = 0; i < PALETTE.length; i++) {
            if (i % 6 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row);
            }
            final int c = PALETTE[i];
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            sw.setLayoutParams(lp);
            sw.setBackgroundColor(c);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chosen[0] = c;
                    preview.setBackgroundColor(c);
                    sr.setProgress(Color.red(c));
                    sg.setProgress(Color.green(c));
                    sb.setProgress(Color.blue(c));
                }
            });
            row.addView(sw);
        }

        SeekBar.OnSeekBarChangeListener rgb = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                if (!fromUser) return;
                chosen[0] = Color.rgb(sr.getProgress(), sg.getProgress(), sb.getProgress());
                preview.setBackgroundColor(chosen[0]);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        };

        addLabeled(root, "Rojo", sr, Color.red(chosen[0]), rgb);
        addLabeled(root, "Verde", sg, Color.green(chosen[0]), rgb);
        addLabeled(root, "Azul", sb, Color.blue(chosen[0]), rgb);

        new AlertDialog.Builder(this)
                .setTitle("Color para pintar")
                .setView(scroll)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setColor(chosen[0]);
                        updateUi();
                    }
                })
                .setNeutralButton("Tomar de la imagen", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setMode(CanvasView.MODE_PICKER);
                        toast("Toca la imagen para tomar ese color");
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void addLabeled(LinearLayout root, String name, SeekBar bar, int value,
                            SeekBar.OnSeekBarChangeListener l) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(l);
        root.addView(bar);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------
    // Dialogos
    // ------------------------------------------------------------------

    private void hardnessDialog() {
        final String[] items = {"Muy suave 20%", "Suave 40%", "Media 70%", "Dura 100%"};
        final float[] vals = {0.2f, 0.4f, 0.7f, 1f};
        new AlertDialog.Builder(this)
                .setTitle("Dureza del pincel")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setHardness(vals[i]);
                        toast("Dureza " + items[i]);
                    }
                })
                .show();
    }

    private void rotateDialog() {
        if (!needProject()) return;
        final String[] items = {"Girar a la derecha", "Girar a la izquierda",
                "Voltear horizontal", "Voltear vertical"};
        new AlertDialog.Builder(this)
                .setTitle("Girar imagen")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.transform(i);
                    }
                })
                .show();
    }

    private void edgeDialog() {
        if (!needProject()) return;
        final String[] ops = {"Expandir borde", "Contraer borde", "Suavizar borde", "Endurecer borde"};
        new AlertDialog.Builder(this)
                .setTitle("Borde de la seleccion")
                .setItems(ops, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int kind) {
                        if (kind == 3) {
                            canvas.edgeOp(3, 0);
                            return;
                        }
                        final String[] radios = {"1 px", "2 px", "3 px", "5 px", "8 px", "12 px"};
                        final int[] vals = {1, 2, 3, 5, 8, 12};
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cuanto")
                                .setItems(radios, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int i) {
                                        canvas.edgeOp(kind, vals[i]);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    private void lineArtDialog() {
        if (!needProject()) return;
        if (canvas.isUseBarrier() && canvas.getProject().barrier != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Line art")
                    .setMessage("La barrera esta activa. La varita y el balde se detienen en las lineas.")
                    .setPositiveButton("Desactivar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.setUseBarrier(false);
                            updateUi();
                        }
                    })
                    .setNegativeButton("Recalcular", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            thresholdDialog();
                        }
                    })
                    .show();
            return;
        }
        thresholdDialog();
    }

    private void thresholdDialog() {
        final String[] items = {"Lineas muy oscuras (60)", "Oscuras (90)", "Normal (120)", "Tenues (160)"};
        final int[] vals = {60, 90, 120, 160};
        new AlertDialog.Builder(this)
                .setTitle("Que tan oscura es la linea")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int i) {
                        final String[] gaps = {"Sin cerrar huecos", "Cerrar 1 px", "Cerrar 2 px", "Cerrar 3 px"};
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cerrar huecos de la linea")
                                .setItems(gaps, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int g) {
                                        canvas.buildBarrier(vals[i], g);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    // ------------------------------------------------------------------
    // Exportar
    // ------------------------------------------------------------------

    private void exportDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        if (p.layers.isEmpty()) {
            toast("Crea al menos una capa antes de exportar");
            return;
        }
        final int[][] sizes = {
                {p.w, p.h},
                {Math.max(1, p.w / 2), Math.max(1, p.h / 2)},
                longSide(p, 1920),
                longSide(p, 1280)
        };
        final String[] items = new String[sizes.length];
        items[0] = "Original  " + sizes[0][0] + "x" + sizes[0][1];
        items[1] = "Mitad  " + sizes[1][0] + "x" + sizes[1][1];
        items[2] = "Lado largo 1920  " + sizes[2][0] + "x" + sizes[2][1];
        items[3] = "Lado largo 1280  " + sizes[3][0] + "x" + sizes[3][1];

        new AlertDialog.Builder(this)
                .setTitle("Tamano de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        outW = sizes[i][0];
                        outH = sizes[i][1];
                        createZip.launch("capas_anime.zip");
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Mantiene la proporcion para que todas las capas sigan cuadrando entre si. */
    private int[] longSide(Project p, int target) {
        int max = Math.max(p.w, p.h);
        if (max <= target) return new int[]{p.w, p.h};
        float f = target / (float) max;
        return new int[]{Math.max(1, Math.round(p.w * f)), Math.max(1, Math.round(p.h * f))};
    }

    private void doExportZip(final Uri uri) {
        final Project p = canvas.getProject();
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    lastExportCount = Exporter.exportZip(getContentResolver(), p, uri, true, outW, outH);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al exportar: " + lastError);
                else toast(lastExportCount + " PNG de " + outW + "x" + outH + " guardados en el ZIP");
            }
        });
    }

    private void doExportPng(final Uri uri) {
        final Project p = canvas.getProject();
        final byte[] mask = pendingPngMask;
        pendingPngMask = null;
        if (mask == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    Exporter.exportPng(getContentResolver(), p, mask, uri, p.w, p.h);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error: " + lastError);
                else toast("PNG guardado a " + p.w + " x " + p.h);
            }
        });
    }

    // ------------------------------------------------------------------
    // Guardar y abrir el proyecto
    // ------------------------------------------------------------------

    private void projectDialog() {
        final boolean has = canvas.getProject() != null;
        final String[] items = {
                "Guardar proyecto en un archivo",
                "Abrir un proyecto guardado",
                "Guardar ahora en la app"
        };
        new AlertDialog.Builder(this)
                .setTitle("Proyecto")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 1) {
                            openProject.launch(new String[]{"*/*"});
                            return;
                        }
                        if (!has) {
                            toast("Abre una imagen primero");
                            return;
                        }
                        if (i == 0) createProject.launch("proyecto.acut");
                        else autosave(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void saveProjectTo(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int color = canvas.getColor();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    ProjectIO.save(os, p, color);
                    if (os != null) os.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al guardar: " + lastError);
                else toast("Proyecto guardado con sus " + p.layers.size() + " capas");
            }
        });
    }

    private void openProjectFrom(final Uri uri) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    loaded = ProjectIO.load(is);
                    if (is != null) is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void recoverFrom(final File f) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileInputStream is = new FileInputStream(f);
                    loaded = ProjectIO.load(is);
                    is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void applyLoaded() {
        if (lastError != null) {
            toast("No se pudo abrir: " + lastError);
            return;
        }
        if (loaded == null || loaded.project == null) return;
        canvas.setProject(loaded.project);
        canvas.setColor(loaded.color);
        toast("Proyecto abierto: " + loaded.project.layers.size() + " capas");
        loaded = null;
        updateUi();
    }

    /**
     * Guardado automatico dentro de la app. Se dispara al crear una capa y
     * al salir, para que una llamada o que Android cierre la app no borre
     * media hora de trabajo.
     */
    private void autosave(final boolean notify) {
        final Project p = canvas.getProject();
        if (p == null || saving) return;
        saving = true;
        final int color = canvas.getColor();
        final File dest = new File(getFilesDir(), AUTOSAVE);
        final File tmp = new File(getFilesDir(), AUTOSAVE + ".tmp");
        if (notify) toast("Guardando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileOutputStream fo = new FileOutputStream(tmp);
                    ProjectIO.save(fo, p, color);
                    fo.close();
                    if (dest.exists() && !dest.delete()) throw new java.io.IOException("No se pudo reemplazar");
                    if (!tmp.renameTo(dest)) throw new java.io.IOException("No se pudo renombrar");
                    lastError = null;
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                saving = false;
                if (notify) {
                    if (lastError != null) toast("Error al guardar: " + lastError);
                    else toast("Guardado dentro de la app");
                }
            }
        });
    }

    private void offerRecovery() {
        final File f = new File(getFilesDir(), AUTOSAVE);
        if (!f.exists() || f.length() == 0) return;
        new AlertDialog.Builder(this)
                .setTitle("Trabajo sin cerrar")
                .setMessage("Se encontro el proyecto de la ultima vez. Quieres recuperarlo?")
                .setCancelable(false)
                .setPositiveButton("Recuperar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        recoverFrom(f);
                    }
                })
                .setNegativeButton("Empezar de cero", null)
                .show();
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    private boolean sliderIsTolerance() {
        int m = canvas.getMode();
        return m == CanvasView.MODE_WAND || m == CanvasView.MODE_BUCKET;
    }

    private void applySlider(int v) {
        if (sliderIsTolerance()) {
            canvas.setTolerance(v);
            sliderLabel.setText(String.format(Locale.US, "Tolerancia %d", v));
        } else {
            float size = 1 + v * 2.5f;
            canvas.setBrushSize(size);
            sliderLabel.setText(String.format(Locale.US, "Tamano %d px", (int) size));
        }
    }

    private void syncSlider() {
        if (sliderIsTolerance()) {
            slider.setProgress(canvas.getTolerance());
            sliderLabel.setText(String.format(Locale.US, "Tolerancia %d", canvas.getTolerance()));
        } else {
            slider.setProgress((int) ((canvas.getBrushSize() - 1) / 2.5f));
            sliderLabel.setText(String.format(Locale.US, "Tamano %d px", (int) canvas.getBrushSize()));
        }
    }

    private void updateUi() {
        Project p = canvas.getProject();
        StringBuilder sb = new StringBuilder();
        if (p == null) {
            sb.append(getString(R.string.open_hint));
        } else {
            sb.append(p.w).append("x").append(p.h);
            sb.append("  |  capas: ").append(p.layers.size());
            sb.append("  |  ").append(modeName());
            if (canvas.isSmart()) sb.append("  |  FINO");
            if (canvas.isWandGlobal()) sb.append("  |  GLOBAL");
            if (canvas.isSubtract()) sb.append("  |  RESTAR");
            if (canvas.isUseBarrier() && p.barrier != null) sb.append("  |  LINE ART");
        }
        status.setText(sb.toString());
        ((Button) findViewById(R.id.btnGlobal)).setText(canvas.isWandGlobal() ? "Global ON" : "Global");
        ((Button) findViewById(R.id.btnSub)).setText(canvas.isSubtract() ? "Restar ON" : "Restar");
        ((Button) findViewById(R.id.btnSmart)).setText(canvas.isSmart() ? "Fino ON" : "Fino");
        Button color = findViewById(R.id.btnColor);
        color.setBackgroundColor(canvas.getColor());
        color.setTextColor(luminance(canvas.getColor()) > 140 ? Color.BLACK : Color.WHITE);
    }

    private int luminance(int c) {
        return (Color.red(c) * 77 + Color.green(c) * 151 + Color.blue(c) * 28) >> 8;
    }

    private String modeName() {
        switch (canvas.getMode()) {
            case CanvasView.MODE_WAND:
                return "Varita";
            case CanvasView.MODE_BRUSH:
                return "Pincel";
            case CanvasView.MODE_ERASER:
                return "Borrador";
            case CanvasView.MODE_LASSO:
                return "Lazo";
            case CanvasView.MODE_CLONE:
                return "Clonar";
            case CanvasView.MODE_PAINT:
                return "Pintar";
            case CanvasView.MODE_BUCKET:
                return "Balde";
            case CanvasView.MODE_PICKER:
                return "Cuentagotas";
            default:
                return "Mano";
        }
    }

    private boolean needProject() {
        if (canvas.getProject() == null) {
            toast("Abre una imagen primero");
            return false;
        }
        return true;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------
    // CanvasView.Callback
    // ------------------------------------------------------------------

    @Override
    public void onBusy(boolean busy) {
        status.setAlpha(busy ? 0.5f : 1f);
        findViewById(R.id.btnExport).setEnabled(!busy);
    }

    @Override
    public void onChanged() {
        updateUi();
    }

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    @Override
    public void onColorPicked(int color) {
        updateUi();
        toast(String.format(Locale.US, "Color tomado #%06X", color & 0xFFFFFF));
    }
}
