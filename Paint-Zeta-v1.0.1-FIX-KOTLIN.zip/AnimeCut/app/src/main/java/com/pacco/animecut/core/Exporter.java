package com.pacco.animecut.core;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Exporta cada capa como PNG transparente dentro de un ZIP.
 * Todas las capas salen del MISMO tamano de lienzo, tanto si exportas a
 * resolucion original como si reduces, asi que en Alight Motion entran
 * alineadas sin tocar nada.
 *
 * El bitmap se rellena fila por fila para no cargar la imagen entera
 * duplicada en memoria.
 */
public final class Exporter {

    private Exporter() {
    }

    public static int exportZip(ContentResolver cr, Project p, Uri uri, boolean includeRest,
                                int outW, int outH) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");

        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os));
        zos.setLevel(1); // el PNG ya viene comprimido
        int count = 0;
        try {
            byte[] union = includeRest ? new byte[p.w * p.h] : null;
            int idx = 1;
            for (Layer l : p.layers) {
                if (!l.visible) continue;
                if (union != null) {
                    for (int i = 0; i < union.length; i++) {
                        int v = l.mask[i] & 0xFF;
                        if (v > (union[i] & 0xFF)) union[i] = (byte) v;
                    }
                }
                String name = String.format(Locale.US, "%02d_%s.png", idx++, safe(l.name));
                zos.putNextEntry(new ZipEntry(name));
                writePng(p, l.mask, false, outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            if (union != null && count > 0) {
                zos.putNextEntry(new ZipEntry("99_fondo_restante.png"));
                writePng(p, union, true, outW, outH, zos);
                zos.closeEntry();
                count++;
            }
            zos.finish();
        } finally {
            try {
                zos.close();
            } catch (IOException ignored) {
            }
        }
        return count;
    }

    /** Guarda una sola capa como PNG suelto. */
    public static void exportPng(ContentResolver cr, Project p, byte[] mask, Uri uri,
                                 int outW, int outH) throws IOException {
        OutputStream os = cr.openOutputStream(uri);
        if (os == null) throw new IOException("No se pudo abrir el destino");
        BufferedOutputStream bos = new BufferedOutputStream(os);
        try {
            writePng(p, mask, false, outW, outH, bos);
            bos.flush();
        } finally {
            try {
                bos.close();
            } catch (IOException ignored) {
            }
        }
    }

    private static void writePng(Project p, byte[] mask, boolean invert,
                                 int outW, int outH, OutputStream out) {
        if (outW <= 0 || outH <= 0 || (outW == p.w && outH == p.h)) {
            writeFull(p, mask, invert, out);
        } else {
            writeScaled(p, mask, invert, outW, outH, out);
        }
    }

    private static void writeFull(Project p, byte[] mask, boolean invert, OutputStream out) {
        Bitmap bmp = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        int[] row = new int[p.w];
        for (int y = 0; y < p.h; y++) {
            int off = y * p.w;
            for (int x = 0; x < p.w; x++) {
                int a = mask[off + x] & 0xFF;
                if (invert) a = 255 - a;
                row[x] = (a << 24) | (p.pixels[off + x] & 0x00FFFFFF);
            }
            bmp.setPixels(row, 0, p.w, 0, y, p.w, 1);
        }
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        bmp.recycle();
    }

    /**
     * Reduce promediando el bloque de pixeles que cae en cada pixel de salida.
     * El color se promedia pesado por el alfa para que el borde no arrastre
     * el color de lo que quedo transparente.
     */
    private static void writeScaled(Project p, byte[] mask, boolean invert,
                                    int outW, int outH, OutputStream out) {
        Bitmap bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        int[] row = new int[outW];
        for (int y = 0; y < outH; y++) {
            int sy0 = (int) ((long) y * p.h / outH);
            int sy1 = (int) ((long) (y + 1) * p.h / outH);
            if (sy1 <= sy0) sy1 = sy0 + 1;
            if (sy1 > p.h) sy1 = p.h;
            for (int x = 0; x < outW; x++) {
                int sx0 = (int) ((long) x * p.w / outW);
                int sx1 = (int) ((long) (x + 1) * p.w / outW);
                if (sx1 <= sx0) sx1 = sx0 + 1;
                if (sx1 > p.w) sx1 = p.w;

                long sumA = 0, sumR = 0, sumG = 0, sumB = 0;
                int n = 0;
                for (int sy = sy0; sy < sy1; sy++) {
                    int off = sy * p.w;
                    for (int sx = sx0; sx < sx1; sx++) {
                        int i = off + sx;
                        int a = mask[i] & 0xFF;
                        if (invert) a = 255 - a;
                        int c = p.pixels[i];
                        sumA += a;
                        sumR += (long) ((c >> 16) & 0xFF) * a;
                        sumG += (long) ((c >> 8) & 0xFF) * a;
                        sumB += (long) (c & 0xFF) * a;
                        n++;
                    }
                }
                if (n == 0 || sumA == 0) {
                    row[x] = 0;
                } else {
                    int a = (int) (sumA / n);
                    int r = (int) (sumR / sumA);
                    int g = (int) (sumG / sumA);
                    int b = (int) (sumB / sumA);
                    row[x] = (a << 24) | (r << 16) | (g << 8) | b;
                }
            }
            bmp.setPixels(row, 0, outW, 0, y, outW, 1);
        }
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        bmp.recycle();
    }

    private static String safe(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c) || c == '_' || c == '-') sb.append(c);
            else sb.append('_');
        }
        String r = sb.toString();
        return r.isEmpty() ? "capa" : r;
    }
}
