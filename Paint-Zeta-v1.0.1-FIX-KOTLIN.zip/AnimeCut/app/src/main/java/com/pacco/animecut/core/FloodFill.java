package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Varita magica. Relleno por lineas (scanline), que es O(N) sobre los
 * pixeles de la region y no revienta la pila como la version recursiva.
 * Si hay barrera de line art, el relleno se detiene en las lineas negras,
 * igual que el "close gap" de Clip Studio.
 */
public final class FloodFill {

    private FloodFill() {
    }

    /** Relleno contiguo desde un punto. Devuelve el rectangulo modificado. */
    public static Rect contiguous(int[] px, int w, int h, byte[] out, byte[] barrier,
                                  int seedX, int seedY, int tolerance, boolean subtract) {
        if (seedX < 0 || seedY < 0 || seedX >= w || seedY >= h) return null;
        int seed = seedY * w + seedX;
        if (barrier != null && barrier[seed] != 0) return null;

        final int target = px[seed];
        final byte value = (byte) (subtract ? 0 : 255);

        boolean[] done = new boolean[w * h];
        int[] stack = new int[4096];
        int sp = 0;
        stack[sp++] = seed;

        int minX = seedX, maxX = seedX, minY = seedY, maxY = seedY;

        while (sp > 0) {
            int idx = stack[--sp];
            if (done[idx]) continue;

            int y = idx / w;
            int x = idx - y * w;
            int row = y * w;

            int x1 = x;
            while (x1 >= 0 && ok(px, done, barrier, row + x1, target, tolerance)) x1--;
            x1++;
            int x2 = x;
            while (x2 < w && ok(px, done, barrier, row + x2, target, tolerance)) x2++;
            x2--;
            if (x2 < x1) continue;

            for (int i = x1; i <= x2; i++) {
                done[row + i] = true;
                out[row + i] = value;
            }

            if (x1 < minX) minX = x1;
            if (x2 > maxX) maxX = x2;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;

            if (y > 0) {
                int up = row - w;
                boolean run = false;
                for (int i = x1; i <= x2; i++) {
                    boolean good = ok(px, done, barrier, up + i, target, tolerance);
                    if (good && !run) {
                        if (sp == stack.length) stack = grow(stack);
                        stack[sp++] = up + i;
                        run = true;
                    } else if (!good) {
                        run = false;
                    }
                }
            }
            if (y < h - 1) {
                int dn = row + w;
                boolean run = false;
                for (int i = x1; i <= x2; i++) {
                    boolean good = ok(px, done, barrier, dn + i, target, tolerance);
                    if (good && !run) {
                        if (sp == stack.length) stack = grow(stack);
                        stack[sp++] = dn + i;
                        run = true;
                    } else if (!good) {
                        run = false;
                    }
                }
            }
        }
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** Selecciona TODOS los pixeles de ese color en la imagen, no solo los pegados. */
    public static Rect global(int[] px, int w, int h, byte[] out,
                              int seedX, int seedY, int tolerance, boolean subtract) {
        if (seedX < 0 || seedY < 0 || seedX >= w || seedY >= h) return null;
        final int target = px[seedY * w + seedX];
        final byte value = (byte) (subtract ? 0 : 255);
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (close(px[row + x], target, tolerance)) {
                    out[row + x] = value;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    private static boolean ok(int[] px, boolean[] done, byte[] barrier, int idx,
                              int target, int tol) {
        if (done[idx]) return false;
        if (barrier != null && barrier[idx] != 0) return false;
        return close(px[idx], target, tol);
    }

    /** Compara por el canal que mas se aleja. Tolerancia 0 = color identico. */
    /** Publico para que el pincel fino pueda usar el mismo criterio de color. */
    public static boolean similar(int a, int b, int tol) {
        return close(a, b, tol);
    }

    private static boolean close(int a, int b, int tol) {
        int dr = ((a >> 16) & 0xFF) - ((b >> 16) & 0xFF);
        int dg = ((a >> 8) & 0xFF) - ((b >> 8) & 0xFF);
        int db = (a & 0xFF) - (b & 0xFF);
        if (dr < 0) dr = -dr;
        if (dg < 0) dg = -dg;
        if (db < 0) db = -db;
        int max = dr > dg ? dr : dg;
        if (db > max) max = db;
        return max <= tol;
    }

    private static int[] grow(int[] s) {
        int[] n = new int[s.length * 2];
        System.arraycopy(s, 0, n, 0, s.length);
        return n;
    }
}
