package com.pacco.animecut.core;

/**
 * Una capa = una mascara de opacidad del mismo tamano que la imagen original.
 * 1 byte por pixel (0 = transparente, 255 = opaco). Ocupa 4 veces menos
 * memoria que guardar un bitmap ARGB completo por capa.
 */
public class Layer {

    public String name;
    public boolean visible = true;
    public byte[] mask;

    public Layer(String name, byte[] mask) {
        this.name = name;
        this.mask = mask;
    }
}
