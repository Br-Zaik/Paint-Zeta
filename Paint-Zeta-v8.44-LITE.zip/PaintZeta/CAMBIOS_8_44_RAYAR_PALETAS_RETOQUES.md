# Paint Zeta v8.44 — Rayar partes, paletas de personaje y retoques (sobre la v8.43)

Las 4 mejoras de Colorear fácil, más una extra para los toques finales.

## Cómo se usa

Menú ⋮ → **Colorear fácil**. En el **Paso 1** ahora hay dos formas:

- **Tocar zonas** (como antes): toca un color, toca una parte, ✓.
- **Rayar partes** (NUEVO, recomendado para colorear todo):
  1. Toca un color de la paleta (por ejemplo "Pelo").
  2. Haz un rayón en el pelo. Cambia a "Piel" y raya la cara, el cuello y las manos. Sigue igual con la ropa y el fondo.
  3. Lo que no quieras pintar (ojos blancos, fondo blanco) se raya con **No pintar**.
  4. Toca **✓** abajo (o **Siguiente**). **Toda la imagen** se reparte entre tus rayones: el límite cae justo sobre la línea negra y no quedan pedacitos grises.
  - Abajo: el color actual, No pintar, Borrar rayones, Borrar todos y ✓.

**Paletas** (Paso 1, toca "Paleta: ..."):

- **Básica anime**: pieles, pelos, colores de ropa, ojos.
- **Horikita**: pelo negro azulado, piel, ojos rojos, saco rojo, camisa, moño azul, falda blanca, medias negras, zapatos marrones.
- **Ayanokouji**: pelo castaño, piel, ojos, saco rojo, camisa, corbata azul oscuro, pantalón gris oscuro, zapatos.
- **Fondos**: cielo, pared, piso, madera, árboles, edificio, metal, noche.
- **Tus paletas**: en el Paso 3, **Guardar paleta** guarda los colores de la obra con un nombre.
- Cada color tiene su nombre abajo, para saber qué es cada uno.

**Paso 3 (toques finales):**

- **Pincel de retoque**: capa arriba de todo y Brocha. Para rubor, brillos en ojos y pelo. No se borra al cambiar las sombras.
- **Sombra a mano**: capa en Multiplicar, suave, con un color de sombra lila. Para sombras extra donde quieras.
- **Guardar paleta**.
- **Brillo y fondo** y **Cambiar una zona**, como antes.

## YA EXISTÍA (se reutilizó, no se duplicó)

- **Separar** (rayones, v8.33): el reparto de rayones. Ahora también sirve para colorear.
- **Color por zonas** (v8.40): sombra y luz desde los grises del B/N.
- **Colorear fácil** (v8.43): la tarjeta de pasos.
- Capas, modos, Brocha y Deshacer.

## MODIFICADO

- **Colorear fácil, color de las partes** (ajustes automáticos):
  - **la piel ya no queda blanca**: en la piel lo blanco del dibujo también toma color (antes la cara salía casi blanca);
  - **ropa clara lisa**: camisa y falda blanca sin manchitas de la trama;
  - **colores muy oscuros** (pelo negro, corbata azul oscuro) tiñen también lo negro;
  - en ropa de color, **los bordes blancos se quedan blancos** (el vivo blanco del saco).
- **Separar** (el de siempre, desde las herramientas) no cambia: al elegirlo se apaga Rayar partes.
- **Versión**: 8.44 (código 82).

## NUEVO

- Rayar partes, paletas (4 de la app + las tuyas), Pincel de retoque y Sombra a mano.

## PENDIENTE

- **Probar en tu teléfono**: la tarjeta con las dos formas, la barra de Rayar partes, las paletas y las capas de retoque. Aquí no hay emulador.
- **Máximo 11 colores por vez** en Rayar partes. Si necesitas más: toca ✓, y luego raya más partes con otros colores.
- **Si un rayón cae en la parte equivocada, el color se escapa**: Deshacer, borra ese rayón y raya más cerca de la parte. Rayones cerca de los bordes ayudan.
- **Los colores de los personajes** vienen de las imágenes que me pasaste y de una ficha en internet de Horikita. Cámbialos si no te gustan: Más colores o De la referencia.

## Registro de pruebas

### Pruebas ejecutadas de verdad en PC

Con el código de la app (Separar + Color por zonas + los ajustes automáticos nuevos) y tus 4 imágenes de Horikita y Ayanokouji:

- colores de las paletas;
- la imagen entera repartida entre los rayones en 0,2–0,4 s y pintada en 0,5–0,8 s en el PC;
- resultado en v844_rayar_partes_resultado.jpg.

**Fallo encontrado y corregido:** con "lo blanco toma color" en todo, el borde blanco del saco salía rojo. Ahora solo pasa en la piel y en colores claros.

**Compilación**: todo el código compila contra el Android real (android.jar 34).

### Solo compilado, pendiente en tu teléfono

- La interfaz: la tarjeta, la barra de Rayar, las paletas y Guardar paleta.
- Dibujar rayones con el dedo y la vista previa de colores mientras rayas.
