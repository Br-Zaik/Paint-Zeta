package com.pacco.animecut.ai;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * v8.39 MODO AHORRO de la IA: una copia del MISMO modelo que mira la imagen a 768, 640 o 512 px
 * en vez de 1024. Gasta mucha menos memoria (medido en PC con ONNX Runtime 1.20: 1013 MB a 1024,
 * ~600 a 768, ~460 a 640, ~350 a 512) y el recorte sale casi igual (IoU 0,99 en personajes; en
 * una portada llena de letras, 0,94).
 *
 * El modelo (isnetis.onnx) es todo convoluciones; lo unico atado a 1024 es:
 *  - el tamano de entrada y salida (1x3x1024x1024 y 1x1x1024x1024),
 *  - los 34 "Resize" con tamanos fijos (1,C,h,w) guardados como int64 crudos,
 *  - las 354 "value_info" (formas de ayuda; no hacen falta para correr).
 * Se copia el archivo y se cambian esos bytes EN SU LUGAR (mismo largo): h,w * S/1024, la forma
 * de entrada/salida, y las value_info pasan a un campo reservado que ONNX ignora. No se baja nada
 * nuevo ni se cambian los pesos. Java puro (sin Android): lo usan la app y las pruebas de PC.
 */
public final class ModelResize {
    private ModelResize() { }

    /** Tamanos del modo ahorro (de mas detalle a menos memoria). */
    public static final int[] SIZES = {1024, 768, 640, 512};

    /** Archivo de la copia para el lado S (S = 1024 es el original). */
    public static File fileFor(File original, int S) {
        if (S == 1024) return original;
        String n = original.getName();
        int dot = n.lastIndexOf('.');
        String base = dot > 0 ? n.substring(0, dot) : n;
        return new File(original.getParentFile(), base + "_" + S + (dot > 0 ? n.substring(dot) : ""));
    }

    /** Marca de "copia lista y completa" (largo del original y S). */
    private static File okFile(File copy) { return new File(copy.getPath() + ".ok"); }

    /**
     * Devuelve la copia para S (la crea si falta). Tarda unos segundos la primera vez (copia
     * 168 MB) y necesita ese espacio libre. Lanza IOException si no se puede.
     */
    public static synchronized File ensure(File original, int S) throws IOException {
        if (S == 1024) return original;
        File out = fileFor(original, S);
        String tag = original.length() + " " + S;
        File ok = okFile(out);
        if (out.isFile() && out.length() == original.length() && ok.isFile() && tag.equals(readSmall(ok))) return out;
        if (original.getParentFile() != null && original.getParentFile().getUsableSpace() < original.length() + (20L << 20))
            throw new IOException("sin espacio para el modo ahorro");
        List<long[]> patches = plan(original, S);       // {offset, valor, largo en bytes (1, 2 u 8)}
        File tmp = new File(out.getPath() + ".tmp");
        tmp.delete();
        try (FileInputStream in = new FileInputStream(original); FileOutputStream fo = new FileOutputStream(tmp)) {
            FileChannel src = in.getChannel(), dst = fo.getChannel();
            long pos = 0, size = src.size();
            while (pos < size) pos += src.transferTo(pos, size - pos, dst);
        }
        try (RandomAccessFile raf = new RandomAccessFile(tmp, "rw")) {
            for (long[] p : patches) {
                raf.seek(p[0]);
                if (p[2] == 1) raf.write((int) p[1]);
                else if (p[2] == 2) { raf.write((int) (p[1] & 0xFF)); raf.write((int) ((p[1] >> 8) & 0xFF)); }
                else {
                    ByteBuffer bb = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
                    bb.putLong(p[1]);
                    raf.write(bb.array());
                }
            }
            raf.getFD().sync();
        }
        out.delete();
        if (!tmp.renameTo(out)) throw new IOException("no se pudo guardar la copia");
        try (FileOutputStream fo = new FileOutputStream(ok)) { fo.write(tag.getBytes("UTF-8")); }
        return out;
    }

    /** Borra las copias del modo ahorro (por ejemplo, si el modelo cambia). */
    public static void deleteCopies(File original) {
        for (int S : SIZES) {
            if (S == 1024) continue;
            File f = fileFor(original, S);
            f.delete();
            okFile(f).delete();
            new File(f.getPath() + ".tmp").delete();
        }
    }

    // ------------------------------------------------------------------ lectura del ONNX
    private static final class Pb {
        final MappedByteBuffer b;
        int i;
        Pb(MappedByteBuffer b) { this.b = b; }
        long varint() {
            long r = 0;
            int s = 0;
            while (true) {
                int c = b.get(i++) & 0xFF;
                r |= (long) (c & 0x7F) << s;
                if (c < 0x80) return r;
                s += 7;
                if (s > 63) throw new IllegalStateException("varint");
            }
        }
        /** Salta el valor del tipo t. Para t = 2 devuelve {inicio, fin}; si no, null. */
        int[] value(int t) {
            if (t == 0) { varint(); return null; }
            if (t == 1) { i += 8; return null; }
            if (t == 5) { i += 4; return null; }
            if (t == 2) {
                int len = (int) varint();
                int[] r = {i, i + len};
                i += len;
                return r;
            }
            throw new IllegalStateException("tipo " + t);
        }
        String str(int[] r) {
            byte[] x = new byte[r[1] - r[0]];
            for (int k = 0; k < x.length; k++) x[k] = b.get(r[0] + k);
            try { return new String(x, "UTF-8"); } catch (Exception e) { return ""; }
        }
    }

    /** Lista de cambios para pasar de 1024 a S. Revisa todo; si algo no cuadra, lanza IOException. */
    public static List<long[]> plan(File model, int S) throws IOException {
        if (S % 64 != 0 || S < 256 || S >= 1024 || S >= 2048) throw new IOException("tamano " + S);
        List<long[]> out = new ArrayList<long[]>();
        try (RandomAccessFile raf = new RandomAccessFile(model, "r"); FileChannel ch = raf.getChannel()) {
            if (ch.size() > Integer.MAX_VALUE) throw new IOException("modelo muy grande");
            MappedByteBuffer mb = ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size());
            mb.order(ByteOrder.LITTLE_ENDIAN);
            Pb p = new Pb(mb);
            int end = (int) ch.size();
            int[] graph = null;
            while (p.i < end) {
                long k = p.varint();
                int[] r = p.value((int) (k & 7));
                if ((k >>> 3) == 7 && r != null) graph = r;
            }
            if (graph == null) throw new IOException("sin grafo");

            List<String> resizeSizes = new ArrayList<String>();
            Map<String, int[]> raw32 = new HashMap<String, int[]>();
            List<int[]> io = new ArrayList<int[]>();
            List<Integer> vinfoTags = new ArrayList<Integer>();
            p.i = graph[0];
            while (p.i < graph[1]) {
                int tagAt = p.i;
                long k = p.varint();
                int f = (int) (k >>> 3), t = (int) (k & 7);
                int[] r = p.value(t);
                if (r == null) continue;
                if (f == 1) {                       // NodeProto
                    String op = null;
                    List<String> ins = new ArrayList<String>();
                    int save = p.i;
                    p.i = r[0];
                    while (p.i < r[1]) {
                        long k2 = p.varint();
                        int[] r2 = p.value((int) (k2 & 7));
                        if (r2 == null) continue;
                        int f2 = (int) (k2 >>> 3);
                        if (f2 == 1) ins.add(p.str(r2));
                        else if (f2 == 4) op = p.str(r2);
                    }
                    p.i = save;
                    if ("Resize".equals(op)) {
                        if (ins.size() < 4) throw new IOException("Resize sin tamanos");
                        resizeSizes.add(ins.get(3));
                    }
                } else if (f == 5) {                // TensorProto (initializer)
                    String name = null;
                    int[] raw = null;
                    int save = p.i;
                    p.i = r[0];
                    while (p.i < r[1]) {
                        long k2 = p.varint();
                        int[] r2 = p.value((int) (k2 & 7));
                        if (r2 == null) continue;
                        int f2 = (int) (k2 >>> 3);
                        if (f2 == 8) name = p.str(r2);
                        else if (f2 == 9) raw = r2;
                    }
                    p.i = save;
                    if (name != null && raw != null && raw[1] - raw[0] == 32) raw32.put(name, raw);
                } else if (f == 11 || f == 12) {    // entrada / salida
                    io.add(r);
                } else if (f == 13) {               // value_info
                    if ((mb.get(tagAt) & 0xFF) != 0x6A) throw new IOException("value_info raro");
                    vinfoTags.add(tagAt);
                }
            }
            if (resizeSizes.isEmpty() || io.size() < 2) throw new IOException("modelo inesperado");
            // 1) tamanos de los Resize: (1, C, h, w) -> (1, C, h*S/1024, w*S/1024)
            for (String nm : resizeSizes) {
                int[] raw = raw32.get(nm);
                if (raw == null) throw new IOException("Resize sin tamano fijo");
                long n0 = mb.getLong(raw[0]), c = mb.getLong(raw[0] + 8), h = mb.getLong(raw[0] + 16), w = mb.getLong(raw[0] + 24);
                if (n0 != 1 || c < 1 || h * S % 1024 != 0 || w * S % 1024 != 0) throw new IOException("Resize " + h + "x" + w);
                out.add(new long[]{raw[0] + 16, h * S / 1024, 8});
                out.add(new long[]{raw[0] + 24, w * S / 1024, 8});
            }
            // 2) forma de entrada y salida: dim_value 1024 (08 80 08) -> S (2 bytes)
            int dims = 0;
            long enc = (0x80 | (S & 0x7F)) | ((long) (S >> 7) << 8);
            if ((S >> 7) >= 0x80) throw new IOException("tamano");
            for (int[] r : io) {
                for (int q = r[0]; q + 2 < r[1]; q++) {
                    if ((mb.get(q) & 0xFF) == 0x08 && (mb.get(q + 1) & 0xFF) == 0x80 && (mb.get(q + 2) & 0xFF) == 0x08) {
                        out.add(new long[]{q + 1, enc, 2});
                        dims++;
                    }
                }
            }
            if (dims != 4) throw new IOException("forma " + dims);
            // 3) value_info -> campo reservado 3 (se ignora)
            for (int at : vinfoTags) out.add(new long[]{at, 0x1A, 1});
        }
        return out;
    }

    private static String readSmall(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[64];
            int n = in.read(b);
            return n <= 0 ? "" : new String(b, 0, n, "UTF-8").trim();
        } catch (IOException e) {
            return "";
        }
    }
}
