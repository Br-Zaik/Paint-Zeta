package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * v8.43: Antes / Despues con una linea en medio. Arrastra la linea (o toca un lado) para
 * comparar; dos dedos hacen zoom y mueven la imagen. Las dos imagenes tienen el mismo tamano.
 */
public class CompareView extends View {
    private final Bitmap before, after;
    private float split = 0.5f;          // posicion de la linea en la imagen (0..1)
    private float scale = 1f, tx, ty;    // vista
    private boolean fitted, movingLine;
    private final Paint img = new Paint(Paint.FILTER_BITMAP_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG), chip = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector sg;
    private float lastX, lastY;
    private final float dens;

    public CompareView(Context c, Bitmap before, Bitmap after) {
        super(c);
        this.before = before;
        this.after = after;
        dens = c.getResources().getDisplayMetrics().density;
        line.setColor(0xFFFFFFFF);
        line.setStrokeWidth(2.5f * dens);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(14 * dens);
        chip.setColor(0xAA000000);
        sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float ns = Math.max(minScale(), Math.min(minScale() * 12f, scale * d.getScaleFactor()));
                float f = ns / scale;
                tx = d.getFocusX() - (d.getFocusX() - tx) * f;
                ty = d.getFocusY() - (d.getFocusY() - ty) * f;
                scale = ns;
                invalidate();
                return true;
            }
        });
    }

    private float minScale() {
        return Math.min(getWidth() / (float) after.getWidth(), getHeight() / (float) after.getHeight());
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        fitted = false;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF1B1B20);
        if (!fitted && getWidth() > 0) {
            scale = minScale();
            tx = (getWidth() - after.getWidth() * scale) / 2f;
            ty = (getHeight() - after.getHeight() * scale) / 2f;
            fitted = true;
        }
        Matrix m = new Matrix();
        m.setScale(scale, scale);
        m.postTranslate(tx, ty);
        float lx = tx + split * after.getWidth() * scale;
        RectF r = new RectF(tx, ty, tx + after.getWidth() * scale, ty + after.getHeight() * scale);
        c.save();
        c.clipRect(r.left, r.top, Math.max(r.left, Math.min(r.right, lx)), r.bottom);
        c.drawBitmap(before, m, img);
        c.restore();
        c.save();
        c.clipRect(Math.min(r.right, Math.max(r.left, lx)), r.top, r.right, r.bottom);
        c.drawBitmap(after, m, img);
        c.restore();
        c.drawLine(lx, 0, lx, getHeight(), line);
        c.drawCircle(lx, getHeight() / 2f, 14 * dens, line);
        label(c, "Antes", lx - 8 * dens, true);
        label(c, "Despues", lx + 8 * dens, false);
    }

    private void label(Canvas c, String s, float x, boolean left) {
        float w = text.measureText(s) + 16 * dens, h = 26 * dens, y = 12 * dens;
        float x0 = left ? x - w : x;
        c.drawRoundRect(new RectF(x0, y, x0 + w, y + h), 8 * dens, 8 * dens, chip);
        c.drawText(s, x0 + 8 * dens, y + h - 8 * dens, text);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        sg.onTouchEvent(e);
        float lx = tx + split * after.getWidth() * scale;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX();
                lastY = e.getY();
                movingLine = Math.abs(e.getX() - lx) < 48 * dens || scale <= minScale() * 1.01f;
                if (movingLine) setSplit(e.getX());
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                movingLine = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (e.getPointerCount() > 1 || sg.isInProgress()) {
                    // mover con dos dedos: el centro de los dedos
                    float cx = (e.getX(0) + e.getX(1)) / 2f, cy = (e.getY(0) + e.getY(1)) / 2f;
                    if (!Float.isNaN(lastX)) { tx += cx - lastX; ty += cy - lastY; }
                    lastX = cx;
                    lastY = cy;
                    invalidate();
                } else if (movingLine) {
                    setSplit(e.getX());
                } else {
                    if (!Float.isNaN(lastX)) {
                        tx += e.getX() - lastX;
                        ty += e.getY() - lastY;
                    }
                    lastX = e.getX();
                    lastY = e.getY();
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                lastX = Float.NaN;
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                movingLine = false;
                return true;
        }
        return true;
    }

    private void setSplit(float x) {
        split = Math.max(0f, Math.min(1f, (x - tx) / (after.getWidth() * scale)));
        invalidate();
    }

    /** Suelta las imagenes (al cerrar). */
    public void release() {
        if (!before.isRecycled()) before.recycle();
        if (!after.isRecycled()) after.recycle();
    }
}
