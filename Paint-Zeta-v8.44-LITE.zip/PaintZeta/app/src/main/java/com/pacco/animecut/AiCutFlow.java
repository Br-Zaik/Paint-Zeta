package com.pacco.animecut;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.pacco.animecut.ai.AiCache;
import com.pacco.animecut.ai.AiCutSession;
import com.pacco.animecut.ai.AiJob;
import com.pacco.animecut.ai.AiMatte;
import com.pacco.animecut.ai.AiPrep;
import com.pacco.animecut.ai.AiSegmenter;
import com.pacco.animecut.ai.ModelResize;
import com.pacco.animecut.ai.ModelStore;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.view.AiCutView;
import com.pacco.animecut.view.CanvasView;

import java.io.File;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v8.33: "Recortar con IA" (Borrar fondo). 100 % en el telefono, sin cuentas ni pagos.
 *  1) Si falta el modelo: se baja UNA vez (168 MB) con progreso, Cancelar y Continuar; se
 *     verifica su SHA-256. Despues funciona sin internet.
 *  2) La IA corre en otro hilo (se puede cancelar). Su salida se guarda: reabrir la misma capa
 *     no vuelve a correr la IA.
 *  3) Editor a pantalla completa: vista previa sobre cuadros/blanco/negro/magenta, comparar con
 *     el original, pincel Quitar/Anadir, toque Quitar zona/Anadir zona, Solo este, Escoba,
 *     ajustes del borde, Deshacer/Rehacer. Nada toca la capa hasta Aplicar.
 *  4) Aplicar: capa nueva "Recorte IA" (la original queda intacta y oculta) o en la misma capa.
 *     Un solo Deshacer.
 */
final class AiCutFlow {
    private final MainActivity act;
    private final CanvasView canvas;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final SharedPreferences prefs;

    AiCutFlow(MainActivity a, CanvasView c) {
        act = a;
        canvas = c;
        prefs = a.getSharedPreferences("pz", Context.MODE_PRIVATE);
    }

    private int dp(float v) { return Math.round(v * act.getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(act, s, Toast.LENGTH_SHORT).show(); }

    private ModelStore store() {
        return new ModelStore(new File(act.getFilesDir(), "models"), prefs.getString("ia_model_url", null));
    }

    // ------------------------------------------------------------------ inicio
    /** v8.39 barra de la marca: "Quitar fondo" con lo pintado. */
    void runMarked() {
        if (!canvas.isAiMarking()) return;
        if (!canvas.aiMarkHasStrokes()) { toast("Primero pinta encima del personaje, o toca Toda la imagen"); return; }
        canvas.fireAiMarkNow();
        act.updateUi();
    }

    /** v8.39 barra de la marca: quitar el fondo de toda la imagen sin pintar. */
    void runWhole() {
        canvas.cancelAiMark();
        act.updateUi();
        final Layer t0 = canvas.aiTargetLayer();
        if (t0 == null) return;
        final ModelStore st0 = store();
        if (st0.isInstalled()) checkMemoryThenRun(t0, st0, null);
    }

    void start() {
        // ya pintando: con trazos, correr ya; sin trazos, toda la imagen
        if (canvas.isAiMarking()) {
            if (canvas.aiMarkHasStrokes()) { canvas.fireAiMarkNow(); act.updateUi(); return; }
            canvas.cancelAiMark();
            act.updateUi();
            final Layer t0 = canvas.aiTargetLayer();
            if (t0 == null) return;
            final ModelStore st0 = store();
            if (st0.isInstalled()) checkMemoryThenRun(t0, st0, null);
            return;
        }
        final Layer t = canvas.aiTargetLayer();
        if (t == null) return;
        if (!AiSegmenter.available()) {
            new AlertDialog.Builder(act)
                    .setTitle("IA no disponible")
                    .setMessage("Este telefono no puede correr la IA (procesador no compatible).\nUsa Balde, Pincel y Borrador de Borrar fondo.")
                    .setPositiveButton("Entendido", null).show();
            return;
        }
        final ModelStore st = store();
        if (st.isInstalled()) { mark(t, st); return; }
        // el archivo puede estar pero sin su marca (por ejemplo, copia de seguridad): verificar
        act.runBusy("Revisando el modelo...", new Runnable() {
            @Override public void run() { st.verifyExisting(); }
        }, new Runnable() {
            @Override public void run() {
                if (st.isInstalled()) mark(t, st);
                else askDownload(t, st);
            }
        });
    }

    private void askDownload(final Layer t, final ModelStore st) {
        long part = st.partBytes();
        String msg = "La IA para quitar fondos se baja UNA sola vez (168 MB) y despues funciona sin internet."
                + "\nTus imagenes no salen del telefono. Gratis, licencia Apache-2.0."
                + (part > 0 ? "\n\nYa hay " + (part >> 20) + " MB bajados: se continua." : "")
                + "\n\nConviene usar Wi-Fi.";
        new AlertDialog.Builder(act)
                .setTitle("Recortar con IA")
                .setMessage(msg)
                .setPositiveButton(part > 0 ? "Continuar" : "Descargar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { download(t, st); }
                })
                .setNeutralButton("Licencias", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showLicenses(); }
                })
                .setNegativeButton("Ahora no", null)
                .show();
    }

    private void download(final Layer t, final ModelStore st) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(14), dp(20), dp(6));
        final TextView txt = new TextView(act);
        txt.setText("Conectando...");
        box.addView(txt);
        final ProgressBar bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        final AtomicBoolean cancel = new AtomicBoolean(false);
        final AlertDialog dlg = new AlertDialog.Builder(act)
                .setTitle("Bajando la IA (una sola vez)")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { cancel.set(true); }
                })
                .show();
        Thread th = new Thread(new Runnable() {
            @Override public void run() {
                final ModelStore.Result r = st.download(new ModelStore.Listener() {
                    @Override public void progress(final long done, final long total, final int src) {
                        ui.post(new Runnable() {
                            @Override public void run() {
                                bar.setProgress((int) (done * 1000 / Math.max(1, total)));
                                txt.setText((done >> 20) + " de " + (total >> 20) + " MB");
                            }
                        });
                    }
                }, cancel);
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { dlg.dismiss(); } catch (Throwable ignored) { }
                        if (r.ok()) { toast("IA lista. Ya funciona sin internet"); mark(t, st); return; }
                        if (r.code == ModelStore.CANCELLED) { toast("Pausado: lo bajado se guarda"); return; }
                        new AlertDialog.Builder(act)
                                .setTitle("No se pudo bajar")
                                .setMessage(r.message)
                                .setPositiveButton("Reintentar", new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface d, int w) { download(t, st); }
                                })
                                .setNeutralButton("Origen propio", new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface d, int w) { customSource(); }
                                })
                                .setNegativeButton("Cerrar", null).show();
                    }
                });
            }
        }, "pz-ia-descarga");
        th.start();
    }

    /** Un enlace https propio (por ejemplo un Release tuyo). Igual se exige el MISMO SHA-256. */
    private void customSource() {
        final EditText in = new EditText(act);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        in.setHint("https://.../isnetis.onnx");
        in.setText(prefs.getString("ia_model_url", ""));
        new AlertDialog.Builder(act)
                .setTitle("Origen propio (opcional)")
                .setMessage("Se prueba primero. Solo se acepta el archivo exacto (SHA-256 fijo).")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String u = in.getText().toString().trim();
                        prefs.edit().putString("ia_model_url", u.startsWith("https://") ? u : "").apply();
                        if (u.length() > 0 && !u.startsWith("https://")) toast("Solo enlaces https://");
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    void showLicenses() {
        String txt;
        try (InputStream in = act.getAssets().open("LICENCIAS_IA.txt")) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            txt = bo.toString("UTF-8");
        } catch (Exception e) {
            txt = "ISNet-Anime (SkyTNT/anime-segmentation): Apache-2.0.\nONNX Runtime (Microsoft): MIT.";
        }
        TextView tv = new TextView(act);
        tv.setText(txt);
        tv.setTextSize(11f);
        tv.setPadding(dp(16), dp(10), dp(16), dp(10));
        tv.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(act);
        sv.addView(tv);
        new AlertDialog.Builder(act).setTitle("Licencias de la IA").setView(sv).setPositiveButton("Cerrar", null).show();
    }

    /**
     * v8.39: ya no sale el aviso "Poca memoria libre" cada vez. Se elige solo el tamano con que
     * mira la IA segun la memoria libre del telefono (modo ahorro) y, si aun asi Android cierra
     * la IA, se reintenta sola con menos memoria. Medido en PC (pico del proceso de la IA):
     * 1024 px ~1013 MB, 768 ~600, 640 ~460, 512 ~350.
     */
    private void checkMemoryThenRun(final Layer t, final ModelStore st, final float[] hint) {
        ActivityManager am = (ActivityManager) act.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        long avail = 0;
        if (am != null) { am.getMemoryInfo(mi); avail = mi.availMem; }
        aiLevel = levelFor(avail);
        aiSize = ModelResize.SIZES[aiLevel];
        run(t, st, hint);
    }

    /** Nivel inicial (0 = 1024 ... 3 = 512) segun la memoria libre. 0 si no se sabe. */
    static int levelFor(long availBytes) {
        if (availBytes <= 0) return 0;
        long mb = availBytes >> 20;
        if (mb >= 1400) return 0;
        if (mb >= 900) return 1;
        if (mb >= 650) return 2;
        return 3;
    }

    private volatile int aiLevel = 0;
    private volatile int aiSize = 1024;

    /** Baja un nivel (menos memoria). false si ya estaba en el minimo. */
    private boolean stepDown(AiSegmenter[] seg) {
        if (aiLevel >= ModelResize.SIZES.length - 1) return false;
        aiLevel++;
        aiSize = ModelResize.SIZES[aiLevel];
        if (seg[0] != null) { running = null; try { seg[0].close(); } catch (Throwable ignored) { } seg[0] = null; }
        return true;
    }

    /**
     * v8.36: primer toque de la IA = pintar encima del personaje que quieres (celeste). Al soltar
     * el dedo (y un momento sin pintar mas) la IA corre con esa marca. Tocar la IA otra vez sin
     * pintar = toda la imagen (como antes). Dos dedos: zoom; toque con dos dedos = borra el
     * ultimo trazo.
     */
    private void mark(final Layer t, final ModelStore st) {
        canvas.startAiMark(new CanvasView.AiMarkListener() {
            @Override public void onAiMarkReady(float[] hint) {
                act.updateUi();
                if (canvas.aiTargetLayer() != t) return;
                checkMemoryThenRun(t, st, hint);
            }
        });
        act.updateUi();
    }

    // ------------------------------------------------------------------ IA
    private volatile AiSegmenter running;

    private void run(final Layer t, final ModelStore st, final float[] hint) {
        final int[] px;
        try { px = t.px(); } catch (OutOfMemoryError e) { toast("Falta memoria"); return; }
        final int W = canvas.getProject().w, H = canvas.getProject().h;
        final Rect crop = canvas.aiCropRect();
        final AtomicBoolean cancel = new AtomicBoolean(false);
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        box.addView(new ProgressBar(act), new LinearLayout.LayoutParams(dp(36), dp(36)));
        final TextView txt = new TextView(act);
        txt.setText("  La IA esta mirando la imagen...");
        box.addView(txt);
        final AlertDialog dlg = new AlertDialog.Builder(act)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        cancel.set(true);
                        AiSegmenter s = running;
                        if (s != null) s.cancel();
                        killAiProcess();
                    }
                })
                .show();
        final long t0 = System.currentTimeMillis();
        Thread th = new Thread(new Runnable() {
            @Override public void run() {
                AiCutSession ses = null;
                int[] result = null;
                String err = null;
                AiSegmenter[] seg = new AiSegmenter[1];
                try {
                    AiCache cache = new AiCache(new File(act.getCacheDir(), "ia"));
                    if (aiSize < 1024) {
                        final String m0 = "  La IA esta mirando la imagen (modo ahorro de memoria)...";
                        ui.post(new Runnable() { @Override public void run() { txt.setText(m0); } });
                    }
                    Object[] r1;
                    // v8.39: si Android cierra la IA por memoria, se reintenta sola con menos
                    while (true) {
                        try {
                            r1 = look(cache, seg, st, px, W, crop.left, crop.top, crop.width(), crop.height(), cancel);
                            break;
                        } catch (OutOfMemoryError oom) {
                            if (cancel.get() || !stepDown(seg)) throw oom;
                            final String m = "  Poca memoria: la IA prueba otra vez gastando menos (" + aiSize + " px)...";
                            ui.post(new Runnable() { @Override public void run() { txt.setText(m); } });
                            System.gc();
                            Thread.sleep(1500);
                            if (cancel.get()) return;
                        }
                    }
                    if (r1 == null || cancel.get()) return;
                    AiPrep prep = (AiPrep) r1[0];
                    byte[] raw = (byte[]) r1[1];
                    boolean mono2 = AiPrep.meanSaturation(px, W, crop.left, crop.top, crop.width(), crop.height()) < 12;
                    AiMatte.Params prm = AiCutSession.defaults(mono2);
                    prm.setHardness(prefs.getFloat("ia_hard", 0.5f));
                    prm.hint = hint;
                    // v8.36: con la marca del dedo, segunda mirada de la IA solo en ese personaje
                    // (mas pixeles por celda = mas detalle) si es bastante mas chico que la imagen
                    int[] c2 = hint != null ? AiMatte.secondLook(prep, raw, px, W, H, prm) : null;
                    if (c2 != null && !cancel.get()) {
                        ui.post(new Runnable() { @Override public void run() { txt.setText("  Mirando de cerca al personaje..."); } });
                        Object[] r2;
                        try {
                            r2 = look(cache, seg, st, px, W, c2[0], c2[1], c2[2], c2[3], cancel);
                        } catch (OutOfMemoryError oom) {
                            r2 = null;     // la segunda mirada es un extra: sin memoria, se usa la primera
                        }
                        if (cancel.get()) return;
                        if (r2 != null) {
                            prep = (AiPrep) r2[0];
                            raw = (byte[]) r2[1];
                            mono2 = AiPrep.meanSaturation(px, W, c2[0], c2[1], c2[2], c2[3]) < 12;
                            AiMatte.Params p2 = AiCutSession.defaults(mono2);
                            p2.setHardness(prefs.getFloat("ia_hard", 0.5f));
                            p2.hint = hint;
                            prm = p2;
                        }
                    }
                    if (seg[0] != null) { running = null; seg[0].close(); seg[0] = null; }   // ~300 MB menos
                    ui.post(new Runnable() { @Override public void run() { txt.setText("  Ajustando el borde a las lineas..."); } });
                    ses = new AiCutSession(px, W, H, prep, raw, prm);
                    // v8.35: sin editor aparte; el resultado va directo a la capa
                    if (ses.anyVisible() && !cancel.get()) {
                        int[] o = new int[W * H];
                        ses.exportTo(o);
                        result = o;
                    }
                } catch (OutOfMemoryError oom) {
                    err = "La IA se cerro por falta de memoria, aun en el modo ahorro (tu dibujo esta a salvo). Cierra otras apps (o reinicia el telefono) y prueba otra vez";
                } catch (Throwable e) {
                    err = "La IA fallo: " + e.getClass().getSimpleName();
                    // archivo danado: se vuelve a verificar la proxima vez
                    try { new File(st.modelFile().getParentFile(), ModelStore.FILE + ".ok").delete(); } catch (Throwable ignored) { }
                } finally {
                    running = null;
                    if (seg[0] != null) try { seg[0].close(); } catch (Throwable ignored) { }
                }
                final AiCutSession fs = ses;
                final int[] fr = result;
                final String fe = err;
                final long ms = System.currentTimeMillis() - t0;
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { dlg.dismiss(); } catch (Throwable ignored) { }
                        if (cancel.get()) { toast("Cancelado"); return; }
                        if (fe != null) { new AlertDialog.Builder(act).setMessage(fe).setPositiveButton("Cerrar", null).show(); return; }
                        if (fs == null) return;
                        if (!fs.anyVisible()) {
                            new AlertDialog.Builder(act).setMessage("La IA no encontro un personaje aqui. Pinta mas encima del personaje, o usa Balde y Pincel.")
                                    .setPositiveButton("Cerrar", null).show();
                            return;
                        }
                        if (fr == null) { toast("Falta memoria para aplicar"); return; }
                        // aplica en la misma capa (un Deshacer); Restaurar devuelve lo quitado
                        canvas.applyAiCut(t, fr, false);
                        act.afterAiCut();
                        // v8.38: si la IA dudo bastante, un aviso corto (no bloquea)
                        if (AiJob.doubt(fs.raw) > (fs.mono ? AiJob.DOUBT_WARN : AiJob.DOUBT_WARN_MIRROR))
                            canvas.showHud("La IA dudo en partes: repasa el borde (Balde o Restaurar)", 3400);
                        else if (aiSize < 1024)
                            canvas.showHud("Listo en modo ahorro de memoria (" + aiSize + " px)", 2400);
                    }
                });
            }
        }, "pz-ia");
        th.start();
    }

    /**
     * Salida de la IA para una zona (de la cache si ya se miro igual). seg[0] se abre una vez y
     * sirve para las dos miradas. null si se cancelo.
     */
    private Object[] look(AiCache cache, AiSegmenter[] seg, ModelStore st, int[] px, int W,
                          int cx, int cy, int cw, int ch, AtomicBoolean cancel) throws Exception {
        final int S = aiSize;
        boolean mono = AiPrep.meanSaturation(px, W, cx, cy, cw, ch) < 12;
        // v8.38: a color la IA mira tambien en espejo (en manga no ayudaba)
        boolean mirror = !mono;
        long key = AiCache.key(px, W, cx, cy, cw, ch, S + (mirror ? 7 : 0));
        Object[] hit = cache.load(key);
        if (hit != null) return hit;
        if (cancel.get()) return null;
        AiPrep prep = AiPrep.plan(S, cx, cy, cw, ch);
        FloatBuffer out = null;
        if (serviceOk) {
            try {
                out = lookInProcess(st, prep, px, W, mono, mirror, cancel);
                if (out == null) return null;          // cancelado
            } catch (ServiceUnavailable e) {
                serviceOk = false;                     // este telefono no deja: se hace en la app
            }
        }
        if (out == null) {
            // respaldo: la IA dentro de la app (como hasta la v8.37), sin espejo
            if (seg[0] != null && seg[0].inputSize() != S) { running = null; seg[0].close(); seg[0] = null; }
            if (seg[0] == null) {
                seg[0] = new AiSegmenter(ModelResize.ensure(st.modelFile(), S), threadsFor(S), S < 1024);
                running = seg[0];
            }
            if (cancel.get()) return null;
            FloatBuffer in = seg[0].inputBuffer();
            prep.fill(px, W, in, mono);
            if (cancel.get()) return null;
            try {
                out = seg[0].run(in);
            } catch (ai.onnxruntime.OrtException e) {
                String m = String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.US);
                if (m.contains("alloc") || m.contains("memory")) throw new OutOfMemoryError("ia");
                throw e;
            }
            if (out == null || cancel.get()) return null;
            key = AiCache.key(px, W, cx, cy, cw, ch, S);
        }
        byte[] raw = prep.cropOutput(out);
        cache.save(key, prep, raw);
        return new Object[]{prep, raw};
    }

    /** El servicio no se pudo iniciar en este telefono (no es falta de memoria). */
    private static final class ServiceUnavailable extends Exception {
        ServiceUnavailable(String m) { super(m); }
    }

    private volatile boolean serviceOk = true;
    private volatile boolean aiProcSeen;

    /**
     * v8.38: corre el modelo en el proceso ":ia" (AiService) y espera su resultado. Si ese proceso
     * desaparece sin terminar, fue por falta de memoria: se avisa y la app sigue abierta.
     * Devuelve null si se cancelo.
     */
    private FloatBuffer lookInProcess(ModelStore st, AiPrep prep, int[] px, int W, boolean mono, boolean mirror,
                                      AtomicBoolean cancel) throws Exception {
        final int S = prep.S;
        File dir = new File(act.getCacheDir(), "ia_trabajo");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new ServiceUnavailable("carpeta");
        File in = new File(dir, AiJob.IN), out = new File(dir, AiJob.OUT), state = new File(dir, AiJob.STATE);
        out.delete();
        state.delete();
        FloatBuffer buf = FloatBuffer.allocate(3 * S * S);
        prep.fill(px, W, buf, mono);
        AiJob.writeFloats(in, buf);
        buf = null;
        if (cancel.get()) return null;
        File modelForS;
        try {
            modelForS = ModelResize.ensure(st.modelFile(), S);
        } catch (java.io.IOException e) {
            throw new IllegalStateException("No se pudo preparar el modo ahorro: " + e.getMessage());
        }
        if (cancel.get()) return null;
        android.content.Intent it = new android.content.Intent(act, AiService.class)
                .putExtra(AiService.X_MODEL, modelForS.getAbsolutePath())
                .putExtra(AiService.X_DIR, dir.getAbsolutePath())
                .putExtra(AiService.X_THREADS, threadsFor(S))
                .putExtra(AiService.X_LOWMEM, S < 1024)
                .putExtra(AiService.X_MIRROR, mirror)
                .putExtra(AiService.X_PADX, prep.padX)
                .putExtra(AiService.X_W, prep.w);
        aiProcSeen = false;
        try {
            if (act.startService(it) == null) throw new ServiceUnavailable("sin servicio");
        } catch (ServiceUnavailable e) {
            throw e;
        } catch (Throwable e) {
            throw new ServiceUnavailable(e.getClass().getSimpleName());
        }
        // v8.39: unida a la app que estas usando (sin AUTO_CREATE: si la IA termina o se cierra,
        // Android no la vuelve a abrir sola)
        final android.content.ServiceConnection conn = new android.content.ServiceConnection() {
            @Override public void onServiceConnected(android.content.ComponentName n, android.os.IBinder b) { }
            @Override public void onServiceDisconnected(android.content.ComponentName n) { }
        };
        boolean bound = false;
        try { bound = act.bindService(new android.content.Intent(act, AiService.class), conn, Context.BIND_IMPORTANT); } catch (Throwable ignored) { }
        try {
            return waitResult(state, out, S, cancel);
        } finally {
            if (bound) try { act.unbindService(conn); } catch (Throwable ignored) { }
        }
    }

    private FloatBuffer waitResult(File state, File out, int S, AtomicBoolean cancel) throws Exception {
        long t0 = System.currentTimeMillis();
        while (true) {
            if (cancel.get()) { killAiProcess(); return null; }
            if (state.isFile()) {
                String r = readText(state);
                if (r.startsWith("ok")) return AiJob.readFloats(out, S * S, null);
                if (r.contains("memoria")) throw new OutOfMemoryError("ia");
                throw new IllegalStateException(r.startsWith("error:") ? r.substring(6) : r);
            }
            boolean alive = aiProcessPid() != 0;
            if (alive) aiProcSeen = true;
            long waited = System.currentTimeMillis() - t0;
            // el proceso desaparecio sin terminar: Android lo cerro por falta de memoria
            if (!alive && (aiProcSeen || waited > 15000) && !state.isFile()) {
                Thread.sleep(300);
                if (!state.isFile()) throw new OutOfMemoryError("ia cerrada");
            }
            if (waited > 8 * 60_000L) { killAiProcess(); throw new IllegalStateException("tardo demasiado"); }
            Thread.sleep(150);
        }
    }

    /** Hilos de calculo: en modo ahorro, 2 como maximo (cada hilo gasta su parte). */
    private static int threadsFor(int S) {
        int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
        return Math.max(1, Math.min(S < 1024 ? 2 : 4, cores));
    }

    private static String readText(File f) {
        try (InputStream is = new java.io.FileInputStream(f)) {
            byte[] b = new byte[512];
            int n = is.read(b);
            return n <= 0 ? "" : new String(b, 0, n, "UTF-8").trim();
        } catch (Exception e) {
            return "";
        }
    }

    /** pid del proceso ":ia" o 0 si no esta corriendo. */
    private int aiProcessPid() {
        try {
            ActivityManager am = (ActivityManager) act.getSystemService(Context.ACTIVITY_SERVICE);
            java.util.List<ActivityManager.RunningAppProcessInfo> ps = am == null ? null : am.getRunningAppProcesses();
            if (ps == null) return 0;
            String name = act.getPackageName() + ":ia";
            for (ActivityManager.RunningAppProcessInfo p : ps) if (name.equals(p.processName)) return p.pid;
        } catch (Throwable ignored) { }
        return 0;
    }

    /** Cancelar: se cierra el proceso de la IA (libera su memoria al instante). */
    private void killAiProcess() {
        int pid = aiProcessPid();
        if (pid != 0) try { android.os.Process.killProcess(pid); } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ editor
    private void openEditor(final Layer t, final AiCutSession ses, long ms) {
        final Dialog d = new Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout root = new FrameLayout(act);
        root.setBackgroundColor(0xFF121214);
        final AiCutView view = new AiCutView(act);
        root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        final TextView hud = new TextView(act);
        hud.setTextColor(0xFFFFFFFF);
        hud.setTextSize(13f);
        hud.setBackgroundColor(0xCC202024);
        hud.setPadding(dp(10), dp(5), dp(10), dp(5));
        hud.setVisibility(View.GONE);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hp.topMargin = dp(58);
        root.addView(hud, hp);
        final Runnable hideHud = new Runnable() { @Override public void run() { hud.setVisibility(View.GONE); } };
        final AiCutView[] vref = {view};
        final AiCutView.Host host = new AiCutView.Host() {
            @Override public void onChanged() { }
            @Override public void onHud(String text) {
                hud.setText(text);
                hud.setVisibility(View.VISIBLE);
                ui.removeCallbacks(hideHud);
                ui.postDelayed(hideHud, 1500);
            }
            @Override public void onFingerTap(int fingers) {
                AiCutView v = vref[0];
                if (v.isBusy()) return;
                String l = fingers == 2 ? ses.undo() : ses.redo();
                v.refreshAll();
                onHud(fingers == 2 ? (l == null ? "Nada que deshacer" : "Deshacer: " + l) : (l == null ? "Nada que rehacer" : "Rehacer: " + l));
            }
        };
        view.setHost(host);
        view.setSession(ses);
        view.setTolerance(prefs.getInt("ia_tol", 30));

        // ---- arriba: cerrar, deshacer, rehacer | comparar, fondo de vista, ajustes
        LinearLayout top = row();
        top.setBackgroundColor(0xE0202024);
        top.addView(btn(R.drawable.ic_close, "Cancelar: la capa no cambia", new Runnable() {
            @Override public void run() { askCancel(d, view); }
        }));
        top.addView(btn(R.drawable.ic_undo, "Deshacer", new Runnable() {
            @Override public void run() { if (view.isBusy()) return; String l = ses.undo(); view.refreshAll(); host.onHud(l == null ? "Nada que deshacer" : "Deshacer: " + l); }
        }));
        top.addView(btn(R.drawable.ic_redo, "Rehacer", new Runnable() {
            @Override public void run() { if (view.isBusy()) return; String l = ses.redo(); view.refreshAll(); host.onHud(l == null ? "Nada que rehacer" : "Rehacer: " + l); }
        }));
        top.addView(space());
        final ImageButton cmp = btn(R.drawable.ic_preview, "Manten pulsado: ver el original", null);
        cmp.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) { view.setCompare(true); host.onHud("Original"); }
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) view.setCompare(false);
                return true;
            }
        });
        top.addView(cmp);
        top.addView(btn(R.drawable.ic_eye, "Ver sobre cuadros, blanco, negro o magenta (no se exporta)", new Runnable() {
            @Override public void run() {
                int b = view.cycleBg();
                host.onHud(new String[]{"Cuadros", "Blanco", "Negro", "Magenta"}[b] + " (solo para ver)");
            }
        }));
        final float[] ghosts = {0f, 0.3f, 0.6f};
        final int[] gi = {prefs.getInt("ia_ghost", 0)};
        view.setGhost(ghosts[Math.max(0, Math.min(2, gi[0]))]);
        final ImageButton gb = btn(R.drawable.ic_opacity, "Ver lo quitado (tenue, en rojo) para saber que devolver con Anadir", new Runnable() {
            @Override public void run() {
                gi[0] = (gi[0] + 1) % 3;
                prefs.edit().putInt("ia_ghost", gi[0]).apply();
                view.setGhost(ghosts[gi[0]]);
                host.onHud(gi[0] == 0 ? "Lo quitado: oculto" : "Lo quitado se ve al " + Math.round(ghosts[gi[0]] * 100) + " % (solo para ver)");
            }
        });
        top.addView(gb);
        top.addView(btn(R.drawable.ic_tune, "Ajustes del borde", new Runnable() {
            @Override public void run() { if (!view.isBusy()) settings(view, ses, host); }
        }));
        root.addView(top, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), Gravity.TOP));

        // ---- abajo: herramientas + tamano + aplicar
        LinearLayout bottom = new LinearLayout(act);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackgroundColor(0xE0202024);
        bottom.setPadding(dp(4), dp(4), dp(4), dp(6));
        final LinearLayout tools = row();
        final int[] ids = {AiCutView.T_REMOVE, AiCutView.T_ADD, AiCutView.T_ZONE_REMOVE, AiCutView.T_ZONE_ADD, AiCutView.T_KEEP_ONLY};
        final int[] icons = {R.drawable.ic_eraser, R.drawable.ic_restore_brush, R.drawable.ic_ai_zone_remove, R.drawable.ic_ai_zone_add, R.drawable.ic_sel_keep};
        final String[] names = {"Quitar: pincel que borra", "Anadir: pincel que devuelve", "Quitar zona: toca lo que sobra (barra, edificio). Sobre el fondo: ajusta el borde",
                "Anadir zona: toca lo que falta", "Solo este: toca un personaje y se quitan los otros"};
        final ImageButton[] tb = new ImageButton[ids.length];
        for (int k = 0; k < ids.length; k++) {
            final int which = k;
            tb[k] = btn(icons[k], names[k], new Runnable() {
                @Override public void run() {
                    view.setTool(ids[which]);
                    for (int q = 0; q < tb.length; q++) tb[q].setBackgroundResource(q == which ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                    host.onHud(names[which].split(":")[0]);
                }
            });
            tools.addView(tb[k]);
        }
        tb[0].setBackgroundResource(R.drawable.bg_tool_on);
        tools.addView(btn(R.drawable.ic_broom, "Escoba: quita pedazos sueltos lejos del personaje", new Runnable() {
            @Override public void run() {
                final int[] n = new int[1];
                view.runWork(new Runnable() {
                    @Override public void run() { ses.beginEdit(); n[0] = ses.cleanRemnants(); ses.endEdit("Escoba"); }
                }, new Runnable() {
                    @Override public void run() { host.onHud(n[0] > 0 ? "Restos quitados" : "No hay restos sueltos"); }
                });
            }
        }));
        tools.addView(space());
        ImageButton ok = btn(R.drawable.ic_check, "Aplicar", new Runnable() {
            @Override public void run() { askApply(d, t, view, ses); }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        tools.addView(ok);
        bottom.addView(tools);
        LinearLayout sz = row();
        ImageView dot = new ImageView(act);
        dot.setImageResource(R.drawable.ic_brush);
        sz.addView(dot, new LinearLayout.LayoutParams(dp(26), dp(26)));
        SeekBar size = new SeekBar(act);
        size.setMax(120);
        size.setProgress((int) view.getSizeDp());
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { view.setSizeDp(Math.max(3, v)); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        sz.addView(size, new LinearLayout.LayoutParams(0, dp(36), 1f));
        bottom.addView(sz);
        // v8.33: FUERZA (opacidad) del pincel Quitar/Anadir: quitar o devolver a medias
        LinearLayout st = row();
        ImageView op = new ImageView(act);
        op.setImageResource(R.drawable.ic_opacity);
        st.addView(op, new LinearLayout.LayoutParams(dp(26), dp(26)));
        final TextView stv = new TextView(act);
        stv.setTextColor(0xFFFFFFFF);
        stv.setTextSize(12f);
        SeekBar str = new SeekBar(act);
        str.setMax(100);
        int sp0 = prefs.getInt("ia_strength", 100);
        str.setProgress(sp0);
        ses.strength = Math.max(5, sp0) / 100f;
        stv.setText(sp0 + "%");
        str.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
                int q = Math.max(5, v);
                ses.strength = q / 100f;
                stv.setText(q + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { prefs.edit().putInt("ia_strength", Math.max(5, s.getProgress())).apply(); }
        });
        st.addView(str, new LinearLayout.LayoutParams(0, dp(36), 1f));
        st.addView(stv, new LinearLayout.LayoutParams(dp(44), dp(36)));
        bottom.addView(st);
        root.addView(bottom, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        d.setContentView(root);
        d.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override public boolean onKey(DialogInterface di, int code, android.view.KeyEvent e) {
                if (code == android.view.KeyEvent.KEYCODE_BACK && e.getAction() == android.view.KeyEvent.ACTION_UP) { askCancel(d, view); return true; }
                return false;
            }
        });
        d.show();
        AiMatte.Result r = ses.res;
        host.onHud("Listo en " + (ms / 100) / 10f + " s" + (r.islandsRemoved > 0 ? " - quite " + r.islandsRemoved + " restos" : ""));
        // el grosor de linea (para tocar el fondo y ajustar el borde) se mide ya, sin esperar
        Thread pre = new Thread(new Runnable() { @Override public void run() { try { ses.width(); } catch (Throwable ignored) { } } }, "pz-ia-lineas");
        pre.setPriority(Thread.NORM_PRIORITY - 1);
        pre.start();
    }

    private void askCancel(final Dialog d, final AiCutView view) {
        if (!view.session().canUndo()) { close(d, view); return; }
        new AlertDialog.Builder(act).setMessage("Salir sin aplicar? La capa no cambia.")
                .setPositiveButton("Salir", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int w) { close(d, view); }
                })
                .setNegativeButton("Seguir", null).show();
    }

    private void close(Dialog d, AiCutView view) {
        try { d.dismiss(); } catch (Throwable ignored) { }
        view.release();
    }

    private void askApply(final Dialog d, final Layer t, final AiCutView view, final AiCutSession ses) {
        if (view.isBusy()) return;
        new AlertDialog.Builder(act)
                .setTitle("Aplicar el recorte")
                .setItems(new String[]{"En una capa nueva (la original queda intacta)", "En esta misma capa"}, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int which) {
                        final boolean newLayer = which == 0;
                        final int[][] out = new int[1][];
                        view.runWork(new Runnable() {
                            @Override public void run() {
                                int[] o = new int[ses.W * ses.H];
                                ses.exportTo(o);
                                out[0] = o;
                            }
                        }, new Runnable() {
                            @Override public void run() {
                                if (out[0] == null) { toast("Falta memoria para aplicar"); return; }
                                close(d, view);
                                canvas.applyAiCut(t, out[0], newLayer);
                                act.afterAiCut();
                            }
                        });
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    // ------------------------------------------------------------------ ajustes
    private void settings(final AiCutView view, final AiCutSession ses, final AiCutView.Host host) {
        final AiMatte.Params p = ses.params.copy();
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(4));
        final float[] hard = {prefs.getFloat("ia_hard", 0.5f)};
        final SeekBar sh = slider(box, "Dureza del borde", 100, Math.round(hard[0] * 100));
        final SeekBar sb = slider(box, "Borde: achicar  -  agrandar", 6, p.shift + 3);
        final SeekBar st = slider(box, "Parecido de Quitar/Anadir zona", 120, view.getTolerance());
        final CheckBox c1 = check(box, "Quitar pedazos sueltos lejanos", p.islands);
        final CheckBox c2 = check(box, "Rellenar agujeros chicos", p.holes);
        final CheckBox c3 = check(box, "Bajar manchas dudosas (luz, vidrio)", p.uncertain);
        final CheckBox c4 = check(box, "Borde pegado a la imagen", p.guided);
        final CheckBox c5 = check(box, "Incluir la linea del dibujo", p.lines);
        final CheckBox c6 = check(box, "Quitar el tinte del fondo en el borde", p.decontam);
        ScrollView sv = new ScrollView(act);
        sv.addView(box);
        new AlertDialog.Builder(act)
                .setTitle("Ajustes del recorte")
                .setView(sv)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int w) {
                        float h = sh.getProgress() / 100f;
                        prefs.edit().putFloat("ia_hard", h).putInt("ia_tol", Math.max(4, st.getProgress())).apply();
                        p.setHardness(h);
                        p.shift = sb.getProgress() - 3;
                        p.islands = c1.isChecked(); p.holes = c2.isChecked(); p.uncertain = c3.isChecked();
                        p.guided = c4.isChecked(); p.lines = c5.isChecked(); p.decontam = c6.isChecked();
                        view.setTolerance(Math.max(4, st.getProgress()));
                        view.runWork(new Runnable() {
                            @Override public void run() { ses.reprocess(p); }
                        }, new Runnable() {
                            @Override public void run() { host.onHud("Ajustes aplicados (tus retoques se conservan)"); }
                        });
                    }
                })
                .setNeutralButton("De fabrica", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int w) {
                        prefs.edit().putFloat("ia_hard", 0.5f).putInt("ia_tol", 30).apply();
                        view.setTolerance(30);
                        final AiMatte.Params def = AiCutSession.defaults(ses.mono);
                        view.runWork(new Runnable() {
                            @Override public void run() { ses.reprocess(def); }
                        }, new Runnable() {
                            @Override public void run() { host.onHud("De fabrica"); }
                        });
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private SeekBar slider(LinearLayout box, String name, int max, int val) {
        TextView t = new TextView(act);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        box.addView(t);
        SeekBar s = new SeekBar(act);
        s.setMax(max);
        s.setProgress(Math.max(0, Math.min(max, val)));
        box.addView(s);
        return s;
    }

    private CheckBox check(LinearLayout box, String name, boolean on) {
        CheckBox c = new CheckBox(act);
        c.setText(name);
        c.setChecked(on);
        box.addView(c);
        return c;
    }

    // ------------------------------------------------------------------ ui
    private LinearLayout row() {
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(4), dp(4), dp(4));
        return r;
    }

    private View space() {
        View v = new View(act);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        return v;
    }

    private ImageButton btn(int icon, final String name, final Runnable action) {
        ImageButton b = new ImageButton(act);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        lp.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(lp);
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setPadding(dp(9), dp(9), dp(9), dp(9));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setImageResource(icon);
        b.setContentDescription(name);
        if (action != null) b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { toast(name); return true; }
        });
        return b;
    }
}
