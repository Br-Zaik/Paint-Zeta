package com.pacco.animecut.ai;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v8.33: el modelo ISNet-Anime se descarga UNA vez a la memoria privada de la app y despues se
 * usa sin red. Nunca se acepta un archivo cuyo SHA-256 no coincida con el fijado aqui.
 *
 *  - Archivo: isnetis.onnx de SkyTNT (anime-segmentation), 176.069.933 bytes,
 *    SHA-256 f15622d853e8260172812b657053460e20806f04b9e05147d49af7bed31a6e99.
 *    Licencia: Apache-2.0 (codigo y pesos; el autor lo confirmo en la discusion #4 del repo).
 *  - Origenes, en orden: el tuyo propio (si lo configuras), Hugging Face con la revision FIJA
 *    43f900433e97e87503906dbdad018ba7467b66d8, y la copia identica publicada por rembg en
 *    GitHub. Da igual de donde venga: si el SHA no coincide se borra.
 *  - Se descarga a "isnetis.onnx.part" y se puede CONTINUAR (cabecera Range) si se corto.
 *  - Antes de empezar se comprueba el espacio libre.
 *  - Al terminar se guarda una marca (tamano + fecha) para no recalcular el SHA en cada uso;
 *    si el archivo cambia, se vuelve a verificar.
 * Java puro (java.net / java.security): lo prueban las pruebas de PC con un servidor local.
 */
public final class ModelStore {
    public static final String FILE = "isnetis.onnx";
    public static final long SIZE = 176_069_933L;
    public static final String SHA256 = "f15622d853e8260172812b657053460e20806f04b9e05147d49af7bed31a6e99";
    public static final String[] OFFICIAL = {
            "https://huggingface.co/skytnt/anime-seg/resolve/43f900433e97e87503906dbdad018ba7467b66d8/isnetis.onnx",
            "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-anime.onnx",
    };

    public static final int OK = 0, CANCELLED = 1, NO_SPACE = 2, NETWORK = 3, BAD_HASH = 4, HTTP = 5, IO = 6;

    public static final class Result {
        public final int code;
        public final String message;
        public final int source;

        Result(int code, String message, int source) { this.code = code; this.message = message; this.source = source; }

        public boolean ok() { return code == OK; }
    }

    public interface Listener {
        /** done/total en bytes; source = numero de origen (0..). */
        void progress(long done, long total, int source);
    }

    private final File dir;
    private final long size;
    private final String sha;
    private final List<String> urls = new ArrayList<>();
    /** Tiempo de espera (ms). */
    public int connectTimeout = 15000, readTimeout = 30000;
    /** Margen de espacio libre ademas del archivo. */
    public long spareBytes = 32L << 20;

    /** Modelo real con sus origenes oficiales; custom (puede ser null) va primero. */
    public ModelStore(File dir, String custom) {
        this(dir, SIZE, SHA256, custom);
        for (String u : OFFICIAL) urls.add(u);
    }

    /** Para pruebas: otro tamano / SHA y sin origenes oficiales (se agregan con addSource). */
    public ModelStore(File dir, long size, String sha, String custom) {
        this.dir = dir;
        this.size = size;
        this.sha = sha.toLowerCase(java.util.Locale.ROOT);
        if (custom != null && custom.trim().startsWith("https://")) urls.add(custom.trim());
    }

    public void addSource(String url) { urls.add(url); }

    public List<String> sources() { return new ArrayList<>(urls); }

    public File modelFile() { return new File(dir, FILE); }

    private File partFile() { return new File(dir, FILE + ".part"); }

    private File markFile() { return new File(dir, FILE + ".ok"); }

    public long partBytes() { File p = partFile(); return p.exists() ? p.length() : 0; }

    /** true si el modelo esta y ya se verifico (marca vigente). Barato: no lee el archivo. */
    public boolean isInstalled() {
        File f = modelFile();
        if (!f.exists() || f.length() != size) return false;
        String m = readMark();
        return m != null && m.equals(markText(f));
    }

    private String markText(File f) { return sha + " " + f.length() + " " + f.lastModified(); }

    private String readMark() {
        File m = markFile();
        if (!m.exists()) return null;
        try (FileInputStream in = new FileInputStream(m)) {
            byte[] b = new byte[(int) Math.min(512, m.length())];
            int n = in.read(b);
            return n <= 0 ? null : new String(b, 0, n, "UTF-8").trim();
        } catch (IOException e) {
            return null;
        }
    }

    private void writeMark(File f) throws IOException {
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(markFile())) {
            o.write(markText(f).getBytes("UTF-8"));
        }
    }

    /**
     * Si el archivo esta pero falta la marca (o cambio), vuelve a calcular su SHA. Si no
     * coincide, se borra. Devuelve true si quedo instalado.
     */
    public boolean verifyExisting() {
        File f = modelFile();
        if (!f.exists()) return false;
        if (isInstalled()) return true;
        try {
            if (f.length() == size && sha.equals(hashFile(f))) { writeMark(f); return true; }
        } catch (IOException ignored) { }
        f.delete();
        markFile().delete();
        return false;
    }

    public void delete() {
        ModelResize.deleteCopies(modelFile());     // v8.39: copias del modo ahorro
        modelFile().delete();
        partFile().delete();
        markFile().delete();
    }

    static String hashFile(File f) throws IOException {
        MessageDigest md = sha256();
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[1 << 16];
            int n;
            while ((n = in.read(b)) > 0) md.update(b, 0, n);
        }
        return hex(md.digest());
    }

    static MessageDigest sha256() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }

    static String hex(byte[] d) {
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format("%02x", b & 0xFF));
        return sb.toString();
    }

    /**
     * Descarga (o continua) el modelo. Bloquea: llamar en otro hilo. cancel = true lo corta y
     * deja el .part para continuar despues.
     */
    public Result download(Listener l, AtomicBoolean cancel) {
        if (isInstalled()) return new Result(OK, "Ya estaba", -1);
        if (!dir.exists() && !dir.mkdirs()) return new Result(IO, "No se pudo crear la carpeta", -1);
        if (verifyExisting()) return new Result(OK, "Ya estaba", -1);
        long have = partBytes();
        long free = dir.getUsableSpace();
        if (free > 0 && free < (size - have) + spareBytes) {
            return new Result(NO_SPACE, "Falta espacio: libera " + mb(size - have + spareBytes - free) + " MB", -1);
        }
        Result last = new Result(NETWORK, "Sin origen", -1);
        for (int s = 0; s < urls.size(); s++) {
            if (cancel != null && cancel.get()) return new Result(CANCELLED, "Cancelado", s);
            last = tryOne(urls.get(s), s, l, cancel);
            if (last.code == OK || last.code == CANCELLED || last.code == NO_SPACE) return last;
            // con hash malo se borro el .part: el siguiente origen empieza de cero
        }
        return last;
    }

    static long mb(long b) { return (b + (1 << 20) - 1) >> 20; }

    private Result tryOne(String url, int s, Listener l, AtomicBoolean cancel) {
        File part = partFile();
        HttpURLConnection c = null;
        MessageDigest md = sha256();
        try {
            long have = part.exists() ? part.length() : 0;
            if (have > size) { part.delete(); have = 0; }
            // lo que ya habia entra al SHA
            if (have > 0) {
                try (InputStream in = new FileInputStream(part)) {
                    byte[] b = new byte[1 << 16];
                    long left = have;
                    int n;
                    while (left > 0 && (n = in.read(b, 0, (int) Math.min(b.length, left))) > 0) { md.update(b, 0, n); left -= n; }
                }
            }
            if (have < size) {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(connectTimeout);
                c.setReadTimeout(readTimeout);
                c.setRequestProperty("User-Agent", "PaintZeta/8.33");
                c.setRequestProperty("Accept-Encoding", "identity");
                if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                int code = c.getResponseCode();
                boolean append;
                if (code == 206 && have > 0) append = true;
                else if (code == 200) {
                    append = false;
                    if (have > 0) { md = sha256(); have = 0; }   // el servidor no continua: de cero
                } else if (code == 416 && have == size) {
                    append = true;
                } else {
                    return new Result(HTTP, "El servidor respondio " + code, s);
                }
                if (code != 416) {
                    try (InputStream in = c.getInputStream();
                         RandomAccessFile out = new RandomAccessFile(part, "rw")) {
                        if (!append) out.setLength(0);
                        out.seek(have);
                        byte[] b = new byte[1 << 16];
                        int n;
                        long done = have;
                        long lastCb = 0;
                        while ((n = in.read(b)) > 0) {
                            if (cancel != null && cancel.get()) return new Result(CANCELLED, "Cancelado", s);
                            if (done + n > size) return badHash(part, s);
                            out.write(b, 0, n);
                            md.update(b, 0, n);
                            done += n;
                            if (l != null && (done - lastCb >= (256 << 10) || done == size)) { l.progress(done, size, s); lastCb = done; }
                        }
                        if (done < size) return new Result(NETWORK, "Se corto la descarga (" + mb(done) + " de " + mb(size) + " MB)", s);
                    }
                }
            }
            String got = hex(md.digest());
            if (part.length() != size || !got.equals(sha)) return badHash(part, s);
            File f = modelFile();
            f.delete();
            if (!part.renameTo(f)) return new Result(IO, "No se pudo guardar el archivo", s);
            writeMark(f);
            return new Result(OK, "Listo", s);
        } catch (java.net.UnknownHostException | java.net.ConnectException | java.net.SocketTimeoutException e) {
            return new Result(NETWORK, "Sin conexion", s);
        } catch (IOException e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("ENOSPC") || m.toLowerCase(java.util.Locale.ROOT).contains("no space")) return new Result(NO_SPACE, "Falta espacio", s);
            return new Result(NETWORK, "Error de red: " + e.getClass().getSimpleName(), s);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private Result badHash(File part, int s) {
        part.delete();
        return new Result(BAD_HASH, "El archivo descargado no es el modelo correcto (se borro)", s);
    }
}
