package com.pacco.animecut;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.pacco.animecut.ai.AiJob;

import java.io.File;
import java.io.FileOutputStream;

/**
 * v8.38: la IA corre en un PROCESO APARTE (":ia", ver AndroidManifest). Si al telefono le falta
 * memoria, Android cierra solo este proceso: Paint Zeta sigue abierta y avisa. Al terminar, el
 * proceso se cierra solo y devuelve toda su memoria (unos cientos de MB).
 * Solo corre el modelo; preparar la imagen y limpiar el borde se hace en la app.
 */
public class AiService extends Service {
    public static final String X_MODEL = "model", X_DIR = "dir", X_THREADS = "threads", X_MIRROR = "mirror", X_PADX = "padx", X_W = "w";
    /** v8.39: modo ahorro de memoria. */
    public static final String X_LOWMEM = "lowmem";

    /**
     * v8.39: la app se "une" a este proceso mientras la IA trabaja (BIND_IMPORTANT): Android lo
     * trata como parte de la app que estas usando y, si falta memoria, cierra primero otras apps
     * en segundo plano en vez de la IA.
     */
    @Override public IBinder onBind(Intent intent) { return new android.os.Binder(); }

    @Override
    public int onStartCommand(final Intent it, int flags, final int startId) {
        if (it == null) { stopSelf(startId); return START_NOT_STICKY; }
        final String model = it.getStringExtra(X_MODEL), dir = it.getStringExtra(X_DIR);
        final int threads = it.getIntExtra(X_THREADS, 2), padX = it.getIntExtra(X_PADX, 0), w = it.getIntExtra(X_W, 0);
        final boolean mirror = it.getBooleanExtra(X_MIRROR, false);
        final boolean lowMem = it.getBooleanExtra(X_LOWMEM, false);
        if (model == null || dir == null) { stopSelf(startId); return START_NOT_STICKY; }
        Thread th = new Thread(new Runnable() {
            @Override public void run() {
                String st;
                try {
                    AiJob.run(new File(model), new File(dir), threads, mirror, padX, w, lowMem);
                    st = "ok";
                } catch (OutOfMemoryError oom) {
                    st = "error:memoria";
                } catch (Throwable e) {
                    String m = e.getMessage();
                    st = "error:" + e.getClass().getSimpleName() + (m != null ? " " + m.replace('\n', ' ') : "");
                    if (st.length() > 200) st = st.substring(0, 200);
                }
                try (FileOutputStream fo = new FileOutputStream(new File(dir, AiJob.STATE + ".tmp"))) {
                    fo.write(st.getBytes("UTF-8"));
                } catch (Throwable ignored) { }
                new File(dir, AiJob.STATE + ".tmp").renameTo(new File(dir, AiJob.STATE));
                stopSelf(startId);
                // el proceso de la IA se cierra: devuelve toda su memoria
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        }, "pz-ia-proceso");
        th.start();
        return START_NOT_STICKY;
    }
}
