package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.core.ProjectStore;
import com.pacco.animecut.core.Thumbs;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.view.CanvasView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements CanvasView.Callback {

    private static final int[] PALETTE = {
            0xFF000000, 0xFF444444, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF, 0xFF7A4A2B,
            0xFFE05A5A, 0xFFFF7A45, 0xFFFFB03A, 0xFFFFE05C, 0xFFB5E05A, 0xFF4FC66B,
            0xFF3DD6C0, 0xFF4DA3FF, 0xFF3D6BFF, 0xFF7B5CFF, 0xFFB558FF, 0xFFFF6FC3,
            0xFFFFE0C4, 0xFFF5C9A6, 0xFFD9A377, 0xFF9C6B4A, 0xFF2B2B3A, 0xFF1B3358
    };

    private CanvasView canvas;
    private TextView sliderLabel;
    private SeekBar slider;

    private ActivityResultLauncher<String> openImage;
    private ActivityResultLauncher<String> createZip;
    private ActivityResultLauncher<String> createPng;
    private ActivityResultLauncher<String> createProject;
    private ActivityResultLauncher<String[]> openProject;

    public static final String EXTRA_PROJECT = "obra";

    private String projectId;

    private byte[] pendingPngMask;
    private String lastError;
    private int lastExportCount;
    private int outW, outH;
    private int edgeClean = 1;
    private boolean saving = false;
    private final android.os.Handler previewHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private ProjectIO.Loaded loaded;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        canvas = findViewById(R.id.canvas);
        sliderLabel = findViewById(R.id.sliderLabel);
        slider = findViewById(R.id.slider);
        canvas.setCallback(this);

        openImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) loadImage(uri);
                    }
                });

        createZip = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/zip"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportZip(uri);
                    }
                });

        createPng = registerForActivityResult(new ActivityResultContracts.CreateDocument("image/png"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportPng(uri);
                    }
                });

        createProject = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) saveProjectTo(uri);
                    }
                });

        openProject = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) openProjectFrom(uri);
                    }
                });

        click(R.id.btnMenu, new Runnable() {
            public void run() {
                mainMenu();
            }
        });
        click(R.id.btnFit, new Runnable() {
            public void run() {
                if (needProject()) canvas.fit();
            }
        });
        click(R.id.btnUndo, new Runnable() {
            public void run() {
                canvas.doUndo();
                updateUi();
            }
        });
        click(R.id.btnRedo, new Runnable() {
            public void run() {
                canvas.doRedo();
                updateUi();
            }
        });
        click(R.id.btnAim, new Runnable() {
            public void run() {
                canvas.setAim(!canvas.isAim());
                canvas.showHud(canvas.isAim() ? "Cursor desplazado y lupa: SI" : "Cursor desplazado: NO");
                updateUi();
            }
        });
        click(R.id.btnSelMenu, new Runnable() {
            public void run() {
                selectionMenu();
            }
        });
        click(R.id.btnTools, new Runnable() {
            public void run() {
                toolGrid();
            }
        });
        click(R.id.btnSize, new Runnable() {
            public void run() {
                brushPresets();
            }
        });
        click(R.id.btnColor, new Runnable() {
            public void run() {
                colorDialog();
            }
        });
        click(R.id.btnSavePart, new Runnable() {
            public void run() {
                savePartDialog();
            }
        });
        click(R.id.btnLayers, new Runnable() {
            public void run() {
                toggleLayersPanel();
            }
        });
        click(R.id.btnLayersClose, new Runnable() {
            public void run() {
                findViewById(R.id.layersPanel).setVisibility(View.GONE);
            }
        });
        click(R.id.btnExport, new Runnable() {
            public void run() {
                exportDialog();
            }
        });
        click(R.id.btnAddMode, new Runnable() {
            public void run() {
                canvas.setSubtract(false);
                updateUi();
            }
        });
        click(R.id.btnSubMode, new Runnable() {
            public void run() {
                canvas.setSubtract(true);
                updateUi();
            }
        });
        click(R.id.btnSmart, new Runnable() {
            public void run() {
                canvas.setSmart(!canvas.isSmart());
                canvas.showHud(canvas.isSmart() ? "Fino: SI" : "Fino: NO");
                updateUi();
            }
        });
        click(R.id.btnLineart, new Runnable() {
            public void run() {
                lineArtDialog();
            }
        });

        // botones - y + de los sliders, para ajustar fino como en Ibis
        click(R.id.btnSizeMinus, new Runnable() {
            public void run() {
                slider.setProgress(Math.max(0, slider.getProgress() - 1));
            }
        });
        click(R.id.btnSizePlus, new Runnable() {
            public void run() {
                slider.setProgress(Math.min(slider.getMax(), slider.getProgress() + 1));
            }
        });
        final SeekBar op = findViewById(R.id.opacity);
        click(R.id.btnOpMinus, new Runnable() {
            public void run() {
                op.setProgress(Math.max(2, op.getProgress() - 5));
            }
        });
        click(R.id.btnOpPlus, new Runnable() {
            public void run() {
                op.setProgress(Math.min(100, op.getProgress() + 5));
            }
        });
        op.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                v = Math.max(2, v);
                canvas.setBrushOpacity(v / 100f);
                ((TextView) findViewById(R.id.opacityLabel)).setText(String.valueOf(v));
            }
        });

        installTooltips();

        slider.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                applySlider(v);
            }
        });

        canvas.setMode(CanvasView.MODE_WAND);
        syncSlider();
        updateUi();
        measureBars();

        projectId = getIntent().getStringExtra(EXTRA_PROJECT);
        if (projectId != null) {
            recoverFrom(ProjectStore.fileFor(this, projectId));
        } else {
            openImage.launch("image/*");
        }
    }

    private void measureBars() {
        final View top = findViewById(R.id.topBar);
        final View bottom = findViewById(R.id.bottomPanel);
        top.post(new Runnable() {
            @Override
            public void run() {
                canvas.setInsets(top.getHeight() + dp(12), bottom.getHeight());
                if (canvas.getProject() != null) canvas.fit();
            }
        });
    }

    private void mainMenu() {
        final java.util.List<String> items = new java.util.ArrayList<String>();
        items.add("Guia rapida: como se usa");
        items.add("Abrir otra imagen");
        items.add("Ajustes de la varita");
        items.add(canvas.isWandGlobal() ? "Varita global: SI (toda la imagen)" : "Varita global: NO (solo lo pegado)");
        items.add(canvas.isShowParts() ? "Partes guardadas en verde: SI" : "Partes guardadas en verde: NO");
        items.add(canvas.isAvoidParts() ? "No agarrar lo ya guardado: SI" : "No agarrar lo ya guardado: NO");
        items.add("Cerrar figura de las tijeras");
        items.add("Refinar borde (pelo y bordes finos)");
        items.add("Rellenar zonas sin pintar");
        items.add("Cerrar huecos de la trama");
        items.add("Expandir borde con decimales");
        items.add("Gama de colores");
        items.add("Invertir la seleccion");
        items.add("Limpiar la seleccion");
        items.add("Filtros de limpieza");
        items.add("Copiar seleccion");
        items.add("Cortar seleccion");
        items.add("Pegar");
        items.add("Girar la imagen");
        items.add("Estabilizador del trazo");
        items.add("Dureza del pincel");
        items.add("Guardar ahora");
        items.add("Guardar copia en un archivo");
        items.add("Que hace cada icono");

        new AlertDialog.Builder(this)
                .setTitle("Paint Zeta")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        runMenu(items.get(i));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Se elige por el texto, asi agregar opciones no descuadra nada. */
    private void runMenu(String item) {
        if (item.startsWith("Guia")) {
            guideDialog();
        } else if (item.startsWith("Abrir otra")) {
            openImage.launch("image/*");
        } else if (item.startsWith("Ajustes de la varita")) {
            wandDialog();
        } else if (item.startsWith("Varita global")) {
            canvas.setWandGlobal(!canvas.isWandGlobal());
            toast(canvas.isWandGlobal() ? "La varita busca ese color en toda la imagen"
                    : "La varita solo agarra lo que esta pegado");
            updateUi();
        } else if (item.startsWith("Partes guardadas")) {
            canvas.setShowParts(!canvas.isShowParts());
        } else if (item.startsWith("No agarrar")) {
            canvas.setAvoidParts(!canvas.isAvoidParts());
            toast(canvas.isAvoidParts() ? "Lo que ya guardaste no se vuelve a seleccionar"
                    : "Se puede volver a seleccionar lo ya guardado");
        } else if (item.startsWith("Cerrar figura")) {
            if (needProject()) canvas.scissorsClose();
        } else if (item.startsWith("Refinar")) {
            refineDialog();
        } else if (item.startsWith("Rellenar zonas")) {
            unpaintedDialog();
        } else if (item.startsWith("Cerrar huecos")) {
            closeHolesDialog();
        } else if (item.startsWith("Expandir")) {
            expandDialog();
        } else if (item.startsWith("Gama")) {
            colorRangeDialog();
        } else if (item.startsWith("Invertir")) {
            if (needProject()) canvas.invertSelection();
        } else if (item.startsWith("Limpiar")) {
            if (needProject()) canvas.clearSelection();
        } else if (item.startsWith("Filtros")) {
            filtersDialog();
        } else if (item.startsWith("Copiar")) {
            if (needProject()) canvas.copySelection(false);
        } else if (item.startsWith("Cortar")) {
            if (needProject()) canvas.copySelection(true);
        } else if (item.startsWith("Pegar")) {
            if (needProject()) canvas.paste(0, 0);
        } else if (item.startsWith("Girar")) {
            rotateDialog();
        } else if (item.startsWith("Estabilizador")) {
            stabilizerDialog();
        } else if (item.startsWith("Dureza")) {
            hardnessDialog();
        } else if (item.startsWith("Guardar ahora")) {
            if (needProject()) autosave(true);
        } else if (item.startsWith("Guardar copia")) {
            projectDialog();
        } else {
            helpDialog();
        }
    }

    /** Ajustes de la varita, al estilo de los de Ibis. */
    private void wandDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Fuerza: " + canvas.getTolerance());
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tTol.setText("Fuerza: " + v);
            }
        });
        root.addView(tTol);
        root.addView(sTol);

        final TextView tSoft = new TextView(this);
        final SeekBar sSoft = new SeekBar(this);
        sSoft.setMax(120);
        sSoft.setProgress(canvas.getSoftness());
        tSoft.setText("Suavidad del borde: " + canvas.getSoftness());
        sSoft.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tSoft.setText("Suavidad del borde: " + v);
            }
        });
        root.addView(tSoft);
        root.addView(sSoft);

        final TextView tExp = new TextView(this);
        final SeekBar sExp = new SeekBar(this);
        sExp.setMax(80); // -3.0 .. +5.0 en pasos de 0.1
        sExp.setProgress(Math.round((canvas.getExpansion() + 3f) * 10f));
        tExp.setText(expLabel(canvas.getExpansion()));
        sExp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tExp.setText(expLabel(v / 10f - 3f));
            }
        });
        root.addView(tExp);
        root.addView(sExp);

        final CheckBox cbGap = new CheckBox(this);
        cbGap.setText("Reconocimiento de huecos (linea abierta)");
        cbGap.setChecked(canvas.isGapOn());
        root.addView(cbGap);

        final TextView tGap = new TextView(this);
        final SeekBar sGap = new SeekBar(this);
        sGap.setMax(12);
        sGap.setProgress(canvas.getGapRadius());
        tGap.setText("Tamano del hueco que tapa: " + canvas.getGapRadius() + " px");
        sGap.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tGap.setText("Tamano del hueco que tapa: " + v + " px");
            }
        });
        root.addView(tGap);
        root.addView(sGap);

        final TextView tMode = new TextView(this);
        tMode.setText("Como compara el color");
        tMode.setPadding(0, dp(10), 0, 0);
        root.addView(tMode);
        final RadioGroup rg = new RadioGroup(this);
        String[] names = {"Exacto (RGB)", "Por tono, ignora sombras", "Como lo ve el ojo (Lab)"};
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(1000 + i);
            rg.addView(rb);
        }
        rg.check(1000 + canvas.getColorMode());
        root.addView(rg);

        new AlertDialog.Builder(this)
                .setTitle("Varita y balde")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.setSoftness(sSoft.getProgress());
                        canvas.setExpansion(sExp.getProgress() / 10f - 3f);
                        canvas.setGap(cbGap.isChecked(), Math.max(1, sGap.getProgress()));
                        int m = rg.getCheckedRadioButtonId() - 1000;
                        canvas.setColorMode(m < 0 ? ColorDist.RGB : m);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNeutralButton("Valores de fabrica", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(28);
                        canvas.setSoftness(24);
                        canvas.setExpansion(1.5f);
                        canvas.setGap(false, 4);
                        canvas.setColorMode(ColorDist.RGB);
                        syncSlider();
                        updateUi();
                        toast("Restablecido");
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private String expLabel(float v) {
        return String.format(Locale.US, "Expansion del borde: %.1f px", v);
    }

    /** Gama de colores, con vista previa mientras mueves el margen. */
    private void colorRangeDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView info = new TextView(this);
        info.setText("Se usa el color cargado. Mueve el margen y mira el lienzo: la seleccion se actualiza sola.");
        root.addView(info);

        final View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        lp.topMargin = dp(8);
        sw.setLayoutParams(lp);
        sw.setBackgroundColor(canvas.getColor());
        root.addView(sw);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Margen: " + canvas.getTolerance());
        root.addView(tTol);
        root.addView(sTol);

        final CheckBox replace = new CheckBox(this);
        replace.setText("Reemplazar la seleccion actual");
        replace.setChecked(true);
        root.addView(replace);

        canvas.beginPreview();
        final Runnable[] pending = new Runnable[1];
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, final int v, boolean u) {
                tTol.setText("Margen: " + v);
                if (pending[0] != null) previewHandler.removeCallbacks(pending[0]);
                pending[0] = new Runnable() {
                    @Override
                    public void run() {
                        canvas.previewColorRange(canvas.getColor(), v, replace.isChecked());
                    }
                };
                previewHandler.postDelayed(pending[0], 180);
            }
        });
        canvas.previewColorRange(canvas.getColor(), sTol.getProgress(), replace.isChecked());

        new AlertDialog.Builder(this)
                .setTitle("Gama de colores")
                .setView(scroll)
                .setCancelable(false)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.endPreview(true);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.endPreview(false);
                    }
                })
                .show();
    }

    private void refineDialog() {
        if (!needProject()) return;
        final String[] items = {"Suave (pelo fino)", "Medio", "Fuerte"};
        final int[] rad = {6, 12, 20};
        final float[] eps = {0.0004f, 0.0016f, 0.006f};
        new AlertDialog.Builder(this)
                .setTitle("Refinar borde")
                .setMessage("Hace que el borde de la seleccion siga el dibujo real. Para pelo y bordes finos.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.refineEdge(rad[i], eps[i]);
                    }
                })
                .show();
    }

    private void unpaintedDialog() {
        if (!needProject()) return;
        final String[] items = {"Solo huecos chicos", "Huecos medianos", "Huecos grandes", "Todos los huecos"};
        final int[] vals = {2, 8, 30, 0};
        new AlertDialog.Builder(this)
                .setTitle("Rellenar zonas sin pintar")
                .setMessage("Rellena los huecos que quedaron encerrados dentro de la seleccion, sin deformar el contorno de afuera.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(5, vals[i]);
                    }
                })
                .show();
    }

    private void filtersDialog() {
        if (!needProject()) return;
        final String[] items = {
                "Quitar ruido de JPEG (mediana)",
                "Aplanar tonos (posterizar)",
                "Niveles: mas contraste",
                "Extraer line art"
        };
        new AlertDialog.Builder(this)
                .setTitle("Filtros de limpieza")
                .setMessage("Aplicar uno antes de seleccionar hace que la varita agarre mucho mejor.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                canvas.applyFilter(0, 0, 0, 0);
                                break;
                            case 1:
                                posterizeDialog();
                                break;
                            case 2:
                                canvas.applyFilter(2, 25, 230, 100);
                                break;
                            default:
                                lineArtFilterDialog();
                                break;
                        }
                    }
                })
                .show();
    }

    private void posterizeDialog() {
        final String[] items = {"4 tonos", "6 tonos", "10 tonos", "16 tonos"};
        final int[] vals = {4, 6, 10, 16};
        new AlertDialog.Builder(this)
                .setTitle("Aplanar tonos")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.applyFilter(1, vals[i], 0, 0);
                    }
                })
                .show();
    }

    /** Extraer line art con sus tres controles, como el filtro de Ibis. */
    private void lineArtFilterDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tw = new TextView(this);
        final SeekBar sw = new SeekBar(this);
        sw.setMax(255);
        sw.setProgress(210);
        tw.setText("Blanco: 210");
        sw.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tw.setText("Blanco: " + v);
            }
        });
        root.addView(tw);
        root.addView(sw);

        final TextView tb = new TextView(this);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(255);
        sb.setProgress(40);
        tb.setText("Negro: 40");
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tb.setText("Negro: " + v);
            }
        });
        root.addView(tb);
        root.addView(sb);

        final TextView tm = new TextView(this);
        final SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(50);
        tm.setText("Medio: 50");
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tm.setText("Medio: " + Math.max(1, v));
            }
        });
        root.addView(tm);
        root.addView(sm);

        new AlertDialog.Builder(this)
                .setTitle("Extraer line art")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.applyFilter(3, sw.getProgress(), sb.getProgress(),
                                Math.max(1, sm.getProgress()));
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void stabilizerDialog() {
        final String[] items = {"Apagado", "Suave", "Medio", "Fuerte"};
        final float[] vals = {0f, 0.5f, 0.72f, 0.88f};
        new AlertDialog.Builder(this)
                .setTitle("Estabilizador del trazo")
                .setMessage("Corrige el pulso. Cuanto mas fuerte, mas suave sale la linea, pero responde con mas retraso.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setStabilizer(vals[i]);
                        toast("Estabilizador: " + items[i]);
                    }
                })
                .show();
    }

    private void expandDialog() {
        if (!needProject()) return;
        final String[] items = {"+0.5 px", "+1.0 px", "+1.5 px", "+2.0 px", "-0.5 px", "-1.0 px"};
        final float[] vals = {0.5f, 1f, 1.5f, 2f, -0.5f, -1f};
        new AlertDialog.Builder(this)
                .setTitle("Expandir o contraer con decimales")
                .setMessage("Lo positivo se come el antialias del contorno y quita los cuadraditos blancos.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.expandSelection(vals[i]);
                    }
                })
                .show();
    }

    /** Quita los puntitos que deja la trama del manga dentro de la seleccion. */
    private void closeHolesDialog() {
        if (!needProject()) return;
        final String[] items = {"Puntos chicos (1 px)", "Medianos (2 px)", "Grandes (3 px)", "Muy grandes (5 px)"};
        final int[] vals = {1, 2, 3, 5};
        new AlertDialog.Builder(this)
                .setTitle("Cerrar huecos de la trama")
                .setMessage("Rellena los puntitos blancos que la trama deja dentro de lo que seleccionaste.")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(4, vals[i]);
                    }
                })
                .show();
    }

    private void guideIfFirstTime() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("guia", false)) return;
        sp.edit().putBoolean("guia", true).apply();
        guideDialog();
    }

    /** Lo minimo para entender la app. */
    private void guideDialog() {
        String t = "Tu trabajo en 5 pasos:\n\n"
                + "1. Abres la imagen.\n\n"
                + "2. SACAR EL PERSONAJE: herramienta Borrar fondo. Pasa el pincel por el borde: "
                + "solo borra el color que queda en el centro de la cruz. La mira de arriba pone el "
                + "cursor separado del dedo y una lupa.\n\n"
                + "3. LAS PARTES: herramienta Separar partes. Raya cada parte con su color (pelo, cara, "
                + "ojos, manos) y el fondo en gris. Rayones toscos, sin cuidado. Toca el check verde "
                + "y cada parte sale en su capa, cortada justo en la linea negra.\n\n"
                + "4. RECONSTRUIR LO DE ATRAS: en Capas toca la parte que sacaste (ojo, boca, "
                + "mechon, brazo). Despues, en herramientas:\n"
                + "  Continuar linea: traza por donde seguia la linea cortada.\n"
                + "  Rellenar zona: toca cada zona del hueco y queda con su color plano.\n"
                + "  Copiar zona: pinta en verde de donde copiar sombras o brillos, y el check.\n"
                + "  Corrector: como clonar, pero funde el color.\n"
                + "  Trama manga: toca la trama de al lado y la continua.\n\n"
                + "5. La flecha de abajo exporta todo para Alight Motion.";
        new AlertDialog.Builder(this)
                .setTitle("Como se usa")
                .setMessage(t)
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void helpDialog() {
        String t = "ARRIBA\n"
                + "Tres puntos: este menu\n"
                + "Flechas: deshacer y rehacer\n"
                + "Esquinas: encuadrar la imagen\n"
                + "Rombo con mas: crear capa de la seleccion\n"
                + "Rombos: lista de capas\n"
                + "Flecha abajo: exportar el ZIP\n\n"
                + "IZQUIERDA, herramientas\n"
                + "Varita: selecciona el color que tocas\n"
                + "Lazo: rodea una zona con el dedo\n"
                + "Tijeras: la linea se pega sola al contorno\n"
                + "Cuadros con flecha: mover la seleccion\n"
                + "Pincel y goma: corrigen la seleccion\n"
                + "Rodillo: pinta con el color cargado\n"
                + "Balde: rellena de color una zona\n"
                + "Gotero: toma un color de la imagen\n"
                + "Dos cuadros: clonar, copia de un lado a otro\n"
                + "Cruz: mover la imagen\n\n"
                + "ABAJO\n"
                + "Circulo de color: abre la paleta\n"
                + "Diana: pincel fino, se queda en el color que tocas\n"
                + "Globo: la varita busca ese color en toda la imagen\n"
                + "Menos: restar de la seleccion\n"
                + "Linea: usa el line art como barrera\n"
                + "Cuadro punteado: ajustar el borde\n\n"
                + "GESTOS\n"
                + "Dos dedos, toque: deshacer\n"
                + "Tres dedos, toque: rehacer\n"
                + "Dos dedos arrastrando: mover y hacer zoom\n"
                + "Dos dedos en circulo: girar el lienzo\n"
                + "Mantener pulsado: gotero rapido con burbuja de color";
        new AlertDialog.Builder(this)
                .setTitle("Que hace cada icono")
                .setMessage(t)
                .setPositiveButton("Entendido", null)
                .show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        autosave(false);
    }

    /** Manten pulsado cualquier boton y te dice que es. */
    private void installTooltips() {
        int[] ids = {R.id.btnAim, R.id.btnUndo, R.id.btnRedo, R.id.btnSelMenu, R.id.btnFit, R.id.btnMenu,
                R.id.btnTools, R.id.btnSize, R.id.btnColor, R.id.btnSavePart, R.id.btnLayers,
                R.id.btnExport, R.id.btnAddMode, R.id.btnSubMode, R.id.btnSmart, R.id.btnLineart};
        String[] names = {"Cursor desplazado y lupa", "Deshacer", "Rehacer", "Seleccion", "Encuadrar", "Mas opciones",
                "Herramientas", "Tipo de pincel", "Color", "Guardar parte (capa de lo azul)",
                "Capas", "Exportar", "Agregar a la seleccion", "Quitar de la seleccion",
                "Fino: se queda en el color que tocas", "Line art: la linea hace de pared"};
        for (int i = 0; i < ids.length; i++) {
            final String n = names[i];
            findViewById(ids[i]).setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    toast(n);
                    return true;
                }
            });
        }
    }

    private void tool(int id, final int mode) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canvas.setMode(mode);
                if (mode == CanvasView.MODE_CLONE) canvas.resetCloneSource();
                if (mode == CanvasView.MODE_PICKER) toast("Toca la imagen para tomar ese color");
                if (mode == CanvasView.MODE_SCISSORS) {
                    toast("Arrastra siguiendo el contorno. Vuelve al punto verde para cerrar");
                }
                if (mode == CanvasView.MODE_MOVE) toast("Arrastra para mover la seleccion");
                syncSlider();
                updateUi();
            }
        });
    }

    private void click(int id, final Runnable r) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
    }

    // ------------------------------------------------------------------
    // Imagen
    // ------------------------------------------------------------------

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    private void loadImage(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            if (bmp == null) {
                toast("No se pudo leer la imagen");
                return;
            }
            canvas.setProject(new Project(bmp));
            toast("Cargada a " + bmp.getWidth() + " x " + bmp.getHeight());
            updateUi();
            guideIfFirstTime();
        } catch (OutOfMemoryError err) {
            toast("La imagen es demasiado grande para la memoria del telefono");
        } catch (Exception ex) {
            toast("Error al abrir: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // Capas
    // ------------------------------------------------------------------

    private static final String[] PART_NAMES = {
            "pelo", "pelo_atras", "flequillo", "cara", "ojo_izq", "ojo_der", "cejas",
            "boca", "cuello", "cuerpo", "ropa", "brazo_izq", "brazo_der", "mano_izq",
            "mano_der", "pierna_izq", "pierna_der", "accesorio", "fondo"
    };

    /** Un toque: eliges el nombre de la parte y queda guardada. */
    private void savePartDialog() {
        if (!needProject()) return;
        if (!canvas.getProject().hasSelection()) {
            toast("Primero selecciona la parte: se tiene que ver azul");
            return;
        }
        final String[] items = new String[PART_NAMES.length + 1];
        for (int i = 0; i < PART_NAMES.length; i++) items[i] = PART_NAMES[i].replace('_', ' ');
        items[PART_NAMES.length] = "Otro nombre...";
        new AlertDialog.Builder(this)
                .setTitle("Que parte es")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i < PART_NAMES.length) {
                            addLayerFromSelection(uniqueName(PART_NAMES[i]));
                        } else {
                            customPartName();
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void customPartName() {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la parte")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        addLayerFromSelection(uniqueName(s.isEmpty() ? "parte" : s));
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Si ya hay un "ojo_izq", el siguiente se llama "ojo_izq_2". */
    private String uniqueName(String base) {
        Project p = canvas.getProject();
        String name = base;
        int n = 2;
        boolean clash = true;
        while (clash) {
            clash = false;
            for (Layer l : p.layers) {
                if (l.name.equals(name)) {
                    clash = true;
                    name = base + "_" + n++;
                    break;
                }
            }
        }
        return name;
    }

    private void addLayerFromSelection(String name) {
        final Project p = canvas.getProject();
        if (p == null || !p.hasSelection()) return;
        byte[] mask = new byte[p.selection.length];
        System.arraycopy(p.selection, 0, mask, 0, mask.length);
        p.layers.add(new Layer(name, mask));
        p.active = p.layers.size() - 1;
        canvas.clearSelection();
        canvas.layersChanged();
        canvas.refreshParts();
        canvas.showHud("Guardada: " + name.replace('_', ' '));
        updateUi();
        if (findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE) buildLayersPanel();
        autosave(false);
    }




    private void toggleLayersPanel() {
        if (!needProject()) return;
        View panel = findViewById(R.id.layersPanel);
        if (panel.getVisibility() == View.VISIBLE) {
            panel.setVisibility(View.GONE);
        } else {
            buildLayersPanel();
            panel.setVisibility(View.VISIBLE);
        }
    }







    // ------------------------------------------------------------------
    // Herramientas: cuadricula de iconos como la de Ibis
    // ------------------------------------------------------------------

    private static final int[] TOOL_MODES = {
            CanvasView.MODE_BGERASE, CanvasView.MODE_MARKER,
            CanvasView.MODE_WAND, CanvasView.MODE_MAGNET,
            CanvasView.MODE_SCISSORS, CanvasView.MODE_LASSO,
            CanvasView.MODE_BRUSH, CanvasView.MODE_ERASER,
            CanvasView.MODE_PAINT, CanvasView.MODE_BUCKET,
            CanvasView.MODE_PICKER, CanvasView.MODE_CLONE,
            CanvasView.MODE_MOVE, CanvasView.MODE_PAN,
            CanvasView.MODE_LINE, CanvasView.MODE_ZONE,
            CanvasView.MODE_PATCH, CanvasView.MODE_HEAL,
            CanvasView.MODE_TONE
    };
    private static final String[] TOOL_NAMES = {
            "Borrar fondo", "Separar partes",
            "Varita", "Magnetico",
            "Tijeras", "Lazo",
            "Pincel sel.", "Goma",
            "Brocha", "Relleno",
            "Gotero", "Clonar",
            "Mover sel.", "Mano",
            "Continuar linea", "Rellenar zona",
            "Copiar zona", "Corrector",
            "Trama manga"
    };

    private int toolIcon(int mode) {
        switch (mode) {
            case CanvasView.MODE_LASSO: return R.drawable.ic_lasso;
            case CanvasView.MODE_SCISSORS: return R.drawable.ic_scissors;
            case CanvasView.MODE_BRUSH: return R.drawable.ic_brush;
            case CanvasView.MODE_ERASER: return R.drawable.ic_eraser;
            case CanvasView.MODE_PAINT: return R.drawable.ic_paint;
            case CanvasView.MODE_BUCKET: return R.drawable.ic_bucket;
            case CanvasView.MODE_PICKER: return R.drawable.ic_picker;
            case CanvasView.MODE_CLONE: return R.drawable.ic_clone;
            case CanvasView.MODE_MOVE: return R.drawable.ic_move;
            case CanvasView.MODE_PAN: return R.drawable.ic_hand;
            case CanvasView.MODE_BGERASE: return R.drawable.ic_bgerase;
            case CanvasView.MODE_MARKER: return R.drawable.ic_marker;
            case CanvasView.MODE_MAGNET: return R.drawable.ic_magnet;
            case CanvasView.MODE_LINE: return R.drawable.ic_line_cont;
            case CanvasView.MODE_ZONE: return R.drawable.ic_zone;
            case CanvasView.MODE_PATCH: return R.drawable.ic_patch_fill;
            case CanvasView.MODE_HEAL: return R.drawable.ic_heal;
            case CanvasView.MODE_TONE: return R.drawable.ic_tone;
            default: return R.drawable.ic_wand;
        }
    }

    private void toolGrid() {
        int[] icons = new int[TOOL_MODES.length];
        Runnable[] actions = new Runnable[TOOL_MODES.length];
        int active = -1;
        for (int i = 0; i < TOOL_MODES.length; i++) {
            final int m = TOOL_MODES[i];
            icons[i] = toolIcon(m);
            if (m == canvas.getMode()) active = i;
            actions[i] = new Runnable() {
                public void run() {
                    selectTool(m);
                }
            };
        }
        showIconGrid(null, icons, TOOL_NAMES, actions, 2, active);
    }

    private void selectTool(int mode) {
        canvas.setMode(mode);
        if (mode == CanvasView.MODE_BGERASE) canvas.showHud("Pasa el pincel por el borde: solo borra el color del centro");
        if (mode == CanvasView.MODE_MARKER) canvas.showHud("Raya cada parte con su color y toca el check");
        if (mode == CanvasView.MODE_MAGNET) canvas.showHud("Arrastra por el contorno: se pega solo");
        if (mode == CanvasView.MODE_LINE || mode == CanvasView.MODE_ZONE
                || mode == CanvasView.MODE_PATCH || mode == CanvasView.MODE_TONE) {
            canvas.enterRepairMode();
        }
        if (mode == CanvasView.MODE_LINE) canvas.showHud("Traza por donde sigue la linea cortada");
        if (mode == CanvasView.MODE_ZONE) canvas.showHud("Toca cada zona del hueco");
        if (mode == CanvasView.MODE_PATCH) canvas.showHud("Pinta en verde de donde copiar y toca el check");
        if (mode == CanvasView.MODE_HEAL) canvas.resetCloneSource();
        if (mode == CanvasView.MODE_TONE) canvas.showHud("Toca la trama de al lado del hueco");
        if (mode == CanvasView.MODE_CLONE) canvas.resetCloneSource();
        if (mode == CanvasView.MODE_ERASER) {
            Project p = canvas.getProject();
            if (p != null && p.activeLayer() == null) {
                canvas.showHud("Al borrar se crea una capa con la imagen");
            }
        }
        syncSlider();
        updateUi();
    }

    /** Menu de seleccion con iconos, como el cuadro punteado de Ibis. */
    private void selectionMenu() {
        if (!needProject()) return;
        int[] icons = {R.drawable.ic_layer_add, R.drawable.ic_sel_delete, R.drawable.ic_sel_keep,
                R.drawable.ic_sel_invert, R.drawable.ic_close, R.drawable.ic_grow,
                R.drawable.ic_refine, R.drawable.ic_holes, R.drawable.ic_range,
                R.drawable.ic_scissors, R.drawable.ic_patch};
        String[] names = {"Guardar parte", "Borrar area", "Dejar solo esto", "Invertir",
                "Quitar", "Ampliar", "Refinar borde", "Cerrar puntos", "Gama color",
                "Cerrar tijeras", "Tapar hueco"};
        Runnable[] actions = {
                new Runnable() { public void run() { savePartDialog(); } },
                new Runnable() { public void run() { canvas.eraseSelectionFromLayer(); } },
                new Runnable() { public void run() { canvas.keepSelectionInLayer(); } },
                new Runnable() { public void run() { canvas.invertSelection(); } },
                new Runnable() { public void run() { canvas.clearSelection(); } },
                new Runnable() { public void run() { expandDialog(); } },
                new Runnable() { public void run() { refineDialog(); } },
                new Runnable() { public void run() { closeHolesDialog(); } },
                new Runnable() { public void run() { colorRangeDialog(); } },
                new Runnable() { public void run() { canvas.scissorsClose(); } },
                new Runnable() { public void run() { canvas.fillHoleUnderActive(); } }
        };
        showIconGrid(null, icons, names, actions, 3, -1);
    }

    private void showIconGridTinted(int[] icons, String[] names, Runnable[] actions, int cols,
                                    int active, int[] tints) {
        tintNext = tints;
        showIconGrid(null, icons, names, actions, cols, active);
        tintNext = null;
    }

    private int[] tintNext;

    /** Cuadricula de iconos con su nombre corto debajo. */
    private void showIconGrid(String title, int[] icons, String[] names, final Runnable[] actions,
                              int cols, int active) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                root.addView(row);
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(4), dp(10), dp(4), dp(10));
            cell.setBackgroundResource(i == active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(3), dp(3), dp(3), dp(3));
            cell.setLayoutParams(clp);

            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
            img.setImageResource(icons[i]);
            if (tintNext != null && i < tintNext.length) img.setColorFilter(tintNext[i]);
            cell.addView(img);

            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, dp(4), 0, 0);
            cell.addView(t);

            final int idx = i;
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    actions[idx].run();
                }
            });
            row.addView(cell);
        }
        // rellenar la ultima fila para que no se estiren las celdas
        int rest = icons.length % cols;
        if (rest != 0 && row != null) {
            for (int k = rest; k < cols; k++) {
                View v = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
                v.setLayoutParams(lp);
                row.addView(v);
            }
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setView(root);
        if (title != null) b.setTitle(title);
        dlg[0] = b.create();
        dlg[0].show();
    }

    /** Tipos de pincel, como la lista de brochas de Ibis. */
    private void brushPresets() {
        final String[] names = {"Pluma suave", "Pluma fuerte", "Rotulador fino", "Rotulador",
                "Lapiz difuminado", "Aerografo"};
        final float[] sizes = {22f, 30f, 3f, 8f, 60f, 80f};
        final float[] hard = {0.35f, 1f, 0.9f, 0.9f, 0.1f, 0.05f};
        final int[] opac = {100, 100, 100, 100, 100, 30};

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < names.length; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setBackgroundResource(R.drawable.bg_cell);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
            img.setImageBitmap(strokePreview(dp(260), dp(36), sizes[i], hard[i], opac[i]));
            row.addView(img);
            TextView t = new TextView(this);
            t.setText(names[i] + "   " + (int) sizes[i] + " px");
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12f);
            row.addView(t);
            final int idx = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dlg[0].dismiss();
                    canvas.setBrushSize(sizes[idx]);
                    canvas.setHardness(hard[idx]);
                    ((SeekBar) findViewById(R.id.opacity)).setProgress(opac[idx]);
                    syncSlider();
                    updateUi();
                    canvas.showHud(names[idx]);
                }
            });
            root.addView(row);
        }
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        dlg[0] = new AlertDialog.Builder(this).setView(sc).create();
        dlg[0].show();
    }

    /** Dibuja una muestra del trazo para la lista de pinceles. */
    private Bitmap strokePreview(int w, int h, float size, float hardness, int opacity) {
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setStyle(android.graphics.Paint.Style.STROKE);
        p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        p.setColor(0xFFFFFFFF);
        p.setAlpha(opacity * 255 / 100);
        float sw = Math.max(1.5f, Math.min(h * 0.7f, size * 0.35f));
        p.setStrokeWidth(sw);
        if (hardness < 0.8f) {
            p.setMaskFilter(new android.graphics.BlurMaskFilter(
                    Math.max(1f, sw * (1f - hardness) * 0.6f),
                    android.graphics.BlurMaskFilter.Blur.NORMAL));
        }
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(sw, h / 2f);
        path.cubicTo(w * 0.3f, h * 0.1f, w * 0.6f, h * 0.9f, w - sw, h / 2f);
        c.drawPath(path, p);
        return b;
    }

    // ------------------------------------------------------------------
    // Panel de capas como el de Ibis
    // ------------------------------------------------------------------

    private void buildLayersPanel() {
        final Project p = canvas.getProject();
        LinearLayout list = findViewById(R.id.layersList);
        list.removeAllViews();
        if (p == null) return;

        // fila de la seleccion
        LinearLayout sel = rowBase(false);
        sel.addView(thumb(Thumbs.forMask(p, p.selection, 96)));
        sel.addView(rowText("Seleccion", p.hasSelection() ? "con algo marcado" : "vacia", true));
        list.addView(sel);

        // capas, la ultima arriba
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            final int idx = i;
            final Layer l = p.layers.get(i);
            LinearLayout row = rowBase(p.active == i);
            ImageView th = thumb(Thumbs.forLayer(p, l, 96));
            row.addView(th);
            row.addView(rowText(l.name, (l.opacity * 100 / 255) + "%", l.visible));
            row.addView(iconButton(l.visible ? R.drawable.ic_eye : R.drawable.ic_eye_off,
                    l.visible ? "Ocultar" : "Mostrar", new Runnable() {
                        public void run() {
                            l.visible = !l.visible;
                            canvas.layersChanged();
                            buildLayersPanel();
                        }
                    }));
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    canvas.setActive(idx);
                    buildLayersPanel();
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    renameDialog(l);
                    return true;
                }
            });
            list.addView(row);
        }

        // la imagen original, abajo del todo
        LinearLayout base = rowBase(p.active == -1);
        base.addView(thumb(Thumbs.forMask(p, null, 96)));
        base.addView(rowText("Imagen original", p.baseVisible ? "visible" : "oculta", p.baseVisible));
        base.addView(iconButton(p.baseVisible ? R.drawable.ic_eye : R.drawable.ic_eye_off,
                p.baseVisible ? "Ocultar imagen" : "Mostrar imagen", new Runnable() {
                    public void run() {
                        canvas.setBaseVisible(!p.baseVisible);
                        buildLayersPanel();
                    }
                }));
        base.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canvas.setActive(-1);
                buildLayersPanel();
            }
        });
        list.addView(base);

        buildLayerActions();
    }

    /** Botones de abajo del panel: actuan sobre la capa marcada en azul. */
    private void buildLayerActions() {
        LinearLayout bar = findViewById(R.id.layersActions);
        bar.removeAllViews();
        bar.addView(iconButton(R.drawable.ic_dup, "Duplicar", new Runnable() {
            public void run() {
                canvas.duplicateActive();
                buildLayersPanel();
                autosave(false);
            }
        }));
        bar.addView(iconButton(R.drawable.ic_layer_add, "Capa de lo seleccionado", new Runnable() {
            public void run() {
                savePartDialog();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_patch, "Tapar el hueco debajo", new Runnable() {
            public void run() {
                canvas.fillHoleUnderActive();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_up, "Subir", new Runnable() {
            public void run() {
                moveActive(1);
            }
        }));
        bar.addView(iconButton(R.drawable.ic_down, "Bajar", new Runnable() {
            public void run() {
                moveActive(-1);
            }
        }));
        bar.addView(iconButton(R.drawable.ic_opacity, "Opacidad", new Runnable() {
            public void run() {
                Layer l = canvas.getProject().activeLayer();
                if (l == null) toast("Toca una capa primero");
                else opacityDialog(l);
            }
        }));
        bar.addView(iconButton(R.drawable.ic_trash, "Eliminar capa", new Runnable() {
            public void run() {
                Project p = canvas.getProject();
                Layer l = p.activeLayer();
                if (l == null) {
                    toast("Toca una capa primero");
                    return;
                }
                p.layers.remove(p.active);
                p.active = Math.min(p.active, p.layers.size() - 1);
                canvas.layersChanged();
                buildLayersPanel();
                updateUi();
            }
        }));
    }

    /** Opciones propias de la herramienta, solo iconos. */
    private void buildOptBar(int mode) {
        LinearLayout bar = findViewById(R.id.optBar);
        bar.removeAllViews();
        if (mode == CanvasView.MODE_BGERASE) {
            bar.setVisibility(View.VISIBLE);
            ImageButton once = iconButton(canvas.isBgOnce() ? R.drawable.ic_once : R.drawable.ic_cont,
                    canvas.isBgOnce() ? "Toma el color una vez" : "Toma el color todo el rato",
                    new Runnable() {
                        public void run() {
                            canvas.setBgOnce(!canvas.isBgOnce());
                            canvas.showHud(canvas.isBgOnce() ? "Color: una vez al tocar"
                                    : "Color: sigue al pincel");
                            updateUi();
                        }
                    });
            bar.addView(once);
            int lim = canvas.getBgLimit();
            int icon = lim == 0 ? R.drawable.ic_lim_cont : lim == 1 ? R.drawable.ic_lim_disp : R.drawable.ic_lim_edge;
            final String[] names = {"Contiguo: solo lo pegado", "Disperso: tambien entre mechones",
                    "Bordes: respeta el contorno"};
            bar.addView(iconButton(icon, names[lim], new Runnable() {
                public void run() {
                    canvas.setBgLimit((canvas.getBgLimit() + 1) % 3);
                    canvas.showHud(names[canvas.getBgLimit()]);
                    updateUi();
                }
            }));
            ImageButton lock = iconButton(R.drawable.ic_lock, "Proteger el color de pintar", new Runnable() {
                public void run() {
                    canvas.setProtect(!canvas.isProtect());
                    canvas.showHud(canvas.isProtect() ? "Protegido el color cargado" : "Sin proteccion");
                    updateUi();
                }
            });
            lock.setBackgroundResource(canvas.isProtect() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(lock);
            bar.addView(iconButton(R.drawable.ic_range, "Cuanto se parece el color", new Runnable() {
                public void run() {
                    toleranceDialog();
                }
            }));
        } else if (mode == CanvasView.MODE_MARKER) {
            bar.setVisibility(View.VISIBLE);
            int lab = canvas.getMarkerLabel();
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            sw.setLayoutParams(lp);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(CanvasView.LABEL_COLORS[lab - 1]);
            g.setStroke(dp(2), 0xFFFFFFFF);
            sw.setBackground(g);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    labelPicker();
                }
            });
            bar.addView(sw);
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar rayones", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todos los rayones", new Runnable() {
                public void run() {
                    canvas.clearMarkers();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Separar las partes", new Runnable() {
                public void run() {
                    canvas.separateParts();
                    autosave(false);
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else {
            bar.setVisibility(View.GONE);
        }
    }

    private void toleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getTolerance());
        final TextView t = new TextView(this);
        t.setText(String.valueOf(canvas.getTolerance()));
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText(String.valueOf(v));
                canvas.setTolerance(v);
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Elegir que parte se esta rayando: un color por parte, el gris es el fondo. */
    private void labelPicker() {
        int n = CanvasView.LABEL_NAMES.length;
        int[] icons = new int[n];
        String[] names = new String[n];
        Runnable[] actions = new Runnable[n];
        for (int i = 0; i < n; i++) {
            icons[i] = R.drawable.ic_color;
            names[i] = CanvasView.LABEL_NAMES[i].replace('_', ' ');
            final int lab = i + 1;
            actions[i] = new Runnable() {
                public void run() {
                    canvas.setMarkerLabel(lab);
                    canvas.setSubtract(false);
                    canvas.showHud("Rayando: " + CanvasView.LABEL_NAMES[lab - 1].replace('_', ' '));
                    updateUi();
                }
            };
        }
        showIconGridTinted(icons, names, actions, 3, canvas.getMarkerLabel() - 1, CanvasView.LABEL_COLORS);
    }

    private void moveActive(int delta) {
        Project p = canvas.getProject();
        int i = p.active;
        int t = i + delta;
        if (i < 0 || t < 0 || t >= p.layers.size()) return;
        Layer a = p.layers.get(i);
        p.layers.set(i, p.layers.get(t));
        p.layers.set(t, a);
        p.active = t;
        canvas.layersChanged();
        buildLayersPanel();
    }

    private ImageView thumb(Bitmap b) {
        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageBitmap(b);
        return img;
    }

    private TextView rowText(String name, String sub, boolean bright) {
        TextView t = new TextView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(10);
        t.setLayoutParams(lp);
        t.setText(name + "\n" + sub);
        t.setTextColor(bright ? 0xFFFFFFFF : 0xFF7A7A7A);
        t.setTextSize(13f);
        return t;
    }

    private LinearLayout rowBase(boolean on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);
        return row;
    }

    private ImageButton iconButton(int icon, final String name, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setImageResource(icon);
        b.setContentDescription(name);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                toast(name);
                return true;
            }
        });
        return b;
    }

    private void opacityDialog(final Layer l) {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(l.opacity * 100 / 255);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        final TextView t = new TextView(this);
        t.setText("Opacidad: " + bar.getProgress() + "%");
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Opacidad: " + v + "%");
            }
        });
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setView(root)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        l.opacity = bar.getProgress() * 255 / 100;
                        canvas.layersChanged();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void layersDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        if (p.layers.isEmpty()) {
            toast("Todavia no hay capas");
            return;
        }
        final String[] items = new String[p.layers.size()];
        for (int i = 0; i < items.length; i++) {
            Layer l = p.layers.get(i);
            items[i] = (l.visible ? "[visible] " : "[oculta]  ") + l.name;
        }
        new AlertDialog.Builder(this)
                .setTitle("Capas (" + items.length + ")")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        layerOptions(which);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void layerOptions(final int index) {
        final Project p = canvas.getProject();
        final Layer l = p.layers.get(index);
        final String[] opts = {
                l.visible ? "Ocultar" : "Mostrar",
                "Subir (va mas adelante)",
                "Bajar (va mas atras)",
                "Cargar a la seleccion",
                "Renombrar",
                "Exportar solo esta capa",
                "Eliminar"
        };
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(opts, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                l.visible = !l.visible;
                                updateUi();
                                break;
                            case 1:
                                move(index, -1);
                                break;
                            case 2:
                                move(index, 1);
                                break;
                            case 3:
                                canvas.loadSelection(l.mask);
                                toast("Capa cargada en la seleccion");
                                break;
                            case 4:
                                renameDialog(l);
                                break;
                            case 5:
                                pendingPngMask = l.mask;
                                createPng.launch(l.name + ".png");
                                break;
                            default:
                                p.layers.remove(index);
                                toast("Capa eliminada");
                                updateUi();
                                break;
                        }
                    }
                })
                .show();
    }

    /** Cambia el orden de la capa. El orden manda en el numero del PNG exportado. */
    private void move(int index, int delta) {
        Project p = canvas.getProject();
        int target = index + delta;
        if (target < 0 || target >= p.layers.size()) {
            toast("Ya esta en el extremo");
            return;
        }
        Layer a = p.layers.get(index);
        p.layers.set(index, p.layers.get(target));
        p.layers.set(target, a);
        buildLayersPanel();
    }

    private void renameDialog(final Layer l) {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        in.setText(l.name);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la capa")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        if (!s.isEmpty()) l.name = s;
                        updateUi();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------------
    // Color
    // ------------------------------------------------------------------

    private void colorDialog() {
        final int[] chosen = {canvas.getColor()};

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final View preview = new View(this);
        LinearLayout.LayoutParams pvp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        pvp.bottomMargin = dp(10);
        preview.setLayoutParams(pvp);
        preview.setBackgroundColor(chosen[0]);
        root.addView(preview);

        final SeekBar sr = new SeekBar(this);
        final SeekBar sg = new SeekBar(this);
        final SeekBar sb = new SeekBar(this);
        sr.setMax(255);
        sg.setMax(255);
        sb.setMax(255);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        root.addView(grid);

        LinearLayout row = null;
        for (int i = 0; i < PALETTE.length; i++) {
            if (i % 6 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row);
            }
            final int c = PALETTE[i];
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            sw.setLayoutParams(lp);
            sw.setBackgroundColor(c);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chosen[0] = c;
                    preview.setBackgroundColor(c);
                    sr.setProgress(Color.red(c));
                    sg.setProgress(Color.green(c));
                    sb.setProgress(Color.blue(c));
                }
            });
            row.addView(sw);
        }

        SeekBar.OnSeekBarChangeListener rgb = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                if (!fromUser) return;
                chosen[0] = Color.rgb(sr.getProgress(), sg.getProgress(), sb.getProgress());
                preview.setBackgroundColor(chosen[0]);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        };

        addLabeled(root, "Rojo", sr, Color.red(chosen[0]), rgb);
        addLabeled(root, "Verde", sg, Color.green(chosen[0]), rgb);
        addLabeled(root, "Azul", sb, Color.blue(chosen[0]), rgb);

        new AlertDialog.Builder(this)
                .setTitle("Color para pintar")
                .setView(scroll)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setColor(chosen[0]);
                        updateUi();
                    }
                })
                .setNeutralButton("Tomar de la imagen", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setMode(CanvasView.MODE_PICKER);
                        toast("Toca la imagen para tomar ese color");
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void addLabeled(LinearLayout root, String name, SeekBar bar, int value,
                            SeekBar.OnSeekBarChangeListener l) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(l);
        root.addView(bar);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------
    // Dialogos
    // ------------------------------------------------------------------

    private void hardnessDialog() {
        final String[] items = {"Muy suave 20%", "Suave 40%", "Media 70%", "Dura 100%"};
        final float[] vals = {0.2f, 0.4f, 0.7f, 1f};
        new AlertDialog.Builder(this)
                .setTitle("Dureza del pincel")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setHardness(vals[i]);
                        toast("Dureza " + items[i]);
                    }
                })
                .show();
    }

    private void rotateDialog() {
        if (!needProject()) return;
        final String[] items = {"Girar a la derecha", "Girar a la izquierda",
                "Voltear horizontal", "Voltear vertical"};
        new AlertDialog.Builder(this)
                .setTitle("Girar imagen")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.transform(i);
                    }
                })
                .show();
    }

    private void edgeDialog() {
        if (!needProject()) return;
        final String[] ops = {"Expandir borde", "Contraer borde", "Suavizar borde",
                "Endurecer borde", "Cerrar huecos de la trama"};
        new AlertDialog.Builder(this)
                .setTitle("Borde de la seleccion")
                .setItems(ops, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int kind) {
                        if (kind == 3) {
                            canvas.edgeOp(3, 0);
                            return;
                        }
                        if (kind == 4) {
                            closeHolesDialog();
                            return;
                        }
                        final String[] radios = {"1 px", "2 px", "3 px", "5 px", "8 px", "12 px"};
                        final int[] vals = {1, 2, 3, 5, 8, 12};
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cuanto")
                                .setItems(radios, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int i) {
                                        canvas.edgeOp(kind, vals[i]);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    private void lineArtDialog() {
        if (!needProject()) return;
        if (canvas.isUseBarrier() && canvas.getProject().barrier != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Line art")
                    .setMessage("La barrera esta activa. La varita y el balde se detienen en las lineas.")
                    .setPositiveButton("Desactivar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.setUseBarrier(false);
                            updateUi();
                        }
                    })
                    .setNegativeButton("Recalcular", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            thresholdDialog();
                        }
                    })
                    .show();
            return;
        }
        thresholdDialog();
    }

    private void thresholdDialog() {
        final String[] items = {"Lineas muy oscuras (60)", "Oscuras (90)", "Normal (120)", "Tenues (160)"};
        final int[] vals = {60, 90, 120, 160};
        new AlertDialog.Builder(this)
                .setTitle("Que tan oscura es la linea")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int i) {
                        final String[] gaps = {"Sin cerrar huecos", "Cerrar 1 px", "Cerrar 2 px", "Cerrar 3 px"};
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cerrar huecos de la linea")
                                .setItems(gaps, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int g) {
                                        canvas.buildBarrier(vals[i], g);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    // ------------------------------------------------------------------
    // Exportar
    // ------------------------------------------------------------------

    private void exportDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        if (p.layers.isEmpty()) {
            toast("Crea al menos una capa antes de exportar");
            return;
        }
        final int[][] sizes = {
                {p.w, p.h},
                {Math.max(1, p.w / 2), Math.max(1, p.h / 2)},
                longSide(p, 1920),
                longSide(p, 1280)
        };
        final String[] items = new String[sizes.length];
        items[0] = "Original  " + sizes[0][0] + "x" + sizes[0][1];
        items[1] = "Mitad  " + sizes[1][0] + "x" + sizes[1][1];
        items[2] = "Lado largo 1920  " + sizes[2][0] + "x" + sizes[2][1];
        items[3] = "Lado largo 1280  " + sizes[3][0] + "x" + sizes[3][1];

        new AlertDialog.Builder(this)
                .setTitle("Tamano de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        outW = sizes[i][0];
                        outH = sizes[i][1];
                        edgeDialogExport();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /**
     * Limpieza del borde al exportar. Es lo que evita el halo blanco cuando
     * pones la capa sobre otro fondo en Alight Motion.
     */
    private void edgeDialogExport() {
        final String[] items = {
                "Limpiar borde y quitar el fondo pegado (recomendado)",
                "Solo limpiar borde",
                "No tocar el borde"
        };
        final int[] vals = {2, 1, 0};
        new AlertDialog.Builder(this)
                .setTitle("Borde de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        edgeClean = vals[i];
                        createZip.launch("capas_anime.zip");
                    }
                })
                .show();
    }

    /** Mantiene la proporcion para que todas las capas sigan cuadrando entre si. */
    private int[] longSide(Project p, int target) {
        int max = Math.max(p.w, p.h);
        if (max <= target) return new int[]{p.w, p.h};
        float f = target / (float) max;
        return new int[]{Math.max(1, Math.round(p.w * f)), Math.max(1, Math.round(p.h * f))};
    }

    private void doExportZip(final Uri uri) {
        final Project p = canvas.getProject();
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    lastExportCount = Exporter.exportZip(getContentResolver(), p, uri, true, outW, outH, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al exportar: " + lastError);
                else toast(lastExportCount + " PNG de " + outW + "x" + outH + " guardados en el ZIP");
            }
        });
    }

    private void doExportPng(final Uri uri) {
        final Project p = canvas.getProject();
        final byte[] mask = pendingPngMask;
        pendingPngMask = null;
        if (mask == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    Exporter.exportPng(getContentResolver(), p, mask, uri, p.w, p.h, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error: " + lastError);
                else toast("PNG guardado a " + p.w + " x " + p.h);
            }
        });
    }

    // ------------------------------------------------------------------
    // Guardar y abrir el proyecto
    // ------------------------------------------------------------------

    private void projectDialog() {
        final boolean has = canvas.getProject() != null;
        final String[] items = {
                "Guardar proyecto en un archivo",
                "Abrir un proyecto guardado",
                "Guardar ahora en la app"
        };
        new AlertDialog.Builder(this)
                .setTitle("Proyecto")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 1) {
                            openProject.launch(new String[]{"*/*"});
                            return;
                        }
                        if (!has) {
                            toast("Abre una imagen primero");
                            return;
                        }
                        if (i == 0) createProject.launch("proyecto.acut");
                        else autosave(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void saveProjectTo(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int color = canvas.getColor();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    ProjectIO.save(os, p, color);
                    if (os != null) os.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al guardar: " + lastError);
                else toast("Proyecto guardado con sus " + p.layers.size() + " capas");
            }
        });
    }

    private void openProjectFrom(final Uri uri) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    loaded = ProjectIO.load(is);
                    if (is != null) is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void recoverFrom(final File f) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileInputStream is = new FileInputStream(f);
                    loaded = ProjectIO.load(is);
                    is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void applyLoaded() {
        if (lastError != null) {
            toast("No se pudo abrir: " + lastError);
            return;
        }
        if (loaded == null || loaded.project == null) return;
        canvas.setProject(loaded.project);
        canvas.setColor(loaded.color);
        toast("Proyecto abierto: " + loaded.project.layers.size() + " capas");
        loaded = null;
        updateUi();
    }

    /**
     * Guardado automatico dentro de la app. Se dispara al crear una capa y
     * al salir, para que una llamada o que Android cierre la app no borre
     * media hora de trabajo.
     */
    /**
     * Guardado automatico en la carpeta de obras. Se dispara al crear una
     * capa y al salir. Guarda tambien la miniatura para la galeria.
     */
    private void autosave(final boolean notify) {
        final Project p = canvas.getProject();
        if (p == null || saving) return;
        saving = true;
        if (projectId == null) projectId = ProjectStore.newId();
        final String id = projectId;
        final int color = canvas.getColor();
        final File dest = ProjectStore.fileFor(this, id);
        final File tmp = new File(dest.getAbsolutePath() + ".tmp");
        if (notify) toast("Guardando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileOutputStream fo = new FileOutputStream(tmp);
                    ProjectIO.save(fo, p, color);
                    fo.close();
                    if (dest.exists() && !dest.delete()) throw new java.io.IOException("No se pudo reemplazar");
                    if (!tmp.renameTo(dest)) throw new java.io.IOException("No se pudo renombrar");
                    ProjectStore.saveThumb(MainActivity.this, id, p.base);
                    lastError = null;
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                saving = false;
                if (notify) {
                    if (lastError != null) toast("Error al guardar: " + lastError);
                    else toast("Guardado en la galeria");
                }
            }
        });
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    private boolean sliderIsTolerance() {
        int m = canvas.getMode();
        return m == CanvasView.MODE_WAND || m == CanvasView.MODE_BUCKET;
    }

    private void applySlider(int v) {
        if (sliderIsTolerance()) {
            canvas.setTolerance(v);
            sliderLabel.setText(String.valueOf(v));
        } else {
            float t = v / 120f;
            float size = 1f + t * t * 299f;
            canvas.setBrushSize(size);
            sliderLabel.setText(String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
            ((TextView) findViewById(R.id.btnSize)).setText(
                    String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void syncSlider() {
        if (sliderIsTolerance()) {
            slider.setProgress(canvas.getTolerance());
            sliderLabel.setText(String.valueOf(canvas.getTolerance()));
        } else {
            float t = (float) Math.sqrt(Math.max(0f, (canvas.getBrushSize() - 1f) / 299f));
            slider.setProgress(Math.round(t * 120f));
            float size = canvas.getBrushSize();
            sliderLabel.setText(String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void updateUi() {
        Project p = canvas.getProject();
        ((TextView) findViewById(R.id.layerCount)).setText(
                String.valueOf(p == null ? 0 : p.layers.size()));
        ((TextView) findViewById(R.id.btnSize)).setText(
                String.format(Locale.US, canvas.getBrushSize() < 10 ? "%.1f" : "%.0f", canvas.getBrushSize()));
        android.graphics.drawable.GradientDrawable sw = new android.graphics.drawable.GradientDrawable();
        sw.setCornerRadius(dp(4));
        sw.setColor(canvas.getColor());
        sw.setStroke(dp(2), 0xFFFFFFFF);
        findViewById(R.id.btnColor).setBackground(sw);

        int m = canvas.getMode();
        boolean selTool = m == CanvasView.MODE_WAND || m == CanvasView.MODE_LASSO
                || m == CanvasView.MODE_SCISSORS || m == CanvasView.MODE_BRUSH;
        findViewById(R.id.selBar).setVisibility(selTool ? View.VISIBLE : View.INVISIBLE);
        findViewById(R.id.btnAddMode).setBackgroundResource(
                canvas.isSubtract() ? R.drawable.bg_seg : R.drawable.bg_seg_on);
        findViewById(R.id.btnSubMode).setBackgroundResource(
                canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_seg);
        toggle(R.id.btnAim, canvas.isAim());
        buildOptBar(m);
        if (m == CanvasView.MODE_BGERASE || m == CanvasView.MODE_MARKER
                || m == CanvasView.MODE_PATCH || m == CanvasView.MODE_LINE
                || m == CanvasView.MODE_CLONE || m == CanvasView.MODE_HEAL) {
            findViewById(R.id.selBar).setVisibility(View.GONE);
        }
        toggle(R.id.btnSmart, canvas.isSmart());
        toggle(R.id.btnLineart, canvas.isUseBarrier() && p != null && p.barrier != null);
        highlightTools();
        if (findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE) buildLayersPanel();
    }

    /** Marca en azul lo que esta activado, para que se vea sin leer nada. */
    private void toggle(int id, boolean on) {
        findViewById(id).setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
    }

    private void highlightTools() {
        ((ImageButton) findViewById(R.id.btnTools)).setImageResource(toolIcon(canvas.getMode()));
    }

    private int luminance(int c) {
        return (Color.red(c) * 77 + Color.green(c) * 151 + Color.blue(c) * 28) >> 8;
    }

    /** Una linea que dice que hace la herramienta activa. */
    private String modeHint() {
        switch (canvas.getMode()) {
            case CanvasView.MODE_WAND:
                return canvas.isSubtract() ? "toca y QUITA ese color" : "toca y agarra ese color";
            case CanvasView.MODE_BRUSH:
                return canvas.isSubtract() ? "quita seleccion a mano" : "agrega seleccion a mano";
            case CanvasView.MODE_ERASER:
                return "borra la seleccion azul";
            case CanvasView.MODE_LASSO:
                return "rodea con el dedo";
            case CanvasView.MODE_SCISSORS:
                return "arrastra por el contorno";
            case CanvasView.MODE_MOVE:
                return "arrastra la seleccion";
            case CanvasView.MODE_CLONE:
                return "copia de un lado a otro";
            case CanvasView.MODE_PAINT:
                return "pinta con el COLOR de abajo";
            case CanvasView.MODE_BUCKET:
                return "rellena de color";
            case CanvasView.MODE_PICKER:
                return "toma un color de la imagen";
            default:
                return "mueve la imagen";
        }
    }

    private String modeName() {
        switch (canvas.getMode()) {
            case CanvasView.MODE_WAND:
                return "Varita";
            case CanvasView.MODE_BRUSH:
                return "Pincel";
            case CanvasView.MODE_ERASER:
                return "Borrador";
            case CanvasView.MODE_LASSO:
                return "Lazo";
            case CanvasView.MODE_CLONE:
                return "Clonar";
            case CanvasView.MODE_PAINT:
                return "Pintar";
            case CanvasView.MODE_BUCKET:
                return "Balde";
            case CanvasView.MODE_PICKER:
                return "Cuentagotas";
            case CanvasView.MODE_SCISSORS:
                return "Tijeras";
            case CanvasView.MODE_MOVE:
                return "Mover";
            default:
                return "Mano";
        }
    }

    private boolean needProject() {
        if (canvas.getProject() == null) {
            toast("Abre una imagen primero");
            return false;
        }
        return true;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------
    // CanvasView.Callback
    // ------------------------------------------------------------------

    @Override
    public void onBusy(boolean busy) {
        findViewById(R.id.btnExport).setEnabled(!busy);
        findViewById(R.id.btnSavePart).setEnabled(!busy);
    }

    @Override
    public void onChanged() {
        updateUi();
    }

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    @Override
    public void onColorPicked(int color) {
        updateUi();
        canvas.showHud(String.format(Locale.US, "#%06X", color & 0xFFFFFF));
    }

    @Override
    public void onUndoGesture() {
        canvas.doUndo();
        updateUi();
    }

    @Override
    public void onRedoGesture() {
        canvas.doRedo();
        updateUi();
    }

    /** Para no repetir los tres metodos del SeekBar en cada dialogo. */
    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }
}
