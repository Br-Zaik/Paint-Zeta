package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.pacco.animecut.core.CloneStamp;
import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.FloodFill;
import com.pacco.animecut.core.Filters;
import com.pacco.animecut.core.GuidedFilter;
import com.pacco.animecut.core.HoleFill;
import com.pacco.animecut.core.LineRepair;
import com.pacco.animecut.core.Membrane;
import com.pacco.animecut.core.PatchFill;
import com.pacco.animecut.core.ToneFill;
import com.pacco.animecut.core.ZoneFill;
import com.pacco.animecut.core.Watershed;
import com.pacco.animecut.core.LineArt;
import com.pacco.animecut.core.LiveWire;
import com.pacco.animecut.core.MaskOps;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.UndoManager;

import java.util.Arrays;

/**
 * El lienzo. Dibuja una copia reducida de la imagen para ir fluido, pero
 * todas las operaciones caen sobre los pixeles a resolucion real.
 */
public class CanvasView extends View {

    public static final int MODE_PAN = 0;
    public static final int MODE_WAND = 1;
    public static final int MODE_BRUSH = 2;
    public static final int MODE_ERASER = 3;
    public static final int MODE_LASSO = 4;
    public static final int MODE_CLONE = 5;
    public static final int MODE_PAINT = 6;
    public static final int MODE_BUCKET = 7;
    public static final int MODE_PICKER = 8;
    public static final int MODE_SCISSORS = 9;
    public static final int MODE_MOVE = 10;
    public static final int MODE_BGERASE = 11;
    public static final int MODE_MARKER = 12;
    public static final int MODE_MAGNET = 13;
    public static final int MODE_LINE = 14;
    public static final int MODE_ZONE = 15;
    public static final int MODE_PATCH = 16;
    public static final int MODE_HEAL = 17;
    public static final int MODE_TONE = 18;

    /** Etiquetas para separar partes con rayones. La ultima es el fondo. */
    public static final String[] LABEL_NAMES = {
            "pelo", "cara", "ojo_izq", "ojo_der", "boca", "cejas", "mano_izq", "mano_der",
            "cuerpo", "ropa", "extra", "fondo"
    };
    public static final int[] LABEL_COLORS = {
            0xFFFF5A5F, 0xFFFFC94A, 0xFF1ED6A0, 0xFF1A9BFF, 0xFFFF4FA3, 0xFFB9794A,
            0xFF8B5CF6, 0xFF3B82F6, 0xFFFB7A1B, 0xFF84CC16, 0xFFF9A8D4, 0xFF8A8A8A
    };
    public static final int BG_LABEL = 12;

    public interface Callback {
        void onBusy(boolean busy);

        void onChanged();

        void onMessage(String msg);

        void onColorPicked(int color);

        void onUndoGesture();

        void onRedoGesture();
    }

    private Project project;
    private UndoManager undo;
    private Callback callback;

    private Bitmap display;
    private float dispScale = 1f;
    private Bitmap overlay;
    private int ovScale = 1;

    private final Matrix view = new Matrix();
    private final Matrix inverse = new Matrix();
    private final float[] point = new float[2];
    private ScaleGestureDetector scaleDetector;

    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ovPaint = new Paint();
    private final Paint lassoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinEdge = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int mode = MODE_WAND;
    private float brushRadius = 40f;
    private float hardness = 0.7f;
    private int paintColor = Color.parseColor("#FFE05A5A");

    // Ajustes de la varita y del balde
    private int tolerance = 28;
    private int softness = 24;
    private int colorMode = ColorDist.RGB;
    private float expansion = 1.5f;
    private boolean gapOn = false;
    private int gapRadius = 4;
    private boolean wandGlobal = false;
    private boolean useBarrier = false;

    private boolean subtract = false;
    private boolean smart = false;
    private boolean busy = false;
    private int insetTop = 0;
    private int insetBottom = 0;

    private byte[] scratch;
    private byte[] selBackup;
    private int[] pxBackup;
    private byte[] gapBarrier;

    // portapapeles de seleccion
    private int[] clipPixels;
    private byte[] clipMask;
    private Rect clipRect;

    private boolean drawing = false;
    private boolean panning = false;
    private boolean midValid = false;
    private float lastX, lastY, lastMidX, lastMidY, lastAngle;
    private float ringX, ringY;
    private boolean showRing = false;
    private Rect strokeRect;

    private final Path lasso = new Path();
    private final Path lassoScreen = new Path();

    private boolean cloneSrcSet = false;
    private float cloneSrcX, cloneSrcY;
    private int cloneOffX, cloneOffY;

    private int refColor;
    private boolean selectionActive;
    private int painted;
    private Rect lastFillRect;

    // el toque de varita, balde y gotero se resuelve al levantar el dedo,
    // para que el gesto de dos dedos no dispare una seleccion sin querer
    private boolean pendingTap = false;
    private float tapX, tapY;

    // gestos de dos y tres dedos
    private long gestureStart;
    private int gestureMaxPointers;
    private float gestureMoved;

    // cuentagotas rapido
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean quickPick = false;
    private boolean quickArmed = false;
    private float pickX, pickY;
    private int pickColor;
    private Runnable quickRunnable;

    // tijeras inteligentes
    private LiveWire wire;
    private final Path wirePath = new Path();
    private final Path wireScreen = new Path();
    private int[] livePath;
    private int firstAnchor = -1;
    private boolean wireStarted = false;
    private final Paint wirePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // mover la seleccion
    private byte[] moveBackup;
    private float moveFromX, moveFromY;
    private int moveDx, moveDy;

    private float stabilizer = 0f;
    private float brushOpacity = 1f;
    private byte[] maskBackup;
    private float smoothX, smoothY;
    private boolean smoothInit = false;

    // vista previa de gama de colores
    private byte[] previewBackup;

    // cursor desplazado y lupa
    private boolean aimOn = false;
    private float aimDx = 0f, aimDy = -110f;
    private boolean aiming = false;
    private float aimX, aimY;
    private final Paint loupeEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint aimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // borrador de fondo por color
    private boolean bgOnce = true;
    private int bgLimit = 0; // 0 contiguo, 1 disperso, 2 bordes
    private boolean protectOn = false;
    private int protectColor = 0;
    private int bgRef;
    private byte[] gradient;

    // reconstruccion detras de una parte
    private byte[] repairLines;
    private byte[] patchSource;
    private Bitmap patchOverlay;
    private final java.util.ArrayList<float[]> linePts = new java.util.ArrayList<float[]>();
    private final Paint linePreview = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghostPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    // clonar con espejo y giro
    private boolean cloneMirror = false;
    private float cloneAngle = 0f;
    private float cloneDestX, cloneDestY;

    // rayones para separar partes
    private byte[] markers;
    private Bitmap markersOverlay;
    private int markerLabel = 1;
    private int gapClose = 2;

    // partes ya guardadas: se ven en verde para saber que falta
    private byte[] parts;
    private Bitmap partsOverlay;
    private boolean showParts = true;
    private boolean avoidParts = false;

    // aviso flotante
    private String hud;
    private long hudUntil;

    public CanvasView(Context c) {
        super(c);
        init(c);
    }

    public CanvasView(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        ovPaint.setFilterBitmap(false);
        lassoPaint.setStyle(Paint.Style.STROKE);
        lassoPaint.setColor(Color.parseColor("#FF3D7BFF"));
        lassoPaint.setStrokeWidth(3f);
        markPaint.setStyle(Paint.Style.STROKE);
        markPaint.setColor(Color.parseColor("#FFFF5252"));
        markPaint.setStrokeWidth(3f);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(Color.parseColor("#CCFFFFFF"));
        ringPaint.setStrokeWidth(2f);
        float den = getResources().getDisplayMetrics().density;
        aimDy = -46f * den;
        loupeEdge.setStyle(Paint.Style.STROKE);
        loupeEdge.setColor(Color.WHITE);
        loupeEdge.setStrokeWidth(3f * den);
        aimPaint.setStyle(Paint.Style.STROKE);
        aimPaint.setColor(Color.parseColor("#FFFF3B30"));
        aimPaint.setStrokeWidth(2f * den);
        linePreview.setStyle(Paint.Style.STROKE);
        linePreview.setColor(Color.parseColor("#FFFF9F0A"));
        linePreview.setStrokeWidth(3f * den);
        linePreview.setStrokeCap(Paint.Cap.ROUND);
        ghostPaint.setAlpha(150);
        wirePaint.setStyle(Paint.Style.STROKE);
        wirePaint.setColor(Color.parseColor("#FF32D74B"));
        wirePaint.setStrokeWidth(3f);
        hudBg.setColor(Color.parseColor("#CC000000"));
        hudText.setColor(Color.WHITE);
        hudText.setTextSize(getResources().getDisplayMetrics().density * 14f);
        hudText.setTextAlign(Paint.Align.CENTER);
        pinEdge.setColor(Color.parseColor("#FFF0F0F0"));
        pinFill.setStyle(Paint.Style.FILL);

        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float f = d.getScaleFactor();
                float cur = currentScale();
                if (cur * f < 0.03f || cur * f > 60f) return true;
                view.postScale(f, f, d.getFocusX(), d.getFocusY());
                showHud(Math.round(currentScale() * dispScale * 100f) + "%");
                return true;
            }
        });
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    public void setProject(Project p) {
        this.project = p;
        this.undo = p == null ? null : new UndoManager(p);
        this.scratch = null;
        this.selBackup = null;
        this.pxBackup = null;
        this.gapBarrier = null;
        this.markers = null;
        this.repairLines = null;
        this.patchSource = null;
        if (this.patchOverlay != null) this.patchOverlay.recycle();
        this.patchOverlay = null;
        if (this.markersOverlay != null) this.markersOverlay.recycle();
        this.markersOverlay = null;
        this.gradient = null;
        this.cloneSrcSet = false;
        lasso.reset();
        if (p != null) {
            buildDisplay();
            buildOverlay();
            parts = null;
            refreshParts();
            post(new Runnable() {
                @Override
                public void run() {
                    fit();
                }
            });
        }
        invalidate();
    }

    public Project getProject() {
        return project;
    }

    public void setMode(int m) {
        if (mode == MODE_SCISSORS && m != MODE_SCISSORS) scissorsReset();
        mode = m;
        invalidate();
    }

    public boolean isScissorsActive() {
        return wireStarted;
    }

    public int getMode() {
        return mode;
    }

    // ---- ajustes de la varita ----

    public void setTolerance(int t) {
        tolerance = t;
    }

    public int getTolerance() {
        return tolerance;
    }

    public void setSoftness(int s) {
        softness = Math.max(0, s);
    }

    public int getSoftness() {
        return softness;
    }

    public void setColorMode(int m) {
        colorMode = m;
    }

    public int getColorMode() {
        return colorMode;
    }

    public void setExpansion(float px) {
        expansion = px;
    }

    public float getExpansion() {
        return expansion;
    }

    public void setGap(boolean on, int radius) {
        gapOn = on;
        gapRadius = Math.max(1, radius);
        gapBarrier = null;
    }

    public boolean isGapOn() {
        return gapOn;
    }

    public int getGapRadius() {
        return gapRadius;
    }

    public void setBrushSize(float px) {
        brushRadius = Math.max(0.5f, px / 2f);
    }

    public float getBrushSize() {
        return brushRadius * 2f;
    }

    public void setHardness(float h) {
        hardness = Math.max(0.05f, Math.min(1f, h));
    }

    public void setColor(int c) {
        paintColor = c;
    }

    public int getColor() {
        return paintColor;
    }

    public void setWandGlobal(boolean g) {
        wandGlobal = g;
    }

    public boolean isWandGlobal() {
        return wandGlobal;
    }

    public void setUseBarrier(boolean b) {
        useBarrier = b;
    }

    public boolean isUseBarrier() {
        return useBarrier;
    }

    public void setSubtract(boolean s) {
        subtract = s;
    }

    public boolean isSubtract() {
        return subtract;
    }

    public void setSmart(boolean s) {
        smart = s;
    }

    public boolean isSmart() {
        return smart;
    }

    public boolean hasClipboard() {
        return clipPixels != null;
    }

    public void resetCloneSource() {
        cloneSrcSet = false;
        invalidate();
        msg("Toca el punto de donde quieres copiar");
    }

    // ------------------------------------------------------------------
    // Render
    // ------------------------------------------------------------------

    /**
     * La pantalla muestra lo mismo que Ibis: cuadros grises de fondo, la
     * imagen original si esta visible, y encima cada capa recortada.
     */
    private void buildDisplay() {
        Bitmap old = display;
        int max = Math.max(project.w, project.h);
        float sc = max > 2048 ? max / 2048f : 1f;
        int dw = Math.max(1, Math.round(project.w / sc));
        int dh = Math.max(1, Math.round(project.h / sc));
        display = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        dispScale = (float) project.w / dw;
        composeRegion(0, 0, dw, dh);
        if (old != null && old != project.base && !old.isRecycled()) old.recycle();
    }

    private void composeRegion(int x0, int y0, int x1, int y1) {
        if (display == null || project == null) return;
        int dw = display.getWidth(), dh = display.getHeight();
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > dw) x1 = dw;
        if (y1 > dh) y1 = dh;
        if (x0 >= x1 || y0 >= y1) return;

        int n = project.layers.size();
        com.pacco.animecut.core.Layer[] ls = new com.pacco.animecut.core.Layer[n];
        int vis = 0;
        for (int k = 0; k < n; k++) {
            com.pacco.animecut.core.Layer l = project.layers.get(k);
            if (!l.visible) continue;
            ls[vis++] = l;
        }
        boolean avg = dispScale >= 1.9f;
        int w = project.w, h = project.h;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(h - 1, (int) (y * dispScale));
            for (int x = x0; x < x1; x++) {
                int sx = Math.min(w - 1, (int) (x * dispScale));
                int i = sy * w + sx;
                int src = avg ? average(sx, sy) : project.pixels[i];
                int c = (((x >> 3) + (y >> 3)) & 1) == 0 ? 0xFF3A3A3F : 0xFF2A2A2E;
                if (project.baseVisible) {
                    c = src | 0xFF000000;
                    // una parte con hueco tapado debajo se sigue viendo encima
                    for (int k = 0; k < vis; k++) {
                        com.pacco.animecut.core.Layer l = ls[k];
                        if (l.own == null) continue;
                        int al = ((l.mask[i] & 0xFF) * l.opacity) / 255;
                        if (al > 0) c = blendA(c, l.colorAt(project.pixels, i, sx, sy), al);
                    }
                } else {
                    for (int k = 0; k < vis; k++) {
                        com.pacco.animecut.core.Layer l = ls[k];
                        int al = ((l.mask[i] & 0xFF) * l.opacity) / 255;
                        if (al <= 0) continue;
                        int lc = l.own == null ? src : l.colorAt(project.pixels, i, sx, sy);
                        c = blendA(c, lc, al);
                    }
                }
                row[x - x0] = c;
            }
            display.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    private int average(int sx, int sy) {
        int w = project.w, h = project.h;
        int x2 = Math.min(w - 1, sx + 1), y2 = Math.min(h - 1, sy + 1);
        int a = project.pixels[sy * w + sx], b = project.pixels[sy * w + x2];
        int c = project.pixels[y2 * w + sx], d = project.pixels[y2 * w + x2];
        int r = (((a >> 16) & 0xFF) + ((b >> 16) & 0xFF) + ((c >> 16) & 0xFF) + ((d >> 16) & 0xFF)) >> 2;
        int g = (((a >> 8) & 0xFF) + ((b >> 8) & 0xFF) + ((c >> 8) & 0xFF) + ((d >> 8) & 0xFF)) >> 2;
        int bl = ((a & 0xFF) + (b & 0xFF) + (c & 0xFF) + (d & 0xFF)) >> 2;
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int blendA(int dst, int src, int a) {
        int r = (((src >> 16) & 0xFF) * a + ((dst >> 16) & 0xFF) * (255 - a)) / 255;
        int g = (((src >> 8) & 0xFF) * a + ((dst >> 8) & 0xFF) * (255 - a)) / 255;
        int b = ((src & 0xFF) * a + (dst & 0xFF) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public void refreshDisplay() {
        if (project == null) return;
        buildDisplay();
        invalidate();
    }

    private void buildOverlay() {
        if (overlay != null) overlay.recycle();
        int max = Math.max(project.w, project.h);
        ovScale = max > 1440 ? (int) Math.ceil(max / 1440f) : 1;
        int ow = Math.max(1, project.w / ovScale);
        int oh = Math.max(1, project.h / ovScale);
        overlay = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
        paintOverlay(new Rect(0, 0, project.w, project.h));
    }

    private void paintOverlay(Rect r) {
        if (overlay == null || project == null) return;
        int ow = overlay.getWidth();
        int oh = overlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale);
        int y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1);
        int y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            int base = sy * project.w;
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int a = project.selection[base + sx] & 0xFF;
                row[i] = a == 0 ? 0 : (((a * 150) / 255) << 24) | 0x0080FF;
            }
            overlay.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    public void refreshOverlay(Rect r) {
        if (project == null) return;
        if (r == null) r = new Rect(0, 0, project.w, project.h);
        paintOverlay(r);
        invalidate();
    }

    public void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
    }

    public void fit() {
        if (project == null || getWidth() == 0) return;
        int usable = getHeight() - insetTop - insetBottom;
        if (usable < 80) usable = getHeight();
        float sx = (float) getWidth() / project.w;
        float sy = (float) usable / project.h;
        float s = Math.min(sx, sy) * 0.96f;
        view.reset();
        view.postScale(s, s);
        view.postTranslate((getWidth() - project.w * s) / 2f,
                insetTop + (usable - project.h * s) / 2f);
        invalidate();
    }

    private float currentScale() {
        float[] v = new float[9];
        view.getValues(v);
        float a = v[Matrix.MSCALE_X];
        float b = v[Matrix.MSKEW_X];
        return (float) Math.sqrt(a * a + b * b);
    }

    public void showHud(String text) {
        hud = text;
        hudUntil = System.currentTimeMillis() + 900;
        invalidate();
        postInvalidateDelayed(950);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(Color.parseColor("#FF121212"));
        if (project == null || display == null) return;

        float shown = currentScale() * dispScale;
        bmpPaint.setFilterBitmap(shown < 1f);

        c.save();
        c.concat(view);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, bmpPaint);
        c.restore();

        if (showParts && partsOverlay != null && project.baseVisible) {
            c.save();
            c.concat(view);
            c.scale(ovScale, ovScale);
            c.drawBitmap(partsOverlay, 0, 0, ovPaint);
            c.restore();
        }

        if (overlay != null) {
            c.save();
            c.concat(view);
            c.scale(ovScale, ovScale);
            c.drawBitmap(overlay, 0, 0, ovPaint);
            c.restore();
        }

        if (mode == MODE_LASSO && !lasso.isEmpty()) {
            lassoScreen.reset();
            lasso.transform(view, lassoScreen);
            c.drawPath(lassoScreen, lassoPaint);
        }

        if (markersOverlay != null && mode == MODE_MARKER) {
            c.save();
            c.concat(view);
            c.scale(ovScale, ovScale);
            c.drawBitmap(markersOverlay, 0, 0, ovPaint);
            c.restore();
        }

        if (mode == MODE_SCISSORS || mode == MODE_MAGNET) {
            wireScreen.reset();
            wirePath.transform(view, wireScreen);
            c.drawPath(wireScreen, wirePaint);
            if (livePath != null && livePath.length > 1) {
                Path p = new Path();
                for (int i = 0; i < livePath.length; i += 2) {
                    int idx = livePath[i];
                    int y = idx / project.w;
                    int x = idx - y * project.w;
                    if (i == 0) p.moveTo(x, y);
                    else p.lineTo(x, y);
                }
                Path sp = new Path();
                p.transform(view, sp);
                c.drawPath(sp, wirePaint);
            }
            if (firstAnchor >= 0) {
                int y = firstAnchor / project.w;
                int x = firstAnchor - y * project.w;
                point[0] = x;
                point[1] = y;
                view.mapPoints(point);
                c.drawCircle(point[0], point[1], 16f, wirePaint);
            }
        }

        if (mode == MODE_CLONE && cloneSrcSet) {
            point[0] = cloneSrcX;
            point[1] = cloneSrcY;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 22f, markPaint);
            c.drawLine(point[0] - 30, point[1], point[0] + 30, point[1], markPaint);
            c.drawLine(point[0], point[1] - 30, point[0], point[1] + 30, markPaint);
        }

        float rx = ringX + (usesAim() ? aimDx : 0f);
        float ry = ringY + (usesAim() ? aimDy : 0f);
        if (showRing && usesBrush() && !quickPick) {
            c.drawCircle(rx, ry, brushRadius * currentScale(), ringPaint);
        }
        if (usesAim() && showRing && !quickPick) {
            float d = getResources().getDisplayMetrics().density;
            c.drawLine(rx - 10 * d, ry, rx + 10 * d, ry, aimPaint);
            c.drawLine(rx, ry - 10 * d, rx, ry + 10 * d, aimPaint);
            drawLoupe(c, rx, ry);
        }

        if ((mode == MODE_CLONE || mode == MODE_HEAL) && cloneSrcSet && showRing && display != null) {
            drawCloneGhost(c, rx, ry);
        }

        if (patchOverlay != null && mode == MODE_PATCH) {
            c.save();
            c.concat(view);
            c.scale(ovScale, ovScale);
            c.drawBitmap(patchOverlay, 0, 0, ovPaint);
            c.restore();
        }

        if (mode == MODE_LINE && linePts.size() > 1) {
            Path lp = new Path();
            for (int i = 0; i < linePts.size(); i++) {
                point[0] = linePts.get(i)[0];
                point[1] = linePts.get(i)[1];
                view.mapPoints(point);
                if (i == 0) lp.moveTo(point[0], point[1]);
                else lp.lineTo(point[0], point[1]);
            }
            c.drawPath(lp, linePreview);
        }

        if (quickPick) drawPin(c);

        if (hud != null && System.currentTimeMillis() < hudUntil) {
            float pad = 14f * getResources().getDisplayMetrics().density;
            float tw = hudText.measureText(hud);
            float cx = getWidth() / 2f;
            float top = insetTop + pad;
            c.drawRoundRect(new RectF(cx - tw / 2 - pad, top, cx + tw / 2 + pad, top + pad * 2.6f),
                    12f, 12f, hudBg);
            c.drawText(hud, cx, top + pad * 1.8f, hudText);
        }
    }

    /**
     * Lupa: una ventana redonda en la esquina contraria al dedo que muestra
     * ampliado lo que hay bajo la cruz. El dedo deja de tapar el borde.
     */
    private void drawLoupe(Canvas c, float sx, float sy) {
        if (display == null) return;
        float d = getResources().getDisplayMetrics().density;
        float r = 62f * d;
        float margin = 12f * d;
        float cx = sx < getWidth() / 2f ? getWidth() - r - margin : r + margin;
        float cy = insetTop + r + margin;

        toImage(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float ix = point[0] / dispScale;
        float iy = point[1] / dispScale;
        float zoom = Math.max(2.5f, currentScale() * dispScale * 3f);

        Path clip = new Path();
        clip.addCircle(cx, cy, r, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.drawColor(Color.parseColor("#FF202024"));
        c.translate(cx, cy);
        c.scale(zoom, zoom);
        c.translate(-ix, -iy);
        c.drawBitmap(display, 0, 0, ovPaint);
        if (overlay != null) {
            c.save();
            c.scale(ovScale / dispScale, ovScale / dispScale);
            c.drawBitmap(overlay, 0, 0, ovPaint);
            c.restore();
        }
        c.restore();
        c.drawCircle(cx, cy, r, loupeEdge);
        c.drawLine(cx - 9 * d, cy, cx + 9 * d, cy, aimPaint);
        c.drawLine(cx, cy - 9 * d, cx, cy + 9 * d, aimPaint);
    }

    /** Burbuja del cuentagotas, desplazada para no tapar el punto. */
    private void drawPin(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float r = 34f * d;
        float cx = pickX;
        float cy = pickY - r * 1.8f;
        pinFill.setColor(pickColor);
        pinEdge.setStyle(Paint.Style.STROKE);
        pinEdge.setStrokeWidth(4f * d);
        c.drawCircle(cx, cy, r, pinFill);
        c.drawCircle(cx, cy, r, pinEdge);
        Path tip = new Path();
        tip.moveTo(cx - r * 0.42f, cy + r * 0.86f);
        tip.lineTo(cx, cy + r * 1.9f);
        tip.lineTo(cx + r * 0.42f, cy + r * 0.86f);
        tip.close();
        pinEdge.setStyle(Paint.Style.FILL);
        c.drawPath(tip, pinEdge);
        pinFill.setColor(pickColor);
        c.drawCircle(cx, cy, r - 3f * d, pinFill);
    }

    private boolean usesBrush() {
        return mode == MODE_BRUSH || mode == MODE_ERASER || mode == MODE_CLONE || mode == MODE_PAINT
                || mode == MODE_BGERASE || mode == MODE_MARKER || mode == MODE_PATCH
                || mode == MODE_HEAL;
    }

    // ------------------------------------------------------------------
    // Toque
    // ------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (project == null || busy) return true;
        int action = e.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            gestureStart = System.currentTimeMillis();
            gestureMaxPointers = 1;
            gestureMoved = 0f;
        }
        if (action == MotionEvent.ACTION_POINTER_DOWN) {
            gestureMaxPointers = Math.max(gestureMaxPointers, e.getPointerCount());
        }

        if (e.getPointerCount() >= 2) {
            pendingTap = false;
            cancelQuickTimer();
            if (quickPick) endQuickPick(false);
            if (drawing) cancelStroke();
            panning = false;
            showRing = false;
            scaleDetector.onTouchEvent(e);
            handleTwoFingers(e);
            if (action == MotionEvent.ACTION_POINTER_UP) checkTapGesture(e);
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                midValid = false;
                ringX = e.getX();
                ringY = e.getY();
                pickX = e.getX();
                pickY = e.getY();
                showRing = usesBrush();
                armQuickPick();
                if (isTapTool() && usesAim()) showRing = true;
                if (isTapTool()) {
                    pendingTap = true;
                    tapX = e.getX();
                    tapY = e.getY();
                    return true;
                }
                if (mode == MODE_PAN) {
                    panning = true;
                    lastX = e.getX();
                    lastY = e.getY();
                } else {
                    startStroke(e.getX(), e.getY());
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                gestureMoved += Math.abs(e.getX() - ringX) + Math.abs(e.getY() - ringY);
                ringX = e.getX();
                ringY = e.getY();
                if (quickPick) {
                    updateQuickPick(e.getX(), e.getY());
                    return true;
                }
                if (gestureMoved > 24f) {
                    cancelQuickTimer();
                    if (usesAim() && pendingTap) {
                        tapX = e.getX();
                        tapY = e.getY();
                        invalidate();
                    } else {
                        pendingTap = false;
                    }
                }
                if (panning) {
                    view.postTranslate(e.getX() - lastX, e.getY() - lastY);
                    lastX = e.getX();
                    lastY = e.getY();
                    invalidate();
                } else if (drawing) {
                    moveStroke(e.getX(), e.getY());
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cancelQuickTimer();
                if (quickPick) {
                    endQuickPick(action == MotionEvent.ACTION_UP);
                } else if (pendingTap && action == MotionEvent.ACTION_UP) {
                    pendingTap = false;
                    runTapTool(tapX, tapY);
                } else if (drawing) {
                    endStroke();
                }
                pendingTap = false;
                checkTapGesture(e);
                panning = false;
                midValid = false;
                showRing = false;
                invalidate();
                return true;
        }
        return true;
    }

    private boolean isTapTool() {
        return mode == MODE_WAND || mode == MODE_BUCKET || mode == MODE_PICKER
                || mode == MODE_ZONE || mode == MODE_TONE;
    }

    private void runTapTool(float sx, float sy) {
        toImage(sx, sy);
        int px = (int) point[0];
        int py = (int) point[1];
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;
        if (!inside) return;
        if (mode == MODE_ZONE) {
            runZoneFill(px, py);
            return;
        }
        if (mode == MODE_TONE) {
            runToneFill(px, py);
            return;
        }
        if (mode == MODE_WAND) {
            runWand(px, py);
        } else if (mode == MODE_BUCKET) {
            runBucket(px, py);
        } else {
            paintColor = project.pixels[py * project.w + px] | 0xFF000000;
            if (callback != null) callback.onColorPicked(paintColor);
        }
    }

    /** Dos dedos = deshacer, tres dedos = rehacer, como en Ibis. */
    private void checkTapGesture(MotionEvent e) {
        if (callback == null) return;
        long dur = System.currentTimeMillis() - gestureStart;
        if (dur > 260 || gestureMoved > 30f) return;
        if (gestureMaxPointers == 2) {
            gestureMaxPointers = 0;
            callback.onUndoGesture();
        } else if (gestureMaxPointers >= 3) {
            gestureMaxPointers = 0;
            callback.onRedoGesture();
        }
    }

    private void handleTwoFingers(MotionEvent e) {
        float mx = (e.getX(0) + e.getX(1)) / 2f;
        float my = (e.getY(0) + e.getY(1)) / 2f;
        float angle = (float) Math.toDegrees(Math.atan2(
                e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)));
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_POINTER_DOWN || !midValid) {
            lastMidX = mx;
            lastMidY = my;
            lastAngle = angle;
            midValid = true;
        } else if (a == MotionEvent.ACTION_MOVE) {
            view.postTranslate(mx - lastMidX, my - lastMidY);
            float da = angle - lastAngle;
            while (da > 180f) da -= 360f;
            while (da < -180f) da += 360f;
            if (Math.abs(da) > 0.4f) view.postRotate(da, mx, my);
            lastMidX = mx;
            lastMidY = my;
            lastAngle = angle;
            gestureMoved += 10f;
            invalidate();
        }
        if (a == MotionEvent.ACTION_POINTER_UP) midValid = false;
    }

    // ---- cuentagotas rapido ----

    private void armQuickPick() {
        cancelQuickTimer();
        quickArmed = true;
        quickRunnable = new Runnable() {
            @Override
            public void run() {
                if (!quickArmed || project == null) return;
                if (drawing) cancelStroke();
                panning = false;
                quickPick = true;
                updateQuickPick(pickX, pickY);
            }
        };
        handler.postDelayed(quickRunnable, 550);
    }

    private void cancelQuickTimer() {
        quickArmed = false;
        if (quickRunnable != null) handler.removeCallbacks(quickRunnable);
    }

    private void updateQuickPick(float sx, float sy) {
        pickX = sx;
        pickY = sy;
        toImage(sx, sy);
        int x = (int) point[0];
        int y = (int) point[1];
        if (x >= 0 && y >= 0 && x < project.w && y < project.h) {
            pickColor = project.pixels[y * project.w + x] | 0xFF000000;
        }
        invalidate();
    }

    private void endQuickPick(boolean apply) {
        quickPick = false;
        if (apply) {
            paintColor = pickColor;
            if (callback != null) callback.onColorPicked(paintColor);
        }
        invalidate();
    }

    private boolean usesAim() {
        return aimOn && mode != MODE_PAN && mode != MODE_MOVE;
    }

    private void toImage(float x, float y) {
        if (usesAim() && !quickPick) {
            x += aimDx;
            y += aimDy;
        }
        view.invert(inverse);
        point[0] = x;
        point[1] = y;
        inverse.mapPoints(point);
    }

    // ------------------------------------------------------------------
    // Trazos
    // ------------------------------------------------------------------

    private void startStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0];
        float iy = point[1];
        int px = (int) ix;
        int py = (int) iy;
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;

        switch (mode) {
            case MODE_WAND:
                cancelQuickTimer();
                runWand(px, py);
                return;

            case MODE_PICKER:
                cancelQuickTimer();
                if (inside) {
                    paintColor = project.pixels[py * project.w + px] | 0xFF000000;
                    if (callback != null) callback.onColorPicked(paintColor);
                }
                return;

            case MODE_BUCKET:
                cancelQuickTimer();
                runBucket(px, py);
                return;

            case MODE_ERASER: {
                com.pacco.animecut.core.Layer target = ensureEditableLayer();
                if (target == null) return;
                if (maskBackup == null || maskBackup.length != target.mask.length) {
                    maskBackup = new byte[target.mask.length];
                }
                System.arraycopy(target.mask, 0, maskBackup, 0, maskBackup.length);
                selectionActive = project.hasSelection();
                strokeRect = null;
                drawing = true;
                stampEraser(ix, iy);
                lastX = ix;
                lastY = iy;
                return;
            }

            case MODE_BGERASE: {
                com.pacco.animecut.core.Layer target = ensureEditableLayer();
                if (target == null) return;
                if (maskBackup == null || maskBackup.length != target.mask.length) {
                    maskBackup = new byte[target.mask.length];
                }
                System.arraycopy(target.mask, 0, maskBackup, 0, maskBackup.length);
                selectionActive = project.hasSelection();
                if (inside) bgRef = project.pixels[py * project.w + px];
                if (bgLimit == 2) ensureGradient();
                strokeRect = null;
                drawing = true;
                stampBgErase(ix, iy);
                lastX = ix;
                lastY = iy;
                return;
            }

            case MODE_LINE:
                cancelQuickTimer();
                linePts.clear();
                linePts.add(new float[]{ix, iy});
                drawing = true;
                invalidate();
                return;

            case MODE_PATCH:
                ensurePatchSource();
                strokeRect = null;
                drawing = true;
                stampPatchSource(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_HEAL:
                if (!cloneSrcSet) {
                    cancelQuickTimer();
                    cloneSrcX = ix;
                    cloneSrcY = iy;
                    cloneSrcSet = true;
                    msg("Origen fijado. Ahora pinta donde quieres corregir");
                    invalidate();
                    return;
                }
                ensurePxBackup();
                System.arraycopy(project.pixels, 0, pxBackup, 0, pxBackup.length);
                cloneDestX = ix;
                cloneDestY = iy;
                strokeRect = null;
                drawing = true;
                stampClone(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_MARKER:
                ensureMarkers();
                strokeRect = null;
                drawing = true;
                stampMarker(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_MAGNET:
                cancelQuickTimer();
                if (!inside) return;
                if (wire == null) wire = new LiveWire(project.pixels, project.w, project.h);
                wirePath.reset();
                wirePath.moveTo(px, py);
                firstAnchor = py * project.w + px;
                wireStarted = true;
                wire.setAnchor(px, py, 120);
                livePath = null;
                drawing = true;
                lastX = ix;
                lastY = iy;
                return;

            case MODE_BRUSH:
                ensureSelBackup();
                System.arraycopy(project.selection, 0, selBackup, 0, selBackup.length);
                refColor = inside ? project.pixels[py * project.w + px] : 0;
                strokeRect = null;
                drawing = true;
                stampBrush(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_PAINT:
                ensurePxBackup();
                System.arraycopy(project.pixels, 0, pxBackup, 0, pxBackup.length);
                selectionActive = project.hasSelection();
                painted = 0;
                strokeRect = null;
                drawing = true;
                stampPaint(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_SCISSORS:
                cancelQuickTimer();
                if (!inside) return;
                drawing = true;
                if (!wireStarted) {
                    wireStarted = true;
                    firstAnchor = py * project.w + px;
                    wirePath.reset();
                    wirePath.moveTo(px, py);
                    setAnchorAsync(px, py);
                    msg("Arrastra siguiendo el contorno y suelta para fijar");
                }
                return;

            case MODE_MOVE:
                cancelQuickTimer();
                ensureSelBackup();
                System.arraycopy(project.selection, 0, selBackup, 0, selBackup.length);
                moveBackup = selBackup;
                moveFromX = ix;
                moveFromY = iy;
                moveDx = 0;
                moveDy = 0;
                drawing = true;
                return;

            case MODE_LASSO:
                lasso.reset();
                lasso.moveTo(ix, iy);
                drawing = true;
                lastX = ix;
                lastY = iy;
                invalidate();
                return;

            case MODE_CLONE:
                if (!cloneSrcSet) {
                    cancelQuickTimer();
                    cloneSrcX = ix;
                    cloneSrcY = iy;
                    cloneSrcSet = true;
                    msg("Origen fijado. Ahora arrastra donde quieres copiarlo");
                    invalidate();
                    return;
                }
                ensurePxBackup();
                System.arraycopy(project.pixels, 0, pxBackup, 0, pxBackup.length);
                cloneOffX = (int) (ix - cloneSrcX);
                cloneOffY = (int) (iy - cloneSrcY);
                cloneDestX = ix;
                cloneDestY = iy;
                strokeRect = null;
                drawing = true;
                stampClone(ix, iy);
                lastX = ix;
                lastY = iy;
                return;
        }
    }

    private void moveStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0];
        float iy = point[1];

        if (mode == MODE_LASSO) {
            lasso.lineTo(ix, iy);
            invalidate();
            return;
        }

        if (mode == MODE_SCISSORS) {
            if (wire != null && wire.hasAnchor()) {
                livePath = wire.pathTo((int) ix, (int) iy);
                invalidate();
            }
            return;
        }

        if (mode == MODE_LINE) {
            float[] last = linePts.get(linePts.size() - 1);
            if (Math.hypot(ix - last[0], iy - last[1]) > 2f) linePts.add(new float[]{ix, iy});
            invalidate();
            return;
        }

        if (mode == MODE_MAGNET) {
            if (wire == null || !wire.hasAnchor()) return;
            livePath = wire.pathTo((int) ix, (int) iy);
            float dd = (float) Math.hypot(ix - lastX, iy - lastY);
            if (dd > 36f && livePath != null && livePath.length > 1) {
                // el ancla avanza sola: el trazo se va pegando al contorno
                appendLive();
                wire.setAnchor((int) ix, (int) iy, 120);
                lastX = ix;
                lastY = iy;
            }
            invalidate();
            return;
        }

        if (mode == MODE_MOVE) {
            moveDx = (int) (ix - moveFromX);
            moveDy = (int) (iy - moveFromY);
            shiftSelection(moveDx, moveDy);
            return;
        }

        if (stabilizer > 0f) {
            if (!smoothInit) {
                smoothX = ix;
                smoothY = iy;
                smoothInit = true;
            }
            smoothX = smoothX * stabilizer + ix * (1f - stabilizer);
            smoothY = smoothY * stabilizer + iy * (1f - stabilizer);
            ix = smoothX;
            iy = smoothY;
        }

        float dx = ix - lastX;
        float dy = iy - lastY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float step = Math.max(0.6f, brushRadius * 0.3f);
        int n = (int) (dist / step);
        for (int i = 1; i <= n; i++) {
            float t = i / (float) n;
            float bx = lastX + dx * t;
            float by = lastY + dy * t;
            if (mode == MODE_CLONE || mode == MODE_HEAL) stampClone(bx, by);
            else if (mode == MODE_PATCH) stampPatchSource(bx, by);
            else if (mode == MODE_PAINT) stampPaint(bx, by);
            else if (mode == MODE_ERASER) stampEraser(bx, by);
            else if (mode == MODE_BGERASE) stampBgErase(bx, by);
            else if (mode == MODE_MARKER) stampMarker(bx, by);
            else stampBrush(bx, by);
        }
        if (n > 0) {
            lastX = ix;
            lastY = iy;
        }
        invalidate();
    }

    private void endStroke() {
        drawing = false;
        smoothInit = false;
        if (mode == MODE_LASSO) {
            applyLasso();
            return;
        }
        if (mode == MODE_SCISSORS) {
            commitWire();
            return;
        }
        if (mode == MODE_MOVE) {
            if (moveDx != 0 || moveDy != 0) {
                undo.setLabel("Mover seleccion");
                undo.recordFromBackup(UndoManager.SELECTION, project.fullRect(), moveBackup, null);
                changed();
            }
            moveBackup = null;
            return;
        }
        if (mode == MODE_MARKER || mode == MODE_PATCH) {
            strokeRect = null;
            return;
        }
        if (mode == MODE_LINE) {
            finishLine();
            return;
        }
        if (mode == MODE_HEAL) {
            if (strokeRect != null) finishHeal(strokeRect);
            strokeRect = null;
            return;
        }
        if (mode == MODE_MAGNET) {
            appendLive();
            Path closed = new Path(wirePath);
            closed.close();
            scissorsReset();
            fillPathIntoSelection(closed, "Magnetico");
            return;
        }
        if (mode == MODE_BGERASE) {
            com.pacco.animecut.core.Layer t = project.activeLayer();
            if (strokeRect != null && t != null) {
                undo.setLabel("Borrar fondo");
                undo.recordMaskFromBackup(t, strokeRect, maskBackup);
                refreshParts();
                changed();
            }
            strokeRect = null;
            return;
        }
        if (mode == MODE_ERASER) {
            com.pacco.animecut.core.Layer t = project.activeLayer();
            if (strokeRect != null && t != null) {
                undo.setLabel("Goma");
                undo.recordMaskFromBackup(t, strokeRect, maskBackup);
                refreshParts();
                changed();
            }
            strokeRect = null;
            return;
        }
        if (mode == MODE_PAINT && painted == 0 && selectionActive) {
            msg("Hay una seleccion activa: solo se pinta dentro de lo azul. Usa Limpiar para pintar libre.");
        }
        if (strokeRect != null) {
            undo.setLabel(mode == MODE_PAINT ? "Pincelada"
                    : mode == MODE_CLONE ? "Clonar"
                    : mode == MODE_ERASER ? "Borrador" : "Pincel");
            if (mode == MODE_CLONE || mode == MODE_PAINT) {
                undo.recordFromBackup(UndoManager.PIXELS, strokeRect, null, pxBackup);
            } else {
                undo.recordFromBackup(UndoManager.SELECTION, strokeRect, selBackup, null);
            }
            changed();
        }
        strokeRect = null;
    }

    /** Deshace el trazo en curso sin tocar el historial. */
    private void cancelStroke() {
        if (!drawing) return;
        drawing = false;
        if (strokeRect == null) {
            lasso.reset();
            return;
        }
        Rect r = strokeRect;
        strokeRect = null;
        if (mode == MODE_CLONE || mode == MODE_PAINT) {
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(pxBackup, y * project.w + r.left,
                        project.pixels, y * project.w + r.left, r.width());
            }
            project.pushPixels(r);
            updateDisplayRegion(r);
        } else if (mode == MODE_ERASER) {
            com.pacco.animecut.core.Layer t = project.activeLayer();
            if (t != null && maskBackup != null) {
                for (int y = r.top; y < r.bottom; y++) {
                    System.arraycopy(maskBackup, y * project.w + r.left,
                            t.mask, y * project.w + r.left, r.width());
                }
                updateDisplayRegion(r);
            }
        } else if (mode == MODE_BRUSH) {
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(selBackup, y * project.w + r.left,
                        project.selection, y * project.w + r.left, r.width());
            }
            paintOverlay(r);
        }
        lasso.reset();
        invalidate();
    }

    // ------------------------------------------------------------------
    // Borrador de fondo por color (como el Background Eraser de Photoshop)
    // ------------------------------------------------------------------

    /**
     * Borra solo el color que esta bajo la cruz. Se puede pasar un pincel
     * grueso por el borde del pelo y se va el fondo, no el pelo.
     */
    private void stampBgErase(float cx, float cy) {
        com.pacco.animecut.core.Layer t = project.activeLayer();
        if (t == null) return;
        int w = project.w, h = project.h;
        int cxi = (int) cx, cyi = (int) cy;
        if (!bgOnce && cxi >= 0 && cyi >= 0 && cxi < w && cyi < h) {
            bgRef = project.pixels[cyi * w + cxi];
        }
        int x0 = Math.max(0, (int) Math.floor(cx - brushRadius));
        int y0 = Math.max(0, (int) Math.floor(cy - brushRadius));
        int x1 = Math.min(w, (int) Math.ceil(cx + brushRadius) + 1);
        int y1 = Math.min(h, (int) Math.ceil(cy + brushRadius) + 1);
        if (x0 >= x1 || y0 >= y1) return;
        float inner = brushRadius * hardness;
        float bandR = Math.max(1f, brushRadius - inner);
        int bw = x1 - x0, bh = y1 - y0;

        if (bgLimit == 1) {
            // disperso: cualquier pixel del color dentro del circulo, incluso entre mechones
            for (int y = y0; y < y1; y++) {
                for (int x = x0; x < x1; x++) {
                    float fall = falloff(x, y, cx, cy, inner, bandR);
                    if (fall > 0f) applyBg(t, y * w + x, fall);
                }
            }
        } else {
            // contiguo o bordes: solo lo que esta pegado al centro
            if (cxi < x0 || cyi < y0 || cxi >= x1 || cyi >= y1) return;
            boolean[] seen = new boolean[bw * bh];
            int[] st = new int[Math.max(64, bw * bh)];
            int sp = 0;
            int start = (cyi - y0) * bw + (cxi - x0);
            if (colorAmount(cyi * w + cxi) <= 0f) return;
            st[sp++] = start;
            seen[start] = true;
            while (sp > 0) {
                int li = st[--sp];
                int ly = li / bw, lx = li - ly * bw;
                int x = x0 + lx, y = y0 + ly;
                int i = y * w + x;
                float fall = falloff(x, y, cx, cy, inner, bandR);
                if (fall <= 0f) continue;
                applyBg(t, i, fall);
                // en modo bordes, en una linea fuerte se borra pero no se sigue
                if (bgLimit == 2 && gradient != null && (gradient[i] & 0xFF) > 70) continue;
                int[] nx = {lx - 1, lx + 1, lx, lx};
                int[] ny = {ly, ly, ly - 1, ly + 1};
                for (int k = 0; k < 4; k++) {
                    if (nx[k] < 0 || ny[k] < 0 || nx[k] >= bw || ny[k] >= bh) continue;
                    int q = ny[k] * bw + nx[k];
                    if (seen[q]) continue;
                    seen[q] = true;
                    if (colorAmount((y0 + ny[k]) * w + (x0 + nx[k])) <= 0f) continue;
                    st[sp++] = q;
                }
            }
        }
        Rect r = new Rect(x0, y0, x1, y1);
        grow(r);
        updateDisplayRegion(r);
    }

    private float falloff(int x, int y, float cx, float cy, float inner, float bandR) {
        float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d > brushRadius) return 0f;
        return d <= inner ? 1f : 1f - (d - inner) / bandR;
    }

    /** 1 si es el color del fondo, 0 si no, y una rampa suave entre medias. */
    private float colorAmount(int i) {
        int d = ColorDist.dist(project.pixels[i], bgRef, colorMode);
        if (d <= tolerance) return 1f;
        int band = Math.max(1, softness);
        if (d >= tolerance + band) return 0f;
        return 1f - (d - tolerance) / (float) band;
    }

    private void applyBg(com.pacco.animecut.core.Layer t, int i, float fall) {
        float amt = colorAmount(i) * fall * brushOpacity;
        if (amt <= 0f) return;
        if (protectOn && ColorDist.dist(project.pixels[i], protectColor, colorMode) <= Math.max(6, tolerance / 2)) {
            return;
        }
        if (selectionActive) amt *= (project.selection[i] & 0xFF) / 255f;
        int cur = t.mask[i] & 0xFF;
        int v = (int) (cur * (1f - amt));
        if (v < cur) t.mask[i] = (byte) v;
    }

    private void ensureGradient() {
        if (gradient != null && gradient.length == project.w * project.h) return;
        int w = project.w, h = project.h;
        gradient = new byte[w * h];
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                int gx = lum(i - w + 1) + 2 * lum(i + 1) + lum(i + w + 1)
                        - lum(i - w - 1) - 2 * lum(i - 1) - lum(i + w - 1);
                int gy = lum(i + w - 1) + 2 * lum(i + w) + lum(i + w + 1)
                        - lum(i - w - 1) - 2 * lum(i - w) - lum(i - w + 1);
                int m = (Math.abs(gx) + Math.abs(gy)) >> 2;
                gradient[i] = (byte) (m > 255 ? 255 : m);
            }
        }
    }

    private int lum(int i) {
        int c = project.pixels[i];
        return (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
    }

    // ------------------------------------------------------------------
    // Separar partes con rayones (como la Colorize Mask de Krita)
    // ------------------------------------------------------------------

    private void ensureMarkers() {
        int n = project.w * project.h;
        if (markers == null || markers.length != n) markers = new byte[n];
        if (markersOverlay == null && overlay != null) {
            markersOverlay = Bitmap.createBitmap(overlay.getWidth(), overlay.getHeight(),
                    Bitmap.Config.ARGB_8888);
        }
    }

    private void stampMarker(float cx, float cy) {
        int w = project.w, h = project.h;
        int x0 = Math.max(0, (int) Math.floor(cx - brushRadius));
        int y0 = Math.max(0, (int) Math.floor(cy - brushRadius));
        int x1 = Math.min(w, (int) Math.ceil(cx + brushRadius) + 1);
        int y1 = Math.min(h, (int) Math.ceil(cy + brushRadius) + 1);
        if (x0 >= x1 || y0 >= y1) return;
        float r2 = brushRadius * brushRadius;
        byte v = (byte) (subtract ? 0 : markerLabel);
        for (int y = y0; y < y1; y++) {
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                if (dx * dx + dy * dy > r2) continue;
                markers[y * w + x] = v;
            }
        }
        paintMarkers(new Rect(x0, y0, x1, y1));
        invalidate();
    }

    private void paintMarkers(Rect r) {
        if (markersOverlay == null || markers == null) return;
        int ow = markersOverlay.getWidth(), oh = markersOverlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int lab = markers[sy * project.w + sx] & 0xFF;
                row[i] = lab == 0 ? 0 : (0xB0000000 | (LABEL_COLORS[lab - 1] & 0xFFFFFF));
            }
            markersOverlay.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    public void setMarkerLabel(int label) {
        markerLabel = Math.max(1, Math.min(LABEL_NAMES.length, label));
    }

    public int getMarkerLabel() {
        return markerLabel;
    }

    public void setGapClose(int g) {
        gapClose = Math.max(0, g);
    }

    public int getGapClose() {
        return gapClose;
    }

    public void clearMarkers() {
        if (markers != null) java.util.Arrays.fill(markers, (byte) 0);
        if (markersOverlay != null) markersOverlay.eraseColor(0);
        invalidate();
    }

    private byte[] lastLabels;

    /**
     * Inunda desde los rayones y crea una capa por cada parte marcada.
     * Si se vuelve a correr, reemplaza las capas que creo la vez anterior.
     */
    public void separateParts() {
        if (project == null || markers == null) {
            msg("Primero raya las partes con el marcador");
            return;
        }
        boolean any = false;
        for (byte b : markers) {
            int v = b & 0xFF;
            if (v != 0 && v != BG_LABEL) {
                any = true;
                break;
            }
        }
        if (!any) {
            msg("Raya al menos una parte (y el fondo, en gris)");
            return;
        }
        setBusy(true);
        final byte[] seeds = markers.clone();
        final int gap = gapClose;
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastLabels = Watershed.run(project.pixels, project.w, project.h, seeds, gap, BG_LABEL);
            }
        }, new Runnable() {
            @Override
            public void run() {
                byte[] out = lastLabels;
                if (out != null) buildPartsFromLabels(out, seeds);
                lastLabels = null;
                setBusy(false);
            }
        });
    }

    private void buildPartsFromLabels(byte[] out, byte[] seeds) {
        boolean[] used = new boolean[LABEL_NAMES.length + 1];
        for (byte b : seeds) used[b & 0xFF] = true;
        // quitar las capas que salieron de la separacion anterior
        for (int k = project.layers.size() - 1; k >= 0; k--) {
            if (project.layers.get(k).autoLabel >= 0) project.layers.remove(k);
        }
        int n = project.w * project.h;
        int made = 0;
        for (int lab = 1; lab < BG_LABEL; lab++) {
            if (!used[lab]) continue;
            byte[] m = new byte[n];
            boolean hit = false;
            for (int i = 0; i < n; i++) {
                if ((out[i] & 0xFF) == lab) {
                    m[i] = (byte) 255;
                    hit = true;
                }
            }
            if (!hit) continue;
            MaskOps.feather(m, project.w, project.h, 1);
            com.pacco.animecut.core.Layer l =
                    new com.pacco.animecut.core.Layer(LABEL_NAMES[lab - 1], m);
            l.autoLabel = lab;
            project.layers.add(l);
            made++;
        }
        project.active = project.layers.size() - 1;
        project.baseVisible = false;
        if (markersOverlay != null) markersOverlay.eraseColor(0);
        refreshDisplay();
        refreshParts();
        showHud(made + " partes separadas");
        changed();
    }

    // ------------------------------------------------------------------
    // Tapar el hueco debajo de una parte
    // ------------------------------------------------------------------

    /**
     * La capa activa guarda su propia imagen, y en la imagen de abajo el
     * sitio que ocupaba se rellena con el color de alrededor. Asi, cuando el
     * ojo se mueva en Alight Motion, debajo hay piel y no un agujero.
     */
    public void fillHoleUnderActive() {
        final com.pacco.animecut.core.Layer t = project == null ? null : project.activeLayer();
        if (t == null) {
            msg("Toca en Capas la parte que quieres sacar (por ejemplo el ojo)");
            return;
        }
        final Rect b = HoleFill.bounds(t.mask, project.w, project.h);
        if (b == null) {
            msg("Esa capa esta vacia");
            return;
        }
        if (t.own == null) {
            Rect r = new Rect(b);
            r.inset(-4, -4);
            clamp(r);
            int rw = r.width(), rh = r.height();
            t.own = new int[rw * rh];
            for (int y = 0; y < rh; y++) {
                System.arraycopy(project.pixels, (r.top + y) * project.w + r.left, t.own, y * rw, rw);
            }
            t.ownRect = r;
        }
        final Rect area = new Rect(b);
        area.inset(-27, -27);
        clamp(area);
        undo.setLabel("Tapar hueco");
        undo.record(UndoManager.PIXELS, area);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                HoleFill.fill(project.pixels, project.w, project.h, t.mask, 3);
                project.pushPixels(area);
            }
        }, new Runnable() {
            @Override
            public void run() {
                wire = null;
                gradient = null;
                refreshDisplay();
                setBusy(false);
                showHud("Hueco tapado");
                changed();
            }
        });
    }

    // ------------------------------------------------------------------
    // Reconstruir lo que quedaba detras de una parte
    // ------------------------------------------------------------------

    /**
     * Lo que hay que reconstruir: la parte activa (un poco mas grande, para
     * que al moverla en Alight Motion no aparezca un filo sin pintar), o si no
     * hay parte activa, la seleccion.
     */
    private byte[] holeMask() {
        if (project == null) return null;
        int n = project.w * project.h;
        com.pacco.animecut.core.Layer t = project.activeLayer();
        byte[] m = new byte[n];
        if (t != null) {
            for (int i = 0; i < n; i++) m[i] = (byte) ((t.mask[i] & 0xFF) > 64 ? 255 : 0);
            MaskOps.dilate(m, project.w, project.h, 3);
            return m;
        }
        if (project.hasSelection()) {
            for (int i = 0; i < n; i++) m[i] = (byte) ((project.selection[i] & 0xFF) > 64 ? 255 : 0);
            MaskOps.dilate(m, project.w, project.h, 1);
            return m;
        }
        return null;
    }

    /**
     * Al entrar a reconstruir: la parte guarda su imagen, el hueco se tapa en
     * bruto con el color de alrededor, y la parte se oculta para ver lo de atras.
     */
    public void enterRepairMode() {
        com.pacco.animecut.core.Layer t = project == null ? null : project.activeLayer();
        if (t == null) {
            if (project != null && !project.hasSelection()) {
                msg("En Capas toca la parte que sacaste (o selecciona la zona a rehacer)");
            }
            return;
        }
        if (t.own == null) fillHoleUnderActive();
        if (t.visible) {
            t.visible = false;
            project.baseVisible = true;
            refreshDisplay();
            refreshParts();
            showHud("Parte oculta para ver lo de atras");
            changed();
        } else if (!project.baseVisible) {
            project.baseVisible = true;
            refreshDisplay();
            changed();
        }
    }

    private void afterRepair(Rect r) {
        project.pushPixels(r);
        wire = null;
        gradient = null;
        updateDisplayRegion(r);
        changed();
    }

    private void finishLine() {
        if (linePts.size() < 2) {
            linePts.clear();
            invalidate();
            return;
        }
        byte[] hole = holeMask();
        float[] a = linePts.get(0), b = linePts.get(linePts.size() - 1);
        float[] a2 = linePts.get(Math.min(linePts.size() - 1, 3));
        float[] b2 = linePts.get(Math.max(0, linePts.size() - 4));
        LineRepair.End ea = LineRepair.snap(project.pixels, project.w, project.h, hole,
                a[0], a[1], a2[0] - a[0], a2[1] - a[1], 28);
        LineRepair.End eb = LineRepair.snap(project.pixels, project.w, project.h, hole,
                b[0], b[1], b[0] - b2[0], b[1] - b2[1], 28);
        float[] xy = new float[linePts.size() * 2];
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -1, maxY = -1;
        for (int i = 0; i < linePts.size(); i++) {
            float[] q = linePts.get(i);
            xy[i * 2] = q[0];
            xy[i * 2 + 1] = q[1];
            minX = Math.min(minX, q[0]);
            minY = Math.min(minY, q[1]);
            maxX = Math.max(maxX, q[0]);
            maxY = Math.max(maxY, q[1]);
        }
        minX = Math.min(minX, Math.min(ea.x, eb.x));
        minY = Math.min(minY, Math.min(ea.y, eb.y));
        maxX = Math.max(maxX, Math.max(ea.x, eb.x));
        maxY = Math.max(maxY, Math.max(ea.y, eb.y));
        int pad = 40;
        Rect guard = new Rect((int) minX - pad, (int) minY - pad, (int) maxX + pad, (int) maxY + pad);
        clamp(guard);
        linePts.clear();
        ensureRepairLines();
        undo.setLabel("Continuar linea");
        undo.record(UndoManager.PIXELS, guard);
        Rect r = LineRepair.drawCurve(project.pixels, project.w, project.h, repairLines, ea, eb, xy);
        if (r != null) afterRepair(r);
        showHud(ea.snapped && eb.snapped ? "Linea unida" : "Linea dibujada");
        invalidate();
    }

    /** Une solas las lineas cortadas en el borde del hueco. */
    public void autoJoinLines() {
        final byte[] hole = holeMask();
        if (hole == null) {
            msg("En Capas toca la parte que sacaste");
            return;
        }
        ensureRepairLines();
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        final Rect guard = new Rect(hb);
        guard.inset(-12, -12);
        clamp(guard);
        undo.setLabel("Unir lineas");
        undo.record(UndoManager.PIXELS, guard);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = LineRepair.autoJoin(project.pixels, project.w, project.h, hole, repairLines);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    afterRepair(lastFillRect);
                    showHud("Lineas unidas");
                } else {
                    showHud("No encontre lineas para unir: trazalas con el dedo");
                }
            }
        });
    }

    private void runZoneFill(int x, int y) {
        byte[] hole = holeMask();
        if (hole == null) {
            msg("En Capas toca la parte que sacaste");
            return;
        }
        Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        undo.setLabel("Rellenar zona");
        undo.record(UndoManager.PIXELS, hb);
        Rect r = ZoneFill.fill(project.pixels, project.w, project.h, hole, repairLines, x, y);
        if (r == null) {
            msg("Toca dentro del hueco, en una zona cerrada por lineas");
            return;
        }
        afterRepair(r);
    }

    private void runToneFill(final int x, final int y) {
        final byte[] hole = holeMask();
        if (hole == null) {
            msg("En Capas toca la parte que sacaste");
            return;
        }
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        byte[] region = hole;
        // si hay algo seleccionado, solo dentro de eso
        if (project.hasSelection()) {
            region = hole.clone();
            for (int i = 0; i < region.length; i++) {
                if ((project.selection[i] & 0xFF) <= 64) region[i] = 0;
            }
        }
        final byte[] reg = region;
        undo.setLabel("Continuar trama");
        undo.record(UndoManager.PIXELS, hb);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = ToneFill.fill(project.pixels, project.w, project.h, reg, x, y);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    afterRepair(lastFillRect);
                    showHud("Trama continuada");
                } else {
                    msg("Toca afuera del hueco, sobre la trama que quieres continuar");
                }
            }
        });
    }

    private void ensureRepairLines() {
        int n = project.w * project.h;
        if (repairLines == null || repairLines.length != n) repairLines = new byte[n];
    }

    private void ensurePatchSource() {
        int n = project.w * project.h;
        if (patchSource == null || patchSource.length != n) patchSource = new byte[n];
        if (patchOverlay == null && overlay != null) {
            patchOverlay = Bitmap.createBitmap(overlay.getWidth(), overlay.getHeight(),
                    Bitmap.Config.ARGB_8888);
        }
    }

    /** Pintar de donde se va a copiar (se ve verde). Con quitar, se borra. */
    private void stampPatchSource(float cx, float cy) {
        Rect r = MaskOps.stamp(patchSource, project.w, project.h, cx, cy, brushRadius, 1f, subtract, 1f);
        if (r == null) return;
        int ow = patchOverlay.getWidth(), oh = patchOverlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 < x1 && y0 < y1) {
            int rw = x1 - x0;
            int[] row = new int[rw];
            for (int y = y0; y < y1; y++) {
                int sy = Math.min(project.h - 1, y * ovScale);
                for (int i = 0; i < rw; i++) {
                    int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                    int a = patchSource[sy * project.w + sx] & 0xFF;
                    row[i] = a == 0 ? 0 : (((a * 120) / 255) << 24) | 0x34C759;
                }
                patchOverlay.setPixels(row, 0, rw, x0, y, rw, 1);
            }
        }
        invalidate();
    }

    public void clearPatchSource() {
        if (patchSource != null) java.util.Arrays.fill(patchSource, (byte) 0);
        if (patchOverlay != null) patchOverlay.eraseColor(0);
        invalidate();
    }

    /** Rellena el hueco copiando de lo pintado en verde (o de alrededor si no hay nada). */
    public void runPatchFill() {
        final byte[] hole = holeMask();
        if (hole == null) {
            msg("En Capas toca la parte que sacaste");
            return;
        }
        boolean anySrc = false;
        if (patchSource != null) {
            for (byte b : patchSource) {
                if (b != 0) {
                    anySrc = true;
                    break;
                }
            }
        }
        final byte[] src = anySrc ? patchSource : null;
        Rect guard = HoleFill.bounds(hole, project.w, project.h);
        if (guard == null) return;
        guard.inset(-50, -50);
        if (src != null) {
            Rect sb = HoleFill.bounds(src, project.w, project.h);
            if (sb != null) guard.union(sb);
        }
        clamp(guard);
        undo.setLabel("Copiar zona");
        undo.record(UndoManager.PIXELS, guard);
        setBusy(true);
        showHud("Rellenando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = PatchFill.fill(project.pixels, project.w, project.h, hole, src);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    afterRepair(lastFillRect);
                    showHud("Relleno listo");
                } else {
                    msg("Pinta en verde una zona mas grande de donde copiar");
                }
            }
        });
    }

    /** Al soltar el pincel corrector: se funde el color con el borde. */
    private void finishHeal(Rect r) {
        final int left = r.left, top = r.top, right = r.right, bottom = r.bottom;
        final int rw = right - left, rh = bottom - top;
        final boolean[] region = new boolean[rw * rh];
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                int i = (top + y) * project.w + left + x;
                region[y * rw + x] = project.pixels[i] != pxBackup[i];
            }
        }
        undo.setLabel("Corrector");
        undo.recordFromBackup(UndoManager.PIXELS, r, null, pxBackup);
        final int[] orig = pxBackup.clone();
        final Rect rr = new Rect(r);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                Membrane.heal(project.pixels, orig, orig, project.w, project.h, region,
                        left, top, right, bottom, new Membrane.SourceMap() {
                            @Override
                            public int map(int x, int y) {
                                return cloneSource(x, y);
                            }
                        });
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                afterRepair(rr);
            }
        });
    }

    /** Muestra transparente, bajo el pincel, lo que se va a copiar. */
    private void drawCloneGhost(Canvas c, float sx, float sy) {
        toImage(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float dxi = point[0], dyi = point[1];
        // punto de origen que corresponde a ese destino
        float ddx = dxi - (drawing ? cloneDestX : dxi), ddy = dyi - (drawing ? cloneDestY : dyi);
        float ox = drawing ? cloneDestX : dxi, oy = drawing ? cloneDestY : dyi;
        float mdx = cloneMirror ? -ddx : ddx, mdy = ddy;
        double a = Math.toRadians(cloneAngle);
        float srcX = cloneSrcX + (float) (mdx * Math.cos(a) - mdy * Math.sin(a));
        float srcY = cloneSrcY + (float) (mdx * Math.sin(a) + mdy * Math.cos(a));
        if (!drawing) {
            srcX = cloneSrcX;
            srcY = cloneSrcY;
        }
        Matrix m = new Matrix();
        m.setTranslate(-srcX, -srcY);
        m.postRotate(-cloneAngle);
        if (cloneMirror) m.postScale(-1f, 1f);
        m.postTranslate(dxi, dyi);
        m.postConcat(view);
        Path clip = new Path();
        clip.addCircle(sx, sy, Math.max(12f, brushRadius * currentScale()), Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.concat(m);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, ghostPaint);
        c.restore();
    }

    public void setCloneMirror(boolean m) {
        cloneMirror = m;
        invalidate();
    }

    public boolean isCloneMirror() {
        return cloneMirror;
    }

    public void setCloneAngle(float a) {
        cloneAngle = a;
        invalidate();
    }

    public float getCloneAngle() {
        return cloneAngle;
    }

    // ---- ajustes que usa la barra ----

    public void setAim(boolean on) {
        aimOn = on;
        invalidate();
    }

    public boolean isAim() {
        return aimOn;
    }

    public void setBgOnce(boolean once) {
        bgOnce = once;
    }

    public boolean isBgOnce() {
        return bgOnce;
    }

    public void setBgLimit(int l) {
        bgLimit = Math.max(0, Math.min(2, l));
    }

    public int getBgLimit() {
        return bgLimit;
    }

    public void setProtect(boolean on) {
        protectOn = on;
        protectColor = paintColor;
    }

    public boolean isProtect() {
        return protectOn;
    }

    /** Goma sobre la capa activa. Con seleccion, solo borra dentro de lo azul. */
    private void stampEraser(float cx, float cy) {
        com.pacco.animecut.core.Layer t = project.activeLayer();
        if (t == null) return;
        Rect r = MaskOps.stamp(t.mask, project.w, project.h, cx, cy,
                brushRadius, hardness, true, brushOpacity);
        if (r == null) return;
        if (selectionActive && maskBackup != null) {
            // fuera de lo azul no se borra
            for (int y = r.top; y < r.bottom; y++) {
                int off = y * project.w;
                for (int x = r.left; x < r.right; x++) {
                    int i = off + x;
                    int sel = project.selection[i] & 0xFF;
                    if (sel >= 255) continue;
                    int before = maskBackup[i] & 0xFF;
                    int now = t.mask[i] & 0xFF;
                    t.mask[i] = (byte) (before - ((before - now) * sel) / 255);
                }
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /**
     * Si no hay capa para borrar, se duplica la imagen y se oculta la
     * original. Es lo que se hace a mano en Ibis antes de usar la goma.
     */
    private com.pacco.animecut.core.Layer ensureEditableLayer() {
        com.pacco.animecut.core.Layer t = project.activeLayer();
        if (t != null) {
            if (project.baseVisible) {
                project.baseVisible = false;
                refreshDisplay();
                showHud("Imagen original oculta para ver lo que borras");
                changed();
            }
            return t;
        }
        duplicateImage();
        showHud("Capa nueva: ahora borra lo que sobra");
        return project.activeLayer();
    }

    private void stampBrush(float cx, float cy) {
        Rect r = smart ? smartSelectStamp(cx, cy)
                : MaskOps.stamp(project.selection, project.w, project.h, cx, cy,
                brushRadius, hardness, subtract, brushOpacity);
        if (r == null) return;
        if (!subtract) excludeParts(r);
        grow(r);
        paintOverlay(r);
        invalidate();
    }

    private Rect smartSelectStamp(float cx, float cy) {
        int w = project.w;
        int h = project.h;
        int x0 = (int) Math.floor(cx - brushRadius) - 1;
        int y0 = (int) Math.floor(cy - brushRadius) - 1;
        int x1 = (int) Math.ceil(cx + brushRadius) + 1;
        int y1 = (int) Math.ceil(cy + brushRadius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return null;

        boolean erase = subtract;
        float inner = brushRadius * hardness;
        float band = Math.max(1f, brushRadius - inner);
        int limit = tolerance + softness;

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > brushRadius) continue;
                int i = row + x;
                int cap = 255;
                if (!erase) {
                    if (project.barrier != null && useBarrier && project.barrier[i] != 0) continue;
                    int cd = ColorDist.dist(project.pixels[i], refColor, colorMode);
                    if (cd > limit) continue;
                    if (cd > tolerance && softness > 0) {
                        cap = 255 - ((cd - tolerance) * 255) / softness;
                    }
                }
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (a <= 0f) continue;
                int cur = project.selection[i] & 0xFF;
                int add = (int) (a * cap);
                if (erase) {
                    int v = cur - (int) (a * 255f);
                    project.selection[i] = (byte) (v < 0 ? 0 : v);
                } else if (add > cur) {
                    project.selection[i] = (byte) add;
                }
            }
        }
        return new Rect(x0, y0, x1, y1);
    }

    private void stampPaint(float cx, float cy) {
        int w = project.w;
        int h = project.h;
        int x0 = (int) Math.floor(cx - brushRadius) - 1;
        int y0 = (int) Math.floor(cy - brushRadius) - 1;
        int x1 = (int) Math.ceil(cx + brushRadius) + 1;
        int y1 = (int) Math.ceil(cy + brushRadius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return;

        float inner = brushRadius * hardness;
        float band = Math.max(1f, brushRadius - inner);

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > brushRadius) continue;
                int i = row + x;
                if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                a *= brushOpacity;
                if (a <= 0f) continue;
                painted++;
                project.pixels[i] = blend(project.pixels[i], paintColor, a);
            }
        }
        Rect r = new Rect(x0, y0, x1, y1);
        grow(r);
        project.pushPixels(r);
        updateDisplayRegion(r);
    }

    /** Pixel de origen para el destino (x, y): con espejo y giro si estan activos. */
    private int cloneSource(int x, int y) {
        float dx = x - cloneDestX, dy = y - cloneDestY;
        if (cloneMirror) dx = -dx;
        if (cloneAngle != 0f) {
            double a = Math.toRadians(cloneAngle);
            float c = (float) Math.cos(a), s = (float) Math.sin(a);
            float rx = dx * c - dy * s, ry = dx * s + dy * c;
            dx = rx;
            dy = ry;
        }
        int sx = Math.round(cloneSrcX + dx), sy = Math.round(cloneSrcY + dy);
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return -1;
        return sy * project.w + sx;
    }

    private void stampClone(float cx, float cy) {
        int w = project.w, h = project.h;
        int x0 = Math.max(0, (int) Math.floor(cx - brushRadius));
        int y0 = Math.max(0, (int) Math.floor(cy - brushRadius));
        int x1 = Math.min(w, (int) Math.ceil(cx + brushRadius) + 1);
        int y1 = Math.min(h, (int) Math.ceil(cy + brushRadius) + 1);
        if (x0 >= x1 || y0 >= y1) return;
        float inner = brushRadius * hardness;
        float bandR = Math.max(1f, brushRadius - inner);
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                float a = falloff(x, y, cx, cy, inner, bandR) * brushOpacity;
                if (a <= 0f) continue;
                int src = cloneSource(x, y);
                if (src < 0) continue;
                int i = y * w + x;
                project.pixels[i] = blend(project.pixels[i], pxBackup[src], a);
            }
        }
        Rect r = new Rect(x0, y0, x1, y1);
        grow(r);
        project.pushPixels(r);
        updateDisplayRegion(r);
    }

    private static int blend(int dst, int src, float a) {
        int ia = (int) (a * 256f);
        if (ia <= 0) return dst;
        if (ia > 256) ia = 256;
        int r = (((src >> 16) & 0xFF) * ia + ((dst >> 16) & 0xFF) * (256 - ia)) >> 8;
        int g = (((src >> 8) & 0xFF) * ia + ((dst >> 8) & 0xFF) * (256 - ia)) >> 8;
        int b = ((src & 0xFF) * ia + (dst & 0xFF) * (256 - ia)) >> 8;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void updateDisplayRegion(Rect r) {
        if (display == null) return;
        int x0 = (int) (r.left / dispScale) - 1;
        int y0 = (int) (r.top / dispScale) - 1;
        int x1 = (int) Math.ceil(r.right / dispScale) + 1;
        int y1 = (int) Math.ceil(r.bottom / dispScale) + 1;
        composeRegion(x0, y0, x1, y1);
        invalidate();
    }

    private void grow(Rect r) {
        if (strokeRect == null) strokeRect = new Rect(r);
        else strokeRect.union(r);
    }

    private void applyLasso() {
        Path closed = new Path(lasso);
        closed.close();
        RectF b = new RectF();
        closed.computeBounds(b, true);
        int l = Math.max(0, (int) Math.floor(b.left));
        int t = Math.max(0, (int) Math.floor(b.top));
        int rr = Math.min(project.w, (int) Math.ceil(b.right) + 1);
        int bb = Math.min(project.h, (int) Math.ceil(b.bottom) + 1);
        lasso.reset();
        if (l >= rr || t >= bb) {
            invalidate();
            return;
        }
        Rect region = new Rect(l, t, rr, bb);
        undo.record(UndoManager.SELECTION, region);

        int rw = region.width();
        int rh = region.height();
        Bitmap tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        pt.setStyle(Paint.Style.FILL);
        c.translate(-l, -t);
        c.drawPath(closed, pt);

        int[] row = new int[rw];
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (t + y) * project.w + l;
            for (int x = 0; x < rw; x++) {
                int a = (row[x] >>> 24);
                if (a == 0) continue;
                if (subtract) {
                    int cur = project.selection[off + x] & 0xFF;
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > (project.selection[off + x] & 0xFF)) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        paintOverlay(region);
        invalidate();
        changed();
    }

    // ------------------------------------------------------------------
    // Varita y balde
    // ------------------------------------------------------------------

    private void runWand(final int sx, final int sy) {
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                if (wandGlobal) {
                    lastFillRect = FloodFill.global(project.pixels, project.w, project.h,
                            scratch, sx, sy, tolerance, softness, colorMode);
                } else {
                    lastFillRect = fillWithGaps(sx, sy);
                }
                if (lastFillRect != null && expansion != 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(Math.abs(expansion)) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Varita");
                    undo.record(UndoManager.SELECTION, r);
                    mergeScratch(r);
                    excludeParts(r);
                    paintOverlay(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    /**
     * Relleno con reconocimiento de huecos. Engorda la linea para tapar los
     * cortes, rellena dentro, y devuelve el relleno a su sitio. Asi no se
     * escapa por una linea abierta.
     */
    private Rect fillWithGaps(int sx, int sy) {
        byte[] barrier = useBarrier ? project.barrier : null;
        if (!gapOn || barrier == null) {
            return FloodFill.contiguous(project.pixels, project.w, project.h,
                    scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        if (gapBarrier == null || gapBarrier.length != barrier.length) {
            gapBarrier = new byte[barrier.length];
        }
        MaskOps.closeGapsBarrier(barrier, project.w, project.h, gapRadius, gapBarrier);
        if (gapBarrier[sy * project.w + sx] != 0) {
            // el punto quedo bajo la linea engordada: se rellena sin cierre
            return FloodFill.contiguous(project.pixels, project.w, project.h,
                    scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        Rect r = FloodFill.contiguous(project.pixels, project.w, project.h,
                scratch, gapBarrier, sx, sy, tolerance, softness, colorMode);
        if (r == null) return null;
        MaskOps.dilate(scratch, project.w, project.h, gapRadius);
        for (int i = 0; i < scratch.length; i++) {
            if (barrier[i] != 0) scratch[i] = 0;
        }
        r.inset(-gapRadius - 1, -gapRadius - 1);
        clamp(r);
        return r;
    }

    /** Con "no repetir" activo, lo que ya se guardo como parte no se vuelve a agarrar. */
    private void excludeParts(Rect r) {
        if (!avoidParts || parts == null || subtract || r == null) return;
        for (int y = Math.max(0, r.top); y < Math.min(project.h, r.bottom); y++) {
            int off = y * project.w;
            for (int x = Math.max(0, r.left); x < Math.min(project.w, r.right); x++) {
                if ((parts[off + x] & 0xFF) > 128) project.selection[off + x] = 0;
            }
        }
    }

    private void mergeScratch(Rect r) {
        for (int y = r.top; y < r.bottom; y++) {
            int off = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                int a = scratch[off + x] & 0xFF;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
    }

    private void clamp(Rect r) {
        if (r.left < 0) r.left = 0;
        if (r.top < 0) r.top = 0;
        if (r.right > project.w) r.right = project.w;
        if (r.bottom > project.h) r.bottom = project.h;
    }

    private void runBucket(final int sx, final int sy) {
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return;
        setBusy(true);
        ensureScratch();
        final boolean useSel = project.hasSelection();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = fillWithGaps(sx, sy);
                if (lastFillRect != null && expansion > 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(expansion) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Balde");
                    undo.record(UndoManager.PIXELS, r);
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * project.w;
                        for (int x = r.left; x < r.right; x++) {
                            int i = off + x;
                            int a = scratch[i] & 0xFF;
                            if (a == 0) continue;
                            float f = a / 255f;
                            if (useSel) f *= (project.selection[i] & 0xFF) / 255f;
                            if (f <= 0f) continue;
                            project.pixels[i] = blend(project.pixels[i], paintColor, f);
                        }
                    }
                    project.pushPixels(r);
                    updateDisplayRegion(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    // ------------------------------------------------------------------
    // Gama de colores, copiar y pegar
    // ------------------------------------------------------------------

    /** Selecciona ese color en toda la imagen. Lo usa Gama de colores. */
    public void selectColorRange(final int color, final int tol, final int soft,
                                 final boolean replace) {
        if (project == null) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.globalColor(project.pixels, project.w, project.h,
                        scratch, color, tol, soft, colorMode);
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.record(UndoManager.SELECTION, project.fullRect());
                if (replace) project.clearSelection();
                if (lastFillRect != null) mergeScratch(lastFillRect);
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void copySelection(boolean cut) {
        if (project == null) return;
        Rect r = project.selectionBounds();
        if (r == null) {
            msg("No hay nada seleccionado");
            return;
        }
        int rw = r.width(), rh = r.height();
        clipPixels = new int[rw * rh];
        clipMask = new byte[rw * rh];
        clipRect = new Rect(r);
        for (int y = 0; y < rh; y++) {
            int src = (r.top + y) * project.w + r.left;
            System.arraycopy(project.pixels, src, clipPixels, y * rw, rw);
            System.arraycopy(project.selection, src, clipMask, y * rw, rw);
        }
        if (cut) {
            undo.record(UndoManager.PIXELS, r);
            for (int y = 0; y < rh; y++) {
                int off = (r.top + y) * project.w + r.left;
                for (int x = 0; x < rw; x++) {
                    int a = clipMask[y * rw + x] & 0xFF;
                    if (a == 0) continue;
                    project.pixels[off + x] = blend(project.pixels[off + x], 0xFFFFFFFF, a / 255f);
                }
            }
            project.pushPixels(r);
            updateDisplayRegion(r);
            changed();
        }
        msg(cut ? "Cortado" : "Copiado");
    }

    /** Pega lo copiado donde estaba, o desplazado si se indica. */
    public void paste(int offX, int offY) {
        if (project == null || clipPixels == null) {
            msg("No hay nada copiado");
            return;
        }
        int rw = clipRect.width(), rh = clipRect.height();
        Rect dst = new Rect(clipRect.left + offX, clipRect.top + offY,
                clipRect.left + offX + rw, clipRect.top + offY + rh);
        Rect safe = new Rect(dst);
        clamp(safe);
        if (safe.isEmpty()) return;
        undo.record(UndoManager.PIXELS, safe);
        for (int y = 0; y < rh; y++) {
            int ty = dst.top + y;
            if (ty < 0 || ty >= project.h) continue;
            for (int x = 0; x < rw; x++) {
                int tx = dst.left + x;
                if (tx < 0 || tx >= project.w) continue;
                int a = clipMask[y * rw + x] & 0xFF;
                if (a == 0) continue;
                int i = ty * project.w + tx;
                project.pixels[i] = blend(project.pixels[i], clipPixels[y * rw + x], a / 255f);
            }
        }
        project.pushPixels(safe);
        updateDisplayRegion(safe);
        changed();
        msg("Pegado");
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    private void ensureScratch() {
        if (scratch == null || scratch.length != project.w * project.h)
            scratch = new byte[project.w * project.h];
    }

    private void ensureSelBackup() {
        if (selBackup == null || selBackup.length != project.w * project.h)
            selBackup = new byte[project.w * project.h];
    }

    private void ensurePxBackup() {
        if (pxBackup == null || pxBackup.length != project.w * project.h)
            pxBackup = new int[project.w * project.h];
    }

    private void setBusy(boolean b) {
        busy = b;
        if (callback != null) callback.onBusy(b);
    }

    private void changed() {
        if (callback != null) callback.onChanged();
    }

    private void msg(String s) {
        if (callback != null) callback.onMessage(s);
    }

    public void doUndo() {
        if (undo == null) return;
        Rect r = undo.undo();
        if (r != null) {
            applyRestored(r);
            String l = undo.lastLabel();
            showHud(l == null || l.isEmpty() ? "Deshacer" : "Deshacer: " + l);
        } else {
            showHud("Nada que deshacer");
        }
    }

    public void doRedo() {
        if (undo == null) return;
        Rect r = undo.redo();
        if (r != null) {
            applyRestored(r);
            String l = undo.lastLabel();
            showHud(l == null || l.isEmpty() ? "Rehacer" : "Rehacer: " + l);
        } else {
            showHud("Nada que rehacer");
        }
    }

    private void applyRestored(Rect r) {
        int t = undo.lastRestoredType();
        if (t == UndoManager.PIXELS) {
            updateDisplayRegion(r);
        } else if (t == UndoManager.MASK) {
            updateDisplayRegion(r);
            refreshParts();
        } else {
            paintOverlay(r);
        }
        invalidate();
        changed();
    }

    public void clearSelection() {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void invertSelection() {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        MaskOps.invert(project.selection);
        refreshOverlay(null);
        changed();
    }

    public void loadSelection(byte[] mask) {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        MaskOps.copyInto(project.selection, mask);
        refreshOverlay(null);
        changed();
    }

    /** kind: 0 expandir, 1 contraer, 2 suavizar, 3 endurecer, 4 cerrar huecos */
    public void edgeOp(final int kind, final int radius) {
        if (project == null) return;
        setBusy(true);
        undo.record(UndoManager.SELECTION, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        MaskOps.dilate(project.selection, project.w, project.h, radius);
                        break;
                    case 1:
                        MaskOps.erode(project.selection, project.w, project.h, radius);
                        break;
                    case 2:
                        MaskOps.feather(project.selection, project.w, project.h, radius);
                        break;
                    case 4:
                        MaskOps.closeHoles(project.selection, project.w, project.h, radius);
                        break;
                    case 5:
                        MaskOps.fillEnclosed(project.selection, project.w, project.h,
                                radius <= 0 ? 0 : radius * 400);
                        break;
                    default:
                        MaskOps.threshold(project.selection, 128);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    /** Expansion con decimales aplicada a mano sobre la seleccion. */
    public void expandSelection(final float px) {
        if (project == null) return;
        setBusy(true);
        undo.record(UndoManager.SELECTION, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                MaskOps.expandSubpixel(project.selection, project.w, project.h, px, null);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void buildBarrier(final int threshold, final int closeGap) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                project.barrier = LineArt.build(project.pixels, project.w, project.h,
                        threshold, closeGap);
                gapBarrier = null;
                wire = null;
            }
        }, new Runnable() {
            @Override
            public void run() {
                useBarrier = true;
                setBusy(false);
                msg("Line art listo: la varita y el balde ya no se escapan por las lineas");
                changed();
            }
        });
    }

    public void transform(final int kind) {
        if (project == null) return;
        for (com.pacco.animecut.core.Layer l : project.layers) {
            if (l.own != null) {
                msg("Gira la imagen antes de tapar huecos");
                return;
            }
        }
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        project.rotate90(true);
                        break;
                    case 1:
                        project.rotate90(false);
                        break;
                    case 2:
                        project.flip(true);
                        break;
                    default:
                        project.flip(false);
                        break;
                }
                gapBarrier = null;
                wire = null;
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.clear();
                scissorsReset();
                markers = null;
                if (markersOverlay != null) markersOverlay.recycle();
                markersOverlay = null;
                gradient = null;
                repairLines = null;
                patchSource = null;
                if (patchOverlay != null) patchOverlay.recycle();
                patchOverlay = null;
                buildDisplay();
                buildOverlay();
                refreshParts();
                fit();
                setBusy(false);
                msg("Listo. El historial de deshacer se reinicia al girar");
                changed();
            }
        });
    }

    // ------------------------------------------------------------------
    // Tijeras inteligentes
    // ------------------------------------------------------------------

    private void setAnchorAsync(final int x, final int y) {
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (wire == null) wire = new LiveWire(project.pixels, project.w, project.h);
                wire.setAnchor(x, y, 320);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                invalidate();
            }
        });
    }

    private void appendLive() {
        if (livePath == null || livePath.length < 2) return;
        for (int i = livePath.length - 1; i >= 0; i -= 2) {
            int idx = livePath[i];
            int y = idx / project.w;
            int x = idx - y * project.w;
            wirePath.lineTo(x, y);
        }
        livePath = null;
    }

    /** Fija el tramo que se estaba viendo y arranca el siguiente. */
    private void commitWire() {
        if (livePath == null || livePath.length < 2) return;
        // el camino viene del dedo hacia el ancla, se recorre al reves
        for (int i = livePath.length - 1; i >= 0; i -= 2) {
            int idx = livePath[i];
            int y = idx / project.w;
            int x = idx - y * project.w;
            wirePath.lineTo(x, y);
        }
        int last = livePath[0];
        int ly = last / project.w;
        int lx = last - ly * project.w;
        livePath = null;

        if (firstAnchor >= 0) {
            int fy = firstAnchor / project.w;
            int fx = firstAnchor - fy * project.w;
            float d = (float) Math.hypot(lx - fx, ly - fy);
            if (d < 24f) {
                scissorsClose();
                return;
            }
        }
        setAnchorAsync(lx, ly);
        invalidate();
    }

    /** Cierra la figura y la convierte en seleccion. */
    public void scissorsClose() {
        if (project == null || !wireStarted) {
            msg("Primero traza el contorno con las tijeras");
            return;
        }
        Path closed = new Path(wirePath);
        closed.close();
        scissorsReset();
        fillPathIntoSelection(closed, "Tijeras");
    }

    public void scissorsReset() {
        wirePath.reset();
        livePath = null;
        firstAnchor = -1;
        wireStarted = false;
        invalidate();
    }

    /** Rellena una figura cerrada dentro de la seleccion. */
    private void fillPathIntoSelection(Path closed, String label) {
        RectF b = new RectF();
        closed.computeBounds(b, true);
        int l = Math.max(0, (int) Math.floor(b.left));
        int t = Math.max(0, (int) Math.floor(b.top));
        int rr = Math.min(project.w, (int) Math.ceil(b.right) + 1);
        int bb = Math.min(project.h, (int) Math.ceil(b.bottom) + 1);
        if (l >= rr || t >= bb) {
            invalidate();
            return;
        }
        Rect region = new Rect(l, t, rr, bb);
        undo.setLabel(label);
        undo.record(UndoManager.SELECTION, region);

        int rw = region.width();
        int rh = region.height();
        Bitmap tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        pt.setStyle(Paint.Style.FILL);
        c.translate(-l, -t);
        c.drawPath(closed, pt);

        int[] row = new int[rw];
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (t + y) * project.w + l;
            for (int x = 0; x < rw; x++) {
                int a = (row[x] >>> 24);
                if (a == 0) continue;
                if (subtract) {
                    int cur = project.selection[off + x] & 0xFF;
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > (project.selection[off + x] & 0xFF)) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        excludeParts(region);
        paintOverlay(region);
        invalidate();
        changed();
    }

    // ------------------------------------------------------------------
    // Mover la seleccion
    // ------------------------------------------------------------------

    private void shiftSelection(int dx, int dy) {
        if (moveBackup == null) return;
        int w = project.w, h = project.h;
        java.util.Arrays.fill(project.selection, (byte) 0);
        for (int y = 0; y < h; y++) {
            int ty = y + dy;
            if (ty < 0 || ty >= h) continue;
            int src = y * w;
            int dst = ty * w;
            for (int x = 0; x < w; x++) {
                int tx = x + dx;
                if (tx < 0 || tx >= w) continue;
                project.selection[dst + tx] = moveBackup[src + x];
            }
        }
        refreshOverlay(null);
    }

    // ------------------------------------------------------------------
    // Estabilizador, vista previa, refinado y filtros
    // ------------------------------------------------------------------

    /** Duplica la imagen en una capa nueva completa, la activa y oculta la original. */
    public void duplicateImage() {
        if (project == null) return;
        byte[] m = new byte[project.w * project.h];
        java.util.Arrays.fill(m, (byte) 255);
        com.pacco.animecut.core.Layer l =
                new com.pacco.animecut.core.Layer("capa_" + (project.layers.size() + 1), m);
        project.layers.add(l);
        project.active = project.layers.size() - 1;
        project.baseVisible = false;
        refreshDisplay();
        refreshParts();
        changed();
    }

    /** Duplica la capa activa, o la imagen si esta activa la original. */
    public void duplicateActive() {
        com.pacco.animecut.core.Layer a = project == null ? null : project.activeLayer();
        if (a == null) {
            duplicateImage();
            return;
        }
        byte[] m = a.mask.clone();
        com.pacco.animecut.core.Layer l = new com.pacco.animecut.core.Layer(a.name + "_copia", m);
        l.opacity = a.opacity;
        project.layers.add(project.active + 1, l);
        project.active = project.active + 1;
        refreshDisplay();
        refreshParts();
        changed();
    }

    /** Borra de la capa activa lo que esta seleccionado. */
    public void eraseSelectionFromLayer() {
        com.pacco.animecut.core.Layer t = project == null ? null : project.activeLayer();
        if (t == null) {
            msg("Elige una capa primero, no la imagen original");
            return;
        }
        undo.setLabel("Eliminar area");
        undo.recordMask(t, project.fullRect());
        for (int i = 0; i < t.mask.length; i++) {
            int sel = project.selection[i] & 0xFF;
            if (sel == 0) continue;
            t.mask[i] = (byte) (((t.mask[i] & 0xFF) * (255 - sel)) / 255);
        }
        refreshDisplay();
        refreshParts();
        changed();
    }

    /** Deja en la capa activa solo lo seleccionado. */
    public void keepSelectionInLayer() {
        com.pacco.animecut.core.Layer t = project == null ? null : project.activeLayer();
        if (t == null) {
            msg("Elige una capa primero, no la imagen original");
            return;
        }
        undo.setLabel("Recortar capa");
        undo.recordMask(t, project.fullRect());
        for (int i = 0; i < t.mask.length; i++) {
            int sel = project.selection[i] & 0xFF;
            t.mask[i] = (byte) (((t.mask[i] & 0xFF) * sel) / 255);
        }
        refreshDisplay();
        refreshParts();
        changed();
    }

    public void setActive(int index) {
        if (project == null) return;
        project.active = index;
        changed();
    }

    public void setBaseVisible(boolean v) {
        if (project == null) return;
        project.baseVisible = v;
        refreshDisplay();
        changed();
    }

    /** Recalcula la capa verde con todas las partes guardadas y visibles. */
    public void refreshParts() {
        if (project == null) return;
        int n = project.w * project.h;
        if (parts == null || parts.length != n) parts = new byte[n];
        java.util.Arrays.fill(parts, (byte) 0);
        boolean any = false;
        for (com.pacco.animecut.core.Layer l : project.layers) {
            if (!l.visible) continue;
            any = true;
            for (int i = 0; i < n; i++) {
                int v = l.mask[i] & 0xFF;
                if (v > (parts[i] & 0xFF)) parts[i] = (byte) v;
            }
        }
        if (partsOverlay != null) partsOverlay.recycle();
        partsOverlay = null;
        if (any && overlay != null) {
            int ow = overlay.getWidth(), oh = overlay.getHeight();
            partsOverlay = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
            int[] row = new int[ow];
            for (int y = 0; y < oh; y++) {
                int sy = Math.min(project.h - 1, y * ovScale);
                int base = sy * project.w;
                for (int x = 0; x < ow; x++) {
                    int sx = Math.min(project.w - 1, x * ovScale);
                    int a = parts[base + sx] & 0xFF;
                    row[x] = a == 0 ? 0 : (((a * 95) / 255) << 24) | 0x2FC060;
                }
                partsOverlay.setPixels(row, 0, ow, 0, y, ow, 1);
            }
        }
        invalidate();
    }

    /** Llamar tras mostrar, ocultar, borrar o reordenar capas. */
    public void layersChanged() {
        refreshDisplay();
        refreshParts();
    }

    public void setShowParts(boolean v) {
        showParts = v;
        invalidate();
    }

    public boolean isShowParts() {
        return showParts;
    }

    public void setAvoidParts(boolean v) {
        avoidParts = v;
    }

    public boolean isAvoidParts() {
        return avoidParts;
    }

    public void setBrushOpacity(float v) {
        brushOpacity = Math.max(0.02f, Math.min(1f, v));
    }

    public float getBrushOpacity() {
        return brushOpacity;
    }

    public void setStabilizer(float v) {
        stabilizer = Math.max(0f, Math.min(0.92f, v));
    }

    public float getStabilizer() {
        return stabilizer;
    }

    /** Guarda la seleccion para poder ir probando margenes en vivo. */
    public void beginPreview() {
        if (project == null) return;
        if (previewBackup == null || previewBackup.length != project.selection.length) {
            previewBackup = new byte[project.selection.length];
        }
        System.arraycopy(project.selection, 0, previewBackup, 0, previewBackup.length);
    }

    public void previewColorRange(final int color, final int tol, final boolean replace) {
        if (project == null || previewBackup == null || busy) return;
        setBusy(true);
        ensureScratch();
        final int soft = softness;
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.globalColor(project.pixels, project.w, project.h,
                        scratch, color, tol, soft, colorMode);
            }
        }, new Runnable() {
            @Override
            public void run() {
                System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
                if (replace) project.clearSelection();
                if (lastFillRect != null) mergeScratch(lastFillRect);
                refreshOverlay(null);
                setBusy(false);
            }
        });
    }

    /** Se queda con lo que se ve, o lo devuelve a como estaba. */
    public void endPreview(boolean keep) {
        if (project == null || previewBackup == null) return;
        if (keep) {
            byte[] shown = new byte[project.selection.length];
            System.arraycopy(project.selection, 0, shown, 0, shown.length);
            System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
            undo.setLabel("Gama de colores");
            undo.record(UndoManager.SELECTION, project.fullRect());
            System.arraycopy(shown, 0, project.selection, 0, shown.length);
        } else {
            System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
        }
        previewBackup = null;
        refreshOverlay(null);
        changed();
    }

    /** Refina el borde siguiendo el dibujo. Para pelo y bordes finos. */
    public void refineEdge(final int radius, final float eps) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Refinar borde");
        undo.record(UndoManager.SELECTION, project.fullRect());
        final Rect area = project.selectionBounds();
        Task.run(new Runnable() {
            @Override
            public void run() {
                GuidedFilter.refine(project.selection, project.pixels,
                        project.w, project.h, radius, eps, area);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    /** kind: 0 mediana, 1 posterizar, 2 niveles, 3 extraer line art */
    public void applyFilter(final int kind, final int a, final int b, final int c) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Filtro");
        undo.record(UndoManager.PIXELS, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        Filters.median3(project.pixels, project.w, project.h);
                        break;
                    case 1:
                        Filters.posterize(project.pixels, a);
                        break;
                    case 2:
                        Filters.levels(project.pixels, a, b, c / 100f);
                        break;
                    default:
                        Filters.extractLineArt(project.pixels, project.w, project.h, a, b, c);
                        break;
                }
                project.pushPixels(null);
            }
        }, new Runnable() {
            @Override
            public void run() {
                wire = null;
                refreshDisplay();
                setBusy(false);
                changed();
            }
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (project != null && ow == 0) fit();
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelQuickTimer();
        super.onDetachedFromWindow();
    }
}
