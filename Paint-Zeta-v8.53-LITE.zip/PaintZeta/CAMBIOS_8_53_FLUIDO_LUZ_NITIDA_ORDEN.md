# Paint Zeta v8.53: Borrar fondo fluido, luz nítida y pantalla ordenada (sobre la v8.52)

Se aplicó la investigación profunda, punto por punto, siguiendo el plan en orden: cómo lo resuelven ibisPaint, Procreate, MediBang, Clip Studio y Krita.

## 1. Borrar fondo fluido otra vez

El pincel en sí es igual al de la v8.38. Lo lento era lo que se agregó alrededor; ahora:

- **Al poner el dedo ya no se recorre la imagen entera.** Antes, en cada trazo:
  - se comparaba toda la capa con la copia de antes;
  - con B/N se pasaba toda la imagen a gris dos veces;
  - se volvía a analizar todo el fondo, con mapas de 4 bytes por píxel que después se tiraban.

  Ahora, si desde el trazo anterior solo borraste, todo eso se reutiliza. La copia gris se mantiene al día solo en la zona que tocas.
- **Las tareas de fondo van con prioridad baja**: el análisis del fondo, la medida de las líneas y el guardado. El dedo y la pantalla van primero.
- **Capas de abajo en caché** (como Krita y las apps de pintura): mientras pintas o borras en una capa, las capas de abajo se mezclan una sola vez, por bloques de 64 px y solo donde pasa el dedo. Cada toque mezcla solo la capa activa y las de arriba; antes eran todas, en cada toque. Funciona también con zoom, y ahí el detalle nítido aguanta zonas 4 veces más grandes antes de esperar a soltar el dedo.
- **Guardado automático más liviano**:
  - espera 5 s quieto (8 s en Borrar fondo); antes eran 2,5 s;
  - usa un PNG rápido hecho a mano, sin crear una imagen recortada de la capa;
  - las capas que no cambiaron no se vuelven a comprimir;
  - la copia de Restaurar usa el mismo PNG rápido.
- **La barra de abajo y el panel de capas** se rehacen un momento después del trazo, no en el mismo instante.

## 2. Luz nítida: capas que solo tienen luz

- **Antes**: ✦ Luz era tu dibujo entero con la luz encima. Tapaba las capas de abajo, y la vista previa era chica (unos 500 × 500) estirada: por eso se veía borroso.
- **Ahora** quedan capas **solo con el efecto**. Tu dibujo no se toca:
  - **✦ Luz** (Superponer, como la capa de "dar vida" de Ibis);
  - **✦ Brillo** (Pantalla: contraluz y resplandor);
  - **✦ Sombra** (Multiplicar);
  - **✦ Fondo** (cielo y sol, debajo del personaje, solo si está recortado);
  - **✦ Tono** (solo con foto de fondo).
- **Se ve igual que antes**: la diferencia media es de 1 de 255. Se pueden ocultar, bajar o retocar una por una, y se reemplazan al volver a aplicar.
- **Vista previa**: el dibujo nítido a casi 3 veces más resolución que antes. Los efectos, que son suaves, se calculan chicos y se agrandan.

## 3. Pantalla ordenada, como ibisPaint

- **Herramientas**:
  - arriba de todo, **COLOREAR (EN ORDEN)**: 1 Colorear, 2 Toques, 3 Luz, 4 Estilo, Mejorar y Manga;
  - después Pintar y retocar;
  - después Extraer personajes;
  - después Mover y animar.
- **Capas**: una **barra al costado con íconos y nombre**: Limpiar, Mover, Voltear ↔, Voltear ↕, Girar 90°, Modo, Sacar líneas, Difuminar, Color, Filtros y Opciones. Mantener pulsado dice qué hace.
- **Botón de girar arriba**: un toque gira el lienzo 90°, mantener pulsado lo endereza. No cambia el dibujo.
- **Menú ⋮**: solo lo básico (imagen, pincel, vista, ayuda y guardar).
- **Modos de mezcla**: arriba los **MÁS USADOS** (Normal, Multiplicar, Añadir, Superponer, Pantalla), como dice el manual de Ibis.

## 4. Manga más fácil

- **Sacar líneas** (el "Extraer dibujo lineal" de Ibis):
  - deslizadores Blanco 85, Negro 20 y Medio 50, con el resultado en el lienzo mientras mueves;
  - opción de que las líneas guarden su color;
  - Listo se puede deshacer y Cancelar devuelve la capa.
- **Toques** con las fuerzas de las guías: sombra cerca del 40 %, rubor cerca del 45 % y luz en Superponer cerca del 70 %.

## Pruebas

Lo que se probó en la PC:
- **PNG rápido**:
  - página de 2480 × 3508 en 98–136 ms, contra 393–419 ms del PNG normal;
  - mismo tamaño;
  - al abrirlo los píxeles salen idénticos.
- **Huella para saber si una capa cambió**: 13 ms.
- **Luz en capas**:
  - mismo resultado que antes (diferencia media de 1 de 255 con la escena entera y de 1 de 255 con el personaje recortado);
  - sin copiar el dibujo.
- **Sacar líneas**: 1108 × 1108 en 12 ms. El papel queda transparente y las líneas sólidas.

Lo que falta probar en tu teléfono:
- la fluidez de Borrar fondo;
- la barra de capas;
- el botón de girar;
- el panel de herramientas;
- la vista previa nueva.

Todo eso **solo se compiló**.
