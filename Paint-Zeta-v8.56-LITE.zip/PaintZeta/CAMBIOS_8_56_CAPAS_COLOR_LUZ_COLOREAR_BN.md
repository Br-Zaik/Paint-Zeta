# Paint Zeta v8.56: lo que pediste de la 8.55 (sobre la 8.55)

## 1. Capas: como antes, pero transparente (imagen 1)

- El panel de capas volvió a ser como antes:
  - ancho completo abajo;
  - filas grandes;
  - los 3 botones junto a la capa elegida;
  - la barra de opacidad de antes.
- Lo único que queda nuevo: el panel y las filas son semitransparentes, así que se ve el dibujo de atrás.
- La lista de modos de mezcla tipo Ibis sigue igual.

## 2. Colores: como antes, pero fluido (imágenes 2 y 3)

- Se quitaron los cuadros de colores al costado de la rueda. La rueda queda centrada como antes.
- El botón de cuadritos sigue llevando a "Mis colores". Ahora el cambio es fluido:
  - la ventana mantiene el mismo alto, así que no salta ni se mueve;
  - aparece con un fundido corto.

## 3. Luz no hacía nada en tu manga (imágenes 4 y 5)

- **Causa:**
  - La "Luz" se pone en modo Superponer. En un manga blanco y negro, Superponer no cambia ni el blanco del papel ni el negro de la tinta.
  - Por eso, aunque subieras o bajaras, casi no se notaba nada. Con "Día", que es la luz más pálida, menos todavía.
- **Ahora:**
  - Si el dibujo es casi todo blanco y negro, la luz además tiñe el papel del color de la luz, en Multiplicar: fuerte cerca del sol y nada lejos.
  - Así se ve y sigue sin tapar la tinta.
  - Ese tinte queda dentro de la capa "✦ Sombra" (que está en Multiplicar).
- **Medido con tu imagen:**
  - el cambio promedio pasó de 31 a 60 con Atardecer, y de 23 a 37 con Día;
  - la parte de la imagen que cambia pasó de la mitad a 3 de cada 4 partes.
- **Si al tocar ✓ no aparece ninguna capa ✦:** mándame captura del mensaje que sale. En la PC, con tu imagen, las capas sí se crean.

## 4. Colorear decía "Tocaste la línea negra" al tocar lo blanco (imágenes 6 y 7)

- **Causa:**
  - Al preparar Colorear, la app pregunta cuál capa es el manga si hay varias con dibujo. En la lista salía también la capa de Toques (el rubor rosado).
  - Esa capa quedó como "Tinta B/N" (en tu captura, al 47 % y con rayas rosadas).
  - Como esa capa es casi toda transparente, todo lo transparente contaba como línea. Por eso cualquier toque en lo blanco decía "Tocaste la línea negra".
- **Ahora:**
  - La app elige sola la imagen que más cubre el lienzo, y ya no ofrece capas de Toques, Luz, Estilo ni de color.
  - En tu obra ya preparada, al tocar 1 Colorear o Manga se arregla sola:
    - la imagen pasa a ser la "Tinta B/N";
    - la capa de Toques vuelve a ser una capa normal ("capa (antes Tinta)");
    - las capas de color quedan encima de la tinta.
  - Deshacer lo devuelve.

## 5. B/N se ponía oscuro solo (imágenes 8 y 9)

- **Causa:** fue un cambio mío de la 8.54. Al cerrar la barra de B/N se veía el gris "limpio", sin tu contraste ni tu brillo. Con una imagen oscura parecía que se oscurecía sola.
- **Ahora:**
  - Se ve siempre con tu ajuste, como antes de la 8.54. Lo que ves es lo que usa la herramienta.
  - Sigue la mejora de que, al cambiar el B/N, la imagen nítida no desaparece un momento.

## Qué falta probar en tu teléfono

- Capas: que se vea como antes, pero transparente.
- Colores: el cambio a "Mis colores" sin saltos.
- Luz sobre un manga, con Atardecer y con Día.
- 1 Colorear en tu obra de las capturas 6 y 7: debería arreglarse sola al entrar.
- B/N con tu ajuste.

Luz se probó en la PC con tu imagen. Lo demás se revisó en el código, pero no se pudo armar el APK aquí: lo compila GitHub Actions como siempre.
