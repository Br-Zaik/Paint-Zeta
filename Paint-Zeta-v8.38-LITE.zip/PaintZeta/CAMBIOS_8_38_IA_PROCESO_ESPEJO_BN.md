# Paint Zeta v8.38 — La IA no tumba la app, mira en espejo, y B/N más cómodo (sobre la v8.37)

## 1. La IA corre en un proceso aparte (idea del módulo de Zeta Motion)

- **El modelo corre en un proceso aparte del teléfono** (`AiService`, proceso `:ia`).
  - **Si falta memoria**, Android cierra **solo la IA**: Paint Zeta y tu dibujo siguen abiertos y sale un aviso.
  - Antes se podía cerrar toda la app.
- **Al terminar, ese proceso se cierra solo** y devuelve toda su memoria.
- **Cancelar** cierra el proceso de la IA al instante.
- **Respaldo**: si el teléfono no deja iniciar el proceso aparte, la IA corre dentro de la app como en la v8.37.
- **Preparar la imagen y limpiar el borde** (borde por línea, marca del dedo, manchas) se sigue haciendo en la app, igual que antes.
- **El intercambio es por archivos** (`ai/AiJob.java`).
  - Probado en el PC (`docs/qa838/P20_proceso_aparte.txt`): el resultado es igual al de correr la IA directo (diferencia máxima de 1 en 255) y escribir la entrada tarda 20 a 80 ms.

## 2. En imágenes a color, la IA mira también en espejo

- **La misma IA mira la imagen normal y dada vuelta** (izquierda-derecha) y se promedian las dos. Se conoce como "test-time augmentation".
  - No baja nada nuevo.
  - Tarda el doble en la parte de la IA: unos 4 s en este PC en vez de 2.
- **Medido** (`docs/qa838/P19_espejo.txt`, escenas propias con verdad conocida):
  - **mejora el acierto en 5 de 7 escenas**:
    - fondo blanco: 99,72 % → 99,99 % (falta de personaje 940 → 112 px);
    - brillos: 98,13 % → 98,88 % (restos de fondo 6596 → 3483 px);
    - edificio: 96,42 % → 97,23 % (restos 16 698 → 8168 px);
  - **pero** en el edificio el borde salió peor y se perdieron 2163 px del personaje;
  - **en manga con trama empeora** (98,86 % contra 99,13 %), por eso **en blanco y negro no se usa**;
  - JPEG malo: igual.
- **En tu imagen de los dos personajes con barras** quitó la barra de la derecha que quedaba pegada: `docs/qa838/espejo_quita_barra.png`.

## 3. Aviso "la IA dudó"

- Si la IA dudó bastante, sale un aviso corto arriba: **"La IA dudó en partes: repasa el borde (Balde o Restaurar)"**.
- **Calibrado con las imágenes de prueba**:
  - las que salen bien dan 0,02-0,045;
  - las que dejan restos (barras, edificio, JPEG malo) dan 0,056-0,24;
  - avisa desde 0,05 en blanco y negro y desde 0,06 en color.

## 4. B/N más cómodo (tus 2 capturas)

- **Los cuadros del fondo ya no se ponen grises.** El gris se aplica solo a las capas, antes de ponerlas sobre los cuadros. El verde (o el que elijas con el ojo) queda verde y se ve claro lo ya borrado.
- **Los ajustes van en una barra chica abajo**, justo encima de las herramientas; ya no hay ventana en el medio.
  - El lienzo queda a la vista mientras mueves Saturación, Contraste o Brillo.
  - **No bloquea**: puedes seguir usando el Balde con la barra abierta.
- **Se guarda al momento**: apagar y prender B/N lo deja como lo dejaste.
- **Botones de la barra**:
  - **"Ver color"**: miras tu color un momento sin perder el ajuste; "Ver B/N" vuelve.
  - **"De fábrica"**: vuelve todo a cero.
  - **"Apagar B/N"**.
  - **"Listo"**: cierra la barra.

## 5. La IA de Zeta Motion (la probé)

- **Es el mismo modelo**: isnet-anime, el mismo SHA-256.
- **Su recorte es más simple** (sin limpieza del borde) y sale peor en 6 de 7 escenas.
  - Error del borde en la escena blanca: 8,98 contra 3,62.
  - Halo: 13,77 contra 3,89.
  - Datos: `docs/qa837/zeta_motion_vs_paint_*`.
- **De ahí se tomó** el proceso aparte y el aviso de duda.

## 6. Lo que se buscó en internet y no se agregó

- **ToonOut** (2025, licencia MIT): una IA para anime con muy buen resultado en su propia prueba (99,5 % de acierto por píxel). Usa la versión grande de BiRefNet: es mucho más pesada y lenta para un teléfono.
- **No se pudo bajar aquí para probarla**: Hugging Face está bloqueado en este entorno. Sin probarla no se agrega.
- **Fuentes**:
  - https://arxiv.org/abs/2509.06839
  - https://huggingface.co/joelseytre/toonout

## Archivos

- **Nuevos**:
  - `AiService.java`: el proceso aparte;
  - `ai/AiJob.java`: el trabajo por archivos, el espejo y la duda.
- **Cambiados**:
  - `AiCutFlow.java`;
  - `MainActivity.java`: la barra del B/N;
  - `view/CanvasView.java`: el gris solo en las capas y "Ver color";
  - `core/GrayView.java`;
  - `AndroidManifest.xml`: el servicio `:ia`;
  - `app/build.gradle`: versión 8.38 (76).
- **Pruebas**: `P19Espejo`, `P20Proceso`, `ZmCompare`, `P18IaBalde`, `EspejoView` (en `run_qa833.sh`).
- `.github` sin cambios.

## No probado (verdad)

- **No se probó en un teléfono**:
  - el proceso aparte (si Android lo cierra por memoria, cómo se ve el aviso);
  - el tiempo real con espejo;
  - la barra del B/N.
- **Compila** completo contra android.jar: 754 clases. El AndroidManifest no se pudo validar aquí; lo hace Gradle en Actions.
- **Las pruebas P11** (sesión de la IA) siguen 13 de 13 OK.
- **P17** (B/N): tu color sigue sin cambiar (0 píxeles).
- **No es 100 %**: la IA todavía puede dejar barras u objetos pegados. El espejo ayuda a veces; si quedan, marca al personaje con el dedo o usa el Balde.
