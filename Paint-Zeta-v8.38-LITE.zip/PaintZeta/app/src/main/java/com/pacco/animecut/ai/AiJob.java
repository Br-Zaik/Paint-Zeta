package com.pacco.animecut.ai;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.channels.FileChannel;

/**
 * v8.38: un trabajo de la IA por ARCHIVOS, para correr el modelo en un PROCESO APARTE (idea
 * tomada del modulo de Zeta Motion). Si al telefono le falta memoria, Android cierra solo ese
 * proceso y Paint Zeta sigue abierta con un aviso.
 *
 *  entrada.f32 : tensor 1x3xSxS ya preparado (AiPrep.fill), floats little-endian
 *  salida.f32  : SxS (0..1)
 *  estado.txt  : "ok" o "error:motivo" (se escribe AL FINAL)
 *
 * Espejo (solo imagenes a color): la IA mira tambien la imagen dada vuelta (izquierda-derecha) y
 * se promedian las dos miradas. En las pruebas quito restos (una barra pegada) y mejoro el borde
 * en 5 de 6 escenas a color; en manga no ayudaba, por eso no se usa ahi.
 * Java puro: lo usan el servicio de la app y las pruebas de PC.
 */
public final class AiJob {
    public static final String IN = "entrada.f32", OUT = "salida.f32", STATE = "estado.txt";

    private AiJob() { }

    public static void writeFloats(File f, FloatBuffer src) throws IOException {
        src.rewind();
        int n = src.remaining();
        File tmp = new File(f.getPath() + ".tmp");
        try (RandomAccessFile raf = new RandomAccessFile(tmp, "rw"); FileChannel ch = raf.getChannel()) {
            raf.setLength(0);
            ByteBuffer bb = ByteBuffer.allocateDirect(1 << 20).order(ByteOrder.LITTLE_ENDIAN);
            int left = n;
            while (left > 0) {
                bb.clear();
                int k = Math.min(left, bb.capacity() / 4);
                for (int i = 0; i < k; i++) bb.putFloat(src.get());
                bb.flip();
                while (bb.hasRemaining()) ch.write(bb);
                left -= k;
            }
        }
        src.rewind();
        if (!tmp.renameTo(f)) throw new IOException("no se pudo guardar " + f.getName());
    }

    /** Lee n floats en dst (o en uno nuevo si dst es null o chico). */
    public static FloatBuffer readFloats(File f, int n, FloatBuffer dst) throws IOException {
        if (f.length() < 4L * n) throw new IOException("archivo corto: " + f.getName());
        if (dst == null || dst.capacity() < n) dst = FloatBuffer.allocate(n);
        dst.clear();
        try (RandomAccessFile raf = new RandomAccessFile(f, "r"); FileChannel ch = raf.getChannel()) {
            ByteBuffer bb = ByteBuffer.allocateDirect(1 << 20).order(ByteOrder.LITTLE_ENDIAN);
            int left = n;
            while (left > 0) {
                bb.clear();
                bb.limit(Math.min(bb.capacity(), left * 4));
                while (bb.hasRemaining()) if (ch.read(bb) < 0) throw new IOException("fin de archivo");
                bb.flip();
                while (bb.hasRemaining()) { dst.put(bb.getFloat()); left--; }
            }
        }
        dst.flip();
        return dst;
    }

    /** Da vuelta (izquierda-derecha) las columnas [x0, x0+w) de cada fila de cada plano SxS. */
    public static void flipCols(FloatBuffer b, int planes, int S, int x0, int w) {
        for (int p = 0; p < planes; p++)
            for (int y = 0; y < S; y++) {
                int o = p * S * S + y * S + x0;
                for (int i = 0, j = w - 1; i < j; i++, j--) {
                    float t = b.get(o + i);
                    b.put(o + i, b.get(o + j));
                    b.put(o + j, t);
                }
            }
    }

    /**
     * Corre el trabajo: lee la entrada, corre la IA (y el espejo si se pide) y escribe la salida.
     * padX, w = zona con imagen dentro del cuadrado (el resto es relleno negro).
     */
    public static void run(File model, File dir, int threads, boolean mirror, int padX, int w) throws Exception {
        try (AiSegmenter seg = new AiSegmenter(model, threads)) {
            int S = seg.inputSize();
            FloatBuffer in = seg.inputBuffer();
            readInto(new File(dir, IN), in, 3 * S * S);
            FloatBuffer o1 = seg.run(in);
            if (o1 == null) throw new IllegalStateException("cancelado");
            if (mirror && w > 1) {
                flipCols(in, 3, S, padX, w);
                FloatBuffer o2 = seg.run(in);
                if (o2 == null) throw new IllegalStateException("cancelado");
                flipCols(o2, 1, S, padX, w);
                for (int i = 0; i < S * S; i++) o1.put(i, (o1.get(i) + o2.get(i)) * 0.5f);
            }
            o1.rewind();
            writeFloats(new File(dir, OUT), o1);
        }
    }

    static void readInto(File f, FloatBuffer dst, int n) throws IOException {
        FloatBuffer tmp = readFloats(f, n, null);
        dst.clear();
        dst.put(tmp);
        dst.rewind();
    }

    /**
     * v8.38: cuanto DUDO la IA dentro de lo que vio como personaje (celdas entre 40 y 215 de 255,
     * contra las de 40 o mas). Medido en las imagenes de prueba: 0,02-0,03 en las que salen bien y
     * 0,056-0,087 en las que dejan restos (barras, edificio, JPEG malo). Mas de 0,05 = avisar.
     */
    public static float doubt(byte[] raw) {
        long uns = 0, any = 0;
        for (byte b : raw) {
            int v = b & 0xFF;
            if (v < 40) continue;
            any++;
            if (v < 215) uns++;
        }
        return any == 0 ? 0f : uns / (float) any;
    }

    public static final float DOUBT_WARN = 0.05f;
    /**
     * Con espejo (imagenes a color) el promedio de dos miradas deja mas valores intermedios:
     * medido 0,022-0,045 en las que salen bien y 0,068-0,237 en las que dejan restos.
     */
    public static final float DOUBT_WARN_MIRROR = 0.06f;
}
