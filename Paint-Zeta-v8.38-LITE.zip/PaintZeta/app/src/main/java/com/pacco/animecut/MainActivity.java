package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.core.ProjectStore;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.Thumbs;
import com.pacco.animecut.view.CanvasView;
import com.pacco.animecut.view.ColorPickerView;
import com.pacco.animecut.view.SelDemoView;
import com.pacco.animecut.view.ReferenceImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Pantalla principal. Funciona como Ibis: capas de verdad, capa de seleccion,
 * herramientas en un panel chico abajo a la izquierda.
 */
public class MainActivity extends AppCompatActivity implements CanvasView.Callback {

    public static final String EXTRA_PROJECT = "obra";

    private static final int[] PALETTE = {
            0xFF000000, 0xFF444444, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF, 0xFF7A4A2B,
            0xFFE05A5A, 0xFFFF7A45, 0xFFFFB03A, 0xFFFFE05C, 0xFFB5E05A, 0xFF4FC66B,
            0xFF3DD6C0, 0xFF4DA3FF, 0xFF3D6BFF, 0xFF7B5CFF, 0xFFB558FF, 0xFFFF6FC3,
            0xFFFFE0C4, 0xFFF5C9A6, 0xFFD9A377, 0xFF9C6B4A, 0xFF2B2B3A, 0xFF1B3358
    };

    private CanvasView canvas;
    private TextView sliderLabel;
    private SeekBar slider;
    // La fila inferior es Opacidad en Brocha y Fortaleza en Especial.
    // Ambos valores se mantienen independientes al cambiar de herramienta.
    private int previousControlMode = -100;

    private ActivityResultLauncher<String> openImage;
    private ActivityResultLauncher<String> addImage;
    private ActivityResultLauncher<String> createZip;
    private ActivityResultLauncher<String> createPng;
    private ActivityResultLauncher<Uri> pickFolder;
    private ActivityResultLauncher<String> createProject;
    private ActivityResultLauncher<String[]> openProject;
    private ActivityResultLauncher<String[]> pickColorRef;

    private interface ColorPickTarget {
        void onColor(int color);
    }

    private String projectId;
    private String lastError;
    private int lastExportCount;
    private int outW, outH;
    private int edgeClean = 2;
    private boolean saving = false;
    private volatile boolean recoveredBackup = false;
    private boolean destroyed = false;
    private boolean showAdvanced = false;
    private Layer pendingLayerExport;
    private ProjectIO.Loaded loaded;
    private int[] tintNext;
    private Runnable hideDemo;
    private Bitmap colorRefBitmap;
    private ColorPickTarget pendingColorRefTarget;
    private PopupWindow colorRefWindow;
    private ReferenceImageView colorRefView;
    private int colorRefX = 18, colorRefY = 90;
    private int colorRefW = 330, colorRefH = 390;
    private final android.os.Handler previewHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        android.content.SharedPreferences refPrefs = getSharedPreferences("pz", MODE_PRIVATE);
        colorRefX = refPrefs.getInt("ref_x", 18);
        colorRefY = refPrefs.getInt("ref_y", 90);
        colorRefW = refPrefs.getInt("ref_w", 330);
        colorRefH = refPrefs.getInt("ref_h", 390);
        canvas = findViewById(R.id.canvas);
        sliderLabel = findViewById(R.id.sliderLabel);
        slider = findViewById(R.id.slider);
        canvas.setCallback(this);

        openImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) loadImage(uri);
                        else if (canvas.getProject() == null) finish();
                    }
                });
        addImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) addImageLayer(uri);
                    }
                });
        createZip = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/zip"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportZip(uri);
                    }
                });
        pickFolder = registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportFolder(uri);
                    }
                });
        createPng = registerForActivityResult(new ActivityResultContracts.CreateDocument("image/png"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri == null) { pendingFlatExport = false; return; }
                        if (pendingFlatExport) { pendingFlatExport = false; doExportFlat(uri); }
                        else doExportLayer(uri);
                    }
                });
        createProject = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) saveProjectTo(uri);
                    }
                });
        openProject = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) openProjectFrom(uri);
                    }
                });

        pickColorRef = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri == null) {
                            pendingColorRefTarget = null;
                            return;
                        }
                        Bitmap bmp = decodeReference(uri);
                        if (bmp == null) return;
                        if (colorRefBitmap != null && colorRefBitmap != bmp && !colorRefBitmap.isRecycled()) {
                            colorRefBitmap.recycle();
                        }
                        colorRefBitmap = bmp;
                        toast("Referencia de color cargada");
                        // v8.26: si se eligio guardarla con la obra, se guarda una copia reducida
                        if (keepRefInProject() && canvas.getProject() != null) {
                            canvas.getProject().refImagePng = compactReferencePng(bmp);
                            markDirty();
                        }
                        if (pendingColorRefTarget != null) {
                            showReferenceColorPanel(pendingColorRefTarget);
                            pendingColorRefTarget = null;
                        }
                    }
                });

        click(R.id.btnUndo, new Runnable() {
            public void run() {
                canvas.doUndo();
                updateUi();
            }
        });
        click(R.id.btnRedo, new Runnable() {
            public void run() {
                canvas.doRedo();
                updateUi();
            }
        });
        click(R.id.btnSelMenu, new Runnable() {
            public void run() {
                selectionMenu();
            }
        });
        click(R.id.btnMenu, new Runnable() {
            public void run() {
                mainMenu();
            }
        });
        click(R.id.btnTools, new Runnable() {
            public void run() {
                toolGrid();
            }
        });
        click(R.id.btnSize, new Runnable() {
            public void run() {
                brushPresets();
            }
        });
        click(R.id.btnColor, new Runnable() {
            public void run() {
                colorDialog();
            }
        });
        click(R.id.btnLayers, new Runnable() {
            public void run() {
                toggleLayersPanel();
            }
        });
        click(R.id.btnLayersClose, new Runnable() {
            public void run() {
                closeLayers();
            }
        });
        click(R.id.btnExport, new Runnable() {
            public void run() {
                exportDialog();
            }
        });
        click(R.id.btnAddMode, new Runnable() {
            public void run() {
                canvas.setSubtract(false);
                updateUi();
            }
        });
        click(R.id.btnSubMode, new Runnable() {
            public void run() {
                canvas.setSubtract(true);
                updateUi();
            }
        });
        click(R.id.btnSmart, new Runnable() {
            public void run() {
                canvas.setSmart(!canvas.isSmart());
                canvas.showHud(canvas.isSmart() ? "Fino: SI (se queda en el color que tocas)" : "Fino: NO");
                updateUi();
            }
        });
        click(R.id.btnLineart, new Runnable() {
            public void run() {
                lineArtDialog();
            }
        });
        click(R.id.btnSizeMinus, new Runnable() {
            public void run() {
                slider.setProgress(Math.max(0, slider.getProgress() - 1));
            }
        });
        click(R.id.btnSizePlus, new Runnable() {
            public void run() {
                slider.setProgress(Math.min(slider.getMax(), slider.getProgress() + 1));
            }
        });
        final SeekBar op = findViewById(R.id.opacity);
        click(R.id.btnOpMinus, new Runnable() {
            public void run() {
                if (bgFeatherSlider()) {
                    op.setProgress(Math.max(0, op.getProgress() - 25));
                    return;
                }
                op.setProgress(Math.max(2, op.getProgress() - 5));
            }
        });
        click(R.id.btnOpPlus, new Runnable() {
            public void run() {
                if (bgFeatherSlider()) {
                    op.setProgress(Math.min(100, op.getProgress() + 25));
                    canvas.featherWholeLayer();
                    return;
                }
                op.setProgress(Math.min(100, op.getProgress() + 5));
            }
        });
        op.setOnSeekBarChangeListener(new SimpleSeek() {
            private float featherAtTouch;

            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (canvas.getMode() == CanvasView.MODE_BGERASE && canvas.getBgSub() == CanvasView.BG_SUB_ERASER) {
                    // v8.32: con el Borrador manual esta barra es su FUERZA
                    v = Math.max(2, v);
                    canvas.setBgEraserStrength(v / 100f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText("Fuerza " + v + "%");
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_er_strength", v).apply();
                } else if (canvas.getMode() == CanvasView.MODE_BGERASE) {
                    // v8.30: en Borrar fondo esta barra es la SUAVIDAD del borde (0 a 4 px)
                    canvas.setBgFeather(v / 25f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText(featherLabel(v));
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_feather", v).apply();
                } else if (canvas.getMode() == CanvasView.MODE_LIQUIFY) {
                    v = Math.max(5, v);
                    canvas.setEffectStrength(v / 100f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText("Fuerza " + v + "%");
                } else {
                    v = Math.max(2, v);
                    canvas.setBrushOpacity(v / 100f);
                    ((TextView) findViewById(R.id.opacityLabel)).setText(String.valueOf(v));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                featherAtTouch = canvas.getBgFeather();
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                // mas suave: se aplica tambien a lo que ya estaba recortado (se deshace con un toque)
                if (bgFeatherSlider() && canvas.getBgFeather() > featherAtTouch + 0.05f)
                    canvas.featherWholeLayer();
            }
        });
        slider.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                applySlider(v);
            }
        });
        installTooltips();

        canvas.setBrushSize(20f);
        canvas.setSmoothZoom(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("smooth_zoom", true));
        canvas.setRotateEnabled(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("rotate_view", true));
        {
            // v8.29: Borrar fondo nuevo (simple). Una vez se vuelven los ajustes a los de fabrica:
            // una dilatacion o tolerancia cambiadas a escondidas dejaban sobras que no se podian quitar.
            android.content.SharedPreferences sp0 = getSharedPreferences("pz", MODE_PRIVATE);
            if (!sp0.getBoolean("bg_reset_v829", false)) {
                sp0.edit().putBoolean("bg_reset_v829", true).putBoolean("bg_exp_on", false).putInt("bg_tol", 46)
                        .putInt("bg_soft", 42).putBoolean("bg_once", false).putInt("bg_limit", 0)
                        .putBoolean("bg_decontam", true).apply();
            }
            // v8.31: otra vez de fabrica (en el telefono estaban en 55/78 y el pincel cruzaba la linea);
            // el icono de Ajustes ya no esta en la barra
            // v8.32: motor nuevo; Disperso y Dilatacion ya no existen en Borrar fondo
            if (!sp0.getBoolean("bg_reset_v832", false)) {
                sp0.edit().putBoolean("bg_reset_v832", true).putInt("bg_limit", 0).putInt("bg_gap", 100).apply();
            }
            if (!sp0.getBoolean("bg_reset_v831", false)) {
                sp0.edit().putBoolean("bg_reset_v831", true).putBoolean("bg_exp_on", false).putInt("bg_tol", 46)
                        .putInt("bg_soft", 42).putBoolean("bg_once", false).putInt("bg_limit", 0)
                        .putBoolean("bg_decontam", true).apply();
            }
        }
        bgExpOn = getSharedPreferences("pz", MODE_PRIVATE).getBoolean("bg_exp_on", false);
        bgExpAmt = getSharedPreferences("pz", MODE_PRIVATE).getInt("bg_exp_amt", 2);
        canvas.setBgExpansion(bgExpOn ? bgExpAmt : 0f);
        {
            android.content.SharedPreferences bsp = getSharedPreferences("pz", MODE_PRIVATE);
            canvas.setBgTolerance(bsp.getInt("bg_tol", 46));
            canvas.setBgSoftness(bsp.getInt("bg_soft", 42));
            canvas.setBgDecontam(bsp.getBoolean("bg_decontam", true));
            canvas.setBgOnce(bsp.getBoolean("bg_once", false));
            // v8.32: el Borrador manual vuelve a la barra de Borrar fondo (con su propia fuerza y dureza)
            canvas.setBgSub(bsp.getInt("bg_sub", CanvasView.BG_SUB_TAP));
            canvas.setBgEraserStrength(bsp.getInt("bg_er_strength", 100) / 100f);
            canvas.setBgEraserHard(bsp.getInt("bg_er_hard", 85) / 100f);
            canvas.setBgGapScale(bsp.getInt("bg_gap", 100) / 100f);
            canvas.setSuggestMultiply(bsp.getBoolean("suggest_multiply", true));
            canvas.setBgLimit(bsp.getInt("bg_limit", 0));
            canvas.setBgFeather(bsp.getInt("bg_feather", 0) / 25f);
        }
        loadFillPrefs();
        loadPuppetPrefs();
        loadMangaPrefs();
        {
            // v8.27: el pincel elegido Y su dureza se guardan. Antes la dureza no se guardaba:
            // al volver a abrir la app quedaba en 0,7 (borde borroso) aunque el pincel fuera otro.
            android.content.SharedPreferences bsp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean firstTime = !bsp.contains("brush_preset4") && !bsp.contains("brush_preset3");
            int bi;
            if (bsp.contains("brush_preset4")) bi = bsp.getInt("brush_preset4", 0);
            else bi = com.pacco.animecut.core.BrushPreset.migrateV826(bsp.getInt("brush_preset3", 0));
            if (bi < 0 || bi >= com.pacco.animecut.core.BrushPreset.PRESETS.length) bi = 0;
            com.pacco.animecut.core.BrushPreset bp = com.pacco.animecut.core.BrushPreset.PRESETS[bi];
            applyBrushPreset(bi, false);
            canvas.setHardness(bsp.getFloat("brush_hardness_v827", bp.hardness));
            if (firstTime) canvas.setBrushSize(bp.size);
            bsp.edit().putInt("brush_preset4", bi).putFloat("brush_hardness_v827", canvas.getHardness()).apply();
        }
        canvas.setFlatPaint(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("flat_paint", true));
        canvas.setLineStop(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("line_stop", false));
        canvas.setAutoLines(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("auto_lines", true));
        canvas.setToLine(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("to_line", true));
        canvas.setFillUnpainted(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("fill_unpainted", false));
        // boton de ajustes de la varita, junto a los de la barra de seleccion
        ImageButton gear = new ImageButton(this);
        gear.setImageResource(R.drawable.ic_menu);
        gear.setBackgroundResource(R.drawable.bg_tool);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER);
        gear.setPadding(dp(9), dp(9), dp(9), dp(9));
        gear.setContentDescription("Ajustes de la varita");
        gear.setId(View.generateViewId());
        wandGear = gear;
        ((ViewGroup) findViewById(R.id.btnLineart).getParent()).addView(gear,
                new LinearLayout.LayoutParams(dp(44), dp(40)));
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wandDialog();
            }
        });
        Task.setErrorListener(new Task.ErrorListener() {
            @Override
            public void onError(Throwable t) {
                if (destroyed) return;
                if (t instanceof OutOfMemoryError) {
                    toast("No alcanzo la memoria para eso. Combina o borra alguna capa y prueba otra vez.");
                }
            }
        });
        syncSlider();
        updateUi();
        measureBars();

        saveHandler.postDelayed(savePeriodic, 30000);
        projectId = getIntent().getStringExtra(EXTRA_PROJECT);
        if (projectId != null) {
            // la obra aparece de una vez ya ajustada, sin salto de zoom
            canvas.setAlpha(0f);
            recoverFrom(ProjectStore.fileFor(this, projectId));
        }
        else openImage.launch("image/*");
    }

    @Override
    protected void onPause() {
        super.onPause();
        autosave(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (dirty) autosave(false);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        closeGrayPop();
        saveHandler.removeCallbacksAndMessages(null);
        previewHandler.removeCallbacksAndMessages(null);
        opHandler.removeCallbacksAndMessages(null);
        Task.setErrorListener(null);
        try { thumbPool.shutdownNow(); } catch (Throwable ignored) {}
        for (Bitmap b : new ArrayList<Bitmap>(thumbCache.values()))
            if (b != null && !b.isRecycled()) b.recycle();
        thumbCache.clear();
        if (colorRefWindow != null) {
            try { colorRefWindow.dismiss(); } catch (Throwable ignored) {}
            colorRefWindow = null; colorRefView = null;
        }
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) {
            colorRefBitmap.recycle();
            colorRefBitmap = null;
        }
        rowHolders.clear();
        if (canvas != null) {
            canvas.setCallback(null);
            canvas.releaseUiResources();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // Guardado automatico: poco despues de cada cambio y cada 30 segundos.
    // Asi, si la app se cierra de golpe, se pierde muy poco.
    // ------------------------------------------------------------------

    private boolean dirty = false, saveAgain = false;
    private final android.os.Handler saveHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable saveSoon = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            if (dirty) autosave(false);
        }
    };
    private final Runnable savePeriodic = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            if (dirty) autosave(false);
            if (!destroyed) saveHandler.postDelayed(this, 30000);
        }
    };

    private void markDirty() {
        dirty = true;
        saveHandler.removeCallbacks(saveSoon);
        saveHandler.postDelayed(saveSoon, 4000);
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    private void installTooltips() {
        int[] ids = {R.id.btnUndo, R.id.btnRedo, R.id.btnSelMenu, R.id.btnMenu, R.id.btnTools, R.id.btnSize,
                R.id.btnColor, R.id.btnLayers, R.id.btnExport, R.id.btnAddMode, R.id.btnSubMode, R.id.btnSmart,
                R.id.btnLineart};
        String[] names = {"Deshacer (o toca con dos dedos)", "Rehacer (o toca con tres dedos)",
                "Seleccion: acciones con lo azul", "Mas opciones", "Herramientas", "Tipo de pincel",
                "Color", "Capas", "Exportar", "Agregar a lo azul", "Quitar de lo azul",
                "Fino: se queda en el color que tocas", "Line art: la linea hace de pared"};
        for (int i = 0; i < ids.length; i++) {
            final String n = names[i];
            findViewById(ids[i]).setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    toast(n);
                    return true;
                }
            });
        }
    }

    // ==================================================================
    // Abrir, agregar imagen, guardar
    // ==================================================================

    /**
     * Ya no hay un limite artificial de 4096 px. El tamano de apertura se decide
     * con la memoria real disponible del dispositivo para no cerrar Android.
     */
    private long safeOpenPixels() {
        long heap = Runtime.getRuntime().maxMemory();
        // Abrir una obra necesita temporalmente Bitmap + int[] de la capa + buffers.
        // Aproximar 14 bytes/pixel deja margen para la interfaz y el deshacer.
        return Math.max(8_000_000L, heap / 14L);
    }

    private Bitmap decode(Uri uri) {
        try {
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            InputStream is0 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is0, null, b);
            if (is0 != null) is0.close();
            int ow = b.outWidth, oh = b.outHeight;
            if (ow <= 0 || oh <= 0) {
                toast("No se pudo leer el tamano de la imagen");
                return null;
            }

            long safePixels = safeOpenPixels();
            int sample = 1;
            while ((long) Math.max(1, ow / sample) * Math.max(1, oh / sample) > safePixels * 2L) {
                sample *= 2;
            }

            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            if (bmp == null) {
                toast("No se pudo abrir la imagen");
                return null;
            }

            long got = (long) bmp.getWidth() * bmp.getHeight();
            if (got > safePixels) {
                float f = (float) Math.sqrt(safePixels / (double) got);
                int tw = Math.max(1, Math.round(bmp.getWidth() * f));
                int th = Math.max(1, Math.round(bmp.getHeight() * f));
                Bitmap sc = Bitmap.createScaledBitmap(bmp, tw, th, true);
                if (sc != bmp) bmp.recycle();
                bmp = sc;
            }
            if (bmp.getWidth() != ow || bmp.getHeight() != oh) {
                toast("La imagen " + ow + "x" + oh + " se ajusto a " + bmp.getWidth() + "x"
                        + bmp.getHeight() + " segun la memoria disponible del telefono");
            }
            return bmp;
        } catch (OutOfMemoryError e) {
            toast("Android se quedo sin memoria al abrir esa imagen");
        } catch (Exception e) {
            toast("No se pudo abrir: " + e.getMessage());
        }
        return null;
    }

    private void loadImage(Uri uri) {
        Bitmap bmp = decode(uri);
        if (bmp == null) return;
        projectId = null;
        canvas.setProject(new Project(bmp));
        bmp.recycle();
        afterProjectLoaded();
        markDirty();
        toast("Imagen abierta en la capa \"imagen\"");
        guideIfFirstTime();
    }

    private void addImageLayer(Uri uri) {
        if (!needProject()) return;
        Bitmap bmp = decode(uri);
        if (bmp == null) return;
        canvas.addImageLayer(bmp);
        bmp.recycle();
        updateUi();
    }

    private void afterProjectLoaded() {
        closeTools();
        closeLayers();
        // Abrir con Mano: nunca arrancar en una herramienta retirada del menu.
        canvas.setMode(CanvasView.MODE_PAN);
        canvas.setSubtract(false);
        syncSlider();
        updateUi();
    }

    private void applyLoaded() {
        if (lastError != null) {
            canvas.setAlpha(1f);
            toast("No se pudo abrir: " + lastError);
            return;
        }
        if (loaded == null || loaded.project == null) {
            canvas.setAlpha(1f);
            return;
        }
        canvas.setProject(loaded.project);
        canvas.setColor(loaded.color);
        loaded = null;
        restoreProjectReference();
        afterProjectLoaded();
        revealCanvas();
        if (recoveredBackup) {
            recoveredBackup = false;
            toast("Recuperamos la copia de seguridad de tu obra");
            markDirty();
        }
    }

    private boolean barsMeasured, pendingReveal;

    /** Muestra el lienzo con un fundido corto, cuando ya esta en su lugar. */
    private void revealCanvas() {
        if (!barsMeasured) {
            pendingReveal = true;
            return;
        }
        pendingReveal = false;
        canvas.post(new Runnable() {
            @Override
            public void run() {
                if (!canvas.isFitted()) canvas.fit();
                canvas.animate().alpha(1f).setDuration(140).start();
            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.pz_stay, R.anim.pz_fade_out);
    }

    /** Guarda sola en la galeria al salir y al hacer cambios de capas. */
    private void autosave(final boolean notify) {
        if (canvas != null && canvas.isTransformActive()) {
            saveAgain = true;
            return;
        }
        final Project p = canvas.getProject();
        if (p == null) return;
        if (saving) {
            saveAgain = true;
            return;
        }
        saving = true;
        dirty = false;
        if (projectId == null) projectId = ProjectStore.newId();
        final String id = projectId;
        final int color = canvas.getColor();
        final File dest = ProjectStore.fileFor(this, id);
        final File tmp = new File(dest.getAbsolutePath() + ".tmp");
        final File bak = new File(dest.getAbsolutePath() + ".bak");
        if (notify) toast("Guardando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    // Primero crear y cerrar la revision nueva. Nunca borrar el
                    // proyecto valido antes de tener el reemplazo listo.
                    try (FileOutputStream fo = new FileOutputStream(tmp)) {
                        ProjectIO.save(fo, p, color);
                    }
                    if (!tmp.exists() || tmp.length() < 60)
                        throw new java.io.IOException("Proyecto temporal incompleto");
                    if (dest.exists()) {
                        // Conservar la ultima revision valida por si hay un corte
                        // entre mover el viejo y colocar el nuevo.
                        if (bak.exists() && !bak.delete())
                            throw new java.io.IOException("No se pudo renovar el respaldo");
                        if (!dest.renameTo(bak))
                            throw new java.io.IOException("No se pudo respaldar el proyecto");
                    }
                    if (!tmp.renameTo(dest)) {
                        if (!dest.exists() && bak.exists()) bak.renameTo(dest);
                        throw new java.io.IOException("No se pudo confirmar el guardado");
                    }
                    Bitmap th = p.previewBitmap(320);
                    ProjectStore.saveThumb(MainActivity.this, id, th);
                    th.recycle();
                    lastError = null;
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                saving = false;
                if (lastError != null) dirty = true;
                if (notify) toast(lastError != null ? "Error al guardar: " + lastError : "Guardado en la galeria");
                if (saveAgain) {
                    saveAgain = false;
                    if (dirty) autosave(false);
                }
            }
        });
    }

    // ==================================================================
    // Herramientas
    // ==================================================================

    // Menú de herramientas práctico para extraer personajes y animar.
    // Los modos antiguos siguen en CanvasView para proyectos previos.
    private static final String[] GROUPS = {"EXTRAER PERSONAJES", "PINTAR Y RETOCAR", "MOVER Y ANIMAR"};
    private static final int[][] TOOLS = {
            {0, CanvasView.MODE_MARKER, 0, 0}, {0, CanvasView.MODE_BGERASE, 0, 0},
            {0, CanvasView.MODE_LASSO, 0, 0},
            {1, CanvasView.MODE_PAINT, 0, 0}, {1, CanvasView.MODE_ERASER, 0, 0},
            {1, CanvasView.MODE_BUCKET, 0, 0}, {1, CanvasView.MODE_SMUDGE, 0, 0},
            {1, CanvasView.MODE_BLUR, 0, 0}, {1, CanvasView.MODE_LIQUIFY, 0, 0},
            // Curva y Polilínea no dependen de selección azul y son útiles para dibujar partes.
            {1, CanvasView.MODE_CURVE, 0, 0}, {1, CanvasView.MODE_POLY, 0, 0},
            {2, CanvasView.MODE_PAN, 0, 0}, {2, CanvasView.MODE_MOVE, 0, 0},
            {2, CanvasView.MODE_TRANSFORM, 0, 0}, {2, CanvasView.MODE_PUPPET, 0, 0}
    };

    private String[] toolInfo(int mode, int sub) {
        switch (mode) {
            case CanvasView.MODE_BGERASE: return new String[]{"Borrar fondo",
                    "Balde: toca el fondo. Pincel: pasa junto a la linea.",
                    "Borrador: borra todo. Restaurar: lo devuelve.",
                    "Escoba: limpia puntos."};
            case CanvasView.MODE_WAND: return new String[]{"Varita",
                    "Marca en azul una zona del mismo color.",
                    "Toca una zona. Abajo, el + agrega y el - quita.",
                    "Despues: en el cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_BRUSH: return sub == 2 ? new String[]{"Borrar azul",
                    "Quita parte de lo marcado en azul. No borra el dibujo.",
                    "Pinta sobre lo azul que sobra.", "Sirve para corregir lo que marco la Varita."}
                    : new String[]{"Marcar azul", "Marca a mano lo que quieres sacar.",
                    "Pinta encima. Lo azul es lo que vas a copiar o borrar.",
                    "Despues: cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_ERASER: return new String[]{"Goma",
                    "Borra el dibujo de la capa elegida, como la goma de Ibis.",
                    "Elige la capa en Capas y borra. Si hay algo azul, solo borra dentro.",
                    "Si en Capas esta elegida la capa de seleccion, borra lo azul."};
            case CanvasView.MODE_MARKER: return new String[]{"Separar",
                    "Saca partes (pelo, brazo, ojo) a capas propias para animarlas. No pinta.",
                    "Raya cada parte con un color. El color que ves es solo vista previa.",
                    "Check: cada parte a su capa, con sus colores reales. Una sola raya: solo lo encerrado por la linea."};
            case CanvasView.MODE_SCISSORS: return new String[]{"Tijeras", "Marca siguiendo el contorno.",
                    "Arrastra cerca de la linea y se pega sola. Vuelve al punto verde para cerrar.",
                    "Queda azul."};
            case CanvasView.MODE_MAGNET: return new String[]{"Magnetico", "Como las tijeras, de un solo trazo.",
                    "Arrastra por el contorno sin soltar. Al soltar se cierra.", "Queda azul."};
            case CanvasView.MODE_LASSO: return new String[]{"Lazo", "Copia una parte en otra capa.",
                    "Rodea la parte; elige nombre y solapamiento para animación.",
                    "Crea la capa sin borrar el original."};
            case CanvasView.MODE_BUCKET: return new String[]{"Relleno",
                    "Pinta de un color toda una zona de golpe.",
                    "Toca la zona. Abajo: tolerancia (gota), dilatacion (cuadrito +, y sus tres puntos), "
                            + "mirar todas las capas o solo esta, hasta la linea y \"→ capa\" (el DESTINO).",
                    "El destino se ve en la barra: Pintar en capa actual (de fabrica) o Capa de color automatica. "
                            + "Ahi tambien: Por lineas (manga) y Vista previa."};
            case CanvasView.MODE_PAINT: return new String[]{"Brocha",
                    "Pinta con el color de abajo, con el pincel que elijas.",
                    "Pasa el dedo. Abajo: el escudo prende \"Proteger contornos\": "
                            + "pinta solo la zona donde empiezas y no tapa la tinta. \"→ capa\" muestra donde pinta.",
                    "Pinceles: Color plano (borde duro, de fabrica) o Brocha suave. Si hay algo azul, solo pinta dentro."};
            case CanvasView.MODE_CURVE: return new String[]{"Curva",
                    "Dibuja una linea curva suave por los puntos que pones.",
                    "Toca para poner puntos. Arrastra un punto para moverlo. Deshacer quita el ultimo.",
                    "Check: se dibuja con el color y el grosor de abajo. Llenar: pinta por dentro."};
            case CanvasView.MODE_POLY: return new String[]{"Polilinea",
                    "Lineas rectas de punto a punto: cuadros, bordes, vinetas.",
                    "Toca para poner puntos. Arrastra un punto para moverlo. Deshacer quita el ultimo.",
                    "Check: se dibuja con el color y el grosor de abajo. Llenar: pinta por dentro."};
            case CanvasView.MODE_PICKER: return new String[]{"Gotero", "Toma un color de la imagen.",
                    "Toca un color. Tambien manteniendo pulsado con cualquier herramienta.", "Despues: Brocha o Relleno."};
            case CanvasView.MODE_ZONE: return new String[]{"Zona",
                    "Rellena lo azul con el color plano que tiene alrededor.",
                    "Marca en azul lo que hay que rehacer (donde estaba el ojo). Toca dentro de lo azul.",
                    "Hazlo en la capa de atras, la que quedo con el hueco."};
            case CanvasView.MODE_CLONE: return new String[]{"Clonar", "Copia un trozo de la capa a otro lugar.",
                    "Toca de donde copiar (cruz roja). Despues pinta. Tiene espejo y giro abajo.",
                    "Para tapar huecos copiando algo parecido."};
            case CanvasView.MODE_LINE: return new String[]{"Linea",
                    "Continua una linea cortada dentro de lo azul.",
                    "Traza por donde seguia la linea. Se engancha a la linea real.", "Despues: Zona."};
            case CanvasView.MODE_PATCH: return new String[]{"Copiar zona",
                    "Rellena lo azul copiando sombras o brillos de otro lado.",
                    "Pinta en verde de donde copiar y toca el check.", "Para cuando Zona queda muy plano."};
            case CanvasView.MODE_HEAL: return new String[]{"Corrector",
                    "Copia de un lado a otro y funde el color para que no se note.",
                    "Toca de donde copiar. Despues pinta donde quieres.", "Para disimular cortes."};
            case CanvasView.MODE_TONE: return new String[]{"Trama",
                    "Continua la trama de puntos del manga dentro de lo azul.",
                    "Toca la trama que esta al lado de lo azul.", "Solo para manga."};
            case CanvasView.MODE_SMUDGE: return new String[]{"Difuminar",
                    "Arrastra y mezcla los pixeles siguiendo el dedo.",
                    "Pasa el pincel sobre pelo, sombras o bordes. Abajo puedes ajustar la fuerza.",
                    "Trabaja solo en la zona del pincel para mantener fluidez."};
            case CanvasView.MODE_BLUR: return new String[]{"Borrosidad",
                    "Desenfoca solo donde pintas.",
                    "Pasa varias veces para aumentar el desenfoque. Ajusta tamano y fuerza.",
                    "No desenfoca toda la capa."};
            case CanvasView.MODE_LIQUIFY: return new String[]{"Especial",
                    "Licua la imagen con cinco modos.",
                    "Arrastrar, Contraer, Expandir, Suavizar y Restaurar. Elige el modo abajo.",
                    "Restaurar vuelve hacia el estado que tenia la capa al entrar a Especial."};
            case CanvasView.MODE_TRANSFORM: return new String[]{"Transformar",
                    "Mueve, escala, gira, cambia perspectiva o deforma con malla o puntos.",
                    "Mover: arrastra; dos dedos escalan y giran. Perspectiva/Malla/Puntos: arrastra sus puntos.",
                    "Usa check para aplicar o X para cancelar. Para enderezar un personaje usa Marioneta."};
            case CanvasView.MODE_PUPPET: return new String[]{"Marioneta",
                    "Endereza o cambia la postura con puntos, como el Puppet Warp de Photoshop.",
                    "Toca el dibujo para poner puntos. Fija los pies (Fijar) y arrastra cadera, hombros y cabeza. "
                            + "Por partes: un punto en la corbata mueve solo la corbata. El anillo del punto lo gira.",
                    "Check aplica, X cancela. Deshacer/Rehacer de arriba deshacen puntos mientras trabajas. "
                            + "Lo que estaba tapado no se inventa: retocalo despues con Clonar o Copiar zona."};
            case CanvasView.MODE_MOVE: return new String[]{"Mover",
                    "Mueve la capa entera, o solo lo azul si hay algo marcado.",
                    "Arrastra.", ""};
            default: return new String[]{"Mano", "Mueve y acerca la imagen sin pintar.",
                    "Arrastra con un dedo. Con dos dedos haces zoom en cualquier herramienta.", ""};
        }
    }

    private void toolGrid() {
        final View panel = findViewById(R.id.toolPanel);
        final View scrim = findViewById(R.id.toolScrim);
        if (panel.getVisibility() == View.VISIBLE) {
            closeTools();
            return;
        }
        closeLayers();
        LinearLayout box = findViewById(R.id.toolPanelContent);
        box.removeAllViews();
        TextView tip = new TextView(this);
        tip.setText("Manten pulsada una herramienta para ver que hace");
        tip.setTextColor(0xFF9FC6FF);
        tip.setTextSize(10f);
        tip.setPadding(dp(4), dp(2), dp(4), dp(2));
        box.addView(tip);
        int cols = 4, lastGroup = -1, inRow = 0;
        LinearLayout row = null;
        for (int[] tdef : TOOLS) {
            final int group = tdef[0], mode = tdef[1], sub = tdef[2];
            if (group != lastGroup) {
                if (row != null) fillRow(row, inRow, cols);
                TextView h = new TextView(this);
                h.setText(GROUPS[group]);
                h.setTextColor(0xFF8A8A92);
                h.setTextSize(10f);
                h.setPadding(dp(4), dp(8), 0, dp(2));
                box.addView(h);
                row = null;
                inRow = 0;
                lastGroup = group;
            }
            if (row == null || inRow == cols) {
                if (row != null) fillRow(row, inRow, cols);
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row);
                inRow = 0;
            }
            boolean active = canvas.getMode() == mode && (sub == 0 || (sub == 2) == canvas.isSubtract());
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(2), dp(6), dp(2), dp(5));
            cell.setBackgroundResource(active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(1), dp(1), dp(1), dp(1));
            cell.setLayoutParams(clp);
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
            img.setImageResource(sub == 2 ? R.drawable.ic_remove : toolIcon(mode));
            cell.addView(img);
            TextView t = new TextView(this);
            t.setText(toolInfo(mode, sub)[0]);
            t.setTextColor(0xFFE0E0E0);
            t.setTextSize(9.5f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setMaxLines(1);
            t.setPadding(0, dp(3), 0, 0);
            cell.addView(t);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closeTools();
                    if (sub == 1) canvas.setSubtract(false);
                    if (sub == 2) canvas.setSubtract(true);
                    selectTool(mode);
                    // Sin tutorial emergente al cambiar de herramienta.
                    // La explicación sigue disponible al mantener pulsado.
                }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showToolCard(mode, sub);
                    return true;
                }
            });
            row.addView(cell);
            inRow++;
        }
        if (row != null) fillRow(row, inRow, cols);

        View bottom = findViewById(R.id.bottomPanel);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) panel.getLayoutParams();
        lp.bottomMargin = bottom.getHeight() + dp(4);
        panel.setLayoutParams(lp);
        final int limit = canvas.getHeight() - bottom.getHeight() - findViewById(R.id.topBar).getHeight() - dp(16);
        scrim.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        panel.post(new Runnable() {
            @Override
            public void run() {
                if (limit > 0 && panel.getHeight() > limit) {
                    FrameLayout.LayoutParams l2 = (FrameLayout.LayoutParams) panel.getLayoutParams();
                    l2.height = limit;
                    panel.setLayoutParams(l2);
                }
            }
        });
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeTools();
            }
        });
    }

    private void selectTool(int mode) {
        if (mode == CanvasView.MODE_LASSO) {
            canvas.setSubtract(false);
            if (canvas.getProject() != null && canvas.getProject().hasSelection())
                canvas.clearSelection(); // cada parte nueva comienza sin máscara anterior
        }
        canvas.setMode(mode);
        // Deformar arranca al elegirlo: la malla o los puntos aparecen enseguida.
        if (mode == CanvasView.MODE_PUPPET) canvas.setTransformType(canvas.getTransformType());
        if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) canvas.resetCloneSource();
        syncSlider();
        updateUi();
    }

    /** Opciones propias de cada herramienta, solo iconos. */
    private void buildOptBar(int mode) {
        LinearLayout bar = findViewById(R.id.optBar);
        bar.removeAllViews();
        bar.setVisibility(View.VISIBLE);
        if (mode != CanvasView.MODE_BGERASE || !canvas.isBgGray()) closeGrayPop();
        if (mode == CanvasView.MODE_BGERASE) {
            // v8.30: Borrar fondo SIMPLE, solo iconos (mantener pulsado dice el nombre):
            // Toque · Pincel · Restaurar | Limpiar restos · Ver
            // La Goma de aqui se quito: era igual a la Goma de la caja de herramientas y se usaba
            // creyendo que respetaba la linea (captura 1 de v8.29). Para borrar todo: la Goma normal.
            final int sub = canvas.getBgSub();
            // v8.33: Recortar con IA (primero y resaltado). No reemplaza a las herramientas manuales.
            // v8.33: es un BOTON (abre el recorte con IA), no una herramienta: no queda marcado. Lo
            // marcado en azul es la herramienta manual elegida (Balde, Pincel, Borrador, Restaurar).
            // v8.36: primer toque = pinta encima del personaje (celeste); queda marcado mientras pintas.
            // Otro toque sin pintar = toda la imagen.
            ImageButton ai = iconButton(R.drawable.ic_ai, canvas.isAiMarking()
                    ? "Pinta el personaje. Toca otra vez: toda la imagen"
                    : "Recortar con IA: pinta encima del personaje que quieres", new Runnable() {
                public void run() { aiFlow().start(); }
            });
            if (canvas.isAiMarking()) ai.setBackgroundResource(R.drawable.bg_tool_on);
            bar.addView(ai);
            View sep = new View(this);
            sep.setBackgroundColor(0x55FFFFFF);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(1), dp(26));
            slp.setMargins(dp(4), 0, dp(4), 0);
            sep.setLayoutParams(slp);
            bar.addView(sep);
            // v8.32: Balde · Pincel protegido · Borrador manual · Restaurar | Escoba · Ver
            final int[] subIds = {CanvasView.BG_SUB_TAP, CanvasView.BG_SUB_BRUSH, CanvasView.BG_SUB_ERASER, CanvasView.BG_SUB_RESTORE};
            int[] subIcons = {R.drawable.ic_bucket, R.drawable.ic_bgerase, R.drawable.ic_eraser, R.drawable.ic_restore_brush};
            final String[] subNames = {"Balde: un toque borra el fondo", "Pincel protegido: no cruza la linea",
                    "Borrador: borra justo donde pasas", "Restaurar: devuelve lo borrado"};
            for (int k = 0; k < subIds.length; k++) {
                final int which = k;
                ImageButton b = iconButton(subIcons[k], subNames[k], new Runnable() {
                    public void run() {
                        canvas.setBgSub(subIds[which]);
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_sub", subIds[which]).apply();
                        canvas.showHud(subNames[which]);
                        updateUi();
                    }
                });
                b.setBackgroundResource(!canvas.isAiMarking() && sub == subIds[k] ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(b);
            }
            bar.addView(iconButton(R.drawable.ic_broom, "Escoba: limpia puntos y bordes sueltos", new Runnable() {
                public void run() { canvas.cleanBackgroundRemnants(); }
            }));
            bar.addView(iconButton(R.drawable.ic_eye, "Ver sobre cuadros, blanco, negro, gris o verde (no cambia el PNG)", new Runnable() {
                public void run() { cycleViewBg(); }
            }));
            // v8.37: B/N. Primer toque: el Balde y el Pincel miran en blanco y negro (fondos con
            // muchos colores). Con B/N prendido, otro toque abre sus ajustes y "Volver a color".
            final TextView bw = smallTextButton("B/N");
            bw.setBackgroundResource(canvas.isBgGray() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bw.setContentDescription("Blanco y negro: el Balde mira en gris (tu color no cambia)");
            bw.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!canvas.isBgGray()) {
                        canvas.setBgGrayView(loadGrayView());
                        canvas.setBgGray(true);
                        canvas.showHud("B/N: el Balde mira en gris · toca B/N para ajustar", 2600);
                        updateUi();
                    } else {
                        grayDialog();
                    }
                }
            });
            bw.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    canvas.showHud("Blanco y negro: solo para mirar; tu color no cambia");
                    return true;
                }
            });
            bar.addView(bw);
            // v8.31: sin icono de Ajustes (era confuso y no se notaba diferencia). Los ajustes de
            // fabrica son los que mejor funcionan; quien los quiera cambiar los tiene en Menu >
            // "Borrar fondo: ajustes avanzados".
        } else if (mode == CanvasView.MODE_BUCKET && canvas.isMangaMode()) {
            buildMangaBucketBar(bar);
        } else if ((mode == CanvasView.MODE_LASSO || mode == CanvasView.MODE_WAND) && canvas.isMangaMode()) {
            buildMangaSelectionBar(bar);
        } else if (mode == CanvasView.MODE_PICKER) {
            final int ps = canvas.getPickSource();
            TextView t = smallTextButton("Gotero: " + (ps == CanvasView.PICK_VISIBLE ? "Visible" : ps == CanvasView.PICK_LAYER ? "Capa actual" : "Automatico"));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { pickSourceDialog(); }
            });
            bar.addView(t);
            bar.addView(iconButton(R.drawable.ic_add, "Guardar el color actual en la paleta", new Runnable() {
                public void run() { saveSwatchDialog(canvas.getColor(), null); }
            }));
        } else if (mode == CanvasView.MODE_BUCKET) {
            if (canvas.hasFillPreview()) {
                // v8.27: vista previa del balde normal: Aceptar / Cancelar
                ImageButton okp = iconButton(R.drawable.ic_check, "Aceptar: pintar la vista previa", new Runnable() {
                    public void run() {
                        canvas.acceptFillPreview();
                        updateUi();
                    }
                });
                okp.setBackgroundResource(R.drawable.bg_save);
                bar.addView(okp);
                bar.addView(iconButton(R.drawable.ic_close, "Cancelar: no pintar nada", new Runnable() {
                    public void run() {
                        canvas.cancelFillPreview();
                        updateUi();
                    }
                }));
                bar.addView(destinationChip(true));
                return;
            }
            bar.addView(iconButton(R.drawable.ic_range, "Cuanto se parece el color", new Runnable() {
                public void run() {
                    fillToleranceDialog();
                }
            }));
            ImageButton fd = iconButton(R.drawable.ic_grow, "Dilatacion del relleno", new Runnable() {
                public void run() {
                    fillExpOn = !fillExpOn;
                    applyFillPrefs();
                    canvas.showHud(fillExpOn ? "Dilatacion prendida: " + signed(fillExpAmt) + " px" : "Dilatacion apagada");
                    updateUi();
                }
            });
            fd.setBackgroundResource(fillExpOn ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fd);
            bar.addView(dotsButton("Ajustar la dilatacion", new Runnable() {
                public void run() {
                    expansionDialog(true);
                }
            }));
            final boolean all = canvas.isFillAllLayers();
            ImageButton src = iconButton(all ? R.drawable.ic_layers : R.drawable.ic_image,
                    all ? "Mira todas las capas" : "Mira solo la capa elegida", new Runnable() {
                        public void run() {
                            canvas.setFillAllLayers(!canvas.isFillAllLayers());
                            applyFillPrefs();
                            canvas.showHud(canvas.isFillAllLayers()
                                    ? "Mira todas las capas: rellena debajo de la linea"
                                    : "Mira solo la capa elegida");
                            updateUi();
                        }
                    });
            src.setBackgroundResource(all ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(src);
            ImageButton ln = iconButton(R.drawable.ic_edge, "Hasta la linea", new Runnable() {
                public void run() {
                    canvas.setFillToLine(!canvas.isFillToLine());
                    applyFillPrefs();
                    canvas.showHud(canvas.isFillToLine() ? "Hasta la linea: SI" : "Hasta la linea: NO");
                    updateUi();
                }
            });
            ln.setBackgroundResource(canvas.isFillToLine() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(ln);
            bar.addView(iconButton(R.drawable.ic_ref_color, "Referencia de color: abrir otra imagen y tomar sus colores (no se exporta)", new Runnable() {
                public void run() { requestColorReference(paintColorTarget()); }
            }));
            // v8.27: el destino se VE en la barra y se elige en su panel (Pintar en capa actual /
            // Capa de color automatica, Por lineas, Vista previa). Antes un boton "capa aparte"
            // prendido de fabrica creaba Color_1 aunque el usuario hubiera creado su capa.
            bar.addView(destinationChip(true));
        } else if (mode == CanvasView.MODE_CURVE || mode == CanvasView.MODE_POLY) {
            final boolean curve = mode == CanvasView.MODE_CURVE;
            bar.addView(iconButton(curve ? R.drawable.ic_poly : R.drawable.ic_curve,
                    curve ? "Pasar a lineas rectas" : "Pasar a curva", new Runnable() {
                        public void run() {
                            canvas.setMode(curve ? CanvasView.MODE_POLY : CanvasView.MODE_CURVE);
                            canvas.showHud(curve ? "Polilinea: lineas rectas" : "Curva");
                            updateUi();
                        }
                    }));
            ImageButton fl = iconButton(R.drawable.ic_bucket, "Llenar por dentro", new Runnable() {
                public void run() {
                    canvas.setShapeFill(!canvas.isShapeFill());
                    canvas.showHud(canvas.isShapeFill() ? "Llenar: SI (necesita 3 puntos)" : "Llenar: NO");
                    updateUi();
                }
            });
            fl.setBackgroundResource(canvas.isShapeFill() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fl);
            bar.addView(iconButton(R.drawable.ic_remove, "Quitar el punto rojo", new Runnable() {
                public void run() {
                    canvas.shapeDeleteSelected();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todos los puntos", new Runnable() {
                public void run() {
                    canvas.shapeClear();
                }
            }));
            ImageButton ok = iconButton(R.drawable.ic_check, "Dibujar en la capa", new Runnable() {
                public void run() {
                    canvas.commitShape();
                    updateUi();
                }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
        } else if (mode == CanvasView.MODE_MARKER) {
            int lab = canvas.getMarkerLabel();
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            sw.setLayoutParams(lp);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(CanvasView.LABEL_COLORS[lab - 1]);
            g.setStroke(dp(2), 0xFFFFFFFF);
            sw.setBackground(g);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    labelPicker();
                }
            });
            bar.addView(sw);
            final int bgLab = CanvasView.LABEL_NAMES.length;
            final boolean onBg = lab == bgLab;
            ImageButton fondo = iconButton(R.drawable.ic_sub, onBg ? "Volver a marcar partes" : "Marcar fondo (gris)",
                    new Runnable() {
                        public void run() {
                            if (canvas.getMarkerLabel() == bgLab) {
                                canvas.setMarkerLabel(lastPartLabel);
                            } else {
                                lastPartLabel = canvas.getMarkerLabel();
                                canvas.setMarkerLabel(bgLab);
                            }
                            if (canvas.isSubtract()) canvas.setSubtract(false);
                            updateUi();
                        }
                    });
            fondo.setBackgroundResource(onBg ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fondo);
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar rayones", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todos los rayones", new Runnable() {
                public void run() {
                    canvas.clearMarkers();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_bgerase, "Quitar fondo: queda lo marcado con color", new Runnable() {
                public void run() {
                    canvas.removeBackgroundByMarks();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Separar las partes", new Runnable() {
                public void run() {
                    canvas.separateParts();
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else if (mode == CanvasView.MODE_LINE) {
            bar.addView(iconButton(R.drawable.ic_join, "Unir solas las lineas cortadas", new Runnable() {
                public void run() {
                    canvas.autoJoinLines();
                }
            }));
        } else if (mode == CanvasView.MODE_ZONE || mode == CanvasView.MODE_TONE) {
            bar.addView(iconButton(R.drawable.ic_patch, "Tapar todo lo azul de una vez", new Runnable() {
                public void run() {
                    canvas.fillHoleInSelection();
                }
            }));
        } else if (mode == CanvasView.MODE_PATCH) {
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar lo verde", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todo lo verde", new Runnable() {
                public void run() {
                    canvas.clearPatchSource();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Rellenar lo azul", new Runnable() {
                public void run() {
                    canvas.runPatchFill();
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else if (mode == CanvasView.MODE_SMUDGE || mode == CanvasView.MODE_BLUR) {
            bar.addView(iconButton(R.drawable.ic_range, "Fuerza del efecto", new Runnable() {
                public void run() { effectStrengthDialog(); }
            }));
        } else if (mode == CanvasView.MODE_LIQUIFY) {
            // Barra compacta inspirada en el flujo de ibis: 5 modos accesibles,
            // sin tapar el lienzo con una ficha cada vez que se toca un icono.
            // Los iconos deben poder tocarse sin la etiqueta grande que los
            // comprimia a solo 31dp; descripcion accesible al mantener pulsado.
            final int lt = canvas.getLiquifyType();
            int[] icons = {R.drawable.ic_liq_drag, R.drawable.ic_liq_pinch, R.drawable.ic_liq_expand, R.drawable.ic_liq_smooth, R.drawable.ic_liq_restore};
            String[] names = {"Arrastrar", "Contraer", "Expandir", "Suavizar", "Restaurar"};
            for (int i = 0; i < 5; i++) {
                final int which = i;
                ImageButton b = compactIconButton(icons[i], "Especial: " + names[i], new Runnable() {
                    public void run() {
                        canvas.setLiquifyType(which);
                        updateUi();
                    }
                });
                // La animacion solo aparece al mantener pulsado, no al tocar.
                b.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override public boolean onLongClick(View v) {
                        showDemo(CanvasView.MODE_LIQUIFY, 0);
                        return true;
                    }
                });
                b.setLayoutParams(new LinearLayout.LayoutParams(dp(43), dp(42)));
                b.setPadding(dp(8), dp(8), dp(8), dp(8));
                b.setBackgroundResource(lt == i ? R.drawable.bg_liq_active : R.drawable.bg_liq_idle);
                if (lt == i) b.setColorFilter(0xFF121216);
                bar.addView(b);
            }
            // La fortaleza se controla siempre con el segundo deslizador visible.
            // El boton de ajustes da acceso rapido a la suavidad del borde.
            ImageButton liqSettings = compactIconButton(R.drawable.ic_liq_settings, "Suavidad de deformacion", new Runnable() {
                public void run() { effectSoftnessDialog(); }
            });
            liqSettings.setLayoutParams(new LinearLayout.LayoutParams(dp(43), dp(42)));
            liqSettings.setPadding(dp(8), dp(8), dp(8), dp(8));
            bar.addView(liqSettings);
        } else if (mode == CanvasView.MODE_TRANSFORM) {
            // Transformar como antes: Mover, Perspectiva, Malla y Puntos de anclaje.
            int tt = canvas.getTransformType();
            ImageButton free = compactIconButton(R.drawable.ic_move, "Mover, escalar y girar", new Runnable() {
                public void run() { canvas.setTransformType(0); canvas.showHud("Mover / escalar / girar"); updateUi(); }
            });
            free.setBackgroundResource(tt == 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(free);
            ImageButton persp = compactIconButton(R.drawable.ic_curve, "Perspectiva: 4 esquinas", new Runnable() {
                public void run() { canvas.setTransformType(1); canvas.showHud("Perspectiva: 1 dedo esquinas · 2 dedos mover/zoom"); updateUi(); }
            });
            persp.setBackgroundResource(tt == 1 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(persp);
            ImageButton mesh = compactIconButton(R.drawable.ic_transform, "Malla deformable", new Runnable() {
                public void run() { canvas.setTransformType(2); canvas.showHud("Malla: 1 dedo nodos · 2 dedos mover/zoom"); updateUi(); }
            });
            mesh.setBackgroundResource(tt == 2 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(mesh);
            ImageButton anchors = compactIconButton(R.drawable.ic_anchor_points, "Puntos y anclajes", new Runnable() {
                public void run() { canvas.setTransformType(3); canvas.showHud("Puntos: azul fija · naranja mueve · 2 dedos mover/zoom"); updateUi(); }
            });
            anchors.setBackgroundResource(tt == 3 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(anchors);
            if (tt == 2) {
                bar.addView(compactIconButton(R.drawable.ic_sub, "Malla menos densa", new Runnable() {
                    public void run() { canvas.changeTransformGrid(-1); updateUi(); }
                }));
                TextView gridInfo = new TextView(this);
                gridInfo.setText(canvas.getTransformGridCols() + "x" + canvas.getTransformGridRows());
                gridInfo.setTextColor(0xFFE6E6E6);
                gridInfo.setTextSize(11f);
                gridInfo.setGravity(android.view.Gravity.CENTER);
                gridInfo.setPadding(dp(2), 0, dp(2), 0);
                bar.addView(gridInfo, new LinearLayout.LayoutParams(dp(38), dp(36)));
                bar.addView(compactIconButton(R.drawable.ic_add, "Malla mas densa", new Runnable() {
                    public void run() { canvas.changeTransformGrid(1); updateUi(); }
                }));
                bar.addView(compactIconButton(R.drawable.ic_menu, "Opciones de malla", new Runnable() {
                    public void run() { meshOptionsDialog(); }
                }));
            } else if (tt == 3) {
                final int am = canvas.getTransformAnchorAddMode();
                ImageButton fixed = compactIconButton(R.drawable.ic_anchor_fixed, "Agregar punto fijo azul", new Runnable() {
                    public void run() { canvas.setTransformAnchorAddMode(0); updateUi(); }
                });
                fixed.setBackgroundResource(am == 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(fixed);
                ImageButton movable = compactIconButton(R.drawable.ic_anchor_move, "Agregar punto movil naranja", new Runnable() {
                    public void run() { canvas.setTransformAnchorAddMode(1); updateUi(); }
                });
                movable.setBackgroundResource(am == 1 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(movable);
                bar.addView(compactIconButton(R.drawable.ic_trash, "Eliminar punto seleccionado", new Runnable() {
                    public void run() { canvas.deleteSelectedTransformAnchor(); }
                }));
                bar.addView(compactIconButton(R.drawable.ic_menu, "Mas opciones de puntos", new Runnable() {
                    public void run() { transformAnchorOptionsDialog(); }
                }));
            }
            addTransformApplyCancel(bar);
        } else if (mode == CanvasView.MODE_PUPPET) {
            buildDeformBar(bar);
        } else if (mode == CanvasView.MODE_PAINT) {
            ImageButton ls = iconButton(R.drawable.ic_line_guard, "Proteger contornos negros (no tapar la tinta)", new Runnable() {
                public void run() {
                    boolean on = !canvas.isLineStop();
                    canvas.setLineStop(on);
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("line_stop", on).apply();
                    canvas.showHud(on ? "Proteger contornos: pinta solo la zona donde empiezas y no tapa la tinta"
                            : "Pincel libre: pasa por encima de la linea");
                    updateUi();
                }
            });
            ls.setBackgroundResource(canvas.isLineStop() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            // v8.28: COLOR PLANO o SOMBRA SUAVE a un toque (el tamano no cambia)
            final int curPreset = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset4", 0);
            final TextView style = smallTextButton(curPreset == 1 ? "Suave" : "Plano");
            style.setContentDescription(curPreset == 1 ? "Sombra suave: borde difuminado. Toca para Color plano"
                    : "Color plano: borde definido. Toca para Sombra suave");
            style.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int next = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset4", 0) == 1 ? 0 : 1;
                    applyBrushStyle(next);
                    canvas.showHud(next == 1 ? "Sombra suave: borde difuminado para sombras y degradados"
                            : "Color plano: borde definido y color parejo");
                    updateUi();
                }
            });
            bar.addView(style);
            bar.addView(ls);
            bar.addView(iconButton(R.drawable.ic_ref_color, "Referencia de color: abrir otra imagen y tomar sus colores (no se exporta)", new Runnable() {
                public void run() { requestColorReference(paintColorTarget()); }
            }));
            bar.addView(iconButton(toolIcon(CanvasView.MODE_PAINT), "Pinceles", new Runnable() {
                public void run() {
                    brushPresets();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_layers, "Crear capa Superposicion", new Runnable() {
                public void run() {
                    canvas.addOverlayPaintLayer();
                    updateUi();
                }
            }));
            // v8.33: sombra automatica por direccion de la luz (capa aparte, se corrige a mano)
            bar.addView(iconButton(R.drawable.ic_shadow, "Sombra automatica: elige de donde viene la luz", new Runnable() {
                public void run() { autoShadeDialog(); }
            }));
            if (canvas.isMangaMode()) {
                // v8.26: sombras y luces a un toque mientras se pinta el manga
                bar.addView(iconButton(R.drawable.ic_shadow, "Sombra rapida (capa recortada, Multiplicar 40 %)", new Runnable() {
                    public void run() { canvas.addQuickShadeLayer(true); afterLayerOp(); }
                }));
                bar.addView(iconButton(R.drawable.ic_light, "Luz rapida (capa recortada, Pantalla 60 %)", new Runnable() {
                    public void run() { canvas.addQuickShadeLayer(false); afterLayerOp(); }
                }));
                bar.addView(iconButton(R.drawable.ic_manga, "Colorear manga: mas opciones", new Runnable() {
                    public void run() { mangaMenu(); }
                }));
            }
            bar.addView(destinationChip(false));
        } else if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) {
            bar.addView(iconButton(R.drawable.ic_aim, "Elegir otro origen", new Runnable() {
                public void run() {
                    canvas.resetCloneSource();
                }
            }));
            ImageButton mir = iconButton(R.drawable.ic_mirror, "Espejo", new Runnable() {
                public void run() {
                    canvas.setCloneMirror(!canvas.isCloneMirror());
                    canvas.showHud(canvas.isCloneMirror() ? "Espejo: SI" : "Espejo: NO");
                    updateUi();
                }
            });
            mir.setBackgroundResource(canvas.isCloneMirror() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(mir);
            bar.addView(iconButton(R.drawable.ic_rotate, "Girar el origen", new Runnable() {
                public void run() {
                    cloneAngleDialog();
                }
            }));
        } else {
            bar.setVisibility(View.GONE);
        }
    }

    private void effectStrengthDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF);
        value.setTextSize(18f);
        value.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(95);
        int cur = Math.max(5, Math.round(canvas.getEffectStrength() * 100f));
        bar.setProgress(cur - 5);
        value.setText("Fuerza " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                int x = v + 5;
                canvas.setEffectStrength(x / 100f);
                value.setText("Fuerza " + x + "%");
            }
        });
        root.addView(value);
        root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Fuerza").setView(root).setPositiveButton("Listo", null).show();
    }

    private void effectSoftnessDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF);
        value.setTextSize(18f);
        value.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getEffectSoftness() * 100f)));
        bar.setProgress(cur);
        value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setEffectSoftness(v / 100f);
                value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value);
        root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Suavidad de Especial").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void transformMeshSmoothnessDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(18f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getTransformMeshSmoothness() * 100f)));
        bar.setProgress(cur); value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setTransformMeshSmoothness(v / 100f); value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value); root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Suavidad de malla").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void addTransformApplyCancel(LinearLayout bar) {
        ImageButton cancel = compactIconButton(R.drawable.ic_close, "Cancelar", new Runnable() {
            public void run() { canvas.cancelTransform(); updateUi(); }
        });
        bar.addView(cancel);
        ImageButton ok = compactIconButton(R.drawable.ic_check, "Aplicar", new Runnable() {
            public void run() { canvas.applyTransform(); updateUi(); }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        bar.addView(ok);
    }

    /** Barra de Marioneta (herramienta propia): controles compactos. */
    private void buildDeformBar(LinearLayout bar) {
        ImageButton add = compactIconButton(R.drawable.ic_pin_add, "Poner puntos al tocar", new Runnable() {
            public void run() { canvas.setPuppetAddMode(!canvas.isPuppetAddMode()); updateUi(); }
        });
        add.setBackgroundResource(canvas.isPuppetAddMode() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(add);
        boolean fixedSel = canvas.isPuppetSelectionFixed();
        ImageButton fix = compactIconButton(fixedSel ? R.drawable.ic_anchor_fixed : R.drawable.ic_anchor_move,
                "Fijar / soltar el punto elegido", new Runnable() {
            public void run() { canvas.togglePuppetFixed(); updateUi(); }
        });
        fix.setBackgroundResource(fixedSel ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(fix);
        bar.addView(compactIconButton(R.drawable.ic_trash, "Eliminar el punto elegido", new Runnable() {
            public void run() { canvas.deletePuppetPin(); updateUi(); }
        }));
        ImageButton parts = compactIconButton(R.drawable.ic_puppet_parts, "Mover por partes (lo demas queda quieto)", new Runnable() {
            public void run() {
                boolean on = !canvas.isPuppetByParts();
                canvas.setPuppetByParts(on);
                savePuppetPrefs();
                canvas.showHud(on ? "Por partes: cada punto mueve solo su parte"
                        : "Todo junto: sin puntos fijos, el dibujo entero sigue al punto");
                updateUi();
            }
        });
        parts.setBackgroundResource(canvas.isPuppetByParts() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(parts);
        ImageButton eye = compactIconButton(canvas.isPuppetShowMesh() ? R.drawable.ic_eye : R.drawable.ic_eye_off,
                "Ver malla (solo se dibuja; el motor la usa igual)", new Runnable() {
            public void run() {
                canvas.setPuppetShowMesh(!canvas.isPuppetShowMesh());
                savePuppetPrefs();
                canvas.showHud(canvas.isPuppetShowMesh() ? "Malla visible" : "Malla oculta (el motor la sigue usando)");
                updateUi();
            }
        });
        eye.setBackgroundResource(canvas.isPuppetShowMesh() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(eye);
        bar.addView(compactIconButton(R.drawable.ic_menu, "Opciones de Marioneta", new Runnable() {
            public void run() { puppetOptionsDialog(); }
        }));
        ImageButton cancel = compactIconButton(R.drawable.ic_close, "Cancelar", new Runnable() {
            public void run() { canvas.cancelTransform(); updateUi(); }
        });
        bar.addView(cancel);
        ImageButton ok = compactIconButton(R.drawable.ic_check, "Aplicar", new Runnable() {
            public void run() { applyPuppetChecked(); }
        });
        ok.setBackgroundResource(R.drawable.bg_save);
        bar.addView(ok);
    }

    /**
     * v8.27: Aplicar Marioneta. Si el resultado sale del lienzo se pregunta ANTES (con el
     * lienzo nuevo dibujado en azul): ampliar lo justo y aplicar, moverlo dentro (si cabe),
     * aplicar recortando, o seguir editando. Antes solo avisaba y se cortaba al aplicar.
     */
    private void applyPuppetChecked() {
        if (!canvas.isPuppetReady()) {
            canvas.applyTransform();
            updateUi();
            return;
        }
        final int[] m = canvas.puppetOverflow();
        if (m == null) {
            canvas.applyTransform();
            updateUi();
            return;
        }
        final boolean canMove = canvas.puppetCanMoveInside();
        canvas.setCanvasGrowPreview(m);
        StringBuilder sb = new StringBuilder("Una parte del dibujo sale del lienzo");
        sb.append(" (arriba ").append(m[1]).append(" px, abajo ").append(m[3]).append(" px, izquierda ")
                .append(m[0]).append(" px, derecha ").append(m[2]).append(" px, con 8 px de aire).\n\n");
        sb.append("En azul se ve el lienzo ampliado. Ampliar se puede deshacer y tu original no se pierde.");
        final String[] opts = canMove
                ? new String[]{"Ampliar lienzo y aplicar (recomendado)", "Mover el resultado dentro del lienzo (sin deformarlo)",
                        "Aplicar recortando lo que sale", "Seguir editando"}
                : new String[]{"Ampliar lienzo y aplicar (recomendado)", "Aplicar recortando lo que sale", "Seguir editando"};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(8), dp(18), dp(4));
        TextView msgV = new TextView(this);
        msgV.setText(sb.toString());
        msgV.setTextColor(0xFFDDDDDD);
        msgV.setTextSize(13f);
        root.addView(msgV);
        final boolean[] chosen = {false};
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < opts.length; i++) {
            final String it = opts[i];
            TextView row = new TextView(this);
            row.setText(it);
            row.setTextColor(i == 0 ? 0xFF9FC6FF : 0xFFFFFFFF);
            row.setTextSize(15f);
            row.setPadding(dp(4), dp(12), dp(4), dp(12));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    chosen[0] = true;
                    if (dlg[0] != null) dlg[0].dismiss();
                    if (it.startsWith("Ampliar")) {
                        canvas.applyPuppetEnlarged(m);
                    } else if (it.startsWith("Mover")) {
                        canvas.setCanvasGrowPreview(null);
                        canvas.puppetMoveInside();
                    } else if (it.startsWith("Aplicar recortando")) {
                        canvas.setCanvasGrowPreview(null);
                        canvas.applyTransform();
                    } else {
                        canvas.setCanvasGrowPreview(null);
                    }
                    updateUi();
                }
            });
            root.addView(row);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dlg[0] = new AlertDialog.Builder(this).setTitle("Fuera del lienzo").setView(sv).create();
        dlg[0].setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface dd) {
                if (!chosen[0]) canvas.setCanvasGrowPreview(null);
            }
        });
        dlg[0].show();
    }

    private void transformAnchorOptionsDialog() {
        final String[] items = {"Radio de influencia", "Borrar todos los puntos"};
        new AlertDialog.Builder(this)
                .setTitle("Puntos y anclajes")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == 0) transformAnchorRadiusDialog();
                        else if (which == 1) {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setMessage("¿Borrar todos los puntos?")
                                    .setNegativeButton("Cancelar", null)
                                    .setPositiveButton("Borrar", new android.content.DialogInterface.OnClickListener() {
                                        @Override public void onClick(android.content.DialogInterface d, int w) {
                                            canvas.clearTransformAnchors();
                                        }
                                    }).show();
                        }
                    }
                }).show();
    }

    private void transformAnchorRadiusDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(18f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(860);
        int cur = Math.max(40, Math.min(900, Math.round(canvas.getTransformAnchorRadius())));
        bar.setProgress(cur - 40); value.setText("Radio " + cur + " px");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                int px = v + 40;
                canvas.setTransformAnchorRadius(px);
                value.setText("Radio " + px + " px");
            }
        });
        root.addView(value); root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Influencia de los puntos").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void meshOptionsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(16f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getTransformMeshSmoothness() * 100f)));
        bar.setProgress(cur); value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setTransformMeshSmoothness(v / 100f); value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value); root.addView(bar);
        TextView tip = new TextView(this);
        tip.setText("Los nodos se mueven tan lejos como quieras. Solo se detienen si la malla se doblaria sobre si misma.");
        tip.setTextColor(0xFFB8B8C0); tip.setTextSize(12f); tip.setPadding(0, dp(8), 0, 0);
        root.addView(tip);
        new AlertDialog.Builder(this).setTitle("Opciones de Malla").setView(root)
                .setNeutralButton("Restablecer malla", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { canvas.resetMeshGrid(); }
                })
                .setPositiveButton("Listo", null).show();
    }

    private void loadPuppetPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        canvas.setPuppetRigidity(sp.getInt("puppet_rigidity", 1));
        canvas.setPuppetMeshOptions(sp.getInt("puppet_density", 1), sp.getInt("puppet_expansion", 2));
        canvas.setPuppetFoldGuard(sp.getBoolean("puppet_foldguard", true));
        canvas.setPuppetStiffCells(sp.getFloat("puppet_stiff_cells", 3f));
        canvas.setPuppetByParts(sp.getBoolean("puppet_by_parts", true));
        canvas.setPuppetReachCells(sp.getFloat("puppet_reach_cells", 12f));
        canvas.setPuppetShowMesh(sp.getBoolean("puppet_show_mesh_v834", true));
        canvas.setPuppetMinAlpha(sp.getInt("puppet_min_alpha", 8));
    }

    private void savePuppetPrefs() {
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putInt("puppet_rigidity", canvas.getPuppetRigidity())
                .putInt("puppet_density", canvas.getPuppetDensity())
                .putInt("puppet_expansion", canvas.getPuppetExpansion())
                .putBoolean("puppet_foldguard", canvas.isPuppetFoldGuard())
                .putFloat("puppet_stiff_cells", canvas.getPuppetStiffCells())
                .putBoolean("puppet_by_parts", canvas.isPuppetByParts())
                .putFloat("puppet_reach_cells", canvas.getPuppetReachCells())
                .putBoolean("puppet_show_mesh_v834", canvas.isPuppetShowMesh())
                .putInt("puppet_min_alpha", canvas.getPuppetMinAlpha()).apply();
    }

    private RadioGroup choiceRow(String[] labels, int checked, final IntConsumerCompat onPick) {
        RadioGroup g = new RadioGroup(this);
        g.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < labels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(labels[i]);
            rb.setTextColor(0xFFFFFFFF);
            rb.setTextSize(13f);
            rb.setId(1000 + i);
            g.addView(rb);
        }
        g.check(1000 + checked);
        g.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup group, int id) { onPick.accept(id - 1000); }
        });
        return g;
    }

    /** Equivalente simple de IntConsumer (Android 26 lo tiene, pero asi no dependemos de java.util.function). */
    private interface IntConsumerCompat { void accept(int v); }

    private TextView optLabel(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFF9FC6FF);
        v.setTextSize(12f);
        v.setPadding(0, dp(10), 0, dp(2));
        return v;
    }

    /** Panel plegable de Marioneta: lo avanzado no ocupa la barra. */
    private void puppetOptionsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(6), dp(18), dp(4));
        root.addView(optLabel("Rigidez"));
        root.addView(choiceRow(new String[]{"Flexible", "Normal", "Rigido"}, canvas.getPuppetRigidity(), new IntConsumerCompat() {
            public void accept(int v) { canvas.setPuppetRigidity(v); savePuppetPrefs(); }
        }));
        root.addView(optLabel("Densidad de la malla"));
        root.addView(choiceRow(new String[]{"Menos", "Normal", "Mas"}, canvas.getPuppetDensity(), new IntConsumerCompat() {
            public void accept(int v) { canvas.setPuppetMeshOptions(v, canvas.getPuppetExpansion()); savePuppetPrefs(); }
        }));
        final TextView expL = optLabel("Expansion: " + canvas.getPuppetExpansion() + " px");
        root.addView(expL);
        final SeekBar exp = new SeekBar(this);
        exp.setMax(20);
        exp.setProgress(canvas.getPuppetExpansion());
        exp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) { expL.setText("Expansion: " + v + " px"); }
            @Override public void onStopTrackingTouch(SeekBar s) {
                canvas.setPuppetMeshOptions(canvas.getPuppetDensity(), s.getProgress());
                savePuppetPrefs();
            }
        });
        root.addView(exp);
        final TextView rl = optLabel("Alcance de cada punto (por partes): " + Math.round(canvas.getPuppetReachCells()) + " celdas");
        root.addView(rl);
        SeekBar reach = new SeekBar(this);
        reach.setMax(28);
        reach.setProgress(Math.round(canvas.getPuppetReachCells()) - 2);
        reach.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean fromUser) {
                rl.setText("Alcance de cada punto (por partes): " + (v + 2) + " celdas");
            }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                canvas.setPuppetReachCells(sb.getProgress() + 2);
                savePuppetPrefs();
            }
        });
        root.addView(reach);
        final CheckBox stiff = new CheckBox(this);
        stiff.setText("Proteger la zona del punto elegido (cara, manos)");
        stiff.setTextColor(0xFFFFFFFF);
        stiff.setChecked(canvas.isPuppetSelectionStiff());
        stiff.setEnabled(canvas.hasPuppetSelection());
        stiff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (on != canvas.isPuppetSelectionStiff()) canvas.togglePuppetStiff();
            }
        });
        root.addView(stiff);
        final TextView zl = optLabel("Tamano de la zona protegida: " + Math.round(canvas.getPuppetStiffCells()) + " celdas");
        root.addView(zl);
        SeekBar zone = new SeekBar(this);
        zone.setMax(7);
        zone.setProgress(Math.round(canvas.getPuppetStiffCells()) - 1);
        zone.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                zl.setText("Tamano de la zona protegida: " + (v + 1) + " celdas");
            }
            @Override public void onStopTrackingTouch(SeekBar s) {
                canvas.setPuppetStiffCells(s.getProgress() + 1);
                savePuppetPrefs();
            }
        });
        root.addView(zone);
        CheckBox haze = new CheckBox(this);
        haze.setText("Ignorar restos casi invisibles del recorte (alfa menor a 3 %): malla solo sobre el dibujo");
        haze.setTextColor(0xFFFFFFFF);
        haze.setChecked(canvas.getPuppetMinAlpha() > 1);
        haze.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setPuppetMinAlpha(on ? 8 : 1); savePuppetPrefs(); }
        });
        root.addView(haze);
        CheckBox fold = new CheckBox(this);
        fold.setText("Evitar pliegues (el punto se detiene antes de doblar la malla)");
        fold.setTextColor(0xFFFFFFFF);
        fold.setChecked(canvas.isPuppetFoldGuard());
        fold.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setPuppetFoldGuard(on); savePuppetPrefs(); }
        });
        root.addView(fold);
        TextView tip = new TextView(this);
        tip.setText("Girar: toca un punto naranja y arrastra su anillo. Rojo = pliegue (se ve aunque la malla este oculta). "
                + "Expansion = margen de seguridad de la malla alrededor del dibujo.");
        tip.setTextColor(0xFFB8B8C0);
        tip.setTextSize(12f);
        tip.setPadding(0, dp(8), 0, 0);
        root.addView(tip);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new AlertDialog.Builder(this).setTitle("Opciones de Marioneta").setView(sv)
                .setNeutralButton("Quitar todos los puntos", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { canvas.resetPuppetPins(); updateUi(); }
                })
                .setPositiveButton("Listo", null).show();
    }

    /**
     * Dilatacion propia de Borrar fondo. Se prende y apaga con un toque;
     * manteniendo presionado se ajusta de 1 en 1. Funciona en vivo mientras
     * pasas el pincel: al soltar no se come nada mas.
     */
    private boolean bgExpOn;
    private int bgExpAmt = 2;
    private static final int EXP_MIN = -3, EXP_MAX = 10;

    private void applyBgExp() {
        canvas.setBgExpansion(bgExpOn ? bgExpAmt : 0f);
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putBoolean("bg_exp_on", bgExpOn).putInt("bg_exp_amt", bgExpAmt).apply();
    }

    // ---- Relleno: opciones guardadas ----
    private boolean fillExpOn = true;
    private int fillExpAmt = 2;

    private void applyFillPrefs() {
        canvas.setFillExpansion(fillExpOn ? fillExpAmt : 0f);
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putBoolean("fill_exp_on", fillExpOn).putInt("fill_exp_amt", fillExpAmt)
                .putInt("fill_tol_v824", canvas.getFillTolerance())
                .putBoolean("fill_shade", canvas.isFillShade())
                .putBoolean("fill_all", canvas.isFillAllLayers())
                .putBoolean("fill_line", canvas.isFillToLine())
                .putInt("fill_target_v827", canvas.getFillTarget())
                .putBoolean("fill_by_lines", canvas.isFillByLines())
                .putBoolean("bucket_preview", canvas.isBucketPreview())
                .putInt("fill_gap", canvas.getGapRadius()).apply();
    }

    private void loadFillPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        fillExpOn = sp.getBoolean("fill_exp_on", true);
        fillExpAmt = sp.getInt("fill_exp_amt", 2);
        // v8.24: la tolerancia ahora es estricta (antes se sumaba la suavidad): nuevo valor inicial
        canvas.setFillTolerance(sp.getInt("fill_tol_v824", 20));
        canvas.setFillShade(sp.getBoolean("fill_shade", false));
        canvas.setFillAllLayers(sp.getBoolean("fill_all", true));
        canvas.setFillToLine(sp.getBoolean("fill_line", true));
        // v8.27: destino del balde. Clave nueva: el "capa aparte" de fabrica de v8.24-8.26
        // creaba Color_1 encima de la capa del usuario. De fabrica: pintar en la capa actual.
        canvas.setFillTarget(sp.getInt("fill_target_v827", CanvasView.FILL_TARGET_CURRENT));
        canvas.setFillByLines(sp.getBoolean("fill_by_lines", false));
        canvas.setBucketPreview(sp.getBoolean("bucket_preview", false));
        canvas.setGap(canvas.isGapOn(), sp.getInt("fill_gap", 4));
        canvas.setFillExpansion(fillExpOn ? fillExpAmt : 0f);
    }

    private static String signed(int v) {
        return (v > 0 ? "+" : "") + v;
    }

    /** Boton de tres puntos para abrir las opciones de al lado. */
    private ImageButton dotsButton(String name, Runnable r) {
        ImageButton b = iconButton(R.drawable.ic_menu, name, r);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(26), dp(38)));
        b.setPadding(dp(2), dp(9), dp(2), dp(9));
        b.setBackground(null);
        return b;
    }

    private void fillToleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getFillTolerance());
        final TextView t = new TextView(this);
        t.setText("Tolerancia " + canvas.getFillTolerance());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta rellena colores mas distintos. Si se sale de la zona, bajala. "
                + "Si quedan puntitos sin pintar, subela un poco.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Tolerancia " + v);
                canvas.setFillTolerance(v);
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                applyFillPrefs();
            }
        });
        // v8.23: el cierre de huecos ya existia (automatico con lineas); aqui se ajusta su tamano.
        final TextView gt = new TextView(this);
        gt.setText(gapText(canvas.getGapRadius()));
        gt.setTextColor(0xFFFFFFFF);
        gt.setTextSize(16f);
        gt.setGravity(android.view.Gravity.CENTER);
        gt.setPadding(0, dp(14), 0, 0);
        final SeekBar gb = new SeekBar(this);
        gb.setMax(9); // niveles 3..12 (el relleno con lineas usa 3 como minimo)
        gb.setProgress(Math.max(3, Math.min(12, canvas.getGapRadius())) - 3);
        TextView gh = new TextView(this);
        gh.setText("Si el color se escapa por un corte de la linea, subelo. Si no llega a rincones finos, bajalo.");
        gh.setTextColor(0xFFAAAAAA);
        gh.setTextSize(12f);
        root.addView(gt);
        root.addView(gb);
        root.addView(gh);
        // v8.24: plano (color exacto) o conservando las sombras del dibujo
        final CheckBox sh = new CheckBox(this);
        sh.setText("Conservar sombras (el color toma las sombras del dibujo)");
        sh.setTextColor(0xFFFFFFFF);
        sh.setChecked(canvas.isFillShade());
        sh.setPadding(0, dp(10), 0, 0);
        sh.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                canvas.setFillShade(on);
                applyFillPrefs();
            }
        });
        root.addView(sh);
        gb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                gt.setText(gapText(v + 3));
                canvas.setGap(canvas.isGapOn(), v + 3);
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                applyFillPrefs();
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    private static String gapText(int r) {
        // medido en pruebas: el nivel N cierra cortes de hasta unos 2N px
        return "Cerrar cortes de la linea de hasta " + (r * 2) + " px";
    }

    /** Dilatacion de 1 en 1, para Borrar fondo (fill=false) o Relleno (fill=true). */
    private void expansionDialog(final boolean fill) {
        final int min = fill ? 0 : EXP_MIN;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.setBackgroundColor(0xFF232329);
        final TextView t = new TextView(this);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(EXP_MAX - min);
        final int cur = fill ? fillExpAmt : bgExpAmt;
        bar.setProgress(cur - min);
        t.setText(expText(cur));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageButton minus = iconButton(R.drawable.ic_sub, "Menos 1", new Runnable() {
            public void run() {
                bar.setProgress(Math.max(0, bar.getProgress() - 1));
                setExp(fill, bar.getProgress() + min, t);
            }
        });
        ImageButton plus = iconButton(R.drawable.ic_add, "Mas 1", new Runnable() {
            public void run() {
                bar.setProgress(Math.min(EXP_MAX - min, bar.getProgress() + 1));
                setExp(fill, bar.getProgress() + min, t);
            }
        });
        row.addView(minus);
        row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(plus);
        TextView hint = new TextView(this);
        hint.setText(fill
                ? "Cuantos pixeles se mete el color debajo del borde de la linea. Asi no queda filo blanco."
                : "Mas alto: se come el borde de color pegado al fondo, sin tocar la linea negra. "
                + "Negativo: deja un poco de borde. Se ve en vivo mientras pasas el dedo.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        hint.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        root.addView(row);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (u) setExp(fill, v + min, t);
            }
        });
        new AlertDialog.Builder(this).setView(root)
                .setNeutralButton("Restablecer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        setExp(fill, 2, null);
                    }
                })
                .setPositiveButton("Listo", null)
                .setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface d) {
                        updateUi();
                    }
                })
                .show();
    }

    private void setExp(boolean fill, int amount, TextView label) {
        if (fill) {
            fillExpAmt = Math.max(0, Math.min(EXP_MAX, amount));
            fillExpOn = true;
            applyFillPrefs();
            if (label != null) label.setText(expText(fillExpAmt));
        } else {
            setBgExp(amount, label);
        }
    }

    /** Al ajustar el valor, la dilatacion queda prendida. */
    private void setBgExp(int amount, TextView label) {
        bgExpAmt = Math.max(EXP_MIN, Math.min(EXP_MAX, amount));
        bgExpOn = true;
        applyBgExp();
        if (label != null) label.setText(expText(bgExpAmt));
    }

    private static String expText(int e) {
        return "Dilatacion " + (e > 0 ? "+" : "") + e + " px";
    }

    /** Tolerancia propia de Borrar fondo: no toca la de la varita. */
    /**
     * v8.27 Refinar borde: descontaminar el color del fondo viejo, contraer/expandir con
     * fracciones de pixel, suavizar solo el borde y quitar restos sueltos. La vista previa
     * es el resultado real en el lienzo; Cancelar deja la capa exacta.
     */
    private void edgeRefineDialog() {
        if (!canvas.beginEdgeRefine()) return;
        final com.pacco.animecut.core.EdgeRefine.Params prm = new com.pacco.animecut.core.EdgeRefine.Params();
        final int picked = canvas.getBgRefColor();
        prm.bg = 0xFFFFFFFF;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(4), dp(18), dp(4));
        final TextView info = smallText("Lo que ves en el lienzo es el resultado. Para revisar usa fondo gris, negro o blanco.");
        root.addView(info);
        root.addView(optLabel("Color del fondo que se borro"));
        root.addView(choiceRow(new String[]{"Blanco", "Negro", String.format(Locale.US, "Tomado #%06X", picked & 0xFFFFFF)}, 0,
                new IntConsumerCompat() {
                    public void accept(int v) {
                        prm.bg = v == 0 ? 0xFFFFFFFF : v == 1 ? 0xFF000000 : picked;
                        edgeRefinePreview(prm, info);
                    }
                }));
        final TextView dl = optLabel("Quitar el color del fondo: 100 %");
        root.addView(dl);
        SeekBar dec = new SeekBar(this);
        dec.setMax(100);
        dec.setProgress(100);
        dec.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                dl.setText("Quitar el color del fondo: " + v + " %");
                prm.decontam = v / 100f;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(dec);
        final TextView sl = optLabel("Contraer / expandir: 0 px");
        root.addView(sl);
        SeekBar sh = new SeekBar(this);
        sh.setMax(16);
        sh.setProgress(8);
        sh.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                float px = (v - 8) * 0.25f;
                prm.shift = px;
                sl.setText("Contraer / expandir: " + (px > 0 ? "+" : "") + String.format(Locale.US, "%.2f", px)
                        + " px" + (px > 0 ? " (come el filo)" : px < 0 ? " (devuelve el filo)" : ""));
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(sh);
        final TextView ml = optLabel("Suavizar solo el borde: 0 %");
        root.addView(ml);
        SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(0);
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                ml.setText("Suavizar solo el borde: " + v + " %");
                prm.smooth = v / 100f;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(sm);
        final TextView rl = optLabel("Quitar restos sueltos de hasta: " + prm.speckle + " px");
        root.addView(rl);
        SeekBar rs = new SeekBar(this);
        rs.setMax(200);
        rs.setProgress(prm.speckle);
        rs.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                rl.setText(v == 0 ? "Quitar restos sueltos: no" : "Quitar restos sueltos de hasta: " + v + " px");
                prm.speckle = v;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(rs);
        CheckBox dark = new CheckBox(this);
        dark.setText("No comerse las lineas oscuras al contraer");
        dark.setTextColor(0xFFFFFFFF);
        dark.setChecked(true);
        dark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                prm.keepDark = on;
                edgeRefinePreview(prm, info);
            }
        });
        root.addView(dark);
        root.addView(optLabel("Ver sobre"));
        final int[] bgIdx = {0, 2, 3, 5, 4};
        int curBg = 0;
        for (int k = 0; k < bgIdx.length; k++) if (bgIdx[k] == canvas.getViewBg()) curBg = k;
        root.addView(choiceRow(new String[]{"Cuadros", "Blanco", "Negro", "Gris", "Verde"}, curBg, new IntConsumerCompat() {
            public void accept(int v) {
                canvas.setViewBg(bgIdx[v]);
                if (layersOpen()) buildViewBg();
            }
        }));
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        final boolean[] done = {false};
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Refinar borde").setView(sv)
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dd, int w) {
                        done[0] = true;
                        canvas.cancelEdgeRefine();
                        updateUi();
                    }
                })
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dd, int w) {
                        done[0] = true;
                        canvas.acceptEdgeRefine();
                        updateUi();
                    }
                })
                .create();
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface dd) {
                if (!done[0]) canvas.cancelEdgeRefine();
            }
        });
        if (d.getWindow() != null) {
            // abajo y sin oscurecer: el lienzo con la vista previa queda a la vista
            d.getWindow().setGravity(Gravity.BOTTOM);
            d.getWindow().setDimAmount(0f);
        }
        d.show();
        edgeRefinePreview(prm, info);
    }

    private final Runnable[] edgeRefineJob = new Runnable[1];

    /** Pide la vista previa (con una pausa corta mientras se mueve la barra). */
    private void edgeRefinePreview(final com.pacco.animecut.core.EdgeRefine.Params prm, final TextView info) {
        if (edgeRefineJob[0] != null) opHandler.removeCallbacks(edgeRefineJob[0]);
        edgeRefineJob[0] = new Runnable() {
            @Override public void run() {
                com.pacco.animecut.core.EdgeRefine.Params p = new com.pacco.animecut.core.EdgeRefine.Params();
                p.bg = prm.bg; p.decontam = prm.decontam; p.shift = prm.shift; p.smooth = prm.smooth;
                p.speckle = prm.speckle; p.keepDark = prm.keepDark;
                canvas.previewEdgeRefine(p);
                opHandler.postDelayed(new Runnable() {
                    @Override public void run() {
                        com.pacco.animecut.core.EdgeRefine.Result r = canvas.lastEdgeRefine;
                        if (r != null && canvas.isEdgeRefineActive())
                            info.setText("Cambian " + r.changed + " px: fondo quitado " + r.decontaminated + ", restos " + r.speckles
                                    + ", contraidos " + r.contracted + ", devueltos " + r.expanded + ", suavizados " + r.smoothed);
                    }
                }, 450);
            }
        };
        opHandler.postDelayed(edgeRefineJob[0], 120);
    }

    // ---- v8.27: medir rendimiento en el telefono ----
    private com.pacco.animecut.view.PerfBench perfBench;
    private CanvasView perfCanvas;

    private void perfDialog() {
        final TextView out = new TextView(this);
        out.setTextColor(0xFFE0E0E0);
        out.setTextSize(11f);
        out.setTypeface(android.graphics.Typeface.MONOSPACE);
        out.setTextIsSelectable(true);
        out.setPadding(dp(14), dp(8), dp(14), dp(8));
        String live = com.pacco.animecut.core.PerfStats.report();
        out.setText("Tiempos de TU uso real desde que abriste la app (este telefono):\n"
                + (live.isEmpty() ? "(todavia no hay; pinta un rato y vuelve)\n" : live)
                + "\nMedir: prueba automatica con obras de prueba (tu obra se guarda antes y no se toca). "
                + "Rapida: 720p y 1080p (~1 min). Completa: hasta 4K y A4 (2-4 min). No toques la pantalla mientras corre.");
        ScrollView sv = new ScrollView(this);
        sv.addView(out);
        final AlertDialog d = new AlertDialog.Builder(this).setTitle("Rendimiento").setView(sv)
                .setPositiveButton("Medir completa", null)
                .setNeutralButton("Medir rapida", null)
                .setNegativeButton("Cerrar", null)
                .create();
        d.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface di) {
                d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { startPerfBench(true, out, d); }
                });
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { startPerfBench(false, out, d); }
                });
            }
        });
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface di) { stopPerfBench(); }
        });
        d.show();
    }

    private void startPerfBench(boolean all, final TextView out, final AlertDialog d) {
        if (perfBench != null) return;
        autosave(false);
        ViewGroup host = findViewById(android.R.id.content);
        if (host == null) return;
        perfCanvas = new CanvasView(this);
        perfCanvas.setVisibility(View.INVISIBLE);
        host.addView(perfCanvas, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(false);
        perfBench = new com.pacco.animecut.view.PerfBench(perfCanvas, opHandler, new com.pacco.animecut.view.PerfBench.Listener() {
            @Override public void onProgress(String step) { out.setText("Midiendo... " + step); }

            @Override public void onDone(String report) {
                out.setText(report);
                lastPerfReport = report;
                stopPerfBench();
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setText("Copiar");
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(true);
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("Paint Zeta rendimiento", lastPerfReport));
                        toast("Informe copiado");
                    }
                });
            }
        });
        // la vista se mide y se coloca en el siguiente cuadro; luego empieza
        opHandler.postDelayed(new Runnable() {
            @Override public void run() { if (perfBench != null) perfBench.start(all); }
        }, 120);
    }

    private String lastPerfReport = "";

    private void stopPerfBench() {
        if (perfBench != null) perfBench.cancel();
        perfBench = null;
        if (perfCanvas != null) {
            ViewGroup parent = (ViewGroup) perfCanvas.getParent();
            if (parent != null) parent.removeView(perfCanvas);
            perfCanvas = null;
        }
    }

    private void bgToleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getBgTolerance());
        final TextView t = new TextView(this);
        t.setText("Tolerancia " + canvas.getBgTolerance());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta borra mas de golpe. Si se come el dibujo, bajala.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Tolerancia " + v);
                canvas.setBgTolerance(v);
                if (u) getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_tol", v).apply();
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Suavidad independiente: crea una transicion de alfa en el borde en vez de un corte duro. */
    private void bgSoftnessDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getBgSoftness());
        final TextView t = new TextView(this);
        t.setText("Suavidad " + canvas.getBgSoftness());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta suaviza el borde y ayuda a quitar halos. Si queda demasiado transparente, bajala.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Suavidad " + v);
                canvas.setBgSoftness(v);
                if (u) getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_soft", v).apply();
            }
        });
        // v8.23: limpieza del filo (quita el color del fondo del borde del personaje).
        final CheckBox dc = new CheckBox(this);
        dc.setText("Limpiar el filo (sin franja del color del fondo)");
        dc.setTextColor(0xFFFFFFFF);
        dc.setChecked(canvas.isBgDecontam());
        dc.setPadding(0, dp(10), 0, 0);
        dc.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                canvas.setBgDecontam(on);
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("bg_decontam", on).apply();
            }
        });
        root.addView(dc);
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    private void cloneAngleDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(360);
        bar.setProgress(Math.round(canvas.getCloneAngle()) + 180);
        final TextView t = new TextView(this);
        t.setText(Math.round(canvas.getCloneAngle()) + "°");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int a = v - 180;
                for (int snap : new int[]{-180, -90, 0, 90, 180}) if (Math.abs(a - snap) <= 4) a = snap;
                t.setText(a + "°");
                canvas.setCloneAngle(a);
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Lazo: el usuario puede crear directamente una capa sin buscar Copiar. */
    /** v8.28: colorear manga en una capa Normal tapa tramas y grises: se ofrece Multiplicar. */
    @Override public void onSuggestMultiply(final Layer l) {
        if (l == null || isFinishing()) return;
        new AlertDialog.Builder(this)
                .setTitle("Conservar tramas y sombras")
                .setMessage("Vas a pintar color sobre un dibujo en blanco y negro. Con la capa \"" + l.name
                        + "\" en Normal, el color TAPA los grises, las tramas y las sombras.\n\n"
                        + "En Multiplicar el color queda debajo de la tinta y se siguen viendo. "
                        + "Lo que ya pintaste en esta capa tambien cambia (se puede deshacer).")
                .setPositiveButton("Usar Multiplicar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.setLayerMode(l, Layer.MODE_MULTIPLY);
                        canvas.showHud("\"" + l.name + "\" en Multiplicar: se ven las tramas debajo del color");
                        markDirty();
                        updateUi();
                        canvas.resumeSuggestedFill();
                    }
                })
                .setNegativeButton("Dejar Normal", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.resumeSuggestedFill();
                    }
                })
                .setNeutralButton("No preguntar mas", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.setSuggestMultiply(false);
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("suggest_multiply", false).apply();
                        canvas.resumeSuggestedFill();
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface d) {
                        canvas.resumeSuggestedFill();
                    }
                })
                .show();
    }

    @Override public void onLassoCompleted() {
        if (!destroyed && canvas.getProject() != null && canvas.getProject().hasSelection()) {
            if (canvas.isMangaMode()) mangaLassoDialog();
            else partFromSelectionDialog(false);
        }
    }

    // ==================================================================
    // Menu de seleccion (cuadro punteado de arriba)
    // ==================================================================

    private void selectionMenu() {
        if (!needProject()) return;
        int[] icons = {R.drawable.ic_layer_add, R.drawable.ic_sel_delete, R.drawable.ic_clone,
                R.drawable.ic_sel_keep, R.drawable.ic_sel_invert, R.drawable.ic_close};
        String[] names = {"Copiar a capa", "Cortar a capa", "Duplicar capa", "Dejar solo esto",
                "Invertir", "Quitar azul"};
        Runnable[] actions = {
                new Runnable() { public void run() { partFromSelectionDialog(false); } },
                new Runnable() { public void run() { partFromSelectionDialog(true); } },
                new Runnable() { public void run() { canvas.duplicateActive(); updateUi(); } },
                new Runnable() { public void run() { canvas.keepSelectionInLayer(); } },
                new Runnable() { public void run() { canvas.invertSelection(); } },
                new Runnable() { public void run() { canvas.clearSelection(); } }
        };
        demoNext = new int[]{SelDemoView.COPY, SelDemoView.CUT, SelDemoView.DUP, SelDemoView.KEEP,
                SelDemoView.INVERT, SelDemoView.CLEAR};
        showIconGrid(null, icons, names, actions, 3, -1);
        demoNext = null;
    }

    /** Crear una parte con nombre y solapamiento listos para Alight Motion. */
    private void partFromSelectionDialog(final boolean cut) {
        Project p = canvas.getProject();
        if (p == null || !p.hasSelection()) {
            toast("Primero marca en azul la parte");
            return;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(8), dp(16), dp(4));

        TextView hint = new TextView(this);
        hint.setText("El solapamiento deja unos pixeles escondidos para que al mover la parte no aparezcan huecos.");
        hint.setTextColor(0xFFCCCCCC);
        hint.setTextSize(12.5f);
        root.addView(hint);

        final String[] names = {"parte", "cabeza", "cabello_frontal", "cabello_trasero",
                "brazo_I", "brazo_D", "mano_I", "mano_D", "torso", "pierna_I", "pierna_D"};
        final android.widget.Spinner spin = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> ad = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, names);
        spin.setAdapter(ad);
        root.addView(spin);

        final TextView ovText = new TextView(this);
        final SeekBar ov = new SeekBar(this);
        ov.setMax(12);
        ov.setProgress(6);
        ovText.setText("Solapamiento para animar: 6 px");
        ov.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar b, int v, boolean u) {
                ovText.setText("Solapamiento para animar: " + v + " px");
            }
        });
        root.addView(ovText);
        root.addView(ov);

        new AlertDialog.Builder(this)
                .setTitle("Separar parte para animar")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton(cut ? "Cortar" : "Copiar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        finishPartExtraction(cut, ov.getProgress(), names[spin.getSelectedItemPosition()]);
                    }
                })
                .setNeutralButton(cut ? "Copiar" : "Cortar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        finishPartExtraction(!cut, ov.getProgress(), names[spin.getSelectedItemPosition()]);
                    }
                }).show();
    }

    /** Copiar conserva la fuente. Cortar deja el hueco para reparar después. */
    private void finishPartExtraction(boolean cut, int overlap, String name) {
        Project p = canvas.getProject();
        if (p == null) return;
        int before = p.layers.size();
        canvas.layerFromSelection(cut, overlap, name);
        if (p.layers.size() > before) {
            canvas.clearTemporarySelectionAfterCopy();
            canvas.showHud(cut ? "Parte separada. Revisa el hueco de la capa original"
                    : "Capa copiada sin borrar la imagen original");
        }
        updateUi();
        if (layersOpen()) buildLayersPanel();
    }

    private int[] demoNext;
    private int lastPartLabel = 1;
    private ImageButton wandGear;

    private static final String[][] SEL_INFO = {
            {"Copiar a capa", "Copia lo azul a una capa nueva. La imagen queda igual."},
            {"Cortar a capa", "Saca lo azul a una capa nueva y lo borra de la capa original."},
            {"Duplicar capa", "Hace una copia de la capa entera."},
            {"Dejar solo esto", "Borra todo lo que no esta en azul, en la capa elegida."},
            {"Invertir", "Lo azul pasa a no azul y al reves. Elige el fondo con la varita e invierte para quedarte con el personaje."},
            {"Quitar azul", "Borra la seleccion. Los dibujos no se tocan."},
            {"Ampliar", "Agranda lo azul unos pixeles hacia afuera."},
            {"Refinar borde", "Ajusta el borde azul al dibujo real. Para pelo y bordes finos."},
            {"Cerrar puntos", "Rellena los huequitos que quedaron sin azul dentro de la seleccion."},
            {"Gama color", "Selecciona todos los pixeles de un color parecido en toda la imagen."},
            {"Tapar hueco", "Rellena lo azul con el color de al lado y une la linea negra. Usalo en el cuerpo despues de sacar un brazo."},
            {"Cerrar tijeras", "Cierra el contorno que marcaste con las tijeras y lo vuelve azul."},
            {"Varita que no se escapa", "La varita respeta la linea negra aunque tenga cortes chicos. Se prende y apaga en el menu de tres puntos."},
            {"Separar partes", "Raya cada parte con un color (pelo, cuerpo, brazo) y el fondo en gris. Toca el check y cada parte sale en su capa, cortada sobre la linea negra."}
    };

    /** Ficha con la animacion de antes y despues. */
    private void showSelCard(int scene) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(SEL_INFO[scene][0]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        SelDemoView art = new SelDemoView(this, scene);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(200), dp(200));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        root.addView(cardLine("", SEL_INFO[scene][1]));
        new AlertDialog.Builder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    // ==================================================================
    // Panel de capas, como Ibis
    // ==================================================================

    private void toggleLayersPanel() {
        if (!needProject()) return;
        View panel = findViewById(R.id.layersPanel);
        if (panel.getVisibility() == View.VISIBLE) {
            closeLayers();
        } else {
            closeTools();
            panel.setVisibility(View.VISIBLE);
            hideForLayers(true);
            buildLayersPanel();
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            if (!sp.getBoolean("hint_layer_drag", false)) {
                sp.edit().putBoolean("hint_layer_drag", true).apply();
                toast("Arrastra las rayitas de la derecha para subir o bajar una capa. Toca la capa elegida para cambiarle el nombre.");
            }
        }
    }

    private void closeLayers() {
        if (layerDrag != null) layerDrag.cancel();
        findViewById(R.id.layersPanel).setVisibility(View.GONE);
        canvas.setCompactHold(false);
        hideForLayers(false);
        updateUi();
    }

    private void hideForLayers(boolean hide) {
        int v = hide ? View.GONE : View.VISIBLE;
        findViewById(R.id.sizeRow).setVisibility(v);
        findViewById(R.id.opacityRow).setVisibility(v);
        if (hide) {
            findViewById(R.id.selBar).setVisibility(View.GONE);
            findViewById(R.id.optBar).setVisibility(View.GONE);
        }
    }

    private boolean layersOpen() {
        return findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE;
    }

    // ------------------------------------------------------------------
    // Filas de capas: se crean una vez y despues solo se actualizan.
    // Antes se borraba y rehacia todo el panel en cada toque (y las
    // miniaturas tambien), por eso se trababa.
    // ------------------------------------------------------------------

    private static final class RowHolder {
        Layer layer;
        LinearLayout row;
        ImageView thumb;
        TextView text;
        ImageButton eye;
    }

    private final java.util.IdentityHashMap<Layer, RowHolder> rowHolders = new java.util.IdentityHashMap<Layer, RowHolder>();
    private final java.util.IdentityHashMap<Layer, Bitmap> thumbCache = new java.util.IdentityHashMap<Layer, Bitmap>();
    private final java.util.concurrent.ExecutorService thumbPool = java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean thumbsBusy, thumbsAgain, layerActionsBuilt, opacityRowReady, panelRefreshing;
    private LayerDrag layerDrag;
    private LinearLayout selectionPanelRow;
    private TextView selectionPanelText;

    private void buildLayersPanel() {
        final Project p = canvas.getProject();
        if (p == null || panelRefreshing) return;
        if (layerDrag != null && layerDrag.active) return;
        panelRefreshing = true;
        try {
            buildViewBg();
            setupOpacityRow();
            updateOpacityRow();

            LinearLayout list = findViewById(R.id.layersList);
            java.util.IdentityHashMap<Layer, Boolean> alive = new java.util.IdentityHashMap<Layer, Boolean>();
            for (Layer l : p.layers) alive.put(l, Boolean.TRUE);
            for (Layer l : new ArrayList<Layer>(rowHolders.keySet()))
                if (!alive.containsKey(l)) rowHolders.remove(l);
            for (Layer l : new ArrayList<Layer>(thumbCache.keySet())) {
                if (!alive.containsKey(l)) {
                    Bitmap old = thumbCache.remove(l);
                    if (old != null && !old.isRecycled()) old.recycle();
                }
            }

            boolean hasMask = p.hasSelection();
            if (hasMask) ensureSelectionPanelRow();
            int n = p.layers.size(), offset = hasMask ? 1 : 0;
            boolean same = list.getChildCount() == n + offset
                    && (!hasMask || list.getChildAt(0) == selectionPanelRow);
            for (int pos = 0; pos < n; pos++) {
                Layer l = p.layers.get(n - 1 - pos);
                RowHolder h = rowHolders.get(l);
                if (h == null) {
                    h = makeRow(l);
                    rowHolders.put(l, h);
                    same = false;
                } else if (same && list.getChildAt(pos + offset) != h.row) {
                    same = false;
                }
            }
            if (!same) {
                list.removeAllViews();
                if (hasMask) list.addView(selectionPanelRow);
                for (int pos = 0; pos < n; pos++) {
                    RowHolder h = rowHolders.get(p.layers.get(n - 1 - pos));
                    h.row.setTranslationY(0f);
                    list.addView(h.row);
                }
            }
            if (hasMask) bindSelectionPanelRow(p);
            for (int i = 0; i < n; i++) bindRow(rowHolders.get(p.layers.get(i)), i == p.active);
            if (!layerActionsBuilt) {
                buildLayerActions();
                layerActionsBuilt = true;
            }
        } finally {
            panelRefreshing = false;
        }
        requestThumbs();
    }

    private void ensureSelectionPanelRow() {
        if (selectionPanelRow != null) return;
        selectionPanelRow = rowBase(false);
        ImageView icon = thumb(null);
        icon.setImageResource(R.drawable.ic_select);
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));
        selectionPanelText = rowText("Seleccion", "Lo azul", true);
        ImageButton clear = iconButton(R.drawable.ic_close, "Quitar seleccion", new Runnable() {
            @Override public void run() {
                canvas.clearSelection();
                buildLayersPanel();
            }
        });
        clear.setBackground(null);
        selectionPanelRow.addView(icon);
        selectionPanelRow.addView(selectionPanelText);
        selectionPanelRow.addView(clear);
        selectionPanelRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Project p = canvas.getProject();
                if (p == null) return;
                canvas.setActive(Project.SEL);
                buildLayersPanel();
            }
        });
    }

    private void bindSelectionPanelRow(Project p) {
        if (selectionPanelRow == null || p == null) return;
        boolean on = p.active == Project.SEL;
        selectionPanelRow.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        selectionPanelText.setText("Seleccion\n" + (p.hasSelection() ? "Azul activo - toca para editar" : "Vacia - pinta o usa Varita"));
        selectionPanelText.setTextColor(p.hasSelection() ? 0xFFFFFFFF : 0xFF9A9A9A);
    }

    private void bindRow(RowHolder h, boolean on) {
        Layer l = h.layer;
        h.row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        h.row.setPadding(dp(6), dp(6), dp(2), dp(6));
        StringBuilder sub = new StringBuilder();
        sub.append(l.opacity * 100 / 255).append('%');
        if (l.mode != Layer.MODE_NORMAL) sub.append("  ").append(Layer.MODE_NAMES[l.mode]);
        if (l.alphaLock) sub.append("  alfa bloq.");
        if (l.reference) sub.append("  ref. balde");
        if (l.locked) sub.append("  BLOQUEADA");
        if (l.hasAdjust()) sub.append("  color cambiado");
        h.text.setText((l.clip ? "\u21B3 " : "") + l.name + "\n" + sub);
        // la capa con recorte va corrida a la derecha, como en Ibis
        ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) h.row.getLayoutParams();
        int want = l.clip ? dp(18) : 0;
        if (mlp != null && mlp.leftMargin != want) {
            mlp.leftMargin = want;
            h.row.setLayoutParams(mlp);
        }
        h.text.setTextColor(l.visible ? 0xFFFFFFFF : 0xFF7A7A7A);
        h.eye.setImageResource(l.visible ? R.drawable.ic_eye : R.drawable.ic_eye_off);
        h.eye.setContentDescription(l.visible ? "Ocultar" : "Mostrar");
        Bitmap tb = thumbCache.get(l);
        if (tb != null && h.thumb.getTag() != tb) {
            h.thumb.setImageBitmap(tb);
            h.thumb.setTag(tb);
        }
    }

    private RowHolder makeRow(final Layer l) {
        final RowHolder h = new RowHolder();
        h.layer = l;
        h.row = rowBase(false);
        h.thumb = thumb(null);
        h.thumb.setBackgroundColor(0xFF3A3A40);
        h.text = rowText(l.name, "", true);
        h.eye = iconButton(R.drawable.ic_eye, "Ocultar o mostrar", new Runnable() {
            public void run() {
                canvas.recordPropsUndo(l.visible ? "Ocultar capa" : "Mostrar capa");
                l.visible = !l.visible;
                bindRow(h, canvas.getProject().activeLayer() == l);
                canvas.layersChangedAsync();
            }
        });
        h.eye.setBackground(null);
        ImageView handle = new ImageView(this);
        handle.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(48)));
        handle.setPadding(dp(8), dp(12), dp(8), dp(12));
        handle.setScaleType(ImageView.ScaleType.FIT_CENTER);
        handle.setImageResource(R.drawable.ic_drag);
        handle.setContentDescription("Arrastra para subir o bajar la capa");
        h.row.addView(h.thumb);
        h.row.addView(h.text);
        h.row.addView(h.eye);
        h.row.addView(handle);
        h.row.setOnTouchListener(new RowTouch(h, false));
        handle.setOnTouchListener(new RowTouch(h, true));
        return h;
    }

    /** Toque corto: elige la capa (o abre sus opciones si ya era la elegida). Mantener: arrastrar. */
    private void onRowTap(RowHolder h) {
        Project p = canvas.getProject();
        if (p == null) return;
        int idx = p.layers.indexOf(h.layer);
        if (idx < 0) return;
        if (idx == p.active) layerOptions(h.layer);
        else canvas.setActive(idx); // avisa por onChanged y el panel se actualiza solo
    }

    private final class RowTouch implements View.OnTouchListener {
        final RowHolder h;
        final boolean handle;
        float downX, downY, lastY;
        boolean pressed, dragging;
        final Runnable longPress;

        RowTouch(final RowHolder h, boolean handle) {
            this.h = h;
            this.handle = handle;
            longPress = new Runnable() {
                @Override
                public void run() {
                    if (pressed && !dragging) {
                        dragging = true;
                        h.row.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        startDrag(h, lastY);
                    }
                }
            };
        }

        @Override
        public boolean onTouch(View v, android.view.MotionEvent e) {
            int slop = android.view.ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = lastY = e.getRawY();
                    pressed = true;
                    dragging = false;
                    if (handle) {
                        dragging = true;
                        startDrag(h, lastY);
                    } else {
                        h.row.postDelayed(longPress, android.view.ViewConfiguration.getLongPressTimeout());
                    }
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    lastY = e.getRawY();
                    if (dragging) {
                        if (layerDrag != null) layerDrag.move(lastY);
                    } else if (Math.abs(e.getRawX() - downX) > slop || Math.abs(lastY - downY) > slop) {
                        pressed = false;
                        h.row.removeCallbacks(longPress);
                    }
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                    h.row.removeCallbacks(longPress);
                    if (dragging) {
                        if (layerDrag != null) layerDrag.finish();
                    } else if (pressed && !handle) {
                        onRowTap(h);
                    }
                    pressed = dragging = false;
                    return true;
                case android.view.MotionEvent.ACTION_CANCEL:
                    h.row.removeCallbacks(longPress);
                    if (dragging && layerDrag != null) layerDrag.finish();
                    pressed = dragging = false;
                    return true;
            }
            return false;
        }
    }

    private void startDrag(RowHolder h, float rawY) {
        if (layerDrag != null && layerDrag.active) return;
        layerDrag = new LayerDrag(h, rawY);
    }

    /** Arrastrar una capa como en Ibis: las demas se corren para hacerle espacio. */
    private final class LayerDrag {
        final RowHolder h;
        final LinearLayout list;
        final ScrollView scroll;
        final float startY;
        final int startScroll, from, n;
        final float pitch;
        int to;
        boolean active = true;

        LayerDrag(RowHolder h, float rawY) {
            this.h = h;
            list = findViewById(R.id.layersList);
            scroll = findViewById(R.id.layersScroll);
            startY = rawY;
            startScroll = scroll.getScrollY();
            from = to = list.indexOfChild(h.row);
            n = list.getChildCount();
            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) h.row.getLayoutParams();
            pitch = h.row.getHeight() + lp.topMargin + lp.bottomMargin;
            scroll.requestDisallowInterceptTouchEvent(true);
            canvas.setCompactHold(true);
            h.row.setElevation(dp(10));
            h.row.animate().scaleX(1.03f).scaleY(1.03f).alpha(0.94f).setDuration(90).start();
            if (from < 0 || pitch <= 0) active = false;
        }

        void move(float rawY) {
            if (!active) return;
            int[] loc = new int[2];
            scroll.getLocationOnScreen(loc);
            float yIn = rawY - loc[1];
            int edge = dp(40);
            if (yIn < edge) scroll.scrollBy(0, -dp(12));
            else if (yIn > scroll.getHeight() - edge) scroll.scrollBy(0, dp(12));
            float dy = (rawY - startY) + (scroll.getScrollY() - startScroll);
            // La fila 0 es la capa Seleccion y no forma parte del orden de capas.
            // Nunca dejamos que una capa normal se arrastre por encima de ella.
            int firstLayerRow = selectionPanelRow != null && list.getChildAt(0) == selectionPanelRow ? 1 : 0;
            float min = (firstLayerRow - from) * pitch, max = (n - 1 - from) * pitch;
            if (dy < min) dy = min;
            if (dy > max) dy = max;
            h.row.setTranslationY(dy);
            int t = Math.round(from + dy / pitch);
            t = Math.max(firstLayerRow, Math.min(n - 1, t));
            if (t == to) return;
            to = t;
            for (int k = 0; k < n; k++) {
                if (k == from) continue;
                View c = list.getChildAt(k);
                float want = 0f;
                if (from < to && k > from && k <= to) want = -pitch;
                else if (from > to && k >= to && k < from) want = pitch;
                if (c.getTranslationY() != want) c.animate().translationY(want).setDuration(110).start();
            }
        }

        void finish() {
            if (!active) return;
            active = false;
            float dy = h.row.getTranslationY();
            for (int k = 0; k < list.getChildCount(); k++) {
                View c = list.getChildAt(k);
                c.animate().cancel();
                if (c != h.row) c.setTranslationY(0f);
            }
            if (to != from && from >= 0) {
                list.removeView(h.row);
                list.addView(h.row, to);
                h.row.setTranslationY(dy - (to - from) * pitch);
                int fromIdx = n - 1 - from, toIdx = n - 1 - to;
                canvas.moveLayer(fromIdx, toIdx);
            }
            h.row.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(1f).setDuration(120)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            h.row.setElevation(0f);
                        }
                    }).start();
            canvas.setCompactHold(false);
            buildLayersPanel();
        }

        void cancel() {
            if (!active) return;
            to = from;
            finish();
        }
    }

    /** Miniaturas en segundo plano: se ve la anterior hasta que llega la nueva. */
    private void requestThumbs() {
        if (!layersOpen()) return;
        if (thumbsBusy) {
            thumbsAgain = true;
            return;
        }
        final Project p = canvas.getProject();
        if (p == null) return;
        thumbsBusy = true;
        thumbsAgain = false;
        final List<Layer> ls = new ArrayList<Layer>(p.layers);
        final Bitmap[] out = new Bitmap[ls.size()];
        thumbPool.execute(new Runnable() {
            @Override
            public void run() {
                for (int k = 0; k < ls.size(); k++) {
                    try {
                        out[k] = Thumbs.forLayer(p, ls.get(k), 96);
                    } catch (Throwable ignored) {
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (destroyed) {
                            for (Bitmap b : out) if (b != null && !b.isRecycled()) b.recycle();
                            return;
                        }
                        thumbsBusy = false;
                        if (canvas.getProject() == p) {
                            for (int k = 0; k < ls.size(); k++) {
                                if (out[k] == null) continue;
                                thumbCache.put(ls.get(k), out[k]);
                                RowHolder h = rowHolders.get(ls.get(k));
                                if (h != null) {
                                    h.thumb.setImageBitmap(out[k]);
                                    h.thumb.setTag(out[k]);
                                }
                            }
                        }
                        if (thumbsAgain) requestThumbs();
                    }
                });
            }
        });
    }

    /** Opacidad arriba, fija, como en Ibis: se ve al momento y sin trabarse. */
    private void setupOpacityRow() {
        if (opacityRowReady) return;
        opacityRowReady = true;
        SeekBar ob = findViewById(R.id.layersOpBar);
        ob.setMax(100);
        ob.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (!u) return;
                Project p = canvas.getProject();
                Layer l = p == null ? null : p.activeLayer();
                if (l == null) return;
                l.opacity = Math.round(v * 255 / 100f);
                ((TextView) findViewById(R.id.layersOpText)).setText("Opacidad " + v + "%");
                RowHolder h = rowHolders.get(l);
                if (h != null) bindRow(h, true);
                canvas.refreshDisplayAsync();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                canvas.recordPropsUndo("Opacidad de capa");
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                canvas.layersChangedAsync();
            }
        });
    }

    private void updateOpacityRow() {
        Project p = canvas.getProject();
        Layer l = p == null ? null : p.activeLayer();
        SeekBar ob = findViewById(R.id.layersOpBar);
        TextView ot = findViewById(R.id.layersOpText);
        ob.setEnabled(l != null);
        int v = l == null ? 100 : l.opacity * 100 / 255;
        if (ob.getProgress() != v) ob.setProgress(v);
        ot.setText("Opacidad " + v + "%");
    }

    /** Fondo para mirar: cuadros claros, cuadros oscuros, blanco, negro, verde. */
    private void buildViewBg() {
        LinearLayout row = findViewById(R.id.viewBgRow);
        if (row.getChildCount() != CanvasView.VIEW_BG.length) {
            row.removeAllViews();
            for (int k = 0; k < CanvasView.VIEW_BG.length; k++) {
                final int idx = k;
                View sw = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
                lp.setMargins(dp(3), 0, dp(3), 0);
                sw.setLayoutParams(lp);
                sw.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        canvas.setViewBg(idx);
                        buildViewBg();
                    }
                });
                row.addView(sw);
            }
        }
        for (int k = 0; k < CanvasView.VIEW_BG.length; k++) {
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(6));
            int[] c = CanvasView.VIEW_BG[k];
            if (c[0] != c[1]) g.setColors(new int[]{c[0], c[1]});
            else g.setColor(c[0]);
            boolean on = canvas.getViewBg() == k;
            g.setStroke(dp(on ? 3 : 1), on ? 0xFF2F6BD8 : 0xFF777777);
            row.getChildAt(k).setBackground(g);
        }
    }

    /**
     * Botones de abajo del panel (v8.24): las 4 acciones principales y "Mas".
     * Lo secundario va en el menu "Mas" para que los textos no se corten en
     * telefonos chicos y no haya iconos repetidos para cosas distintas.
     */
    private void buildLayerActions() {
        LinearLayout bar = findViewById(R.id.layersActions);
        bar.removeAllViews();
        addAction(bar, R.drawable.ic_add, "Nueva", new Runnable() {
            public void run() {
                Project pj = canvas.getProject();
                Layer below = pj == null ? null : pj.activeLayer();
                canvas.addEmptyLayer();
                afterLayerOp();
                askClipNewLayer(below);
            }
        });
        addAction(bar, R.drawable.ic_dup, "Duplicar", new Runnable() {
            public void run() {
                canvas.duplicateActive();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_merge, "Combinar", new Runnable() {
            public void run() {
                canvas.mergeDown();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_trash, "Eliminar", new Runnable() {
            public void run() {
                canvas.deleteActive();
                afterLayerOp();
            }
        });
        // v8.28: la referencia de color vuelve a estar a la vista en Capas (captura 3: no se
        // encontraba dentro de "Mas"). NO crea capa: abre la ventana de referencia.
        addAction(bar, R.drawable.ic_ref_color, "Ref. color", new Runnable() {
            public void run() {
                requestColorReference(paintColorTarget());
            }
        });
        addAction(bar, R.drawable.ic_menu, "Mas", new Runnable() {
            public void run() {
                layersMoreMenu();
            }
        });
    }

    /** Menu "Mas" del panel de capas. "Crear capa desde la seleccion" solo aparece si hay seleccion. */
    /**
     * v8.29: "Mas" de Capas con ICONOS (sin lista de textos). Mantener pulsado un icono dice su nombre.
     */
    private void layersMoreMenu() {
        final Project p = canvas.getProject();
        if (p == null) return;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(10), dp(14), dp(10), dp(14));
        final AlertDialog[] dlg = new AlertDialog[1];
        java.util.List<Object[]> items = new java.util.ArrayList<Object[]>();
        if (p.hasSelection()) items.add(new Object[]{R.drawable.ic_layer_add, "Capa con lo seleccionado", new Runnable() {
            public void run() { partFromSelectionDialog(false); }
        }});
        items.add(new Object[]{R.drawable.ic_lineart, "Separar las lineas en una capa", new Runnable() {
            public void run() { linesDialog(); }
        }});
        items.add(new Object[]{R.drawable.ic_broom, "Limpiar la capa (borra todo lo que tiene)", new Runnable() {
            public void run() { canvas.clearActive(); afterLayerOp(); }
        }});
        if (p.activeLayer() != null) items.add(new Object[]{R.drawable.ic_tune, "Opciones de la capa", new Runnable() {
            public void run() {
                Layer l = canvas.getProject() == null ? null : canvas.getProject().activeLayer();
                if (l != null) layerOptions(l);
            }
        }});
        for (final Object[] it : items) {
            ImageButton b = iconButton((Integer) it[0], (String) it[1], new Runnable() {
                public void run() {
                    if (dlg[0] != null) dlg[0].dismiss();
                    ((Runnable) it[2]).run();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(54));
            lp.setMargins(dp(6), 0, dp(6), 0);
            b.setLayoutParams(lp);
            b.setPadding(dp(12), dp(12), dp(12), dp(12));
            row.addView(b);
        }
        dlg[0] = new AlertDialog.Builder(this).setView(row).create();
        dlg[0].show();
    }

    /**
     * v8.24 "Lineas": separa las lineas del dibujo en una capa transparente, con vista
     * previa a tamano real. Avisa si la imagen es a color (ahi se usan solo los
     * trazos finos, para no tomar sombras ni zonas oscuras como linea).
     */
    private void linesDialog() {
        if (!needProject()) return;
        final com.pacco.animecut.core.LineArt.Extract ex = new com.pacco.animecut.core.LineArt.Extract();
        ex.colored = canvas.activeLooksColored();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(4));
        TextView info = new TextView(this);
        info.setTextColor(0xFFCCCCCC);
        info.setTextSize(13f);
        info.setText(ex.colored
                ? "ATENCION: la imagen es a color. Solo se separan los trazos finos y oscuros; el pelo oscuro, "
                + "la ropa y las sombras NO cuentan como linea. Revisa la vista previa: con imagenes a color "
                + "el resultado puede no ser perfecto."
                : "Crea una capa nueva encima con las lineas sobre fondo transparente. Tu dibujo original no cambia. "
                + "Sirve para pintar debajo de las lineas sin taparlas.");
        root.addView(info);
        final ImageView prev = new ImageView(this);
        prev.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(200)));
        prev.setScaleType(ImageView.ScaleType.FIT_CENTER);
        prev.setBackgroundColor(0xFFB0D0F0); // fondo de color: se ve que el papel quedo transparente
        prev.setPadding(0, dp(8), 0, dp(8));
        root.addView(prev);
        TextView ph = new TextView(this);
        ph.setText("Vista previa a tamano real del centro de la pantalla, sobre fondo celeste");
        ph.setTextColor(0xFF999999);
        ph.setTextSize(11f);
        root.addView(ph);
        final TextView t1 = new TextView(this), t2 = new TextView(this);
        t1.setTextColor(0xFFFFFFFF);
        t2.setTextColor(0xFFFFFFFF);
        final SeekBar s1 = new SeekBar(this), s2 = new SeekBar(this);
        if (ex.colored) {
            s1.setMax(12); s1.setProgress(ex.maxWidth - 1);
            s2.setMax(120); s2.setProgress(ex.contrast);
        } else {
            s1.setMax(255); s1.setProgress(ex.white);
            s2.setMax(255); s2.setProgress(ex.black);
        }
        root.addView(t1); root.addView(s1); root.addView(t2); root.addView(s2);
        final CheckBox withColor = new CheckBox(this);
        withColor.setText("Crear tambien una capa \"Color\" debajo de las lineas para pintar");
        withColor.setTextColor(0xFFFFFFFF);
        withColor.setChecked(true);
        root.addView(withColor);
        final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable[] refresh = new Runnable[1];
        refresh[0] = new Runnable() {
            @Override public void run() {
                if (ex.colored) {
                    ex.maxWidth = s1.getProgress() + 1;
                    ex.contrast = s2.getProgress();
                    t1.setText("Grosor maximo de linea: " + ex.maxWidth + " px");
                    t2.setText("Contraste minimo del trazo: " + ex.contrast + " (mas alto: menos sombras)");
                } else {
                    ex.white = s1.getProgress();
                    ex.black = Math.min(s2.getProgress(), ex.white - 1);
                    t1.setText("Blanco (lo que se vuelve transparente): " + ex.white);
                    t2.setText("Negro (lo que queda como linea llena): " + ex.black);
                }
                final com.pacco.animecut.core.LineArt.Extract snap = new com.pacco.animecut.core.LineArt.Extract();
                snap.colored = ex.colored; snap.white = ex.white; snap.black = ex.black;
                snap.maxWidth = ex.maxWidth; snap.contrast = ex.contrast;
                new Thread(new Runnable() {
                    @Override public void run() {
                        final int[] r = canvas.previewLines(snap, 300);
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (r == null || destroyed) return;
                                Bitmap b = Bitmap.createBitmap(r, 2, r[0], r[0], r[1], Bitmap.Config.ARGB_8888);
                                prev.setImageBitmap(b);
                            }
                        });
                    }
                }).start();
            }
        };
        SimpleSeek seek = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
                hd.removeCallbacks(refresh[0]);
                hd.postDelayed(refresh[0], 150);
            }
        };
        s1.setOnSeekBarChangeListener(seek);
        s2.setOnSeekBarChangeListener(seek);
        refresh[0].run();
        new AlertDialog.Builder(this)
                .setTitle("Lineas")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear capa", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        canvas.extractLinesLayer(ex, withColor.isChecked());
                        afterLayerOp();
                    }
                })
                .show();
    }

    private void addAction(LinearLayout bar, int icon, String name, final Runnable r) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(android.view.Gravity.CENTER);
        cell.setPadding(dp(2), dp(6), dp(2), dp(6));
        cell.setBackgroundResource(R.drawable.bg_cell);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        clp.setMargins(dp(2), 0, dp(2), 0);
        cell.setLayoutParams(clp);
        ImageView img = new ImageView(this);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(24), dp(24));
        ilp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        img.setLayoutParams(ilp);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageResource(icon);
        cell.addView(img);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFDDDDDD);
        t.setTextSize(10f);
        t.setSingleLine(true);
        t.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, dp(3), 0, 0);
        cell.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        bar.addView(cell);
    }

    /**
     * v8.36: capa nueva encima de un dibujo recortado (con fondo transparente): se pregunta si
     * lo pintado debe verse SOLO dentro del dibujo (Recorte). Asi pasarse del borde no ensucia
     * el fondo transparente. "No volver a preguntar" recuerda la respuesta; se cambia tocando la
     * capa elegida > Recorte.
     */
    private void askClipNewLayer(final Layer below) {
        final Layer nl = canvas.getProject() == null ? null : canvas.getProject().activeLayer();
        if (below == null || nl == null || nl == below || !canvas.layerHasTransparency(below)) return;
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (!sp.getBoolean("clip_new_ask", true)) {
            if (sp.getBoolean("clip_new_on", true)) setClipQuiet(nl);
            return;
        }
        final CheckBox remember = new CheckBox(this);
        remember.setText("No volver a preguntar");
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(remember);
        new AlertDialog.Builder(this)
                .setTitle("Pintar solo dentro del dibujo?")
                .setMessage("Lo que pintes fuera del personaje no se vera.")
                .setView(box)
                .setPositiveButton("Solo dentro", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (remember.isChecked()) sp.edit().putBoolean("clip_new_ask", false).putBoolean("clip_new_on", true).apply();
                        setClipQuiet(nl);
                    }
                })
                .setNegativeButton("Libre", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (remember.isChecked()) sp.edit().putBoolean("clip_new_ask", false).putBoolean("clip_new_on", false).apply();
                    }
                })
                .show();
    }

    private void setClipQuiet(Layer l) {
        canvas.setLayerClip(l, true);
        canvas.showHud("Solo dentro del dibujo · se cambia tocando la capa", 2200);
        afterLayerOp();
    }

    // ------------------------------------------------------------------ v8.37 B/N
    private com.pacco.animecut.core.GrayView loadGrayView() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        com.pacco.animecut.core.GrayView g = new com.pacco.animecut.core.GrayView();
        g.channel = Math.max(0, Math.min(3, sp.getInt("bg_gray_ch", 0)));
        g.saturation = Math.max(0, Math.min(100, sp.getInt("bg_gray_sat", 0)));
        g.contrast = Math.max(-100, Math.min(100, sp.getInt("bg_gray_con", 0)));
        g.brightness = Math.max(-100, Math.min(100, sp.getInt("bg_gray_bri", 0)));
        return g;
    }

    private void saveGrayView(com.pacco.animecut.core.GrayView g) {
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_gray_ch", g.channel).putInt("bg_gray_sat", g.saturation)
                .putInt("bg_gray_con", g.contrast).putInt("bg_gray_bri", g.brightness).apply();
    }

    /**
     * v8.38: ajustes del B/N en una barra CHICA pegada abajo (justo encima de las herramientas):
     * el lienzo queda a la vista mientras mueves el brillo o el contraste. Todo se guarda al
     * momento (apagar y prender B/N lo deja igual). Ver color: mira tu color un momento sin
     * perder el ajuste. La barra no bloquea el lienzo: puedes seguir usando el Balde.
     */
    private PopupWindow grayPop;

    private void grayDialog() {
        if (grayPop != null && grayPop.isShowing()) { grayPop.dismiss(); return; }
        final com.pacco.animecut.core.GrayView g = canvas.getBgGrayView();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(6));
        android.graphics.drawable.GradientDrawable bgd = new android.graphics.drawable.GradientDrawable();
        bgd.setColor(0xE6202024);
        bgd.setCornerRadius(dp(14));
        box.setBackground(bgd);
        // fila 1: de que color sale el gris
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER_VERTICAL);
        final TextView[] ch = new TextView[4];
        for (int k = 0; k < 4; k++) {
            final int which = k;
            ch[k] = smallTextButton(com.pacco.animecut.core.GrayView.CH_NAMES[k]);
            ch[k].setBackgroundResource(k == g.channel ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            ch[k].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    g.channel = which;
                    for (int j = 0; j < 4; j++) ch[j].setBackgroundResource(j == which ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                    canvas.setBgGrayView(g);
                    saveGrayView(g);
                }
            });
            chips.addView(ch[k]);
        }
        box.addView(chips);
        // filas 2-4: tres barras cortas
        final SeekBar sat = grayRow(box, "Saturacion", 100, g.saturation);
        final SeekBar con = grayRow(box, "Contraste", 200, g.contrast + 100);
        final SeekBar bri = grayRow(box, "Brillo", 200, g.brightness + 100);
        SeekBar.OnSeekBarChangeListener live = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean user) {
                g.saturation = sat.getProgress();
                g.contrast = con.getProgress() - 100;
                g.brightness = bri.getProgress() - 100;
                canvas.setBgGrayView(g);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { saveGrayView(g); }
        };
        sat.setOnSeekBarChangeListener(live);
        con.setOnSeekBarChangeListener(live);
        bri.setOnSeekBarChangeListener(live);
        // fila 5: Ver color · De fabrica · Apagar · Listo
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        final TextView peek = smallTextButton(canvas.isBgGrayPeek() ? "Ver B/N" : "Ver color");
        peek.setBackgroundResource(canvas.isBgGrayPeek() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        peek.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !canvas.isBgGrayPeek();
                canvas.setBgGrayPeek(on);
                peek.setText(on ? "Ver B/N" : "Ver color");
                peek.setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            }
        });
        TextView reset = smallTextButton("De fabrica");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                g.reset();
                sat.setProgress(g.saturation);
                con.setProgress(g.contrast + 100);
                bri.setProgress(g.brightness + 100);
                for (int j = 0; j < 4; j++) ch[j].setBackgroundResource(j == g.channel ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                canvas.setBgGrayView(g);
                saveGrayView(g);
            }
        });
        TextView off = smallTextButton("Apagar B/N");
        off.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveGrayView(g);
                canvas.setBgGray(false);
                canvas.showHud("Color original");
                if (grayPop != null) grayPop.dismiss();
                updateUi();
            }
        });
        TextView done = smallTextButton("Listo");
        done.setBackgroundResource(R.drawable.bg_tool_on);
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveGrayView(g);
                if (canvas.isBgGrayPeek()) canvas.setBgGrayPeek(false);
                if (grayPop != null) grayPop.dismiss();
            }
        });
        btns.addView(peek);
        btns.addView(reset);
        btns.addView(off);
        btns.addView(done);
        box.addView(btns);
        View bar = findViewById(R.id.optBar);
        int w = getResources().getDisplayMetrics().widthPixels - dp(16);
        grayPop = new PopupWindow(box, w, ViewGroup.LayoutParams.WRAP_CONTENT, false);
        grayPop.setOutsideTouchable(false);
        grayPop.setTouchable(true);
        // justo encima de la barra de herramientas: el lienzo queda libre arriba
        int[] loc = new int[2];
        bar.getLocationInWindow(loc);
        int screenH = getWindow().getDecorView().getHeight();
        int y = Math.max(0, screenH - loc[1] + dp(4));
        grayPop.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, y);
    }

    private void closeGrayPop() {
        if (grayPop != null && grayPop.isShowing()) grayPop.dismiss();
        grayPop = null;
    }

    private SeekBar grayRow(LinearLayout box, String name, int max, int val) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(12f);
        row.addView(t, new LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(val);
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(32), 1f));
        box.addView(row);
        return sb;
    }

    private void afterLayerOp() {
        if (layersOpen()) buildLayersPanel();
        updateUi();
    }

    private void layerOptions(final Layer l) {
        final String[] items = {
                "Modo de mezcla: " + Layer.MODE_NAMES[l.mode],
                l.clip ? "Recorte (solo dentro de la capa de abajo): SI" : "Recorte (solo dentro de la capa de abajo): NO",
                l.alphaLock ? "Bloquear alfa (pintar solo sobre lo dibujado): SI" : "Bloquear alfa (pintar solo sobre lo dibujado): NO",
                l.reference ? "Referencia del balde (los contornos salen de esta capa): SI"
                        : "Referencia del balde (los contornos salen de esta capa): NO",
                "Cambiar nombre",
                "Exportar solo esta capa",
                l.locked ? "Bloqueo total (no se puede pintar ni mover): SI" : "Bloqueo total (no se puede pintar ni mover): NO",
                l.hasAdjust() ? "Cambiar color (tono " + signed(l.hue) + ", sat. " + signed(l.sat) + ", luz " + signed(l.lit) + ")"
                        : "Cambiar color (tono, saturacion, luminosidad)",
                l.hasAdjust() ? "Fijar el cambio de color en los pixeles" : "Fijar cambio de color (no hay cambios)"};
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                modeDialog(l);
                                break;
                            case 1:
                                canvas.setLayerClip(l, !l.clip);
                                canvas.showHud(l.clip ? "Recorte: la capa solo se ve dentro de la de abajo" : "Recorte apagado");
                                buildLayersPanel();
                                break;
                            case 2:
                                canvas.setLayerAlphaLock(l, !l.alphaLock);
                                canvas.showHud(l.alphaLock ? "Alfa bloqueado: solo se pinta sobre lo que ya hay" : "Alfa libre");
                                buildLayersPanel();
                                break;
                            case 3:
                                canvas.setLayerReference(l, !l.reference);
                                canvas.showHud(l.reference
                                        ? "El balde toma los contornos de las capas marcadas como referencia"
                                        : "Referencia del balde quitada");
                                buildLayersPanel();
                                break;
                            case 4:
                                renameDialog(l);
                                break;
                            case 6:
                                canvas.setLayerLocked(l, !l.locked);
                                canvas.showHud(l.locked ? "Capa bloqueada: no se puede pintar, borrar ni mover" : "Capa desbloqueada");
                                buildLayersPanel();
                                break;
                            case 7:
                                changeColorDialog(l);
                                break;
                            case 8:
                                if (l.hasAdjust()) {
                                    canvas.bakeLayerAdjust(l);
                                    canvas.showHud("Color fijado en los pixeles (se puede deshacer)");
                                    buildLayersPanel();
                                }
                                break;
                            default:
                                pendingFlatExport = false;
                                pendingLayerExport = l;
                                createPng.launch(l.name + ".png");
                                break;
                        }
                    }
                })
                .show();
    }

    /** Modos de mezcla mas usados para anime, con para que sirve cada uno. */
    private void modeDialog(final Layer l) {
        final String[] items = {
                "Normal",
                "Multiplicar: sombras y la linea (el blanco se vuelve invisible)",
                "Pantalla: luces suaves",
                "Anadir (brillo): brillos fuertes y ojos",
                "Superponer: ambiente y color sobre gris",
                "Color: tine grises y tramas sin oscurecerlos"};
        new AlertDialog.Builder(this)
                .setTitle("Modo de mezcla")
                .setSingleChoiceItems(items, l.mode, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        d.dismiss();
                        canvas.setLayerMode(l, i);
                        canvas.showHud("Modo: " + Layer.MODE_NAMES[i]);
                        buildLayersPanel();
                    }
                })
                .show();
    }

    // ==================================================================
    // Menu de tres puntos
    // ==================================================================

    private void mainMenu() {
        final List<String> items = new ArrayList<String>();
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        items.add("Preparar personaje (pasos rapidos)");
        items.add(canvas.isMangaMode() ? "Colorear manga: opciones" : "Colorear manga (preparar capas)");
        items.add("Guia rapida: como se usa");
        items.add("Que hace cada herramienta");
        items.add("Encuadrar la imagen");
        items.add("Restablecer vista (sin giro ni volteo)");
        items.add(canvas.isViewFlipped() ? "Voltear la vista (espejo): SI" : "Voltear la vista (espejo): NO");
        items.add(canvas.isRotateEnabled() ? "Girar el lienzo con dos dedos: SI" : "Girar el lienzo con dos dedos: NO");
        items.add(canvas.isAim() ? "Cursor separado con lupa: SI" : "Cursor separado con lupa: NO");
        items.add(sp.getBoolean("demo_on", true) ? "Animacion al elegir herramienta: SI"
                : "Animacion al elegir herramienta: NO");
        items.add(canvas.isSmoothZoom() ? "Zoom suave (como la galeria): SI" : "Zoom suave (como la galeria): NO");
        items.add("Abrir otra imagen");
        items.add("Agregar una imagen como capa");
        items.add(colorRefBitmap != null ? "Referencia de color: CAMBIAR" : "Importar referencia de color");
        if (colorRefBitmap != null) items.add("Quitar referencia de color");
        items.add(canvas.isFlatPaint() ? "Repasar no oscurece (pintado plano): SI" : "Repasar no oscurece (pintado plano): NO");
        items.add("Filtros de la capa");
        items.add("Girar la imagen");
        items.add("Ampliar lienzo (agregar espacio)");
        items.add("Estabilizador del trazo");
        items.add("Dureza del pincel");
        items.add("Borrar fondo: ajustes avanzados");
        items.add("Medir rendimiento (prueba en este telefono)");
        items.add("Guardar ahora");
        items.add("Guardar copia en un archivo");
        new AlertDialog.Builder(this)
                .setTitle("Paint Zeta")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        runMenu(items.get(i));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void runMenu(String item) {
        if (item.startsWith("Preparar personaje (pasos rapidos)")) {
            animationWorkflowDialog();
        } else if (item.startsWith("Colorear manga")) {
            mangaEntry();
        } else if (item.startsWith("Guia")) {
            guideDialog();
        } else if (item.startsWith("Que hace")) {
            toolCardsList();
        } else if (item.startsWith("Encuadrar")) {
            if (needProject()) canvas.fit();
        } else if (item.startsWith("Restablecer vista")) {
            if (needProject()) canvas.resetView();
        } else if (item.startsWith("Voltear la vista")) {
            if (needProject()) canvas.toggleViewFlip();
        } else if (item.startsWith("Girar el lienzo con dos dedos")) {
            boolean on = !canvas.isRotateEnabled();
            canvas.setRotateEnabled(on);
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("rotate_view", on).apply();
            canvas.showHud(on ? "Dos dedos: mover, ampliar y GIRAR" : "Dos dedos: solo mover y ampliar");
        } else if (item.startsWith("Cursor")) {
            canvas.setAim(!canvas.isAim());
            canvas.showHud(canvas.isAim() ? "Cursor separado del dedo, con lupa" : "Cursor normal");
        } else if (item.startsWith("Ver en rojo")) {
            canvas.previewAutoLines();
        } else if (item.startsWith("Varita no se escapa")) {
            boolean on = !canvas.isAutoLines();
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("auto_lines", on).apply();
            canvas.setAutoLines(on);
            canvas.showHud(on ? "La varita respeta la linea negra aunque tenga cortes" : "Varita normal");
            if (on) canvas.previewAutoLines();
        } else if (item.startsWith("Zoom suave")) {
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean on = !canvas.isSmoothZoom();
            sp.edit().putBoolean("smooth_zoom", on).apply();
            canvas.setSmoothZoom(on);
            canvas.showHud(on ? "Zoom suave" : "Zoom con pixeles marcados, para bordes exactos");
        } else if (item.startsWith("Animacion")) {
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean on = !sp.getBoolean("demo_on", true);
            sp.edit().putBoolean("demo_on", on).apply();
            toast(on ? "Animacion al elegir herramienta: SI" : "Animaciones apagadas");
        } else if (item.startsWith("Ampliar lienzo")) {
            enlargeCanvasDialog();
        } else if (item.startsWith("Medir rendimiento")) {
            perfDialog();
        } else if (item.startsWith("Borrar fondo: ajustes")) {
            bgSettingsDialog();
        } else if (item.startsWith("Abrir otra")) {
            autosave(false);
            openImage.launch("image/*");
        } else if (item.startsWith("Agregar una imagen")) {
            addImage.launch("image/*");
        } else if (item.startsWith("Importar referencia") || item.startsWith("Referencia de color")) {
            pendingColorRefTarget = null;
            pickColorRef.launch(new String[]{"image/*"});
        } else if (item.startsWith("Quitar referencia")) {
            clearColorReference(true);
        } else if (item.startsWith("Ajustes de la varita")) {
            wandDialog();
        } else if (item.startsWith("Varita en toda")) {
            canvas.setWandGlobal(!canvas.isWandGlobal());
            toast(canvas.isWandGlobal() ? "La varita busca ese color en toda la imagen" : "La varita agarra solo lo pegado");
        } else if (item.startsWith("Repasar no oscurece")) {
            boolean on = !canvas.isFlatPaint();
            canvas.setFlatPaint(on);
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("flat_paint", on).apply();
            canvas.showHud(on ? "Repasar no oscurece: el color queda parejo" : "Cada pasada oscurece un poco mas");
        } else if (item.startsWith("Filtros")) {
            filtersDialog();
        } else if (item.startsWith("Girar")) {
            rotateDialog();
        } else if (item.startsWith("Estabilizador")) {
            stabilizerDialog();
        } else if (item.startsWith("Dureza")) {
            hardnessDialog();
        } else if (item.startsWith("Guardar ahora")) {
            if (needProject()) autosave(true);
        } else if (item.startsWith("Guardar copia")) {
            projectDialog();
        }
    }

    /** Lista de todas las herramientas; al tocar una, sale su ficha animada. */
    private void toolCardsList() {
        final List<int[]> defs = new ArrayList<int[]>();
        List<String> names = new ArrayList<String>();
        for (int[] t : TOOLS) {
            defs.add(t);
            names.add(toolInfo(t[1], t[2])[0]);
        }
        new AlertDialog.Builder(this)
                .setTitle("Toca una para ver que hace")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        showToolCard(defs.get(i)[1], defs.get(i)[2]);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Flujo guiado: cinco acciones reales, sin exponer herramientas antiguas de azul. */
    private void animationWorkflowDialog() {
        if (!needProject()) return;
        final String[] steps = {
                "1. Quitar fondo",
                "2. Seleccionar parte con Lazo",
                "3. Pintar o corregir bordes",
                "4. Ajustar con Especial",
                "5. Exportar partes como PNG transparentes",
                "Ver las capas"
        };
        new AlertDialog.Builder(this)
                .setTitle("Preparar personaje para animar")
                .setMessage("Cada parte debe estar en su propia capa. Pellizca con dos dedos para acercar y mover sin cambiar de herramienta.")
                .setItems(steps, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int index) {
                        if (index == 0) selectTool(CanvasView.MODE_BGERASE);
                        else if (index == 1) {
                            selectTool(CanvasView.MODE_LASSO);
                            canvas.showHud("Rodea la parte: se creara una capa nueva");
                        } else if (index == 2) selectTool(CanvasView.MODE_PAINT);
                        else if (index == 3) selectTool(CanvasView.MODE_LIQUIFY);
                        else if (index == 4) exportAnimationZip();
                        else if (!layersOpen()) toggleLayersPanel();
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Exportacion recomendada para Alight Motion: un PNG completo por capa. */
    private void exportAnimationZip() {
        final Project p = canvas.getProject();
        if (p == null) return;
        int count = 0;
        for (Layer l : p.layers) if (l.visible) count++;
        if (count == 0) {
            toast("Activa por lo menos una capa para exportar");
            return;
        }
        outW = p.w;
        outH = p.h;
        edgeClean = 1;  // Mantiene la transparencia y limpia RGB de bordes.
        new AlertDialog.Builder(this)
                .setTitle("Exportar " + count + " capas")
                .setMessage("Se guardara un ZIP con un PNG transparente por capa visible. "
                        + "Todas conservaran " + p.w + " × " + p.h
                        + " pixeles para quedar alineadas al importar en Alight Motion.")
                .setPositiveButton("Elegir donde guardar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        createZip.launch("PaintZeta_partes.zip");
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ==================================================================
    // Exportar
    // ==================================================================

    private void exportDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        new AlertDialog.Builder(this)
                .setTitle("¿Que necesitas exportar?")
                .setItems(new String[]{"Para animar: PNG por capa en ZIP (recomendado)",
                        "Imagen completa: un PNG con todo junto, como se ve (manga coloreado)",
                        "Opciones avanzadas: tamanos y formato"},
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int which) {
                                if (which == 0) exportAnimationZip();
                                else if (which == 1) {
                                    pendingFlatExport = true;
                                    createPng.launch("imagen_completa.png");
                                }
                                else exportAdvancedDialog();
                            }
                        }).show();
    }

    private void exportAdvancedDialog() {
        final Project p = canvas.getProject();
        final int[][] sizes = {{p.w, p.h}, {Math.max(1, p.w / 2), Math.max(1, p.h / 2)},
                longSide(p, 1920), longSide(p, 1280)};
        final String[] items = {"Original  " + sizes[0][0] + "x" + sizes[0][1],
                "Mitad  " + sizes[1][0] + "x" + sizes[1][1],
                "Lado largo 1920  " + sizes[2][0] + "x" + sizes[2][1],
                "Lado largo 1280  " + sizes[3][0] + "x" + sizes[3][1]};
        new AlertDialog.Builder(this)
                .setTitle("Exportar las capas visibles")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        outW = sizes[i][0];
                        outH = sizes[i][1];
                        edgeDialogExport();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void edgeDialogExport() {
        final String[] items = {"Limpiar borde y quitar el fondo pegado (recomendado)", "Solo limpiar borde",
                "No tocar el borde"};
        final int[] vals = {2, 1, 0};
        new AlertDialog.Builder(this)
                .setTitle("Borde de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        edgeClean = vals[i];
                        formatDialog();
                    }
                })
                .show();
    }

    private void formatDialog() {
        final String[] items = {"Elegir capas y guardar en Pictures/PaintZeta (automatico)",
                "PNG sueltos en una carpeta que elijo", "Todo junto en un ZIP"};
        new AlertDialog.Builder(this)
                .setTitle("Como guardar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 0) {
                            chooseLayersToSave();
                        } else if (i == 1) {
                            toast("Elige o crea la carpeta donde van los PNG");
                            pickFolder.launch(null);
                        } else {
                            createZip.launch("capas_anime.zip");
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Marca las capas que quieres; salen todas juntas como PNG transparente. */
    private void chooseLayersToSave() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int n = p.layers.size();
        final String[] names = new String[n];
        final boolean[] on = new boolean[n];
        for (int k = 0; k < n; k++) {
            Layer l = p.layers.get(n - 1 - k);
            names[k] = l.name;
            on[k] = l.visible;
        }
        new AlertDialog.Builder(this)
                .setTitle("Capas a guardar")
                .setMultiChoiceItems(names, on, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i, boolean c) {
                        on[i] = c;
                    }
                })
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        ArrayList<Layer> pick = new ArrayList<Layer>();
                        for (int k = n - 1; k >= 0; k--) if (on[k]) pick.add(p.layers.get(n - 1 - k));
                        if (pick.isEmpty()) {
                            toast("No marcaste ninguna capa");
                            return;
                        }
                        doExportAuto(pick);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Guarda en Pictures/PaintZeta/<fecha>/ sin preguntar carpeta (Android 10 o mas). */
    private void doExportAuto(final List<Layer> layers) {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            toast("En este Android elige la carpeta una vez");
            pickFolder.launch(null);
            return;
        }
        final Project p = canvas.getProject();
        final String folder = "Pictures/PaintZeta/" + new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US)
                .format(new java.util.Date());
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.ContentResolver cr = getContentResolver();
                    int idx = 1;
                    for (Layer l : layers) {
                        String name = String.format(Locale.US, "%02d_%s.png", idx++, safeName(l.name));
                        android.content.ContentValues cv = new android.content.ContentValues();
                        cv.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, name);
                        cv.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png");
                        cv.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, folder);
                        Uri uri = cr.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        if (uri == null) throw new java.io.IOException("No se pudo crear " + name);
                        Exporter.exportLayer(cr, p, l, uri, outW, outH, edgeClean);
                        lastExportCount++;
                    }
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al guardar: " + lastError
                        : lastExportCount + " PNG transparentes guardados en " + folder);
            }
        });
    }

    /** Cada capa visible sale como PNG suelto en la carpeta: 01_pelo.png, 02_brazo.png... */
    private void doExportFolder(final Uri tree) {
        final Project p = canvas.getProject();
        if (p == null) return;
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.ContentResolver cr = getContentResolver();
                    Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,
                            android.provider.DocumentsContract.getTreeDocumentId(tree));
                    int idx = 1;
                    for (Layer l : new ArrayList<Layer>(p.layers)) {
                        if (!l.visible) continue;
                        String name = String.format(java.util.Locale.US, "%02d_%s", idx++, safeName(l.name));
                        Uri doc = android.provider.DocumentsContract.createDocument(cr, parent, "image/png", name);
                        if (doc == null) throw new java.io.IOException("No se pudo crear " + name);
                        Exporter.exportLayer(cr, p, l, doc, outW, outH, edgeClean);
                        lastExportCount++;
                    }
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al exportar: " + lastError
                        : lastExportCount + " PNG de " + outW + "x" + outH + " guardados en la carpeta");
            }
        });
    }

    private static String safeName(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(Character.isLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
        return sb.length() == 0 ? "capa" : sb.toString();
    }

    private void doExportZip(final Uri uri) {
        final Project p = canvas.getProject();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    lastExportCount = Exporter.exportZip(getContentResolver(), p, uri, outW, outH, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al exportar: " + lastError
                        : lastExportCount + " PNG de " + outW + "x" + outH + " guardados en el ZIP");
            }
        });
    }

    private void doExportLayer(final Uri uri) {
        final Project p = canvas.getProject();
        final Layer l = pendingLayerExport;
        pendingLayerExport = null;
        if (l == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    Exporter.exportLayer(getContentResolver(), p, l, uri, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error: " + lastError : "PNG guardado");
            }
        });
    }

    // ==================================================================
    // Interfaz
    // ==================================================================

    void updateUi() {
        Project p = canvas.getProject();
        ((TextView) findViewById(R.id.layerCount)).setText(String.valueOf(p == null ? 0 : p.layers.size()));
        ((TextView) findViewById(R.id.btnSize)).setText(String.format(Locale.US,
                canvas.getBrushSize() < 10 ? "%.1f" : "%.0f", canvas.getBrushSize()));
        android.graphics.drawable.GradientDrawable sw = new android.graphics.drawable.GradientDrawable();
        sw.setCornerRadius(dp(4));
        sw.setColor(canvas.getColor());
        sw.setStroke(dp(2), 0xFFFFFFFF);
        findViewById(R.id.btnColor).setBackground(sw);
        ((ImageButton) findViewById(R.id.btnTools)).setImageResource(
                canvas.getMode() == CanvasView.MODE_BRUSH && canvas.isSubtract() ? R.drawable.ic_remove
                        : toolIcon(canvas.getMode()));

        if (layersOpen()) {
            hideForLayers(true);
            buildLayersPanel();
            return;
        }
        int m = canvas.getMode();
        syncEffectControls(m);
        // Lazo ofrece copiar directamente: ocultar los ajustes de máscara azul.
        findViewById(R.id.selBar).setVisibility(View.GONE);
        findViewById(R.id.btnSelMenu).setVisibility(
                p != null && p.hasSelection() ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnAddMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg : R.drawable.bg_seg_on);
        findViewById(R.id.btnSubMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_seg);
        toggle(R.id.btnSmart, canvas.isSmart());
        toggle(R.id.btnLineart, canvas.isUseBarrier() && p != null && p.barrier != null);
        if (wandGear != null) wandGear.setVisibility(m == CanvasView.MODE_WAND ? View.VISIBLE : View.GONE);
        buildOptBar(m);
    }

    /** Texto corto de la Suavidad de Borrar fondo (0 = nitido). */
    /** En Borrar fondo la segunda barra es la Suavidad (salvo con el Borrador manual: Fuerza). */
    private boolean bgFeatherSlider() {
        return canvas.getMode() == CanvasView.MODE_BGERASE && canvas.getBgSub() != CanvasView.BG_SUB_ERASER;
    }

    private static String featherLabel(int v) {
        float px = v / 25f;
        return "\u25D0 " + (px < 0.05f ? "0" : String.format(Locale.US, px == Math.round(px) ? "%.0f" : "%.1f", px));
    }

    /** Especial trabaja con Fortaleza, no con la opacidad del pincel. */
    private void syncEffectControls(int mode) {
        final boolean special = mode == CanvasView.MODE_LIQUIFY;
        TextView sizeLabel = findViewById(R.id.sliderLabel);
        LinearLayout.LayoutParams sizeLp = (LinearLayout.LayoutParams) sizeLabel.getLayoutParams();
        int sizeWidth = dp(special ? 58 : 46);
        if (sizeLp.width != sizeWidth) { sizeLp.width = sizeWidth; sizeLabel.setLayoutParams(sizeLp); }
        sizeLabel.setTextSize(special ? 10f : 13f);
        sizeLabel.setGravity(special ? Gravity.CENTER : Gravity.RIGHT);
        TextView label = findViewById(R.id.opacityLabel);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) label.getLayoutParams();
        int width = dp(special ? 80 : 46);
        if (lp.width != width) { lp.width = width; label.setLayoutParams(lp); }
        SeekBar strength = findViewById(R.id.opacity);
        final boolean bgEr = mode == CanvasView.MODE_BGERASE && canvas.getBgSub() == CanvasView.BG_SUB_ERASER;
        final boolean feather = mode == CanvasView.MODE_BGERASE && !bgEr;
        int controlKey = mode == CanvasView.MODE_BGERASE ? 1000 + canvas.getBgSub() : mode;
        if (controlKey != previousControlMode) {
            previousControlMode = controlKey;
            strength.setProgress(bgEr ? Math.round(canvas.getBgEraserStrength() * 100f)
                    : feather ? Math.round(canvas.getBgFeather() * 25f) : Math.round(100f * (special
                    ? canvas.getEffectStrength() : canvas.getBrushOpacity())));
        }
        int pct = strength.getProgress();
        label.setText(bgEr ? "Fuerza " + Math.max(2, pct) + "%" : feather ? featherLabel(pct)
                : special ? "Fuerza " + Math.max(5, pct) + "%" : String.valueOf(Math.max(2, pct)));
        findViewById(R.id.opacityRow).setContentDescription(bgEr ? "Fuerza del borrador" : feather ? "Suavidad del borde (0 a 4 px)"
                : special ? "Fortaleza de Especial" : "Opacidad del pincel");
    }

    // ==================================================================
    // Avisos del lienzo
    // ==================================================================

    @Override
    public void onBusy(boolean busy) {
        int[] ids = {R.id.btnExport, R.id.btnTools, R.id.btnUndo, R.id.btnRedo,
                R.id.btnLayers, R.id.btnMenu, R.id.btnSelMenu};
        for (int id : ids) {
            View v = findViewById(id);
            if (v != null) v.setEnabled(!busy);
        }
    }

    @Override
    public void onChanged() {
        markDirty();
        updateUi();
    }

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    @Override
    public void onToolStateChanged() {
        int m = canvas.getMode();
        if (m == CanvasView.MODE_PUPPET || m == CanvasView.MODE_TRANSFORM || m == CanvasView.MODE_BUCKET
                || canvas.isMangaMode()) updateUi();
    }

    @Override
    public void onColorPicked(int color) {
        updateUi();
        canvas.showHud(String.format(Locale.US, "Color #%06X", color & 0xFFFFFF));
    }

    @Override
    public void onUndoGesture() {
        canvas.doUndo();
        updateUi();
    }

    @Override
    public void onRedoGesture() {
        canvas.doRedo();
        updateUi();
    }


    // ==================================================================
    // Dialogos
    // ==================================================================

    /** Ajustes de la varita, al estilo de los de Ibis. */
    /** Panel chico de la varita, como en ibis: se aplica al momento. */
    private void wandDialog() {
        if (!needProject()) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);

        final TextView tExp = smallText("Dilatacion " + String.format(Locale.US, "%.1f", canvas.getExpansion()));
        final SeekBar sExp = new SeekBar(this);
        sExp.setMax(80); // -3.0 .. +5.0
        sExp.setProgress(Math.round((canvas.getExpansion() + 3f) * 10f));
        sExp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                float e = v / 10f - 3f;
                tExp.setText("Dilatacion " + String.format(Locale.US, "%.1f", e));
                canvas.setExpansion(e);
            }
        });
        root.addView(tExp);
        root.addView(sExp);

        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        root.addView(smallSwitch("Hasta la linea", canvas.isToLine(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setToLine(on);
                sp.edit().putBoolean("to_line", on).apply();
            }
        }));
        root.addView(smallSwitch("Reconocimiento de huecos", canvas.isAutoLines(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setAutoLines(on);
                sp.edit().putBoolean("auto_lines", on).apply();
            }
        }));
        root.addView(smallSwitch("Zonas sin pintar", canvas.isFillUnpainted(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setFillUnpainted(on);
                sp.edit().putBoolean("fill_unpainted", on).apply();
            }
        }));
        root.addView(smallSwitch("Llenado continuo", !canvas.isWandGlobal(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setWandGlobal(!on);
            }
        }));

        final AlertDialog dlg = new AlertDialog.Builder(this).setView(root)
                .setPositiveButton("Listo", null)
                .setNeutralButton("Restablecer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(28);
                        canvas.setSoftness(24);
                        canvas.setExpansion(1.5f);
                        canvas.setAutoLines(true);
                        canvas.setWandGlobal(false);
                        canvas.setToLine(true);
                        canvas.setFillUnpainted(false);
                        canvas.setColorMode(ColorDist.RGB);
                        sp.edit().putBoolean("auto_lines", true).putBoolean("to_line", true)
                                .putBoolean("fill_unpainted", false).apply();
                        syncSlider();
                        toast("Restablecido");
                    }
                })
                .create();
        dlg.show();
        // cuadro chico, no toda la pantalla
        if (dlg.getWindow() != null) {
            dlg.getWindow().setLayout(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private interface SwitchDo {
        void set(boolean on);
    }

    private TextView smallText(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFFE0E0E0);
        v.setTextSize(13f);
        v.setPadding(0, dp(4), 0, 0);
        return v;
    }

    private android.widget.Switch smallSwitch(String text, boolean on, final SwitchDo d) {
        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setText(text);
        sw.setTextSize(13f);
        sw.setTextColor(0xFFE0E0E0);
        sw.setChecked(on);
        sw.setPadding(0, dp(2), 0, dp(2));
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean c) {
                d.set(c);
            }
        });
        return sw;
    }

    private String expLabel(float v) {
        return String.format(Locale.US, "Expansion del borde: %.1f px", v);
    }

    /** Gama de colores, con vista previa mientras mueves el margen. */
    private void colorRangeDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView info = new TextView(this);
        info.setText("Se usa el color cargado. Mueve el margen y mira el lienzo: la seleccion se actualiza sola.");
        root.addView(info);

        final View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        lp.topMargin = dp(8);
        sw.setLayoutParams(lp);
        sw.setBackgroundColor(canvas.getColor());
        root.addView(sw);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Margen: " + canvas.getTolerance());
        root.addView(tTol);
        root.addView(sTol);

        final CheckBox replace = new CheckBox(this);
        replace.setText("Reemplazar la seleccion actual");
        replace.setChecked(true);
        root.addView(replace);

        canvas.beginPreview();
        final Runnable[] pending = new Runnable[1];
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, final int v, boolean u) {
                tTol.setText("Margen: " + v);
                if (pending[0] != null) previewHandler.removeCallbacks(pending[0]);
                pending[0] = new Runnable() {
                    @Override
                    public void run() {
                        canvas.previewColorRange(canvas.getColor(), v, replace.isChecked());
                    }
                };
                previewHandler.postDelayed(pending[0], 180);
            }
        });
        canvas.previewColorRange(canvas.getColor(), sTol.getProgress(), replace.isChecked());

        new AlertDialog.Builder(this)
                .setTitle("Gama de colores")
                .setView(scroll)
                .setCancelable(false)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.endPreview(true);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.endPreview(false);
                    }
                })
                .show();
    }

    private void refineDialog() {
        if (!needProject()) return;
        final String[] items = {"Suave (pelo fino)", "Medio", "Fuerte"};
        final int[] rad = {6, 12, 20};
        final float[] eps = {0.0004f, 0.0016f, 0.006f};
        new AlertDialog.Builder(this)
                .setTitle("Refinar borde")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.refineEdge(rad[i], eps[i]);
                    }
                })
                .show();
    }

    private void unpaintedDialog() {
        if (!needProject()) return;
        final String[] items = {"Solo huecos chicos", "Huecos medianos", "Huecos grandes", "Todos los huecos"};
        final int[] vals = {2, 8, 30, 0};
        new AlertDialog.Builder(this)
                .setTitle("Rellenar zonas sin pintar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(5, vals[i]);
                    }
                })
                .show();
    }

    /** Saca la linea del manga a su capa y deja una capa de color debajo. */
    private void filtersDialog() {
        if (!needProject()) return;
        final String[] items = {
                "Quitar ruido de JPEG (mediana)",
                "Aplanar tonos (posterizar)",
                "Niveles: mas contraste",
                "Extraer line art"
        };
        new AlertDialog.Builder(this)
                .setTitle("Filtros de limpieza")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                canvas.applyFilter(0, 0, 0, 0);
                                break;
                            case 1:
                                posterizeDialog();
                                break;
                            case 2:
                                canvas.applyFilter(2, 25, 230, 100);
                                break;
                            default:
                                lineArtFilterDialog();
                                break;
                        }
                    }
                })
                .show();
    }

    private void posterizeDialog() {
        final String[] items = {"4 tonos", "6 tonos", "10 tonos", "16 tonos"};
        final int[] vals = {4, 6, 10, 16};
        new AlertDialog.Builder(this)
                .setTitle("Aplanar tonos")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.applyFilter(1, vals[i], 0, 0);
                    }
                })
                .show();
    }

    /** Extraer line art con sus tres controles, como el filtro de Ibis. */
    private void lineArtFilterDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tw = new TextView(this);
        final SeekBar sw = new SeekBar(this);
        sw.setMax(255);
        sw.setProgress(210);
        tw.setText("Blanco: 210");
        sw.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tw.setText("Blanco: " + v);
            }
        });
        root.addView(tw);
        root.addView(sw);

        final TextView tb = new TextView(this);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(255);
        sb.setProgress(40);
        tb.setText("Negro: 40");
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tb.setText("Negro: " + v);
            }
        });
        root.addView(tb);
        root.addView(sb);

        final TextView tm = new TextView(this);
        final SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(50);
        tm.setText("Medio: 50");
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tm.setText("Medio: " + Math.max(1, v));
            }
        });
        root.addView(tm);
        root.addView(sm);

        new AlertDialog.Builder(this)
                .setTitle("Extraer line art")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.applyFilter(3, sw.getProgress(), sb.getProgress(),
                                Math.max(1, sm.getProgress()));
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void stabilizerDialog() {
        final String[] items = {"Apagado", "Suave", "Medio", "Fuerte"};
        final float[] vals = {0f, 0.5f, 0.72f, 0.88f};
        new AlertDialog.Builder(this)
                .setTitle("Estabilizador del trazo")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setStabilizer(vals[i]);
                        toast("Estabilizador: " + items[i]);
                    }
                })
                .show();
    }

    private void expandDialog() {
        if (!needProject()) return;
        final String[] items = {"+0.5 px", "+1.0 px", "+1.5 px", "+2.0 px", "-0.5 px", "-1.0 px"};
        final float[] vals = {0.5f, 1f, 1.5f, 2f, -0.5f, -1f};
        new AlertDialog.Builder(this)
                .setTitle("Expandir o contraer con decimales")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.expandSelection(vals[i]);
                    }
                })
                .show();
    }

    /** Quita los puntitos que deja la trama del manga dentro de la seleccion. */
    private void closeHolesDialog() {
        if (!needProject()) return;
        final String[] items = {"Puntos chicos (1 px)", "Medianos (2 px)", "Grandes (3 px)", "Muy grandes (5 px)"};
        final int[] vals = {1, 2, 3, 5};
        new AlertDialog.Builder(this)
                .setTitle("Cerrar huecos de la trama")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(4, vals[i]);
                    }
                })
                .show();
    }

    private void hardnessDialog() {
        final String[] items = {"Muy suave 20%", "Suave 40%", "Media 70%", "Dura 100% (color plano, borde limpio)"};
        final float[] vals = {0.2f, 0.4f, 0.7f, 1f};
        new AlertDialog.Builder(this)
                .setTitle("Dureza del pincel")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setHardness(vals[i]);
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putFloat("brush_hardness_v827", vals[i]).apply();
                        toast("Dureza " + items[i]);
                    }
                })
                .show();
    }

    /** Agregar espacio transparente al lienzo (por ejemplo arriba, para enderezar un personaje). */
    private void enlargeCanvasDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(8), dp(18), dp(4));
        final CheckBox top = new CheckBox(this), bottom = new CheckBox(this), left = new CheckBox(this), right = new CheckBox(this);
        top.setText("Arriba"); bottom.setText("Abajo"); left.setText("Izquierda"); right.setText("Derecha");
        top.setChecked(true);
        for (CheckBox c : new CheckBox[]{top, bottom, left, right}) { c.setTextColor(0xFFFFFFFF); root.addView(c); }
        final TextView val = optLabel("");
        root.addView(val);
        final SeekBar amt = new SeekBar(this);
        amt.setMax(45);
        amt.setProgress(10);
        final Runnable upd = new Runnable() {
            public void run() {
                int pct = amt.getProgress() + 5;
                val.setText("Agregar " + pct + "%  (" + Math.round(p.h * pct / 100f) + " px arriba/abajo, "
                        + Math.round(p.w * pct / 100f) + " px a los lados)");
            }
        };
        amt.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { upd.run(); }
        });
        upd.run();
        root.addView(amt);
        TextView note = new TextView(this);
        note.setText("Las capas no se achican: solo se agrega espacio transparente. El historial de Deshacer se reinicia.");
        note.setTextColor(0xFFB8B8C0);
        note.setTextSize(12f);
        note.setPadding(0, dp(6), 0, 0);
        root.addView(note);
        new AlertDialog.Builder(this)
                .setTitle("Ampliar lienzo (" + p.w + " x " + p.h + ")")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Ampliar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        int pct = amt.getProgress() + 5;
                        int v = Math.round(p.h * pct / 100f), hz = Math.round(p.w * pct / 100f);
                        canvas.enlargeCanvas(left.isChecked() ? hz : 0, top.isChecked() ? v : 0,
                                right.isChecked() ? hz : 0, bottom.isChecked() ? v : 0);
                        markDirty();
                    }
                }).show();
    }

    private void rotateDialog() {
        if (!needProject()) return;
        final String[] items = {"Girar a la derecha", "Girar a la izquierda",
                "Voltear horizontal", "Voltear vertical"};
        new AlertDialog.Builder(this)
                .setTitle("Girar imagen")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.transform(i);
                    }
                })
                .show();
    }

    private void lineArtDialog() {
        if (!needProject()) return;
        if (canvas.isUseBarrier() && canvas.getProject().barrier != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Line art")
                    .setMessage("La barrera esta activa. La varita y el balde se detienen en las lineas.")
                    .setPositiveButton("Desactivar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.setUseBarrier(false);
                            updateUi();
                        }
                    })
                    .setNegativeButton("Recalcular", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            thresholdDialog();
                        }
                    })
                    .show();
            return;
        }
        thresholdDialog();
    }

    private void thresholdDialog() {
        final String[] items = {"Lineas muy oscuras (60)", "Oscuras (90)", "Normal (120)", "Tenues (160)"};
        final int[] vals = {60, 90, 120, 160};
        new AlertDialog.Builder(this)
                .setTitle("Que tan oscura es la linea")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int i) {
                        final String[] gaps = {"Sin cerrar huecos", "Cerrar 1 px", "Cerrar 2 px", "Cerrar 3 px"};
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cerrar huecos de la linea")
                                .setItems(gaps, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int g) {
                                        canvas.buildBarrier(vals[i], g);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    private Bitmap decodeReference(Uri uri) {
        try {
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            InputStream is0 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is0, null, b);
            if (is0 != null) is0.close();
            int ow = b.outWidth, oh = b.outHeight;
            if (ow <= 0 || oh <= 0) return null;
            int sample = 1;
            int maxSide = Math.max(ow, oh);
            while (maxSide / sample > 2800) sample *= 2;
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o.inMutable = false;
            o.inSampleSize = Math.max(1, sample);
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            return bmp;
        } catch (Throwable t) {
            toast("No se pudo abrir la referencia");
            return null;
        }
    }

    private void clearColorReference(boolean showToast) {
        pendingColorRefTarget = null;
        if (colorRefWindow != null) { try { colorRefWindow.dismiss(); } catch (Throwable ignored) {} }
        colorRefWindow = null; colorRefView = null;
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) colorRefBitmap.recycle();
        colorRefBitmap = null;
        refSampleView = null;
        refSampleText = null;
        refPaletteStrip = null;
        // v8.26: si estaba guardada con la obra, se quita de la obra (la foto del telefono no se toca;
        // la exportacion nunca la incluyo)
        Project p = canvas.getProject();
        if (p != null && p.refImagePng != null) {
            p.refImagePng = null;
            markDirty();
        }
        if (showToast) toast("Referencia de color quitada");
    }

    private void requestColorReference(ColorPickTarget target) {
        if (colorRefBitmap == null || colorRefBitmap.isRecycled()) {
            pendingColorRefTarget = target;
            pickColorRef.launch(new String[]{"image/*"});
        } else {
            showReferenceColorPanel(target);
        }
    }

    private int[] extractReferencePalette(Bitmap bmp, int count) {
        if (bmp == null) return new int[0];
        java.util.LinkedHashMap<Integer, Integer> hist = new java.util.LinkedHashMap<Integer, Integer>();
        int w = bmp.getWidth(), h = bmp.getHeight();
        int sx = Math.max(1, w / 80), sy = Math.max(1, h / 80);
        for (int y = 0; y < h; y += sy) {
            for (int x = 0; x < w; x += sx) {
                int c = bmp.getPixel(x, y);
                if (((c >>> 24) & 0xFF) < 20) continue;
                int r = (Color.red(c) >> 4) & 0xF;
                int g = (Color.green(c) >> 4) & 0xF;
                int b = (Color.blue(c) >> 4) & 0xF;
                int key = (r << 8) | (g << 4) | b;
                Integer old = hist.get(key);
                hist.put(key, old == null ? 1 : old + 1);
            }
        }
        java.util.List<java.util.Map.Entry<Integer, Integer>> list = new java.util.ArrayList<java.util.Map.Entry<Integer, Integer>>(hist.entrySet());
        java.util.Collections.sort(list, new java.util.Comparator<java.util.Map.Entry<Integer, Integer>>() {
            @Override
            public int compare(java.util.Map.Entry<Integer, Integer> a, java.util.Map.Entry<Integer, Integer> b) {
                return b.getValue() - a.getValue();
            }
        });
        java.util.ArrayList<Integer> out = new java.util.ArrayList<Integer>();
        for (java.util.Map.Entry<Integer, Integer> e : list) {
            int key = e.getKey();
            int r = ((key >> 8) & 0xF) * 17;
            int g = ((key >> 4) & 0xF) * 17;
            int bl = (key & 0xF) * 17;
            int c = Color.rgb(r, g, bl);
            boolean close = false;
            for (int i = 0; i < out.size(); i++) {
                int oc = out.get(i);
                int dr = Color.red(oc) - r, dg = Color.green(oc) - g, db = Color.blue(oc) - bl;
                if (dr * dr + dg * dg + db * db < 28 * 28) {
                    close = true;
                    break;
                }
            }
            if (!close) out.add(c);
            if (out.size() >= count) break;
        }
        int[] arr = new int[out.size()];
        for (int i = 0; i < out.size(); i++) arr[i] = out.get(i);
        return arr;
    }

    private Integer colorFromImageTouch(ImageView iv, Bitmap bmp, MotionEvent e) {
        if (bmp == null || iv.getDrawable() == null) return null;
        float[] values = new float[9];
        Matrix m = iv.getImageMatrix();
        m.getValues(values);
        float scaleX = values[Matrix.MSCALE_X];
        float scaleY = values[Matrix.MSCALE_Y];
        float transX = values[Matrix.MTRANS_X];
        float transY = values[Matrix.MTRANS_Y];
        if (scaleX == 0f || scaleY == 0f) return null;
        float bx = (e.getX() - transX) / scaleX;
        float by = (e.getY() - transY) / scaleY;
        if (bx < 0 || by < 0 || bx >= bmp.getWidth() || by >= bmp.getHeight()) return null;
        return bmp.getPixel(Math.max(0, Math.min(bmp.getWidth() - 1, Math.round(bx))),
                Math.max(0, Math.min(bmp.getHeight() - 1, Math.round(by))));
    }

    /** Muestra de la ventana de referencia (todavia no se usa hasta "Usar este color"). */
    private int refSample = 0;
    private boolean refFolded;
    private View refSampleView;
    private TextView refSampleText;
    private LinearLayout refPaletteStrip;

    private void setRefSample(int c) {
        refSample = c;
        if (refSampleView != null) refSampleView.setBackgroundColor(c | 0xFF000000);
        if (refSampleText != null) refSampleText.setText(String.format(Locale.US, "#%06X", c & 0xFFFFFF));
    }

    /** Muestras de la obra como cuadritos: tocar = usar ese color. */
    private void fillRefPalette(final ColorPickTarget target) {
        if (refPaletteStrip == null) return;
        refPaletteStrip.removeAllViews();
        Project p = canvas.getProject();
        if (p == null) return;
        for (final Project.Swatch sw : p.swatches) {
            View v = new View(this);
            v.setBackgroundColor(sw.color | 0xFF000000);
            v.setContentDescription(sw.name);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(26), dp(26));
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            v.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View vv) {
                    setRefSample(sw.color);
                    target.onColor(sw.color);
                    toast("\"" + sw.name + "\" en uso");
                }
            });
            refPaletteStrip.addView(v, lp);
        }
    }

    private void showReferenceColorPanel(final ColorPickTarget target) {
        if (colorRefBitmap == null || colorRefBitmap.isRecycled()) return;
        if (colorRefWindow != null && colorRefWindow.isShowing()) {
            if (colorRefView != null) {
                colorRefView.setBitmap(colorRefBitmap);
                colorRefView.setListener(new ReferenceImageView.Listener() {
                    @Override public void onColor(int color) { setRefSample(color); }
                });
            }
            refUseTarget = target;
            fillRefPalette(target);
            return;
        }
        refUseTarget = target;

        final FrameLayout shell = new FrameLayout(this);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(4), dp(4), dp(4), dp(4));
        root.setBackgroundResource(R.drawable.bg_ref_panel);
        shell.addView(root, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Referencia");
        title.setTextColor(0xFFF4F4F6);
        title.setTextSize(14f);
        title.setPadding(dp(8), 0, dp(4), 0);
        head.addView(title, new LinearLayout.LayoutParams(0, dp(34), 1f));

        final ImageButton fold = refIconButton(R.drawable.ic_up, "Plegar / desplegar");
        ImageButton more = refIconButton(R.drawable.ic_menu, "Mas: cambiar, quitar, paleta, guardar con la obra");
        ImageButton close = refIconButton(R.drawable.ic_close, "Cerrar referencia");
        head.addView(fold); head.addView(more); head.addView(close);
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));

        colorRefView = new ReferenceImageView(this);
        colorRefView.setBitmap(colorRefBitmap);
        colorRefView.setAverage3(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("ref_avg3", true));
        colorRefView.setListener(new ReferenceImageView.Listener() {
            @Override public void onColor(int color) { setRefSample(color); }
        });
        final LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(colorRefView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Pie: muestra + Usar + Guardar + Ajustar + 3x3
        LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(0, dp(3), 0, 0);
        refSampleView = new View(this);
        foot.addView(refSampleView, new LinearLayout.LayoutParams(dp(28), dp(28)));
        refSampleText = new TextView(this);
        refSampleText.setTextColor(0xFFE0E0E0);
        refSampleText.setTextSize(10f);
        refSampleText.setPadding(dp(3), 0, dp(3), 0);
        foot.addView(refSampleText);
        TextView use = smallTextButton("Usar");
        TextView save = smallTextButton("Guardar");
        TextView adj = smallTextButton("Ajustar");
        final TextView avg = smallTextButton("");
        foot.addView(use); foot.addView(save); foot.addView(adj); foot.addView(avg);
        android.widget.HorizontalScrollView footScroll = new android.widget.HorizontalScrollView(this);
        footScroll.addView(foot);
        body.addView(footScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        refPaletteStrip = new LinearLayout(this);
        refPaletteStrip.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView palScroll = new android.widget.HorizontalScrollView(this);
        palScroll.addView(refPaletteStrip);
        body.addView(palScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setRefSample(refSample != 0 ? refSample : canvas.getColor());
        fillRefPalette(target);

        final Runnable avgLabel = new Runnable() {
            @Override public void run() { avg.setText(colorRefView.isAverage3() ? "3x3: SI" : "3x3: NO"); }
        };
        avgLabel.run();
        use.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (refUseTarget != null) refUseTarget.onColor(refSample | 0xFF000000);
                toast(String.format(Locale.US, "Color #%06X listo para pincel y balde", refSample & 0xFFFFFF));
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveSwatchDialog(refSample, new Runnable() {
                    @Override public void run() { fillRefPalette(refUseTarget != null ? refUseTarget : target); }
                });
            }
        });
        adj.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                sampleAdjustDialog(refSample, new ColorPickTarget() {
                    @Override public void onColor(int c) { setRefSample(c); }
                });
            }
        });
        avg.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                colorRefView.setAverage3(!colorRefView.isAverage3());
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("ref_avg3", colorRefView.isAverage3()).apply();
                avgLabel.run();
            }
        });

        // Tirador pequeno: solo aparece en la esquina y no tapa la imagen.
        final ImageView resize = new ImageView(this);
        resize.setImageResource(R.drawable.ic_resize_ref);
        resize.setPadding(dp(4), dp(4), dp(4), dp(4));
        resize.setBackgroundResource(R.drawable.bg_ref_handle);
        FrameLayout.LayoutParams rh = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.RIGHT | Gravity.BOTTOM);
        rh.setMargins(0, 0, dp(4), dp(4));
        shell.addView(resize, rh);

        float density = getResources().getDisplayMetrics().density;
        int swDp = Math.round(getResources().getDisplayMetrics().widthPixels / density);
        int shDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        colorRefW = Math.max(200, Math.min(colorRefW, Math.max(200, swDp - 8)));
        colorRefH = Math.max(230, Math.min(colorRefH, Math.max(230, shDp - 8)));
        refFolded = false;
        colorRefWindow = new PopupWindow(shell, dp(colorRefW), dp(colorRefH), false);
        colorRefWindow.setOutsideTouchable(false);
        colorRefWindow.setClippingEnabled(true);
        colorRefWindow.setElevation(dp(8));
        colorRefWindow.showAtLocation(findViewById(android.R.id.content), Gravity.TOP | Gravity.START, colorRefX, colorRefY);

        fold.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (colorRefWindow == null) return;
                refFolded = !refFolded;
                body.setVisibility(refFolded ? View.GONE : View.VISIBLE);
                resize.setVisibility(refFolded ? View.GONE : View.VISIBLE);
                fold.setImageResource(refFolded ? R.drawable.ic_down : R.drawable.ic_up);
                colorRefWindow.update(colorRefX, colorRefY, dp(colorRefW), refFolded ? dp(46) : dp(colorRefH));
            }
        });

        final float[] drag = new float[4];
        head.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (colorRefWindow == null) return false;
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    drag[0] = e.getRawX(); drag[1] = e.getRawY(); drag[2] = colorRefX; drag[3] = colorRefY; return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    int sw = getResources().getDisplayMetrics().widthPixels;
                    int sh = getResources().getDisplayMetrics().heightPixels;
                    colorRefX = Math.max(0, Math.min(sw - dp(70), Math.round(drag[2] + e.getRawX() - drag[0])));
                    colorRefY = Math.max(0, Math.min(sh - dp(70), Math.round(drag[3] + e.getRawY() - drag[1])));
                    colorRefWindow.update(colorRefX, colorRefY, -1, -1); return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("ref_x", colorRefX).putInt("ref_y", colorRefY).apply();
                    return true;
                }
                return false;
            }
        });

        final float[] size = new float[4];
        resize.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (colorRefWindow == null) return false;
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    size[0] = e.getRawX(); size[1] = e.getRawY(); size[2] = colorRefW; size[3] = colorRefH; return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    float d = getResources().getDisplayMetrics().density;
                    int sw = Math.round(getResources().getDisplayMetrics().widthPixels / d);
                    int sh = Math.round(getResources().getDisplayMetrics().heightPixels / d);
                    int dx = Math.round((e.getRawX() - size[0]) / d);
                    int dy = Math.round((e.getRawY() - size[1]) / d);
                    colorRefW = Math.max(200, Math.min(sw - Math.round(colorRefX / d) - 6, Math.round(size[2]) + dx));
                    colorRefH = Math.max(230, Math.min(sh - Math.round(colorRefY / d) - 6, Math.round(size[3]) + dy));
                    colorRefWindow.update(colorRefX, colorRefY, dp(colorRefW), dp(colorRefH));
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("ref_w", colorRefW).putInt("ref_h", colorRefH).apply();
                    return true;
                }
                return false;
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final Project p = canvas.getProject();
                final boolean keep = p != null && p.refImagePng != null;
                final String[] items = {"Cambiar imagen", "Volver a encuadrar", "Paleta automatica (sugerencias)",
                        keep ? "Guardar copia reducida con la obra: SI" : "Guardar copia reducida con la obra: NO",
                        "Quitar referencia (no borra la foto del telefono)"};
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Referencia de colores")
                        .setItems(items, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int i) {
                                if (i == 0) { pendingColorRefTarget = refUseTarget; pickColorRef.launch(new String[]{"image/*"}); }
                                else if (i == 1) colorRefView.refit();
                                else if (i == 2) autoPaletteDialog();
                                else if (i == 3) setKeepRefInProject(!keep);
                                else clearColorReference(true);
                            }
                        })
                        .show();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (colorRefWindow != null) colorRefWindow.dismiss(); colorRefWindow = null; colorRefView = null; }
        });
    }

    /** A donde va el color al pulsar "Usar" (pincel/balde, o el dialogo de Color). */
    private ColorPickTarget refUseTarget;

    private ImageButton refIconButton(int icon, String desc) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(icon);
        b.setColorFilter(0xFFF1F1F3);
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setContentDescription(desc);
        b.setPadding(dp(7), dp(7), dp(7), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
        lp.setMargins(dp(1), 0, dp(1), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView smallTextButton(String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(0xFFFFFFFF); v.setTextSize(12f); v.setGravity(Gravity.CENTER);
        v.setPadding(dp(7), 0, dp(7), 0);
        v.setBackgroundResource(R.drawable.bg_tool);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.setMargins(dp(2), 0, dp(2), 0); v.setLayoutParams(lp);
        return v;
    }

    /**
     * v8.33: selector de color profesional y compacto:
     *  anterior | actual (tocar anterior vuelve) - aro de tono + CUADRADO S/V (llega a blanco y
     *  negro) - blanco, grises y negro a un toque - recientes - paleta de la obra y global (+ guarda)
     *  - HEX y barras RGB o HSV - mezclar dos colores con proporcion - referencia: tomar color o
     *  sacar su paleta (la referencia no se exporta) - opacidad - Gotero con lupa.
     */
    private void colorDialog() {
        final int previous = canvas.getColor() | 0xFF000000;
        final int[] chosen = {previous};
        final boolean[] syncing = {false};
        final boolean[] hsvMode = {getSharedPreferences("pz", MODE_PRIVATE).getBoolean("color_hsv", false)};

        ScrollView scroll = new ScrollView(this);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(8), dp(12), dp(8));
        scroll.addView(root);

        // anterior | actual
        LinearLayout previews = new LinearLayout(this);
        previews.setOrientation(LinearLayout.HORIZONTAL);
        final TextView oldPreview = new TextView(this);
        final TextView newPreview = new TextView(this);
        oldPreview.setText("Anterior"); newPreview.setText("Actual");
        oldPreview.setGravity(android.view.Gravity.CENTER); newPreview.setGravity(android.view.Gravity.CENTER);
        oldPreview.setTextColor(contrastText(previous)); newPreview.setTextColor(contrastText(previous));
        oldPreview.setBackgroundColor(previous); newPreview.setBackgroundColor(previous);
        previews.addView(oldPreview, new LinearLayout.LayoutParams(0, dp(40), 1f));
        previews.addView(newPreview, new LinearLayout.LayoutParams(0, dp(40), 1f));
        root.addView(previews);

        final ColorPickerView picker = new ColorPickerView(this);
        picker.setColor(previous);
        root.addView(picker, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)));

        final LinearLayout quick = swatchRow();
        root.addView(sectionTitle("Blanco, grises y negro"));
        root.addView(quick);
        final android.widget.HorizontalScrollView recScroll = new android.widget.HorizontalScrollView(this);
        final LinearLayout recent = swatchRow();
        recScroll.addView(recent);
        root.addView(sectionTitle("Recientes"));
        root.addView(recScroll);
        final android.widget.HorizontalScrollView palScroll = new android.widget.HorizontalScrollView(this);
        final LinearLayout pal = swatchRow();
        palScroll.addView(pal);
        root.addView(sectionTitle("Paleta (mantener pulsado: quitar)"));
        root.addView(palScroll);

        // HEX
        LinearLayout hexRow = new LinearLayout(this);
        hexRow.setOrientation(LinearLayout.HORIZONTAL);
        hexRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        final EditText hex = new EditText(this);
        hex.setSingleLine(true);
        hex.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        hex.setText(com.pacco.animecut.core.ColorTools.toHex(previous));
        TextView hexGo = smallTextButton("OK");
        final TextView modeBtn = smallTextButton(hsvMode[0] ? "HSV" : "RGB");
        hexRow.addView(hex, new LinearLayout.LayoutParams(0, dp(46), 1f));
        hexRow.addView(hexGo);
        hexRow.addView(modeBtn);
        root.addView(hexRow);

        final SeekBar s1 = new SeekBar(this), s2 = new SeekBar(this), s3 = new SeekBar(this), sa = new SeekBar(this);
        final TextView v1 = new TextView(this), v2 = new TextView(this), v3 = new TextView(this), va = new TextView(this);
        final TextView[] lab = new TextView[3];
        lab[0] = addColorChannel2(root, "R", s1, v1);
        lab[1] = addColorChannel2(root, "G", s2, v2);
        lab[2] = addColorChannel2(root, "B", s3, v3);
        sa.setMax(100);
        addColorChannel(root, "Opacidad", sa, va);

        // mezclar
        root.addView(sectionTitle("Mezclar dos colores"));
        LinearLayout mixRow = new LinearLayout(this);
        mixRow.setOrientation(LinearLayout.HORIZONTAL);
        mixRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        final View mixA = new View(this), mixB = new View(this), mixR = new View(this);
        final int[] mixCols = {previous, getSharedPreferences("pz", MODE_PRIVATE).getInt("mix_b", 0xFFFFFFFF)};
        final SeekBar mixT = new SeekBar(this);
        mixT.setMax(100);
        mixT.setProgress(50);
        final boolean[] mixLin = {false};
        final TextView mixPct = new TextView(this);
        mixPct.setTextColor(0xFFFFFFFF);
        mixRow.addView(mixA, new LinearLayout.LayoutParams(dp(34), dp(34)));
        mixRow.addView(mixT, new LinearLayout.LayoutParams(0, dp(36), 1f));
        mixRow.addView(mixB, new LinearLayout.LayoutParams(dp(34), dp(34)));
        root.addView(mixRow);
        LinearLayout mixRow2 = new LinearLayout(this);
        mixRow2.setOrientation(LinearLayout.HORIZONTAL);
        mixRow2.setGravity(android.view.Gravity.CENTER_VERTICAL);
        final TextView setA = smallTextButton("A = actual"), setB = smallTextButton("B = actual"), kind = smallTextButton("Pintura");
        mixRow2.addView(setA); mixRow2.addView(setB); mixRow2.addView(kind);
        mixRow2.addView(mixPct, new LinearLayout.LayoutParams(dp(54), dp(34)));
        mixRow2.addView(mixR, new LinearLayout.LayoutParams(0, dp(34), 1f));
        TextView useMix = smallTextButton("Usar");
        mixRow2.addView(useMix);
        root.addView(mixRow2);

        // referencia
        final LinearLayout refBox = new LinearLayout(this);
        refBox.setOrientation(LinearLayout.VERTICAL);
        refBox.setPadding(0, dp(8), 0, 0);
        TextView refTitle = sectionTitle("Imagen de referencia para sacar colores (no se exporta, no es una capa)");
        refBox.addView(refTitle);
        LinearLayout refActions = new LinearLayout(this);
        refActions.setOrientation(LinearLayout.HORIZONTAL);
        TextView refBtn = smallAction(colorRefBitmap == null ? "Abrir imagen" : "Tomar color");
        TextView palBtn = smallAction("Sacar paleta");
        TextView changeBtn = smallAction("Cambiar");
        TextView clearBtn = smallAction("Quitar");
        refActions.addView(refBtn, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(38), 1f); ap.setMargins(dp(4), 0, 0, 0);
        refActions.addView(palBtn, ap);
        LinearLayout.LayoutParams ap1 = new LinearLayout.LayoutParams(0, dp(38), 1f); ap1.setMargins(dp(4), 0, 0, 0);
        refActions.addView(changeBtn, ap1);
        LinearLayout.LayoutParams ap2 = new LinearLayout.LayoutParams(0, dp(38), 1f); ap2.setMargins(dp(4), 0, 0, 0);
        refActions.addView(clearBtn, ap2);
        refBox.addView(refActions);
        final android.widget.HorizontalScrollView refPalScroll = new android.widget.HorizontalScrollView(this);
        final LinearLayout refPal = swatchRow();
        refPalScroll.addView(refPal);
        refBox.addView(refPalScroll);
        root.addView(refBox);

        final Runnable[] fill = new Runnable[1];
        final Runnable syncUi = new Runnable() {
            @Override public void run() {
                syncing[0] = true;
                int c = chosen[0];
                if (hsvMode[0]) {
                    float[] h = com.pacco.animecut.core.ColorTools.rgbToHsv(c);
                    if (h[1] <= 0.001f || h[2] <= 0.001f) h[0] = picker.getHue();
                    s1.setMax(360); s2.setMax(100); s3.setMax(100);
                    s1.setProgress(Math.round(h[0])); s2.setProgress(Math.round(h[1] * 100)); s3.setProgress(Math.round(h[2] * 100));
                    lab[0].setText("H"); lab[1].setText("S"); lab[2].setText("V");
                    v1.setText(Math.round(h[0]) + "°"); v2.setText(Math.round(h[1] * 100) + "%"); v3.setText(Math.round(h[2] * 100) + "%");
                } else {
                    s1.setMax(255); s2.setMax(255); s3.setMax(255);
                    s1.setProgress(Color.red(c)); s2.setProgress(Color.green(c)); s3.setProgress(Color.blue(c));
                    lab[0].setText("R"); lab[1].setText("G"); lab[2].setText("B");
                    v1.setText(String.valueOf(Color.red(c))); v2.setText(String.valueOf(Color.green(c))); v3.setText(String.valueOf(Color.blue(c)));
                }
                hex.setText(com.pacco.animecut.core.ColorTools.toHex(c));
                newPreview.setBackgroundColor(c); newPreview.setTextColor(contrastText(c));
                mixA.setBackgroundColor(mixCols[0]);
                mixB.setBackgroundColor(mixCols[1]);
                int m = com.pacco.animecut.core.ColorTools.mix(mixCols[0], mixCols[1], mixT.getProgress() / 100f, mixLin[0]);
                mixR.setBackgroundColor(m);
                mixPct.setText(" " + (100 - mixT.getProgress()) + "/" + mixT.getProgress());
                syncing[0] = false;
            }
        };
        final ColorPickTarget pickTo = new ColorPickTarget() {
            @Override public void onColor(int color) {
                chosen[0] = color | 0xFF000000;
                picker.setColor(chosen[0]);
                syncUi.run();
            }
        };
        fill[0] = new Runnable() {
            @Override public void run() {
                quick.removeAllViews();
                for (int c : new int[]{0xFFFFFFFF, 0xFFD9D9D9, 0xFFA6A6A6, 0xFF737373, 0xFF404040, 0xFF1A1A1A, 0xFF000000})
                    quick.addView(swatch(c, pickTo, null));
                recent.removeAllViews();
                for (int c : com.pacco.animecut.core.ColorTools.parseList(getSharedPreferences("pz", MODE_PRIVATE).getString("recent_colors", "")))
                    recent.addView(swatch(c, pickTo, null));
                pal.removeAllViews();
                final Project p = canvas.getProject();
                ImageButton add = iconButton(R.drawable.ic_add, "Guardar el color actual en la paleta", new Runnable() {
                    public void run() { saveSwatchDialog(chosen[0], fill[0]); }
                });
                pal.addView(add);
                if (p != null) for (final Project.Swatch sw : p.swatches) {
                    pal.addView(swatch(sw.color, pickTo, new Runnable() {
                        public void run() { p.swatches.remove(sw); markDirty(); fill[0].run(); toast("Quitado de la paleta"); }
                    }));
                }
                for (Project.Swatch sw : globalSwatches()) pal.addView(swatch(sw.color, pickTo, null));
            }
        };
        fill[0].run();

        picker.setListener(new ColorPickerView.Listener() {
            @Override public void onColorChanged(int color) {
                if (syncing[0]) return;
                chosen[0] = color | 0xFF000000;
                syncUi.run();
            }
        });
        SeekBar.OnSeekBarChangeListener chan = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (syncing[0] || !fromUser) return;
                chosen[0] = hsvMode[0]
                        ? com.pacco.animecut.core.ColorTools.hsvToRgb(s1.getProgress(), s2.getProgress() / 100f, s3.getProgress() / 100f)
                        : Color.rgb(s1.getProgress(), s2.getProgress(), s3.getProgress());
                picker.setColor(chosen[0]);
                syncUi.run();
            }
        };
        s1.setOnSeekBarChangeListener(chan); s2.setOnSeekBarChangeListener(chan); s3.setOnSeekBarChangeListener(chan);
        sa.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) { va.setText(Math.max(1, value) + "%"); }
        });
        modeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                hsvMode[0] = !hsvMode[0];
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("color_hsv", hsvMode[0]).apply();
                modeBtn.setText(hsvMode[0] ? "HSV" : "RGB");
                syncUi.run();
            }
        });
        mixT.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) { if (!syncing[0]) syncUi.run(); }
        });
        setA.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { mixCols[0] = chosen[0]; syncUi.run(); }
        });
        setB.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                mixCols[1] = chosen[0];
                getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("mix_b", chosen[0]).apply();
                syncUi.run();
            }
        });
        kind.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                mixLin[0] = !mixLin[0];
                kind.setText(mixLin[0] ? "Luz" : "Pintura");
                toast(mixLin[0] ? "Mezcla como luz (brillos, sin oscurecer el medio)" : "Mezcla como se ve en pantalla");
                syncUi.run();
            }
        });
        useMix.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pickTo.onColor(com.pacco.animecut.core.ColorTools.mix(mixCols[0], mixCols[1], mixT.getProgress() / 100f, mixLin[0]));
            }
        });
        oldPreview.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pickTo.onColor(previous); }
        });
        refBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestColorReference(pickTo); }
        });
        palBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final Bitmap ref = colorRefBitmap;
                if (ref == null || ref.isRecycled()) { toast("Primero abre una imagen de referencia"); return; }
                final int[][] out = new int[1][];
                Task.run(new Runnable() {
                    @Override public void run() {
                        int w = ref.getWidth(), h = ref.getHeight();
                        float sc = Math.min(1f, 600f / Math.max(w, h));
                        Bitmap b = sc < 1f ? Bitmap.createScaledBitmap(ref, Math.max(1, (int) (w * sc)), Math.max(1, (int) (h * sc)), true) : ref;
                        int[] pxs = new int[b.getWidth() * b.getHeight()];
                        b.getPixels(pxs, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
                        out[0] = com.pacco.animecut.core.ColorTools.palette(pxs, b.getWidth(), b.getHeight(), 12, 24);
                        if (b != ref) b.recycle();
                    }
                }, new Runnable() {
                    @Override public void run() {
                        refPal.removeAllViews();
                        if (out[0] == null) return;
                        for (int c : out[0]) refPal.addView(swatch(c, pickTo, null));
                        toast("Paleta: toca un color para usarlo; + lo guarda");
                    }
                });
            }
        });
        changeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pendingColorRefTarget = pickTo; pickColorRef.launch(new String[]{"image/*"}); }
        });
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { clearColorReference(true); refPal.removeAllViews(); toast("La referencia se puede volver a abrir cuando quieras"); }
        });
        hexGo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Integer parsed = com.pacco.animecut.core.ColorTools.parseHex(hex.getText().toString());
                if (parsed == null) { toast("HEX invalido. Ejemplo: #FF3030"); return; }
                pickTo.onColor(parsed);
            }
        });

        int opa = Math.max(1, Math.round(canvas.getBrushOpacity() * 100f));
        sa.setProgress(opa); va.setText(opa + "%");
        syncUi.run();

        new AlertDialog.Builder(this)
                .setTitle("Color")
                .setView(scroll)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Integer parsed = com.pacco.animecut.core.ColorTools.parseHex(hex.getText().toString());
                        if (parsed != null) chosen[0] = parsed | 0xFF000000;
                        canvas.setColor(chosen[0]);
                        SharedPreferencesHolder.pushRecent(MainActivity.this, chosen[0]);
                        int op = Math.max(1, sa.getProgress());
                        canvas.setBrushOpacity(op / 100f);
                        SeekBar bottomOp = findViewById(R.id.opacity);
                        if (canvas.getMode() != CanvasView.MODE_LIQUIFY) bottomOp.setProgress(op);
                        updateUi();
                    }
                })
                .setNeutralButton("Gotero", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.setMode(CanvasView.MODE_PICKER);
                        toast("Toca la imagen: la lupa muestra el pixel exacto");
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Recientes guardados en preferencias (12, sin repetir). */
    static final class SharedPreferencesHolder {
        static void pushRecent(android.content.Context c, int color) {
            android.content.SharedPreferences sp = c.getSharedPreferences("pz", MODE_PRIVATE);
            sp.edit().putString("recent_colors", com.pacco.animecut.core.ColorTools.pushRecent(sp.getString("recent_colors", ""), color, 12)).apply();
        }
    }

    private LinearLayout swatchRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(2), 0, dp(2));
        return r;
    }

    private TextView sectionTitle(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFF9FC6FF);
        v.setTextSize(11f);
        v.setPadding(0, dp(6), 0, dp(1));
        return v;
    }

    /** Muestra de color: tocar la usa; mantener pulsado la quita (si se puede) o dice su HEX. */
    private View swatch(final int c, final ColorPickTarget to, final Runnable remove) {
        View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(32), dp(32));
        lp.setMargins(dp(2), 0, dp(2), 0);
        sw.setLayoutParams(lp);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(c | 0xFF000000);
        g.setCornerRadius(dp(5));
        g.setStroke(dp(1), 0xFF6A6A72);
        sw.setBackground(g);
        sw.setContentDescription(com.pacco.animecut.core.ColorTools.toHex(c));
        sw.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { to.onColor(c); }
        });
        sw.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (remove != null) remove.run(); else toast(com.pacco.animecut.core.ColorTools.toHex(c));
                return true;
            }
        });
        return sw;
    }

    /** Fila de canal con etiqueta cambiable (RGB / HSV). */
    private TextView addColorChannel2(LinearLayout root, String name, final SeekBar bar, final TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this);
        label.setText(name); label.setTextColor(0xFFE8E8E8); label.setTextSize(13f); label.setGravity(android.view.Gravity.CENTER);
        row.addView(label, new LinearLayout.LayoutParams(dp(24), dp(38)));
        row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        value.setTextColor(0xFFFFFFFF); value.setGravity(android.view.Gravity.CENTER);
        row.addView(value, new LinearLayout.LayoutParams(dp(46), dp(38)));
        root.addView(row);
        return label;
    }

    private TextView smallAction(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setTextColor(0xFFFFFFFF);
        tv.setBackgroundResource(R.drawable.bg_tool);
        tv.setTextSize(12f);
        return tv;
    }

    private void addColorChannel(LinearLayout root, String name, final SeekBar bar, final TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this);
        label.setText(name); label.setTextColor(0xFFE8E8E8); label.setTextSize(13f); label.setGravity(android.view.Gravity.CENTER);
        row.addView(label, new LinearLayout.LayoutParams(dp(name.equals("Opacidad") ? 72 : 26), dp(42)));
        ImageButton minus = iconButton(R.drawable.ic_sub, "Menos", new Runnable() {
            @Override public void run() { bar.setProgress(Math.max(0, bar.getProgress() - (bar.getMax() == 100 ? 5 : 1))); }
        });
        minus.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        row.addView(minus);
        row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        value.setTextColor(0xFFFFFFFF); value.setGravity(android.view.Gravity.CENTER); value.setMinWidth(dp(42));
        row.addView(value, new LinearLayout.LayoutParams(dp(48), dp(42)));
        ImageButton plus = iconButton(R.drawable.ic_add, "Mas", new Runnable() {
            @Override public void run() { bar.setProgress(Math.min(bar.getMax(), bar.getProgress() + (bar.getMax() == 100 ? 5 : 1))); }
        });
        plus.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        row.addView(plus);
        root.addView(row);
    }

    private Integer parseHexColor(String text) {
        if (text == null) return null;
        String s = text.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6) return null;
        try { return 0xFF000000 | (int) Long.parseLong(s, 16); }
        catch (Throwable t) { return null; }
    }

    private int contrastText(int c) {
        int y = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
        return y > 150 ? 0xFF000000 : 0xFFFFFFFF;
    }

    private void addLabeled(LinearLayout root, String name, SeekBar bar, int value,
                            SeekBar.OnSeekBarChangeListener l) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(l);
        root.addView(bar);
    }

    private void renameDialog(final Layer l) {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        in.setText(l.name);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la capa")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        if (!s.isEmpty()) l.name = s;
                        updateUi();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private final android.os.Handler opHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean opPending;

    /** Mientras mueves la barra de opacidad, la imagen se actualiza seguido pero sin trabarse. */
    private void scheduleOpacityRefresh() {
        if (opPending) return;
        opPending = true;
        opHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                opPending = false;
                canvas.refreshDisplayAsync();
            }
        }, 60);
    }

    /**
     * v8.27: "→ capa_1 · Normal" en la barra de la brocha y del balde: el destino se ve sin
     * leer manuales. Tocarlo muestra el texto completo (y en el balde abre sus opciones).
     */
    private TextView destinationChip(final boolean bucket) {
        String full = bucket ? canvas.fillDestinationText() : canvas.paintDestinationText();
        final TextView t = smallTextButton(full.replace("Destino: ", "→ "));
        t.setTextSize(11f);
        t.setSingleLine(true);
        t.setMaxWidth(dp(104));
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setContentDescription(full);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bucket) bucketDestinationDialog();
                else canvas.showHud(canvas.paintDestinationText());
            }
        });
        return t;
    }

    /** v8.27: destino del balde y sus opciones. Se guarda al reiniciar la app. */
    private void bucketDestinationDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(6), dp(18), dp(4));
        root.addView(optLabel("Donde va el color"));
        final RadioGroup g = new RadioGroup(this);
        g.setOrientation(LinearLayout.VERTICAL);
        RadioButton cur = new RadioButton(this);
        cur.setText("Pintar en capa actual: exactamente la capa elegida en Capas (nunca crea otra)");
        cur.setTextColor(0xFFFFFFFF);
        cur.setTextSize(13f);
        cur.setId(2000);
        g.addView(cur);
        RadioButton auto = new RadioButton(this);
        auto.setText("Capa de color automatica: UNA sola capa \"Color\", creada la primera vez y reutilizada siempre. Tu capa elegida no cambia");
        auto.setTextColor(0xFFFFFFFF);
        auto.setTextSize(13f);
        auto.setId(2001);
        g.addView(auto);
        g.check(canvas.getFillTarget() == CanvasView.FILL_TARGET_AUTO ? 2001 : 2000);
        root.addView(g);
        root.addView(optLabel("Como busca la zona"));
        final CheckBox lines = new CheckBox(this);
        lines.setText("Por lineas (manga blanco y negro): la trama, los grises y el ruido no cortan la zona");
        lines.setTextColor(0xFFFFFFFF);
        lines.setTextSize(13f);
        lines.setChecked(canvas.isFillByLines());
        root.addView(lines);
        final CheckBox prev = new CheckBox(this);
        prev.setText("Vista previa antes de pintar (✓ pinta, ✕ cancela)");
        prev.setTextColor(0xFFFFFFFF);
        prev.setTextSize(13f);
        prev.setChecked(canvas.isBucketPreview());
        root.addView(prev);
        TextView tip = new TextView(this);
        tip.setText(canvas.fillDestinationText() + "\n\"Colorear manga\" (Menu) usa su propia capa \"Color base\" en Multiplicar.");
        tip.setTextColor(0xFFB8B8C0);
        tip.setTextSize(12f);
        tip.setPadding(0, dp(8), 0, 0);
        root.addView(tip);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new AlertDialog.Builder(this).setTitle("Balde").setView(sv)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Listo", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setFillTarget(g.getCheckedRadioButtonId() == 2001
                                ? CanvasView.FILL_TARGET_AUTO : CanvasView.FILL_TARGET_CURRENT);
                        canvas.setFillByLines(lines.isChecked());
                        canvas.setBucketPreview(prev.isChecked());
                        applyFillPrefs();
                        canvas.showHud(canvas.fillDestinationText());
                        updateUi();
                    }
                })
                .show();
    }

    /** Pinceles como la lista basica de Ibis: cada uno con su propio trazo. */
    private void brushPresets() {
        final com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        int current = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset4", 0);
        if (current < 0 || current >= list.length) current = 0;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText("Pinceles");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(17f);
        title.setPadding(dp(6), dp(2), 0, dp(4));
        root.addView(title);
        final android.widget.CheckBox flat = new android.widget.CheckBox(this);
        flat.setText("Repasar no oscurece (color parejo con poca opacidad)");
        flat.setTextColor(0xFFDDDDDD);
        flat.setTextSize(12.5f);
        flat.setChecked(canvas.isFlatPaint());
        flat.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                canvas.setFlatPaint(on);
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("flat_paint", on).apply();
            }
        });
        root.addView(flat);
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < list.length; i++) {
            final com.pacco.animecut.core.BrushPreset bp = list[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            if (i == current) {
                android.graphics.drawable.GradientDrawable sel = new android.graphics.drawable.GradientDrawable();
                sel.setColor(0xFF1E2A44);
                sel.setStroke(dp(2), 0xFF3D7BFF);
                sel.setCornerRadius(dp(8));
                row.setBackground(sel);
            } else {
                row.setBackgroundResource(R.drawable.bg_cell);
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, 0, 0, dp(4));
            row.setLayoutParams(rlp);
            row.setPadding(dp(10), dp(6), dp(10), dp(6));
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(android.view.Gravity.CENTER_VERTICAL);
            TextView t = new TextView(this);
            t.setText(bp.name + (i == current ? "  (en uso)" : ""));
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12.5f);
            top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView sz = new TextView(this);
            sz.setText(String.format(Locale.US, bp.size < 10 ? "%.1f" : "%.0f", bp.size));
            sz.setTextColor(0xFFAAAAAA);
            sz.setTextSize(12f);
            top.addView(sz);
            row.addView(top);
            final ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
            img.setScaleType(ImageView.ScaleType.FIT_XY);
            row.addView(img);
            // las muestras se dibujan aparte para que la lista abra al instante
            final int pw = dp(260), ph = dp(34);
            thumbPool.execute(new Runnable() {
                @Override
                public void run() {
                    final Bitmap b = bp.preview(pw, ph);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            img.setImageBitmap(b);
                        }
                    });
                }
            });
            final int idx = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dlg[0].dismiss();
                    applyBrushPreset(idx, true);
                    canvas.showHud(bp.name);
                }
            });
            root.addView(row);
        }
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        dlg[0] = new AlertDialog.Builder(this).setView(sc).create();
        dlg[0].show();
    }

    /** v8.28: Plano (0) / Suave (1) sin cambiar el tamano elegido. */
    private void applyBrushStyle(int idx) {
        com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        if (idx < 0 || idx >= list.length) return;
        com.pacco.animecut.core.BrushPreset bp = list[idx];
        canvas.setBrushDynamics(bp.taperStart, bp.taperEnd, bp.speedThin, bp.particles, bp.grain, bp.spacing, bp.flow);
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("brush_preset4", idx)
                .putFloat("brush_hardness_v827", bp.hardness).apply();
        canvas.setHardness(bp.hardness);
    }

    /** v8.29: el ojo de Borrar fondo: cuadros -> blanco -> negro -> gris -> verde. */
    private void cycleViewBg() {
        final int[] order = {0, 2, 3, 5, 4};
        final String[] names = {"Cuadros", "Blanco", "Negro", "Gris", "Verde"};
        int cur = 0;
        for (int k = 0; k < order.length; k++) if (order[k] == canvas.getViewBg()) cur = k;
        int nx = (cur + 1) % order.length;
        canvas.setViewBg(order[nx]);
        canvas.showHud("Ver: " + names[nx]);
        if (layersOpen()) buildViewBg();
    }

    /** v8.29: todos los ajustes de Borrar fondo juntos (antes eran 6 botones en la barra). */
    private static String gapLabel(int g) {
        return "Cerrar huecos de la linea: " + (g / 100) + "," + (g % 100 / 10) + "x" + (g == 100 ? " (normal)" : "");
    }

    private void bgSettingsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(6));
        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        final TextView tt = new TextView(this);
        tt.setTextColor(0xFFFFFFFF);
        tt.setText("Parecido del color: " + canvas.getBgTolerance());
        root.addView(tt);
        SeekBar tb = new SeekBar(this);
        tb.setMax(160);
        tb.setProgress(canvas.getBgTolerance());
        tb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s0, int v, boolean u) {
                canvas.setBgTolerance(v);
                tt.setText("Parecido del color: " + v);
                if (u) sp.edit().putInt("bg_tol", v).apply();
            }
        });
        root.addView(tb);
        // v8.32: "Borde suave" ya no hace falta: el borde sale de desmezclar la linea y el fondo
        final CheckBox once = new CheckBox(this);
        once.setText("Tomar el color solo al empezar");
        once.setTextColor(0xFFFFFFFF);
        once.setChecked(canvas.isBgOnce());
        once.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                canvas.setBgOnce(on);
                sp.edit().putBoolean("bg_once", on).apply();
            }
        });
        root.addView(once);
        // v8.32: CERRAR HUECOS (veces el grosor medido de las lineas). 1x = normal. Mas = no pasa
        // por cortes mas grandes de la linea; menos = entra en rincones mas angostos.
        final TextView gt = new TextView(this);
        gt.setTextColor(0xFFFFFFFF);
        gt.setPadding(0, dp(8), 0, 0);
        gt.setText(gapLabel(Math.round(canvas.getBgGapScale() * 100)));
        root.addView(gt);
        SeekBar gb = new SeekBar(this);
        gb.setMax(250);
        gb.setProgress(Math.round(canvas.getBgGapScale() * 100) - 50);
        gb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s0, int v, boolean u) {
                int g = v + 50;
                canvas.setBgGapScale(g / 100f);
                gt.setText(gapLabel(g));
                if (u) sp.edit().putInt("bg_gap", g).apply();
            }
        });
        root.addView(gb);
        final TextView ht = new TextView(this);
        ht.setTextColor(0xFFFFFFFF);
        ht.setPadding(0, dp(8), 0, 0);
        ht.setText("Dureza del borrador: " + Math.round(canvas.getBgEraserHard() * 100) + "%");
        root.addView(ht);
        SeekBar hb = new SeekBar(this);
        hb.setMax(100);
        hb.setProgress(Math.round(canvas.getBgEraserHard() * 100));
        hb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s0, int v, boolean u) {
                canvas.setBgEraserHard(v / 100f);
                ht.setText("Dureza del borrador: " + v + "%");
                if (u) sp.edit().putInt("bg_er_hard", v).apply();
            }
        });
        root.addView(hb);
        final CheckBox prot = new CheckBox(this);
        prot.setText("Proteger el color elegido");
        prot.setTextColor(0xFFFFFFFF);
        prot.setChecked(canvas.isProtect());
        prot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { canvas.setProtect(on); }
        });
        root.addView(prot);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        TextView refine = smallTextButton("Refinar borde");
        refine.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { edgeRefineDialog(); }
        });
        TextView fab = smallTextButton("De fabrica");
        fab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                sp.edit().putInt("bg_tol", 46).putInt("bg_soft", 42).putBoolean("bg_once", false)
                        .putInt("bg_gap", 100).putInt("bg_er_hard", 85).apply();
                canvas.setBgTolerance(46);
                canvas.setBgSoftness(42);
                canvas.setBgOnce(false);
                canvas.setBgGapScale(1f);
                canvas.setBgEraserHard(0.85f);
                canvas.showHud("Borrar fondo: de fabrica");
            }
        });
        row.addView(refine);
        row.addView(fab);
        root.addView(row);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new AlertDialog.Builder(this).setTitle("Borrar fondo").setView(sv).setPositiveButton("Listo", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int w) { updateUi(); }
        }).show();
    }

    /** v8.28: cambia el fondo de VISTA (cuadros, blanco, negro, gris, verde). No toca el PNG. */
    private TextView viewBgChip() {
        final int[] order = {0, 2, 3, 5, 4};
        final String[] names = {"Cuadros", "Blanco", "Negro", "Gris", "Verde"};
        int cur = 0;
        for (int k = 0; k < order.length; k++) if (order[k] == canvas.getViewBg()) cur = k;
        final int curF = cur;
        TextView t = smallTextButton("Ver: " + names[cur]);
        t.setContentDescription("Fondo para revisar el recorte (no se guarda en el PNG)");
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int n = (curF + 1) % order.length;
                canvas.setViewBg(order[n]);
                canvas.showHud("Fondo de vista: " + names[n] + " (el PNG queda transparente)");
                if (layersOpen()) buildViewBg();
                updateUi();
            }
        });
        return t;
    }

    /** Aplica un pincel. Con all=false solo su forma de trazo (al abrir la app). */
    private void applyBrushPreset(int idx, boolean all) {
        com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        if (idx < 0 || idx >= list.length) return;
        com.pacco.animecut.core.BrushPreset bp = list[idx];
        canvas.setBrushDynamics(bp.taperStart, bp.taperEnd, bp.speedThin, bp.particles, bp.grain, bp.spacing, bp.flow);
        if (!all) return;
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("brush_preset4", idx)
                .putFloat("brush_hardness_v827", bp.hardness).apply();
        canvas.setBrushSize(bp.size);
        canvas.setHardness(bp.hardness);
        canvas.setBrushOpacity(bp.opacity / 100f);
        if (canvas.getMode() != CanvasView.MODE_LIQUIFY)
            ((SeekBar) findViewById(R.id.opacity)).setProgress(bp.opacity);
        syncSlider();
        updateUi();
    }

    private void toleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getTolerance());
        final TextView t = new TextView(this);
        t.setText(String.valueOf(canvas.getTolerance()));
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText(String.valueOf(v));
                canvas.setTolerance(v);
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Elegir que parte se esta rayando: un color por parte, el gris es el fondo. */
    private void labelPicker() {
        int n = CanvasView.LABEL_NAMES.length;
        int[] icons = new int[n];
        String[] names = new String[n];
        Runnable[] actions = new Runnable[n];
        for (int i = 0; i < n; i++) {
            icons[i] = R.drawable.ic_color;
            names[i] = i == n - 1 ? "fondo" : "parte " + (i + 1);
            final int lab = i + 1;
            actions[i] = new Runnable() {
                public void run() {
                    canvas.setMarkerLabel(lab);
                    canvas.setSubtract(false);
                    canvas.showHud(lab == CanvasView.LABEL_NAMES.length ? "Rayando el fondo" : "Rayando parte " + lab);
                    updateUi();
                }
            };
        }
        showIconGridTinted(icons, names, actions, 3, canvas.getMarkerLabel() - 1, CanvasView.LABEL_COLORS);
    }

    private void showIconGridTinted(int[] icons, String[] names, Runnable[] actions, int cols,
                                    int active, int[] tints) {
        tintNext = tints;
        showIconGrid(null, icons, names, actions, cols, active);
        tintNext = null;
    }

    /** Cuadricula de iconos con su nombre corto debajo. */
    private void showIconGrid(String title, int[] icons, String[] names, final Runnable[] actions,
                              int cols, int active) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                root.addView(row);
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(4), dp(10), dp(4), dp(10));
            cell.setBackgroundResource(i == active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(3), dp(3), dp(3), dp(3));
            cell.setLayoutParams(clp);

            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
            img.setImageResource(icons[i]);
            if (tintNext != null && i < tintNext.length) img.setColorFilter(tintNext[i]);
            cell.addView(img);

            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, dp(4), 0, 0);
            cell.addView(t);

            final int idx = i;
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    actions[idx].run();
                }
            });
            if (demoNext != null && i < demoNext.length) {
                final int scene = demoNext[i];
                cell.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showSelCard(scene);
                        return true;
                    }
                });
            }
            row.addView(cell);
        }
        // rellenar la ultima fila para que no se estiren las celdas
        int rest = icons.length % cols;
        if (rest != 0 && row != null) {
            for (int k = rest; k < cols; k++) {
                View v = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
                v.setLayoutParams(lp);
                row.addView(v);
            }
        }
        if (demoNext != null) {
            TextView hint = new TextView(this);
            hint.setText("Manten presionado un boton para ver que hace");
            hint.setTextColor(0xFF9FC6FF);
            hint.setTextSize(12f);
            hint.setGravity(android.view.Gravity.CENTER);
            hint.setPadding(0, dp(8), 0, dp(2));
            root.addView(hint);
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setView(root);
        if (title != null) b.setTitle(title);
        dlg[0] = b.create();
        dlg[0].show();
    }

    /** Ficha de la herramienta: dibujo de antes y despues y tres lineas cortas. */
    private void showToolCard(int mode, int sub) {
        String[] info = toolInfo(mode, sub);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(info[0]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        View art = demoFor(mode, sub);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        root.addView(cardLine("Para que:", info[1]));
        root.addView(cardLine("Como:", info[2]));
        if (!info[3].isEmpty()) root.addView(cardLine("", info[3]));
        new AlertDialog.Builder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    private TextView cardLine(String head, String text) {
        TextView t = new TextView(this);
        t.setText(head.isEmpty() ? text : head + " " + text);
        t.setTextColor(head.isEmpty() ? 0xFF9FC6FF : 0xFFE0E0E0);
        t.setTextSize(13f);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    /**
     * La primera vez que eliges una herramienta sale su ficha completa. Las
     * siguientes veces, un cuadrito con la animacion unos segundos.
     */
    private void cardFirstTime(int mode, int sub) {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        String key = "card_" + mode + "_" + sub;
        if (!sp.getBoolean(key, false)) {
            sp.edit().putBoolean(key, true).apply();
            showToolCard(mode, sub);
            return;
        }
        if (sp.getBoolean("demo_on", true)) showDemo(mode, sub);
    }

    /** Animacion de la herramienta. Separar y la varita usan la de antes y despues. */
    private View demoFor(int mode, int sub) {
        if (mode == CanvasView.MODE_MARKER) return new SelDemoView(this, SelDemoView.SEPARATE);
        if (mode == CanvasView.MODE_WAND && canvas.isAutoLines()) return new SelDemoView(this, SelDemoView.WAND_LINES);
        int variant = mode == CanvasView.MODE_LIQUIFY ? canvas.getLiquifyType() : 0;
        return new com.pacco.animecut.view.ToolDemoView(this, mode, sub == 2, variant);
    }

    /** Cuadrito arriba a la izquierda con la herramienta trabajando. Se va solo. */
    private void showDemo(int mode, int sub) {
        final View box = findViewById(R.id.demoBox);
        FrameLayout holder = findViewById(R.id.demoHolder);
        holder.removeAllViews();
        holder.addView(demoFor(mode, sub),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        String demoTitle = toolInfo(mode, sub)[0];
        if (mode == CanvasView.MODE_LIQUIFY) {
            int lt = canvas.getLiquifyType();
            demoTitle = "Especial · " + (lt == 0 ? "Arrastrar" : lt == 1 ? "Contraer"
                    : lt == 2 ? "Expandir" : lt == 3 ? "Suavizar" : "Restaurar");
        }
        ((TextView) findViewById(R.id.demoName)).setText(demoTitle);
        box.setVisibility(View.VISIBLE);
        box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                box.setVisibility(View.GONE);
            }
        });
        if (hideDemo != null) box.removeCallbacks(hideDemo);
        hideDemo = new Runnable() {
            @Override
            public void run() {
                box.setVisibility(View.GONE);
                ((FrameLayout) findViewById(R.id.demoHolder)).removeAllViews();
            }
        };
        box.postDelayed(hideDemo, 4500);
    }

    private void tutorialPage(final int page) {
        final int[] modes = {CanvasView.MODE_BGERASE, CanvasView.MODE_MARKER, CanvasView.MODE_ZONE,
                CanvasView.MODE_PAN};
        final String[] titles = {"1. Saca el personaje", "2. Separa las partes",
                "3. Rellena lo de atras", "4. Exporta"};
        final String[] texts = {
                "Tu imagen queda en la capa \"imagen\". Con Borrar fondo pasas el pincel por el borde y "
                        + "solo se borra el fondo. En Capas puedes mirar sobre negro o verde para ver si quedo limpio.",
                "Separar: raya cada parte con un color (pelo, cara, ojos) y el fondo en gris, y toca el check "
                        + "verde. Cada parte sale en su capa. Tambien: Varita y en el cuadro punteado, Copiar a capa.",
                "Donde sacaste un ojo o un brazo, en la capa de atras queda el dibujo viejo. Marca esa zona en azul, "
                        + "toca esa capa en Capas y usa Zona tocando dentro de lo azul: queda con el color de alrededor.",
                "La flecha de abajo guarda un PNG por cada capa visible, todas del mismo tamano, "
                        + "listas para Alight Motion."
        };        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(titles[page]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        com.pacco.animecut.view.ToolDemoView art =
                new com.pacco.animecut.view.ToolDemoView(this, modes[page], false);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        TextView t = new TextView(this);
        t.setText(texts[page]);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(14f);
        root.addView(t);
        TextView foot = new TextView(this);
        foot.setText((page + 1) + " de 4    Manten pulsada cualquier herramienta para ver su ficha");
        foot.setTextColor(0xFF8A8A92);
        foot.setTextSize(11f);
        foot.setPadding(0, dp(10), 0, 0);
        root.addView(foot);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setView(root);
        if (page < 3) {
            b.setPositiveButton("Siguiente", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    tutorialPage(page + 1);
                }
            });
            b.setNegativeButton("Saltar", null);
        } else {
            b.setPositiveButton("Empezar", null);
        }
        b.show();
    }

    /** Tutorial: cuatro fichas con dibujo, una detras de otra. */
    private void guideDialog() {
        tutorialPage(0);
    }

    private void guideIfFirstTime() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("guia3", false)) return;
        sp.edit().putBoolean("guia3", true).apply();
        guideDialog();
    }

    private void projectDialog() {
        final boolean has = canvas.getProject() != null;
        final String[] items = {
                "Guardar proyecto en un archivo",
                "Abrir un proyecto guardado",
                "Guardar ahora en la app"
        };
        new AlertDialog.Builder(this)
                .setTitle("Proyecto")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 1) {
                            openProject.launch(new String[]{"*/*"});
                            return;
                        }
                        if (!has) {
                            toast("Abre una imagen primero");
                            return;
                        }
                        if (i == 0) createProject.launch("proyecto.acut");
                        else autosave(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void saveProjectTo(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int color = canvas.getColor();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    ProjectIO.save(os, p, color);
                    if (os != null) os.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al guardar: " + lastError);
                else toast("Proyecto guardado con sus " + p.layers.size() + " capas");
            }
        });
    }

    private void openProjectFrom(final Uri uri) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    loaded = ProjectIO.load(is);
                    if (is != null) is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void recoverFrom(final File f) {
        onBusy(true);
        lastError = null;
        loaded = null;
        recoveredBackup = false;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try (FileInputStream is = new FileInputStream(f)) {
                    loaded = ProjectIO.load(is);
                } catch (Throwable t) {
                    // Un cierre inesperado no debe inutilizar toda la obra.
                    File bak = new File(f.getAbsolutePath() + ".bak");
                    try (FileInputStream is = new FileInputStream(bak)) {
                        loaded = ProjectIO.load(is);
                        lastError = null;
                        recoveredBackup = true;
                    } catch (Throwable fallback) {
                        lastError = String.valueOf(t.getMessage());
                    }
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    /** Mantiene la proporcion para que todas las capas sigan cuadrando entre si. */
    private int[] longSide(Project p, int target) {
        int max = Math.max(p.w, p.h);
        if (max <= target) return new int[]{p.w, p.h};
        float f = target / (float) max;
        return new int[]{Math.max(1, Math.round(p.w * f)), Math.max(1, Math.round(p.h * f))};
    }

    private int toolIcon(int mode) {
        switch (mode) {
            case CanvasView.MODE_LASSO: return R.drawable.ic_lasso;
            case CanvasView.MODE_SCISSORS: return R.drawable.ic_scissors;
            case CanvasView.MODE_BRUSH: return R.drawable.ic_brush;
            case CanvasView.MODE_ERASER: return R.drawable.ic_eraser;
            case CanvasView.MODE_PAINT: return R.drawable.ic_paint;
            case CanvasView.MODE_BUCKET: return R.drawable.ic_bucket;
            case CanvasView.MODE_PICKER: return R.drawable.ic_picker;
            case CanvasView.MODE_CLONE: return R.drawable.ic_clone;
            case CanvasView.MODE_MOVE: return R.drawable.ic_move;
            case CanvasView.MODE_PAN: return R.drawable.ic_hand;
            case CanvasView.MODE_BGERASE: return R.drawable.ic_bgerase;
            case CanvasView.MODE_MARKER: return R.drawable.ic_marker;
            case CanvasView.MODE_MAGNET: return R.drawable.ic_magnet;
            case CanvasView.MODE_LINE: return R.drawable.ic_line_cont;
            case CanvasView.MODE_CURVE: return R.drawable.ic_curve;
            case CanvasView.MODE_POLY: return R.drawable.ic_poly;
            case CanvasView.MODE_ZONE: return R.drawable.ic_zone;
            case CanvasView.MODE_PATCH: return R.drawable.ic_patch_fill;
            case CanvasView.MODE_HEAL: return R.drawable.ic_heal;
            case CanvasView.MODE_TONE: return R.drawable.ic_tone;
            case CanvasView.MODE_SMUDGE: return R.drawable.ic_smudge;
            case CanvasView.MODE_BLUR: return R.drawable.ic_blur;
            case CanvasView.MODE_LIQUIFY: return R.drawable.ic_liquify;
            case CanvasView.MODE_TRANSFORM: return R.drawable.ic_transform;
            case CanvasView.MODE_PUPPET: return R.drawable.ic_puppet;
            default: return R.drawable.ic_wand;
        }
    }

    private void fillRow(LinearLayout row, int used, int cols) {
        for (int k = used; k < cols; k++) {
            View v = new View(this);
            v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
            row.addView(v);
        }
    }

    private void closeTools() {
        findViewById(R.id.toolPanel).setVisibility(View.GONE);
        findViewById(R.id.toolScrim).setVisibility(View.GONE);
        FrameLayout.LayoutParams l = (FrameLayout.LayoutParams) findViewById(R.id.toolPanel).getLayoutParams();
        l.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        findViewById(R.id.toolPanel).setLayoutParams(l);
    }

    /** v8.33: de donde viene la luz (8 flechas) + ancho de la sombra. */
    private void autoShadeDialog() {
        final Project p = canvas.getProject();
        if (p == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(4));
        TextView t = new TextView(this);
        t.setText("Toca de donde VIENE la luz:");
        box.addView(t);
        final String[] arrows = {"↖", "↑", "↗", "←", "", "→", "↙", "↓", "↘"};
        final float[][] dir = {{1, 1}, {0, 1}, {-1, 1}, {1, 0}, {0, 0}, {-1, 0}, {1, -1}, {0, -1}, {-1, -1}};
        final int[] chosen = {getSharedPreferences("pz", MODE_PRIVATE).getInt("shade_dir", 0)};
        final TextView[] cells = new TextView[9];
        for (int r = 0; r < 3; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for (int c = 0; c < 3; c++) {
                final int k = r * 3 + c;
                TextView b = smallTextButton(arrows[k]);
                b.setTextSize(20f);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(46));
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                b.setLayoutParams(lp);
                if (k == 4) b.setVisibility(View.INVISIBLE);
                cells[k] = b;
                b.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        chosen[0] = k;
                        for (int q = 0; q < 9; q++) cells[q].setBackgroundResource(q == k ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                    }
                });
                row.addView(b);
            }
            box.addView(row);
        }
        cells[chosen[0] == 4 ? 0 : chosen[0]].setBackgroundResource(R.drawable.bg_tool_on);
        TextView wt = new TextView(this);
        wt.setText("Ancho de la sombra");
        wt.setPadding(0, dp(8), 0, 0);
        box.addView(wt);
        final SeekBar wb = new SeekBar(this);
        wb.setMax(100);
        wb.setProgress(getSharedPreferences("pz", MODE_PRIVATE).getInt("shade_w", 35));
        box.addView(wb);
        final CheckBox parts = new CheckBox(this);
        parts.setText("Por partes (cara, pelo y ropa por separado)");
        parts.setChecked(true);
        box.addView(parts);
        new AlertDialog.Builder(this)
                .setTitle("Sombra automatica")
                .setView(box)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        int k = chosen[0] == 4 ? 0 : chosen[0];
                        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("shade_dir", k).putInt("shade_w", wb.getProgress()).apply();
                        int width = Math.max(2, Math.round(Math.max(p.w, p.h) * (0.005f + wb.getProgress() / 100f * 0.06f)));
                        canvas.addAutoShade(dir[k][0], dir[k][1], width, parts.isChecked());
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    // ---- v8.33: Recortar con IA ----
    private AiCutFlow aiFlow;

    private AiCutFlow aiFlow() {
        if (aiFlow == null) aiFlow = new AiCutFlow(this, canvas);
        return aiFlow;
    }

    /** Despues de aplicar el recorte de la IA. */
    void afterAiCut() {
        markDirty();
        updateUi();
    }

    /** Corre algo corto en segundo plano con un aviso, y despues "after" en pantalla. */
    void runBusy(String text, Runnable bg, Runnable after) {
        if (text != null) canvas.showHud(text);
        Task.run(bg, after);
    }

    private ImageButton iconButton(int icon, final String name, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setImageResource(icon);
        b.setContentDescription(name);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                toast(name);
                return true;
            }
        });
        return b;
    }

    /** Boton compacto para Transformar: evita que X/✓ queden fuera de pantalla. */
    private ImageButton compactIconButton(int icon, final String name, final Runnable action) {
        ImageButton b = iconButton(icon, name, action);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(31), dp(36)));
        b.setPadding(dp(6), dp(7), dp(6), dp(7));
        return b;
    }

    private ImageView thumb(Bitmap b) {
        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageBitmap(b);
        return img;
    }

    private TextView rowText(String name, String sub, boolean bright) {
        TextView t = new TextView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(10);
        t.setLayoutParams(lp);
        t.setText(name + "\n" + sub);
        t.setTextColor(bright ? 0xFFFFFFFF : 0xFF7A7A7A);
        t.setTextSize(13f);
        return t;
    }

    private LinearLayout rowBase(boolean on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);
        return row;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void click(int id, final Runnable r) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
    }

    private boolean needProject() {
        if (canvas.getProject() == null) {
            toast("Abre una imagen primero");
            return false;
        }
        return true;
    }

    /** Marca en azul lo que esta activado, para que se vea sin leer nada. */
    private void toggle(int id, boolean on) {
        findViewById(id).setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
    }

    private boolean sliderIsTolerance() {
        int m = canvas.getMode();
        return m == CanvasView.MODE_WAND || m == CanvasView.MODE_BUCKET;
    }

    private void applySlider(int v) {
        if (sliderIsTolerance()) {
            canvas.setTolerance(v);
            sliderLabel.setText(String.valueOf(v));
        } else {
            float t = v / 120f;
            float size = 1f + t * t * 299f;
            canvas.setBrushSize(size);
            canvas.showSizePreview(size);
            String sizeText = String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size);
            sliderLabel.setText(canvas.getMode() == CanvasView.MODE_LIQUIFY
                    ? "Grosor\n" + sizeText + "px" : sizeText);
            ((TextView) findViewById(R.id.btnSize)).setText(
                    String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void syncSlider() {
        if (sliderIsTolerance()) {
            slider.setProgress(canvas.getTolerance());
            sliderLabel.setText(String.valueOf(canvas.getTolerance()));
        } else {
            float t = (float) Math.sqrt(Math.max(0f, (canvas.getBrushSize() - 1f) / 299f));
            slider.setProgress(Math.round(t * 120f));
            float size = canvas.getBrushSize();
            String sizeText = String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size);
            sliderLabel.setText(canvas.getMode() == CanvasView.MODE_LIQUIFY
                    ? "Grosor\n" + sizeText + "px" : sizeText);
        }
    }

    private void measureBars() {
        final View top = findViewById(R.id.topBar);
        final View bottom = findViewById(R.id.bottomPanel);
        top.post(new Runnable() {
            @Override
            public void run() {
                canvas.setInsets(top.getHeight() + dp(12), bottom.getHeight());
                if (canvas.getProject() != null) canvas.fit();
                barsMeasured = true;
                if (pendingReveal) revealCanvas();
            }
        });
    }

    /** Para no repetir los tres metodos del SeekBar en cada dialogo. */
    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }

    // ==================================================================
    // v8.26 COLOREAR MANGA (interfaz)
    // ==================================================================

    private void loadMangaPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        canvas.setMangaToneLevel(sp.getInt("manga_tone_level", 1));
        canvas.setMangaGapLevel(sp.getInt("manga_gap", 2));
        canvas.setMangaExpand(sp.getInt("manga_expand", 2));
        canvas.setMangaInk(sp.getInt("manga_ink", 128));
        canvas.setFillPreview(sp.getBoolean("manga_preview", true));
        canvas.setShowProtect(sp.getBoolean("manga_show_protect", true));
        canvas.setPickSource(sp.getInt("pick_source", CanvasView.PICK_AUTO));
    }

    private void saveMangaPrefs() {
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putInt("manga_tone_level", canvas.getMangaToneLevel())
                .putInt("manga_gap", canvas.getMangaGapLevel())
                .putInt("manga_expand", canvas.getMangaExpand())
                .putInt("manga_ink", canvas.getMangaInk())
                .putBoolean("manga_preview", canvas.isFillPreview())
                .putBoolean("manga_show_protect", canvas.isShowProtect())
                .putInt("pick_source", canvas.getPickSource())
                .apply();
    }

    /** Entrada del menu: prepara el preset o, si ya esta activo, muestra sus acciones. */
    private void mangaEntry() {
        if (!needProject()) return;
        if (canvas.isMangaMode()) {
            mangaMenu();
            return;
        }
        final Project p = canvas.getProject();
        int c = canvas.mangaInkCandidate();
        if (c == -2) {
            canvas.prepareManga(-1);
            afterMangaReady();
            return;
        }
        if (c >= 0) {
            final int idx = c;
            new AlertDialog.Builder(this)
                    .setTitle("Colorear manga")
                    .setMessage("Se prepara asi (el manga original NO cambia):\n\n"
                            + "- \"" + p.layers.get(idx).name + "\" pasa a llamarse \"Tinta B/N\", queda BLOQUEADA y sus lineas "
                            + "marcan los limites del balde.\n"
                            + "- Encima se crea \"Color base\" en Multiplicar: el color no tapa la tinta, los grises ni las tramas.\n\n"
                            + "Luego: elige un color y toca una zona. Veras una vista previa antes de pintar.")
                    .setPositiveButton("Preparar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            if (canvas.prepareManga(idx)) afterMangaReady();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        // varias capas con dibujo: el usuario elige cual es el manga
        final List<Integer> idxs = new ArrayList<Integer>();
        final List<String> names = new ArrayList<String>();
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            Layer l = p.layers.get(i);
            if (l.bounds(p.w, p.h) == null) continue;
            idxs.add(i);
            names.add(l.name + (l.visible ? "" : " (oculta)"));
        }
        if (idxs.isEmpty()) {
            toast("No hay ninguna capa con dibujo");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("¿Cual capa es el manga original?")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (canvas.prepareManga(idxs.get(i))) afterMangaReady();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void afterMangaReady() {
        selectTool(CanvasView.MODE_BUCKET);
        if (layersOpen()) buildLayersPanel();
        updateUi();
        markDirty();
    }

    /** Acciones del preset, agrupadas para no llenar la pantalla. */
    private void mangaMenu() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final List<String> items = new ArrayList<String>();
        items.add("Sombra rapida (capa recortada, Multiplicar 40 %)");
        items.add("Luz rapida (capa recortada, Pantalla 60 %)");
        items.add("Brillo encima (capa Normal arriba de todo, para ojos)");
        items.add("Cambiar color de la capa elegida (tono, saturacion, luz)");
        if (p.hasSelection()) {
            items.add("Rellenar lo seleccionado con el color");
            items.add("Proteger lo seleccionado (No colorear)");
            items.add("Quitar proteccion de lo seleccionado");
        }
        if (canvas.hasProtectZones()) items.add("Borrar todas las zonas protegidas");
        items.add(canvas.isShowProtect() ? "Ver zonas protegidas: SI" : "Ver zonas protegidas: NO");
        items.add("Imagen de referencia de colores");
        items.add("Paleta de la obra (" + p.swatches.size() + " colores)");
        items.add("Gotero: " + pickName(canvas.getPickSource()));
        items.add("Ajustes del balde manga");
        items.add("Salir de Colorear manga");
        new AlertDialog.Builder(this)
                .setTitle("Colorear manga")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        runMangaItem(items.get(i));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void runMangaItem(String it) {
        if (it.startsWith("Sombra rapida")) {
            canvas.addQuickShadeLayer(true);
            afterLayerOp();
        } else if (it.startsWith("Luz rapida")) {
            canvas.addQuickShadeLayer(false);
            afterLayerOp();
        } else if (it.startsWith("Brillo encima")) {
            canvas.addShineLayer();
            afterLayerOp();
        } else if (it.startsWith("Cambiar color")) {
            Layer l = canvas.getProject().activeLayer();
            if (l == null) toast("Elige una capa en Capas");
            else changeColorDialog(l);
        } else if (it.startsWith("Rellenar lo seleccionado")) {
            canvas.fillSelectionWithColor();
        } else if (it.startsWith("Proteger lo seleccionado")) {
            canvas.protectSelection(true);
            updateUi();
        } else if (it.startsWith("Quitar proteccion")) {
            canvas.protectSelection(false);
            updateUi();
        } else if (it.startsWith("Borrar todas las zonas")) {
            canvas.clearProtect();
        } else if (it.startsWith("Ver zonas")) {
            canvas.setShowProtect(!canvas.isShowProtect());
            saveMangaPrefs();
        } else if (it.startsWith("Imagen de referencia")) {
            requestColorReference(paintColorTarget());
        } else if (it.startsWith("Paleta")) {
            paletteDialog();
        } else if (it.startsWith("Gotero")) {
            pickSourceDialog();
        } else if (it.startsWith("Ajustes del balde")) {
            mangaFillSettingsDialog();
        } else if (it.startsWith("Salir")) {
            new AlertDialog.Builder(this)
                    .setTitle("Salir de Colorear manga")
                    .setMessage("El balde vuelve a ser el normal y la Tinta B/N se desbloquea. Tus capas de color se quedan.")
                    .setPositiveButton("Salir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.exitManga();
                            afterLayerOp();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        }
    }

    private static String pickName(int s) {
        return s == CanvasView.PICK_VISIBLE ? "Visible (lo que se ve)"
                : s == CanvasView.PICK_LAYER ? "Capa actual" : "Automatico (Capa actual en Multiplicar)";
    }

    private void pickSourceDialog() {
        final String[] items = {"Automatico: en capas Multiplicar toma de la capa; si no, lo visible",
                "Visible: el color que se ve (tinta + color)",
                "Capa actual: el color guardado en la capa elegida"};
        new AlertDialog.Builder(this)
                .setTitle("¿De donde toma el color el gotero?")
                .setSingleChoiceItems(items, canvas.getPickSource(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        d.dismiss();
                        canvas.setPickSource(i);
                        saveMangaPrefs();
                        canvas.showHud("Gotero: " + pickName(i));
                        updateUi();
                    }
                })
                .show();
    }

    /** Ajustes del balde manga, todos en un solo lugar. */
    private void mangaFillSettingsDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        final TextView inkT = smallText("");
        final SeekBar ink = new SeekBar(this);
        ink.setMax(160);
        ink.setProgress(canvas.getMangaInk() - 40);
        final Runnable inkLabel = new Runnable() {
            @Override public void run() {
                int v = ink.getProgress() + 40;
                inkT.setText("Que cuenta como linea: " + v + (v < 100 ? " (solo lo muy negro)" : v > 160 ? " (tambien grises)" : " (medio)"));
            }
        };
        inkLabel.run();
        ink.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { inkLabel.run(); }
        });
        root.addView(inkT);
        root.addView(ink);
        root.addView(optLabel("Cerrar huecos de lineas abiertas"));
        final RadioGroup gap = choiceRow(com.pacco.animecut.core.MangaFill.GAP_NAMES, canvas.getMangaGapLevel(), new IntConsumerCompat() { public void accept(int v) { } });
        root.addView(gap);
        final TextView expT = smallText("");
        final SeekBar exp = new SeekBar(this);
        exp.setMax(4);
        exp.setProgress(canvas.getMangaExpand());
        final Runnable expLabel = new Runnable() {
            @Override public void run() {
                expT.setText("Meter el color bajo la linea: " + exp.getProgress() + " px (evita bordes blancos)");
            }
        };
        expLabel.run();
        exp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { expLabel.run(); }
        });
        root.addView(expT);
        root.addView(exp);
        root.addView(optLabel("Modo trama (puntos de trama dentro de la zona)"));
        final RadioGroup tone = choiceRow(new String[]{"No", "Puntos", "Densa"}, canvas.getMangaToneLevel(),
                new IntConsumerCompat() { public void accept(int v) { } });
        root.addView(tone);
        root.addView(smallText("Densa: tambien entra hasta 24 px en la trama tupida pegada (puede tocar la trama de la zona de al lado: revisa la vista previa)."));
        final CheckBox prev = new CheckBox(this);
        prev.setText("Vista previa antes de pintar (Aceptar / Cancelar)");
        prev.setTextColor(0xFFFFFFFF);
        prev.setChecked(canvas.isFillPreview());
        root.addView(prev);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        new AlertDialog.Builder(this)
                .setTitle("Balde manga")
                .setView(sv)
                .setPositiveButton("Listo", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setMangaInk(ink.getProgress() + 40);
                        int g = 0;
                        for (int k = 0; k < gap.getChildCount(); k++)
                            if (((RadioButton) gap.getChildAt(k)).isChecked()) g = k;
                        canvas.setMangaGapLevel(g);
                        canvas.setMangaExpand(exp.getProgress());
                        int tl = 1;
                        for (int k = 0; k < tone.getChildCount(); k++)
                            if (((RadioButton) tone.getChildAt(k)).isChecked()) tl = k;
                        canvas.setMangaToneLevel(tl);
                        canvas.setFillPreview(prev.isChecked());
                        saveMangaPrefs();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Barra del balde en modo manga. Con vista previa pendiente: Aceptar / Parecidas / Cancelar. */
    private void buildMangaBucketBar(LinearLayout bar) {
        if (canvas.hasFillPreview()) {
            ImageButton ok = iconButton(R.drawable.ic_check, "Aceptar: pintar la vista previa", new Runnable() {
                public void run() {
                    canvas.acceptFillPreview();
                    updateUi();
                }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
            bar.addView(iconButton(R.drawable.ic_similar, "Parecidas: sugerir zonas como esta (tu confirmas)", new Runnable() {
                public void run() {
                    canvas.suggestSimilarZones();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_close, "Cancelar: no pintar nada", new Runnable() {
                public void run() {
                    canvas.cancelFillPreview();
                    updateUi();
                }
            }));
            TextView info = smallText(canvas.fillPreviewCount() == 1 ? "Toca otra zona para sumarla"
                    : canvas.fillPreviewCount() + " zonas. Toca una para quitarla");
            info.setPadding(dp(6), 0, dp(6), 0);
            bar.addView(info);
            return;
        }
        ImageButton tone = iconButton(R.drawable.ic_tone, "Modo trama: " + CanvasView.TONE_NAMES[canvas.getMangaToneLevel()], new Runnable() {
            public void run() {
                canvas.setMangaToneLevel((canvas.getMangaToneLevel() + 1) % 3);
                saveMangaPrefs();
                int lv = canvas.getMangaToneLevel();
                canvas.showHud(lv == 0 ? "Modo trama apagado: cada punto de trama corta la zona"
                        : lv == 1 ? "Modo trama: los puntitos sueltos no cortan la zona"
                        : "Trama densa: tambien entra en la trama tupida pegada (revisa la vista previa)");
                updateUi();
            }
        });
        tone.setBackgroundResource(canvas.getMangaToneLevel() > 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(tone);
        bar.addView(iconButton(R.drawable.ic_join, "Cerrar huecos: " + com.pacco.animecut.core.MangaFill.GAP_NAMES[canvas.getMangaGapLevel()],
                new Runnable() {
                    public void run() {
                        canvas.setMangaGapLevel((canvas.getMangaGapLevel() + 1) % 4);
                        saveMangaPrefs();
                        canvas.showHud("Cerrar huecos: " + com.pacco.animecut.core.MangaFill.GAP_NAMES[canvas.getMangaGapLevel()]);
                        updateUi();
                    }
                }));
        ImageButton exp = iconButton(R.drawable.ic_grow, "Color bajo la linea: " + canvas.getMangaExpand() + " px", new Runnable() {
            public void run() {
                canvas.setMangaExpand(canvas.getMangaExpand() > 0 ? 0 : 2);
                saveMangaPrefs();
                canvas.showHud(canvas.getMangaExpand() > 0 ? "Color bajo la linea: " + canvas.getMangaExpand() + " px"
                        : "Color bajo la linea: apagado");
                updateUi();
            }
        });
        exp.setBackgroundResource(canvas.getMangaExpand() > 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(exp);
        ImageButton pv = iconButton(R.drawable.ic_preview, canvas.isFillPreview() ? "Vista previa: SI" : "Vista previa: NO", new Runnable() {
            public void run() {
                canvas.setFillPreview(!canvas.isFillPreview());
                saveMangaPrefs();
                canvas.showHud(canvas.isFillPreview() ? "Vista previa antes de pintar" : "Pinta al tocar (sin vista previa)");
                updateUi();
            }
        });
        pv.setBackgroundResource(canvas.isFillPreview() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
        bar.addView(pv);
        bar.addView(iconButton(R.drawable.ic_shield, "Zonas protegidas (No colorear)", new Runnable() {
            public void run() {
                protectMenu();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_manga, "Colorear manga: mas opciones", new Runnable() {
            public void run() {
                mangaMenu();
            }
        }));
    }

    private void protectMenu() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final List<String> items = new ArrayList<String>();
        if (p.hasSelection()) {
            items.add("Proteger lo seleccionado (No colorear)");
            items.add("Quitar proteccion de lo seleccionado");
        } else {
            items.add("Marcar zona con Lazo (luego vuelve aqui)");
        }
        if (canvas.hasProtectZones()) items.add("Borrar todas las zonas protegidas");
        items.add(canvas.isShowProtect() ? "Ver zonas protegidas: SI" : "Ver zonas protegidas: NO");
        new AlertDialog.Builder(this)
                .setTitle("Zonas protegidas (globos, rayas de velocidad...)")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        String it = items.get(i);
                        if (it.startsWith("Marcar zona")) {
                            selectTool(CanvasView.MODE_LASSO);
                            toast("Rodea el globo o las rayas con el Lazo; al soltar elige Proteger");
                        } else {
                            runMangaItem(it);
                        }
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Al terminar un Lazo en modo manga: lo mas comun a mano. */
    private void mangaLassoDialog() {
        final String[] items = {"Rellenar con el color elegido", "Proteger esta zona (No colorear)",
                "Crear una capa con esta parte", "Nada por ahora (seguir marcando)"};
        new AlertDialog.Builder(this)
                .setTitle("Zona marcada")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 0) canvas.fillSelectionWithColor();
                        else if (i == 1) canvas.protectSelection(true);
                        else if (i == 2) partFromSelectionDialog(false);
                        updateUi();
                    }
                })
                .show();
    }

    /** Barra del Lazo / Varita en modo manga. */
    private void buildMangaSelectionBar(LinearLayout bar) {
        bar.addView(iconButton(R.drawable.ic_bucket, "Rellenar lo seleccionado", new Runnable() {
            public void run() {
                canvas.fillSelectionWithColor();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_shield, "Proteger lo seleccionado (No colorear)", new Runnable() {
            public void run() {
                canvas.protectSelection(true);
                updateUi();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_grow, "Expandir o contraer lo seleccionado", new Runnable() {
            public void run() {
                expandDialog();
            }
        }));
        bar.addView(iconButton(R.drawable.ic_manga, "Colorear manga: mas opciones", new Runnable() {
            public void run() {
                mangaMenu();
            }
        }));
    }

    /** "Cambiar color" de una capa: NO destructivo (se puede volver a 0 o fijar). */
    private void changeColorDialog(final Layer l) {
        final int[] prev = {l.hue, l.sat, l.lit};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        TextView info = smallText("Cambia el color de \"" + l.name + "\" sin repintar. La transparencia y la tinta no cambian. "
                + "Se guarda con la obra y se puede volver a 0.");
        root.addView(info);
        final TextView ht = smallText(""), st = smallText(""), lt = smallText("");
        final SeekBar hb = new SeekBar(this), sb = new SeekBar(this), lb = new SeekBar(this);
        hb.setMax(360);
        sb.setMax(200);
        lb.setMax(200);
        hb.setProgress(l.hue + 180);
        sb.setProgress(l.sat + 100);
        lb.setProgress(l.lit + 100);
        root.addView(ht); root.addView(hb);
        root.addView(st); root.addView(sb);
        root.addView(lt); root.addView(lb);
        final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable apply = new Runnable() {
            @Override public void run() {
                canvas.previewLayerAdjust(l, hb.getProgress() - 180, sb.getProgress() - 100, lb.getProgress() - 100);
            }
        };
        final Runnable labels = new Runnable() {
            @Override public void run() {
                ht.setText("Tono: " + signed(hb.getProgress() - 180) + " grados");
                st.setText("Saturacion: " + signed(sb.getProgress() - 100));
                lt.setText("Luminosidad: " + signed(lb.getProgress() - 100));
            }
        };
        labels.run();
        SimpleSeek seek = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
                labels.run();
                hd.removeCallbacks(apply);
                hd.postDelayed(apply, 60);
            }
        };
        hb.setOnSeekBarChangeListener(seek);
        sb.setOnSeekBarChangeListener(seek);
        lb.setOnSeekBarChangeListener(seek);
        final boolean hasSel = canvas.getProject() != null && canvas.getProject().hasSelection();
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Cambiar color")
                .setView(root)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        hd.removeCallbacks(apply);
                        canvas.commitLayerAdjust(l, prev, hb.getProgress() - 180, sb.getProgress() - 100, lb.getProgress() - 100);
                        afterLayerOp();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        hd.removeCallbacks(apply);
                        canvas.previewLayerAdjust(l, prev[0], prev[1], prev[2]);
                    }
                });
        if (hasSel) {
            b.setNeutralButton("Solo lo azul", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) {
                    hd.removeCallbacks(apply);
                    int h0 = hb.getProgress() - 180, s0 = sb.getProgress() - 100, l0 = lb.getProgress() - 100;
                    canvas.previewLayerAdjust(l, prev[0], prev[1], prev[2]);
                    canvas.adjustSelectionColors(h0, s0, l0);
                    toast("Cambiado solo lo seleccionado (se puede deshacer)");
                }
            });
        }
        AlertDialog dlg = b.create();
        dlg.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override public void onCancel(DialogInterface d) {
                hd.removeCallbacks(apply);
                canvas.previewLayerAdjust(l, prev[0], prev[1], prev[2]);
            }
        });
        dlg.show();
    }

    // ---------------- paleta de la obra ----------------

    private static final String[] SWATCH_NAMES = {"Piel", "Sombra piel", "Cabello", "Ojos", "Ropa", "Luces"};

    private ColorPickTarget paintColorTarget() {
        return new ColorPickTarget() {
            @Override public void onColor(int color) {
                canvas.setColor(color | 0xFF000000);
                canvas.showHud(String.format(Locale.US, "Color #%06X", color & 0xFFFFFF));
                updateUi();
            }
        };
    }

    /** Guardar una muestra con nombre (en la obra y, si se quiere, en la paleta global). */
    private void saveSwatchDialog(final int color, final Runnable after) {
        final Project p = canvas.getProject();
        if (p == null) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        View sw = new View(this);
        sw.setBackgroundColor(color | 0xFF000000);
        root.addView(sw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Nombre");
        String sug = SWATCH_NAMES[Math.min(SWATCH_NAMES.length - 1, p.swatches.size() % SWATCH_NAMES.length)];
        name.setText(sug);
        root.addView(name);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(chips);
        for (final String s : SWATCH_NAMES) {
            TextView c = smallTextButton(s);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { name.setText(s); }
            });
            chips.addView(c);
        }
        root.addView(hs);
        final CheckBox global = new CheckBox(this);
        global.setText("Guardar tambien en la paleta global (para otras obras)");
        global.setTextColor(0xFFFFFFFF);
        root.addView(global);
        new AlertDialog.Builder(this)
                .setTitle("Guardar muestra")
                .setView(root)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String n = name.getText().toString().trim();
                        if (n.isEmpty()) n = "Color";
                        p.swatches.add(new Project.Swatch(n, color | 0xFF000000));
                        if (global.isChecked()) addGlobalSwatch(n, color | 0xFF000000);
                        markDirty();
                        toast("Muestra \"" + n + "\" guardada en la obra");
                        if (after != null) after.run();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private List<Project.Swatch> globalSwatches() {
        List<Project.Swatch> out = new ArrayList<Project.Swatch>();
        String txt = getSharedPreferences("pz", MODE_PRIVATE).getString("global_palette", "");
        com.pacco.animecut.core.ProjectIO.parsePalette(txt, out);
        return out;
    }

    private void addGlobalSwatch(String n, int c) {
        List<Project.Swatch> g = globalSwatches();
        g.add(new Project.Swatch(n, c));
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putString("global_palette", com.pacco.animecut.core.ProjectIO.paletteText(g)).apply();
    }

    private void saveGlobal(List<Project.Swatch> g) {
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putString("global_palette", com.pacco.animecut.core.ProjectIO.paletteText(g)).apply();
    }

    /** Paleta de la obra + global: tocar = usar; mantener = renombrar / ajustar / borrar. */
    private void paletteDialog() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final List<Project.Swatch> global = globalSwatches();
        final List<Object[]> rows = new ArrayList<Object[]>();
        for (Project.Swatch s : p.swatches) rows.add(new Object[]{s, Boolean.FALSE});
        for (Project.Swatch s : global) rows.add(new Object[]{s, Boolean.TRUE});
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(8), dp(12), dp(4));
        if (rows.isEmpty()) root.addView(smallText("Todavia no hay muestras. En la Imagen de referencia toca un color y pulsa \"Guardar\"."));
        final AlertDialog[] dlg = new AlertDialog[1];
        boolean globalHeader = false;
        for (final Object[] r : rows) {
            final Project.Swatch s = (Project.Swatch) r[0];
            final boolean isGlobal = (Boolean) r[1];
            if (isGlobal && !globalHeader) {
                globalHeader = true;
                root.addView(optLabel("Paleta global"));
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(3), 0, dp(3));
            View sw = new View(this);
            sw.setBackgroundColor(s.color | 0xFF000000);
            row.addView(sw, new LinearLayout.LayoutParams(dp(40), dp(32)));
            TextView t = smallText("  " + s.name + String.format(Locale.US, "  #%06X", s.color & 0xFFFFFF));
            row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    canvas.setColor(s.color | 0xFF000000);
                    canvas.showHud("Color \"" + s.name + "\"");
                    updateUi();
                    if (dlg[0] != null) dlg[0].dismiss();
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    swatchActions(s, isGlobal, global);
                    return true;
                }
            });
            root.addView(row);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        dlg[0] = new AlertDialog.Builder(this)
                .setTitle("Paleta (tocar: usar · mantener: editar)")
                .setView(sv)
                .setPositiveButton("Guardar el color actual", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        saveSwatchDialog(canvas.getColor(), null);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void swatchActions(final Project.Swatch s, final boolean isGlobal, final List<Project.Swatch> global) {
        final Project p = canvas.getProject();
        final String[] items = isGlobal
                ? new String[]{"Copiar a la paleta de esta obra", "Borrar de la paleta global"}
                : new String[]{"Renombrar", "Ajustar tono / saturacion / brillo", "Borrar de la obra"};
        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int i) {
                        if (isGlobal) {
                            if (i == 0) { p.swatches.add(new Project.Swatch(s.name, s.color)); markDirty(); }
                            else { global.remove(s); saveGlobal(global); }
                            return;
                        }
                        if (i == 0) {
                            final EditText e = new EditText(MainActivity.this);
                            e.setText(s.name);
                            new AlertDialog.Builder(MainActivity.this).setTitle("Nombre").setView(e)
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override public void onClick(DialogInterface d2, int w) {
                                            s.name = e.getText().toString().trim();
                                            markDirty();
                                        }
                                    }).show();
                        } else if (i == 1) {
                            sampleAdjustDialog(s.color, new ColorPickTarget() {
                                @Override public void onColor(int c) { s.color = c; markDirty(); }
                            });
                        } else {
                            p.swatches.remove(s);
                            markDirty();
                        }
                    }
                })
                .show();
    }

    /** Ajusta una muestra (HSV y opacidad) sin tocar la imagen de referencia. */
    private void sampleAdjustDialog(final int color, final ColorPickTarget done) {
        final float[] hsv = new float[3];
        Color.colorToHSV(color | 0xFF000000, hsv);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(4));
        final View sw = new View(this);
        sw.setBackgroundColor(color | 0xFF000000);
        root.addView(sw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
        final TextView t = smallText("");
        root.addView(t);
        final SeekBar h = new SeekBar(this), s = new SeekBar(this), v = new SeekBar(this), a = new SeekBar(this);
        h.setMax(360); s.setMax(100); v.setMax(100); a.setMax(100);
        h.setProgress(Math.round(hsv[0])); s.setProgress(Math.round(hsv[1] * 100)); v.setProgress(Math.round(hsv[2] * 100));
        a.setProgress(Math.round((color >>> 24) * 100 / 255f));
        if (a.getProgress() == 0) a.setProgress(100);
        root.addView(optLabel("Tono")); root.addView(h);
        root.addView(optLabel("Saturacion")); root.addView(s);
        root.addView(optLabel("Brillo")); root.addView(v);
        root.addView(optLabel("Opacidad")); root.addView(a);
        final int[] out = {color | 0xFF000000};
        SimpleSeek k = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar sb, int val, boolean u) {
                int rgb = Color.HSVToColor(new float[]{h.getProgress(), s.getProgress() / 100f, v.getProgress() / 100f});
                int al = Math.max(3, Math.round(a.getProgress() * 255 / 100f));
                out[0] = (al << 24) | (rgb & 0xFFFFFF);
                sw.setBackgroundColor(rgb | 0xFF000000);
                t.setText(String.format(Locale.US, "#%06X  opacidad %d%%", rgb & 0xFFFFFF, a.getProgress()));
            }
        };
        h.setOnSeekBarChangeListener(k); s.setOnSeekBarChangeListener(k); v.setOnSeekBarChangeListener(k); a.setOnSeekBarChangeListener(k);
        k.onProgressChanged(h, 0, false);
        new AlertDialog.Builder(this)
                .setTitle("Ajustar muestra")
                .setView(root)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { done.onColor(out[0]); }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ---------------- referencia guardada con la obra ----------------

    /** Copia compacta (lado max 1024) para guardar dentro de la obra. */
    private static byte[] compactReferencePng(Bitmap src) {
        if (src == null || src.isRecycled()) return null;
        int w = src.getWidth(), h = src.getHeight();
        float s = Math.min(1f, 1024f / Math.max(w, h));
        Bitmap b = s < 1f ? Bitmap.createScaledBitmap(src, Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s)), true) : src;
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, bo);
        if (b != src) b.recycle();
        return bo.toByteArray();
    }

    private boolean keepRefInProject() {
        return getSharedPreferences("pz", MODE_PRIVATE).getBoolean("ref_in_project", false);
    }

    private void setKeepRefInProject(boolean on) {
        getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("ref_in_project", on).apply();
        Project p = canvas.getProject();
        if (p == null) return;
        p.refImagePng = on ? compactReferencePng(colorRefBitmap) : null;
        markDirty();
        toast(on ? "La referencia (copia reducida) se guarda con la obra. No se exporta nunca."
                : "La referencia ya no se guarda con la obra");
    }

    /** Al abrir una obra con referencia guardada, se carga para poder sacar colores. */
    private void restoreProjectReference() {
        Project p = canvas.getProject();
        if (p == null || p.refImagePng == null) return;
        Bitmap b = BitmapFactory.decodeByteArray(p.refImagePng, 0, p.refImagePng.length);
        if (b == null) return;
        if (colorRefWindow != null) { try { colorRefWindow.dismiss(); } catch (Throwable ignored) {} }
        colorRefWindow = null;
        colorRefView = null;
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) colorRefBitmap.recycle();
        colorRefBitmap = b;
    }

    /**
     * Paleta automatica (corte por la mediana, determinista): se ignoran casi blancos
     * y casi negros, y se ordena por tono. NO reemplaza tomar colores a mano.
     */
    private int[] autoPaletteMedianCut(Bitmap bmp, int count) {
        if (bmp == null) return new int[0];
        int w = bmp.getWidth(), h = bmp.getHeight();
        int step = Math.max(1, (int) Math.sqrt((double) w * h / 40000.0));
        ArrayList<Integer> px = new ArrayList<Integer>();
        for (int y = 0; y < h; y += step) for (int x = 0; x < w; x += step) {
            int c = bmp.getPixel(x, y);
            if ((c >>> 24) < 128) continue;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int l = (r * 77 + g * 151 + b * 28) >> 8;
            if (l > 242 || l < 20) continue;
            px.add(c | 0xFF000000);
        }
        if (px.isEmpty()) return new int[0];
        List<List<Integer>> boxes = new ArrayList<List<Integer>>();
        boxes.add(px);
        while (boxes.size() < count) {
            int bi = -1, bestRange = -1, bestCh = 0;
            for (int k = 0; k < boxes.size(); k++) {
                List<Integer> bx = boxes.get(k);
                if (bx.size() < 2) continue;
                for (int ch = 0; ch < 3; ch++) {
                    int mn = 255, mx = 0;
                    for (int c : bx) { int v = (c >> (16 - 8 * ch)) & 255; if (v < mn) mn = v; if (v > mx) mx = v; }
                    if (mx - mn > bestRange) { bestRange = mx - mn; bi = k; bestCh = ch; }
                }
            }
            if (bi < 0 || bestRange < 12) break;
            final int sh = 16 - 8 * bestCh;
            List<Integer> bx = boxes.remove(bi);
            java.util.Collections.sort(bx, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) { return ((a >> sh) & 255) - ((b >> sh) & 255); }
            });
            int mid = bx.size() / 2;
            boxes.add(new ArrayList<Integer>(bx.subList(0, mid)));
            boxes.add(new ArrayList<Integer>(bx.subList(mid, bx.size())));
        }
        final float[][] hsvs = new float[boxes.size()][];
        int[] cols = new int[boxes.size()];
        for (int k = 0; k < boxes.size(); k++) {
            long r = 0, g = 0, b = 0;
            List<Integer> bx = boxes.get(k);
            for (int c : bx) { r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255; }
            int n = Math.max(1, bx.size());
            cols[k] = 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
        }
        Integer[] order = new Integer[cols.length];
        for (int k = 0; k < cols.length; k++) {
            order[k] = k;
            hsvs[k] = new float[3];
            Color.colorToHSV(cols[k], hsvs[k]);
        }
        java.util.Arrays.sort(order, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer a, Integer b) {
                float ha = hsvs[a][1] < .12f ? 400 : hsvs[a][0], hb = hsvs[b][1] < .12f ? 400 : hsvs[b][0];
                if (Math.abs(ha - hb) > 12) return Float.compare(ha, hb);
                return Float.compare(hsvs[b][2], hsvs[a][2]);
            }
        });
        int[] out = new int[cols.length];
        for (int k = 0; k < out.length; k++) out[k] = cols[order[k]];
        return out;
    }

    private void autoPaletteDialog() {
        final int[] cols = autoPaletteMedianCut(colorRefBitmap, 10);
        if (cols.length == 0) {
            toast("No encontre colores (la imagen es casi blanco y negro)");
            return;
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(6));
        final AlertDialog[] dlg = new AlertDialog[1];
        for (final int c : cols) {
            View sw = new View(this);
            sw.setBackgroundColor(c);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    saveSwatchDialog(c, null);
                }
            });
            row.addView(sw, lp);
        }
        dlg[0] = new AlertDialog.Builder(this)
                .setTitle("Paleta automatica (toca uno para guardarlo)")
                .setView(row)
                .setNegativeButton("Cerrar", null)
                .show();
    }

    // ---------------- exportar imagen completa ----------------

    private boolean pendingFlatExport;

    private void doExportFlat(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    Exporter.exportFlattened(getContentResolver(), p, uri, p.w, p.h);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override public void run() {
                onBusy(false);
                toast(lastError != null ? "Error: " + lastError : "Imagen completa guardada (como se ve en pantalla)");
            }
        });
    }
}
