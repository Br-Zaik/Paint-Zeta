package com.pacco.animecut.core;

/**
 * v8.37: "B/N" de Borrar fondo. El Balde y el Pincel protegido MIRAN una copia en blanco y negro
 * (ajustable) para decidir que es fondo; lo que se borra se aplica a la capa ORIGINAL, que nunca
 * pierde su color. La vista en pantalla usa la misma transformacion (matriz de color), asi lo
 * que ves es lo que mira la herramienta.
 *
 * Transformacion lineal (una matriz 4x5 como la ColorMatrix de Android):
 *  1) gris = canal elegido (Normal = luminancia, o solo Rojo / Verde / Azul, como los filtros de
 *     color de la foto en blanco y negro: separan dos colores que tienen el mismo brillo);
 *  2) saturacion: cuanto color se deja (0 = blanco y negro puro);
 *  3) contraste y brillo.
 * Java puro: lo usan la app y las pruebas.
 */
public final class GrayView {
    public static final int CH_NORMAL = 0, CH_RED = 1, CH_GREEN = 2, CH_BLUE = 3;
    public static final String[] CH_NAMES = {"Normal", "Rojo", "Verde", "Azul"};

    /** Canal del gris. */
    public int channel = CH_NORMAL;
    /** 0..100: cuanto color queda (0 = blanco y negro). */
    public int saturation = 0;
    /** -100..100. */
    public int contrast = 0;
    /** -100..100. */
    public int brightness = 0;

    public GrayView copy() {
        GrayView g = new GrayView();
        g.channel = channel; g.saturation = saturation; g.contrast = contrast; g.brightness = brightness;
        return g;
    }

    public boolean sameAs(GrayView o) {
        return o != null && o.channel == channel && o.saturation == saturation && o.contrast == contrast && o.brightness == brightness;
    }

    public void reset() { channel = CH_NORMAL; saturation = 0; contrast = 0; brightness = 0; }

    /** Matriz 4x5 (filas R, G, B, A; columnas R, G, B, A, suma) para ColorMatrix. */
    public float[] matrix() {
        float wr, wg, wb;
        switch (channel) {
            case CH_RED: wr = 1f; wg = 0f; wb = 0f; break;
            case CH_GREEN: wr = 0f; wg = 1f; wb = 0f; break;
            case CH_BLUE: wr = 0f; wg = 0f; wb = 1f; break;
            default: wr = 0.299f; wg = 0.587f; wb = 0.114f;
        }
        float s = Math.max(0, Math.min(100, saturation)) / 100f, t = 1f - s;
        int c = Math.max(-100, Math.min(100, contrast));
        float k = c < 0 ? 1f + c / 100f : 1f + c / 50f;          // 0 .. 3
        float off = 128f * (1f - k) + Math.max(-100, Math.min(100, brightness)) * 1.28f;
        float[] m = new float[20];
        for (int row = 0; row < 3; row++) {
            m[row * 5] = k * (t * wr + (row == 0 ? s : 0f));
            m[row * 5 + 1] = k * (t * wg + (row == 1 ? s : 0f));
            m[row * 5 + 2] = k * (t * wb + (row == 2 ? s : 0f));
            m[row * 5 + 3] = 0f;
            m[row * 5 + 4] = off;
        }
        m[18] = 1f;   // alfa igual
        return m;
    }

    /** La matriz en enteros (x1024), para que sea rapido en el telefono. */
    public int[] quantized() {
        float[] m = matrix();
        int[] q = new int[15];
        for (int r = 0; r < 3; r++) {
            q[r * 5] = Math.round(m[r * 5] * 1024f);
            q[r * 5 + 1] = Math.round(m[r * 5 + 1] * 1024f);
            q[r * 5 + 2] = Math.round(m[r * 5 + 2] * 1024f);
            q[r * 5 + 4] = Math.round(m[r * 5 + 4] * 1024f);
        }
        return q;
    }

    /** Un color transformado con la matriz en enteros (mismo alfa). */
    public static int map(int c, int[] q) {
        int R = (c >> 16) & 255, G = (c >> 8) & 255, B = c & 255;
        int nr = clamp((q[0] * R + q[1] * G + q[2] * B + q[4] + 512) >> 10);
        int ng = clamp((q[5] * R + q[6] * G + q[7] * B + q[9] + 512) >> 10);
        int nb = clamp((q[10] * R + q[11] * G + q[12] * B + q[14] + 512) >> 10);
        return (c & 0xFF000000) | nr << 16 | ng << 8 | nb;
    }

    /** Copia transformada de src (mismo alfa). dst puede ser null (se crea). */
    public int[] apply(int[] src, int[] dst) {
        if (src == null) return null;
        if (dst == null || dst.length != src.length) dst = new int[src.length];
        int[] q = quantized();
        for (int i = 0; i < src.length; i++) dst[i] = map(src[i], q);
        return dst;
    }

    /** Copia el alfa de px a la copia en la zona (lo que se borro de verdad). */
    public static void syncAlpha(int[] px, int[] copy, int W, int x0, int y0, int x1, int y1) {
        if (px == null || copy == null || copy.length != px.length) return;
        for (int y = Math.max(0, y0); y < y1; y++) {
            int o = y * W;
            for (int x = Math.max(0, x0); x < x1; x++) {
                int i = o + x;
                copy[i] = (px[i] & 0xFF000000) | (copy[i] & 0x00FFFFFF);
            }
        }
    }

    static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }
}
