# Paint Zeta 9.05

## Colorear: Borrar con 2 modos (como Borrar fondo)

Al elegir Borrar en el paso 1 de Colorear salen dos botones:

- **Protegido** (viene puesto): arrastras el dedo y el color se borra, pero NO pasa la linea negra.
  Solo se quita la parte donde empezaste el trazo. Mientras pasas el dedo se ve en rojo lo que se
  va a borrar; lo que la linea protege se ve gris claro. Si empiezas encima de la linea o en un
  rinconcito, toma la parte por donde sigue el dedo. Tambien respeta las lineas de Separar.
- **Libre**: borra justo por donde pasa el dedo, sin limites (como en la 9.04).

En los dos, un toque sin arrastrar sigue quitando la parte entera. El modo elegido se recuerda.

Las lineas se preparan en otro hilo al elegir Borrar (son las mismas del balde). Si todavia no
estan listas cuando sueltas el dedo, se calculan en ese momento y luego se borra.
