# Paint Zeta v8.99 — Marcar ordenado, Stickers y Guardar nuevo

Incluye todo lo de la 8.98 (arreglo del cierre al pasar a "2 Acabado").

## Marcar > Texto
- Causa: se escribia en una cajita invisible y diminuta. En algunos celulares (moto e30) el
  teclado no salia, y cuando salia tapaba el texto. Ademas cada letra rehacia el texto con todos
  sus efectos: en gama baja se trababa.
- Ahora: como iMarkup. Sale una pantalla oscura con "Escribe algo" ARRIBA y el teclado al toque.
  Con el check (o Atras) el texto va a la imagen, una sola vez. La X lo deja como estaba.
- El texto queda donde tocaste (antes subia solo para que no lo tape el teclado).
- Boton grande "+ Escribir texto": pone el texto en el medio.
- La fila de estilos (Normal, Meme...) y la ayuda larga ya no estan encima: los estilos siguen en
  Estilo > Rapido al tocar un texto.

## Marcar > barra de abajo
- Antes: solo iconos (no se entendia que era cada uno).
- Ahora: cada uno con su nombre debajo: Texto, Foco, Tapar, Lupa, 1 2 3, Flechas, Sticker.
  Si no caben en un celular angosto, la fila se desliza.

## Marcar > lo dibujado a mano
- Antes: lo hecho a mano (lapiz, flecha a mano, foco y tapar a mano) solo se podia mover.
- Ahora: tiene un punto verde en la esquina para girar y agrandar (como iMarkup).
  Tapar "con el dedo" sigue igual (solo se mueve).

## Marcar > Stickers (nuevo)
- 3 pestanas: Senales (20 dibujadas por nosotros: check, X, prohibido, cuidado, !!, ?, corazon,
  estrella, flechas, volver, NUEVO, OK, SOS, alfiler), Manos y Caras (emojis del telefono).
- Tocas uno y sale en el medio, elegido. Se mueve con el dedo; punto verde: girar y agrandar;
  X quita y +1 copia. Con el check se pintan en la capa Marcas, como las demas marcas.

## Guardar imagen
- Antes: todo junto, muchos botones rojos y verdes pegados, textos cortados ("WhatsA pp").
- Ahora: "Para donde" con iconos redondos y su nombre (Galeria, WhatsApp, Instagram, Historias,
  Facebook, Correo, X): cada uno pone solo la medida y el formato justos. "Calidad" con 3
  opciones (Normal, Alta, Maxima). Formato, medida, peso, nombre y "guardar directo" estan en
  "Mas opciones" (cerrado). Abajo dos botones grandes: Compartir y Guardar. Colores tranquilos.
- Galeria siempre guarda PNG (con transparencia): Maxima = medida original, Alta = lado 2048,
  Normal = lado 1280.

## Firma
- Misma firma fija: se instala encima de la 8.98 sin desinstalar.

## Revision
- Revisado con el compilador de Java sobre todo el codigo: solo faltan las piezas de Android,
  como siempre. Los 20 stickers dibujados se probaron en PC (se ven bien). No probado en un telefono.

## Como probarlo
1. Marcar > Texto: toca "+ Escribir texto" o toca la imagen. Debe salir la pantalla oscura con el
   teclado. Escribe, toca el check: el texto aparece donde tocaste.
2. Toca el texto otra vez: vuelve a la pantalla para cambiarlo. La X lo deja como estaba.
3. Flechas > Lapiz: dibuja algo, tocalo, arrastra el punto verde: gira y se agranda.
4. Sticker: toca uno de cada pestana, muevelo, giralo con el punto verde, copialo con +1.
   Toca el check de abajo: quedan pintados.
5. Guardar: elige WhatsApp y luego Galeria, cambia la Calidad, abre "Mas opciones". Guarda y comparte.
