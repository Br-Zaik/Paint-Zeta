package com.pacco.animecut;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

/**
 * v9.04 (pedido de Brian): las ventanas de opciones salen CENTRADAS y un poco transparentes (se ve
 * el dibujo detras), con esquinas redondeadas. En v8.96 se habian pasado abajo y opacas.
 */
final class SheetBuilder extends AlertDialog.Builder {

    SheetBuilder(Context c) {
        super(c, android.R.style.Theme_Material_Dialog_Alert);
    }

    @Override
    public AlertDialog create() {
        AlertDialog d = super.create();
        sheet(d);
        return d;
    }

    @Override
    public AlertDialog show() {
        AlertDialog d = create();
        d.show();
        Window w = d.getWindow();
        if (w != null) w.setLayout(width(d.getContext()), ViewGroup.LayoutParams.WRAP_CONTENT);
        return d;
    }

    /** Ancho de la ventana: casi toda la pantalla, sin pasarse en tablets. */
    static int width(Context c) {
        float dn = c.getResources().getDisplayMetrics().density;
        int sw = c.getResources().getDisplayMetrics().widthPixels;
        return Math.min(sw - Math.round(24f * dn), Math.round(520f * dn));
    }

    /** Pone una ventana en el centro, un poco transparente, con esquinas redondeadas. */
    static void sheet(Dialog d) {
        Window w = d.getWindow();
        if (w == null) return;
        float r = 18f * d.getContext().getResources().getDisplayMetrics().density;
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xD9202026);       // ~85%: un poco transparente
        g.setCornerRadius(r);
        w.setBackgroundDrawable(g);
        w.setGravity(Gravity.CENTER);
        w.setLayout(width(d.getContext()), ViewGroup.LayoutParams.WRAP_CONTENT);
        w.setDimAmount(0.25f);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }
}
