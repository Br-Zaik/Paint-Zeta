package com.pacco.animecut.core;

/**
 * v9.07 PINTAR CON IMAGEN (Colorear, paso 1). Java puro: se prueba en la PC.
 *
 * Idea del video de Ibis Paint (pantalon de jean): en vez de pegar una foto de tela encima y
 * estirarla (se ve falso), se "pinta" la tela sobre la parte del dibujo y se oscurece con el gris
 * del dibujo: quedan las lineas, las sombras y los pliegues, y la tela encima.
 *
 * Las texturas de la app son NUESTRAS (se calculan con formulas, no son fotos de nadie) y toman
 * el color elegido en la paleta: jean azul, jean negro o jean rosa salen del mismo "Jean".
 * Todas pensadas para anime, manga y manhwa: ropa (jean, tela, cuadros, lunares), fondos y
 * efectos (cielo, galaxia, brillos) y la trama de puntitos del manga.
 */
public final class Textures {
    private Textures() { }

    /** Nombres en el orden de los botones (0 = imagen propia de la galeria). */
    public static final String[] NAMES = {"Mi imagen", "Jean", "Tela", "Cuadros", "Lunares", "Trama", "Cielo", "Galaxia", "Brillos"};
    public static final String[] HELP = {
            "Una foto o dibujo de tu galeria",
            "Tela de jean (sarga en diagonal)",
            "Tela tejida (algodon, uniforme)",
            "Cuadros escoceses (falda, camisa)",
            "Lunares blancos",
            "Trama de puntitos de manga",
            "Cielo con nubes",
            "Galaxia con estrellas",
            "Brillos y destellos"};

    // ------------------------------------------------------------------ ruido sin memoria

    private static float hash(int x, int y) {
        int h = x * 374761393 + y * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) / 16777216f;
    }

    private static float smooth(float t) { return t * t * (3f - 2f * t); }

    /** Ruido de valor suave (0..1). */
    static float noise(float x, float y) {
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
        float fx = smooth(x - xi), fy = smooth(y - yi);
        float a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
        return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
    }

    static float fbm(float x, float y) {
        return noise(x, y) * 0.55f + noise(x * 2.03f + 17f, y * 2.03f + 5f) * 0.28f + noise(x * 4.1f + 3f, y * 4.1f + 29f) * 0.17f;
    }

    private static int clamp(float v) { return v < 0f ? 0 : v > 255f ? 255 : Math.round(v); }

    /** Color base por un factor de luz (f < 1 oscurece, f > 1 aclara hacia blanco). */
    private static int tone(int base, float f) {
        int r = (base >> 16) & 255, g = (base >> 8) & 255, b = base & 255;
        if (f <= 1f) return 0xFF000000 | (clamp(r * f) << 16) | (clamp(g * f) << 8) | clamp(b * f);
        float t = Math.min(1f, f - 1f);
        return 0xFF000000 | (clamp(r + (255 - r) * t) << 16) | (clamp(g + (255 - g) * t) << 8) | clamp(b + (255 - b) * t);
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = clamp(((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = clamp(((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = clamp((a & 255) + (((b & 255) - (a & 255)) * t));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Tamano de la celda de la textura segun la obra: size 0 chica, 1 mediana, 2 grande. */
    public static float cellFor(int W, int H, int size) {
        float base = Math.max(6f, Math.max(W, H) / 110f);
        return base * (size == 0 ? 0.6f : size == 2 ? 1.8f : 1f);
    }

    /**
     * Color (opaco) de la textura kind en (x, y). base = color elegido. cell = tamano (cellFor).
     */
    public static int at(int kind, int x, int y, int base, float cell) {
        float u = x / cell, v = y / cell;
        switch (kind) {
            case 1: { // Jean: sarga en diagonal + hilos claros + desgaste
                float tw = (float) Math.sin((u + v * 0.5f) * Math.PI * 2.0 * 2.2);
                float th = noise(u * 9f, v * 0.9f);              // hilos verticales irregulares
                float wear = fbm(u * 0.35f, v * 0.35f);
                float f = 0.86f + 0.07f * tw + 0.10f * (th - 0.5f) + 0.12f * (wear - 0.5f);
                int c = tone(base, f);
                float fleck = hash(x, y);
                if (fleck > 0.985f) c = mix(c, 0xFFF4F4F4, 0.35f);       // motitas blancas del algodon
                return c;
            }
            case 2: { // Tela tejida: arriba/abajo de hilos
                float p = 3.2f;
                float sx = (float) Math.sin(u * Math.PI * p), sy = (float) Math.sin(v * Math.PI * p);
                boolean over = ((int) Math.floor(u * p) + (int) Math.floor(v * p) & 1) == 0;
                float f = 0.93f + (over ? 0.05f * Math.abs(sy) : 0.05f * Math.abs(sx)) - 0.04f * (1f - Math.abs(over ? sx : sy));
                f += 0.04f * (noise(u * 3f, v * 3f) - 0.5f);
                return tone(base, f);
            }
            case 3: { // Cuadros escoceses
                float px = u / 6f, py = v / 6f;
                float fx = px - (float) Math.floor(px), fy = py - (float) Math.floor(py);
                boolean bx = fx < 0.42f, by = fy < 0.42f;
                boolean lx = Math.abs(fx - 0.71f) < 0.035f, ly = Math.abs(fy - 0.71f) < 0.035f;
                float f = 1.06f;
                if (bx && by) f = 0.62f; else if (bx || by) f = 0.82f;
                int c = tone(base, f);
                if (lx || ly) c = mix(c, 0xFFF6F0E6, 0.55f);
                // hilos en diagonal (sarga)
                float tw = (float) Math.sin((u + v) * Math.PI * 2.5);
                return tone(c, 0.97f + 0.03f * tw);
            }
            case 4: { // Lunares blancos
                float s = 5f;
                float gx = u / s, gy = v / s;
                int row = (int) Math.floor(gy);
                if ((row & 1) == 1) gx += 0.5f;
                float fx = gx - (float) Math.floor(gx) - 0.5f, fy = gy - (float) Math.floor(gy) - 0.5f;
                float d = (float) Math.sqrt(fx * fx + fy * fy) * s;   // en celdas
                float r = 1.15f;
                float a = Math.max(0f, Math.min(1f, (r - d) * cell * 0.5f + 0.5f));   // borde suave de ~1 px
                return mix(base | 0xFF000000, 0xFFFFFFFF, a * 0.95f);
            }
            case 5: { // Trama de manga (puntitos a 45 grados del color, sobre blanco)
                float s = 1.6f;
                float ru = (u + v) * 0.7071f / s, rv = (v - u) * 0.7071f / s;
                float fx = ru - (float) Math.floor(ru) - 0.5f, fy = rv - (float) Math.floor(rv) - 0.5f;
                float d = (float) Math.sqrt(fx * fx + fy * fy) * s;
                float r = 0.48f;
                float a = Math.max(0f, Math.min(1f, (r - d) * cell * 0.6f + 0.5f));
                return mix(0xFFFFFFFF, base | 0xFF000000, a);
            }
            case 6: { // Cielo: degradado + nubes
                float sky = Math.max(0f, Math.min(1f, v / 60f));
                int top = tone(base, 0.78f), bottom = tone(base, 1.55f);
                int c = mix(top, bottom, sky);
                float cl = fbm(u * 0.12f, v * 0.22f);
                float cloud = Math.max(0f, Math.min(1f, (cl - 0.52f) * 4f));
                return mix(c, 0xFFFFFFFF, cloud * 0.85f);
            }
            case 7: { // Galaxia: noche + nebulosa del color + estrellas
                float neb = fbm(u * 0.08f + 3f, v * 0.08f);
                float neb2 = fbm(u * 0.2f, v * 0.2f + 9f);
                int night = 0xFF0B0B22;
                int c = mix(night, tone(base, 0.9f), Math.max(0f, neb - 0.38f) * 1.6f);
                c = mix(c, tone(base, 1.4f), Math.max(0f, neb2 - 0.62f) * 1.8f);
                float h = hash(x / 2, y / 2);
                if (h > 0.9965f) {
                    float tw = hash(x / 2 + 7, y / 2 + 3);
                    c = mix(c, 0xFFFFFFFF, 0.6f + 0.4f * tw);
                } else if (h > 0.990f) c = mix(c, 0xFFE8ECFF, 0.35f);
                return c;
            }
            case 8: { // Brillos: base con destellos de 4 puntas y burbujas de luz
                int c = tone(base, 0.95f + 0.1f * fbm(u * 0.15f, v * 0.15f));
                float s = 5.5f;
                int cx = (int) Math.floor(u / s), cy = (int) Math.floor(v / s);
                float best = 0f;
                for (int oy = -1; oy <= 1; oy++)
                    for (int ox = -1; ox <= 1; ox++) {
                        int gx = cx + ox, gy = cy + oy;
                        float hx = hash(gx * 3 + 1, gy * 5 + 2), hy = hash(gx * 7 + 3, gy * 11 + 4), hs = hash(gx + 9, gy + 13);
                        float sx = (gx + hx) * s, sy = (gy + hy) * s;
                        float dx = u - sx, dy = v - sy;
                        if (hs > 0.55f) {
                            // destello: cruz fina que se apaga
                            float len = 1.5f + 2.5f * hs;
                            float cross = Math.max(Math.max(0f, 1f - Math.abs(dy) * 6f) * Math.max(0f, 1f - Math.abs(dx) / len),
                                    Math.max(0f, 1f - Math.abs(dx) * 6f) * Math.max(0f, 1f - Math.abs(dy) / len));
                            float core = Math.max(0f, 1f - (dx * dx + dy * dy) * 2.5f);
                            best = Math.max(best, Math.max(cross, core));
                        } else if (hs > 0.25f) {
                            float rr = 0.8f + 1.6f * hs;
                            float d = (float) Math.sqrt(dx * dx + dy * dy);
                            best = Math.max(best, Math.max(0f, 1f - d / rr) * 0.35f);
                        }
                    }
                return mix(c, 0xFFFFFFFF, best);
            }
            default:
                return base | 0xFF000000;
        }
    }

    /**
     * Imagen propia (iw x ih) puesta sobre la obra W x H: cubre la obra (sin deformar) y se repite
     * si hace falta. size 0 = mas chica (se repite mas), 2 = mas grande.
     */
    public static int imageAt(int[] img, int iw, int ih, int x, int y, int W, int H, int size) {
        float cover = Math.max(W / (float) iw, H / (float) ih);
        float s = cover * (size == 0 ? 0.4f : size == 2 ? 1f : 0.65f);
        int sx = (int) (x / s), sy = (int) (y / s);
        sx %= iw; sy %= ih;
        if (sx < 0) sx += iw;
        if (sy < 0) sy += ih;
        return img[sy * iw + sx] | 0xFF000000;
    }

    /**
     * Gris del dibujo para oscurecer la textura: 255 = papel (la textura tal cual), menos = la
     * linea, la sombra o la trama del dibujo (se multiplica). El papel se mide (el blanco del
     * dibujo puede ser 240): asi el papel no ensucia la textura.
     */
    public static byte[] shadeMap(int[] ref, int W, int H) {
        int n = W * H;
        int[] hist = new int[256];
        int[] l = new int[n];
        for (int i = 0; i < n; i++) {
            int c = ref[i];
            int a = c >>> 24;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            if (a < 255) {
                r = (r * a + 255 * (255 - a)) / 255;
                g = (g * a + 255 * (255 - a)) / 255;
                b = (b * a + 255 * (255 - a)) / 255;
            }
            int v = (r * 77 + g * 151 + b * 28) >> 8;
            l[i] = v;
            hist[v]++;
        }
        // papel = percentil 98 (lo mas claro que hay en cantidad)
        int want = n * 98 / 100, acc = 0, paper = 255;
        for (int v = 0; v < 256; v++) { acc += hist[v]; if (acc >= want) { paper = v; break; } }
        paper = Math.max(160, paper);
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) out[i] = (byte) Math.min(255, l[i] * 255 / paper);
        return out;
    }

    /** Textura por el gris del dibujo (multiplicar). */
    public static int darken(int c, int shade) {
        if (shade >= 255) return c;
        int r = ((c >> 16) & 255) * shade / 255, g = ((c >> 8) & 255) * shade / 255, b = (c & 255) * shade / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
