package com.pacco.animecut.core;

/**
 * v8.52 Toques suaves (la tecnica de Procreate / Ibis para piel natural): manchas de color
 * que se funden. Se difumina SOLO lo que agrego el ultimo trazo (la diferencia entre antes y
 * despues), asi las manchas viejas no se vuelven cada vez mas borrosas.
 * Todo en color premultiplicado (no salen bordes oscuros) y, si el difuminado es grande,
 * se calcula en pequeno y se agranda (rapido aun con pinceles enormes).
 */
public final class SoftBlend {
    private SoftBlend() { }

    /**
     * px: capa entera (ancho W). La zona (x0, y0, rw, rh) se reemplaza por
     * original + difuminado(px - original). orig = la zona como estaba antes (null = vacia,
     * o sea difuminar todo lo que hay). sigma = cuanto se difumina, en pixeles.
     */
    public static void apply(int[] px, int W, int x0, int y0, int rw, int rh, int[] orig, float sigma) {
        if (rw <= 0 || rh <= 0) return;
        int n = rw * rh;
        int f = sigma >= 48f ? 8 : sigma >= 24f ? 4 : sigma >= 10f ? 2 : 1;   // v9.06: pinceles enormes, mas rapido
        int sw = (rw + f - 1) / f, sh = (rh + f - 1) / f;
        int rb = Math.max(1, Math.round(sigma / f));
        int[] small = new int[sw * sh];
        int[] tmp = new int[sw * sh];
        int[] out = new int[n];
        for (int ch = 0; ch < 4; ch++) {
            int shift = ch == 0 ? 24 : ch == 1 ? 16 : ch == 2 ? 8 : 0;
            java.util.Arrays.fill(small, 0);
            for (int y = 0; y < rh; y++) {
                int row = (y0 + y) * W + x0, sRow = (y / f) * sw;
                for (int x = 0; x < rw; x++) {
                    int a = px[row + x];
                    int o = orig == null ? 0 : orig[y * rw + x];
                    int d = pm(a, ch, shift) - pm(o, ch, shift);
                    if (d != 0) small[sRow + x / f] += d;
                }
            }
            if (f > 1) {
                for (int by = 0; by < sh; by++) {
                    int ch2 = Math.min(f, rh - by * f);
                    for (int bx = 0; bx < sw; bx++) {
                        int cnt = ch2 * Math.min(f, rw - bx * f);
                        int k = by * sw + bx;
                        if (small[k] != 0) small[k] = div(small[k], cnt);
                    }
                }
            }
            blur3(small, tmp, sw, sh, rb);
            for (int y = 0; y < rh; y++) {
                float fy = f == 1 ? y : (y + 0.5f) / f - 0.5f;
                int yA = (int) Math.floor(fy);
                float ty = fy - yA;
                int y1 = clamp(yA, 0, sh - 1), y2 = clamp(yA + 1, 0, sh - 1);
                for (int x = 0; x < rw; x++) {
                    int k = y * rw + x;
                    float dv;
                    if (f == 1) dv = small[y * sw + x];
                    else {
                        float fx = (x + 0.5f) / f - 0.5f;
                        int xA = (int) Math.floor(fx);
                        float tx = fx - xA;
                        int x1 = clamp(xA, 0, sw - 1), x2 = clamp(xA + 1, 0, sw - 1);
                        float top = small[y1 * sw + x1] * (1f - tx) + small[y1 * sw + x2] * tx;
                        float bot = small[y2 * sw + x1] * (1f - tx) + small[y2 * sw + x2] * tx;
                        dv = top * (1f - ty) + bot * ty;
                    }
                    int o = orig == null ? 0 : orig[k];
                    int v = pm(o, ch, shift) + Math.round(dv);
                    v = v < 0 ? 0 : v > 255 ? 255 : v;
                    out[k] |= v << shift;
                }
            }
        }
        for (int y = 0; y < rh; y++) {
            int row = (y0 + y) * W + x0;
            for (int x = 0; x < rw; x++) {
                int c = out[y * rw + x];
                int a = c >>> 24;
                if (a == 0) { px[row + x] = 0; continue; }
                int r = Math.min(255, (((c >> 16) & 0xFF) * 255 + a / 2) / a);
                int g = Math.min(255, (((c >> 8) & 0xFF) * 255 + a / 2) / a);
                int b = Math.min(255, ((c & 0xFF) * 255 + a / 2) / a);
                px[row + x] = (a << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }

    /** Canal premultiplicado (0 = alfa). */
    private static int pm(int c, int ch, int shift) {
        int a = c >>> 24;
        if (ch == 0) return a;
        if (a == 0) return 0;
        return (((c >> shift) & 0xFF) * a + 127) / 255;
    }

    private static int clamp(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

    /** Division redondeada que funciona con negativos. */
    private static int div(int s, int d) {
        return s >= 0 ? (s + d / 2) / d : -((-s + d / 2) / d);
    }

    /** Tres pasadas de caja horizontal + vertical (casi gaussiano). Afuera cuenta como 0. */
    static void blur3(int[] a, int[] t, int w, int h, int r) {
        for (int p = 0; p < 3; p++) {
            boxH(a, t, w, h, r);
            boxV(t, a, w, h, r);
        }
    }

    private static void boxH(int[] s, int[] d, int w, int h, int r) {
        int div = 2 * r + 1;
        for (int y = 0; y < h; y++) {
            int o = y * w, sum = 0;
            for (int x = 0; x <= Math.min(r, w - 1); x++) sum += s[o + x];
            for (int x = 0; x < w; x++) {
                d[o + x] = div(sum, div);
                int add = x + r + 1, rem = x - r;
                if (add < w) sum += s[o + add];
                if (rem >= 0) sum -= s[o + rem];
            }
        }
    }

    private static void boxV(int[] s, int[] d, int w, int h, int r) {
        int div = 2 * r + 1;
        for (int x = 0; x < w; x++) {
            int sum = 0;
            for (int y = 0; y <= Math.min(r, h - 1); y++) sum += s[y * w + x];
            for (int y = 0; y < h; y++) {
                d[y * w + x] = div(sum, div);
                int add = y + r + 1, rem = y - r;
                if (add < h) sum += s[add * w + x];
                if (rem >= 0) sum -= s[rem * w + x];
            }
        }
    }

    /**
     * v8.53 "Sacar lineas" (el Extraer dibujo lineal de Ibis): blanco, negro y medio en 0..100.
     * Lo mas claro que 'white' queda transparente, lo mas oscuro que 'black' queda opaco y 'mid'
     * cambia los grises del medio (50 = parejo; mas = lineas mas llenas). keepColor: las lineas
     * guardan su color; si no, quedan en negro.
     */
    public static void extractLines(int[] src, int[] dst, int white, int black, int mid, boolean keepColor) {
        float W = Math.max(white, black + 1) * 2.55f, B = Math.min(black, white - 1) * 2.55f;
        float gamma = (float) Math.pow(2.0, (50 - mid) / 25.0);
        int[] lut = new int[256];
        for (int L = 0; L < 256; L++) {
            float t = (W - L) / Math.max(1f, W - B);
            t = t < 0f ? 0f : t > 1f ? 1f : t;
            lut[L] = Math.round(255f * (float) Math.pow(t, gamma));
        }
        for (int i = 0; i < src.length; i++) {
            int c = src[i];
            int a = c >>> 24;
            if (a == 0) { dst[i] = 0; continue; }
            int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            int lum = (r * 299 + g * 587 + b * 114) / 1000;
            if (a < 255) lum = 255 - a * (255 - lum) / 255;   // lo semitransparente, como sobre papel blanco
            int na = lut[lum];
            dst[i] = na == 0 ? 0 : (na << 24) | (keepColor ? (c & 0xFFFFFF) : 0);
        }
    }

    /**
     * v8.52 "Quitar blanco" (el Blanco claro de Ibis): lo blanco se vuelve transparente.
     * keepColor=false: queda solo la linea en negro (escala de grises).
     * keepColor=true: se quita el blanco pero se guarda el color de las lineas.
     */
    public static void whiteToAlpha(int[] px, boolean keepColor) {
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int a = c >>> 24;
            if (a == 0) continue;
            int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            if (!keepColor) {
                int lum = (r * 299 + g * 587 + b * 114) / 1000;
                int na = a * (255 - lum) / 255;
                px[i] = na << 24;
                continue;
            }
            int k = Math.max(255 - r, Math.max(255 - g, 255 - b));
            if (k <= 0) { px[i] = 0; continue; }
            int nr = 255 - (255 - r) * 255 / k, ng = 255 - (255 - g) * 255 / k, nb = 255 - (255 - b) * 255 / k;
            nr = nr < 0 ? 0 : nr; ng = ng < 0 ? 0 : ng; nb = nb < 0 ? 0 : nb;
            int na = a * k / 255;
            px[i] = na == 0 ? 0 : (na << 24) | (nr << 16) | (ng << 8) | nb;
        }
    }

    /**
     * v9.07 FUNDIR SUAVE (paso 3 de Colorear; pedido de Brian con el video de Procreate: pincel
     * suave con "mezcla" y "desenfoque" y sin arrastre). Dentro de [x0,x1)x[y0,y1), donde cov > 0,
     * cada pixel pintado se acerca (k * cov) al PROMEDIO de los pixeles pintados de alrededor
     * (radio rad, dos pasadas de caja = casi gaussiano, en color premultiplicado). No arrastra el
     * color como el dedo: lo mezcla en el lugar.
     *  - La linea (lines != 0) no se cambia y no entra al promedio: los colores de dos partes
     *    separadas por la linea no se mezclan.
     *  - El alfa no cambia: no lleva color a lo que no esta pintado.
     * @return {l, t, r, b} de lo que cambio, o null
     */
    public static int[] blendStamp(int[] px, int W, int H, byte[] cov, byte[] lines,
                                   int x0, int y0, int x1, int y1, int rad, float k) {
        return blendStamp(px, W, H, cov, lines, null, x0, y0, x1, y1, rad, k);
    }

    /**
     * owner (puede ser null): de que parte es cada pixel (0 = de ninguna). Con owner, cada pixel
     * solo se mezcla con los de SU parte: la cara no se mezcla con el cuello de la camisa aunque
     * la linea entre las dos sea clara o este cortada.
     */
    public static int[] blendStamp(int[] px, int W, int H, byte[] cov, byte[] lines, short[] owner,
                                   int x0, int y0, int x1, int y1, int rad, float k) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(W, x1); y1 = Math.min(H, y1);
        if (x0 >= x1 || y0 >= y1 || rad < 1) return null;
        // partes que toca el pincel
        int[] ids = new int[8];
        int nid = 0;
        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++) {
                int i = y * W + x;
                if (cov[i] == 0) continue;
                int id = owner != null ? owner[i] : 0;
                boolean seen = false;
                for (int q = 0; q < nid; q++) if (ids[q] == id) { seen = true; break; }
                if (seen) continue;
                if (nid == ids.length) ids = java.util.Arrays.copyOf(ids, nid * 2);
                ids[nid++] = id;
            }
        int[] box = {W, H, -1, -1};
        for (int q = 0; q < nid; q++) blendGroup(px, W, H, cov, lines, owner, ids[q], x0, y0, x1, y1, rad, k, box);
        return box[2] < box[0] ? null : new int[]{box[0], box[1], box[2] + 1, box[3] + 1};
    }

    private static void blendGroup(int[] px, int W, int H, byte[] cov, byte[] lines, short[] owner, int id,
                                   int x0, int y0, int x1, int y1, int rad, float k, int[] box) {
        int wx0 = Math.max(0, x0 - rad), wy0 = Math.max(0, y0 - rad);
        int wx1 = Math.min(W, x1 + rad), wy1 = Math.min(H, y1 + rad);
        int ww = wx1 - wx0, wh = wy1 - wy0, n = ww * wh;
        float[] R = new float[n], G = new float[n], B = new float[n], A = new float[n];
        boolean any = false;
        for (int y = 0; y < wh; y++)
            for (int x = 0; x < ww; x++) {
                int i = (y + wy0) * W + x + wx0;
                if (lines != null && lines[i] != 0) continue;
                if (owner != null && owner[i] != id) continue;
                int c = px[i];
                float a = (c >>> 24) / 255f;
                if (a <= 0f) continue;
                int j = y * ww + x;
                R[j] = ((c >> 16) & 255) * a; G[j] = ((c >> 8) & 255) * a; B[j] = (c & 255) * a; A[j] = a;
                any = true;
            }
        if (!any) return;
        float[] tmp = new float[Math.max(ww, wh)];
        int r1 = Math.max(1, rad / 2);
        for (int pass = 0; pass < 2; pass++) {
            box(R, ww, wh, r1, tmp); box(G, ww, wh, r1, tmp); box(B, ww, wh, r1, tmp); box(A, ww, wh, r1, tmp);
        }
        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++) {
                int i = y * W + x;
                int cv = cov[i] & 0xFF;
                if (cv == 0) continue;
                if (lines != null && lines[i] != 0) continue;
                if (owner != null && owner[i] != id) continue;
                int c = px[i];
                int a = c >>> 24;
                if (a == 0) continue;
                int j = (y - wy0) * ww + x - wx0;
                float wa = A[j];
                if (wa <= 1e-3f) continue;
                float mr = R[j] / wa, mg = G[j] / wa, mb = B[j] / wa;
                float f = k * cv / 255f;
                int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
                int nr = Math.round(cr + (mr - cr) * f), ng = Math.round(cg + (mg - cg) * f), nb = Math.round(cb + (mb - cb) * f);
                nr = Math.max(0, Math.min(255, nr)); ng = Math.max(0, Math.min(255, ng)); nb = Math.max(0, Math.min(255, nb));
                int nc = (a << 24) | (nr << 16) | (ng << 8) | nb;
                if (nc == c) continue;
                px[i] = nc;
                if (x < box[0]) box[0] = x; if (x > box[2]) box[2] = x; if (y < box[1]) box[1] = y; if (y > box[3]) box[3] = y;
            }
    }

    /** Caja (promedio) de radio r en x y despues en y, bordes repetidos. */
    private static void box(float[] a, int w, int h, int r, float[] tmp) {
        float inv = 1f / (2 * r + 1);
        for (int y = 0; y < h; y++) {
            int o = y * w;
            float acc = 0f;
            for (int k = -r; k <= r; k++) acc += a[o + Math.max(0, Math.min(w - 1, k))];
            for (int x = 0; x < w; x++) {
                tmp[x] = acc * inv;
                acc += a[o + Math.min(w - 1, x + r + 1)] - a[o + Math.max(0, x - r)];
            }
            System.arraycopy(tmp, 0, a, o, w);
        }
        for (int x = 0; x < w; x++) {
            float acc = 0f;
            for (int k = -r; k <= r; k++) acc += a[Math.max(0, Math.min(h - 1, k)) * w + x];
            for (int y = 0; y < h; y++) {
                tmp[y] = acc * inv;
                acc += a[Math.min(h - 1, y + r + 1) * w + x] - a[Math.max(0, y - r) * w + x];
            }
            for (int y = 0; y < h; y++) a[y * w + x] = tmp[y];
        }
    }

    /**
     * v9.07 "Negro a transparente" (video de las burbujas): lo negro se vuelve transparente y lo
     * claro queda con su color y su brillo, a medias donde es medio oscuro (como la mezcla
     * Pantalla). Sirve para burbujas, fuego, humo, luces y chispas sobre fondo negro: quedan
     * transparentes de verdad, sin invertir colores. Es la cuenta inversa de "Pantalla":
     * puesto encima de cualquier fondo en modo Normal se ve igual que el original en Pantalla.
     */
    public static void blackToAlpha(int[] px) {
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int a = c >>> 24;
            if (a == 0) continue;
            int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            int k = Math.max(r, Math.max(g, b));
            if (k <= 0) { px[i] = 0; continue; }
            int nr = Math.min(255, r * 255 / k), ng = Math.min(255, g * 255 / k), nb = Math.min(255, b * 255 / k);
            int na = a * k / 255;
            px[i] = na == 0 ? 0 : (na << 24) | (nr << 16) | (ng << 8) | nb;
        }
    }
}
