package com.pacco.animecut;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * v9.06 Mini tutorial animado (mantener presionado una herramienta de Colorear o de Toques).
 * Dos partes con linea negra: la "cara" (circulo) y el "pelo" (ovalo a la derecha). Un dedo
 * muestra que hacer y la escena enseña el resultado. Se repite cada 2.6 s.
 */
public class ToolTutoView extends View {
    public static final int BUCKET = 0, BRUSH = 1, LOOP = 2, ERASE = 3, PICK = 4, TEX = 5;
    public static final int SOFT_COLOR = 10, SOFT_SHADOW = 11, SOFT_LIGHT = 12, SOFT_ERASE = 13, SOFT_BLEND = 14, SOFT_CLEAR = 15;
    private static final long PERIOD = 2600L;

    private final int kind;
    private final long t0 = System.currentTimeMillis();

    public ToolTutoView(Context c, int kind) {
        super(c);
        this.kind = kind;
    }

    /** Herramienta de Colorear (en el orden de la fila) a su animacion. */
    public static int ofTool(int t) { return t; }

    @Override
    protected void onDraw(Canvas c) {
        float t = ((System.currentTimeMillis() - t0) % PERIOD) / (float) PERIOD;
        drawScene(c, kind, getWidth(), getHeight(), t, getResources().getDisplayMetrics().density);
        postInvalidateOnAnimation();
    }

    private static final int SKIN = 0xFFFFD9C2, HAIR = 0xFF4A4E7A, PINK = 0xFFFF8FA3, INK = 0xFF1B1B22;

    private static float ease(float a, float b, float t) {
        float u = Math.max(0f, Math.min(1f, (t - a) / (b - a)));
        return u * u * (3f - 2f * u);
    }

    /** Se dibuja aqui (sin View) para poder probarla en la PC. t = 0..1 del ciclo. */
    public static void drawScene(Canvas c, int kind, float w, float h, float t, float dp) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF4F4F6);
        c.drawRoundRect(new RectF(0, 0, w, h), 12 * dp, 12 * dp, p);
        float ax = w * 0.38f, ay = h * 0.55f, ar = h * 0.28f;          // cara
        RectF hb = new RectF(w * 0.60f, h * 0.18f, w * 0.90f, h * 0.84f); // pelo
        Path face = new Path();
        face.addCircle(ax, ay, ar, Path.Direction.CW);
        Path hair = new Path();
        hair.addOval(hb, Path.Direction.CW);
        float hx = (hb.left + hb.right) / 2f, hy = (hb.top + hb.bottom) / 2f;

        float fx = -1, fy = -1;        // dedo
        boolean press = false;
        switch (kind) {
            case BUCKET: {
                float g = ease(0.25f, 0.6f, t);
                if (g > 0) {
                    c.save();
                    c.clipPath(face);
                    p.setColor(SKIN);
                    c.drawCircle(ax, ay, ar * 1.05f * g, p);
                    c.restore();
                }
                fx = ax; fy = ay; press = t > 0.15f && t < 0.35f;
                break;
            }
            case BRUSH: case ERASE: {
                boolean erase = kind == ERASE;
                if (erase) fill(c, face, hair, SKIN, SKIN, p);   // el color se paso al pelo
                float g = ease(0.15f, 0.75f, t);
                float sx = hx + hb.width() * 0.1f, sy = hy - hb.height() * 0.05f;     // empieza en el pelo (borrar)
                float ex = ax - ar * 0.4f, ey = ay + ar * 0.1f;                         // y cruza a la cara
                if (!erase) { float k = sx; sx = ex; ex = k; k = sy; sy = ey; ey = k; }
                float cx = sx + (ex - sx) * g, cy = sy + (ey - sy) * g;
                Path stroke = new Path();
                stroke.moveTo(sx, sy);
                stroke.lineTo(cx, cy);
                Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
                sp.setStyle(Paint.Style.STROKE);
                sp.setStrokeCap(Paint.Cap.ROUND);
                sp.setStrokeWidth(h * 0.22f);
                if (g > 0) {
                    c.save();
                    c.clipPath(erase ? hair : face);          // Protegido: se queda donde empezo
                    sp.setColor(erase ? 0xFFF4F4F6 : PINK);
                    c.drawPath(stroke, sp);
                    c.restore();
                }
                fx = cx; fy = cy; press = t > 0.1f && t < 0.8f;
                break;
            }
            case LOOP: {
                float g = ease(0.1f, 0.6f, t);
                RectF lr = new RectF(hb.left - 10 * dp, hb.top - 8 * dp, hb.right + 10 * dp, hb.bottom + 8 * dp);
                float lx = (lr.left + lr.right) / 2f, ly = (lr.top + lr.bottom) / 2f, rx = lr.width() / 2f, ry = lr.height() / 2f;
                int n = (int) (40 * g);
                p.setColor(0xFF2E7DFF);
                float px = lx, py = ly;
                for (int i = 0; i <= n; i++) {
                    double a = -Math.PI / 2 + i / 40.0 * Math.PI * 2;
                    px = lx + (float) Math.cos(a) * rx;
                    py = ly + (float) Math.sin(a) * ry;
                    if (i % 2 == 0) c.drawCircle(px, py, 2.2f * dp, p);
                }
                float f = ease(0.62f, 0.8f, t);
                if (f > 0) {
                    c.save();
                    c.clipPath(hair);
                    p.setColor((HAIR & 0xFFFFFF) | ((int) (255 * f) << 24));
                    c.drawRect(hb, p);
                    c.restore();
                }
                if (g < 1f) { fx = px; fy = py; press = t > 0.08f; }
                break;
            }
            case TEX: {
                // v9.07 Imagen: el dedo pasa por el "pelo" y aparece una tela de cuadros, sin salirse
                float g = ease(0.12f, 0.75f, t);
                float sx = hb.left + hb.width() * 0.2f, sy = hb.top + hb.height() * 0.15f;
                float ex = hb.right - hb.width() * 0.2f, ey = hb.bottom - hb.height() * 0.15f;
                float cx = sx + (ex - sx) * g, cy = sy + (ey - sy) * g;
                if (g > 0) {
                    Path stroke = new Path();
                    stroke.moveTo(sx, sy);
                    stroke.lineTo(cx, cy);
                    c.save();
                    c.clipPath(hair);
                    Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
                    sp.setStyle(Paint.Style.STROKE);
                    sp.setStrokeCap(Paint.Cap.ROUND);
                    sp.setStrokeWidth(hb.width() * 0.9f);
                    sp.setColor(0xFF3A5A8C);
                    c.drawPath(stroke, sp);
                    // cuadros claros encima de lo pintado
                    Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
                    q.setColor(0x66FFFFFF);
                    float step = hb.width() / 4f;
                    c.clipPath(strokeArea(stroke, hb.width() * 0.9f));
                    for (float xx = hb.left; xx < hb.right; xx += step) c.drawRect(xx, hb.top, xx + step * 0.18f, hb.bottom, q);
                    for (float yy = hb.top; yy < hb.bottom; yy += step) c.drawRect(hb.left, yy, hb.right, yy + step * 0.18f, q);
                    c.restore();
                }
                fx = cx; fy = cy; press = t > 0.1f && t < 0.8f;
                break;
            }
            case PICK: {
                fill(c, face, hair, PINK, 0, p);
                fx = ax; fy = ay; press = t > 0.2f && t < 0.4f;
                float g = ease(0.35f, 0.5f, t);
                p.setColor(0xFFFFFFFF);
                c.drawCircle(w * 0.86f, h * 0.86f, h * 0.10f, p);
                p.setColor(g > 0.5f ? PINK : 0xFFBDBDC4);
                c.drawCircle(w * 0.86f, h * 0.86f, h * 0.08f, p);
                break;
            }
            case SOFT_COLOR: case SOFT_SHADOW: case SOFT_LIGHT: case SOFT_ERASE: case SOFT_BLEND: case SOFT_CLEAR: {
                fill(c, face, hair, SKIN, HAIR, p);
                c.save();
                c.clipPath(face);
                float g = ease(0.2f, 0.7f, t);
                if (kind == SOFT_COLOR) soft(c, ax - ar * 0.45f, ay + ar * 0.2f, ar * 0.45f, 0xFFFF5A6E, 0.75f * g);
                else if (kind == SOFT_SHADOW) soft(c, ax + ar * 0.6f, ay + ar * 0.5f, ar * 0.9f, 0xFF7C6FA8, 0.6f * g);
                else if (kind == SOFT_LIGHT) soft(c, ax - ar * 0.35f, ay - ar * 0.45f, ar * 0.7f, 0xFFFFFFFF, 0.9f * g);
                else if (kind == SOFT_ERASE) soft(c, ax - ar * 0.45f, ay + ar * 0.2f, ar * 0.45f, 0xFFFF5A6E, 0.75f * (1f - g));
                else if (kind == SOFT_CLEAR) {
                    soft(c, ax - ar * 0.45f, ay + ar * 0.2f, ar * 0.45f, 0xFFFF5A6E, 0.75f * (1f - ease(0.3f, 0.45f, t)));
                    soft(c, ax + ar * 0.3f, ay - ar * 0.4f, ar * 0.4f, 0xFFFFE07A, 0.75f * (1f - ease(0.3f, 0.45f, t)));
                } else {
                    // Fundir: manchas duras que se vuelven suaves
                    p.setColor(0x00FF5A6E | ((int) (190 * (1f - g)) << 24));
                    c.drawCircle(ax - ar * 0.3f, ay + ar * 0.2f, ar * 0.35f, p);
                    p.setColor(0x00FFE07A | ((int) (190 * (1f - g)) << 24));
                    c.drawCircle(ax + ar * 0.25f, ay - ar * 0.3f, ar * 0.3f, p);
                    soft(c, ax - ar * 0.3f, ay + ar * 0.2f, ar * 0.6f, 0xFFFF5A6E, 0.7f * g);
                    soft(c, ax + ar * 0.25f, ay - ar * 0.3f, ar * 0.55f, 0xFFFFE07A, 0.7f * g);
                }
                c.restore();
                if (kind == SOFT_ERASE) { fx = ax - ar * 0.45f + (float) Math.sin(t * 18) * ar * 0.2f; fy = ay + ar * 0.2f; press = t > 0.2f && t < 0.7f; }
                else if (kind == SOFT_COLOR) { fx = ax - ar * 0.45f + (float) Math.sin(t * 14) * ar * 0.15f; fy = ay + ar * 0.2f; press = t > 0.15f && t < 0.6f; }
                else if (kind == SOFT_SHADOW) { fx = ax + ar * 0.5f; fy = ay + ar * 0.5f - (float) Math.sin(t * 12) * ar * 0.2f; press = t > 0.15f && t < 0.6f; }
                else if (kind == SOFT_LIGHT) { fx = ax - ar * 0.35f + (float) Math.sin(t * 14) * ar * 0.15f; fy = ay - ar * 0.45f; press = t > 0.15f && t < 0.6f; }
                break;
            }
        }
        // lineas negras encima (siempre se ven)
        Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG);
        lp.setStyle(Paint.Style.STROKE);
        lp.setStrokeWidth(3f * dp);
        lp.setColor(INK);
        c.drawPath(face, lp);
        c.drawPath(hair, lp);
        if (fx >= 0) finger(c, fx, fy, press, dp);
    }

    /** Contorno del trazo (para recortar los cuadros a lo pintado). */
    private static Path strokeArea(Path stroke, float width) {
        Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        sp.setStyle(Paint.Style.STROKE);
        sp.setStrokeCap(Paint.Cap.ROUND);
        sp.setStrokeWidth(width);
        Path out = new Path();
        sp.getFillPath(stroke, out);
        return out;
    }

    private static void fill(Canvas c, Path face, Path hair, int fc, int hc, Paint p) {
        if (fc != 0) { c.save(); c.clipPath(face); p.setColor(fc); c.drawRect(new RectF(-9999, -9999, 9999, 9999), p); c.restore(); }
        if (hc != 0) { c.save(); c.clipPath(hair); p.setColor(hc); c.drawRect(new RectF(-9999, -9999, 9999, 9999), p); c.restore(); }
    }

    private static void soft(Canvas c, float x, float y, float r, int col, float a) {
        if (a <= 0.01f || r <= 1f) return;
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        int al = Math.max(0, Math.min(255, (int) (255 * a)));
        g.setShader(new RadialGradient(x, y, r, (col & 0xFFFFFF) | (al << 24), col & 0xFFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, g);
    }

    private static void finger(Canvas c, float x, float y, boolean press, float dp) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(press ? 0x882E7DFF : 0x55FFFFFF);
        c.drawCircle(x, y, (press ? 11 : 13) * dp, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * dp);
        p.setColor(0xFF2E7DFF);
        c.drawCircle(x, y, (press ? 11 : 13) * dp, p);
    }
}
