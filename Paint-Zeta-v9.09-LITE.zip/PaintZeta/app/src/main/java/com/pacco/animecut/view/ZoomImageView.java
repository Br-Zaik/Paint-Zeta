package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * v9.08 Visor con zoom (como la galeria): dos dedos acercan y alejan, un dedo mueve, doble toque
 * = 100 % (pixel por pixel) y otra vez = entera. Se usa en "Ver como queda" de Guardar imagen.
 * La imagen nunca se pierde de vista: siempre queda centrada o pegada a los bordes.
 */
public class ZoomImageView extends View {

    private Bitmap bmp;
    private final Matrix m = new Matrix();
    private final float[] v = new float[9];
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final ScaleGestureDetector scaler;
    private final GestureDetector taps;
    private float fit = 1f;
    private boolean placed;

    public ZoomImageView(Context c) {
        super(c);
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                zoomBy(d.getScaleFactor(), d.getFocusX(), d.getFocusY());
                return true;
            }
        });
        taps = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }

            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                m.postTranslate(-dx, -dy);
                keepInside();
                invalidate();
                return true;
            }

            @Override public boolean onDoubleTap(MotionEvent e) {
                float s = scale();
                // entera <-> acercada (100 % si la imagen es grande; si no, el doble)
                float target = s > fit * 1.05f ? fit : doubleTapTarget(fit);
                zoomBy(target / s, e.getX(), e.getY());
                return true;
            }
        });
    }

    public void setBitmap(Bitmap b) {
        bmp = b;
        placed = false;
        requestLayout();
        invalidate();
    }

    /** Escala actual (1 = 100 %, un pixel de la imagen por pixel de la pantalla). */
    public float scale() {
        m.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    public float fitScale() { return fit; }

    private void place() {
        if (bmp == null || getWidth() == 0 || getHeight() == 0) return;
        fit = Math.min(getWidth() / (float) bmp.getWidth(), getHeight() / (float) bmp.getHeight());
        m.reset();
        m.postScale(fit, fit);
        m.postTranslate((getWidth() - bmp.getWidth() * fit) / 2f, (getHeight() - bmp.getHeight() * fit) / 2f);
        placed = true;
    }

    private void zoomBy(float k, float fx, float fy) {
        if (bmp == null) return;
        float s = scale();
        float min = fit, max = Math.max(fit * 8f, 4f);
        float ns = Math.max(min, Math.min(max, s * k));
        k = ns / s;
        m.postScale(k, k, fx, fy);
        keepInside();
        invalidate();
    }

    /** Si la imagen es mas chica que la vista va centrada; si es mas grande, sin huecos a los lados. */
    private void keepInside() {
        if (bmp == null) return;
        m.getValues(v);
        float s = v[Matrix.MSCALE_X];
        float w = bmp.getWidth() * s, h = bmp.getHeight() * s;
        float tx = v[Matrix.MTRANS_X], ty = v[Matrix.MTRANS_Y];
        float nx = clampAxis(tx, w, getWidth()), ny = clampAxis(ty, h, getHeight());
        if (nx != tx || ny != ty) m.postTranslate(nx - tx, ny - ty);
    }

    /** A cuanto acerca el doble toque desde la vista entera. */
    static float doubleTapTarget(float fit) { return fit < 0.5f ? 1f : fit * 2f; }

    /** Posicion corregida de un lado (para las pruebas sin pantalla). */
    static float clampAxis(float t, float size, float view) {
        if (size <= view) return (view - size) / 2f;
        return Math.max(view - size, Math.min(0f, t));
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        place();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        scaler.onTouchEvent(e);
        if (!scaler.isInProgress()) taps.onTouchEvent(e);
        return true;
    }

    @Override protected void onDraw(Canvas c) {
        if (bmp == null || bmp.isRecycled()) return;
        if (!placed) place();
        // al 100 % o mas, pixeles nitidos (para ver si quedo borrosa); alejado, suave
        paint.setFilterBitmap(scale() < 0.999f);
        c.drawBitmap(bmp, m, paint);
    }
}
