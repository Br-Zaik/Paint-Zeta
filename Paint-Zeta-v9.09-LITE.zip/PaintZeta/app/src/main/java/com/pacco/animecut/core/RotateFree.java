package com.pacco.animecut.core;

/**
 * v9.07 GIRAR A CUALQUIER ANGULO (Recortar; idea del video de Ibis Paint: "Angulo 14 grados").
 * Java puro: se prueba en la PC.
 *
 * La obra entera gira alrededor de su centro y el lienzo CRECE lo justo para que nada se corte
 * (las esquinas quedan transparentes). Despues se recorta con el cuadro de siempre.
 * Color: mezcla de los 4 vecinos en color premultiplicado (sin bordes negros ni dientes).
 * Mascaras (seleccion, zonas de Colorear): el vecino mas cercano.
 */
public final class RotateFree {
    private RotateFree() { }

    /** Medida del lienzo girado: {nw, nh}. deg positivo = en el sentido del reloj. */
    public static int[] size(int w, int h, double deg) {
        double a = Math.toRadians(deg), c = Math.abs(Math.cos(a)), s = Math.abs(Math.sin(a));
        int nw = (int) Math.ceil(w * c + h * s - 1e-6), nh = (int) Math.ceil(w * s + h * c - 1e-6);
        return new int[]{Math.max(1, nw), Math.max(1, nh)};
    }

    /** Pixeles ARGB (sin premultiplicar) girados a nw x nh. */
    public static int[] pixels(int[] src, int w, int h, double deg, int nw, int nh) {
        int[] out = new int[nw * nh];
        double a = Math.toRadians(deg), cs = Math.cos(a), sn = Math.sin(a);
        double c0x = w / 2.0, c0y = h / 2.0, c1x = nw / 2.0, c1y = nh / 2.0;
        for (int y = 0; y < nh; y++) {
            double dy = y + 0.5 - c1y;
            for (int x = 0; x < nw; x++) {
                double dx = x + 0.5 - c1x;
                double sx = c0x + dx * cs + dy * sn - 0.5, sy = c0y - dx * sn + dy * cs - 0.5;
                if (sx <= -1 || sy <= -1 || sx >= w || sy >= h) continue;
                int x0 = (int) Math.floor(sx), y0 = (int) Math.floor(sy);
                float fx = (float) (sx - x0), fy = (float) (sy - y0);
                float A = 0, R = 0, G = 0, B = 0;
                for (int k = 0; k < 4; k++) {
                    int xx = x0 + (k & 1), yy = y0 + (k >> 1);
                    float wgt = ((k & 1) == 1 ? fx : 1f - fx) * ((k >> 1) == 1 ? fy : 1f - fy);
                    if (wgt <= 0f || xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                    int c = src[yy * w + xx];
                    float al = (c >>> 24) / 255f * wgt;
                    if (al <= 0f) continue;
                    A += al;
                    R += ((c >> 16) & 255) * al; G += ((c >> 8) & 255) * al; B += (c & 255) * al;
                }
                if (A <= 0.002f) continue;
                int ia = Math.min(255, Math.round(A * 255f));
                int r = Math.min(255, Math.round(R / A)), g = Math.min(255, Math.round(G / A)), b = Math.min(255, Math.round(B / A));
                out[y * nw + x] = (ia << 24) | (r << 16) | (g << 8) | b;
            }
        }
        return out;
    }

    /** Mascara (w x h) girada a nw x nh (vecino mas cercano). null -> null. */
    public static byte[] mask(byte[] m, int w, int h, double deg, int nw, int nh) {
        if (m == null) return null;
        byte[] out = new byte[nw * nh];
        double a = Math.toRadians(deg), cs = Math.cos(a), sn = Math.sin(a);
        double c0x = w / 2.0, c0y = h / 2.0, c1x = nw / 2.0, c1y = nh / 2.0;
        for (int y = 0; y < nh; y++) {
            double dy = y + 0.5 - c1y;
            for (int x = 0; x < nw; x++) {
                double dx = x + 0.5 - c1x;
                int sx = (int) Math.floor(c0x + dx * cs + dy * sn), sy = (int) Math.floor(c0y - dx * sn + dy * cs);
                if (sx < 0 || sy < 0 || sx >= w || sy >= h) continue;
                out[y * nw + x] = m[sy * w + sx];
            }
        }
        return out;
    }

    /**
     * Zona de Colorear (recuadro zx,zy,zw,zh dentro de la obra w x h) girada: devuelve
     * {x, y, w, h} nuevos en la obra girada y su mascara en mOut[0], o null si quedo vacia.
     */
    public static int[] zone(byte[] zm, int zx, int zy, int zw, int zh, int w, int h, double deg, int nw, int nh, byte[][] mOut) {
        double a = Math.toRadians(deg), cs = Math.cos(a), sn = Math.sin(a);
        double c0x = w / 2.0, c0y = h / 2.0, c1x = nw / 2.0, c1y = nh / 2.0;
        // esquinas del recuadro, adelante (de la obra vieja a la nueva)
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int k = 0; k < 4; k++) {
            double px = (k & 1) == 0 ? zx : zx + zw, py = (k >> 1) == 0 ? zy : zy + zh;
            double dx = px - c0x, dy = py - c0y;
            double qx = c1x + dx * cs - dy * sn, qy = c1y + dx * sn + dy * cs;
            minX = Math.min(minX, qx); maxX = Math.max(maxX, qx); minY = Math.min(minY, qy); maxY = Math.max(maxY, qy);
        }
        int x0 = Math.max(0, (int) Math.floor(minX)), y0 = Math.max(0, (int) Math.floor(minY));
        int x1 = Math.min(nw, (int) Math.ceil(maxX)), y1 = Math.min(nh, (int) Math.ceil(maxY));
        if (x1 <= x0 || y1 <= y0) return null;
        int rw = x1 - x0, rh = y1 - y0;
        byte[] m = new byte[rw * rh];
        boolean any = false;
        for (int y = 0; y < rh; y++) {
            double dy = y0 + y + 0.5 - c1y;
            for (int x = 0; x < rw; x++) {
                double dx = x0 + x + 0.5 - c1x;
                int sx = (int) Math.floor(c0x + dx * cs + dy * sn) - zx, sy = (int) Math.floor(c0y - dx * sn + dy * cs) - zy;
                if (sx < 0 || sy < 0 || sx >= zw || sy >= zh) continue;
                byte v = zm[sy * zw + sx];
                if (v != 0) { m[y * rw + x] = v; any = true; }
            }
        }
        if (!any) return null;
        mOut[0] = m;
        return new int[]{x0, y0, rw, rh};
    }
}
