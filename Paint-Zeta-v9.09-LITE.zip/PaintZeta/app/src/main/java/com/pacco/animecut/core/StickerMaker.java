package com.pacco.animecut.core;

/**
 * v9.08 Sticker para WhatsApp: toma el dibujo ya recortado (con fondo transparente), lo centra en
 * un cuadro de 512 x 512 con aire alrededor, le pone el borde blanco de los stickers y una sombra
 * suave. Todo en Java puro (sin Android) para poder probarlo aparte.
 *
 * Pixeles ARGB SIN premultiplicar (como las capas de la app).
 */
public final class StickerMaker {

    private StickerMaker() { }

    /** Lado del sticker de WhatsApp. */
    public static final int SIZE = 512;
    /** Aire minimo a cada lado (WhatsApp recomienda unos 16 px). */
    public static final int MARGIN = 16;
    /** Grosor del borde blanco: sin borde, fino y grueso (en el sticker de 512). */
    public static final int[] BORDERS = {0, 7, 13};
    public static final String[] BORDER_NAMES = {"Sin borde", "Fino", "Grueso"};

    /** Caja {izq, arriba, der, abajo} (der/abajo exclusivos) de lo que no es transparente. null = vacio. */
    public static int[] bounds(int[] px, int w, int h, int alphaMin) {
        int l = w, t = h, r = -1, b = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if ((px[row + x] >>> 24) < alphaMin) continue;
                if (x < l) l = x;
                if (x > r) r = x;
                if (y < t) t = y;
                b = y;
            }
        }
        return r < 0 ? null : new int[]{l, t, r + 1, b + 1};
    }

    /** true si hay fondo transparente de verdad (al menos un 3 % de la imagen). */
    public static boolean hasCutout(int[] px) {
        int step = Math.max(1, px.length / 50000), n = 0, clear = 0;
        for (int i = 0; i < px.length; i += step) {
            n++;
            if ((px[i] >>> 24) < 16) clear++;
        }
        return n > 0 && clear * 100 >= n * 3;
    }

    /**
     * Arma el sticker. border = px de borde blanco (0 = sin borde). shadow = sombra suave abajo.
     * Si la imagen no tiene fondo transparente se usa entera (queda como una foto con borde).
     */
    public static int[] make(int[] px, int w, int h, int border, boolean shadow) {
        int[] bb = bounds(px, w, h, 12);
        if (bb == null) return new int[SIZE * SIZE];
        int cw = bb[2] - bb[0], ch = bb[3] - bb[1];
        int shadowPad = shadow ? 16 : 0;          // la sombra borrosa tambien queda dentro del aire
        int inner = SIZE - 2 * MARGIN - 2 * border - shadowPad;
        float k = Math.min(inner / (float) cw, inner / (float) ch);
        int nw = Math.max(1, Math.round(cw * k)), nh = Math.max(1, Math.round(ch * k));
        // 1) el dibujo achicado (o agrandado) en premultiplicado, en el medio del cuadro
        float[] pr = new float[SIZE * SIZE], pg = new float[SIZE * SIZE], pb = new float[SIZE * SIZE], pa = new float[SIZE * SIZE];
        int ox = (SIZE - nw) / 2, oy = (SIZE - nh) / 2 - (shadow ? 4 : 0);
        resample(px, w, bb[0], bb[1], cw, ch, nw, nh, ox, oy, pr, pg, pb, pa);
        // 2) borde blanco: todo lo que esta a menos de "border" px del dibujo
        float[] out = new float[SIZE * SIZE];
        if (border > 0) {
            float[] dist = distanceToShape(pa, SIZE, SIZE, 0.5f);
            for (int i = 0; i < out.length; i++) {
                float d = dist[i];
                out[i] = Math.max(0f, Math.min(1f, border + 0.5f - d));
            }
        } else {
            System.arraycopy(pa, 0, out, 0, out.length);
        }
        // 3) sombra: el contorno borroso, un poco mas abajo
        float[] sh = null;
        if (shadow) {
            sh = new float[SIZE * SIZE];
            int dy = 4;
            for (int y = 0; y < SIZE; y++)
                for (int x = 0; x < SIZE; x++) {
                    int sy = y - dy;
                    if (sy >= 0) sh[y * SIZE + x] = out[sy * SIZE + x];
                }
            boxBlur(sh, SIZE, SIZE, 4);
            boxBlur(sh, SIZE, SIZE, 4);
        }
        // 4) juntar: sombra (negra 35 %), borde blanco y el dibujo encima
        int[] res = new int[SIZE * SIZE];
        for (int i = 0; i < res.length; i++) {
            float a = 0f, r = 0f, g = 0f, b = 0f;           // premultiplicado
            if (sh != null) a = sh[i] * 0.35f;              // negro: r g b = 0
            if (border > 0) {
                float wa = out[i];
                r = wa + r * (1f - wa); g = wa + g * (1f - wa); b = wa + b * (1f - wa);
                a = wa + a * (1f - wa);
            }
            float da = pa[i];
            r = pr[i] + r * (1f - da); g = pg[i] + g * (1f - da); b = pb[i] + b * (1f - da);
            a = da + a * (1f - da);
            if (a <= 0.002f) continue;
            int ia = Math.min(255, Math.round(a * 255f));
            int ir = clamp255(Math.round(r / a * 255f)), ig = clamp255(Math.round(g / a * 255f)), ib = clamp255(Math.round(b / a * 255f));
            res[i] = (ia << 24) | (ir << 16) | (ig << 8) | ib;
        }
        return res;
    }

    private static int clamp255(int v) { return v < 0 ? 0 : Math.min(255, v); }

    /**
     * Cambia de tamano la parte (sx, sy, cw, ch) a nw x nh y la pone en (ox, oy). Para achicar
     * promedia todos los pixeles que caen en cada uno (sin escalones ni puntitos); para agrandar,
     * bilineal. Todo en premultiplicado (sin bordes oscuros).
     */
    static void resample(int[] px, int w, int sx, int sy, int cw, int ch, int nw, int nh, int ox, int oy,
                         float[] pr, float[] pg, float[] pb, float[] pa) {
        float fx = cw / (float) nw, fy = ch / (float) nh;
        boolean down = fx > 1f || fy > 1f;
        for (int y = 0; y < nh; y++) {
            int dy = oy + y;
            if (dy < 0 || dy >= SIZE) continue;
            for (int x = 0; x < nw; x++) {
                int dx = ox + x;
                if (dx < 0 || dx >= SIZE) continue;
                float r = 0, g = 0, b = 0, a = 0, wsum = 0;
                if (down) {
                    float x0 = x * fx, x1 = (x + 1) * fx, y0 = y * fy, y1 = (y + 1) * fy;
                    for (int yy = (int) y0; yy < Math.min(ch, (int) Math.ceil(y1)); yy++) {
                        float wy = Math.min(y1, yy + 1) - Math.max(y0, yy);
                        if (wy <= 0) continue;
                        for (int xx = (int) x0; xx < Math.min(cw, (int) Math.ceil(x1)); xx++) {
                            float wx = Math.min(x1, xx + 1) - Math.max(x0, xx);
                            if (wx <= 0) continue;
                            float ww = wx * wy;
                            int c = px[(sy + yy) * w + sx + xx];
                            float ca = (c >>> 24) / 255f;
                            r += ((c >> 16) & 255) / 255f * ca * ww;
                            g += ((c >> 8) & 255) / 255f * ca * ww;
                            b += (c & 255) / 255f * ca * ww;
                            a += ca * ww;
                            wsum += ww;
                        }
                    }
                } else {
                    float u = (x + 0.5f) * fx - 0.5f, v = (y + 0.5f) * fy - 0.5f;
                    int u0 = (int) Math.floor(u), v0 = (int) Math.floor(v);
                    float du = u - u0, dv = v - v0;
                    for (int j = 0; j < 2; j++)
                        for (int i2 = 0; i2 < 2; i2++) {
                            int xx = Math.max(0, Math.min(cw - 1, u0 + i2)), yy = Math.max(0, Math.min(ch - 1, v0 + j));
                            float ww = (i2 == 0 ? 1 - du : du) * (j == 0 ? 1 - dv : dv);
                            int c = px[(sy + yy) * w + sx + xx];
                            float ca = (c >>> 24) / 255f;
                            r += ((c >> 16) & 255) / 255f * ca * ww;
                            g += ((c >> 8) & 255) / 255f * ca * ww;
                            b += (c & 255) / 255f * ca * ww;
                            a += ca * ww;
                            wsum += ww;
                        }
                }
                if (wsum <= 0) continue;
                int o = dy * SIZE + dx;
                pr[o] = r / wsum; pg[o] = g / wsum; pb[o] = b / wsum; pa[o] = a / wsum;
            }
        }
    }

    /**
     * Distancia (en px) de cada pixel al dibujo (alfa >= thr). Dentro del dibujo = 0. Transformada
     * de distancia exacta (Felzenszwalb): rapida tambien en el telefono.
     */
    static float[] distanceToShape(float[] alpha, int w, int h, float thr) {
        final float INF = 1e10f;
        float[] f = new float[w * h];
        for (int i = 0; i < f.length; i++) f[i] = alpha[i] >= thr ? 0f : INF;
        float[] col = new float[Math.max(w, h)], d = new float[Math.max(w, h)];
        int[] v = new int[Math.max(w, h)];
        float[] z = new float[Math.max(w, h) + 1];
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) col[y] = f[y * w + x];
            edt1d(col, h, d, v, z);
            for (int y = 0; y < h; y++) f[y * w + x] = d[y];
        }
        for (int y = 0; y < h; y++) {
            System.arraycopy(f, y * w, col, 0, w);
            edt1d(col, w, d, v, z);
            for (int x = 0; x < w; x++) f[y * w + x] = (float) Math.sqrt(d[x]);
        }
        return f;
    }

    private static void edt1d(float[] f, int n, float[] d, int[] v, float[] z) {
        int k = 0;
        v[0] = 0;
        z[0] = -Float.MAX_VALUE;
        z[1] = Float.MAX_VALUE;
        for (int q = 1; q < n; q++) {
            double s = cross(f, q, v[k]);
            while (s <= z[k]) {            // z[0] = -infinito: el ciclo siempre termina
                k--;
                s = cross(f, q, v[k]);
            }
            k++;
            v[k] = q;
            z[k] = (float) s;
            z[k + 1] = Float.MAX_VALUE;
        }
        k = 0;
        for (int q = 0; q < n; q++) {
            while (z[k + 1] < q) k++;
            int p = v[k];
            d[q] = (float) (q - p) * (q - p) + f[p];
        }
    }

    private static double cross(float[] f, int q, int p) {
        return ((f[q] + (double) q * q) - (f[p] + (double) p * p)) / (2.0 * q - 2.0 * p);
    }

    /** Desenfoque de caja (horizontal y vertical) de radio r, en el lugar. */
    static void boxBlur(float[] a, int w, int h, int r) {
        float[] tmp = new float[a.length];
        float inv = 1f / (2 * r + 1);
        for (int y = 0; y < h; y++) {
            float s = 0f;
            for (int x = -r; x <= r; x++) s += a[y * w + Math.max(0, Math.min(w - 1, x))];
            for (int x = 0; x < w; x++) {
                tmp[y * w + x] = s * inv;
                s += a[y * w + Math.min(w - 1, x + r + 1)] - a[y * w + Math.max(0, x - r)];
            }
        }
        for (int x = 0; x < w; x++) {
            float s = 0f;
            for (int y = -r; y <= r; y++) s += tmp[Math.max(0, Math.min(h - 1, y)) * w + x];
            for (int y = 0; y < h; y++) {
                a[y * w + x] = s * inv;
                s += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
            }
        }
    }
}
