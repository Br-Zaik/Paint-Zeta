package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Deshacer y rehacer. Guarda solo la zona que cambio de la seleccion o de
 * una capa, y para cambios de capas (agregar, borrar, ordenar) guarda la
 * lista. Varias cosas hechas juntas se deshacen de una sola vez.
 */
public class UndoManager {

    public static final int SELECTION = 0;
    public static final int LAYER = 1;
    public static final int STRUCT = 2;
    /** v8.26: propiedades de las capas (modo, opacidad, recorte, bloqueos, Cambiar color...). */
    public static final int PROPS = 3;
    /** v8.26: zonas protegidas "No colorear". */
    public static final int PROTECT = 4;
    /**
     * v8.27: cambio de tamano del lienzo (Ampliar lienzo). geom = {izq, arriba, der,
     * abajo, tipo}: tipo 1 = restaurar QUITANDO esos margenes; tipo 2 = AGREGANDOLOS.
     * Antes "Ampliar lienzo" borraba todo el historial.
     */
    public static final int GEOM = 5;
    /** v8.40: lista de zonas de "Color por zonas" (las zonas no cambian: se guarda la lista). */
    public static final int ZONES = 6;
    /** v8.42: toda la obra cambio de tamano (Mejorar imagen): se guarda el contenido de cada capa. */
    public static final int RESIZE = 7;

    /** Cuanto puede guardar el deshacer: una parte de la memoria del telefono. */
    /** v8.62: segun el nivel del celular (baja 16-24 MB, media 24-48 MB, alta 24-64 MB como antes). */
    private static final long BUDGET = DeviceTier.undoBudget(Runtime.getRuntime().maxMemory());

    private static class Snap {
        int type;
        Rect r;
        Layer layer;
        byte[] bytes;
        int[] ints;
        /** Respaldo de capa ya existente. UndoManager toma propiedad y lo recicla. */
        Bitmap bitmap;
        List<Layer> list;
        int active;
        /** PROPS: las capas y sus propiedades en ese momento. */
        Layer[] propLayers;
        int[][] props;
        String[] names;
        boolean manga;
        int[] geom;
        List<ZoneTone.Zone> zones;
        /** RESIZE: capas y su contenido; geom = {ancho, alto}; bytes = seleccion; ints no se usa. */
        Layer[] rsLayers;
        Object[] rsContent;
        byte[] rsProtect;

        long size() {
            if (rsContent != null) {
                long t = 256;
                for (Object o : rsContent) t += Layer.contentBytes(o);
                if (bytes != null) t += bytes.length;
                if (rsProtect != null) t += rsProtect.length;
                return t;
            }
            if (bytes != null) return bytes.length;
            if (ints != null) return ints.length * 4L;
            if (bitmap != null && !bitmap.isRecycled()) return bitmap.getAllocationByteCount();
            return 64;
        }
    }

    private static class Entry {
        String label = "";
        final List<Snap> snaps = new ArrayList<Snap>();

        long size() {
            long s = 0;
            for (Snap x : snaps) s += x.size();
            return s;
        }
    }

    private final Project p;
    private final ArrayDeque<Entry> undo = new ArrayDeque<Entry>();
    private final ArrayDeque<Entry> redo = new ArrayDeque<Entry>();
    private long used = 0;
    private String label = "";
    private Entry group;
    private String lastLabel = "";
    private boolean lastStruct = false;

    public UndoManager(Project p) {
        this.p = p;
    }

    public void setLabel(String l) {
        label = l == null ? "" : l;
    }

    public String lastLabel() {
        return lastLabel;
    }

    /** true si lo ultimo que se deshizo cambio la lista de capas. */
    public boolean lastWasStruct() {
        return lastStruct;
    }

    /** Todo lo que se registre hasta end() se deshace junto. */
    public void begin() {
        group = new Entry();
        group.label = label;
    }

    public void end() {
        Entry g = group;
        group = null;
        if (g != null && !g.snaps.isEmpty()) push(g);
    }

    public void recordSelection(Rect r) {
        add(capture(SELECTION, r, null));
    }

    public void recordLayer(Layer l, Rect r) {
        add(capture(LAYER, r, l));
    }

    public void recordStruct() {
        Snap s = new Snap();
        s.type = STRUCT;
        s.list = new ArrayList<Layer>(p.layers);
        s.active = p.active;
        add(s);
    }

    /** v8.26: guarda las propiedades de TODAS las capas (y si el preset manga esta activo). */
    public void recordProps() {
        add(captureProps());
    }

    /** v8.27: se agregaron esos margenes al lienzo (Deshacer los quita). Llamar DESPUES de agrandar. */
    public void recordEnlarge(int left, int top, int right, int bottom) {
        Snap s = new Snap();
        s.type = GEOM;
        s.geom = new int[]{left, top, right, bottom, 1};
        add(s);
    }

    /**
     * v8.42: foto del estado ANTES de cambiar el tamano de toda la obra. Llamar antes de
     * Project.rescale y luego recordResize(foto). No copia pixeles: guarda referencias (las capas
     * reciben arreglos nuevos, asi lo viejo no se toca).
     */
    public Object resizeState() {
        return captureResize();
    }

    public void recordResize(Object state) {
        add((Snap) state);
    }

    private Snap captureResize() {
        Snap s = new Snap();
        s.type = RESIZE;
        s.geom = new int[]{p.w, p.h};
        s.rsLayers = p.layers.toArray(new Layer[0]);
        s.rsContent = new Object[s.rsLayers.length];
        for (int i = 0; i < s.rsLayers.length; i++) s.rsContent[i] = s.rsLayers[i].content();
        s.bytes = p.selection;
        s.rsProtect = p.protect;
        s.zones = new ArrayList<ZoneTone.Zone>(p.zones);
        s.active = p.active;
        return s;
    }

    /** true si el ultimo Deshacer/Rehacer cambio el tamano del lienzo. */
    public boolean lastWasGeom() {
        return lastGeom;
    }

    private boolean lastGeom;

    /** v8.40: guarda la lista de zonas de Color por zonas. */
    public void recordZones() {
        Snap s = new Snap();
        s.type = ZONES;
        s.zones = new ArrayList<ZoneTone.Zone>(p.zones);
        add(s);
    }

    /** v8.26: guarda la zona protegida (todo el lienzo; es un byte por pixel). */
    public void recordProtect() {
        Snap s = new Snap();
        s.type = PROTECT;
        s.bytes = p.protect == null ? null : p.protect.clone();
        add(s);
    }

    private Snap captureProps() {
        Snap s = new Snap();
        s.type = PROPS;
        int n = p.layers.size();
        s.propLayers = p.layers.toArray(new Layer[0]);
        s.props = new int[n][];
        s.names = new String[n];
        for (int i = 0; i < n; i++) {
            Layer l = s.propLayers[i];
            s.names[i] = l.name;
            s.props[i] = new int[]{l.visible ? 1 : 0, l.opacity, l.mode, l.clip ? (l.clipOut ? 2 : 1) : 0, l.alphaLock ? 1 : 0,
                    l.reference ? 1 : 0, l.locked ? 1 : 0, l.role, l.hue, l.sat, l.lit, l.con, l.gch};
        }
        s.manga = p.mangaMode;
        return s;
    }

    public void recordSelectionFromBackup(Rect in, byte[] backup) {
        Rect r = clamp(in);
        if (r == null || backup == null) return;
        Snap s = new Snap();
        s.type = SELECTION;
        s.r = r;
        s.bytes = copyBytes(backup, r);
        add(s);
    }

    public void recordLayerFromBackup(Layer l, Rect in, int[] backup) {
        Rect r = clamp(in);
        if (r == null || backup == null || l == null) return;
        Snap s = new Snap();
        s.type = LAYER;
        s.layer = l;
        s.r = r;
        s.ints = copyInts(backup, r);
        add(s);
    }

    /**
     * Igual que recordLayerFromBackup, pero el arreglo ya contiene SOLO el
     * rectangulo r (fila por fila). Se toma tal cual, sin volver a copiarlo.
     * Esto evita duplicar decenas de MB al confirmar Transformar.
     */
    public void recordLayerRegionBackup(Layer l, Rect in, int[] regionBackup) {
        Rect r = clamp(in);
        if (r == null || l == null || regionBackup == null) return;
        if (r.left != in.left || r.top != in.top || r.right != in.right || r.bottom != in.bottom) return;
        if (regionBackup.length != r.width() * r.height()) return;
        Snap s = new Snap();
        s.type = LAYER;
        s.layer = l;
        s.r = r;
        s.ints = regionBackup;
        add(s);
    }

    /**
     * Respaldo regional ya guardado en Bitmap. Se usa en Transformar para que
     * el Bitmap que ya existe pase directo al historial en vez de convertirlo
     * en otro int[] igual de grande. UndoManager toma propiedad del Bitmap.
     */
    public void recordLayerBitmapRegionBackup(Layer l, Rect in, Bitmap regionBackup) {
        Rect r = clamp(in);
        if (r == null || l == null || regionBackup == null || regionBackup.isRecycled()) return;
        if (r.left != in.left || r.top != in.top || r.right != in.right || r.bottom != in.bottom) return;
        if (regionBackup.getWidth() != r.width() || regionBackup.getHeight() != r.height()) return;
        Snap s = new Snap();
        s.type = LAYER;
        s.layer = l;
        s.r = r;
        s.bitmap = regionBackup;
        add(s);
    }

    /** Version compacta para la seleccion: el arreglo ya es exactamente r. */
    public void recordSelectionRegionBackup(Rect in, byte[] regionBackup) {
        Rect r = clamp(in);
        if (r == null || regionBackup == null) return;
        if (r.left != in.left || r.top != in.top || r.right != in.right || r.bottom != in.bottom) return;
        if (regionBackup.length != r.width() * r.height()) return;
        Snap s = new Snap();
        s.type = SELECTION;
        s.r = r;
        s.bytes = regionBackup;
        add(s);
    }

    private void add(Snap s) {
        if (s == null) return;
        if (group != null) {
            group.snaps.add(s);
            return;
        }
        Entry e = new Entry();
        e.label = label;
        e.snaps.add(s);
        push(e);
    }

    /** Memoria real aproximada de una entrada. Las estructuras cuentan capas que
     * ya no estan en el proyecto pero siguen vivas solo por el historial. */
    private long entrySize(Entry e) {
        long total = 0L;
        java.util.IdentityHashMap<Layer, Boolean> seen = new java.util.IdentityHashMap<Layer, Boolean>();
        for (Snap s : e.snaps) {
            if (s.type != STRUCT) { total += s.size(); continue; }
            total += 128L + (s.list == null ? 0 : s.list.size() * 16L);
            if (s.list != null) for (Layer l : s.list) {
                if (l == null || seen.put(l, Boolean.TRUE) != null) continue;
                if (!p.layers.contains(l)) total += l.memoryBytes();
            }
        }
        return total;
    }

    private void recalcUsed() {
        long n = 0L;
        for (Entry e : undo) n += entrySize(e);
        for (Entry e : redo) n += entrySize(e);
        used = Math.max(0L, n);
    }

    private void push(Entry e) {
        undo.push(e);
        for (Entry x : redo) releaseEntry(x);
        redo.clear();
        recalcUsed();
        while (used > BUDGET && undo.size() > 1) {
            Entry old = undo.removeLast();
            releaseEntry(old);
            recalcUsed();
        }
    }

    private static void releaseEntry(Entry e) {
        if (e == null) return;
        for (Snap s : e.snaps) {
            if (s.bitmap != null && !s.bitmap.isRecycled()) s.bitmap.recycle();
            s.bitmap = null;
        }
    }

    /** Recalcula el peso tras agregar/borrar/reordenar capas y recorta lo mas viejo. */
    public void rebalance() {
        recalcUsed();
        while (used > BUDGET && undo.size() > 1) {
            Entry old = undo.removeLast();
            releaseEntry(old);
            recalcUsed();
        }
    }

    public boolean canUndo() {
        return !undo.isEmpty();
    }

    public boolean canRedo() {
        return !redo.isEmpty();
    }

    /** Devuelve la zona a repintar (null = todo). */
    public Rect undo() {
        return swap(undo, redo);
    }

    public Rect redo() {
        return swap(redo, undo);
    }

    private Rect swap(ArrayDeque<Entry> from, ArrayDeque<Entry> to) {
        if (from.isEmpty()) return null;
        Entry e = from.pop();
        Entry back = new Entry();
        back.label = e.label;
        Rect dirty = null;
        boolean full = false;
        lastStruct = false;
        lastGeom = false;
        for (int k = e.snaps.size() - 1; k >= 0; k--) {
            Snap s = e.snaps.get(k);
            Snap now;
            if (s.type == RESIZE) {
                now = captureResize();
                lastStruct = true;
                lastGeom = true;
                full = true;
            } else if (s.type == GEOM) {
                now = new Snap();
                now.type = GEOM;
                now.geom = new int[]{s.geom[0], s.geom[1], s.geom[2], s.geom[3], s.geom[4] == 1 ? 2 : 1};
                lastStruct = true;
                lastGeom = true;
                full = true;
            } else if (s.type == STRUCT) {
                now = new Snap();
                now.type = STRUCT;
                now.list = new ArrayList<Layer>(p.layers);
                now.active = p.active;
                lastStruct = true;
                full = true;
            } else if (s.type == PROPS) {
                now = captureProps();
                lastStruct = true;
                full = true;
            } else if (s.type == ZONES) {
                now = new Snap();
                now.type = ZONES;
                now.zones = new ArrayList<ZoneTone.Zone>(p.zones);
            } else if (s.type == PROTECT) {
                now = new Snap();
                now.type = PROTECT;
                now.bytes = p.protect == null ? null : p.protect.clone();
                full = true;
            } else {
                now = capture(s.type, s.r, s.layer);
            }
            restore(s);
            // El respaldo bitmap de la entrada consumida ya no se necesitara:
            // el estado opuesto acaba de capturarse en 'now'.
            if (s.bitmap != null && !s.bitmap.isRecycled()) s.bitmap.recycle();
            s.bitmap = null;
            if (now != null) back.snaps.add(0, now);
            if (s.r != null) {
                if (dirty == null) dirty = new Rect(s.r);
                else dirty.union(s.r);
            }
        }
        to.push(back);
        recalcUsed();
        lastLabel = e.label;
        p.markDirty();
        return full ? p.fullRect() : (dirty == null ? p.fullRect() : dirty);
    }

    /** Suelta lo mas viejo hasta quedar en esa parte del limite (para liberar memoria). */
    public void trimTo(float part) {
        for (Entry x : redo) releaseEntry(x);
        redo.clear();
        recalcUsed();
        long lim = (long) (BUDGET * part);
        while (used > lim && !undo.isEmpty()) {
            Entry old = undo.removeLast();
            releaseEntry(old);
            recalcUsed();
        }
    }

    public void clear() {
        for (Entry x : undo) releaseEntry(x);
        for (Entry x : redo) releaseEntry(x);
        undo.clear();
        redo.clear();
        used = 0;
    }

    private Snap capture(int type, Rect in, Layer l) {
        Rect r = clamp(in);
        if (r == null) return null;
        Snap s = new Snap();
        s.type = type;
        s.r = r;
        s.layer = l;
        if (type == SELECTION) s.bytes = copyBytes(p.selection, r);
        else s.ints = copyLayer(l, r);
        return s;
    }

    private void restore(Snap s) {
        if (s.type == RESIZE) {
            for (int i = 0; i < s.rsLayers.length; i++) s.rsLayers[i].setContent(s.rsContent[i]);
            p.selection = s.bytes;
            p.protect = s.rsProtect;
            p.zones = new ArrayList<ZoneTone.Zone>(s.zones);
            p.sizeChanged(s.geom[0], s.geom[1]);
            return;
        }
        if (s.type == GEOM) {
            if (s.geom[4] == 1) p.crop(s.geom[0], s.geom[1], s.geom[2], s.geom[3]);
            else p.enlarge(s.geom[0], s.geom[1], s.geom[2], s.geom[3]);
            return;
        }
        if (s.type == PROPS) {
            for (int i = 0; i < s.propLayers.length; i++) {
                Layer l = s.propLayers[i];
                int[] v = s.props[i];
                l.name = s.names[i];
                l.visible = v[0] != 0;
                l.opacity = v[1];
                l.mode = v[2];
                l.clip = v[3] != 0;
                l.clipOut = v[3] == 2;
                l.alphaLock = v[4] != 0;
                l.reference = v[5] != 0;
                l.locked = v[6] != 0;
                l.role = v[7];
                l.hue = v[8];
                l.sat = v[9];
                l.lit = v[10];
                if (v.length > 12) { l.con = v[11]; l.gch = v[12]; }
            }
            p.mangaMode = s.manga;
            return;
        }
        if (s.type == PROTECT) {
            p.protect = s.bytes == null ? null : s.bytes.clone();
            return;
        }
        if (s.type == ZONES) {
            p.zones = new ArrayList<ZoneTone.Zone>(s.zones);
            return;
        }
        if (s.type == STRUCT) {
            p.layers.clear();
            p.layers.addAll(s.list);
            p.active = s.active < p.layers.size() ? s.active : p.layers.size() - 1;
            return;
        }
        int rw = s.r.width(), rh = s.r.height();
        if (s.type == LAYER && s.bitmap != null && !s.bitmap.isRecycled()) {
            int[] lp = s.layer.px();
            if (lp.length == p.w * p.h) {
                s.bitmap.getPixels(lp, s.r.top * p.w + s.r.left, p.w,
                        0, 0, rw, rh);
            }
            return;
        }
        for (int y = 0; y < rh; y++) {
            int dst = (s.r.top + y) * p.w + s.r.left;
            if (s.type == SELECTION) System.arraycopy(s.bytes, y * rw, p.selection, dst, rw);
            else if (s.bitmap == null) {
                int[] lp = s.layer.px();
                if (lp.length == p.w * p.h) System.arraycopy(s.ints, y * rw, lp, dst, rw);
            }
        }
    }

    private byte[] copyBytes(byte[] src, Rect r) {
        int rw = r.width(), rh = r.height();
        byte[] out = new byte[rw * rh];
        for (int y = 0; y < rh; y++) System.arraycopy(src, (r.top + y) * p.w + r.left, out, y * rw, rw);
        return out;
    }

    private int[] copyInts(int[] src, Rect r) {
        int rw = r.width(), rh = r.height();
        int[] out = new int[rw * rh];
        for (int y = 0; y < rh; y++) System.arraycopy(src, (r.top + y) * p.w + r.left, out, y * rw, rw);
        return out;
    }

    /** Copia la zona de una capa sin desempacarla. */
    private int[] copyLayer(Layer l, Rect r) {
        int[] d = l.denseOrNull();
        if (d != null && d.length == p.w * p.h) return copyInts(d, r);
        int rw = r.width(), rh = r.height();
        int[] out = new int[rw * rh];
        l.read(r.left, r.top, rw, rh, out, p.w, p.h);
        return out;
    }

    private Rect clamp(Rect in) {
        if (in == null) return null;
        int l = Math.max(0, in.left), t = Math.max(0, in.top);
        int rr = Math.min(p.w, in.right), b = Math.min(p.h, in.bottom);
        if (l >= rr || t >= b) return null;
        return new Rect(l, t, rr, b);
    }
}
