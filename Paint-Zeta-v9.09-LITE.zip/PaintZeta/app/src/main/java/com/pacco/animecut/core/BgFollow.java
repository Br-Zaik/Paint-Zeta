package com.pacco.animecut.core;

/**
 * v9.09 BALDE QUE SIGUE EL DEGRADADO (Borrar fondo, sin IA). Java puro: lo usan la app y las pruebas.
 *
 * Problema (fondos de noche, cielos, paredes con luz): el Balde compara cada pixel con UN color, el
 * del toque. En un fondo que se aclara o se oscurece de a poco, el borrado se cortaba a mitad del
 * fondo (con tolerancia 46) y habia que tocar muchas veces, o subir la tolerancia y arriesgar el
 * personaje.
 *
 * Despues del toque normal se mira la ORILLA de lo borrado. Si alli el fondo sigue igual de liso
 * (sin borde marcado: el pixel que quedo se parece al borrado de al lado y su alrededor es parejo)
 * y no se fue muy lejos del color del toque, se toca otra vez ahi, con el color de ese lugar. Se
 * repite unas pocas veces.
 *
 * Por que no se come al personaje: entre el fondo y el dibujo hay una LINEA o un cambio fuerte de
 * color (cara clara sobre fondo negro). Una orilla asi no es lisa: no se sigue. Y cada toque nuevo
 * es el mismo Balde de siempre (no cruza lineas ni cortes).
 */
public final class BgFollow {
    private BgFollow() { }

    /** Resultado: pixeles borrados de mas y caja de lo cambiado. */
    public static final class Result {
        public int steps, erased;
        public int rx0 = Integer.MAX_VALUE, ry0 = Integer.MAX_VALUE, rx1 = Integer.MIN_VALUE, ry1 = Integer.MIN_VALUE;

        void add(BgEngine e) {
            rx0 = Math.min(rx0, e.rx0); ry0 = Math.min(ry0, e.ry0);
            rx1 = Math.max(rx1, e.rx1); ry1 = Math.max(ry1, e.ry1);
        }
    }

    /** Parecido a una orilla lisa (0..255 por canal). */
    static final int SMOOTH_STEP = 16;
    /** Lo parejo que debe ser el alrededor del lugar (diferencia maxima de brillo en 5x5). */
    static final int FLAT = 18;

    /**
     * Sigue el degradado desde lo que borro el ultimo toque (e ya tiene la caja rx0..ry1).
     * @param ref0      color del primer toque
     * @param tol       tolerancia del Balde
     * @param maxSteps  toques extra como maximo
     * @param cancel    null o se consulta entre toques
     */
    public static Result run(BgEngine e, int[] px, int[] snap, int W, int H, BgEngine.Width wd, byte[] sel,
                             int ref0, int tol, int mode, float gap, boolean protect, int protC, int protT,
                             int maxSteps, Acabado.Cancel cancel) {
        Result res = new Result();
        if (snap == null || snap.length != px.length) return res;
        int bx0 = e.rx0, by0 = e.ry0, bx1 = e.rx1, by1 = e.ry1;
        int minGain = Math.max(400, W * H / 400);           // cada toque extra debe borrar algo de verdad
        int far = Math.min(150, tol * 5 / 2);                // hasta donde puede alejarse del color del toque
        boolean[] tried = new boolean[W * H];
        for (int step = 0; step < maxSteps; step++) {
            if (cancel != null && cancel.cancelled()) break;
            int seed = bestSeed(px, snap, W, H, bx0, by0, bx1, by1, ref0, far, mode, tried);
            if (seed < 0) break;
            int sx = seed % W, sy = seed / W;
            // no volver a probar alrededor de este lugar
            for (int y = Math.max(0, sy - 6); y < Math.min(H, sy + 7); y++)
                for (int x = Math.max(0, sx - 6); x < Math.min(W, sx + 7); x++) tried[y * W + x] = true;
            int c0 = BgEngine.tapColor(px, snap, W, H, sx, sy);
            if (c0 == 0) continue;
            e.setImage(px, snap, W, H, wd, sel);
            e.ref = c0 | 0xFF000000;
            e.tol = tol;
            e.mode = mode;
            e.gapScale = gap;
            e.protect = protect;
            e.protectColor = protC;
            e.protectTol = protT;
            if (!e.tap(sx, sy)) continue;
            // si borraria poco, no vale la pena (y evita comerse pedacitos del dibujo)
            int area = (e.rx1 - e.rx0) * (e.ry1 - e.ry0);
            if (area < minGain / 4) continue;
            int n = e.applyTo(px, sel);
            if (n <= 0) continue;
            res.steps++;
            res.erased += n;
            res.add(e);
            bx0 = Math.min(bx0, e.rx0); by0 = Math.min(by0, e.ry0);
            bx1 = Math.max(bx1, e.rx1); by1 = Math.max(by1, e.ry1);
            if (n < minGain) break;                          // ya casi no queda degradado que seguir
        }
        return res;
    }

    /**
     * El mejor lugar para seguir: un pixel que quedo (opaco) junto a lo borrado, liso, parecido a lo
     * borrado de al lado y no muy lejos del color del toque. Se elige el que tiene mas orilla lisa
     * alrededor (un frente ancho de degradado, no una esquinita).
     */
    static int bestSeed(int[] px, int[] snap, int W, int H, int x0, int y0, int x1, int y1,
                        int ref0, int far, int mode, boolean[] tried) {
        x0 = Math.max(2, x0 - 3); y0 = Math.max(2, y0 - 3);
        x1 = Math.min(W - 2, x1 + 3); y1 = Math.min(H - 2, y1 + 3);
        if (x1 <= x0 || y1 <= y0) return -1;
        int rw = x1 - x0, rh = y1 - y0;
        byte[] ok = new byte[rw * rh];
        int cnt = 0;
        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++) {
                int i = y * W + x;
                if ((px[i] >>> 24) < 250 || tried[i]) continue;
                // junto a lo borrado (a 2 px)
                int nb = -1;
                for (int dy = -2; dy <= 2 && nb < 0; dy++)
                    for (int dx = -2; dx <= 2; dx++) {
                        int j = (y + dy) * W + x + dx;
                        if ((px[j] >>> 24) < 20 && (snap[j] >>> 24) > 200) { nb = j; break; }
                    }
                if (nb < 0) continue;
                int c = snap[i], o = snap[nb];
                if (maxCh(c, o) > SMOOTH_STEP) continue;             // borde marcado: no se sigue
                if (ColorDist.dist(c, ref0, mode) > far) continue;  // muy lejos del fondo tocado
                if (!flat(snap, W, x, y)) continue;                  // hay detalle (linea, borde)
                ok[(y - y0) * rw + x - x0] = 1;
                cnt++;
            }
        if (cnt < 12) return -1;
        // frente mas ancho: cuantos candidatos hay en 15x15 alrededor
        int best = -1, bestN = 11;
        for (int y = 0; y < rh; y += 2)
            for (int x = 0; x < rw; x += 2) {
                if (ok[y * rw + x] == 0) continue;
                int n = 0;
                for (int dy = -7; dy <= 7; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= rh) continue;
                    for (int dx = -7; dx <= 7; dx++) {
                        int xx = x + dx;
                        if (xx >= 0 && xx < rw && ok[yy * rw + xx] != 0) n++;
                    }
                }
                if (n > bestN) { bestN = n; best = (y + y0) * W + x + x0; }
            }
        return best;
    }

    static int maxCh(int a, int b) {
        return Math.max(Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)),
                Math.max(Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)), Math.abs((a & 255) - (b & 255))));
    }

    /** Alrededor parejo (5x5, lo que no estaba borrado antes): sin lineas ni bordes. */
    static boolean flat(int[] snap, int W, int x, int y) {
        int lo = 255, hi = 0;
        for (int dy = -2; dy <= 2; dy++)
            for (int dx = -2; dx <= 2; dx++) {
                int c = snap[(y + dy) * W + x + dx];
                int l = BgEngine.lum(c);
                if (l < lo) lo = l;
                if (l > hi) hi = l;
            }
        return hi - lo <= FLAT;
    }
}
