# Paint Zeta v9.01 — Colorear, Parte 2 de 4: Acabado mas simple, con dibujitos

Incluye todo lo de la 9.00 (balde seguro).

## Acabado > Luz: 6 botones con dibujito
- Antes: fichas de solo texto (Dia, Tarde, Atardecer, Luna llena, Media luna, Interior); habia
  que probar cada una para saber que hacia.
- Ahora: cada luz es un cuadradito que MUESTRA el efecto (el color del ambiente y una esfera de
  piel con su luz, su sombra y su borde) y el nombre debajo: Dia, Atardecer, Noche, Lampara,
  Neon y Parque. Al tocar, una frase corta dice que hace.
- Noche = la antigua Luna llena. Tarde y Media luna ya no se muestran (las obras viejas que las
  usan se siguen viendo igual).
- Lampara (antes "Interior", que casi no cambiaba nada): ahora calida de verdad, ambar, con
  sombras marron rojizas.
- Neon (nuevo): luz rosa de frente y contraluz celeste, sombras azul marino.
- Parque (nuevo): luz blanca de dia, sombras lila, verde abajo (el pasto) y celeste arriba (cielo).

## Acabado > Estilo: 3 botones con dibujito
- Manhwa (sombras suaves, brillo fuerte), Anime (sombra de borde duro) y Suave (nuevo).
- Suave (novela ligera): sombras mas livianas y difuminadas, todo un poco mas claro y pastel,
  rubor mas visible y color melocoton, mas resplandor.

## Lo demas
- A la vista solo queda la barra de Fuerza; lo avanzado sigue en "Mas".
- El boton de comparar dice "Manten: antes" (mientras lo mantienes ves como estaba).

## Arreglo: botones encimados
- Causa: la tarjeta se ponia encima de la barra de abajo midiendo su alto UNA vez. Si despues la
  barra crecia (salia "Toca una parte del dibujo"), la tarjeta quedaba encima; y como era medio
  transparente, se veia el texto de abajo a traves ("Antes" y "Mas" encima del texto).
- Ahora: las tarjetas suben o bajan solas cuando la barra cambia de alto, y son casi opacas.

## Prueba en PC con tu dibujo (el chico saludando)
- Se uso el motor del Acabado de la app con 6 partes pintadas (piel, pelo, camisa, corbata,
  chaleco, saco). Las 6 luces se ven distintas entre si; los 3 estilos se distinguen (Suave
  se ajusto para que se note mas). Las miniaturas tambien se dibujaron en PC y se ven bien.

## Firma
- Misma firma fija: se instala encima de la 9.00 sin desinstalar.

## Revision
- Compilador de Java sobre todo el codigo: solo faltan las piezas de Android. No probado en telefono.

## Como probarlo
1. Pinta unas partes y pasa a "2 Acabado".
2. Toca cada luz: el dibujito debe parecerse a lo que pasa en tu dibujo.
3. Prueba los 3 estilos. Manten "Manten: antes" para comparar.
4. Revisa que la tarjeta ya no tape la barra de abajo.
