# Paint Zeta 9.07 — Arreglos y funciones nuevas (todo en una version)

## 1. Quitar fondo: Escobita
- **Causa:** la escoba hacia 4 cosas a la vez: borraba restos sueltos, recortaba el borde a medio
  borrar, rellenaba agujeritos y suavizaba el borde. Por eso a veces tocaba la imagen.
- **Ahora:** solo BARRE: pedazos y puntitos SUELTOS (separados del dibujo) y polvo casi invisible
  suelto. No rellena huecos, no toca el borde y no toca lo grande que estas recortando. El aviso
  dice "Barrido: N pedazos sueltos".

## 2. Quitar fondo: Fondo negro o blanco a transparente (nuevo, video de las burbujas)
- Boton nuevo (burbuja sobre cuadritos) al lado de la escoba, y "Quitar negro" en el menu de la capa.
- Para burbujas, fuego, humo, luces o chispas sobre fondo negro (o blanco): el fondo se va y lo
  transparente queda transparente de verdad, con su brillo y su color. No se come el centro como
  con el balde. Despues se pone cualquier fondo en una capa de abajo. No es para personajes.

## 3. Mejorar x2 / x4
- **Causa:** pedia TODAS las capas grandes a la vez en la memoria de la app (capas + 2). Con
  1280 x 1856 a x2 ya salia "Muy grande para este telefono".
- **Ahora:** trabaja por pedazos y UNA capa a la vez; cada capa lista se guarda en la memoria grande
  del telefono. Si de verdad no entra, dice por que (x4 de una imagen grande pasa el maximo de la
  app; o falta memoria libre) y primero libera lo que puede.

## 4. Colorear
- **Balde / herramientas:** dentro de Colorear el boton de herramientas muestra Colorear y en el
  panel se marca "1 Colorear" (antes se marcaba Relleno y parecia que te mandaba a otra herramienta).
- **Pincel = como la Brocha:** punta redonda y suave, con Protegido y Libre. Pinta AL INSTANTE y en
  tamano real (antes la vista previa era achicada y se veia en cuadritos). Al soltar queda con su
  acabado. Usa tambien la barra de opacidad.
- **Borrar = como el borrador de Borrar fondo:** borde suave; repasar no come de mas.
- **Bordes del Pincel y Borrar:** donde el borde suave toca otro color, se mezclan (sin huecos blancos).
- **Encerrar:** igual que antes (va entero).
- **Imagen (nuevo, video del jean):** pinta una textura o una foto tuya sobre la parte y se siguen
  viendo las lineas, sombras y pliegues del dibujo. Texturas propias de la app (hechas con formulas,
  no son fotos de nadie) que toman el color elegido: Jean, Tela, Cuadros, Lunares, Trama de manga,
  Cielo, Galaxia y Brillos. "Mi imagen" usa una foto de la galeria (mantener = elegir otra).
  Tamano Chica / Mediana / Grande, Protegido / Libre y Borrar. Va en su capa "Textura".
- **Acabado (puntitos blancos, captura 6):**
  - **Causa:** la "luz de borde" se ponia junto a cualquier parte sin pintar que llegaba al borde
    (un mechon gris delante de la cara) y aclaraba la linea: quedaban puntos y rayas blancas sobre
    la linea negra.
  - **Ahora:** la luz de borde va solo junto al fondo de verdad (transparente o papel), no aclara la
    linea ni su filo y es una franja suave.
- **Fundir suave (nuevo, paso 3 Final, video de Procreate):** pasas el dedo por las manchas o
  bordes duros y los colores de esa parte se mezclan como un degradado natural (tambien con zoom).
  No cruza la linea negra, no mezcla dos partes distintas y no pinta lo que no tiene color.
  Mantener presionado = mini tutorial.

## 5. Guardar
- El boton de guardar va directo a "Guardar imagen" (sin ZIP ni capas).
- **Galeria:** SIEMPRE el tamano y la calidad originales (PNG, sin perder nada, con transparencia).
  Antes "Normal" la achicaba a 883 x 1280 (captura 10).
- **Redes (WhatsApp, Instagram, Historias, Facebook, Correo, X):** la medida justa que acepta cada
  red (asi no la vuelve a achicar), JPG calidad 90 o mas, y un toque de nitidez al achicar para que
  no quede borrosa.
- Se quito "Calidad" (Normal / Alta / Maxima).
- **Ver como queda (nuevo):** arma la imagen tal cual se va a guardar y la muestra; con un toque se
  ve al 100 % (pixel por pixel).

## 6. Capas: ver solo una (nuevo, video de Ibis)
- Mantener presionado el ojo de una capa = solo se ve esa. Mantener otra vez = se ven todas como
  estaban. Al guardar la imagen se vuelven a ver todas solas.

## 7. Recortar: girar a cualquier angulo (nuevo, video de Ibis)
- Boton nuevo al lado de "Girar 90". Barrita de -180 a 180 con vista previa, botones de 1 y 0,1
  grados, y se "pega" en 0, 90 y 180. Toda la obra gira (todas las capas y lo pintado en Colorear),
  el lienzo crece para que nada se corte y despues recortas lo que sobra.

## Que NO se probo
- Nada se probo en un telefono: aqui no hay Android para compilar. Revisar en el celular sobre todo:
  Pincel y Borrar de Colorear (se ven al instante), Imagen, Fundir suave, "Ver como queda",
  girar a cualquier angulo, el modo solo de capas y Mejorar x2.
- Si se probo en la PC (Java puro, con las imagenes de prueba): la Escobita (no toca el dibujo, no
  rellena huecos), el Acabado sin puntitos blancos, Fundir suave (no cruza la linea del cuello),
  las texturas sobre el dibujo (jean y cuadros con sus pliegues), negro a transparente, girar
  14 / 90 / -37,5 / 180 grados (las zonas de Colorear giran con el dibujo) y la nitidez al achicar.

## Como probarlo
1. Quitar fondo > borra el fondo > Escoba: solo se van los puntitos sueltos, el borde queda igual.
2. Una imagen de burbujas o fuego en negro > boton de la burbuja > Negro.
3. Mejorar > x2 con tu imagen de 1280 x 1856: ahora debe dejar.
4. Colorear > Pincel: pinta redondo y suave al instante. Borrar: borde suave.
5. Colorear > Imagen > Jean > color azul > pasa el dedo por la ropa.
6. Colorear > 2 Acabado: ya no salen puntitos blancos en la linea. 3 Final > Fundir suave por una mancha.
7. Guardar > Galeria: dice el tamano original. Facebook > Ver como queda > toca para ver al 100 %.
8. Capas > mantener el ojo. Recortar > Girar a cualquier angulo.

## Archivos
- Cambiados: MainActivity.java, CanvasView.java, ToolTutoView.java, core/Acabado.java,
  core/BgCleanup.java, core/Exporter.java, core/Layer.java, core/Project.java, core/Resample.java,
  core/SoftBlend.java, core/ZoneTone.java, app/build.gradle (version 9.07, codigo 145), LEEME_LITE.txt
- Nuevos: core/Textures.java, core/RotateFree.java, res/drawable/ic_black_alpha.xml, CAMBIOS_9_07.md
- La firma fija (paintzeta.keystore) sigue igual: se instala encima de la 9.06 sin desinstalar.
