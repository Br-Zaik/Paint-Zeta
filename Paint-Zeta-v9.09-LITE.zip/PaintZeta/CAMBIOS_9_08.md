# Paint Zeta 9.08 — Arreglos de los 5 videos y las capturas + Sticker y Logo (todo en una version)

## 1. Tutorial del inicio (video 1)
- **Causa:** al tocar "Siguiente" la app cerraba la ventana y abria otra nueva. Por un momento se
  veian las dos mezcladas y transparentes, y despues la ventana cambiaba de alto: el "tik" del 3 al 4.
- **Ahora:** una sola ventana; "Siguiente" cambia solo el contenido con un deslizado suave. Texto
  de una linea por paso, zorrito mas chico, puntitos que dicen en que paso vas, y la ventana no
  cambia de alto. Un doble toque rapido ya no salta dos pasos.

## 2. Capas: arrastrar la rayita (video 2)
- **Causa:** la zona para agarrar media 20 dp. Si el dedo caia un poquito arriba, tocaba la
  imagen y la movia o la agrandaba en vez de subir el panel.
- **Ahora:** zona de toque mas alta (34 dp) y la palabra "Capas" tambien sirve para arrastrar.

## 3. Mover (video 3)
- **Causa:** cada vez que se aplicaba, lo que habia quedado fuera del borde se cortaba para
  siempre. Por eso la imagen termino siendo un pedacito y al final desaparecio.
- **Ahora:** "memoria de Mover". Al aplicar se guarda la imagen ENTERA. Si vuelves a Mover esa
  misma capa (sin haberla pintado ni cambiado), parte de la imagen entera: lo que salio del borde
  vuelve, y achicar y despues agrandar ya no la deja borrosa. Funciona aunque ya no se vea nada.
  Si pintas en la capa, deshaces o usas Perspectiva / Malla, la memoria se olvida (como siempre).
  Cuando algo sale del borde, el aviso dice: "Lo de afuera no se pierde: vuelve a Mover y regresalo".

## 4. Texto (video 4)
- **Causa:** se abria una pantalla negra completa para escribir (no se veia la imagen); abajo
  habia 3 filas (estilos, 8 botones y 3 pestanas), y la barra de "Tamano" repetia lo que ya hace
  la bolita del cuadro. Al achicar el cuadro la palabra se partia ("YYYh" arriba y "b" abajo).
- **Ahora:**
  - Se escribe con la imagen a la vista: arriba una barrita (X, lo que escribes, check) y el texto
    aparece en la imagen mientras escribes. Tocar la imagen = listo. El texto nuevo sale mas
    arriba para que el teclado no lo tape.
  - Abajo UNA sola fila: X, Estilos, Letra, Color, Contorno, Sombra, Mas y check.
    En "Mas": Formato, Fondo, Globo (la forma del globo y su grosor), Color del globo, Letras y Lineas.
  - Sin barra de Tamano ni de Girar: se hacen con los dedos o con la bolita del cuadro.
  - Los estilos rapidos van en una sola fila.
  - Nunca se parte una palabra a la mitad: las palabras enteras pasan a la linea de abajo.

## 5. Colorear: Pincel (video 5)
- **Causa (3 cosas juntas):**
  1. Si las lineas del dibujo aun no estaban listas, el trazo se veia entero en rojo sin proteger;
     al soltar se calculaban las lineas ("Mirando las lineas...") y solo quedaba la parte donde
     empezaste: el "4" se volvio un palito.
  2. Mientras pintabas se veia color plano (tapaba la trama); al soltar cambiaba al acabado.
  3. La primera vez se quedaba pensando.
- **Ahora:**
  - Las lineas se preparan al abrir Colorear (antes de pintar).
  - Si todavia no estan, el trazo espera ("Preparando las lineas... sigue pintando") y apenas
    estan, se ve la parte protegida de verdad. Ya no sale el rojo falso.
  - Al pintar el color ya se ve con la trama y las sombras del dibujo (como queda), no plano.

## 6. Colorear: barra mas corta (video 5)
- **Causa:** hasta 8 filas: pasos, herramientas, colores, Protegido/Libre, su explicacion, el
  aviso "Toca una parte del dibujo" y las barras de tamano y opacidad. La imagen quedaba chica.
- **Ahora:**
  - Protegido / Libre es un boton mas al final de la fila de herramientas (escudo o mano).
  - Sin la fila de explicacion ni la de "Toca una parte del dibujo" (el aviso sale al elegir).
  - Las barras de abajo solo salen cuando sirven: Pincel = tamano y opacidad; Borrar e Imagen = solo tamano;
    3 Final = como siempre; Balde, Encerrar, Tomar y Acabado = ninguna.

## 7. Aviso de Capas la primera vez (imagen 1)
- Se quito: tapaba los botones. La ayuda sigue al mantener presionado.

## 8. "¿Extraer las lineas?" (imagen 2)
- **Causa:** preguntaba con cualquier imagen (tambien a color) y esperaba 0,7 s a proposito.
- **Ahora:** solo pregunta si parece manga en blanco y negro sobre papel, sale al instante,
  ventana centrada y un poco transparente con "Ahora no" / "Si, extraer" y la casilla
  "No volver a preguntar".

## 9. Guardar: Ver como queda y WhatsApp HD (imagenes 3 y 4)
- **Causa:** la vista era un cuadrito sin zoom (solo un toque para el 100 %).
- **Ahora:** pantalla completa como la galeria: dos dedos acercan, un dedo mueve, doble toque =
  100 % (pixel por pixel). Arriba dice la medida, el peso y que Facebook o WhatsApp la vuelven a
  comprimir al subirla (eso no lo controla ninguna app).
- **Nuevo "WhatsApp HD"** (al lado de WhatsApp): guarda hasta 4096 px en JPG calidad 95 y recuerda
  tocar el boton HD de WhatsApp al enviar (o mandarla como documento). Lo elegido antes no cambia.

## 10. CREAR: Sticker y Logo (nuevo, en Herramientas abajo de todo)
- **Sticker:** toma lo visible (ya recortado), lo centra en 512 x 512 con aire, borde blanco (sin,
  fino o grueso) y sombra suave. Guarda en WebP de hasta 100 kB (lo que pide WhatsApp) o PNG, y
  se puede compartir. Si la imagen todavia tiene fondo, ofrece quitarlo con IA primero.
  Para ponerlo en WhatsApp: su opcion de crear sticker o una app de paquetes de stickers.
- **Logo:** circulo, escudo, estrella, sello o cinta; 10 colores y "mas colores"; borde negro,
  blanco o sin borde; nombre al medio y texto en curva arriba. Queda en su capa "Logo": se ubica
  con Mover y se guarda en PNG con fondo transparente.
- Mantener presionado Sticker o Logo = mini tutorial.

## Que NO se probo
- Nada se probo en un telefono: aqui no hay Android para compilar. Revisar en el celular sobre todo:
  el tutorial, arrastrar Capas, Mover dos veces seguidas sacando la imagen del borde, escribir
  texto, el Pincel protegido, la barra de Colorear, el visor con zoom, Sticker y Logo.
- Si se probo aqui (Java puro): el Sticker (512 x 512, aire de 16 px, borde blanco pegado al
  dibujo, sombra dentro del aire, esquinas transparentes, 73 ms con una imagen de 1500 x 2200) y las
  5 formas del Logo (dentro de su caja, bien cerradas, con dibujo de prueba).
- Se reviso todo el codigo: sin errores de escritura y sin nombres que no existan (comparado
  contra la 9.07). La compilacion de verdad la hace GitHub.

## Como probarlo
1. Abre una imagen a color: no debe preguntar "Extraer las lineas". Abre un manga B/N: si.
2. Menu ⋮ > Guia rapida: Siguiente del 3 al 4 sin salto.
3. Capas: arrastra la rayita o la palabra "Capas" arriba y abajo.
4. Mover: saca media imagen del borde > check > Mover otra vez > regresala: vuelve entera.
5. Marcar > Texto > Escribir texto: se ve la imagen, el texto aparece al escribir. Achica el
   cuadro: las palabras no se parten. Abajo una sola fila.
6. Colorear > Pincel (protegido): dibuja un "4" que cruce lineas: lo que ves es lo que queda.
   La barra: Balde sin barras abajo; Pincel con tamano y opacidad; boton escudo/mano.
7. Guardar > Facebook > Ver como queda: zoom con dos dedos y doble toque. Prueba WhatsApp HD.
8. Herramientas > CREAR > Sticker (con un personaje recortado) y Logo.

## Archivos
- Cambiados: MainActivity.java, view/CanvasView.java, app/build.gradle (version 9.08, codigo 146),
  LEEME_LITE.txt, README.md
- Nuevos: core/StickerMaker.java, core/LogoShapes.java, view/ZoomImageView.java, CAMBIOS_9_08.md
- La firma fija (paintzeta.keystore) sigue igual: se instala encima de la 9.07 sin desinstalar.
