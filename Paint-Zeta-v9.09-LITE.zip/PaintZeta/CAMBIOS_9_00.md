# Paint Zeta v9.00 — Colorear, Parte 1 de 4: balde seguro y facil de corregir

Incluye todo lo de la 8.99. Plan de Colorear en 4 partes (sale de la investigacion):
1 Balde seguro (esta) · 2 Acabado mas simple con dibujitos · 3 Mejor luz y sombra · 4 Herramientas nuevas.

## Colorear > paso 1: herramientas con nombre
- Antes: un solo boton que cambiaba entre "Tocar zonas" y "Rayar"; para arreglar algo solo
  quedaba Deshacer.
- Ahora: una fila con icono y nombre: Pintar, Rayar, Borrar, Tomar, Separar y Huecos.

## Borrar (nuevo)
- Tocas una parte pintada y vuelve a quedar sin color. Deshacer la devuelve.

## Tomar (nuevo, cuentagotas)
- Tocas una parte pintada y su color queda elegido; despues vuelve solo a Pintar.

## Cambiar el color de una parte
- Causa: tocar otra vez la misma parte con otro color ponia una zona nueva ENCIMA; se iban
  apilando y al borrar aparecia el color de antes.
- Ahora: si es la misma parte, se le CAMBIA el color (una sola zona).

## Separar (nuevo)
- Dibujas una linea con el dedo donde el color se escapa: el balde ya no pasa por ahi.
  La linea se ve verde mientras pintas y NO sale al guardar. "Quitar lineas" las borra.
- Tambien la respeta Rayar.
- Las lineas duran mientras la obra esta abierta (no se guardan dentro de la obra todavia).

## Huecos (cerrar cortes de la linea)
- Antes: escondido en otro menu, solo con texto.
- Ahora: en la fila, con su nivel a la vista. Al tocarlo salen 4 opciones con dibujito
  (el color escapando por el corte o el corte "cosido"): No, Poco, Medio (recomendado), Mucho.

## Aviso "¿Se salio el color?"
- Si un toque pinta 30% o mas del dibujo, pregunta: Deshacer · Deshacer y tapar el hueco con
  Separar · Esta bien · No preguntar mas.

## Prueba en PC con tu dibujo (el chico saludando, en gris)
- Se uso el mismo motor del balde de la app, tocando 10 partes.
- Huecos en Medio: nada se sale (cara, pelo, cuello, cuello de camisa, oreja: cada uno en su lugar).
- Huecos en No: cara + pelo + oreja se juntan (34% del dibujo) y cuello + camisa (22%): eso es
  "el color se pasa". El aviso nuevo salta en el primer caso.
- Huecos en Mucho: el pelo y la oreja quedan cortados en pedazos. Por eso Medio es lo recomendado.
- Lo que falta: en partes con textura (chaleco tejido, mano con sombras) cada toque pinta solo un
  pedacito. Para eso sirve Rayar; "pintar varias partes arrastrando el dedo" va en la Parte 4.

## Firma
- Misma firma fija: se instala encima de la 8.99 sin desinstalar.

## Revision
- Compilador de Java sobre todo el codigo: solo faltan las piezas de Android, como siempre.
- No probado en un telefono.

## Como probarlo
1. Colorear > paso 1: debe salir la fila Pintar, Rayar, Borrar, Tomar, Separar, Huecos.
2. Pinta la cara. Toca Borrar y toca la cara: vuelve a gris. Deshacer: vuelve el color.
3. Pinta el pelo de cafe; elige otro color y toca el pelo otra vez: cambia (no se apila).
4. Tomar: toca el pelo; luego toca otra parte: se pinta con ese mismo color.
5. Huecos > No, y toca la cara: si se sale, debe salir el aviso. Elige "Deshacer y tapar con
   Separar", dibuja una linea donde se escapo, vuelve a Pintar y toca otra vez.
