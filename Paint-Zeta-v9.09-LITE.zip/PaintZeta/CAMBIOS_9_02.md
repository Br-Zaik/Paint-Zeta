# Paint Zeta v9.02 — Colorear, Parte 3 de 4: mejor luz y sombra

Incluye todo lo de la 9.01. Todo esto es dentro del Acabado (paso 2 de Colorear).
Se probo en PC con el motor de la app: el chico saludando en gris, pintado entero, contra la
ilustracion a color que mandaste como meta.

## Pelo y colores oscuros que salian morados
- Causa: el motor tomaba el castano oscuro (y la corbata marron) como si fueran GRIS, porque son
  colores apagados; a lo gris le pone sombras violeta azuladas. El pelo salia azul marino/morado.
- Ahora: solo cuenta como gris lo que de verdad es gris (blanco, gris, negro). Un color apagado
  conserva su tono: el pelo castano queda castano en la sombra.

## Partes que salian con sombra de piel
- Causa: el saco beige, el chaleco mostaza, la pared y el piso de la paleta "Fondos" contaban como
  piel y les salian sombras rojizas.
- Ahora: piel solo si tiene tono y claridad de piel.

## Colorear los grises del autor (la regla de los coloristas)
- Causa: si el dibujo ya traia sus sombras en gris, el acabado cambiaba mucho la claridad
  (un gris oscuro 44 salia 59; un mechon claro 114 salia 61): se perdia el sombreado del autor.
- Ahora: en las partes que ya traen sombras, la claridad sigue al gris del dibujo y el acabado
  pone el color, la luz del sol, los brillos y el borde de luz encima. Funciona tambien en el
  pelo oscuro. Medido contra la meta: mechones 114/92/73 -> salen 114/93/77 (meta 111/90/73).
  En Anime se aplica menos, para que se noten sus escalones de sombra.

## Orejas y dedos rojizos (nuevo)
- La luz atraviesa la piel fina: las partes finas de la piel (orejas, dedos) se ponen rojizas.
  La app mide lo fina que es cada parte (no hace falta marcar nada).
- Medido: oreja 214,161,152 (meta 213,162,149; antes 213,178,174).

## Luz rebotada (nuevo)
- Dentro de la sombra, cerca del borde del lado contrario a la luz, una franja un poco mas clara
  con el color del lugar: verde en Parque, naranja con Lampara, azulado de Dia.

## Sombra del flequillo
- Mas larga (sigue las puntas del pelo). Se nota en dibujos de solo lineas; si el autor ya dibujo
  esa sombra, se respeta la suya.

## Pelo tipo espejo (Manhwa)
- El brillo del pelo en Manhwa es mas fuerte, mas nitido y mas blanco.

## Rubor con rayitas y brillo del pomulo (nuevo)
- En Manhwa y Suave: rayitas finas en diagonal en el centro del rubor, y un brillo chico en el
  pomulo del lado de la luz.
- Ojo: el rubor automatico solo sale cuando la app encuentra los dos ojos. En el chico de prueba
  (ojos tapados por el flequillo) no sale; ahi se ve el rubor que dibujo el autor.

## No hecho
- Brillo de labios: la app todavia no sabe donde esta la boca.

## Firma
- Misma firma fija: se instala encima de la 9.01 sin desinstalar.

## Revision
- Compilador de Java sobre todo el codigo: solo faltan las piezas de Android. No probado en telefono.
- Velocidad: en PC el acabado del chico tarda lo mismo que antes.

## Como probarlo
1. Colorea un personaje de pelo castano oscuro y pasa a Acabado: el pelo debe quedar castano, no morado.
2. Mira las orejas y los dedos: un poco rojizos.
3. Prueba Parque y Lampara y mira el borde de la sombra (abajo): el color del lugar.
4. Si tu dibujo trae sombras grises, deben verse iguales, solo que con color.
