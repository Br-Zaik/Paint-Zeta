# Paint Zeta 9.09 — Colorear y Quitar fondo mejorados (sin IA), probados con tus imágenes

Regla de esta versión: mejorar las herramientas que ya están, sin botones nuevos y sin IA.

## 1. Colorear, paso 1: el Balde pinta lo NEGRO ancho
- **Causa:** tocar dentro de un negro (pelo negro, short negro, saco, medias) contaba como "tocaste
  la línea": saltaba al blanco de al lado o pintaba manchitas sueltas dentro del negro.
- **Ahora:** si tocas (o pasas el dedo) dentro de un negro ancho, se pinta todo ese negro y los
  brillos encerrados (en el color quedan como luz). Las líneas finas NO se pintan: el relleno no
  viaja por ellas a otras partes.
  - Si el negro se junta con un fondo oscuro (noche), lo intenta otra vez sin cruzar el contorno.
    Si igual saldría el fondo, no pinta nada (nunca pinta media imagen).
  - En gris oscuro (no negro) primero va el Balde de siempre; el nuevo solo entra si el de siempre
    no sirvió. Lo que ya funcionaba no cambia.
- La gargantilla, cinturón o cualquier negro macizo ya no se mete a la piel con manchas marrones.

## 2. Colorear, paso 2 (Acabado)
- **Brillo del pelo:** antes eran manchas tipo plástico. Ahora son rayitas finas de peine, como en el
  anime, saliendo desde la coronilla.
- **Noche y Atardecer:** antes se veían casi igual que Día. Ahora la Noche es azul de verdad (más
  oscura, sombras azules, contraluz celeste) y el Atardecer es naranja con sombras lila.
- **Rojos:** el pelo o la ropa roja ya no se vuelven fucsia en la sombra: queda granate.

## 3. Quitar fondo: Balde que sigue el degradado
- **Causa:** el Balde compara con UN color, el del toque. En un fondo que se aclara o se oscurece de a
  poco (noche, cielo, pared con luz) se cortaba a la mitad y había que tocar muchas veces.
- **Ahora:** después de borrar, mira la orilla de lo borrado: si el fondo sigue liso, sigue solo
  (hasta 6 veces, o 3 en imágenes muy grandes). No sigue por líneas ni por cambios fuertes de color,
  así el personaje no se toca. Todo queda en un solo Deshacer.
- Prueba con la maid de noche: con 4 toques antes borraba 17 %, ahora 30 % (casi todo el fondo).

## 4. Quitar fondo: el borrador que reconoce lo negro
- **Causa:** en un fondo oscuro con rayas o ventanas, el trazo se cortaba en la primera raya y ya no
  borraba más hasta levantar el dedo.
- **Ahora:** con fondo oscuro o de color, si el dedo vuelve a estar entero sobre ese fondo, sigue
  borrando desde ahí (y toma el color de ese lugar). Con papel claro NO lo hace (una camisa
  blanca sobre papel blanco se borraría). Nunca agarra algo más oscuro que el fondo (saco negro).
- Prueba: el mismo trazo en la noche borraba 5 400 px, ahora 23 500 px, sin tocar la mano ni el pelo.

## Optimización
- El relleno de negro trabaja solo en la caja del negro (no en la imagen entera): unos 30 ms en PC
  con una imagen de 832 x 1216.
- El Balde que sigue el degradado trabaja sobre una copia y pasa todo de una vez a la capa.

## Pruebas hechas (en PC, Java puro, con tus imágenes)
- Colorear: Reze, maid y Chizuru pasadas a blanco y negro, pintadas con el Balde (mismos toques que
  harías con el dedo) y con el Acabado en Día, Atardecer y Noche. Comparadas con la 9.08.
- Quitar fondo: Makima (fondo negro), Denji (cielo), maid (noche), Reze (ciudad) a color y en
  blanco y negro. En ninguna se borró parte del personaje.
- Revisión de todo el código contra la 9.07: sin errores de escritura ni nombres que no existan.

## Qué NO se probó
- Nada en un teléfono: aquí no hay Android para compilar. Revisar: velocidad del Balde de Quitar
  fondo en imágenes grandes, el relleno de negro con el dedo y el Acabado en el celular.
- Los dientes y el blanco de los ojos dentro de la piel a veces toman color piel (ya pasaba antes).

## Cómo probarlo
1. Colorear > Balde: toca dentro de un pelo negro o un short negro: se pinta entero.
2. Colorear > 2 Acabado: mira el brillo del pelo; cambia a Noche y a Atardecer.
3. Quitar fondo > Balde en un cielo o una noche: borra más de un toque.
4. Quitar fondo > Borrador en un fondo oscuro: pasa el dedo por la orilla del personaje.

## Archivos
- Cambiados: core/MangaFill.java, core/Acabado.java, core/BgBrushFast.java, view/CanvasView.java,
  app/build.gradle (versión 9.09, código 147), LEEME_LITE.txt, README.md
- Nuevos: core/BgFollow.java, CAMBIOS_9_09.md
- La firma fija sigue igual: se instala encima de la 9.08 sin desinstalar.
