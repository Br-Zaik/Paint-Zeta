# Paint Zeta 9.06 — Colorear mas simple

## Paso 1 de Colorear: solo 5 herramientas
Balde, Pincel, Encerrar, Borrar y Tomar. Se quitaron de la fila Rayar, Retocar, Separar, Cambiar y
Huecos (confundian). Huecos queda solo en Medio (lo que mejor salio en las pruebas). Las rayas
verdes de Separar ya no se ven ni frenan el balde (se limpian al entrar a Colorear). La barra de
rayones (circulo rojo, menos, tacho, ✓) ya no sale debajo de Colorear.

- **Pincel** (nuevo, reemplaza a Retocar): pinta con el dedo. Protegido: el color se queda en la
  parte donde empezaste y no cruza la linea negra; se ve mientras pintas. Libre: todo por donde
  pasas. Ahora SI tapa el color que habia (antes habia que borrar primero).
- **Encerrar** (nuevo): una vuelta con el dedo alrededor de la parte (oreja, mano, mechon). Se
  pintan las partes que quedan dentro; lo que sigue mucho por fuera (pelo de alrededor, fondo) no.
  Si la parte no tiene su linea cerrada, se pinta todo lo de adentro de la vuelta.
- **Borrar**: borra AL INSTANTE mientras arrastras (sin rojo), como el borrador de Borrar fondo.
  Protegido no pasa la linea; Libre borra todo. Un toque quita la parte entera. Con Deshacer.

## Bordes suaves
El color que se mete debajo de la linea negra se apaga hacia el centro de la linea (80 %, 50 %,
25 %). Antes era parejo y la linea se veia en escalera y de color.

## Toques (rubor, sombra, luz)
- Al soltar el dedo el fundido se calcula en otro hilo: ya no se congela con pinceles grandes.
- Los toques no quedan encima de la linea negra (tampoco al usar Fundir).
- Menos cosas: se quito la barra de "Fundir cada trazo" (va sola); queda Fuerza.

## Mantener presionado = mini tutorial
Cada herramienta de Colorear, los botones Protegido/Libre y los botones de Toques muestran una
ventana con un dibujito animado, "Para que" y "Como". El "?" del paso 1 muestra la de la
herramienta puesta.
