# Paint Zeta v8.98 — Arreglo del cierre al pasar a "2 Acabado"

Incluye todo lo de la 8.97.

## Colorear > 2 Acabado
- Causa: al abrir el paso 2, la barra de "Fuerza" se ponia dos veces en la tarjeta. Android no
  deja poner la misma pieza dos veces y la app se cerraba.
- Ahora: la barra de "Fuerza" se pone una sola vez. El paso 2 abre normal.
- Se reviso el resto del codigo buscando el mismo error: no hay otro igual.

## Firma
- Sigue con la misma firma fija: se instala encima de la 8.97 sin desinstalar.

## No probado
- No probado en un telefono.

## Como probarlo
1. Abre una imagen, entra a Colorear y pinta algo en "1 Color".
2. Toca "2 Acabado": debe abrir sin cerrarse.
3. Mueve la barra de Fuerza, toca "Mas" y "Menos", y luego ✓ para pasar a "3 Final".
