# Paint Zeta v9.03 — Colorear, Parte 4 de 4: herramientas nuevas

Incluye todo lo de la 9.02. Con esta parte se termina el plan de Colorear (4 partes).

## Pintar arrastrando el dedo (nuevo, dentro de Pintar)
- Antes: en partes con textura (chaleco tejido, mano con sombras) cada toque pintaba un pedacito
  y arrastrar el dedo no hacia nada.
- Ahora: con Pintar puedes ARRASTRAR el dedo: se llenan todas las partes por donde pasa (hasta
  40 de una vez), con una sola vuelta de Deshacer. Mientras arrastras se ve el camino.
- Probado en PC con tu chico: un trazo por el chaleco junta 10 pedacitos; uno por la mano, 4
  (casi toda la mano). El color va por donde pasa el dedo.
- Con dos dedos sigue siendo mover y hacer zoom.

## Cambiar (nuevo)
- Elige el color nuevo abajo y toca una parte pintada: TODAS las partes de ese mismo color
  cambian al color nuevo (por ejemplo, el pelo en todas las vinetas de una pagina).

## Retocar (nuevo)
- Un pincel (usa el tamano del pincel de abajo) para los pedacitos que el balde no alcanzo.
  Al soltar, lo pintado se SUMA a la parte donde empezaste, y despues el Acabado lo trata igual.
- No tapa partes de otro color ni lo protegido ni las lineas de Separar.
- Si empiezas donde no hay color, se hace una parte nueva con el color elegido.

## Fila de herramientas
- Ahora son 8: Pintar, Rayar, Borrar, Tomar, Cambiar, Retocar, Separar, Huecos.
  Si no caben, la fila se desliza; la elegida queda a la vista.

## Del plan, ya estaba en la app (no se repitio)
- "Manchitas + completar" = Rayar (rayas cada parte y se pintan solas).
- "Tenir la linea negra" = el Acabado ya pone las lineas de color (marron en la piel...).

## Firma
- Misma firma fija: se instala encima de la 9.02 sin desinstalar.

## Revision
- Compilador de Java sobre todo el codigo: solo faltan las piezas de Android. No probado en telefono.

## Como probarlo
1. Pintar: arrastra el dedo por el chaleco o la mano: se llenan todos los pedacitos. Deshacer los
   quita juntos.
2. Pinta el pelo de cafe en varias partes. Elige otro color, toca Cambiar y toca el pelo: cambia todo.
3. Retocar: sube un poco el tamano del pincel y pinta un hueco que quedo gris: se suma a esa parte.
   Pasa por encima de otra parte de otro color: no la tapa.
