# Paint Zeta v9.04 — Arreglos pedidos al probar la 9.03

Incluye todo lo de la 9.03.

## Ventanas de opciones y guia: centradas y un poco transparentes
- Causa: desde la 8.96 todas las ventanas de opciones (guia rapida, menu de ajustes ⋮, avisos,
  ventanas de capas...) salian ABAJO y con fondo oscuro sin transparencia. Ademas la guia y otras
  6 ventanas tenian su propio fondo negro encima.
- Ahora: salen en el CENTRO, con esquinas redondeadas y fondo oscuro un poco transparente (se ve
  el dibujo detras). Se quito el fondo negro propio de esas 7 ventanas.

## Panel de herramientas: transparente
- Antes: casi opaco (el mismo fondo de las barras).
- Ahora: semitransparente, igual que el panel de Capas.

## Colorear > Borrar: se puede arrastrar
- Antes: solo funcionaba con toques (quitaba la parte entera); arrastrar no hacia nada.
- Ahora: es como un borrador normal: ARRASTRA el dedo y se quita el color por donde pasa, con el
  tamano del pincel de abajo (mientras pasas se ve en rojo). Quita el color de cualquier parte
  que toques, sin ir a la herramienta Goma. Un toque sin arrastrar sigue quitando la parte entera.
- Deshacer lo devuelve.

## Mis obras: se quito el boton de la izquierda
- Ese boton NO abria imagenes para pintar: era "Comprimir fotos" (de la 8.92: achica fotos del
  telefono para WhatsApp, Instagram...). Empezaba abriendo la galeria y por eso parecia lo mismo.
- Se escondio el boton; su funcion sigue dentro de la app por si se quiere volver a poner (por
  ejemplo en el menu ⋮).

## Firma
- Misma firma fija: se instala encima de la 9.03 sin desinstalar.

## Revision
- Compilador de Java sobre todo el codigo: solo faltan las piezas de Android. No probado en telefono.

## Como probarlo
1. Abre la guia rapida y el menu ⋮: deben salir en el centro y un poco transparentes.
2. Abre el panel de herramientas: se debe ver el dibujo detras.
3. Colorear > Borrar: arrastra el dedo por donde el color se paso: se quita solo por ahi.
4. Mis obras: arriba quedan solo el boton de informacion y el azul de abrir imagen.
