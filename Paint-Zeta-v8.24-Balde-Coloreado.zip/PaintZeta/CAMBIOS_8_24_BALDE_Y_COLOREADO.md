# Paint Zeta v8.24 — Balde, coloreado, Brocha, Líneas y capas

Versión 8.24 (versionCode 62). Sin IA. Todo lo medido sale de pruebas que se pueden repetir con `sh tests/run_jvm_tests.sh full`. Resultados completos: `docs/RESULTADOS_PRUEBAS_8_24.txt`. Comparación visual: `docs/comparacion_v8_23_vs_v8_24.png`.

Cómo se probó:
- Con el `CanvasView` real de la app dentro de un Android simulado, no en un teléfono.
- Con imágenes hechas para parecerse a tus capturas: trazos gruesos tipo kanji, una escena con línea diagonal y una imagen de anime ya coloreada con sombra. Todas también comprimidas en JPEG, como las imágenes descargadas.
- Los tiempos son de la CPU del servidor de pruebas. Un teléfono económico puede ser de 3 a 8 veces más lento.

## 1. Diagnóstico del balde (causas encontradas en el código)

- **ERROR CONFIRMADO — el color se escapa a zonas parecidas.** `FloodFill` avanzaba por "tolerancia + suavidad" (32 + 24 = 56), no solo por la tolerancia. En la prueba, una zona rosada clara junto a una blanca (31 niveles de diferencia) pintó también la zona blanca.
- **ERROR CONFIRMADO — rincones y motas blancas junto a los contornos (tu captura 1).**
  - Para cerrar cortes, engordaba TODAS las líneas 4 px (`closeGapsBarrier` solo dilataba) y después crecía de vuelta en forma de rombo y solo en parte.
  - En los rincones agudos, y a lo largo de las líneas diagonales, quedaban píxeles blancos.
  - Medido: 20 px en la imagen limpia y 87 px con JPEG; v8.24: 0 y 0.
- **ERROR CONFIRMADO — zonas pintadas a medias detrás de un corte.** El color entraba unos píxeles por el corte y se detenía: ni cerrado ni abierto.
- **ERROR CONFIRMADO — bordes irregulares y manchas junto a la línea (tu captura 2).**
  - Cerca de la línea multiplicaba el color por el brillo de cada píxel y copiaba el ruido del JPEG, que en las diagonales forma escalones.
  - El efecto se ve claramente al ampliar.
- **ERROR CONFIRMADO — restos del color anterior.** Al rellenar dos veces la misma zona quedaban píxeles del primer color: 3 en v8.23, 0 en v8.24.
- **ERROR CONFIRMADO — modificaba el original sin preguntar.** De fábrica el balde pintaba directo sobre tu imagen: un toque cambió 80 115 píxeles del original. En v8.24, 0: va a una capa "Color" aparte.
- **ERROR CONFIRMADO — tres caminos distintos.** Misma capa, otra capa y capa Color pasaban por pasos diferentes ("crecer hasta la línea", "banda oscura" y "dilatación"), unos encima de otros. Por eso los resultados no eran consistentes.
- **ERROR CONFIRMADO — el detector de líneas confundía rellenos anteriores con líneas.** Un color medio pintado junto al blanco se tomaba como "línea fina oscura" y el segundo relleno lo esquivaba.
- **HIPÓTESIS sin poder confirmar:** las líneas finas oscuras que unen trazos en tu captura 1. No las pude reproducir. Pueden ser parte de tu imagen original. Si siguen apareciendo en v8.24, mándame la imagen original.

## 2. Motor nuevo del balde (`core/BucketFill.java`)

Un solo motor para todo: misma capa, capa aparte o capa Color.
- **Zona:** relleno por líneas con la tolerancia **estricta** respecto del color tocado. La tolerancia inicial es ahora 20, porque ya no se le suma la suavidad.
- **Cortes:**
  - Se mide qué tan ancha es cada parte de la zona.
  - Lo ancho del lado tocado se pinta entero. Los rincones también, porque solo los alcanza ese lado.
  - Si una parte grande solo se une por un paso angosto, se corta en el punto **más angosto** (el corte real). Lo de atrás no se pinta nada: queda limpio, no a medias. Tocando adentro se pinta aparte.
  - Los pedazos chicos (menos de 150 px), como el ruido del JPEG, se quedan con la zona.
  - Si tocas una zona angosta, el cierre se ajusta solo.
  - Medido: el nivel N cierra cortes de hasta unos 2N px. Se ajusta en el cuadro de Tolerancia.
- **Motas:** los puntitos encerrados sin línea (ruido) se rellenan. Los puntos oscuros del dibujo se respetan.
- **Hasta la línea:**
  - Cada píxel del borde se analiza como mezcla del color de la zona y del "color de enfrente": la línea, u otro color en un borde de sombra.
  - El resultado es mezcla(color de enfrente, color elegido), así que la línea conserva su forma y su antialias.
  - No quedan franja blanca, dientes, manchas de JPEG ni restos del color anterior.
- **Plano o con sombras:**
  - De fábrica es plano: color exacto y parejo.
  - "Conservar sombras" (casilla en el cuadro de Tolerancia) busca la zona por tono y recolorea la sombra más oscura.
  - Medido: v8.23 no recoloreaba la sombra; v8.24 recolorea 4370 de 4370 píxeles (4362 con JPEG) y la sombra sigue más oscura.
- **Capas de referencia (nuevo):** en Opciones de la capa, "Referencia del balde". El balde toma los contornos solo de esas capas. Medido: con las líneas marcadas, el color pasó por encima de una mancha de color de otra capa (9910 de 10 000 px); sin esa opción se detenía (v8.23: 1585).
- **Capa aparte (de fábrica):**
  - El primer relleno crea una capa "Color" encima y tu dibujo no se toca.
  - El mismo botón de antes (círculo con check en la barra del balde) lo apaga para pintar directo en la capa elegida.
  - Las capas "Color" en Multiplicar de v8.23 se siguen usando igual.
- **Transparencia:** lo transparente cuenta como papel. Con "Bloquear alfa" no se pinta fuera de lo dibujado (medido: 0 píxeles).
- **Lo que se ve = lo que se exporta:** diferencia 0 niveles.
- **Deshacer y Rehacer:** exactos.
- **Tiempo en 2000×2000 (servidor):**
  - Detectar líneas: 82–95 ms, una vez por cada cambio de la imagen.
  - Un toque: de 5 a 269 ms según el tamaño de la zona.
  - Se calcula fuera de la interfaz.

## 3. Brocha

- **ERROR CONFIRMADO — "No pasar la línea negra" tapaba la línea.** Metía el color 2 px dentro de la línea, con opacidad completa. Medido: 370 píxeles de línea tapados; v8.24: 0, sin cruzar y sin huecos blancos.
- Ahora el borde junto a la línea se mezcla con la línea, igual que el balde. Funciona en la misma capa y en una capa nueva.
- Con la protección apagada, el pincel libre funciona igual que antes.
- Ícono propio para "No pasar la línea". Antes usaba el mismo que "Hasta la línea" del balde.
- Siguen pasando las pruebas de v8.23: 1 a 100 px, trazos lentos y rápidos, opacidad, zoom de 100 a 400 % y capas transparentes.

## 4. "Líneas"

- **Para qué sirve:** separar las líneas del dibujo en una capa transparente, para pintar debajo sin taparlas.
- **ERROR CONFIRMADO — duplicado.** El menú tenía "Preparar para colorear", que hacía casi lo mismo. Ahora es una sola herramienta: Capas → Más → Líneas.
- **ERROR CONFIRMADO — resultado incorrecto en imágenes a color.** Usaba solo el brillo: el pelo oscuro, la ropa y las sombras salían como "línea gris". Medido en la imagen de anime: pelo 1244 px y sombra 5055 px tomados como línea; v8.24: 0 y 0, con el contorno completo (472 de 472).
- La imagen a color se detecta sola y se avisa. Ahí se separan solo los trazos finos y oscuros (filtro morfológico "top-hat"), no las zonas oscuras.
- Muestra la vista previa a tamaño real antes de aplicar, con 2 ajustes.
- En blanco y negro, sobre papel blanco se ve igual que el original. Solo los grises más pálidos que el ajuste "Blanco" pasan a transparente.
- No cambia el original. Opcionalmente crea también la capa "Color" debajo. Deshacer quita todo de una vez.
- **Límite:** en imágenes a color, una línea pegada a una zona oscura grande (por ejemplo el borde del pelo negro) no se separa, porque no se distingue de esa zona.

## 5. "De lo azul"

- **Qué hacía:** abría "Crear parte desde la selección" (`partFromSelectionDialog`). Lo mismo que "Copiar a capa" del menú de selección y el cuadro que aparece al terminar el Lazo.
- Era un botón duplicado y se quitó del panel.
- La acción queda en Capas → Más → "Crear capa desde la selección", que solo aparece si hay algo seleccionado.
- La función interna se conserva, porque la usan el Lazo y el menú de selección.

## 6. Panel de capas

- **Abajo quedan 5 botones** (antes 8): Nueva, Duplicar, Combinar, Eliminar y Más. Los textos ya no se cortan.
- **"Más":** Crear capa desde la selección (solo con selección), Líneas, Imagen de referencia de color, Limpiar la capa y Opciones de la capa.
- **Opciones de la capa:** modo de mezcla, recorte, bloquear alfa, **Referencia del balde** (nuevo), nombre y exportar.
- La opacidad sigue en su barra. La capa elegida se resalta y el ojo la oculta.
- La fila de la capa muestra "ref. balde" cuando corresponde.
- Probado: crear, seleccionar, ocultar, duplicar, mover, eliminar, Deshacer, Rehacer, guardar y volver a abrir (también la marca de referencia), abrir obras antiguas y exportar PNG.

## 7. Goma y recorte

- **ERROR CONFIRMADO (lo introduje yo en v8.23) — residuo al mover una parte cortada.**
  - Para que la parte encajara sin línea, la capa de abajo conservaba entero el borde suave.
  - Al mover la parte en Alight Motion quedaba su contorno: 216 píxeles con alfa completo.
  - v8.24: la parte se queda con el borde donde la selección es mayoría y la capa de abajo queda vacía ahí. Resultado: 0 píxeles de residuo, encaje exacto en reposo (también semitransparente) y la parte sigue con borde suave.
- Goma, Borrar fondo y PNG transparente: siguen pasando las pruebas de v8.23 (filo limpio, cabello fino, solo cambia el alfa).

## 8. Gestos

- La navegación con dos dedos de v8.23 se volvió a probar en las 10 herramientas: sin trazos, puntos ni selecciones accidentales, sin saltos al levantar un dedo, y cambios de herramienta con el dedo abajo sin restos.
- Las ventanas de ajustes son cuadros modales: mientras están abiertas, los toques no llegan al lienzo.

## 9. Lo que no cambió

- Especial: motor idéntico byte a byte a v8.22.
- Malla, Transformar y Puntos de anclaje: 61 métodos idénticos y su manejo táctil también.
- Varita, Lazo, Curva, Polilínea, Borrar fondo, Difuminar y Borrosidad pasan sus pruebas.

## Compilación

- Todo el código Java compila **sin errores contra el android.jar oficial de Android 34** (431 clases), también con la biblioteca Java de Android. Script: `tests/sdkcheck/compile_with_android_jar.sh`.
- **No se pudo generar el APK.** Faltan las herramientas de Google (aapt2, d8) y la biblioteca AndroidX, que solo se descargan de los servidores de Google, bloqueados en este entorno. Para compilar se usaron sustitutos mínimos de AndroidX que no van en la app.

## Archivos

- **Nuevos:**
  - `core/BucketFill.java`
  - `res/drawable/ic_line_guard.xml`
  - `tests/BucketTest.java`
  - `docs/RESULTADOS_PRUEBAS_8_24.txt`
  - `docs/comparacion_v8_23_vs_v8_24.png`
- **Modificados:**
  - `view/CanvasView.java`
  - `MainActivity.java`
  - `core/LineArt.java`
  - `core/LineFill.java`
  - `core/Layer.java`
  - `core/ProjectIO.java` (nuevo dato "referencia"; las versiones viejas lo ignoran)
  - `app/build.gradle`
  - `tests/ToolsSimTest.java`
  - `tests/run_jvm_tests.sh`
  - `tests/test_regressions.py`
  - `tests/androidsim` (PNG real para probar guardar y exportar)
- **Quitados:** el diálogo "Preparar para colorear" (unido a Líneas), el botón "De lo azul" del panel y el ícono que ya no se usaba (`ic_lines_layer.xml`).

## Pendiente

- Compilar en Android Studio y probar en tu teléfono con tus imágenes reales, sobre todo las de tus capturas.
- Una zona cerrada por un corte pequeño queda sin pintar a propósito. Tócala adentro, o baja "Cerrar cortes de la línea".
- La tolerancia inicial bajó a 20. Si en imágenes muy comprimidas quedan puntitos, súbela un poco.
- Tiempos en teléfono no medidos: el balde en una página completa puede tardar cerca de 1 segundo en un teléfono económico, sin bloquear la pantalla.
