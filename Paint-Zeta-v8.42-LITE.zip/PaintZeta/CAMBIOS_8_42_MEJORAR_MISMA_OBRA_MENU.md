# Paint Zeta v8.42 — Mejorar en la misma obra, sin Vectorizar y menú con íconos (sobre la v8.41)

Arreglos pedidos después de probar la v8.41 en tu teléfono.

## Cómo se usa

**Mejorar imagen**

1. Menú ⋮ → sección **IMAGEN** → **Mejorar imagen** (ícono de destellos).
2. Elige el **tamaño**:
   - **Igual**: limpia el JPEG y afina las líneas sin agrandar;
   - **x2** o **x4**: toda la obra crece.
3. Marca las **capas que mejora la IA**. Por defecto viene marcada la capa elegida.
   - Las capas sin marcar (por ejemplo, tu capa de color) crecen normal y suave, así siguen calzando encima.
4. **Mejorar**. Sale la barra con el tiempo que falta y **Cancelar**.
5. Todo queda **en la misma obra**. **Deshacer** la devuelve como era, con su tamaño de antes.

**Menú ⋮ nuevo**

- Ahora es como el panel de herramientas: secciones **IMAGEN**, **PINTAR Y PERSONAJES**, **VISTA**, **AYUDA Y AJUSTES** y **GUARDAR**.
- Cada opción tiene su ícono con el nombre abajo.
- Las opciones de SI/NO se ven **encendidas en azul** cuando están en SI.
- **Mantén pulsada** una opción y abajo aparece qué hace.

## YA EXISTÍA (se reutilizó, no se duplicó)

- La IA de Mejorar (modo Rápido de la v8.41) y su trabajo por pedazos.
- Deshacer, capas, empaquetado de capas (para gastar poca memoria) y el guardado.
- Todas las opciones del menú ⋮: hacen lo mismo que antes, solo cambió cómo se ven.

## MODIFICADO

- **Mejorar imagen**:
  - **un solo modo**: el Rápido que te gustó;
  - ventana simple: tamaño y capas;
  - **ya no abre otra obra**: trabaja en la misma, con Deshacer y Rehacer;
  - nuevo tamaño **Igual** (solo limpiar);
  - aviso **antes** de empezar si el resultado no entra en la memoria del teléfono.
- **Menú ⋮**: grilla con íconos en vez de lista de textos.
- **Licencias**: solo queda el modelo Rápido de Real-ESRGAN (BSD-3).
- **Versión**: 8.42 (código 80).

## NUEVO

- **Cambio de tamaño de toda la obra con Deshacer**. Se escalan juntas:
  - todas las capas;
  - la selección azul;
  - las zonas "No colorear";
  - las zonas de Color por zonas.
  Deshacer devuelve todo exacto. La copia para Deshacer es la obra chica de antes, así que gasta poca memoria.
- **Agrandar sin IA** para las capas no marcadas, sin bordes oscuros en lo semitransparente.
- **5 íconos nuevos**: Mejorar, Guía, Herramientas, Rendimiento y Zoom suave. También uno para "Vista normal".

## QUITADO

- **Máxima calidad**: tardaba 11 a 24 minutos en tu teléfono. El APK pesa unos **9 MB menos**.
- **Vectorizar**: en manga y a color engordaba las líneas y dejaba parches. Para tener la imagen nítida y recortar fácil, usa **Mejorar imagen**.
- **"Colores lisos"** (la opción A que te propuse): **lo probé y no lo agregué**.
  - Mejorar ya deja los colores limpios.
  - El filtro extra apenas cambiaba algo y a veces aclaraba las líneas finas del manga.
  - Así la ventana queda más simple.
- La copia del modelo de Máxima calidad que guardó la v8.41 en el teléfono se borra sola (libera 9 MB).

## PENDIENTE

- **Probar en tu teléfono**: la ventana de Mejorar, el menú nuevo, y Deshacer/Rehacer después de agrandar. Aquí no hay emulador.
- **Tiempo real del modo Rápido en tu teléfono**: depende del teléfono. Dime cuánto tarda con tus imágenes.
- **Deshacer de un agrandado es grande**: si después haces muchos cambios, el historial puede soltar ese paso para no quedarse sin memoria (igual que con otros cambios grandes).

## Registro de pruebas

### Pruebas ejecutadas de verdad en PC

Usan el código real de la app (Java) y el modelo ONNX real.

1. **Mejorar en tamaño Igual, x2 y x4** con un manga y una imagen a color bajados de calidad (JPEG fuerte, como imágenes de internet):
   - las tres salen bien;
   - 200 × 200 px tardan menos de 1 s en el PC.
   - Comparación en prueba_mejorar_x4.png.
2. **Toda la obra crece y Deshacer** (con Project, Layer y UndoManager reales; 13 de 13 OK):
   - una obra de 300×200 con capa imagen, capa de color empacada y capa vacía pasa a 1200×800;
   - la capa de color crece sin halo oscuro y queda empacada;
   - la capa vacía sigue sin gastar memoria;
   - la selección y la zona de Color por zonas se escalan bien;
   - **Deshacer**: vuelve a 300×200 con los píxeles idénticos, las zonas y la selección como antes, y la capa de color empacada otra vez;
   - **Rehacer**: otra vez 1200×800, igual;
   - Deshacer 2 veces también deshace el pincel que se hizo antes.
3. **"Colores lisos"**: probado y descartado (ver QUITADO).
4. **Íconos nuevos**: dibujados y revisados en imagen. Vista previa del menú en vista_previa_menu.png. Es un dibujo del diseño, no una captura del teléfono.
5. **Compilación**: todo el código compila contra el Android real (android.jar 34).

### Solo compilado, pendiente en tu teléfono

- La ventana de Mejorar con la lista de capas.
- La pantalla después de agrandar (encuadre automático).
- El menú ⋮ nuevo: tamaño en tu pantalla, scroll y el texto de abajo al mantener pulsado.
- Tiempos y memoria reales.
