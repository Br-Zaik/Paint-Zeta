# Paint Zeta v8.43 — Colorear fácil, capas más simples, borrar varias obras (sobre la v8.42)

Arreglos de tus capturas después de probar la v8.42.

## Cómo se usa

**Colorear fácil (3 pasos)**

1. Menú ⋮ → **PINTAR Y PERSONAJES** → **Colorear fácil**.
   - Si es la primera vez, prepara las capas sola (Tinta B/N bloqueada + Color base). Si hay varias capas con dibujo, te pregunta cuál es el manga.
2. Arriba sale una tarjeta con el paso y botones grandes:
   - **Paso 1 · Colores base**: toca un color de la fila (o "Más colores" o "De la referencia"). Toca una parte del dibujo (pelo, piel, ropa) y luego ✓ abajo. Repite con cada parte. **Siguiente**.
   - **Paso 2 · Sombras**: **un toque** y TODAS las partes reciben sombra y luz sacadas de los grises de tu B/N. Elige **Suave**, **Anime 2 tonos**, **Pintado** o **Sin sombra**. Puedes probar los cuatro. De entrada pone Suave.
   - **Paso 3 · Luz y fondo**: opcional. **Brillo y fondo** (brillo en el borde y fondo degradado) o **Cambiar una zona**. **Terminar**.
3. **Atrás** vuelve al paso anterior (por ejemplo, a pintar otra parte). **Salir** cierra la tarjeta. Deshacer funciona en todo.

**Capa nueva**

- **Nueva** crea al toque una capa transparente, sin preguntar.
- **Toca las rayitas (≡) de una capa** y salen sus opciones con íconos:
  - **Flecha** (pintar solo dentro de la capa de abajo);
  - **Colorear B/N** (Multiplicar: el color no tapa las líneas negras);
  - **Modo** y **Más opciones**.
- Mantener y arrastrar las rayitas sigue moviendo la capa.
- **Más → Tipos de capa**: crear una capa de un tipo (Con flecha, Colorear B/N, Hoja blanca, Hoja de color).

**Borrar varias obras**

- En **Mis obras**, mantén pulsada una obra → **Seleccionar varias**.
- Toca las que quieras (se marcan en azul con ✓). Abajo: **Todas**, **Eliminar** o **Cancelar**.

**Antes / Después al mejorar**

- Al terminar **Mejorar imagen** se abre una pantalla con **Antes** a la izquierda y **Después** a la derecha.
- Mueve la línea del medio con el dedo. Con dos dedos haces zoom. **Listo** para cerrar.

## YA EXISTÍA (se reutilizó, no se duplicó)

- **Color por zonas** (v8.40): el balde por zonas, la vista previa con ✓, el trío y los acabados. Colorear fácil solo lo ordena en pasos.
- **Colorear manga**: prepara las capas sin cambiar el original.
- **Luces y fondo** y **Zonas pintadas**.
- El selector de color y la ventana de referencia.
- Capas: flecha (recorte), modos, opciones, hojas de color.

## MODIFICADO

- **Menú ⋮**: arreglado. En la v8.42 las filas con menos de 4 opciones medían 1 píxel y no se veían. Por eso aparecían pocas opciones (faltaban Girar imagen, Ampliar lienzo, Referencia, Dureza, Borrar fondo +, Cursor lupa, Zoom suave, Guardar...). Ahora se ven todas.
- **Abrir una obra**: sale "Abriendo tu obra..." con una ruedita, en vez de la pantalla negra.
- **Nueva** (capas): capa transparente directa.
- **Mis obras**: opción "Seleccionar varias".
- **Mejorar imagen**: al final muestra Antes / Después.
- **Versión**: 8.43 (código 81).

## NUEVO

- **Colorear fácil**: tarjeta de 3 pasos.
- **Sombras a todas las zonas de una vez** (paso 2): se repinta todo con Deshacer. Lo que pintes a mano fuera de las zonas no se toca.
- **Menú rápido de la capa** (toque en las rayitas).
- **Antes / Después** con línea deslizable y zoom.
- **Seleccionar y borrar varias obras.**

## PENDIENTE

- **Probar en tu teléfono**: la tarjeta de Colorear fácil, el menú de las rayitas, Seleccionar varias, la pantalla Antes/Después y el aviso de carga. Aquí no hay emulador.
- **Partes con línea abierta** (pelo de atrás, mangas que se juntan con el fondo): el balde no las toma con un toque. Corrige con Lazo y el botón de selección, o tocando cada pedacito. En las imágenes de ejemplo quedaron grises el pelo de atrás y la manga derecha por eso.
- **Mechones negros del B/N**: quedan negros (es tinta del dibujo). Para pintarlos usa Pincel en una capa con Colorear B/N.
- **Lo que pintes a mano dentro de una zona** se pisa al cambiar las sombras en el paso 2. Pinta tus retoques en otra capa.

## Registro de pruebas

### Pruebas ejecutadas de verdad en PC

Con el código real de la app (Java) y tu B/N de light novel.

1. **Los 3 pasos**:
   - colores base con Multiplicar;
   - sombras Suave, Anime 2 tonos y Pintado: todas las zonas en 74–90 ms en el PC;
   - brillo de borde y fondo.
   - Imágenes: colorear_facil_pasos.png y colorear_facil_zoom.png.
2. **Sombras a todas las zonas sin repintar de cero**: 0 píxeles distintos a pintar todo de nuevo, y un retoque fuera de las zonas se conservó.
3. **Compilación**: todo el código compila contra el Android real (android.jar 34).

### Solo compilado, pendiente en tu teléfono

- Toda la interfaz nueva: la tarjeta, el menú de rayitas, Seleccionar varias, Antes/Después y el aviso de carga.
- Que el menú ⋮ ya muestre todas las filas.
