# Paint Zeta v8.30 — Borrar fondo sin cruzar la línea

Versión 8.30 (versionCode 68). Base: v8.29.

- No se quitó ninguna función útil. La Goma de la barra de Borrar fondo se quitó porque estaba repetida: queda la Goma de la caja de herramientas.
- No se tocó GitHub ni el flujo de GitHub Actions.
- Pruebas en un servidor con Android simulado. **No es un teléfono.**

## 1. Qué cambia para ti

- **Barra de Borrar fondo (6 iconos):** Toque (balde), Pincel, Restaurar, Escoba, Ojo y Ajustes.
  - Ya no está la Goma aquí. En la captura 1 de v8.29 la Goma de esta barra estaba elegida: esa Goma borra todo lo que toca, por eso cruzó la línea. Para borrar todo sin mirar el color, usa la Goma normal de la caja.
  - Si tenías elegida la Goma de esta barra, al instalar pasa sola al Pincel.
- **Suavidad del borde:** en Borrar fondo, la segunda barra de abajo (la que decía 100) ahora es la Suavidad, de 0 a 4 px. Muestra ◐ y el número.
  - 0 = borde nítido (como antes).
  - Al subirla, el borde del recorte se vuelve transparente poco a poco hacia adentro, también en lo que ya estaba recortado. Se deshace con un toque.
  - Repetirla no come más el borde.
  - En Borrar fondo, el pincel ya no usa la opacidad de la Brocha. Una opacidad baja dejaba fondo a medio borrar.
- **El toque ya no se mete al personaje:**
  - Mira también el tono del color, no solo el brillo. La sombra verde oscura del duende ya no pasa por "parecida" a la cueva azulada.
  - Con un fondo casi negro, protege la línea del dibujo (hasta 4 px junto a lo más claro).
  - En el papel blanco del manga, no entra por las puntas abiertas de los mechones: el pelo blanco se conserva.
- **Escoba:** en imágenes a color quita los puntitos oscuros sueltos pegados a la línea (captura 6). En el manga (papel claro) los conserva, porque pueden ser trama.

## 2. Qué estaba mal y qué se hizo

**CONFIRMADO: el toque en un fondo oscuro se comía la boca, el cuello y el hacha del duende** (capturas 5 y 7, y la prueba del duende entero).

- Causa:
  - El color se comparaba solo canal por canal. La cueva (40,54,57), la sombra verde del duende (41,49,36), el hacha y la línea negra quedaban todos dentro de la tolerancia 46.
  - Por la boca abierta, el toque pasaba a las sombras del personaje y seguía por ellas.
- Ahora:
  - El tono cuenta doble. La cueva contra la sombra del duende da 48 (antes 23), así que queda fuera de 46.
  - Dos tonos de la misma cueva siguen dando 4.
  - Con fondo muy oscuro, la franja de hasta 4 px junto a algo más claro es línea: no se borra.

**CONFIRMADO: el toque en el papel del manga se comía el brillo blanco del pelo.**

- Causa: el blanco del pelo es igual al papel y se une a él por las puntas abiertas de los mechones.
- Ahora:
  - Los huecos de menos de ~10 px entre líneas se cierran, solo con fondo de papel claro.
  - Lo ancho que queda detrás de un paso angosto (el brillo del pelo) se conserva.
  - Los rincones chicos o finos (la cuña entre dos mechones que se abren hacia afuera) sí se borran, como antes.

**CONFIRMADO: la Escoba dejaba puntitos** (captura 6: "quitó 55" pero quedaban).

- Causa: un puntito de 2×2 px contaba como "trazo fino" (punta de mechón) y se conservaba.
- Ahora:
  - "Fino" exige un trazo alargado de 6 px o más.
  - A color, un puntito de tinta de 16 px o menos se quita, aunque esté pegado a la línea.
  - A color también se quita un trazo fino lejos del personaje.
  - Sobre papel claro se conserva (trama).

**Goma repetida (captura 4):** se quitó de la barra de Borrar fondo.

## 3. Resultados: quitar el fondo del personaje ENTERO

Plan de la prueba, igual en las dos versiones:

1. 30 toques, siempre en el fondo más lejos del personaje.
2. Pincel tamaño 20 dando la vuelta a todo el contorno, a 0-12 px de la línea, a veces pisándola.
3. Escoba.

Para medir se usa un recorte de referencia hecho fuera de la app solo para esta prueba (la app no usa IA).

| Duende (imagen 6, a color) | v8.29 | v8.30 |
|---|---|---|
| Personaje perdido | **7,60 %** (57 352 px) | **0,68 %** (5 108 px) |
| Perdido lejos del borde (cruzó la línea) | **6,65 %** (48 362 px) | **0,27 %** (1 957 px) |
| Fondo que queda | 2,92 % | 7,45 % (más toques lo quitan) |
| Puntitos sueltos | 68 (885 px) | 9 (29 px) |
| Un toque en la esquina negra: personaje perdido lejos del borde | 27 704 px | 399 px |

| Manga (imagen 7) | v8.29 | v8.30 |
|---|---|---|
| Personaje perdido | **1,81 %** (19 696 px, el pelo blanco) | **0,00 %** (46 px) |
| Perdido lejos del borde | 1,63 % (17 320 px) | 0,00 % (0 px) |
| Fondo que queda | 0,00 % | 0,00 % |
| Puntitos sueltos | 6 | 1 (2 px) |
| Un toque en el papel: pelo perdido lejos del borde | 1 516 px | 0 px |

Otras pruebas:

- **Suavidad:**
  - Con 0, el borde queda nítido (255).
  - Con 2 px, el alfa sube en rampa hacia adentro: 85, 170, 255.
  - Repetir no come más (0 px). Subir a 4 px cambia 796 px y Deshacer deja 0 diferencias.
  - El centro del personaje no se toca.
- **Escoba:**
  - A color quedan 0 de 10 puntitos (v8.29: 10 de 10).
  - En manga se conservan los 10 de trama y la punta fina del mechón.
- **Toda la batería anterior pasa:** v8.22 a v8.29, incluidas A-R (v8.28) y U-Z (v8.29).
- **Compilación sin SDK:** 634 clases sin errores.

Imágenes ANTES/AHORA en `docs/qa830/`:

- duende completo;
- cara, boca y hacha;
- línea de la cabeza;
- manga completo;
- pelo blanco;
- mapas de errores (rojo = personaje perdido, azul = fondo que queda).

Salida completa en `docs/RESULTADOS_PRUEBAS_8_30.txt`.

## 4. Límites (dicho claro)

- **Más toques en fondos con muchos tonos:** el toque es más estricto con el tono, así que en la cueva quedan manchas de otro tono (rocas azuladas). Se quitan tocándolas o con el Pincel. Es a propósito: es mejor dejar fondo que comerse al personaje.
- **Fondo tan negro como la línea:** la línea gruesa se conserva, pero en la nariz y la boca del duende todavía se pierden ~400 px con un toque en la esquina negra. Restaurar los devuelve.
- **Pincel junto a objetos del mismo tono que el fondo:** la bola de metal gris azulada detrás de la oreja se parece a la luz de la cueva, y el pincel pasado encima se come una parte. Usa Restaurar ahí.
- **Entre líneas muy juntas en el manga**, el toque deja el papel de huecos angostos y largos. Se borra tocando justo ahí o con el Pincel.
- **No probado en un teléfono real.** En la app, Menú > «Medir rendimiento» da los tiempos de tu teléfono.

## 5. Para probar en el teléfono

1. Sube **Paint-Zeta-v8.30-LITE.zip** a GitHub y descarga el APK.
2. Abre el duende y elige Borrar fondo. Toca la cueva cerca de la boca y de la nariz: la boca, los dientes, el cuello y el hacha deben quedar.
3. Toca otra vez las manchas que queden. Pasa el Pincel junto al contorno.
4. Toca la Escoba: no deben quedar puntitos pegados a la línea.
5. Sube la segunda barra (◐) a 2: el borde se suaviza. Deshacer lo vuelve atrás.
6. Abre el manga y toca el papel: el pelo blanco debe quedar.
