#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
DIR="$(mktemp -d)"
trap 'rm -rf "$DIR"' EXIT
javac -d "$DIR" \
    "$ROOT/app/src/main/java/com/pacco/animecut/core/ColorDist.java" \
    "$ROOT/app/src/main/java/com/pacco/animecut/core/BackgroundEraseAlpha.java" \
    "$ROOT/app/src/main/java/com/pacco/animecut/core/LiquifyTopologyGuard.java" \
    "$ROOT/app/src/main/java/com/pacco/animecut/core/InverseLiquifyEngine.java" \
    "$ROOT/app/src/main/java/com/pacco/animecut/core/AlphaColors.java" \
    "$ROOT/tests/BackgroundEraseAlphaTest.java" \
    "$ROOT/tests/LiquifyTopologyTest.java" \
    "$ROOT/tests/InverseLiquifyEngineTest.java" \
    "$ROOT/tests/AlphaColorsTest.java"
java -cp "$DIR" BackgroundEraseAlphaTest
java -cp "$DIR" LiquifyTopologyTest
java -cp "$DIR" InverseLiquifyEngineTest
java -cp "$DIR" AlphaColorsTest
python3 -m unittest discover -s "$ROOT/tests" -p test_regressions.py -q
