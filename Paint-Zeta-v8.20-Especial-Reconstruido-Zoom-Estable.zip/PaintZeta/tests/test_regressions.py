"""Pruebas estaticas del codigo fuente. No reemplazan ejecutar APK en Android."""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VIEW = (ROOT / 'app/src/main/java/com/pacco/animecut/view/CanvasView.java').read_text()
MAIN = (ROOT / 'app/src/main/java/com/pacco/animecut/MainActivity.java').read_text()


class SourceRegressions(unittest.TestCase):
    def test_paint_allocates_coverage_before_use(self):
        # Fallo reproducible de la version 8.14: stampPaint leia cov[i],
        # pero beginLayerStroke dejaba cov en null para MODE_PAINT.
        section = VIEW[VIEW.index('private boolean needsStrokeCoverage()'):VIEW.index('private boolean beginLayerStroke()')]
        self.assertIn('return mode == MODE_PAINT ||', section)
        paint_section = VIEW[VIEW.index('private void stampPaint(float cx, float cy)'):VIEW.index('private void stampParticles(')]
        self.assertIn('if (cov == null || strokeLayer == null) return;', paint_section)
        self.assertIn('int old = cov[i] & 0xFF;', VIEW)

    def test_liquify_modes_are_reachable(self):
        self.assertIn('String[] names = {"Arrastrar", "Contraer", "Expandir", "Suavizar", "Restaurar"}', MAIN)
        self.assertIn('canvas.setLiquifyType(which);', MAIN)
        self.assertIn('"Grosor\\n" + sizeText + "px"', MAIN)
        self.assertIn('"Fuerza " + v + "%"', MAIN)

    def test_color_and_liquify_strength_not_mixed(self):
        self.assertIn('if (canvas.getMode() != CanvasView.MODE_LIQUIFY) bottomOp.setProgress(op);', MAIN)
        self.assertIn('canvas.setEffectStrength(v / 100f);', MAIN)
        self.assertIn('canvas.setBrushOpacity(v / 100f);', MAIN)

    def test_inverse_liquify_single_sampler_no_newton(self):
        engine = (ROOT / 'app/src/main/java/com/pacco/animecut/core/InverseLiquifyEngine.java').read_text()
        self.assertIn('public static void sample(', engine)
        self.assertIn('public static boolean stamp(', engine)
        self.assertNotIn('invertLiquify(', VIEW)
        self.assertNotIn('sampleLiquifyWithJacobian(', VIEW)
        self.assertIn('InverseLiquifyEngine.sample(', VIEW)
        self.assertNotIn('drawBitmapMesh(liquifyMesh', VIEW)
        self.assertEqual(VIEW.count('renderLiquifyRegion(r);'), 2)

    def test_liquify_guard_applied_before_mark_dirty(self):
        engine = (ROOT / 'app/src/main/java/com/pacco/animecut/core/InverseLiquifyEngine.java').read_text()
        self.assertIn('LiquifyTopologyGuard.minTriangleRatio(', engine)
        self.assertIn('if (minArea < .25f)', engine)
        self.assertIn('return false;', engine)
        method = VIEW[VIEW.index('private Rect effectLiquifyField('):VIEW.index('private final float[] liquifySample')]
        self.assertLess(method.index('InverseLiquifyEngine.stamp('), method.index('markLiquifyDirty(dirty)'))
        self.assertIn('if (!changed) return null;', method)

    def test_liquify_input_and_preview_are_not_coarsened(self):
        self.assertIn('getHistoricalX(0, hk)', VIEW)
        self.assertIn('!isShapeTool() && mode != MODE_LIQUIFY', VIEW)
        self.assertIn('mode == MODE_LIQUIFY ? 32 : 48', VIEW)
        self.assertNotIn('liquifyMeshPreviewVisible', VIEW)
        self.assertIn('if (liquifyPreviewDirtyValid) liquifyPreviewDirty.union(r);', VIEW)

    def test_all_resource_xml_parses(self):
        for file in ROOT.glob('app/src/main/res/**/*.xml'):
            with self.subTest(file=file.name):
                ET.parse(file)

    def test_simple_tools_and_automatic_lasso_copy(self):
        main_menu = MAIN[MAIN.index('private static final int[][] TOOLS = {'):MAIN.index('private String[] toolInfo(')]
        for removed in ('MODE_WAND', 'MODE_BRUSH', 'MODE_SCISSORS', 'MODE_MAGNET',
                        'MODE_ZONE', 'MODE_PATCH', 'MODE_CLONE', 'MODE_TONE',
                        'MODE_HEAL', 'MODE_LINE'):
            self.assertNotIn(removed, main_menu)
        for kept in ('MODE_LASSO', 'MODE_PAINT', 'MODE_ERASER', 'MODE_BUCKET',
                     'MODE_LIQUIFY', 'MODE_MARKER', 'MODE_BGERASE', 'MODE_TRANSFORM'):
            self.assertIn(kept, main_menu)
        self.assertIn('callback.onLassoCompleted()', VIEW)
        self.assertIn('partFromSelectionDialog(false)', MAIN)
        self.assertIn('canvas.clearTemporarySelectionAfterCopy()', MAIN)

    def test_two_fingers_use_single_transform_pipeline(self):
        touch = VIEW[VIEW.index('public boolean onTouchEvent(MotionEvent e)'):
                     VIEW.index('private void beginPending()')]
        self.assertNotIn('scaleDetector.onTouchEvent(e)', touch)
        zoom = VIEW[VIEW.index('private void twoFingers('):
                    VIEW.index('private void armQuickPick()')]
        self.assertIn('view.postTranslate(', zoom)
        self.assertIn('view.postScale(', zoom)
        self.assertIn('lastPinchDistance', zoom)
        self.assertIn('postInvalidateOnAnimation()', zoom)

    def test_menu_opens_visible_tool_and_guided_workflow(self):
        section = MAIN[MAIN.index('private void afterProjectLoaded('): MAIN.index('private void applyLoaded(')]
        self.assertIn('canvas.setMode(CanvasView.MODE_PAN)', section)
        self.assertIn('animationWorkflowDialog()', MAIN)
        self.assertIn('exportAnimationZip()', MAIN)
        self.assertIn('selectTool(CanvasView.MODE_LASSO)', MAIN)

    def test_auto_save_has_recoverable_backup(self):
        self.assertIn('final File bak = new File(dest.getAbsolutePath() + ".bak")', MAIN)
        self.assertIn('dest.renameTo(bak)', MAIN)
        self.assertIn('tmp.renameTo(dest)', MAIN)
        self.assertIn('recoveredBackup = true', MAIN)
        store = (ROOT / 'app/src/main/java/com/pacco/animecut/core/ProjectStore.java').read_text()
        self.assertIn('n.endsWith(".acut.bak")', store)
        self.assertIn('if (bak.exists()) bak.delete()', store)

    def test_lasso_copy_and_cut_are_available(self):
        self.assertIn('finishPartExtraction(!cut', MAIN)
        self.assertIn('finishPartExtraction(cut', MAIN)
        self.assertIn('canvas.clearTemporarySelectionAfterCopy()', MAIN)

    def test_special_hold_processing_and_alpha_clean_blur(self):
        self.assertIn('handler.postDelayed(liquifyHold, LIQUIFY_HOLD_MS);', VIEW)
        self.assertIn('handler.removeCallbacks(liquifyHold);', VIEW)
        self.assertIn('AlphaColors.mix(base, warped, sel)', VIEW)
        self.assertIn('AlphaColors.mix(px[row + x], avg, f)', VIEW)
        self.assertIn('int as = blurColA[x0] + blurColA[x1] + blurColA[x2]', VIEW)
        exporter = (ROOT / 'app/src/main/java/com/pacco/animecut/core/Exporter.java').read_text()
        self.assertIn('LEEME_Partes.txt', exporter)

    def test_optimized_background_eraser_keeps_undo_and_alpha(self):
        bg = VIEW[VIEW.index('private void runBgBucket('):VIEW.index('private void ensureGradient(int[] px)')]
        self.assertIn('final byte[][] preparedAlpha', bg)
        self.assertIn('undo.recordLayer(t, r);', bg)
        self.assertIn('BackgroundEraseAlpha.prepare(', bg)
        self.assertIn('System.arraycopy(', VIEW)  # fallback and other batch paths
        self.assertIn('setBusy(false);', bg)
        self.assertIn('despeckle(r);', bg)  # fallback when low RAM

    def test_zoom_and_large_strokes_defer_compositing(self):
        self.assertIn('drawing ? 20_000L : 60_000L', VIEW)
        self.assertIn('if (!drawing) scheduleDetail();', VIEW)
        self.assertIn('private final float[] viewMatrixValues', VIEW)

    def test_heavy_tools_do_not_replay_all_event_history(self):
        touch = VIEW[VIEW.index('public boolean onTouchEvent(MotionEvent e)'):VIEW.index('private void beginPending()')]
        self.assertIn('boolean processHistory = mode == MODE_LASSO', touch)
        self.assertIn('if (processHistory && e.getPointerCount() == 1)', touch)
        self.assertIn('mode == MODE_BGERASE ? .48f', VIEW)

    def test_liquify_preview_and_final_use_same_sampler(self):
        self.assertIn('if (Math.abs(liquifySample[0]) + Math.abs(liquifySample[1]) < .002f)', VIEW)
        self.assertIn('while (n < liquifyDirtyTiles.size())', VIEW)
        self.assertIn('renderLiquifyRegion(r);', VIEW)

    def test_keep_curva_polilinea_malla_unchanged_and_distinct_eraser_icons(self):
        main_menu = MAIN[MAIN.index('private static final int[][] TOOLS = {'):MAIN.index('private String[] toolInfo(')]
        self.assertIn('MODE_CURVE', main_menu)
        self.assertIn('MODE_POLY', main_menu)
        self.assertIn('MODE_TRANSFORM', main_menu)
        self.assertIn('R.drawable.ic_feather_edge', MAIN)
        self.assertIn('R.drawable.ic_range', MAIN)
        self.assertIn('"Suavizar borde del recorte"', MAIN)
        self.assertNotIn('dotsButton("Ajustar borde"', MAIN)

    def test_pinching_does_not_rotate_accidentally(self):
        zoom = VIEW[VIEW.index('private void twoFingers('):VIEW.index('private void armQuickPick()')]
        self.assertNotIn('view.postRotate(', zoom)
        self.assertIn('view.postScale(', zoom)
        self.assertIn('view.postTranslate(', zoom)

    def test_version(self):
        gradle = (ROOT / 'app/build.gradle').read_text()
        self.assertIn('versionCode 58', gradle)
        self.assertIn('versionName "8.20"', gradle)


if __name__ == '__main__':
    unittest.main()
