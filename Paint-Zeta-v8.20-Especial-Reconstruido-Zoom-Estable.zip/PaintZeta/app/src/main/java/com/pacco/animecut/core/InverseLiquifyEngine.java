package com.pacco.animecut.core;

/**
 * Motor de Especial basado en remapeo INVERSO: cada nodo guarda el vector
 * (destino -> fuente). Un pixel se reconstruye en una sola lectura interpolada;
 * no se invierten mallas triangulares ni se itera Newton por cada pixel.
 *
 * No depende de Android. Los cambios se proponen sobre nodos temporales y se
 * retroceden hasta que el jacobiano conserve orientacion y area suficiente.
 * Malla/Transformar utilizan otro motor y NO dependen de esta clase.
 */
public final class InverseLiquifyEngine {
    public static final int DRAG = 0, PINCH = 1, EXPAND = 2, SMOOTH = 3, RESTORE = 4;
    private InverseLiquifyEngine() { }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float falloff(float distanceSq, float radiusSq, float softness) {
        if (distanceSq >= radiusSq) return 0f;
        float q = 1f - distanceSq / radiusSq;
        q = q * q * (3f - 2f * q);
        return (float) Math.pow(q, 1.65f - clamp(softness, 0f, 1f) * .85f);
    }

    /**
     * Aplica una estampa sin cambiar la imagen original. selection == null indica
     * lienzo completo; de lo contrario cada byte es cobertura de 0..255.
     * Una salida false significa que el campo permanece igual.
     */
    public static boolean stamp(float[] dx, float[] dy, float[] prevX, float[] prevY,
            int cols, int rows, float step, int width, int height,
            float cx, float cy, float dragX, float dragY,
            float radius, float strength, float softness, int mode,
            byte[] selection, int gx0, int gy0, int gx1, int gy1) {
        if (dx == null || dy == null || prevX == null || prevY == null
                || width < 2 || height < 2 || cols < 2 || rows < 2
                || radius <= 0f || !Float.isFinite(cx) || !Float.isFinite(cy)) return false;
        gx0 = Math.max(0, gx0); gy0 = Math.max(0, gy0);
        gx1 = Math.min(cols - 1, gx1); gy1 = Math.min(rows - 1, gy1);
        if (gx1 < gx0 || gy1 < gy0) return false;
        // Copiar vecinos para Suavizar y conservar el estado previo al backtracking.
        int left = Math.max(0, gx0 - 1), top = Math.max(0, gy0 - 1);
        int right = Math.min(cols - 1, gx1 + 1), bottom = Math.min(rows - 1, gy1 + 1);
        for (int gy = top; gy <= bottom; gy++) {
            int off = gy * cols + left, n = right - left + 1;
            System.arraycopy(dx, off, prevX, off, n);
            System.arraycopy(dy, off, prevY, off, n);
        }

        float str = clamp(strength, 0f, 1f), r2 = radius * radius;
        // Movimiento de arrastre proporcional a la fuerza: a 32% NO actua como 55%.
        float gain = str;
        float maxNodeDisplacement = Math.max(64f, radius * 2.7f);
        boolean changed = false;
        for (int gy = gy0; gy <= gy1; gy++) {
            float y = Math.min(height - 1f, gy * step);
            for (int gx = gx0; gx <= gx1; gx++) {
                float x = Math.min(width - 1f, gx * step);
                float ux = x - cx, uy = y - cy;
                float influence = falloff(ux * ux + uy * uy, r2, softness);
                if (influence < .0005f) continue;
                if (selection != null) {
                    int sx = (int) clamp(Math.round(x), 0, width - 1);
                    int sy = (int) clamp(Math.round(y), 0, height - 1);
                    influence *= (selection[sy * width + sx] & 255) / 255f;
                    if (influence < .0005f) continue;
                }
                int i = gy * cols + gx;
                float w = influence * gain;
                float oldX = prevX[i], oldY = prevY[i];
                float nx = oldX, ny = oldY;
                if (mode == DRAG) {
                    // Remapeo inverso: tirar de la imagen a +x requiere leer a -x.
                    nx -= dragX * w;
                    ny -= dragY * w;
                } else if (mode == PINCH || mode == EXPAND) {
                    // Contraer (forward) = leer de MAS lejos del centro (inverse).
                    float k = (.008f + .05f * str) * influence;
                    float sign = mode == PINCH ? 1f : -1f;
                    nx += ux * k * sign;
                    ny += uy * k * sign;
                } else if (mode == SMOOTH) {
                    float ax = 0f, ay = 0f, weight = 0f;
                    for (int yy = Math.max(0, gy - 1); yy <= Math.min(rows - 1, gy + 1); yy++) {
                        for (int xx = Math.max(0, gx - 1); xx <= Math.min(cols - 1, gx + 1); xx++) {
                            int j = yy * cols + xx;
                            float kw = xx == gx && yy == gy ? 2f : 1f;
                            ax += prevX[j] * kw; ay += prevY[j] * kw; weight += kw;
                        }
                    }
                    float t = Math.min(.6f, (.06f + .36f * str) * influence);
                    nx += (ax / weight - oldX) * t;
                    ny += (ay / weight - oldY) * t;
                } else if (mode == RESTORE) {
                    float t = Math.min(.75f, (.08f + .50f * str) * influence);
                    nx *= (1f - t);
                    ny *= (1f - t);
                } else return false;
                float norm = (float) Math.hypot(nx, ny);
                if (norm > maxNodeDisplacement) {
                    nx *= maxNodeDisplacement / norm;
                    ny *= maxNodeDisplacement / norm;
                }
                if (Math.abs(nx - oldX) + Math.abs(ny - oldY) > 1e-6f) changed = true;
                dx[i] = nx; dy[i] = ny;
            }
        }
        if (!changed) return false;

        int cellL = Math.max(0, gx0 - 1), cellT = Math.max(0, gy0 - 1);
        int cellR = Math.min(cols - 2, gx1), cellB = Math.min(rows - 2, gy1);
        float minArea = LiquifyTopologyGuard.minTriangleRatio(dx, dy, cols, rows,
                step, width, height, cellL, cellT, cellR, cellB);
        // Reduccion de incremento de manera LOCAL, no frena toda la herramienta.
        for (int n = 0; minArea < .25f && n < 13; n++) {
            for (int gy = gy0; gy <= gy1; gy++) {
                for (int gx = gx0; gx <= gx1; gx++) {
                    int i = gy * cols + gx;
                    dx[i] = (dx[i] + prevX[i]) * .5f;
                    dy[i] = (dy[i] + prevY[i]) * .5f;
                }
            }
            minArea = LiquifyTopologyGuard.minTriangleRatio(dx, dy, cols, rows,
                    step, width, height, cellL, cellT, cellR, cellB);
        }
        if (minArea < .25f) {
            for (int gy = gy0; gy <= gy1; gy++) {
                int off = gy * cols + gx0, n = gx1 - gx0 + 1;
                System.arraycopy(prevX, off, dx, off, n);
                System.arraycopy(prevY, off, dy, off, n);
            }
            return false;
        }
        return true;
    }

    /** Bilineal del campo de desplazamiento inverso, sin calcular jacobianos. */
    public static void sample(float[] dx, float[] dy, int cols, int rows,
            float step, int width, int height, float x, float y, float[] out) {
        x = clamp(x, 0f, width - 1f);
        y = clamp(y, 0f, height - 1f);
        int x0 = Math.min(cols - 1, (int)(x / step));
        int y0 = Math.min(rows - 1, (int)(y / step));
        int x1 = Math.min(cols - 1, x0 + 1);
        int y1 = Math.min(rows - 1, y0 + 1);
        float wx = Math.min(width - 1f, x0 * step), wy = Math.min(height - 1f, y0 * step);
        float fx = x1 == x0 ? 0f : clamp((x - wx) / Math.max(1f, Math.min(width - 1f, x1 * step) - wx), 0f, 1f);
        float fy = y1 == y0 ? 0f : clamp((y - wy) / Math.max(1f, Math.min(height - 1f, y1 * step) - wy), 0f, 1f);
        int i00 = y0 * cols + x0, i10 = y0 * cols + x1;
        int i01 = y1 * cols + x0, i11 = y1 * cols + x1;
        float a = 1f - fx, b = 1f - fy;
        out[0] = b * (a * dx[i00] + fx * dx[i10]) + fy * (a * dx[i01] + fx * dx[i11]);
        out[1] = b * (a * dy[i00] + fx * dy[i10]) + fy * (a * dy[i01] + fx * dy[i11]);
    }
}
