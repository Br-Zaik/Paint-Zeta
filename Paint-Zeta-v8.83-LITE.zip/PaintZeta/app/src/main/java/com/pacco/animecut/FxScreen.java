package com.pacco.animecut;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.pacco.animecut.core.Fx;
import com.pacco.animecut.core.FxSession;
import com.pacco.animecut.core.GodRays;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.view.CanvasView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v8.57 pantalla "Filtros" (como la de Clip Studio en el telefono): la obra arriba, la fila de
 * filtros con miniaturas abajo, solo las barras del filtro elegido, Aceptar / Cancelar.
 *
 *  - La vista previa se calcula en una copia chica, en otro hilo. Si mueves la barra rapido,
 *    los calculos viejos se descartan (contador de generacion): nunca aparece un resultado viejo
 *    despues de uno nuevo. Mientras arrastras usa una copia aun mas chica; al soltar, la normal.
 *  - Aceptar calcula a tamano real con barra de avance y Cancelar. Se puede Deshacer.
 *  - "Aplicar en capa nueva" es OPCIONAL (apagado = cambia la capa elegida).
 *  - Tocar o arrastrar en la imagen mueve el sol / la sombra / el centro (si el filtro lo usa).
 *  - Mantener "Antes" muestra la obra sin el filtro.
 */
final class FxScreen {
    private final Activity act;
    private final CanvasView canvas;
    private final Layer target;
    private final Project project;
    private final float dens;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private Dialog dlg;
    private FxSession session;
    private volatile int gen;
    private volatile boolean closed;
    private int cur;
    private Fx.P params;
    private final Fx.P[] saved = new Fx.P[Fx.COUNT];

    private ImageView preview;
    private PointMark mark;
    private TextView title, help, info;
    private LinearLayout controls;
    private final LinearLayout[] cells = new LinearLayout[Fx.COUNT];
    private final ImageView[] thumbs = new ImageView[Fx.COUNT];
    /** v8.82: miniaturas ya pedidas (se hacen solo las del grupo que se ve). */
    private final boolean[] thumbAsked = new boolean[Fx.COUNT];
    /** v8.82: grupo elegido de la fila de filtros (0 = todos). */
    private int cat;
    private final TextView[] catChips = new TextView[Fx.CATS.length];
    private CheckBox newLayerBox;
    /** v8.80: aviso "va en una capa nueva" de los filtros que crean su propia capa. */
    private TextView layerNote;
    /** v8.80: el origen de los rayos sigue al centro de la fuente hasta que lo muevas a mano. */
    private boolean autoOrigin = true;
    private boolean showAdvanced;
    private final Bitmap[][] bufs = new Bitmap[3][3];
    private final int[] bufIdx = new int[3];
    /** v8.59 zoom de la vista: 1 = entera; centro en coordenadas 0..1 de la imagen. */
    private float zoom = 1f, zcx = .5f, zcy = .5f;
    private android.view.ScaleGestureDetector scaler;
    private android.view.GestureDetector taps;
    private float lastX, lastY;
    private boolean multi;
    private long lastMs;

    private FxScreen(Activity a, CanvasView c, Layer t, int startId) {
        act = a;
        canvas = c;
        target = t;
        project = c.getProject();
        dens = a.getResources().getDisplayMetrics().density;
        prefs = a.getSharedPreferences("pz", Activity.MODE_PRIVATE);
        cur = startId;
    }

    private int dp(float v) { return Math.round(v * dens); }

    /** Abre la pantalla de filtros sobre la capa elegida. startId &lt; 0 = el ultimo usado. */
    /** v8.83: se llama una vez al cerrar la pantalla (o si no pudo abrir). */
    static Runnable afterClose;

    private static void fireAfterClose() {
        Runnable r = afterClose;
        afterClose = null;
        if (r != null) r.run();
    }

    static void open(Activity a, CanvasView c, int startId) {
        if (c.getProject() == null) { fireAfterClose(); return; }
        Layer t = c.fxTarget();
        if (t == null) { fireAfterClose(); return; }
        if (startId < 0) startId = a.getSharedPreferences("pz", Activity.MODE_PRIVATE).getInt("fx_last", Fx.EXTRACT);
        if (startId < 0 || startId >= Fx.COUNT) startId = Fx.EXTRACT;
        new FxScreen(a, c, t, startId).show();
    }

    // ------------------------------------------------------------------ armar la pantalla

    private void show() {
        params = Fx.defaults(cur);
        canvas.setCompactHold(true);
        dlg = new Dialog(act, android.R.style.Theme_Black_NoTitleBar);
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1B1B20);

        // barra de arriba: Cancelar · nombre · Aceptar
        LinearLayout top = new LinearLayout(act);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(6), dp(8), dp(6));
        TextView cancel = pill("Cancelar", 0xFF3A3A42);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { close(); }
        });
        title = new TextView(act);
        title.setTextColor(Color.WHITE);
        title.setTextSize(16f);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        TextView ok = pill("Aceptar", 0xFF2F6BD8);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { applyFull(); }
        });
        top.addView(cancel);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(ok);
        root.addView(top);

        // la obra
        FrameLayout frame = new FrameLayout(act);
        frame.setBackgroundColor(0xFF111114);
        preview = new ImageView(act);
        preview.setScaleType(ImageView.ScaleType.MATRIX);
        preview.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) { applyMatrix(); }
        });
        scaler = new android.view.ScaleGestureDetector(act, new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(android.view.ScaleGestureDetector d) {
                zoom = Math.max(1f, Math.min(12f, zoom * d.getScaleFactor()));
                applyMatrix();
                return true;
            }
        });
        taps = new android.view.GestureDetector(act, new android.view.GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (zoom > 1.01f) { zoom = 1f; zcx = zcy = .5f; } else { zoomAt(e.getX(), e.getY(), 3f); }
                applyMatrix();
                return true;
            }
        });
        frame.addView(preview, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mark = new PointMark();
        frame.addView(mark, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        info = new TextView(act);
        info.setTextColor(0xCCFFFFFF);
        info.setTextSize(11f);
        info.setBackgroundColor(0x88000000);
        info.setPadding(dp(6), dp(2), dp(6), dp(2));
        info.setText("Preparando la vista previa...");
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ilp.gravity = Gravity.TOP | Gravity.START;
        ilp.setMargins(dp(6), dp(6), 0, 0);
        frame.addView(info, ilp);
        final TextView before = pill("Antes", 0xAA000000);
        before.setTextSize(12f);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.TOP | Gravity.END;
        blp.setMargins(0, dp(6), dp(6), 0);
        frame.addView(before, blp);
        before.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) showOriginal();
                else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) request(false);
                return true;
            }
        });
        preview.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) { return touchPreview(e); }
        });
        root.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ayuda corta + controles
        LinearLayout panel = new LinearLayout(act);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(6), dp(12), dp(2));
        help = new TextView(act);
        help.setTextColor(0xFFB8B8C0);
        help.setTextSize(12f);
        panel.addView(help);
        controls = new LinearLayout(act);
        controls.setOrientation(LinearLayout.VERTICAL);
        panel.addView(controls);
        newLayerBox = new CheckBox(act);
        newLayerBox.setText("Aplicar en capa nueva (la original no cambia)");
        newLayerBox.setTextColor(0xFFDDDDDD);
        newLayerBox.setTextSize(13f);
        newLayerBox.setChecked(prefs.getBoolean("fx_new_layer", false));
        newLayerBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                prefs.edit().putBoolean("fx_new_layer", v).apply();
            }
        });
        panel.addView(newLayerBox);
        layerNote = new TextView(act);
        layerNote.setTextColor(0xFF9FD8B8);
        layerNote.setTextSize(12f);
        layerNote.setPadding(0, dp(4), 0, dp(4));
        panel.addView(layerNote);
        root.addView(panel);

        // v8.82: grupos (Todos, Manga, Luz, Estilo, Desenfoque, Ajustes)
        cat = Math.max(0, Math.min(Fx.CATS.length - 1, prefs.getInt("fx_cat", 0)));
        if (cat != 0 && Fx.category(cur) != cat) cat = 0;
        HorizontalScrollView chs = new HorizontalScrollView(act);
        chs.setHorizontalScrollBarEnabled(false);
        chs.setBackgroundColor(0xFF141418);
        LinearLayout chips = new LinearLayout(act);
        chips.setPadding(dp(6), dp(6), dp(6), 0);
        for (int k = 0; k < Fx.CATS.length; k++) {
            final int kk = k;
            TextView c = new TextView(act);
            c.setText(Fx.CATS[k]);
            c.setTextColor(Color.WHITE);
            c.setTextSize(12.5f);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(12), 0, dp(12), 0);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { setCategory(kk); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30));
            lp.setMargins(0, 0, dp(6), 0);
            chips.addView(c, lp);
            catChips[k] = c;
        }
        chs.addView(chips);
        root.addView(chs);

        // fila de filtros con miniaturas
        HorizontalScrollView hs = new HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setBackgroundColor(0xFF141418);
        LinearLayout strip = new LinearLayout(act);
        strip.setPadding(dp(4), dp(6), dp(4), dp(6));
        for (final int id : Fx.ORDER) {
            LinearLayout cell = new LinearLayout(act);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(3), dp(3), dp(3), dp(3));
            ImageView th = new ImageView(act);
            th.setScaleType(ImageView.ScaleType.CENTER_CROP);
            th.setBackgroundColor(0xFF2A2A30);
            cell.addView(th, new LinearLayout.LayoutParams(dp(58), dp(58)));
            TextView tv = new TextView(act);
            tv.setText(Fx.SHORT[id]);
            tv.setTextColor(0xFFDDDDDD);
            tv.setTextSize(10f);
            tv.setGravity(Gravity.CENTER);
            tv.setMaxLines(2);
            cell.addView(tv, new LinearLayout.LayoutParams(dp(66), ViewGroup.LayoutParams.WRAP_CONTENT));
            cell.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(id); }
            });
            cells[id] = cell;
            thumbs[id] = th;
            strip.addView(cell);
        }
        hs.addView(strip);
        root.addView(hs);
        paintCategory();

        dlg.setContentView(root);
        dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) { release(); }
        });
        Window win = dlg.getWindow();
        if (win != null) win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dlg.show();
        bindFilter();

        // copias chicas fuera de la pantalla; luego la primera vista previa y las miniaturas
        final int idx = project.layers.indexOf(target);
        long avail = availMem();
        final int mainSide = avail < 600_000_000L ? 540 : 720;
        final int dragSide = avail < 600_000_000L ? 320 : 400;
        final long avail2 = avail;
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    FxSession s = new FxSession(project.layers, idx, project.w, project.h,
                            project.selection, mainSide, dragSide);
                    s.setHiSide(avail2 < 700_000_000L ? 1400 : 2048);
                    s.build(new Fx.Job() {
                        @Override public boolean cancelled() { return closed; }
                        @Override public void progress(int pct) { }
                    });
                    session = s;
                } catch (Fx.Cancelled c) {
                    return;
                } catch (OutOfMemoryError e) {
                    ui.post(new Runnable() {
                        @Override public void run() { toast("No alcanzo la memoria para la vista previa"); close(); }
                    });
                    return;
                }
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (closed) return;
                        if (cur == Fx.RAYS) centerOrigin(true);
                        warnOpaque();
                        bindFilter();      // ahora se saben los nombres de las capas
                        request(false);
                        makeThumbs();
                        if (session.hasSelection()) toast(cur == Fx.RAYS
                                ? "Hay una seleccion: solo lo seleccionado da luz"
                                : cur == Fx.FOCUS_LINES || cur == Fx.SPEED_LINES
                                ? "Hay una seleccion: las lineas solo van dentro de lo seleccionado"
                                : Fx.makesLayer(cur) ? "Hay una seleccion: solo lo seleccionado lleva el efecto"
                                : "Hay una seleccion: el filtro solo cambia lo seleccionado");
                    }
                });
            }
        });
    }

    private TextView pill(String text, int color) {
        TextView t = new TextView(act);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(18));
        t.setBackground(g);
        return t;
    }

    private long availMem() {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) act.getSystemService(Activity.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.availMem;
        } catch (Throwable t) {
            return 1_000_000_000L;
        }
    }

    // ------------------------------------------------------------------ elegir filtro y barras

    private void select(int id) {
        if (id == cur) return;
        saved[cur] = params;
        cur = id;
        boolean fresh = saved[id] == null;
        params = saved[id] != null ? saved[id] : Fx.defaults(id);
        prefs.edit().putInt("fx_last", id).apply();
        if (fresh && id == Fx.RAYS) {
            autoOrigin = true;
            centerOrigin(true);
        }
        warnOpaque();
        bindFilter();
        request(false);
    }

    private void bindFilter() {
        title.setText(Fx.NAMES[cur]);
        Fx.Spec sp = Fx.spec(cur);
        help.setText(Fx.HELP[cur] + (sp.point != null ? " " + sp.point + "." : ""));
        for (int id = 0; id < Fx.COUNT; id++) {
            if (cells[id] == null) continue;
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(8));
            g.setColor(id == cur ? 0xFF2F6BD8 : 0x00000000);
            cells[id].setBackground(g);
        }
        controls.removeAllViews();
        boolean anyAdv = false;
        for (int i = 0; i < sp.sliders.length; i++) {
            Fx.Slider s = sp.sliders[i];
            if (s.advanced) { anyAdv = true; if (!showAdvanced) continue; }
            controls.addView(sliderRow(i, s));
        }
        if (anyAdv) {
            final TextView more = new TextView(act);
            more.setText(showAdvanced ? "Menos ajustes ▴" : "Más ajustes ▾");
            more.setTextColor(0xFF8FB4FF);
            more.setTextSize(13f);
            more.setPadding(0, dp(4), 0, dp(4));
            more.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showAdvanced = !showAdvanced; bindFilter(); }
            });
            controls.addView(more);
        }
        if (sp.modes != null) controls.addView(modeRow(sp.modes));
        if (Fx.usesColor(cur)) controls.addView(colorRow());
        if (sp.seed) {
            TextView again = new TextView(act);
            again.setText("↻ Otra distribución");
            again.setTextColor(0xFF8FB4FF);
            again.setTextSize(13f);
            again.setPadding(0, dp(6), 0, dp(6));
            again.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { params.seed++; request(false); }
            });
            controls.addView(again);
        }
        if (sp.toggle != null) {
            final CheckBox cb = new CheckBox(act);
            // v8.81: Rayos dice que capa lee
            cb.setText(cur == Fx.RAYS && session != null && session.hasBelowRef()
                    ? sp.toggle + " («" + session.sourceName(true) + "»)" : sp.toggle);
            cb.setTextColor(0xFFDDDDDD);
            cb.setTextSize(13f);
            cb.setChecked(params.opt);
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                    if (cur == Fx.RAYS && v && session != null && !session.hasBelowRef()) {
                        toast("No hay una capa visible abajo");
                        cb.setChecked(false);
                        return;
                    }
                    params.opt = v;
                    if (cur == Fx.RAYS) centerOrigin(autoOrigin);
                    updateLayerNote();
                    request(false);
                }
            });
            controls.addView(cb);
        }
        updateLayerNote();
        mark.invalidate();
    }

    /** v8.81: dice de que capa se lee y donde queda la capa nueva (encima o debajo). */
    private void updateLayerNote() {
        boolean own = Fx.makesLayer(cur);
        newLayerBox.setVisibility(own ? View.GONE : View.VISIBLE);
        layerNote.setVisibility(own ? View.VISIBLE : View.GONE);
        if (!own) return;
        String src = session == null ? "" : session.sourceName(cur == Fx.RAYS && params.opt);
        boolean below = session != null ? session.placeBelow(cur, params) : Fx.effectBelow(cur, params);
        int md = Fx.layerMode(cur, params);
        StringBuilder b = new StringBuilder();
        if (cur != Fx.FOCUS_LINES && cur != Fx.SPEED_LINES && src.length() > 0) b.append("Lee: «").append(src).append("». ");
        b.append("Va en una capa nueva «").append(Fx.NAMES[cur]).append("» ")
                .append(below ? "DEBAJO" : "ENCIMA").append(" de esta")
                .append(md == Fx.MODE_ADD ? " (modo Añadir)" : "")
                .append(": tu dibujo no cambia y el efecto se puede ocultar, borrar o bajar de opacidad.");
        layerNote.setText(b.toString());
    }

    /** v8.81: Exterior / Interior / Ambos. */
    private View modeRow(String[] names) {
        LinearLayout row = new LinearLayout(act);
        row.setPadding(0, dp(4), 0, dp(4));
        final TextView[] tv = new TextView[names.length];
        final Runnable paint = new Runnable() {
            @Override public void run() {
                for (int k = 0; k < tv.length; k++) {
                    GradientDrawable g = new GradientDrawable();
                    g.setCornerRadius(dp(8));
                    g.setColor(params.mode == k ? 0xFF2F6BD8 : 0xFF3A3A42);
                    tv[k].setBackground(g);
                }
            }
        };
        for (int k = 0; k < names.length; k++) {
            final int m = k;
            tv[k] = new TextView(act);
            tv[k].setText(names[k]);
            tv[k].setTextColor(Color.WHITE);
            tv[k].setTextSize(13f);
            tv[k].setGravity(Gravity.CENTER);
            tv[k].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    params.mode = m;
                    paint.run();
                    updateLayerNote();
                    request(false);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            if (k > 0) lp.setMargins(dp(6), 0, 0, 0);
            row.addView(tv[k], lp);
        }
        paint.run();
        return row;
    }

    /** v8.81: contorno y resplandor siguen la transparencia: una capa sin transparencia no tiene borde. */
    private void warnOpaque() {
        if (session == null || (cur != Fx.OUTLINE && cur != Fx.SIL_GLOW)) return;
        if (session.sourceOpaque())
            toast("Esta capa no tiene partes transparentes: no hay silueta que seguir. "
                    + "Primero recorta el personaje (Borrar fondo o IA) o usa una capa con fondo transparente.");
    }

    /** v8.80: colores de la luz (y "Actual" = el color de la brocha). */
    private static final int[] LIGHT_COLORS = {Fx.RAYS_COLOR, 0xFFFFFFFF, 0xFFFFC94D, 0xFFFF8F45, 0xFFA6DCFF,
            0xFFFFA8DA, 0xFFB9FFA0};
    /** v8.81: contorno y lineas de manga (negro primero). */
    private static final int[] INK_COLORS = {0xFF000000, 0xFFFFFFFF, 0xFF1E3A8A, 0xFFD32F2F, 0xFFFFD54F, 0xFF7E57C2};
    /** v8.81: resplandor de silueta (neon). */
    private static final int[] GLOW_COLORS = {0xFF5FE3FF, 0xFFFF5FD2, 0xFFB388FF, 0xFFFFE066, 0xFF69F0AE, 0xFFFFFFFF,
            0xFFFF7043};

    private View colorRow() {
        LinearLayout row = new LinearLayout(act);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(4), 0, dp(4));
        TextView lab = new TextView(act);
        lab.setText("Color");
        lab.setTextColor(0xFFEEEEEE);
        lab.setTextSize(13f);
        lab.setMinWidth(dp(60));
        row.addView(lab);
        final java.util.List<View> sw = new java.util.ArrayList<>();
        final int[] base = cur == Fx.RAYS ? LIGHT_COLORS : cur == Fx.SIL_GLOW ? GLOW_COLORS : INK_COLORS;
        final int[] cols = new int[base.length + 1];
        System.arraycopy(base, 0, cols, 0, base.length);
        cols[base.length] = canvas.getColor() | 0xFF000000;
        final Runnable paint = new Runnable() {
            @Override public void run() {
                for (int k = 0; k < sw.size(); k++) {
                    GradientDrawable g = new GradientDrawable();
                    g.setShape(GradientDrawable.OVAL);
                    g.setColor(cols[k]);
                    boolean on = (params.color | 0xFF000000) == cols[k];
                    g.setStroke(dp(on ? 3 : 1), on ? 0xFF2F8BFF : 0x88FFFFFF);
                    sw.get(k).setBackground(g);
                }
            }
        };
        for (int k = 0; k < cols.length; k++) {
            final int c = cols[k];
            View v;
            if (k == base.length) {
                TextView t = new TextView(act);
                t.setText("Actual");
                t.setTextSize(9f);
                t.setGravity(Gravity.CENTER);
                t.setTextColor(((c >> 16) & 255) + ((c >> 8) & 255) + (c & 255) > 380 ? Color.BLACK : Color.WHITE);
                v = t;
            } else {
                v = new View(act);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(k == base.length ? 40 : 28), dp(28));
            lp.setMargins(dp(3), 0, dp(3), 0);
            v.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View x) {
                    params.color = c;
                    paint.run();
                    request(false);
                }
            });
            sw.add(v);
            row.addView(v, lp);
        }
        paint.run();
        HorizontalScrollView hs = new HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    /**
     * v8.80: pone el origen de los rayos en el centro de lo que da luz (si 'force' o si todavia no
     * lo moviste). Si la fuente esta vacia, lo dice.
     */
    private void centerOrigin(boolean force) {
        if (session == null || cur != Fx.RAYS) return;
        float[] c = session.lightCentroid(params.opt, params.v[GodRays.THRESH]);
        if (c == null) {
            toast(params.opt ? "La capa de abajo no tiene nada que dé luz"
                    : "Esta capa está vacía: dibuja una figura (por ejemplo un círculo relleno) o usa «Fuente: la capa de abajo»");
            return;
        }
        if (force || autoOrigin) {
            params.px = c[0];
            params.py = c[1];
            mark.invalidate();
        }
    }

    private View sliderRow(final int i, final Fx.Slider s) {
        LinearLayout row = new LinearLayout(act);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView lab = new TextView(act);
        lab.setText(s.label);
        lab.setTextColor(0xFFEEEEEE);
        lab.setTextSize(13f);
        lab.setMinWidth(dp(92));
        final TextView val = new TextView(act);
        val.setTextColor(Color.WHITE);
        val.setTextSize(13f);
        val.setGravity(Gravity.END);
        val.setMinWidth(dp(52));
        val.setText(params.v[i] + s.unit);
        SeekBar sb = new SeekBar(act);
        sb.setMax(s.max - s.min);
        sb.setProgress(params.v[i] - s.min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int v, boolean user) {
                if (!user) return;
                params.v[i] = v + s.min;
                val.setText(params.v[i] + s.unit);
                request(true);
            }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { request(false); }
        });
        row.addView(lab);
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(36), 1f));
        row.addView(val);
        return row;
    }

    // ------------------------------------------------------------------ vista previa

    /**
     * Pide una vista previa. Cada pedido sube la generacion; el calculo en curso ve que quedo
     * viejo y se corta, y los que estaban en cola se saltan. Solo se muestra el ultimo.
     */
    private void request(final boolean drag) {
        final FxSession s = session;
        if (s == null || closed) return;
        final int g = ++gen;
        final int id = cur;
        final Fx.P p = params.copy();
        worker.execute(new Runnable() {
            @Override public void run() {
                if (g != gen || closed) return;
                Fx.Job job = new Fx.Job() {
                    @Override public boolean cancelled() { return g != gen || closed; }
                    @Override public void progress(int pct) { }
                };
                // 1) rapida (arrastrando) o normal
                int level = drag ? FxSession.DRAG : FxSession.MAIN;
                if (!show(s, level, id, p, g, job, drag ? "Vista rápida" : "Vista previa")) return;
                if (drag) return;
                // 2) v8.59: al soltar, el resultado REAL (tamano real o casi) para mirar con zoom
                try {
                    if (!s.buildHi(job) || g != gen) return;
                    if (s.widthAt(FxSession.HI) <= s.widthAt(FxSession.MAIN)) return;
                    show(s, FxSession.HI, id, p, g, job, s.scaleAt(FxSession.HI) >= 0.999f ? "Resultado real" : "Alta calidad");
                } catch (Fx.Cancelled c) {
                    // se movio otra cosa: no pasa nada
                } catch (OutOfMemoryError e) {
                    s.setHiSide(0);
                }
            }
        });
    }

    /** Calcula y muestra un nivel. false si quedo viejo o fallo. */
    private boolean show(FxSession s, final int level, int id, Fx.P p, final int g, Fx.Job job, final String what) {
        long t0 = SystemClock.uptimeMillis();
        int[] px;
        try {
            px = s.renderAt(level, id, p, job);
        } catch (Fx.Cancelled c) {
            return false;
        } catch (OutOfMemoryError e) {
            return false;
        }
        if (g != gen || closed) return false;
        int w = s.widthAt(level), h = s.heightAt(level);
        final Bitmap bm = nextBuffer(level, w, h);
        if (bm == null) return false;
        bm.setPixels(px, 0, w, 0, 0, w, h);
        final long ms = SystemClock.uptimeMillis() - t0;
        ui.post(new Runnable() {
            @Override public void run() {
                if (closed || g != gen) return;
                preview.setImageBitmap(bm);
                applyMatrix();
                lastMs = ms;
                info.setText(what + " · " + ms + " ms" + (level == FxSession.HI ? " · pellizca para hacer zoom" : ""));
                mark.invalidate();
            }
        });
        return true;
    }

    /** Ajusta la imagen a la vista con el zoom y centro actuales (sin bordes vacios al hacer zoom). */
    private void applyMatrix() {
        if (preview.getDrawable() == null) return;
        int bw = preview.getDrawable().getIntrinsicWidth(), bh = preview.getDrawable().getIntrinsicHeight();
        int vw = preview.getWidth(), vh = preview.getHeight();
        if (bw <= 0 || bh <= 0 || vw <= 0 || vh <= 0) return;
        float fit = Math.min(vw / (float) bw, vh / (float) bh), sc = fit * zoom;
        float iw = bw * sc, ih = bh * sc;
        // centro limitado: con zoom no se ve fuera de la imagen
        float hx = vw / (2f * iw), hy = vh / (2f * ih);
        zcx = iw <= vw ? .5f : Math.max(hx, Math.min(1 - hx, zcx));
        zcy = ih <= vh ? .5f : Math.max(hy, Math.min(1 - hy, zcy));
        Matrix m = new Matrix();
        m.setScale(sc, sc);
        m.postTranslate(vw / 2f - zcx * iw, vh / 2f - zcy * ih);
        preview.setImageMatrix(m);
        mark.invalidate();
    }

    private void zoomAt(float x, float y, float z) {
        float[] pt = toImage(x, y);
        if (pt != null) { zcx = pt[0]; zcy = pt[1]; }
        zoom = z;
    }

    /** Punto de la vista -&gt; coordenadas 0..1 de la imagen (o null). */
    private float[] toImage(float x, float y) {
        if (preview.getDrawable() == null) return null;
        float[] pt = {x, y};
        Matrix inv = new Matrix();
        if (!preview.getImageMatrix().invert(inv)) return null;
        inv.mapPoints(pt);
        int bw = preview.getDrawable().getIntrinsicWidth(), bh = preview.getDrawable().getIntrinsicHeight();
        if (bw <= 0 || bh <= 0) return null;
        return new float[]{pt[0] / bw, pt[1] / bh};
    }

    /**
     * Dos dedos: zoom y mover. Un dedo: mueve el sol / sombra / centro si el filtro lo usa; si no,
     * mueve la vista cuando hay zoom. Doble toque: acercar o volver a ver todo.
     */
    private boolean touchPreview(MotionEvent e) {
        scaler.onTouchEvent(e);
        taps.onTouchEvent(e);
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_POINTER_DOWN) multi = true;
        if (a == MotionEvent.ACTION_DOWN) multi = false;
        float x = 0, y = 0;
        int n = e.getPointerCount();
        for (int i = 0; i < n; i++) { x += e.getX(i); y += e.getY(i); }
        x /= n; y /= n;
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN || a == MotionEvent.ACTION_POINTER_UP) {
            lastX = x; lastY = y;
            return true;
        }
        if (multi || (Fx.spec(cur).point == null && zoom > 1.01f)) {
            if (a == MotionEvent.ACTION_MOVE && preview.getDrawable() != null) {
                int bw = preview.getDrawable().getIntrinsicWidth(), bh = preview.getDrawable().getIntrinsicHeight();
                float fit = Math.min(preview.getWidth() / (float) bw, preview.getHeight() / (float) bh);
                zcx -= (x - lastX) / (bw * fit * zoom);
                zcy -= (y - lastY) / (bh * fit * zoom);
                applyMatrix();
            }
            lastX = x; lastY = y;
            return true;
        }
        return touchPoint(e);
    }

    /** Tres bitmaps por nivel en rueda: nunca se escribe en el que se esta mostrando. */
    private Bitmap nextBuffer(int level, int w, int h) {
        try {
            int k = bufIdx[level] = (bufIdx[level] + 1) % 3;
            Bitmap b = bufs[level][k];
            if (b == null || b.getWidth() != w || b.getHeight() != h) {
                b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                bufs[level][k] = b;
            }
            return b;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    private void showOriginal() {
        final FxSession s = session;
        if (s == null) return;
        final int g = ++gen;
        worker.execute(new Runnable() {
            @Override public void run() {
                if (g != gen || closed) return;
                int[] px = s.original(false);
                final Bitmap bm = nextBuffer(0, s.width(false), s.height(false));
                if (bm == null) return;
                bm.setPixels(px, 0, s.width(false), 0, 0, s.width(false), s.height(false));
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (closed || g != gen) return;
                        preview.setImageBitmap(bm);
                        applyMatrix();
                        info.setText("Antes (sin el filtro)");
                    }
                });
            }
        });
    }

    /** v8.82: muestra solo los filtros del grupo y pide sus miniaturas. */
    private void setCategory(int k) {
        cat = k;
        prefs.edit().putInt("fx_cat", k).apply();
        paintCategory();
        if (session != null) makeThumbs();
    }

    private void paintCategory() {
        for (int k = 0; k < catChips.length; k++) {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(15));
            g.setColor(k == cat ? 0xFF2F6BD8 : 0xFF2C2C34);
            catChips[k].setBackground(g);
        }
        for (int id = 0; id < Fx.COUNT; id++) {
            if (cells[id] == null) continue;
            cells[id].setVisibility(cat == 0 || Fx.category(id) == cat ? View.VISIBLE : View.GONE);
        }
    }

    private void makeThumbs() {
        final FxSession s = session;
        if (s == null) return;
        for (final int id : Fx.ORDER) {
            // solo las del grupo que se ve (las otras se hacen al abrir su grupo)
            if (thumbAsked[id] || (cat != 0 && Fx.category(id) != cat)) continue;
            thumbAsked[id] = true;
            worker.execute(new Runnable() {
                @Override public void run() {
                    if (closed) return;
                    try {
                        int[] dims = new int[2];
                        int[] px = s.thumb(id, Math.max(48, dp(58)), dims);
                        final Bitmap b = Bitmap.createBitmap(px, dims[0], dims[1], Bitmap.Config.ARGB_8888);
                        ui.post(new Runnable() {
                            @Override public void run() { if (!closed) thumbs[id].setImageBitmap(b); }
                        });
                    } catch (Throwable ignored) { }
                }
            });
        }
    }

    /** Tocar / arrastrar en la imagen: mueve el sol, la sombra o el centro. */
    private boolean touchPoint(MotionEvent e) {
        Fx.Spec sp = Fx.spec(cur);
        if (sp.point == null || preview.getDrawable() == null) return false;
        float[] pt = {e.getX(), e.getY()};
        Matrix inv = new Matrix();
        if (!preview.getImageMatrix().invert(inv)) return false;
        inv.mapPoints(pt);
        int bw = preview.getDrawable().getIntrinsicWidth(), bh = preview.getDrawable().getIntrinsicHeight();
        if (bw <= 0 || bh <= 0) return false;
        // v8.80: el origen de los rayos puede quedar un poco fuera del lienzo (luz que entra de afuera)
        boolean out = cur == Fx.RAYS || cur == Fx.FOCUS_LINES;
        float lo = out ? -0.5f : 0f, hi = out ? 1.5f : 1f;
        params.px = Math.max(lo, Math.min(hi, pt[0] / bw));
        params.py = Math.max(lo, Math.min(hi, pt[1] / bh));
        if (cur == Fx.RAYS) autoOrigin = false;
        mark.invalidate();
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) request(false);
        else request(true);
        return true;
    }

    /** Circulo en el punto elegido (sol, centro o hacia donde cae la sombra). */
    private final class PointMark extends View {
        private final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);

        PointMark() {
            super(act);
            setWillNotDraw(false);
        }

        @Override protected void onDraw(Canvas c) {
            Fx.Spec sp = Fx.spec(cur);
            if (sp.point == null || preview.getDrawable() == null) return;
            int bw = preview.getDrawable().getIntrinsicWidth(), bh = preview.getDrawable().getIntrinsicHeight();
            float[] pt = {params.px * bw, params.py * bh};
            preview.getImageMatrix().mapPoints(pt);
            pen.setStyle(Paint.Style.STROKE);
            pen.setStrokeWidth(dp(3));
            pen.setColor(0xFF000000);
            c.drawCircle(pt[0], pt[1], dp(13), pen);
            pen.setStrokeWidth(dp(1.6f));
            boolean sun = cur == Fx.INFLATE || cur == Fx.RAYS;
            pen.setColor(sun ? 0xFFFFD54F : 0xFFFFFFFF);
            c.drawCircle(pt[0], pt[1], dp(13), pen);
            if (sun) {
                pen.setStyle(Paint.Style.FILL);
                c.drawCircle(pt[0], pt[1], dp(5), pen);
            }
            if (cur == Fx.RAYS) {
                // rayitos cortos: es el origen de la luz (solo en pantalla, nunca en la obra)
                pen.setStyle(Paint.Style.STROKE);
                pen.setStrokeWidth(dp(2));
                for (int k = 0; k < 8; k++) {
                    double a = Math.PI * k / 4;
                    float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                    pen.setColor(0xFF000000);
                    c.drawLine(pt[0] + ca * dp(17), pt[1] + sa * dp(17), pt[0] + ca * dp(24), pt[1] + sa * dp(24), pen);
                    pen.setColor(0xFFFFD54F);
                    c.drawLine(pt[0] + ca * dp(17.5f), pt[1] + sa * dp(17.5f), pt[0] + ca * dp(23.5f), pt[1] + sa * dp(23.5f), pen);
                }
            }
        }
    }

    // ------------------------------------------------------------------ aplicar a tamano real

    private void applyFull() {
        if (session == null) { toast("Espera la vista previa"); return; }
        final int id = cur;
        final Fx.P p = params.copy();
        final boolean asNew = newLayerBox.isChecked();
        final long n = (long) project.w * project.h;
        if (!canvas.fxMemory(n * 4L * 7L)) toast("Poca memoria: puede tardar o no alcanzar");
        gen++;   // corta la vista previa en curso
        final boolean[] cancel = new boolean[1];
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(4));
        final TextView msg = new TextView(act);
        msg.setTextColor(Color.WHITE);
        msg.setText(Fx.NAMES[id] + " a tamaño real (" + project.w + "x" + project.h + ")...");
        final ProgressBar bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        box.addView(msg);
        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        final AlertDialog prog = new AlertDialog.Builder(act).setView(box).setCancelable(false)
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { cancel[0] = true; }
                }).show();
        final long t0 = SystemClock.uptimeMillis();
        final FxSession s = session;
        final int[] ready = s.fullCached(id, p);
        new Thread(new Runnable() {
            @Override public void run() {
                int[] res = ready;
                String err = null;
                if (res == null) try {
                    res = s.full(id, p, new Fx.Job() {
                        @Override public boolean cancelled() { return cancel[0]; }
                        @Override public void progress(final int pct) {
                            ui.post(new Runnable() { @Override public void run() { bar.setProgress(pct); } });
                        }
                    });
                } catch (Fx.Cancelled c) {
                    err = "Cancelado: no cambió nada";
                } catch (OutOfMemoryError e) {
                    err = "No alcanzó la memoria del teléfono: no cambió nada";
                } catch (Throwable t) {
                    err = "No se pudo aplicar: " + t.getMessage();
                }
                final int[] r = res;
                final String e2 = err;
                final long ms = SystemClock.uptimeMillis() - t0;
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { prog.dismiss(); } catch (Throwable ignored) { }
                        if (e2 != null) { toast(e2); return; }
                        if (Fx.makesLayer(id)) {
                            // v8.80: capa de efecto aparte (la capa elegida no cambia)
                            if (GodRays.isEmpty(r)) {
                                toast(id == Fx.RAYS ? (p.opt ? "La capa de abajo no tiene nada que dé luz: no se creó ninguna capa"
                                        : "Esta capa no tiene nada que dé luz: no se creó ninguna capa")
                                        : "El efecto quedó vacío: no se creó ninguna capa");
                                return;
                            }
                            if (!canvas.fxAddEffectLayer(target, r, Fx.NAMES[id], Fx.layerMode(id, p),
                                    s.placeBelow(id, p))) return;
                        } else {
                            canvas.fxCommit(target, r, asNew, Fx.NAMES[id]);
                        }
                        toast(Fx.NAMES[id] + " listo en " + Math.max(1, ms / 100) / 10f + " s");
                        close();
                    }
                });
            }
        }, "pz-filtro").start();
    }

    // ------------------------------------------------------------------ cerrar

    private void close() {
        if (dlg != null && dlg.isShowing()) {
            try { dlg.dismiss(); } catch (Throwable ignored) { }
        } else {
            release();
        }
    }

    private void release() {
        if (closed) return;
        closed = true;
        gen++;
        worker.shutdownNow();
        canvas.setCompactHold(false);
        final FxSession s = session;
        session = null;
        if (s != null) s.release();
        preview.setImageDrawable(null);
        for (Bitmap[] lvl : bufs)
            for (int k = 0; k < lvl.length; k++) lvl[k] = null;   // los suelta el recolector (pueden seguir en uso un instante)
        fireAfterClose();
    }

    private void toast(String s) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show();
    }
}
