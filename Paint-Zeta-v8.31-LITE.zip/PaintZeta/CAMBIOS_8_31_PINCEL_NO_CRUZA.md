# Paint Zeta v8.31 — Pincel de Borrar fondo sin cruzar la línea, sin anillo gris, más simple

Versión 8.31 (versionCode 69). Base: v8.30.

- No se quitó ninguna función: los Ajustes de Borrar fondo pasaron de la barra al Menú.
- No se tocó GitHub ni el flujo de GitHub Actions.
- Pruebas en un servidor con Android simulado. **No es un teléfono.**

## 1. Qué cambia para ti

- **Barra de Borrar fondo con 5 iconos:** Balde, Pincel, Restaurar, Escoba y Ojo. Abajo quedan el tamaño y la suavidad (◐).
- **Sin icono de Ajustes.** En tu teléfono estaban en 55/78 y con eso el pincel cruzaba más. Al instalar vuelven solos a los de fábrica (46/42). Quien los quiera cambiar los tiene en Menú > «Borrar fondo: ajustes avanzados».
- **El pincel ya no cruza la línea:**
  - Puede seguir la línea, pero no pasa por los cortes de la línea al otro lado.
  - No entra al blanco del pelo del manga por las puntas abiertas de los mechones.
  - Si empiezas a pasar el dedo sobre el personaje, junto a algo ya borrado del otro lado de la línea, no borra nada hasta que vuelvas al fondo.
- **Sin anillo gris alrededor de lo borrado:** el borde que deja el dedo en medio del fondo queda limpio. Solo junto a la línea se limpia el filo.
- **El pincel sigue el fondo que cambia poco a poco** (la cueva que se aclara debajo de la oreja), pero no salta al color del personaje.
- **Con fondo oscuro, la línea no se aclara ni se borra:** su borde oscuro se deja entero.

## 2. Qué estaba mal en tus capturas y qué se hizo

**Captura 2 (oreja y cabeza del duende, cueva oscura). CONFIRMADO con la prueba 1.** Se repitió pasando el dedo por el borde, a veces 6 px adentro del personaje.

- En v8.30 pasaba esto:
  - Se comía 275 px del personaje: el borde de abajo de la oreja y un hueco en la base.
  - Dejaba un anillo gris a medio borrar alrededor de lo borrado.
- Causas:
  1. En la cueva oscura el «refinado del filo» trataba la roca más oscura como si fuera borde del personaje: la dejaba a medias y casi negra (el anillo gris).
  2. El color del fondo nunca se actualizaba, porque toda la cueva parecía «tinta». Donde la cueva se aclaraba, el pincel dejaba de borrar.
  3. El borrado pasaba por los cortes de la línea fina de la oreja.

**Captura 1 (borde con puntas).**

- La prueba 2 (panza y taparrabo, piso marrón) no cruza en ninguna de las dos versiones cuando el dedo empieza en el fondo, como lo usa una persona.
- El taparrabo se borraba cuando el trazo EMPEZABA encima de él: el pincel toma el color donde pones el dedo.
- Ahora, si junto al dedo ya hay algo borrado del otro lado de la línea, no borra nada hasta que vuelvas al fondo.

**Manga (pelo). CONFIRMADO con la prueba 3.** En v8.30 el pincel se comía 2 093 px del pelo blanco. Ahora pierde 205 px: queda una manchita en un mechón muy abierto.

**Captura 3 (ventana de ajustes):** muy complicada y no se notaba la diferencia. Se sacó de la barra; ver la sección 1.

## 3. Resultados: 3 pruebas fuertes del pincel (v8.30 → v8.31)

Las tres con el pincel tamaño 20, dos pasadas, y ajustes de fábrica 46/42. Con 55/78 los resultados son parecidos y están en el archivo de resultados.

**1. Oreja y cabeza, cueva oscura**

- Personaje perdido: 275 px (260 lejos del borde) → **0 px**.
- Anillo gris o puntitos en el corte: 140 → **22**.
- Fondo que quedó por donde pasó el dedo: 1 325 → **146** de 7 961.
- Línea comida: 23 → **17** de 552.

**2. Panza y taparrabo, piso marrón**

- Personaje perdido: 14 → **11** px (0 lejos del borde en las dos).
- Fondo que quedó: 11 → **4** de 4 690.
- Línea comida: 52 → **42** de 1 520.

**3. Pelo y hombro del manga, papel blanco**

- Personaje perdido: **2 093 px** (1 304 lejos del borde, el pelo blanco) → **205 px** (90 lejos).
- Línea comida: 0 en las dos.
- Fondo que quedó por donde pasó el dedo: 2 165 → 2 845 de 20 201. Es el papel entre mechones muy juntos, que ahora no se toca a propósito.

**Personaje entero** (30 toques + pincel por todo el contorno + Escoba; misma prueba de v8.30, con la referencia corregida en el taparrabo):

- Duende: perdido 0,60 % → **0,55 %**; lejos del borde 0,25 % → **0,24 %**; fondo que queda 7,47 % → 7,66 %.
- Manga: 0,00 % en las dos.

**Toda la batería anterior pasa:** v8.22 a v8.30, con A-R, U-Z, el personaje entero, la suavidad y la Escoba. **Compilación sin SDK:** 633 clases sin errores (una menos que antes: el botón de Ajustes que salió de la barra).

Imágenes ANTES/AHORA en `docs/qa831/`. Salida completa en `docs/RESULTADOS_PRUEBAS_8_31.txt`.

## 4. Límites (dicho claro)

- **Papel entre mechones muy juntos:** el pincel y el toque no lo borran (huecos de menos de ~10 a 14 px entre líneas). Es a propósito, para no comerse el pelo blanco. Se quita tocando justo ahí con el Balde: los rincones chicos o finos sí se borran.
- **Empezar el trazo sobre el personaje en un lugar donde todavía no borraste nada:** el pincel toma ese color como fondo. Empieza siempre en el fondo. Restaurar lo arregla.
- **Rincones cerrados por líneas** (entre la cabeza y la oreja): el pincel entra por donde están abiertos al fondo, no saltando la línea.
- **No probado en un teléfono real.** En la app, Menú > «Medir rendimiento» da los tiempos de tu teléfono.

## 5. Para probar en el teléfono

1. Sube **Paint-Zeta-v8.31-LITE.zip** a GitHub y descarga el APK.
2. Abre el duende, Borrar fondo, Pincel. Empieza en la cueva y pasa el dedo pegado a la oreja y a la cabeza, pisando a veces la línea: no debe entrar a la piel ni dejar anillo gris.
3. Abre el manga y pasa el pincel junto al pelo: los mechones blancos deben quedar.
4. Toca el Balde en lo que quede y luego la Escoba.
