# Paint Zeta v8.60: Acabado profesional en Colorear

## Qué cambió
- **Colorear, paso 2 = "Acabado"** (antes "Sombra"). Un solo acabado, siempre el mismo:
  sombra de color (rosada en piel, lavanda en ropa y pelo), segunda sombra en huecos,
  sombra del flequillo sobre la frente, luz del lado del sol, luz de borde, pelo con
  degradado y brillo que sigue los mechones, iris con degradado, rubor suave, líneas de
  color, resplandor y tinte suaves.
- **Controles**: ☀ Sol (arrastra con un dedo; dos dedos siguen moviendo y ampliando),
  Fuerza (0 a 100), Sombra + y Luz + (pinceles que corrigen la luz SIN salirse de la parte),
  Mancha (toca una manchita y se va), Antes (mantener pulsado), ↶ (deshace el último
  retoque), Líneas: color / negras, ✕ (cancela, la capa vuelve igual) y ✓ (aplica).
- Con o sin referencia de color: el acabado usa los colores que pusiste en el paso 1.
- **No crea capas nuevas**: va en "Color zonas". Deshacer quita todo el acabado de una vez.
- Las partes guardan el acabado: si después cambias el color de una parte, sale con su acabado.

## Por qué antes salían manchas
La sombra era la forma de la parte corrida unos píxeles (sí/no). Eso daba escalones, bandas
y manchas alrededor de los ojos. Ahora cada parte se trata como una almohada (volumen
calculado), el sol la ilumina y el borde de la sombra se suaviza a 1–2 píxeles. Los huecos
chicos (ojos, boca) se tapan solo para calcular el volumen, y las islitas se quitan.

## Otros arreglos pendientes que entraron
- **Relleno**: la vista previa muestra el color real (antes iba medio transparente y al
  aplicar salía más fuerte). Si va a una capa en Multiplicar, la vista previa también multiplica.
- **Herramientas repetidas**: se quitó "Lápiz" (es la punta "Lápiz digital" en Tipo de pincel)
  y "Manga" (Colorear prepara las mismas capas; sus opciones siguen en la barra del balde).
- Los hilos de vista previa ya no quedan vivos al cerrar una obra.

## Qué no cambió
Borrar fondo, IA, Mejorar imagen, Filtros, Luz, Estilo, Toques, capas y pinceles.
Estilo y Luz siguen igual de lentos que en la 8.59 (pendiente aparte).

## Cómo probarlo
1. Abre un B/N, Herramientas > 1 Colorear, pinta las partes (paso 1).
2. Toca "2 Acabado": espera "Preparando el acabado...".
3. Arrastra el sol alrededor del dibujo. Mueve Fuerza.
4. Sombra + / Luz + con trazos rápidos y grandes: no deben salir de la parte.
5. Mantén "Antes". Prueba ✕ (vuelve igual) y luego ✓ y Deshacer.
6. Paso 3 > Cambiar una parte: cambia un color; debe salir con acabado.
