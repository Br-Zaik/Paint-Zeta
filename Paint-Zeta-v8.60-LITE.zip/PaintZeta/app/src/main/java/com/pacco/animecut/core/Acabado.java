package com.pacco.animecut.core;

import java.util.ArrayList;
import java.util.List;

/**
 * v8.60 ACABADO (Java puro, sin Android: se prueba en PC).
 *
 * Toma las zonas de "Colorear" (mascara + color base que eligio la usuaria) y el dibujo de tinta,
 * y hace el acabado de ilustracion: sombra de color, segunda sombra en huecos, sombra del pelo
 * sobre la cara, luces, luz de borde, pelo con degradado y brillo que sigue los mechones, ojos,
 * rubor, lineas de color, resplandor y tinte. Todo queda DENTRO de la mascara de cada zona.
 *
 * Por que antes salian manchas: la sombra era la mascara de la zona corrida unos pixeles (si/no),
 * con escalones y sin volumen. Ahora cada zona es una "almohada": se resuelve la ecuacion de
 * Poisson dentro de la zona (Ink-and-Ray, Sykora et al. 2014) a resolucion reducida, su raiz da
 * un perfil redondo SIN la cresta del eje medio, de ahi salen normales suaves; el sol da
 * s = n.L y el corte de luz/sombra es un smoothstep de ~1,5 px a resolucion final. Las islitas se
 * quitan antes del corte. La sombra del pelo usa una distancia con signo (transformada de
 * distancia de Felzenszwalb-Huttenlocher) muestreada con bilineal: borde liso.
 *
 * La vista previa y el resultado final son LA MISMA cuenta a resolucion completa (no hay otro
 * camino). Lo que no depende del sol (volumen, lineas, pelo, sombras con signo) se calcula una sola
 * vez en {@link Session}; al mover el sol solo se rehace s = n.L, el corte y la mezcla.
 *
 * Nota honesta: el inflado 2D no entiende anatomia; los pinceles Mas sombra / Mas luz y Quitar
 * mancha estan para corregir. Las detecciones de pelo, cara y ojos son reglas simples y, si no
 * hay seguridad, ese paso se OMITE.
 */
public final class Acabado {
    private Acabado() { }

    /** Lo que mueve la usuaria. */
    public static final class Params {
        /** Sol en coordenadas 0..1 de la imagen (puede quedar afuera, -0.5..1.5). */
        public float sunX = 0.15f, sunY = 0.05f;
        /** 0..100: fuerza de sombras y luces. */
        public int strength = 60;
        /** Lineas de color (marron en piel, tono oscuro del pelo...). false = negras como estan. */
        public boolean colorLines = true;

        public Params copy() {
            Params p = new Params();
            p.sunX = sunX; p.sunY = sunY; p.strength = strength; p.colorLines = colorLines;
            return p;
        }
    }

    public interface Cancel { boolean cancelled(); }

    /** Se lanza si la vista previa quedo vieja (se movio el sol otra vez). */
    public static final class Cancelled extends RuntimeException {
        public Cancelled() { super(null, null, false, false); }
    }

    static boolean DBG = false;
    static final Cancel NEVER = new Cancel() { public boolean cancelled() { return false; } };

    // ==================================================================================== util

    static float smooth(float e0, float e1, float x) {
        if (e1 <= e0) return x < e0 ? 0f : 1f;
        float t = (x - e0) / (e1 - e0);
        t = t < 0f ? 0f : t > 1f ? 1f : t;
        return t * t * (3f - 2f * t);
    }

    static float clamp01(float v) { return v < 0f ? 0f : v > 1f ? 1f : v; }

    static int clampi(int v, int a, int b) { return v < a ? a : v > b ? b : v; }

    /** Percentil q de un histograma de 256. */
    static int pct(int[] hist, int n, float q) {
        int lim = Math.max(1, Math.round(n * q)), s = 0;
        for (int i = 0; i < 256; i++) { s += hist[i]; if (s >= lim) return i; }
        return 255;
    }

    // ------------------------------------------------------------------ transformada de distancia
    private static final float INF = 1e20f;

    /** Una pasada 1D de Felzenszwalb-Huttenlocher (distancia al cuadrado). */
    private static void dt1(float[] f, int n, float[] d, int[] v, float[] z) {
        int k = 0;
        v[0] = 0;
        z[0] = -INF;
        z[1] = INF;
        for (int q = 1; q < n; q++) {
            if (f[q] >= INF) continue;
            if (f[v[k]] >= INF) { v[k] = q; continue; }
            float s;
            while (true) {
                int p = v[k];
                s = ((f[q] + q * (float) q) - (f[p] + p * (float) p)) / (2f * (q - p));
                if (s <= z[k] && k > 0) { k--; continue; }
                break;
            }
            k++;
            v[k] = q;
            z[k] = s;
            z[k + 1] = INF;
        }
        if (f[v[0]] >= INF) { for (int q = 0; q < n; q++) d[q] = INF; return; }
        k = 0;
        for (int q = 0; q < n; q++) {
            while (z[k + 1] < q) k++;
            int p = v[k];
            d[q] = (q - p) * (float) (q - p) + f[p];
        }
    }

    /**
     * Distancia euclidea exacta (en pixeles) de cada celda a la celda "semilla" mas cercana.
     * seed[i] != 0 = semilla. Sin semillas: todo INF.
     */
    public static float[] edt(boolean[] seed, int w, int h) {
        float[] g = new float[w * h];
        for (int i = 0; i < g.length; i++) g[i] = seed[i] ? 0f : INF;
        int m = Math.max(w, h);
        float[] f = new float[m], d = new float[m], z = new float[m + 1];
        int[] v = new int[m];
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) f[y] = g[y * w + x];
            dt1(f, h, d, v, z);
            for (int y = 0; y < h; y++) g[y * w + x] = d[y];
        }
        for (int y = 0; y < h; y++) {
            int o = y * w;
            for (int x = 0; x < w; x++) f[x] = g[o + x];
            dt1(f, w, d, v, z);
            for (int x = 0; x < w; x++) g[o + x] = d[x] >= INF ? INF : (float) Math.sqrt(d[x]);
        }
        return g;
    }

    // ------------------------------------------------------------------ desenfoque de caja (3 pasadas ~ gauss)
    static void blur(float[] a, int w, int h, float sigma) {
        if (sigma < 0.5f) return;
        int r = Math.max(1, Math.round(sigma * 0.95f));
        for (int k = 0; k < 3; k++) ZoneTone.box(a, w, h, r);
    }

    /** Desenfoque que solo promedia celdas 'in' (no oscurece el borde con lo de afuera). */
    static void blurMasked(float[] a, boolean[] in, int w, int h, float sigma) {
        if (sigma < 0.5f) return;
        float[] wt = new float[a.length];
        for (int i = 0; i < a.length; i++) { if (in[i]) wt[i] = 1f; else a[i] = 0f; }
        blur(a, w, h, sigma);
        blur(wt, w, h, sigma);
        for (int i = 0; i < a.length; i++) if (in[i] && wt[i] > 1e-4f) a[i] /= wt[i];
    }

    // ------------------------------------------------------------------ Poisson (inflado)
    /**
     * Resuelve -lap(f) = 1 dentro de 'in' con f = 0 afuera (SOR). Arranca de una estimacion por
     * distancia, asi bastan pocas vueltas aun en 200x200.
     */
    static float[] poisson(boolean[] in, int w, int h, Cancel c) {
        float[] d = edtInside(in, w, h);
        float dm = 1f;
        for (int i = 0; i < d.length; i++) if (in[i] && d[i] > dm) dm = d[i];
        float[] f = new float[w * h];
        for (int i = 0; i < f.length; i++) if (in[i]) f[i] = d[i] * (2f * dm - d[i]) / 3f;
        int iters = Math.max(60, Math.min(260, (int) (dm * 6f)));
        float om = 1.85f;
        for (int it = 0; it < iters; it++) {
            if ((it & 15) == 0 && c.cancelled()) throw new Cancelled();
            for (int y = 1; y < h - 1; y++) {
                int o = y * w;
                for (int x = 1; x < w - 1; x++) {
                    int i = o + x;
                    if (!in[i]) continue;
                    float nb = f[i - 1] + f[i + 1] + f[i - w] + f[i + w];
                    float gs = (nb + 1f) * 0.25f;
                    f[i] += om * (gs - f[i]);
                }
            }
        }
        return f;
    }

    /** Distancia de cada celda de 'in' al afuera (0 afuera). El borde de la caja cuenta como afuera. */
    static float[] edtInside(boolean[] in, int w, int h) {
        boolean[] out = new boolean[in.length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                out[i] = !in[i] || x == 0 || y == 0 || x == w - 1 || y == h - 1;
            }
        float[] d = edt(out, w, h);
        for (int i = 0; i < d.length; i++) if (d[i] >= INF) d[i] = 0f;
        return d;
    }

    /**
     * Normales (nx, ny, nz) de la almohada h = sqrt(f/fmax). Se escalan con el radio para que
     * un circulo de cualquier tamano de una esfera. Las celdas de afuera copian a sus vecinas
     * (para que el bilineal en el borde no traiga normales planas).
     */
    static float[][] normals(float[] f, boolean[] in, int w, int h) {
        float fm = 1e-6f;
        for (int i = 0; i < f.length; i++) if (in[i] && f[i] > fm) fm = f[i];
        float[] hh = new float[f.length];
        for (int i = 0; i < f.length; i++) hh[i] = in[i] ? (float) Math.sqrt(Math.max(0f, f[i]) / fm) : 0f;
        float rp = 2f * (float) Math.sqrt(fm);
        float[] nx = new float[f.length], ny = new float[f.length], nz = new float[f.length];
        boolean[] done = new boolean[f.length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (!in[i]) { nz[i] = 1f; continue; }
                float l = x > 0 ? hh[i - 1] : 0f, r = x < w - 1 ? hh[i + 1] : 0f;
                float u = y > 0 ? hh[i - w] : 0f, dn = y < h - 1 ? hh[i + w] : 0f;
                float gx = (r - l) * 0.5f * rp, gy = (dn - u) * 0.5f * rp;
                float gm = (float) Math.hypot(gx, gy);
                if (gm > 3.2f) { gx *= 3.2f / gm; gy *= 3.2f / gm; }
                float inv = 1f / (float) Math.sqrt(gx * gx + gy * gy + 1f);
                nx[i] = -gx * inv; ny[i] = -gy * inv; nz[i] = inv;
                done[i] = true;
            }
        // afuera: copiar de las vecinas (2 vueltas)
        for (int pass = 0; pass < 2; pass++) {
            boolean[] nd = done.clone();
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int i = y * w + x;
                    if (done[i]) continue;
                    float sx = 0, sy = 0, sz = 0;
                    int n = 0;
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx, yy = y + dy;
                            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                            int j = yy * w + xx;
                            if (!done[j]) continue;
                            sx += nx[j]; sy += ny[j]; sz += nz[j]; n++;
                        }
                    if (n == 0) continue;
                    float m = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
                    if (m < 1e-6f) continue;
                    nx[i] = sx / m; ny[i] = sy / m; nz[i] = sz / m;
                    nd[i] = true;
                }
            done = nd;
        }
        return new float[][]{nx, ny, nz, hh};
    }

    // ------------------------------------------------------------------ hilos
    private static final int THREADS = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
    private static java.util.concurrent.ExecutorService pool;

    interface Rows { void run(int y0, int y1); }

    static synchronized java.util.concurrent.ExecutorService pool() {
        if (pool == null) {
            pool = java.util.concurrent.Executors.newFixedThreadPool(THREADS, new java.util.concurrent.ThreadFactory() {
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "pz-acabado");
                    t.setDaemon(true);
                    return t;
                }
            });
        }
        return pool;
    }

    /** Reparte filas [0,h) entre los hilos y espera. */
    static void parallel(int h, final Rows body) {
        int n = Math.min(THREADS, Math.max(1, h / 32));
        if (n <= 1) { body.run(0, h); return; }
        final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(n);
        final Throwable[] err = new Throwable[1];
        int step = (h + n - 1) / n;
        for (int k = 0; k < n; k++) {
            final int a = k * step, b = Math.min(h, a + step);
            pool().execute(new Runnable() {
                public void run() {
                    try { if (a < b) body.run(a, b); }
                    catch (Throwable t) { synchronized (err) { if (err[0] == null) err[0] = t; } }
                    finally { done.countDown(); }
                }
            });
        }
        try { done.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new Cancelled(); }
        if (err[0] instanceof RuntimeException) throw (RuntimeException) err[0];
        if (err[0] instanceof Error) throw (Error) err[0];
    }

    // ==================================================================================== colores

    /** Colores del acabado para un color base (sRGB 0..1). */
    static final class Pal {
        float[] base, s1, s2, light, rim, line, ring;
        boolean skin, dark, neutral;
    }

    static float[] rgb(int c) { return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f}; }

    static int lab(float L, float C, float hue) {
        return ZoneTone.fromOklab(Math.max(0f, Math.min(1f, L)), C * (float) Math.cos(hue), C * (float) Math.sin(hue));
    }

    /** Gira el tono 'h' hacia 'target' (radianes) como mucho 'amt' radianes. */
    static float toward(float h, float target, float amt) {
        float d = (float) Math.atan2(Math.sin(target - h), Math.cos(target - h));
        if (Math.abs(d) <= amt) return target;
        return h + Math.signum(d) * amt;
    }

    /** Piel: tono calido (entre rojo y amarillo), croma moderado y claro. */
    static boolean isSkin(int c) {
        float[] k = ZoneTone.oklab(c);
        float C = (float) Math.hypot(k[1], k[2]);
        float hue = (float) Math.toDegrees(Math.atan2(k[2], k[1]));
        return k[0] > 0.55f && k[0] < 0.97f && C > 0.018f && C < 0.115f && hue > 18f && hue < 80f;
    }

    static Pal palette(int base) {
        Pal p = new Pal();
        float[] k = ZoneTone.oklab(base);
        float L = k[0], C = (float) Math.hypot(k[1], k[2]);
        float h = (float) Math.atan2(k[2], k[1]);
        final float VIOLET = (float) Math.toRadians(305), RED = (float) Math.toRadians(22), WARM = (float) Math.toRadians(85);
        p.skin = isSkin(base);
        p.dark = L < 0.38f;
        p.neutral = C < 0.03f;
        p.base = rgb(base);
        int s1, s2, li, line;
        if (p.skin) {
            // piel: sombra rojiza/rosada (nunca gris)
            s1 = lab(L * 0.87f, Math.max(C * 1.30f, 0.045f), toward(h, RED, (float) Math.toRadians(14)));
            s2 = lab(L * 0.74f, Math.max(C * 1.45f, 0.06f), toward(h, RED, (float) Math.toRadians(24)));
            li = lab(L + (1f - L) * 0.55f, C * 0.75f, toward(h, WARM, (float) Math.toRadians(8)));
            line = lab(Math.max(0.24f, L * 0.42f), Math.max(0.05f, C * 0.95f), toward(h, RED, (float) Math.toRadians(10)));
        } else if (p.neutral) {
            // blanco, gris, negro: sombra lavanda/azulada
            float ls = L > 0.8f ? L * 0.83f : L * 0.78f;
            s1 = lab(ls, 0.035f + C * 0.5f, VIOLET - (float) Math.toRadians(25));
            s2 = lab(ls * 0.82f, 0.045f + C * 0.5f, VIOLET);
            li = lab(Math.min(1f, L + (1f - L) * 0.5f + 0.02f), C * 0.5f + 0.01f, WARM);
            line = lab(Math.max(0.16f, L * 0.35f), 0.03f, VIOLET - (float) Math.toRadians(20));
        } else {
            float dl = p.dark ? 0.72f : 0.80f;
            s1 = lab(L * dl, C * 1.12f + 0.012f, toward(h, VIOLET, (float) Math.toRadians(16)));
            s2 = lab(L * dl * 0.80f, C * 1.2f + 0.015f, toward(h, VIOLET, (float) Math.toRadians(28)));
            li = lab(L + (1f - L) * (p.dark ? 0.32f : 0.45f), C * 0.9f, toward(h, WARM, (float) Math.toRadians(8)));
            line = lab(Math.max(0.12f, L * 0.38f), Math.max(0.03f, C * 0.9f), toward(h, RED, (float) Math.toRadians(8)));
        }
        p.s1 = rgb(s1);
        p.s2 = rgb(s2);
        p.light = rgb(li);
        float[] lr = rgb(li);
        p.rim = new float[]{lr[0] * 0.5f + 0.5f, lr[1] * 0.5f + 0.47f, lr[2] * 0.5f + 0.42f};
        p.line = rgb(line);
        // brillo del pelo: mas claro y tibio que la base, nunca blanco puro
        p.ring = rgb(lab(Math.min(0.97f, L + (1f - L) * 0.62f + 0.06f), C * 0.7f, toward(h, WARM, (float) Math.toRadians(10))));
        return p;
    }

    // ==================================================================================== sesion

    /** Una zona con todo lo que no depende del sol. */
    static final class ZCtx {
        int idx;
        ZoneTone.Zone z;
        int x0, y0, w, h;          // recuadro en la imagen (recortado)
        int f, gw, gh;             // celda de la grilla (pixeles) y tamano de la grilla
        boolean[] in;              // grilla: dentro de la zona
        float[] nx, ny, nz;        // normales combinadas (zona + personaje)
        float[] edit;              // Mas sombra / Mas luz (+ = mas luz)
        float[] dens;              // densidad de lineas normalizada (oclusion), grilla
        int area;
        boolean thin, bg, skin, hair, eye, face;
        int paper = 245, p50 = 245;
        boolean darkZone, author;
        float rpx;                 // radio aproximado en pixeles
        // sombra proyectada (solo piel con algo encima)
        float[] sdf; int sx0, sy0, sw, sh;
        // pelo
        float hairTop0, faceTop; boolean ring;
        int[] colTop;              // primera fila de pelo por columna (relativa)
        float[] licN;              // brillo en mechones (0..1) a resolucion completa del recuadro, o null
        // ojos
        float eyeCx, eyeCy, eyeRx, eyeRy;
    }

    public static final class Session {
        public final int W, H;
        final float D;
        final List<ZoneTone.Zone> zones;
        final int[] ref;
        final byte[] lum;          // gris del dibujo (0..255) en la caja de union
        final byte[] lineA;        // cuanto es linea (0..255) en la caja de union
        final boolean colored;
        int ux0, uy0, ux1, uy1, uw, uh;   // caja de union (+ margen)
        short[] owner;             // zona de arriba en cada pixel de la caja (+1), 0 = ninguna
        ZCtx[] ctx;
        // personaje
        float charCx, charCy;
        int cgf, cgw, cgh, cgx0, cgy0;
        float[] cnx, cny;          // normales del personaje (para la luz de borde)
        float[] dExt;              // distancia al exterior (caja de union), para la luz de borde
        int faceIdx = -1;
        final List<Integer> eyes = new ArrayList<Integer>();
        public int hairZones, skinZones;
        /** Solo pruebas: si no es null, guarda la sombra 1 de cada pixel (caja de union). */
        float[] dbgShadow;
        public long buildMs;
        /** Historial de retoques (para deshacer el ultimo dentro del Acabado). */
        private final ArrayList<float[][]> undoEdits = new ArrayList<float[][]>();

        /** Prepara todo lo que no depende del sol. Pesado: llamar fuera del hilo de la pantalla. */
        public Session(int[] ref, int W, int H, List<ZoneTone.Zone> zones, Cancel c) {
            long t0 = System.currentTimeMillis();
            if (c == null) c = NEVER;
            this.W = W; this.H = H; this.ref = ref;
            this.zones = new ArrayList<ZoneTone.Zone>(zones);
            D = (float) Math.sqrt((double) W * W + (double) H * H);
            colored = LineArt.isColored(ref);
            // caja de union
            int x0 = W, y0 = H, x1 = 0, y1 = 0;
            for (ZoneTone.Zone z : this.zones) {
                x0 = Math.min(x0, z.x); y0 = Math.min(y0, z.y);
                x1 = Math.max(x1, z.x + z.w); y1 = Math.max(y1, z.y + z.h);
            }
            int pad = 6;
            ux0 = Math.max(0, x0 - pad); uy0 = Math.max(0, y0 - pad);
            ux1 = Math.min(W, x1 + pad); uy1 = Math.min(H, y1 + pad);
            if (ux1 <= ux0 || uy1 <= uy0) { ux0 = uy0 = 0; ux1 = uy1 = 1; }
            uw = ux1 - ux0; uh = uy1 - uy0;
            int un = uw * uh;
            lum = new byte[un];
            lineA = new byte[un];
            owner = new short[un];
            for (int y = 0; y < uh; y++) {
                int gy = y + uy0, o = y * uw;
                for (int x = 0; x < uw; x++) lum[o + x] = (byte) ZoneTone.lum(ref[gy * W + x + ux0]);
            }
            int nz = this.zones.size();
            for (int k = 0; k < nz; k++) {
                ZoneTone.Zone z = this.zones.get(k);
                for (int y = 0; y < z.h; y++) {
                    int gy = y + z.y - uy0;
                    if (gy < 0 || gy >= uh) continue;
                    for (int x = 0; x < z.w; x++) {
                        if ((z.m[y * z.w + x] & 0xFF) < 128) continue;
                        int gx = x + z.x - ux0;
                        if (gx < 0 || gx >= uw) continue;
                        owner[gy * uw + gx] = (short) (k + 1);
                    }
                }
            }
            if (c.cancelled()) throw new Cancelled();
            ctx = new ZCtx[nz];
            long big = (long) W * H * 35 / 100;
            int[] ghist = new int[256];
            int gn = 0;
            for (int k = 0; k < nz; k++) {
                ZCtx q = new ZCtx();
                q.idx = k;
                q.z = this.zones.get(k);
                q.x0 = Math.max(0, q.z.x); q.y0 = Math.max(0, q.z.y);
                q.w = Math.min(W, q.z.x + q.z.w) - q.x0; q.h = Math.min(H, q.z.y + q.z.h) - q.y0;
                if (q.w <= 0 || q.h <= 0) { q.w = q.h = 0; ctx[k] = q; continue; }
                q.area = q.z.area();
                // fondo: muy grande, o grande y pegado a 2 o mas bordes de la imagen
                int sides = (q.z.x <= 1 ? 1 : 0) + (q.z.y <= 1 ? 1 : 0) + (q.z.x + q.z.w >= W - 1 ? 1 : 0) + (q.z.y + q.z.h >= H - 1 ? 1 : 0);
                q.bg = q.area > big || (sides >= 2 && q.area > (long) W * H * 8 / 100 && edgeShare(q.z, W, H) > 0.15f);
                q.skin = isSkin(q.z.s.base);
                // papel y grises propios de la zona
                int[] hist = new int[256];
                int cnt = 0;
                for (int y = 0; y < q.z.h; y++)
                    for (int x = 0; x < q.z.w; x++) {
                        if ((q.z.m[y * q.z.w + x] & 0xFF) < 128) continue;
                        int gx = x + q.z.x - ux0, gy = y + q.z.y - uy0;
                        if (gx < 0 || gy < 0 || gx >= uw || gy >= uh) continue;
                        int v = lum[gy * uw + gx] & 0xFF;
                        hist[v]++; cnt++;
                        ghist[v]++; gn++;
                    }
                if (cnt > 0) {
                    q.paper = Math.max(60, pct(hist, cnt, 0.97f));
                    q.p50 = pct(hist, cnt, 0.5f);
                }
                ctx[k] = q;
            }
            int gpaper = gn > 0 ? Math.max(120, pct(ghist, gn, 0.97f)) : 245;
            for (ZCtx q : ctx) {
                if (q.w == 0) continue;
                if (q.area < 400) q.paper = Math.max(q.paper, gpaper);
                q.darkZone = q.p50 < 95 && !colored;
                q.author = !q.darkZone && q.p50 < q.paper - 22;
            }
            // lineas: cuanto de linea tiene cada pixel (relativo al papel de su zona)
            for (int y = 0; y < uh; y++) {
                int o = y * uw;
                for (int x = 0; x < uw; x++) {
                    int ow = owner[o + x];
                    int P = ow > 0 ? ctx[ow - 1].paper : gpaper;
                    int v = lum[o + x] & 0xFF;
                    float hi = P * 0.60f, lo = P * 0.24f;
                    float a = clamp01((hi - v) / (hi - lo));
                    lineA[o + x] = (byte) Math.round(a * 255f);
                }
            }
            if (c.cancelled()) throw new Cancelled();
            buildCharacter(c);
            for (ZCtx q : ctx) if (q.w > 0) buildZone(q, c);
            findRoles();
            buildDensity(c);
            for (ZCtx q : ctx) if (q.w > 0 && q.skin && !q.bg) buildCast(q, c);
            for (ZCtx q : ctx) if (q.w > 0 && q.hair) buildHair(q, c);
            for (int e : eyes) buildEye(ctx[e]);
            buildMs = System.currentTimeMillis() - t0;
        }

        // ------------------------------------------------------------ personaje (silueta) y exterior
        private void buildCharacter(Cancel c) {
            // union de zonas que NO son fondo, cerrada (tapa las lineas entre zonas)
            boolean[] u = new boolean[uw * uh];
            long sx = 0, sy = 0, n = 0;
            for (int i = 0; i < u.length; i++) {
                int ow = owner[i];
                if (ow > 0 && !ctx[ow - 1].bg) { u[i] = true; sx += i % uw; sy += i / uw; n++; }
            }
            charCx = n > 0 ? ux0 + sx / (float) n : W * 0.5f;
            charCy = n > 0 ? uy0 + sy / (float) n : H * 0.5f;
            int r = Math.max(2, Math.round(D * 0.0025f));
            boolean[] closed = close(u, uw, uh, r);
            // exterior: lo que no es personaje y toca el borde de la caja
            boolean[] ext = new boolean[u.length];
            int[] q = new int[u.length];
            int qh = 0, qt = 0;
            for (int x = 0; x < uw; x++) { qt = seed(ext, closed, q, qt, x); qt = seed(ext, closed, q, qt, (uh - 1) * uw + x); }
            for (int y = 0; y < uh; y++) { qt = seed(ext, closed, q, qt, y * uw); qt = seed(ext, closed, q, qt, y * uw + uw - 1); }
            while (qh < qt) {
                int i = q[qh++], x = i % uw, y = i / uw;
                if (x > 0) qt = seed(ext, closed, q, qt, i - 1);
                if (x < uw - 1) qt = seed(ext, closed, q, qt, i + 1);
                if (y > 0) qt = seed(ext, closed, q, qt, i - uw);
                if (y < uh - 1) qt = seed(ext, closed, q, qt, i + uw);
            }
            dExt = edt(ext, uw, uh);
            if (c.cancelled()) throw new Cancelled();
            // normales del personaje (grilla)
            cgf = Math.max(1, (int) Math.ceil(Math.max(uw, uh) / 200f));
            cgw = (uw + cgf - 1) / cgf + 2; cgh = (uh + cgf - 1) / cgf + 2;
            cgx0 = ux0; cgy0 = uy0;
            boolean[] cin = new boolean[cgw * cgh];
            for (int gy = 1; gy < cgh - 1; gy++)
                for (int gx = 1; gx < cgw - 1; gx++) {
                    int cntIn = 0, cntAll = 0;
                    for (int yy = (gy - 1) * cgf; yy < Math.min(uh, gy * cgf); yy++)
                        for (int xx = (gx - 1) * cgf; xx < Math.min(uw, gx * cgf); xx++) {
                            cntAll++;
                            if (!ext[yy * uw + xx]) cntIn++;
                        }
                    cin[gy * cgw + gx] = cntAll > 0 && cntIn * 2 >= cntAll;
                }
            float[] f = poisson(cin, cgw, cgh, c);
            float[][] nn = normals(f, cin, cgw, cgh);
            cnx = nn[0]; cny = nn[1];
            cnz = nn[2];
        }

        float[] cnz;

        private int seed(boolean[] ext, boolean[] wall, int[] q, int qt, int i) {
            if (ext[i] || wall[i]) return qt;
            ext[i] = true;
            q[qt++] = i;
            return qt;
        }

        /** Normal del personaje en un pixel de la imagen (bilineal). */
        void charNormal(float px, float py, float[] out) {
            float gx = (px - cgx0 + 0.5f) / cgf - 0.5f + 1f, gy = (py - cgy0 + 0.5f) / cgf - 0.5f + 1f;
            out[0] = bil(cnx, cgw, cgh, gx, gy);
            out[1] = bil(cny, cgw, cgh, gx, gy);
            out[2] = bil(cnz, cgw, cgh, gx, gy);
        }

        // ------------------------------------------------------------ volumen de una zona
        private void buildZone(ZCtx q, Cancel c) {
            ZoneTone.Zone z = q.z;
            int side = Math.max(q.w, q.h);
            q.f = Math.max(1, (int) Math.ceil(side / 160f));
            int f = q.f;
            q.gw = (q.w + f - 1) / f + 2;
            q.gh = (q.h + f - 1) / f + 2;
            int gn = q.gw * q.gh;
            q.in = new boolean[gn];
            int cells = 0;
            for (int gy = 1; gy < q.gh - 1; gy++)
                for (int gx = 1; gx < q.gw - 1; gx++) {
                    int cntIn = 0, cntAll = 0;
                    for (int yy = (gy - 1) * f; yy < Math.min(q.h, gy * f); yy++)
                        for (int xx = (gx - 1) * f; xx < Math.min(q.w, gx * f); xx++) {
                            cntAll++;
                            int mx = xx + q.x0 - z.x, my = yy + q.y0 - z.y;
                            if ((z.m[my * z.w + mx] & 0xFF) >= 128) cntIn++;
                        }
                    boolean in = cntAll > 0 && cntIn * 2 >= cntAll;
                    q.in[gy * q.gw + gx] = in;
                    if (in) cells++;
                }
            q.edit = new float[gn];
            // para el VOLUMEN se tapan los huecos chicos (ojos, boca, lineas sueltas): si no, cada
            // hueco hace un "crater" y salen manchas alrededor de los ojos
            boolean[] vin = fillHoles(q.in, q.gw, q.gh, Math.max(4, Math.round(cells * 0.12f)));
            for (boolean b : vin) if (b) cells++;
            cells = 0;
            for (boolean b : vin) if (b) cells++;
            float[] f0 = cells > 0 ? poisson(vin, q.gw, q.gh, c) : new float[gn];
            float fm = 0f;
            for (int i = 0; i < gn; i++) if (vin[i] && f0[i] > fm) fm = f0[i];
            q.rpx = 2f * (float) Math.sqrt(Math.max(0f, fm)) * f;
            q.thin = cells < 10 || q.rpx < Math.max(4f, 0.006f * D);
            float[][] nn = normals(f0, vin, q.gw, q.gh);
            q.nx = nn[0]; q.ny = nn[1]; q.nz = nn[2];
            // combinar con la forma del personaje (las zonas finas usan solo la del personaje)
            float wc = q.thin ? 1f : 0.45f, wz = q.thin ? 0f : 1f;
            float[] cn = new float[3];
            for (int gy = 0; gy < q.gh; gy++)
                for (int gx = 0; gx < q.gw; gx++) {
                    int i = gy * q.gw + gx;
                    float px = q.x0 + (gx - 1 + 0.5f) * f - 0.5f, py = q.y0 + (gy - 1 + 0.5f) * f - 0.5f;
                    if (q.bg) { q.nx[i] = 0; q.ny[i] = 0; q.nz[i] = 1; continue; }
                    charNormal(px, py, cn);
                    float ax = q.nx[i] * wz + cn[0] * wc, ay = q.ny[i] * wz + cn[1] * wc, az = q.nz[i] * wz + cn[2] * wc;
                    float m = (float) Math.sqrt(ax * ax + ay * ay + az * az);
                    if (m < 1e-6f) { ax = 0; ay = 0; az = 1; m = 1; }
                    q.nx[i] = ax / m; q.ny[i] = ay / m; q.nz[i] = az / m;
                }
        }

        // ------------------------------------------------------------ pelo, cara, ojos (reglas simples)
        private void findRoles() {
            int cy0 = H, cy1 = 0;
            long charArea = 0;
            for (ZCtx q : ctx) if (q.w > 0 && !q.bg) { cy0 = Math.min(cy0, q.y0); cy1 = Math.max(cy1, q.y0 + q.h); charArea += q.area; }
            if (charArea == 0) return;
            int chH = Math.max(1, cy1 - cy0);
            // cara: la zona de piel mas grande en la mitad de arriba del personaje
            int face = -1;
            for (ZCtx q : ctx) {
                if (q.w == 0 || q.bg || !q.skin) continue;
                skinZones++;
                float cyz = q.y0 + q.h * 0.5f;
                if (cyz > cy0 + chH * 0.6f && chH > 0.5f * H) continue;
                if (face < 0 || q.area > ctx[face].area) face = q.idx;
            }
            // pelo: zonas no-piel cuyo tope esta entre lo mas alto del personaje y tocan la cara por arriba
            if (face >= 0) {
                ZCtx fz = ctx[face];
                fz.face = true;
                faceIdx = face;
                int best = -1;
                for (ZCtx q : ctx) {
                    if (q.w == 0 || q.bg || q.skin || q.idx == face) continue;
                    if (q.y0 > cy0 + chH * 0.18f + 2) continue;           // empieza arriba de todo
                    if (q.y0 >= fz.y0) continue;                          // empieza mas arriba que la cara
                    if (q.area < charArea * 0.02f && q.area < fz.area * 0.25f) continue;
                    if (!touches(q, fz, Math.max(4, Math.round(D * 0.004f)))) continue;
                    if (best < 0 || q.area > ctx[best].area) best = q.idx;
                }
                if (best >= 0) {
                    int hb = ctx[best].z.s.base;
                    for (ZCtx q : ctx)
                        if (q.w > 0 && !q.bg && !q.skin && (q.idx == best || (q.z.s.base == hb && touchesAny(q, best))))
                            { q.hair = true; hairZones++; }
                }
                // ojos: zonas chicas, casi elipticas, dentro de la cara (franja media)
                for (ZCtx q : ctx) {
                    if (q.w == 0 || q.bg || q.skin || q.hair || q.idx == face) continue;
                    if (q.area < Math.max(30, fz.area * 0.0015f) || q.area > fz.area * 0.06f) continue;
                    float cx = q.x0 + q.w * 0.5f, cyq = q.y0 + q.h * 0.5f;
                    if (cx < fz.x0 || cx > fz.x0 + fz.w) continue;
                    if (cyq < fz.y0 + fz.h * 0.15f || cyq > fz.y0 + fz.h * 0.78f) continue;
                    float asp = q.w / (float) q.h;
                    if (asp < 0.35f || asp > 2.4f) continue;
                    float fill = q.area / (float) (q.w * q.h);
                    if (fill < 0.45f) continue;
                    if (!touches(q, fz, Math.max(4, Math.round(D * 0.004f)))) continue;
                    eyes.add(q.idx);
                }
                if (eyes.size() > 2) {
                    // las dos mas grandes
                    java.util.Collections.sort(eyes, new java.util.Comparator<Integer>() {
                        public int compare(Integer a, Integer b) { return ctx[b].area - ctx[a].area; }
                    });
                    while (eyes.size() > 2) eyes.remove(eyes.size() - 1);
                }
                for (int e : eyes) ctx[e].eye = true;
            }
        }

        /** Las mascaras de a y b estan a menos de r pixeles en algun lugar (mira las mascaras, no el dueno). */
        private boolean touches(ZCtx a, ZCtx b, int r) {
            if (a.w == 0 || b.w == 0) return false;
            if (a.x0 > b.x0 + b.w + r || b.x0 > a.x0 + a.w + r || a.y0 > b.y0 + b.h + r || b.y0 > a.y0 + a.h + r) return false;
            ZoneTone.Zone za = a.z, zb = b.z;
            int step = Math.max(1, r / 2);
            for (int y = 0; y < za.h; y++)
                for (int x = 0; x < za.w; x++) {
                    if ((za.m[y * za.w + x] & 0xFF) < 128) continue;
                    boolean edge = x == 0 || y == 0 || x == za.w - 1 || y == za.h - 1
                            || (za.m[y * za.w + x - 1] & 0xFF) < 128 || (za.m[y * za.w + x + 1] & 0xFF) < 128
                            || (za.m[(y - 1) * za.w + x] & 0xFF) < 128 || (za.m[(y + 1) * za.w + x] & 0xFF) < 128;
                    if (!edge) continue;
                    int gx = x + za.x, gy = y + za.y;
                    for (int dy = -r; dy <= r; dy += step)
                        for (int dx = -r; dx <= r; dx += step) {
                            int bx = gx + dx - zb.x, by = gy + dy - zb.y;
                            if (bx < 0 || by < 0 || bx >= zb.w || by >= zb.h) continue;
                            if ((zb.m[by * zb.w + bx] & 0xFF) >= 128) return true;
                        }
                }
            return false;
        }

        private boolean touchesAny(ZCtx q, int other) { return touches(q, ctx[other], Math.max(4, Math.round(D * 0.004f))); }

        // ------------------------------------------------------------ oclusion por densidad de lineas
        private void buildDensity(Cancel c) {
            int fo = Math.max(1, (int) Math.ceil(Math.max(uw, uh) / 256f));
            int dw = (uw + fo - 1) / fo, dh = (uh + fo - 1) / fo;
            float[] d = new float[dw * dh];
            for (int y = 0; y < uh; y++)
                for (int x = 0; x < uw; x++) d[(y / fo) * dw + x / fo] += (lineA[y * uw + x] & 0xFF) / 255f;
            float inv = 1f / (fo * fo);
            for (int i = 0; i < d.length; i++) d[i] *= inv;
            blur(d, dw, dh, 0.01f * D / fo);
            if (c.cancelled()) throw new Cancelled();
            for (ZCtx q : ctx) {
                if (q.w == 0 || q.bg || q.thin) continue;
                q.dens = new float[q.gw * q.gh];
                int[] hist = new int[256];
                int n = 0;
                float mx = 1e-6f;
                for (int i = 0; i < d.length; i++) mx = Math.max(mx, d[i]);
                for (int gy = 0; gy < q.gh; gy++)
                    for (int gx = 0; gx < q.gw; gx++) {
                        int i = gy * q.gw + gx;
                        float px = q.x0 + (gx - 1 + 0.5f) * q.f - 0.5f - ux0, py = q.y0 + (gy - 1 + 0.5f) * q.f - 0.5f - uy0;
                        float v = bil(d, dw, dh, (px + 0.5f) / fo - 0.5f, (py + 0.5f) / fo - 0.5f);
                        q.dens[i] = v;
                        if (q.in[i]) { hist[Math.min(255, (int) (v / mx * 255f))]++; n++; }
                    }
                if (n == 0) { q.dens = null; continue; }
                float med = pct(hist, n, 0.5f) / 255f * mx, hi = pct(hist, n, 0.97f) / 255f * mx;
                if (hi - med < 0.02f) { q.dens = null; continue; }
                for (int i = 0; i < q.dens.length; i++) q.dens[i] = clamp01((q.dens[i] - med) / (hi - med));
            }
        }

        // ------------------------------------------------------------ sombra que echa el pelo (y la cara sobre el cuello)
        private void buildCast(ZCtx q, Cancel c) {
            // quien tapa: pelo; para el cuello, la cara
            boolean[] occ = new boolean[ctx.length];
            boolean any = false;
            for (ZCtx o : ctx) {
                if (o.w == 0 || o.idx == q.idx) continue;
                boolean use = o.hair || (o.face && !q.face && q.y0 + q.h * 0.5f > o.y0 + o.h * 0.5f && q.y0 > o.y0 + o.h * 0.4f);
                if (!use) continue;
                if (!touches(q, o, Math.max(4, Math.round(D * 0.004f)))) continue;
                occ[o.idx] = true;
                any = true;
            }
            if (!any) return;
            int len = Math.max(3, Math.round(0.03f * D));
            int x0 = Math.max(ux0, q.x0 - len - 4), y0 = Math.max(uy0, q.y0 - len - 4);
            int x1 = Math.min(ux1, q.x0 + q.w + len + 4), y1 = Math.min(uy1, q.y0 + q.h + len + 4);
            int w = x1 - x0, h = y1 - y0;
            if (w <= 2 || h <= 2) return;
            boolean[] in = new boolean[w * h];
            boolean[] out = new boolean[w * h];
            int grow = Math.max(1, Math.round(D * 0.0015f));
            for (ZCtx o : ctx) {
                if (!occ[o.idx]) continue;
                ZoneTone.Zone zo = o.z;
                for (int y = Math.max(y0, zo.y); y < Math.min(y1, zo.y + zo.h); y++)
                    for (int x = Math.max(x0, zo.x); x < Math.min(x1, zo.x + zo.w); x++)
                        if ((zo.m[(y - zo.y) * zo.w + x - zo.x] & 0xFF) >= 128) in[(y - y0) * w + x - x0] = true;
            }
            // la propia piel nunca tapa (si una zona de pelo se encima sobre la piel)
            ZoneTone.Zone zq = q.z;
            in = dilate(in, w, h, grow);   // cubre la linea del borde del pelo
            for (int i = 0; i < in.length; i++) out[i] = !in[i];
            float[] dOut = edt(in, w, h);     // distancia al pelo (afuera)
            float[] dIn = edt(out, w, h);     // distancia a lo que no es pelo (adentro)
            float[] s = new float[w * h];
            for (int i = 0; i < s.length; i++) {
                float a = dOut[i] >= INF ? 1e4f : dOut[i], b = dIn[i] >= INF ? 1e4f : dIn[i];
                s[i] = in[i] ? -(b - 0.5f) : (a - 0.5f);
            }
            q.sdf = s; q.sx0 = x0; q.sy0 = y0; q.sw = w; q.sh = h;
        }

        // ------------------------------------------------------------ pelo: tope por columna, cara, brillo en mechones
        private void buildHair(ZCtx q, Cancel c) {
            ZoneTone.Zone z = q.z;
            q.colTop = new int[q.w];
            int minTop = q.h;
            for (int x = 0; x < q.w; x++) {
                q.colTop[x] = -1;
                for (int y = 0; y < q.h; y++)
                    if ((z.m[(y + q.y0 - z.y) * z.w + x + q.x0 - z.x] & 0xFF) >= 128) { q.colTop[x] = y; break; }
                if (q.colTop[x] >= 0) minTop = Math.min(minTop, q.colTop[x]);
            }
            q.hairTop0 = minTop;
            if (faceIdx < 0) return;
            ZCtx fz = ctx[faceIdx];
            q.faceTop = fz.y0 - q.y0;
            if (q.faceTop <= minTop + 6) return;
            // campo de direccion de los mechones (tensor de estructura) a media resolucion
            int hf = 2;
            int bw = (q.w + hf - 1) / hf, bh = (q.h + hf - 1) / hf;
            if (bw < 8 || bh < 8) return;
            float[] g = new float[bw * bh];
            boolean[] hin = new boolean[bw * bh];
            for (int y = 0; y < bh; y++)
                for (int x = 0; x < bw; x++) {
                    float s = 0; int n = 0; int inside = 0;
                    for (int yy = y * hf; yy < Math.min(q.h, y * hf + hf); yy++)
                        for (int xx = x * hf; xx < Math.min(q.w, x * hf + hf); xx++) {
                            int gi = (yy + q.y0 - uy0) * uw + xx + q.x0 - ux0;
                            s += lum[gi] & 0xFF; n++;
                            if ((z.m[(yy + q.y0 - z.y) * z.w + xx + q.x0 - z.x] & 0xFF) >= 128) inside++;
                        }
                    g[y * bw + x] = n > 0 ? s / n / 255f : 1f;
                    hin[y * bw + x] = inside * 2 >= n;
                }
            blur(g, bw, bh, 0.8f);
            float[] jxx = new float[g.length], jxy = new float[g.length], jyy = new float[g.length];
            for (int y = 1; y < bh - 1; y++)
                for (int x = 1; x < bw - 1; x++) {
                    int i = y * bw + x;
                    float gx = (g[i - bw + 1] + 2 * g[i + 1] + g[i + bw + 1]) - (g[i - bw - 1] + 2 * g[i - 1] + g[i + bw - 1]);
                    float gy = (g[i + bw - 1] + 2 * g[i + bw] + g[i + bw + 1]) - (g[i - bw - 1] + 2 * g[i - bw] + g[i - bw + 1]);
                    jxx[i] = gx * gx; jxy[i] = gx * gy; jyy[i] = gy * gy;
                }
            float sig = Math.max(1.5f, 0.006f * D / hf);
            blur(jxx, bw, bh, sig); blur(jxy, bw, bh, sig); blur(jyy, bw, bh, sig);
            if (c.cancelled()) throw new Cancelled();
            float[] tx = new float[g.length], ty = new float[g.length], coh = new float[g.length];
            double cohSum = 0; int cohN = 0;
            float bandC = minTop + 0.42f * (q.faceTop - minTop), bandH = Math.max(3f, 0.16f * (q.faceTop - minTop));
            for (int i = 0; i < g.length; i++) {
                float a = jxx[i], b = jxy[i], d = jyy[i];
                float tr = a + d, det = (float) Math.sqrt((a - d) * (a - d) + 4 * b * b);
                float l1 = (tr + det) * 0.5f, l2 = (tr - det) * 0.5f;
                // direccion del mechon = autovector del valor propio menor (perpendicular al gradiente)
                float vx = b, vy = l2 - a;
                if (Math.abs(vx) + Math.abs(vy) < 1e-9f) { vx = l2 - d; vy = b; }
                float m = (float) Math.hypot(vx, vy);
                if (m < 1e-9f) { vx = 0; vy = 1; m = 1; }
                tx[i] = vx / m; ty[i] = vy / m;
                coh[i] = tr > 1e-6f ? ((l1 - l2) / (l1 + l2)) * ((l1 - l2) / (l1 + l2)) : 0f;
                int y = i / bw;
                float yy = y * hf;
                if (hin[i] && Math.abs(yy - bandC) < bandH * 1.5f) { cohSum += coh[i]; cohN++; }
            }
            // sin lineas que digan la direccion: no se inventan rayas
            if (cohN < 20 || cohSum / cohN < 0.18) return;
            // LIC: ruido estirado a lo largo de los mechones
            java.util.Random rnd = new java.util.Random(12345L + q.idx);
            float[] noise = new float[g.length];
            for (int i = 0; i < noise.length; i++) noise[i] = rnd.nextFloat();
            blur(noise, bw, bh, 0.6f);
            float[] lic = new float[g.length];
            int steps = 18;
            int[] hhist = new int[256];
            int hn = 0;
            for (int y = 0; y < bh; y++) {
                float yy = y * hf;
                if (Math.abs(yy - bandC) > bandH * 2.2f) continue;
                for (int x = 0; x < bw; x++) {
                    int i = y * bw + x;
                    if (!hin[i]) continue;
                    float acc = noise[i];
                    int n = 1;
                    for (int dir = -1; dir <= 1; dir += 2) {
                        float px = x, py = y, lx = tx[i] * dir, ly = ty[i] * dir;
                        for (int k = 0; k < steps; k++) {
                            int ix = Math.round(px), iy = Math.round(py);
                            if (ix < 0 || iy < 0 || ix >= bw || iy >= bh) break;
                            int j = iy * bw + ix;
                            float ux = tx[j], uy = ty[j];
                            if (ux * lx + uy * ly < 0) { ux = -ux; uy = -uy; }
                            lx = ux; ly = uy;
                            px += lx; py += ly;
                            int jx = Math.round(px), jy = Math.round(py);
                            if (jx < 0 || jy < 0 || jx >= bw || jy >= bh || !hin[jy * bw + jx]) break;
                            acc += noise[jy * bw + jx];
                            n++;
                        }
                    }
                    float v = acc / n;
                    lic[i] = v;
                    hhist[Math.min(255, Math.max(0, (int) (v * 255f)))]++;
                    hn++;
                }
            }
            if (hn < 20) return;
            float lo = pct(hhist, hn, 0.45f) / 255f, hi = pct(hhist, hn, 0.92f) / 255f;
            if (hi - lo < 0.01f) return;
            q.licN = new float[q.w * q.h];
            for (int y = 0; y < q.h; y++)
                for (int x = 0; x < q.w; x++) {
                    float v = bil(lic, bw, bh, (x + 0.5f) / hf - 0.5f, (y + 0.5f) / hf - 0.5f);
                    q.licN[y * q.w + x] = clamp01((v - lo) / (hi - lo));
                }
            q.ring = true;
        }

        private void buildEye(ZCtx q) {
            q.eyeCx = q.x0 + q.w * 0.5f; q.eyeCy = q.y0 + q.h * 0.5f;
            q.eyeRx = q.w * 0.5f; q.eyeRy = q.h * 0.5f;
        }

        // ============================================================ ediciones de la usuaria

        public int zoneAt(int x, int y) {
            if (x < ux0 || y < uy0 || x >= ux1 || y >= uy1) return -1;
            int ow = owner[(y - uy0) * uw + x - ux0];
            if (ow > 0) return ow - 1;
            // un poco al lado (por si toca justo la linea)
            for (int r = 1; r <= 4; r++)
                for (int dy = -r; dy <= r; dy++)
                    for (int dx = -r; dx <= r; dx++) {
                        int xx = x + dx - ux0, yy = y + dy - uy0;
                        if (xx < 0 || yy < 0 || xx >= uw || yy >= uh) continue;
                        int o = owner[yy * uw + xx];
                        if (o > 0) return o - 1;
                    }
            return -1;
        }

        /** Antes de un trazo o de Quitar mancha: guarda las ediciones para poder deshacer. */
        public synchronized void pushUndo() {
            float[][] snap = new float[ctx.length][];
            for (int i = 0; i < ctx.length; i++) if (ctx[i].edit != null) snap[i] = ctx[i].edit.clone();
            undoEdits.add(snap);
            if (undoEdits.size() > 30) undoEdits.remove(0);
        }

        public synchronized boolean canUndo() { return !undoEdits.isEmpty(); }

        public synchronized boolean undo() {
            if (undoEdits.isEmpty()) return false;
            float[][] snap = undoEdits.remove(undoEdits.size() - 1);
            for (int i = 0; i < ctx.length; i++) if (snap[i] != null && ctx[i].edit != null) System.arraycopy(snap[i], 0, ctx[i].edit, 0, snap[i].length);
            return true;
        }

        /**
         * Mas luz (amount > 0) o Mas sombra (amount < 0) en la zona 'zi': sube o baja el mapa de
         * luz con una joroba suave. No pinta pixeles: el corte suave se vuelve a hacer y nunca sale
         * de la zona.
         */
        public synchronized void brush(int zi, float x, float y, float radius, float amount) {
            if (zi < 0 || zi >= ctx.length) return;
            ZCtx q = ctx[zi];
            if (q.edit == null) return;
            float gx = (x - q.x0 + 0.5f) / q.f - 0.5f + 1f, gy = (y - q.y0 + 0.5f) / q.f - 0.5f + 1f;
            float gr = Math.max(1.2f, radius / q.f), s2 = 2f * (gr * 0.5f) * (gr * 0.5f);
            int r = (int) Math.ceil(gr * 1.6f);
            for (int yy = (int) gy - r; yy <= (int) gy + r + 1; yy++)
                for (int xx = (int) gx - r; xx <= (int) gx + r + 1; xx++) {
                    if (xx < 0 || yy < 0 || xx >= q.gw || yy >= q.gh) continue;
                    float d2 = (xx - gx) * (xx - gx) + (yy - gy) * (yy - gy);
                    float wv = (float) Math.exp(-d2 / s2);
                    if (wv < 0.01f) continue;
                    int i = yy * q.gw + xx;
                    q.edit[i] = Math.max(-1.6f, Math.min(1.6f, q.edit[i] + amount * wv));
                }
        }

        /**
         * Quitar mancha: el pedazo de sombra (o de luz) tocado pasa a ser como lo de alrededor.
         * @return false si ahi no hay nada que quitar
         */
        public synchronized boolean removeSpot(int x, int y, Params p) {
            int zi = zoneAt(x, y);
            if (zi < 0) return false;
            ZCtx q = ctx[zi];
            if (q.edit == null || q.in == null) return false;
            Light L = light(p);
            float[] s = shadeField(q, L, p, false);
            float t = threshold(p);
            int gx = clampi(Math.round((x - q.x0 + 0.5f) / q.f - 0.5f + 1f), 0, q.gw - 1);
            int gy = clampi(Math.round((y - q.y0 + 0.5f) / q.f - 0.5f + 1f), 0, q.gh - 1);
            int start = gy * q.gw + gx;
            if (!q.in[start]) {
                // la celda mas cercana adentro
                int best = -1; float bd = 1e9f;
                for (int i = 0; i < q.in.length; i++) if (q.in[i]) {
                    float d = (i % q.gw - gx) * (i % q.gw - gx) + (i / q.gw - gy) * (i / q.gw - gy);
                    if (d < bd) { bd = d; best = i; }
                }
                if (best < 0 || bd > 9) return false;
                start = best;
            }
            boolean shadow = s[start] < t;
            // el pedazo conectado de la misma clase
            boolean[] seen = new boolean[q.in.length];
            int[] st = new int[q.in.length];
            int sp = 0, cnt = 0;
            st[sp++] = start; seen[start] = true;
            ArrayList<Integer> comp = new ArrayList<Integer>();
            while (sp > 0) {
                int i = st[--sp];
                comp.add(i);
                cnt++;
                int cx = i % q.gw, cy = i / q.gw;
                int[] nb = {cx > 0 ? i - 1 : -1, cx < q.gw - 1 ? i + 1 : -1, cy > 0 ? i - q.gw : -1, cy < q.gh - 1 ? i + q.gw : -1};
                for (int j : nb) {
                    if (j < 0 || seen[j] || !q.in[j] || (s[j] < t) != shadow) continue;
                    seen[j] = true;
                    st[sp++] = j;
                }
            }
            int inCells = 0;
            for (boolean b : q.in) if (b) inCells++;
            if (cnt * 100 > inCells * 12) {
                // no es una manchita (es una sombra grande): se quita el RETOQUE hecho ahi, si hay
                float rr = Math.max(2f, 0.04f * D / q.f);
                float found = 0f;
                for (int i = 0; i < q.edit.length; i++) {
                    float dx = i % q.gw - gx, dy = i / q.gw - gy;
                    if (dx * dx + dy * dy <= rr * rr * 4f) found = Math.max(found, Math.abs(q.edit[i]));
                }
                if (found < 0.05f) return false;
                for (int i = 0; i < q.edit.length; i++) {
                    float dx = i % q.gw - gx, dy = i / q.gw - gy;
                    float wv = (float) Math.exp(-(dx * dx + dy * dy) / (2f * rr * rr));
                    q.edit[i] *= 1f - wv;
                    if (Math.abs(q.edit[i]) < 0.02f) q.edit[i] = 0f;
                }
                return true;
            }
            float[] add = new float[q.in.length];
            boolean[] m = new boolean[q.in.length];
            for (int i : comp) {
                m[i] = true;
                add[i] = shadow ? (t - s[i] + 0.25f) : (t - s[i] - 0.25f);
            }
            // un poco mas grande y suave, para que no quede un borde
            boolean[] grown = dilate(m, q.gw, q.gh, 1);
            for (int i = 0; i < add.length; i++) if (grown[i] && !m[i]) add[i] = shadow ? 0.25f : -0.25f;
            float[] wt = new float[add.length];
            for (int i = 0; i < wt.length; i++) wt[i] = grown[i] ? 1f : 0f;
            for (int i = 0; i < add.length; i++) {
                if (!grown[i]) continue;
                q.edit[i] = Math.max(-1.6f, Math.min(1.6f, q.edit[i] + add[i]));
            }
            return true;
        }

        // ============================================================ render

        static final class Light {
            float lx, ly, lz;      // hacia el sol (3D)
            float dx, dy;          // hacia el sol en 2D (unitario)
            float sinT;
        }

        Light light(Params p) {
            Light L = new Light();
            float sx = p.sunX * W, sy = p.sunY * H;
            float ddx = sx - charCx, ddy = sy - charCy;
            float dist = (float) Math.hypot(ddx, ddy);
            float rel = clamp01(dist / (0.5f * D));
            float theta = (float) Math.toRadians(14 + 64 * rel);   // lejos = luz de costado = sombra ancha
            if (dist < 1e-3f) { ddx = 0; ddy = -1; dist = 1; }
            L.dx = ddx / dist; L.dy = ddy / dist;
            L.sinT = (float) Math.sin(theta);
            L.lx = L.dx * L.sinT; L.ly = L.dy * L.sinT; L.lz = (float) Math.cos(theta);
            return L;
        }

        static float threshold(Params p) {
            float k = p.strength / 100f;
            return -0.10f + 0.40f * k;
        }

        /** s = n.L + retoques, sin islitas (grilla de la zona). */
        float[] shadeField(ZCtx q, Light L, Params p, boolean clean) {
            int n = q.gw * q.gh;
            float[] s = new float[n];
            for (int i = 0; i < n; i++) s[i] = q.nx[i] * L.lx + q.ny[i] * L.ly + q.nz[i] * L.lz + q.edit[i];
            if (!clean || q.thin) return s;
            float t = threshold(p);
            // islitas: pedazos chicos de sombra o de luz se pasan a la clase de alrededor
            int minCells = Math.max(2, Math.round(Math.max(40f, 0.005f * q.area) / (q.f * q.f)));
            boolean[] seen = new boolean[n];
            int[] st = new int[n];
            int[] comp = new int[n];
            for (int s0 = 0; s0 < n; s0++) {
                if (seen[s0] || !q.in[s0]) continue;
                boolean cls = s[s0] < t;
                int sp = 0, cn = 0;
                st[sp++] = s0; seen[s0] = true;
                while (sp > 0) {
                    int i = st[--sp];
                    comp[cn++] = i;
                    int cx = i % q.gw, cy = i / q.gw;
                    if (cx > 0) sp = push(s, q.in, seen, st, sp, i - 1, cls, t);
                    if (cx < q.gw - 1) sp = push(s, q.in, seen, st, sp, i + 1, cls, t);
                    if (cy > 0) sp = push(s, q.in, seen, st, sp, i - q.gw, cls, t);
                    if (cy < q.gh - 1) sp = push(s, q.in, seen, st, sp, i + q.gw, cls, t);
                }
                if (cn < minCells) for (int k = 0; k < cn; k++) s[comp[k]] = cls ? t + 0.08f : t - 0.08f;
            }
            return s;
        }

        private static int push(float[] s, boolean[] in, boolean[] seen, int[] st, int sp, int j, boolean cls, float t) {
            if (seen[j] || !in[j] || (s[j] < t) != cls) return sp;
            seen[j] = true;
            st[sp++] = j;
            return sp;
        }

        /**
         * Hace el acabado en 'dst' (un recuadro de la imagen: dx0,dy0,dw,dh), que ya trae lo que habia
         * en la capa. Los pixeles de las zonas se reemplazan (con el alfa de la mascara).
         */
        public void render(Params p, int[] dst, int dx0, int dy0, int dw, int dh, Cancel c) {
            renderImpl(p, dst, dx0, dy0, dw, dh, c, -1);
        }

        private String fullKey;
        private int[] fullBuf;

        /** Acabado completo en la caja de union, sobre transparente (cache por parametros). */
        synchronized int[] fullFor(Params p) {
            String key = p.sunX + "|" + p.sunY + "|" + p.strength + "|" + p.colorLines;
            if (fullBuf != null && key.equals(fullKey)) return fullBuf;
            int[] b = new int[uw * uh];
            renderImpl(p, b, ux0, uy0, uw, uh, NEVER, -1);
            fullBuf = b;
            fullKey = key;
            return b;
        }

        private void renderImpl(Params p, int[] dst, int dx0, int dy0, int dw, int dh, Cancel c, final int only) {
            if (c == null) c = NEVER;
            long T0 = System.nanoTime();
            final Params P = p.copy();
            final Light L = light(P);
            final float k = P.strength / 100f;
            final float t = threshold(P);
            final float op1 = Math.min(1f, k * 1.6f);
            final float opL = Math.min(1f, k * 1.4f);
            // por zona: campos del sol
            final float[][] S = new float[ctx.length][];
            final float[][] Wd = new float[ctx.length][];
            final Pal[] pal = new Pal[ctx.length];
            for (ZCtx q : ctx) {
                if (q.w == 0) continue;
                pal[q.idx] = palette(q.z.s.base);
                if (only >= 0 && q.idx != only) continue;
                float[] s;
                synchronized (this) { s = shadeField(q, L, P, true); }
                // suavizado leve (redondea dientes) y ancho del antialias (en pixeles finales)
                blurMasked(s, q.in, q.gw, q.gh, 0.7f);
                float[] wv = new float[s.length];
                for (int gy = 0; gy < q.gh; gy++)
                    for (int gx = 0; gx < q.gw; gx++) {
                        int i = gy * q.gw + gx;
                        float a = s[Math.max(0, gx - 1) + gy * q.gw], b = s[Math.min(q.gw - 1, gx + 1) + gy * q.gw];
                        float u = s[gx + Math.max(0, gy - 1) * q.gw], d = s[gx + Math.min(q.gh - 1, gy + 1) * q.gw];
                        float g = (float) Math.hypot((b - a) * 0.5f, (d - u) * 0.5f) / q.f;
                        wv[i] = Math.max(0.0035f, 0.9f * g);
                    }
                S[q.idx] = s;
                Wd[q.idx] = wv;
                if (c.cancelled()) throw new Cancelled();
            }
            long T1 = System.nanoTime();
            // limpiar las zonas en el destino y pintar en orden (como "Color zonas")
            for (final ZCtx q : ctx) {
                if (q.w == 0 || (only >= 0 && q.idx != only)) continue;
                if (c.cancelled()) throw new Cancelled();
                final ZoneTone.Zone z = q.z;
                final Pal pz = pal[q.idx];
                final float[] s = S[q.idx], wv = Wd[q.idx];
                final boolean improve = z.s.finish == ZoneTone.IMPROVE || colored;
                final int ox = Math.max(q.x0, dx0), oy = Math.max(q.y0, dy0);
                final int ex = Math.min(q.x0 + q.w, dx0 + dw), ey = Math.min(q.y0 + q.h, dy0 + dh);
                if (ex <= ox || ey <= oy) continue;
                final Cancel cc = c;
                parallel(ey - oy, new Rows() {
                    public void run(int r0, int r1) {
                        float[] col = new float[3];
                        for (int y = oy + r0; y < oy + r1; y++) {
                            if ((y & 31) == 0 && cc.cancelled()) throw new Cancelled();
                            int my = y - z.y;
                            for (int x = ox; x < ex; x++) {
                                int a = z.m[my * z.w + x - z.x] & 0xFF;
                                if (a == 0) continue;
                                int c2 = shadePixel(q, pz, s, wv, L, P, t, k, op1, opL, improve, x, y, col);
                                int di = (y - dy0) * dw + x - dx0;
                                int src = (a << 24) | (c2 & 0x00FFFFFF);
                                dst[di] = a >= 255 ? src : ZoneTone.over(dst[di], src, a);
                            }
                        }
                    }
                });
            }
            long T2 = System.nanoTime();
            if (P.colorLines && only < 0) colorGapLines(pal, dst, dx0, dy0, dw, dh);
            long T3 = System.nanoTime();
            glowAndTint(dst, dx0, dy0, dw, dh, k, c);
            long T4 = System.nanoTime();
            if (DBG) System.out.printf("  campos %d ms, pixeles %d ms, lineas %d ms, resplandor %d ms%n", (T1 - T0) / 1000000, (T2 - T1) / 1000000, (T3 - T2) / 1000000, (T4 - T3) / 1000000);
        }

        /** El color de un pixel de la zona. */
        private int shadePixel(ZCtx q, Pal pz, float[] s, float[] wv, Light L, Params P, float t, float k,
                               float op1, float opL, boolean improve, int x, int y, float[] col) {
            int ui = (y - uy0) * uw + x - ux0;
            int v = lum[ui] & 0xFF;
            float lA = (lineA[ui] & 0xFF) / 255f;
            float gx = (x - q.x0 + 0.5f) / q.f - 0.5f + 1f, gy = (y - q.y0 + 0.5f) / q.f - 0.5f + 1f;
            float sv = bil(s, q.gw, q.gh, gx, gy), w = bil(wv, q.gw, q.gh, gx, gy);
            // el iris no lleva volumen (solo su degradado): si no, salen medias lunas
            float sh1 = q.bg || q.eye ? 0f : 1f - smooth(t - w, t + w, sv);
            // sombra que echa el pelo (borde con signo, bilineal)
            float cast = 0f, contact = 0f;
            if (q.sdf != null) {
                float len = (0.012f + 0.016f * L.sinT) * D;
                float px = x + L.dx * len - q.sx0, py = y + L.dy * len - q.sy0;
                float sd = bil(q.sdf, q.sw, q.sh, px, py);
                float wc = Math.max(1.2f, Math.min(3f, 0.0012f * D));
                cast = clamp01(0.5f - sd / wc);
                float d0 = bil(q.sdf, q.sw, q.sh, x - q.sx0, y - q.sy0);
                contact = 1f - smooth(0f, 0.008f * D, Math.max(0f, d0));
                sh1 = Math.max(sh1, cast);
            }
            // oclusion (2a sombra): lineas que se juntan y contacto con el pelo, solo dentro de la sombra 1
            float occ = 0f;
            if (q.dens != null) occ = 0.75f * bil(q.dens, q.gw, q.gh, gx, gy);
            occ = clamp01(occ + 0.8f * contact * cast);
            float sh2 = smooth(0.42f, 0.62f, occ) * sh1;
            if (dbgShadow != null) dbgShadow[ui] = sh1;
            // base
            float r, g, b;
            if (improve) {
                int src = ref[y * W + x];
                r = ((src >> 16) & 255) / 255f; g = ((src >> 8) & 255) / 255f; b = (src & 255) / 255f;
            } else if (q.darkZone) {
                // zona casi negra (pelo negro de manga): de negro a la sombra, de gris a la base
                float tt = smooth(0.08f, 0.85f, v / (float) q.paper);
                r = pz.s2[0] + (pz.base[0] - pz.s2[0]) * tt;
                g = pz.s2[1] + (pz.base[1] - pz.s2[1]) * tt;
                b = pz.s2[2] + (pz.base[2] - pz.s2[2]) * tt;
                lA = 0f;
            } else {
                r = pz.base[0]; g = pz.base[1]; b = pz.base[2];
            }
            // pelo: degradado raiz-punta (mas oscuro arriba) y puntas tibias
            if (q.hair && q.colTop != null) {
                int lx = x - q.x0;
                int top = q.colTop[Math.min(q.w - 1, Math.max(0, lx))];
                float vv = clamp01((y - q.y0 - Math.max(0, top)) / Math.max(8f, q.h * 0.5f));
                float dk = 0.30f * op1 * (1f - smooth(0f, 0.55f, vv));
                r += (pz.s1[0] - r) * dk; g += (pz.s1[1] - g) * dk; b += (pz.s1[2] - b) * dk;
            }
            // ojos: iris mas oscuro arriba (parpado) y mas claro abajo
            if (q.eye) {
                float vy = clamp01((y - q.y0) / (float) Math.max(1, q.h));
                float top = 0.55f * op1 * (1f - smooth(0f, 0.45f, vy));
                r += (pz.s2[0] - r) * top; g += (pz.s2[1] - g) * top; b += (pz.s2[2] - b) * top;
                float bot = 0.30f * opL * smooth(0.55f, 0.95f, vy);
                r += (pz.light[0] - r) * bot; g += (pz.light[1] - g) * bot; b += (pz.light[2] - b) * bot;
            }
            // sombra 1 y 2 (colores de sombra, no gris)
            float a1 = sh1 * op1, a2 = sh2 * op1;
            r += (pz.s1[0] - r) * a1; g += (pz.s1[1] - g) * a1; b += (pz.s1[2] - b) * a1;
            r += (pz.s2[0] - r) * a2; g += (pz.s2[1] - g) * a2; b += (pz.s2[2] - b) * a2;
            // luz suave del lado del sol (Trama)
            if (!q.bg && !q.eye) {
                float lit = smooth(t + 0.38f, t + 0.68f, sv) * (1f - sh1) * 0.38f * opL;
                if (lit > 0f) {
                    r = 1f - (1f - r) * (1f - pz.light[0] * lit);
                    g = 1f - (1f - g) * (1f - pz.light[1] * lit);
                    b = 1f - (1f - b) * (1f - pz.light[2] * lit);
                }
            }
            // pelo: anillo de brillo roto en mechones (Anadir), solo en la luz
            if (q.ring && q.licN != null) {
                int lx = x - q.x0, ly = y - q.y0;
                int top = q.colTop[Math.min(q.w - 1, Math.max(0, lx))];
                if (top >= 0) {
                    float bandC = top + 0.42f * (q.faceTop - q.hairTop0);
                    float bandH = Math.max(3f, 0.13f * (q.faceTop - q.hairTop0));
                    float band = 1f - smooth(bandH * 0.45f, bandH, Math.abs(ly - bandC));
                    if (band > 0f) {
                        float lic = q.licN[ly * q.w + lx];
                        float side = 0.45f + 0.55f * clamp01(0.5f + 0.5f * sv);
                        float ra = smooth(0.42f, 0.78f, lic) * band * side * (1f - sh1) * 0.62f * opL;
                        r = Math.min(1f, r + pz.ring[0] * ra * 0.8f);
                        g = Math.min(1f, g + pz.ring[1] * ra * 0.8f);
                        b = Math.min(1f, b + pz.ring[2] * ra * 0.8f);
                    }
                }
            }
            // rubor (solo si hay cara y dos ojos)
            if (q.face && eyes.size() == 2) {
                float bl = 0f;
                for (int e : eyes) {
                    ZCtx ez = ctx[e];
                    float cxp = ez.eyeCx, cyp = ez.eyeCy + ez.eyeRy * 2.1f;
                    float rx = ez.eyeRx * 1.25f, ry = ez.eyeRy * 0.75f;
                    float dxe = (x - cxp) / Math.max(1f, rx), dye = (y - cyp) / Math.max(1f, ry);
                    bl = Math.max(bl, (float) Math.exp(-(dxe * dxe + dye * dye) * 1.4f));
                }
                bl *= 0.16f * opL;
                r += (0.98f - r) * bl; g += (0.55f - g) * bl; b += (0.60f - b) * bl;
            }
            // grises y tramas del autor: se multiplican (sombra del dibujante, textura visible)
            if (!improve && !q.darkZone) {
                float P0 = q.paper;
                float vs = Math.max(v, P0 * 0.55f);
                float am = q.author ? 0.62f : 0.45f;
                float m = 1f - am * (1f - Math.min(1f, vs / P0));
                r *= m; g *= m; b *= m;
                // blancos del autor (brillo de ojos y pelo) en zonas con grises: siguen claros
                if (q.author && v > P0 - 14) {
                    float wk = smooth(P0 - 14, P0 - 4, v) * 0.85f;
                    r += (pz.light[0] - r) * wk; g += (pz.light[1] - g) * wk; b += (pz.light[2] - b) * wk;
                }
            }
            // luz de borde: contorno EXTERIOR del lado del sol
            if (!q.bg) {
                int di = ui;
                float de = dExt[di];
                float rw = Math.max(2f, 0.003f * D);
                if (de < rw * 1.2f) {
                    float band = 1f - smooth(rw * 0.55f, rw * 1.15f, de);
                    float[] cn = new float[3];
                    charNormal(x, y, cn);
                    float m = (float) Math.hypot(cn[0], cn[1]);
                    float face = m > 1e-4f ? (cn[0] * L.dx + cn[1] * L.dy) / m : 0f;
                    float ra = band * smooth(0.25f, 0.65f, face) * 0.55f * opL;
                    if (ra > 0f) {
                        r = Math.min(1f, r + pz.rim[0] * ra);
                        g = Math.min(1f, g + pz.rim[1] * ra);
                        b = Math.min(1f, b + pz.rim[2] * ra);
                    }
                }
            }
            // lineas de color (marron en piel, oscuro del pelo en el pelo) con su antialias.
            // En el iris la tinta es la pupila: queda casi negra (se conserva)
            if (lA > 0f) {
                if (q.eye) {
                    float ink = v / 255f * 0.5f;
                    float pr = pz.line[0] * 0.35f + ink, pg = pz.line[1] * 0.35f + ink, pb = pz.line[2] * 0.35f + ink;
                    r += (pr - r) * lA; g += (pg - g) * lA; b += (pb - b) * lA;
                } else if (P.colorLines && !improve) {
                    r += (pz.line[0] - r) * lA; g += (pz.line[1] - g) * lA; b += (pz.line[2] - b) * lA;
                } else {
                    float ink = v / 255f;
                    r += (ink - r) * lA; g += (ink - g) * lA; b += (ink - b) * lA;
                }
            }
            col[0] = r; col[1] = g; col[2] = b;

            return 0xFF000000 | (to8(r) << 16) | (to8(g) << 8) | to8(b);
        }

        /** Lineas que quedaron entre zonas (fuera de toda mascara): del color de la zona vecina. */
        private void colorGapLines(Pal[] pal, int[] dst, int dx0, int dy0, int dw, int dh) {
            int x0 = Math.max(ux0, dx0), y0 = Math.max(uy0, dy0), x1 = Math.min(ux1, dx0 + dw), y1 = Math.min(uy1, dy0 + dh);
            int R = 3;
            for (int y = y0; y < y1; y++)
                for (int x = x0; x < x1; x++) {
                    int ui = (y - uy0) * uw + x - ux0;
                    if (owner[ui] != 0) continue;
                    float lA = (lineA[ui] & 0xFF) / 255f;
                    if (lA <= 0.02f) continue;
                    // zona mas cercana (la de color mas oscuro si empatan)
                    int best = -1; int bd = 99; float bL = 9f;
                    for (int dy = -R; dy <= R; dy++)
                        for (int dx = -R; dx <= R; dx++) {
                            int xx = x + dx - ux0, yy = y + dy - uy0;
                            if (xx < 0 || yy < 0 || xx >= uw || yy >= uh) continue;
                            int o = owner[yy * uw + xx];
                            if (o == 0) continue;
                            ZCtx q = ctx[o - 1];
                            if (q.bg || pal[o - 1] == null) continue;
                            int d = dx * dx + dy * dy;
                            float Lz = pal[o - 1].base[0] + pal[o - 1].base[1] + pal[o - 1].base[2];
                            if (d < bd || (d == bd && Lz < bL)) { bd = d; best = o - 1; bL = Lz; }
                        }
                    if (best < 0) continue;
                    float[] lc = pal[best].line;
                    int a = Math.round(lA * 255f);
                    int src = (a << 24) | (to8(lc[0]) << 16) | (to8(lc[1]) << 8) | to8(lc[2]);
                    int di = (y - dy0) * dw + x - dx0;
                    dst[di] = src;   // reemplaza: repetir el acabado no acumula
                }
        }

        /** Resplandor suave (Trama) y tinte ambiente (Luz suave), solo sobre lo pintado. */
        private void glowAndTint(int[] dst, int dx0, int dy0, int dw, int dh, float k, Cancel c) {
            int x0 = Math.max(ux0, dx0), y0 = Math.max(uy0, dy0), x1 = Math.min(ux1, dx0 + dw), y1 = Math.min(uy1, dy0 + dh);
            if (x1 <= x0 || y1 <= y0 || k <= 0f) return;
            int w = x1 - x0, h = y1 - y0;
            int f = Math.max(2, (int) Math.ceil(Math.max(w, h) / 360f));
            int bw = (w + f - 1) / f, bh = (h + f - 1) / f;
            float[] L = new float[bw * bh], A = new float[bw * bh];
            final float invC = 1f / (f * f);
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int c2 = dst[(y + y0 - dy0) * dw + x + x0 - dx0];
                    int a = c2 >>> 24;
                    if (a == 0) continue;
                    float l = (((c2 >> 16) & 255) * 0.3f + ((c2 >> 8) & 255) * 0.59f + (c2 & 255) * 0.11f) / 255f;
                    int i = (y / f) * bw + x / f;
                    float wa = a / 255f;
                    // solo lo claro brilla (promedio de la celda)
                    L[i] += smooth(0.55f, 0.95f, l) * wa * invC;
                    A[i] += wa * invC;
                }
            float sig = Math.max(1f, 0.012f * D / f);
            blur(L, bw, bh, sig);
            blur(A, bw, bh, sig);
            if (c.cancelled()) throw new Cancelled();
            final float gop = 0.25f * Math.min(1f, k / 0.6f), top = 0.12f * Math.min(1f, k / 0.6f);
            final int fx0 = x0, fy0 = y0, fw = w, fbw = bw, fbh = bh, ff = f;
            final float[] fL = L;
            parallel(h, new Rows() {
                public void run(int r0, int r1) {
                    for (int y = r0; y < r1; y++) {
                        float ty = (y + fy0 - uy0) / (float) Math.max(1, uh - 1);
                        // calido arriba, frio abajo
                        float tr = 1.0f + (0.55f - 1.0f) * ty, tg = 0.80f + (0.66f - 0.80f) * ty, tb = 0.58f + (1.0f - 0.58f) * ty;
                        for (int x = 0; x < fw; x++) {
                            int di = (y + fy0 - dy0) * dw + x + fx0 - dx0;
                            int c2 = dst[di];
                            int a = c2 >>> 24;
                            if (a == 0) continue;
                            int ui = (y + fy0 - uy0) * uw + x + fx0 - ux0;
                            if (owner[ui] == 0) continue;
                            float gl = bil(fL, fbw, fbh, (x + 0.5f) / ff - 0.5f, (y + 0.5f) / ff - 0.5f) * gop;
                            float r = ((c2 >> 16) & 255) / 255f, g = ((c2 >> 8) & 255) / 255f, b = (c2 & 255) / 255f;
                            r = 1f - (1f - r) * (1f - gl); g = 1f - (1f - g) * (1f - gl); b = 1f - (1f - b) * (1f - gl);
                            r = soft(r, tr, top); g = soft(g, tg, top); b = soft(b, tb, top);
                            dst[di] = (a << 24) | (to8(r) << 16) | (to8(g) << 8) | to8(b);
                        }
                    }
                }
            });
        }
    }

    /** Luz suave (W3C) con opacidad. */
    static float soft(float cb, float cs, float op) {
        float r;
        if (cs <= 0.5f) r = cb - (1f - 2f * cs) * cb * (1f - cb);
        else {
            float d = cb <= 0.25f ? ((16f * cb - 12f) * cb + 4f) * cb : (float) Math.sqrt(cb);
            r = cb + (2f * cs - 1f) * (d - cb);
        }
        return cb + (r - cb) * op;
    }

    static int to8(float v) { int i = Math.round(v * 255f); return i < 0 ? 0 : i > 255 ? 255 : i; }

    static float bil(float[] a, int w, int h, float x, float y) {
        if (x < 0) x = 0; if (y < 0) y = 0;
        if (x > w - 1) x = w - 1; if (y > h - 1) y = h - 1;
        int x0 = (int) x, y0 = (int) y;
        int x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
        float fx = x - x0, fy = y - y0;
        float a0 = a[y0 * w + x0] + (a[y0 * w + x1] - a[y0 * w + x0]) * fx;
        float a1 = a[y1 * w + x0] + (a[y1 * w + x1] - a[y1 * w + x0]) * fx;
        return a0 + (a1 - a0) * fy;
    }

    /** Parte del borde de la imagen que toca la zona (0..1). */
    static float edgeShare(ZoneTone.Zone z, int W, int H) {
        int touch = 0;
        for (int x = 0; x < z.w; x++) {
            if (z.y == 0 && (z.m[x] & 0xFF) >= 128) touch++;
            if (z.y + z.h == H && (z.m[(z.h - 1) * z.w + x] & 0xFF) >= 128) touch++;
        }
        for (int y = 0; y < z.h; y++) {
            if (z.x == 0 && (z.m[y * z.w] & 0xFF) >= 128) touch++;
            if (z.x + z.w == W && (z.m[y * z.w + z.w - 1] & 0xFF) >= 128) touch++;
        }
        return touch / (float) (2 * (W + H));
    }

    /** Tapa los huecos (zonas de afuera encerradas, que no tocan el borde) de hasta maxCells celdas. */
    static boolean[] fillHoles(boolean[] in, int w, int h, int maxCells) {
        boolean[] o = in.clone();
        boolean[] seen = new boolean[in.length];
        int[] st = new int[in.length], comp = new int[in.length];
        for (int s0 = 0; s0 < in.length; s0++) {
            if (in[s0] || seen[s0]) continue;
            int sp = 0, cn = 0;
            boolean border = false;
            st[sp++] = s0; seen[s0] = true;
            while (sp > 0) {
                int i = st[--sp];
                comp[cn++] = i;
                int x = i % w, y = i / w;
                if (x == 0 || y == 0 || x == w - 1 || y == h - 1) border = true;
                if (x > 0 && !in[i - 1] && !seen[i - 1]) { seen[i - 1] = true; st[sp++] = i - 1; }
                if (x < w - 1 && !in[i + 1] && !seen[i + 1]) { seen[i + 1] = true; st[sp++] = i + 1; }
                if (y > 0 && !in[i - w] && !seen[i - w]) { seen[i - w] = true; st[sp++] = i - w; }
                if (y < h - 1 && !in[i + w] && !seen[i + w]) { seen[i + w] = true; st[sp++] = i + w; }
            }
            if (!border && cn <= maxCells) for (int k = 0; k < cn; k++) o[comp[k]] = true;
        }
        return o;
    }

    static boolean[] dilate(boolean[] m, int w, int h, int r) {
        if (r <= 0) return m.clone();
        boolean[] seed = m;
        float[] d = edt(seed, w, h);
        boolean[] o = new boolean[m.length];
        for (int i = 0; i < o.length; i++) o[i] = d[i] <= r;
        return o;
    }

    /** Cierre (dilatar y luego erosionar) con radio r. */
    static boolean[] close(boolean[] m, int w, int h, int r) {
        boolean[] dl = dilate(m, w, h, r);
        boolean[] inv = new boolean[m.length];
        for (int i = 0; i < inv.length; i++) inv[i] = !dl[i];
        boolean anyOut = false;
        for (boolean b : inv) if (b) { anyOut = true; break; }
        if (!anyOut) return dl;
        float[] d = edt(inv, w, h);
        boolean[] o = new boolean[m.length];
        for (int i = 0; i < o.length; i++) o[i] = dl[i] && d[i] > r;
        for (int i = 0; i < o.length; i++) o[i] |= m[i];
        return o;
    }

    // ==================================================================================== una zona sola

    private static java.lang.ref.WeakReference<Object[]> lastSession;

    /**
     * Para volver a pintar UNA zona (cambiar su color, borrarla...) con el acabado guardado en su
     * estilo. Se hace el acabado completo (igual que en la pantalla de Acabado) y se toma la zona:
     * asi el resultado es identico. La sesion y el resultado quedan en cache mientras el dibujo y
     * la lista de zonas sean los mismos (las demas zonas de la misma vuelta salen al instante).
     */
    public static int[] renderZoneLocal(int[] src, int W, int H, ZoneTone.Zone z, List<ZoneTone.Zone> all) {
        List<ZoneTone.Zone> list = all;
        if (list == null || !list.contains(z)) { list = new ArrayList<ZoneTone.Zone>(); list.add(z); }
        Session s = null;
        synchronized (Acabado.class) {
            Object[] o = lastSession == null ? null : lastSession.get();
            if (o != null && o[0] == src && o[1] == list && o[2] instanceof Session) s = (Session) o[2];
        }
        if (s == null) {
            s = new Session(src, W, H, list, NEVER);
            synchronized (Acabado.class) { lastSession = new java.lang.ref.WeakReference<Object[]>(new Object[]{src, list, s}); }
        }
        int zi = s.zones.indexOf(z);
        if (zi < 0) return null;
        ZCtx q = s.ctx[zi];
        if (q.w == 0) return null;
        Params p = new Params();
        p.sunX = z.s.sunX / 1000f; p.sunY = z.s.sunY / 1000f; p.strength = z.s.strength; p.colorLines = z.s.colorLines;
        int[] full = s.fullFor(p);
        int[] out = new int[z.w * z.h];
        for (int ly = 0; ly < z.h; ly++)
            for (int lx = 0; lx < z.w; lx++) {
                int a = z.m[ly * z.w + lx] & 0xFF;
                if (a == 0) continue;
                int gx = lx + z.x - s.ux0, gy = ly + z.y - s.uy0;
                if (gx < 0 || gy < 0 || gx >= s.uw || gy >= s.uh) continue;
                out[ly * z.w + lx] = (full[gy * s.uw + gx] & 0x00FFFFFF) | (a << 24);
            }
        return out;
    }
}
