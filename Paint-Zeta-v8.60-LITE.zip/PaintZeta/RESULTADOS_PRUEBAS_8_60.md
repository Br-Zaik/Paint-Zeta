# Pruebas internas del Acabado (v8.60)

**Dónde**: PC en la nube, Linux, OpenJDK 21, procesador de 2 núcleos. **NO se probó en ningún
teléfono ni emulador.** Un teléfono puede ser 2 a 4 veces más lento.

**Compilación**: el motor del Acabado compila y corre completo en la PC. La parte de pantalla
NO se pudo compilar aquí (no hay Android ni internet en este equipo): se comparó contra la 8.59
y los únicos errores nuevos son los mismos "falta Android" que tiene la 8.59 en este equipo.
Si GitHub Actions falla, manda el registro de error.

**Imágenes**: un dibujo de prueba propio (personaje original, 1100x1500) con zonas tocadas
como en la app, una variante con trama de puntos + JPEG malo + un hueco en la línea, la misma
al doble (2200x3000), y tus 5 imágenes en blanco y negro (zonas automáticas, solo para medir).

## Resultados
| Prueba | Resultado |
|---|---|
| Color fuera de las partes (no-línea) | 0 píxeles en todas las imágenes |
| Islitas encerradas tras el acabado | 1 a 19 por imagen, de 1 a 2 px de media |
| Repetir el acabado sobre lo ya hecho | 0 píxeles distintos (no acumula) |
| Cambiar una parte después (zona sola) vs acabado completo | 0 píxeles distintos |
| Sombra + con trazos rápidos y un pincel enorme | cambia solo dentro de la cara; fuera solo el resplandor (máx. 10/255) |
| Deshacer retoque | vuelve exacto (0 px) |
| Quitar mancha | la mancha desaparece (0 px distintos) |
| Fuerza 0/25/50/75/100 | cambio medio 1 / 6 / 11 / 14 / 15 (sube parejo) |
| Misma obra a 1x y a 2x | diferencia media 1,3/255 (la sombra tiene la misma forma) |
| Trama de puntos | sigue visible (contraste 76 → 44) |
| Imagen ya a color | respeta sus colores |
| Ojos detectados en el dibujo de prueba | 2 de 2; pupilas y brillos se conservan |
| Sombra del flequillo / pelo | 3 zonas de pelo y la cara detectadas |

## Tiempos y memoria (PC, 2 núcleos; NO son del teléfono)
- 1100x1500: preparar 0,6 s (una vez al entrar), pintar 0,12 a 0,35 s, mover el sol 0,2 s, ~40 MB.
- 2200x3000 (6,6 MP): preparar 0,9 s, pintar/mover el sol ~0,4 s, ~145 MB.
- Tus imágenes B/N (0,9 a 1,2 MP): preparar 0,24 a 0,53 s, pintar 0,08 a 0,31 s.

## Límites
- El volumen es 2D: no entiende poses complejas (un brazo delante del cuerpo). Para eso están
  Sombra +, Luz + y Mancha.
- Pelo, cara y ojos se detectan con reglas simples. Si no hay seguridad, ese paso se omite
  (sin rubor, sin brillo de pelo) en vez de inventar.
- Los retoques (Sombra +, Luz +) valen mientras el Acabado está abierto: al aceptar quedan en
  la imagen, pero si después vuelves a abrir el Acabado se recalcula sin ellos.
- No probado en el teléfono: fluidez del sol, toques con un dedo/dos dedos, Antes, botones.
