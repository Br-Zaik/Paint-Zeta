package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * El documento: una lista de capas del mismo tamano, mas la capa de
 * seleccion (lo azul). Igual que en Ibis.
 */
public class Project {

    /** Indice especial: la capa de seleccion esta activa y se pinta lo azul. */
    public static final int SEL = -1;

    public int w;
    public int h;
    public final List<Layer> layers = new ArrayList<Layer>();
    public byte[] selection;
    public byte[] barrier;
    public int active = 0;

    private int[] ref;
    private boolean refDirty = true;

    /** Proyecto nuevo con la imagen en la primera capa. */
    public Project(Bitmap img) {
        this.w = img.getWidth();
        this.h = img.getHeight();
        int[] px = new int[w * h];
        img.getPixels(px, 0, w, 0, 0, w, h);
        layers.add(new Layer("imagen", px));
        selection = new byte[w * h];
        active = 0;
    }

    /** Proyecto vacio, para cargar desde archivo. */
    public Project(int w, int h) {
        this.w = w;
        this.h = h;
        selection = new byte[w * h];
    }

    public Layer activeLayer() {
        return active >= 0 && active < layers.size() ? layers.get(active) : null;
    }

    public boolean isSelectionLayerActive() {
        return active == SEL;
    }

    public void markDirty() {
        refDirty = true;
    }

    /**
     * Como se ve todo junto (sin fondo de vista). Es lo que miran la varita,
     * el gotero y el balde, igual que "Lienzo" en Ibis.
     */
    public int[] ref() {
        if (ref == null || ref.length != w * h) {
            ref = new int[w * h];
            refDirty = true;
        }
        if (!refDirty) return ref;
        Arrays.fill(ref, 0);
        for (Layer l : layers) {
            if (!l.visible || l.opacity <= 0) continue;
            int op = l.opacity;
            int[] s = l.denseOrNull();
            if (s != null && s.length == ref.length) {
                for (int i = 0; i < ref.length; i++) {
                    int c = s[i];
                    int sa = ((c >>> 24) * op) / 255;
                    if (sa == 0) continue;
                    ref[i] = over(ref[i], c, sa);
                }
                continue;
            }
            Layer.Packed pk = l.snapshot(w, h);
            if (pk.empty()) continue;
            int[] buf = new int[pk.w];
            for (int yy = 0; yy < pk.h; yy++) {
                pk.row(pk.y + yy, buf);
                int dst = (pk.y + yy) * w + pk.x;
                for (int xx = 0; xx < pk.w; xx++) {
                    int c = buf[xx];
                    int sa = ((c >>> 24) * op) / 255;
                    if (sa == 0) continue;
                    ref[dst + xx] = over(ref[dst + xx], c, sa);
                }
            }
        }
        refDirty = false;
        return ref;
    }

    /** Pone src con alfa sa encima de dst. Todo sin premultiplicar. */
    public static int over(int dst, int src, int sa) {
        if (sa >= 255) return (src & 0x00FFFFFF) | 0xFF000000;
        int da = dst >>> 24;
        if (da == 0) return (src & 0x00FFFFFF) | (sa << 24);
        int oa = sa + (da * (255 - sa)) / 255;
        if (oa == 0) return 0;
        int dw = (da * (255 - sa)) / 255;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * dw) / oa;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * dw) / oa;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * dw) / oa;
        return (oa << 24) | (r << 16) | (g << 8) | b;
    }

    public boolean hasSelection() {
        for (byte b : selection) if (b != 0) return true;
        return false;
    }

    public void clearSelection() {
        Arrays.fill(selection, (byte) 0);
    }

    public Rect fullRect() {
        return new Rect(0, 0, w, h);
    }

    public Rect selectionBounds() {
        return HoleFill.bounds(selection, w, h);
    }

    /** Imagen reducida de todo junto, para miniaturas de la galeria. */
    public Bitmap previewBitmap(int maxSide) {
        int m = Math.max(w, h);
        float sc = m > maxSide ? (float) maxSide / m : 1f;
        int tw = Math.max(1, Math.round(w * sc)), th = Math.max(1, Math.round(h * sc));
        Bitmap b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        int[] row = new int[tw];
        List<Layer> ls = new ArrayList<Layer>(layers);
        for (int y = 0; y < th; y++) {
            int sy = Math.min(h - 1, y * h / th);
            for (int x = 0; x < tw; x++) {
                int sx = Math.min(w - 1, x * w / tw);
                // sobre blanco, para que se vea en la galeria
                int c = 0xFFFFFFFF;
                for (Layer l : ls) {
                    if (!l.visible || l.opacity <= 0) continue;
                    int v = l.at(sx, sy, w);
                    int sa = ((v >>> 24) * l.opacity) / 255;
                    if (sa > 0) c = over(c, v, sa);
                }
                row[x] = c;
            }
            b.setPixels(row, 0, tw, 0, y, tw, 1);
        }
        return b;
    }

    // ---------------- girar y voltear todo junto ----------------

    public void rotate90(boolean cw) {
        int ow = w, oh = h;
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            l.setPx(rotInts(l.px(), ow, oh, cw));
            if (wasPacked && k != active) l.pack(oh, ow);
        }
        selection = rotBytes(selection, ow, oh, cw);
        barrier = null;
        ref = null;
        w = oh;
        h = ow;
        markDirty();
    }

    public void flip(boolean horizontal) {
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            l.setPx(flipInts(l.px(), w, h, horizontal));
            if (wasPacked && k != active) l.pack(w, h);
        }
        selection = flipBytes(selection, w, h, horizontal);
        barrier = null;
        markDirty();
    }

    /** Empaca las capas que no se estan usando para liberar memoria. */
    public void packInactive() {
        for (int k = 0; k < layers.size(); k++) {
            if (k == active) continue;
            Layer l = layers.get(k);
            if (!l.isPacked()) l.pack(w, h);
        }
    }

    /** Memoria que ocupan las capas ahora (aprox). */
    public long layersMemory() {
        long s = 0;
        for (Layer l : layers) s += l.javaMemory();
        return s;
    }

    private static int[] rotInts(int[] s, int w, int h, boolean cw) {
        int[] d = new int[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = cw ? h - 1 - y : y, ny = cw ? x : w - 1 - x;
                d[ny * h + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static byte[] rotBytes(byte[] s, int w, int h, boolean cw) {
        byte[] d = new byte[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = cw ? h - 1 - y : y, ny = cw ? x : w - 1 - x;
                d[ny * h + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static int[] flipInts(int[] s, int w, int h, boolean hor) {
        int[] d = new int[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = hor ? w - 1 - x : x, ny = hor ? y : h - 1 - y;
                d[ny * w + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static byte[] flipBytes(byte[] s, int w, int h, boolean hor) {
        byte[] d = new byte[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = hor ? w - 1 - x : x, ny = hor ? y : h - 1 - y;
                d[ny * w + nx] = s[y * w + x];
            }
        }
        return d;
    }
}
