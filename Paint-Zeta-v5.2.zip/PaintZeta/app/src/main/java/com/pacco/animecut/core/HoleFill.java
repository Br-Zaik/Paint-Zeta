package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Tapa el hueco que deja una parte. Cada pixel del hueco toma el color del
 * pixel mas cercano de alrededor, y despues se suaviza un poco para que no
 * queden rayas. En anime la piel es de color plano, asi que queda limpio.
 */
public final class HoleFill {

    private HoleFill() {
    }

    /**
     * @param hole 1 byte por pixel, lo que hay que tapar (mas de 64 cuenta)
     * @return el rectangulo modificado, o null
     */
    public static Rect fill(int[] px, int w, int h, final byte[] hole, int grow) {
        Rect b = bounds(hole, w, h);
        if (b == null) return null;

        // el hueco se agranda un poco para cubrir el antialias del borde
        final byte[] mask = new byte[w * h];
        for (int i = 0; i < mask.length; i++) mask[i] = (byte) ((hole[i] & 0xFF) > 64 ? 255 : 0);
        if (grow > 0) MaskOps.dilate(mask, w, h, grow);

        Rect area = new Rect(b);
        area.inset(-(grow + 24), -(grow + 24));
        if (area.left < 0) area.left = 0;
        if (area.top < 0) area.top = 0;
        if (area.right > w) area.right = w;
        if (area.bottom > h) area.bottom = h;

        DistanceTransform dt = DistanceTransform.build(w, h, area, new DistanceTransform.Source() {
            @Override
            public boolean isSource(int index) {
                return mask[index] == 0;
            }
        }, true);
        if (dt == null) return null;

        for (int y = 0; y < dt.rh; y++) {
            int row = y * dt.rw;
            int base = (dt.rect.top + y) * w + dt.rect.left;
            for (int x = 0; x < dt.rw; x++) {
                int i = base + x;
                if (mask[i] == 0) continue;
                int src = dt.nearest[row + x];
                if (src >= 0) px[i] = px[src];
            }
        }

        // dos pasadas de promedio solo dentro del hueco, para borrar las rayas
        for (int pass = 0; pass < 2; pass++) {
            int[] copy = px.clone();
            for (int y = Math.max(1, area.top); y < Math.min(h - 1, area.bottom); y++) {
                for (int x = Math.max(1, area.left); x < Math.min(w - 1, area.right); x++) {
                    int i = y * w + x;
                    if (mask[i] == 0) continue;
                    int r = 0, g = 0, bl = 0;
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dx = -1; dx <= 1; dx++) {
                            int c = copy[i + dy * w + dx];
                            r += (c >> 16) & 0xFF;
                            g += (c >> 8) & 0xFF;
                            bl += c & 0xFF;
                        }
                    }
                    px[i] = 0xFF000000 | ((r / 9) << 16) | ((g / 9) << 8) | (bl / 9);
                }
            }
        }
        return area;
    }

    public static Rect bounds(byte[] m, int w, int h) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if ((m[row + x] & 0xFF) <= 64) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }
}
