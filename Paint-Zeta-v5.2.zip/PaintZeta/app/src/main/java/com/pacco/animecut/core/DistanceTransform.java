package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Transformada de distancia exacta (Felzenszwalb y Huttenlocher).
 * Dos pasadas separadas, coste lineal, sin importar el radio.
 *
 * Sirve para dos cosas:
 *  - Expandir o contraer la seleccion con decimales (1.5 px, como Ibis).
 *  - Saber, para cada pixel del borde, cual es el pixel opaco mas cercano,
 *    que es lo que necesita el defringe para quitar el halo.
 *
 * Trabaja solo dentro de un rectangulo para no reservar 48 MB en imagenes
 * grandes.
 */
public final class DistanceTransform {

    private static final float INF = 1e20f;

    /** Distancia al cuadrado, en el sub-rectangulo. */
    public final float[] dist2;
    /** Indice del pixel origen mas cercano, referido a la imagen completa. */
    public final int[] nearest;
    public final Rect rect;
    public final int rw, rh;

    private DistanceTransform(Rect r, float[] d, int[] n) {
        this.rect = r;
        this.rw = r.width();
        this.rh = r.height();
        this.dist2 = d;
        this.nearest = n;
    }

    /**
     * @param inside true si ese pixel pertenece al conjunto origen (distancia 0)
     */
    public interface Source {
        boolean isSource(int index);
    }

    public static DistanceTransform build(int w, int h, Rect area, Source src, boolean wantNearest) {
        int left = Math.max(0, area.left);
        int top = Math.max(0, area.top);
        int right = Math.min(w, area.right);
        int bottom = Math.min(h, area.bottom);
        if (left >= right || top >= bottom) return null;
        Rect r = new Rect(left, top, right, bottom);
        int rw = r.width(), rh = r.height();

        float[] f = new float[rw * rh];
        int[] near = wantNearest ? new int[rw * rh] : null;

        boolean any = false;
        for (int y = 0; y < rh; y++) {
            int row = y * rw;
            int base = (top + y) * w + left;
            for (int x = 0; x < rw; x++) {
                boolean s = src.isSource(base + x);
                if (s) any = true;
                f[row + x] = s ? 0f : INF;
                if (near != null) near[row + x] = s ? (base + x) : -1;
            }
        }
        // Sin ningun pixel origen no hay distancia que calcular.
        if (!any) return null;

        int n = Math.max(rw, rh);
        float[] d = new float[n];
        int[] v = new int[n];
        float[] z = new float[n + 1];
        int[] argIn = new int[n];
        int[] argOut = new int[n];
        float[] col = new float[n];

        // columnas
        for (int x = 0; x < rw; x++) {
            for (int y = 0; y < rh; y++) {
                col[y] = f[y * rw + x];
                if (near != null) argIn[y] = near[y * rw + x];
            }
            pass(col, rh, d, v, z, argIn, argOut, near != null);
            for (int y = 0; y < rh; y++) {
                f[y * rw + x] = d[y];
                if (near != null) near[y * rw + x] = argOut[y];
            }
        }
        // filas
        for (int y = 0; y < rh; y++) {
            int row = y * rw;
            for (int x = 0; x < rw; x++) {
                col[x] = f[row + x];
                if (near != null) argIn[x] = near[row + x];
            }
            pass(col, rw, d, v, z, argIn, argOut, near != null);
            for (int x = 0; x < rw; x++) {
                f[row + x] = d[x];
                if (near != null) near[row + x] = argOut[x];
            }
        }
        return new DistanceTransform(r, f, near);
    }

    /** Envolvente inferior de parabolas en una dimension. */
    private static void pass(float[] f, int n, float[] d, int[] v, float[] z,
                             int[] argIn, int[] argOut, boolean wantArg) {
        int k = 0;
        v[0] = 0;
        z[0] = -INF;
        z[1] = INF;
        for (int q = 1; q < n; q++) {
            if (f[q] >= INF) continue; // parabola vacia, no aporta
            float s = intersect(f, q, v[k]);
            while (s <= z[k] && k > 0) {
                k--;
                s = intersect(f, q, v[k]);
            }
            if (s <= z[k] && k == 0) {
                v[0] = q;
                z[0] = -INF;
                z[1] = INF;
                continue;
            }
            k++;
            v[k] = q;
            z[k] = s;
            z[k + 1] = INF;
        }
        k = 0;
        for (int q = 0; q < n; q++) {
            while (z[k + 1] < q) k++;
            int p = v[k];
            float dq = q - p;
            float base = f[p];
            d[q] = base >= INF ? INF : dq * dq + base;
            if (wantArg) argOut[q] = base >= INF ? -1 : argIn[p];
        }
    }

    private static float intersect(float[] f, int q, int p) {
        if (f[p] >= INF) return -INF;
        return ((f[q] + q * q) - (f[p] + p * p)) / (2f * q - 2f * p);
    }
}
