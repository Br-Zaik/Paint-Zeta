package com.pacco.animecut.core;

import android.graphics.Rect;

import java.util.ArrayDeque;

/**
 * Deshacer / rehacer guardando UNICAMENTE el rectangulo que cambio.
 * Copiar la imagen entera en cada accion agota la memoria del telefono,
 * asi que aqui se guarda solo la zona tocada y con un presupuesto maximo.
 */
public class UndoManager {

    public static final int SELECTION = 0;
    public static final int PIXELS = 1;
    public static final int MASK = 2;

    private static final long BUDGET = 32L * 1024 * 1024;

    private static class Snap {
        int type;
        Layer layer;
        String label = "";
        Rect r;
        byte[] bytes;
        int[] ints;

        long size() {
            return bytes != null ? bytes.length : (ints != null ? ints.length * 4L : 0);
        }
    }

    private final Project p;
    private final ArrayDeque<Snap> undo = new ArrayDeque<>();
    private final ArrayDeque<Snap> redo = new ArrayDeque<>();
    private long used = 0;
    private int lastType = SELECTION;
    private String lastLabel = "";
    private String pendingLabel = "";

    public UndoManager(Project p) {
        this.p = p;
    }

    /** Llamar ANTES de modificar, con la zona que se va a tocar. */
    /** La etiqueta se muestra en el aviso: "Deshacer: Varita". */
    public void setLabel(String label) {
        pendingLabel = label == null ? "" : label;
    }

    public String lastLabel() {
        return lastLabel;
    }

    public void record(int type, Rect r) {
        if (r == null) return;
        Snap s = capture(type, r);
        if (s == null) return;
        s.label = pendingLabel;
        undo.push(s);
        used += s.size();
        for (Snap x : redo) used -= x.size();
        redo.clear();
        while (used > BUDGET && undo.size() > 1) {
            Snap old = undo.removeLast();
            used -= old.size();
        }
    }

    /**
     * Igual que record, pero tomando el estado anterior de una copia hecha
     * al empezar el trazo. Asi un trazo entero de pincel es UN solo deshacer.
     */
    public void recordFromBackup(int type, Rect in, byte[] selBackup, int[] pxBackup) {
        Rect r = clamp(in);
        if (r == null) return;
        Snap s = new Snap();
        s.type = type;
        s.label = pendingLabel;
        s.r = r;
        int rw = r.width();
        int rh = r.height();
        if (type == SELECTION) {
            if (selBackup == null) return;
            s.bytes = new byte[rw * rh];
            for (int y = 0; y < rh; y++) {
                System.arraycopy(selBackup, (r.top + y) * p.w + r.left, s.bytes, y * rw, rw);
            }
        } else {
            if (pxBackup == null) return;
            s.ints = new int[rw * rh];
            for (int y = 0; y < rh; y++) {
                System.arraycopy(pxBackup, (r.top + y) * p.w + r.left, s.ints, y * rw, rw);
            }
        }
        undo.push(s);
        used += s.size();
        for (Snap x : redo) used -= x.size();
        redo.clear();
        while (used > BUDGET && undo.size() > 1) {
            Snap old = undo.removeLast();
            used -= old.size();
        }
    }

    /** Antes de tocar la mascara de una capa. */
    public void recordMask(Layer layer, Rect r) {
        if (layer == null || r == null) return;
        Snap s = capture(MASK, r, layer);
        if (s == null) return;
        s.label = pendingLabel;
        undo.push(s);
        used += s.size();
        for (Snap x : redo) used -= x.size();
        redo.clear();
        while (used > BUDGET && undo.size() > 1) used -= undo.removeLast().size();
    }

    /** Igual, tomando el estado anterior de una copia hecha al empezar el trazo. */
    public void recordMaskFromBackup(Layer layer, Rect in, byte[] backup) {
        Rect r = clamp(in);
        if (layer == null || r == null || backup == null) return;
        Snap s = new Snap();
        s.type = MASK;
        s.layer = layer;
        s.label = pendingLabel;
        s.r = r;
        int rw = r.width(), rh = r.height();
        s.bytes = new byte[rw * rh];
        for (int y = 0; y < rh; y++) {
            System.arraycopy(backup, (r.top + y) * p.w + r.left, s.bytes, y * rw, rw);
        }
        undo.push(s);
        used += s.size();
        for (Snap x : redo) used -= x.size();
        redo.clear();
        while (used > BUDGET && undo.size() > 1) used -= undo.removeLast().size();
    }

    public boolean canUndo() {
        return !undo.isEmpty();
    }

    public boolean canRedo() {
        return !redo.isEmpty();
    }

    /** Devuelve la zona que hay que repintar, o null. */
    public Rect undo() {
        if (undo.isEmpty()) return null;
        Snap s = undo.pop();
        used -= s.size();
        lastType = s.type;
        lastLabel = s.label;
        Snap now = capture(s.type, s.r, s.layer);
        now = withLabel(now, s.label);
        restore(s);
        if (now != null) {
            redo.push(now);
            used += now.size();
        }
        return s.r;
    }

    public Rect redo() {
        if (redo.isEmpty()) return null;
        Snap s = redo.pop();
        used -= s.size();
        lastType = s.type;
        lastLabel = s.label;
        Snap now = capture(s.type, s.r, s.layer);
        now = withLabel(now, s.label);
        restore(s);
        if (now != null) {
            undo.push(now);
            used += now.size();
        }
        return s.r;
    }

    /** Que tipo de dato se restauro la ultima vez. Evita rehacer la copia
     *  de pantalla cuando solo cambio la seleccion. */
    public int lastRestoredType() {
        return lastType;
    }

    public void clear() {
        undo.clear();
        redo.clear();
        used = 0;
    }

    private Snap withLabel(Snap s, String label) {
        if (s != null) s.label = label;
        return s;
    }

    private Snap capture(int type, Rect in) {
        return capture(type, in, null);
    }

    private Snap capture(int type, Rect in, Layer layer) {
        Rect r = clamp(in);
        if (r == null) return null;
        Snap s = new Snap();
        s.type = type;
        s.layer = layer;
        s.r = r;
        int rw = r.width();
        int rh = r.height();
        if (type == SELECTION || type == MASK) {
            byte[] src = type == MASK && layer != null ? layer.mask : p.selection;
            s.bytes = new byte[rw * rh];
            for (int y = 0; y < rh; y++) {
                System.arraycopy(src, (r.top + y) * p.w + r.left, s.bytes, y * rw, rw);
            }
        } else {
            s.ints = new int[rw * rh];
            for (int y = 0; y < rh; y++) {
                System.arraycopy(p.pixels, (r.top + y) * p.w + r.left, s.ints, y * rw, rw);
            }
        }
        return s;
    }

    private void restore(Snap s) {
        int rw = s.r.width();
        int rh = s.r.height();
        if (s.type == SELECTION || s.type == MASK) {
            byte[] dst = s.type == MASK && s.layer != null ? s.layer.mask : p.selection;
            for (int y = 0; y < rh; y++) {
                System.arraycopy(s.bytes, y * rw, dst, (s.r.top + y) * p.w + s.r.left, rw);
            }
        } else {
            for (int y = 0; y < rh; y++) {
                System.arraycopy(s.ints, y * rw, p.pixels, (s.r.top + y) * p.w + s.r.left, rw);
            }
            p.pushPixels(s.r);
        }
    }

    private Rect clamp(Rect in) {
        int l = Math.max(0, in.left);
        int t = Math.max(0, in.top);
        int rr = Math.min(p.w, in.right);
        int b = Math.min(p.h, in.bottom);
        if (l >= rr || t >= b) return null;
        return new Rect(l, t, rr, b);
    }
}
