package com.pacco.animecut.core;

/**
 * Convierte las lineas oscuras del dibujo en una barrera para el relleno.
 * Es lo que hace que la varita magica funcione bien en manga blanco y negro:
 * el relleno se para en la linea en vez de escaparse por toda la pagina.
 */
public final class LineArt {

    private LineArt() {
    }

    /**
     * @param threshold luminancia por debajo de la cual el pixel es "linea" (0..255)
     * @param closeGap  cuantos pixeles engordar la linea para cerrar huecos
     */
    public static byte[] build(int[] px, int w, int h, int threshold, int closeGap) {
        byte[] b = new byte[w * h];
        for (int i = 0; i < b.length; i++) {
            int c = px[i];
            int r = (c >> 16) & 0xFF;
            int g = (c >> 8) & 0xFF;
            int bl = c & 0xFF;
            int lum = (r * 77 + g * 151 + bl * 28) >> 8;
            b[i] = (byte) (lum < threshold ? 255 : 0);
        }
        if (closeGap > 0) MaskOps.dilate(b, w, h, closeGap);
        return b;
    }
}
