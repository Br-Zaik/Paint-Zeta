package com.pacco.animecut.core;

/**
 * Filtros de limpieza previa. Aplicar uno antes de seleccionar hace que la
 * varita agarre mucho mejor, sobre todo en imagenes sacadas de internet que
 * vienen con ruido de JPEG.
 */
public final class Filters {

    private Filters() {
    }

    /**
     * Mediana de 3x3. Se come el ruido de bloque del JPEG y los puntitos
     * sueltos, sin desdibujar las lineas como haria un desenfoque.
     */
    public static void median3(int[] px, int w, int h) {
        int[] src = px.clone();
        int[] r = new int[9], g = new int[9], b = new int[9];
        for (int y = 1; y < h - 1; y++) {
            int row = y * w;
            for (int x = 1; x < w - 1; x++) {
                int k = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int o = row + dy * w + x;
                    for (int dx = -1; dx <= 1; dx++) {
                        int c = src[o + dx];
                        r[k] = (c >> 16) & 0xFF;
                        g[k] = (c >> 8) & 0xFF;
                        b[k] = c & 0xFF;
                        k++;
                    }
                }
                px[row + x] = 0xFF000000 | (median(r) << 16) | (median(g) << 8) | median(b);
            }
        }
    }

    private static int median(int[] a) {
        // ordenacion corta: son nueve valores
        for (int i = 1; i < 9; i++) {
            int v = a[i], j = i - 1;
            while (j >= 0 && a[j] > v) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = v;
        }
        return a[4];
    }

    /** Reduce la cantidad de tonos. Aplana el degradado del JPEG. */
    public static void posterize(int[] px, int levels) {
        if (levels < 2) levels = 2;
        int step = 255 / (levels - 1);
        int[] lut = new int[256];
        for (int i = 0; i < 256; i++) {
            lut[i] = Math.min(255, Math.round((float) i / step) * step);
        }
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            px[i] = 0xFF000000 | (lut[(c >> 16) & 0xFF] << 16)
                    | (lut[(c >> 8) & 0xFF] << 8) | lut[c & 0xFF];
        }
    }

    /** Niveles: lo que este por debajo de negro se va a negro, y al reves. */
    public static void levels(int[] px, int black, int white, float gamma) {
        if (white <= black) white = black + 1;
        int[] lut = new int[256];
        for (int i = 0; i < 256; i++) {
            float v = (i - black) / (float) (white - black);
            if (v < 0f) v = 0f;
            if (v > 1f) v = 1f;
            if (gamma != 1f) v = (float) Math.pow(v, gamma);
            lut[i] = (int) (v * 255f + 0.5f);
        }
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            px[i] = 0xFF000000 | (lut[(c >> 16) & 0xFF] << 16)
                    | (lut[(c >> 8) & 0xFF] << 8) | lut[c & 0xFF];
        }
    }

    /**
     * Extraer line art, con los tres controles de siempre: blanco, negro y
     * medio. Deja el dibujo en blanco y negro limpio, que es lo que mejor
     * agarra la varita y la barrera de linea.
     */
    public static void extractLineArt(int[] px, int w, int h, int white, int black, int middle) {
        if (white <= black) white = black + 1;
        float g = middle <= 0 ? 1f : (50f / middle);
        int[] lut = new int[256];
        for (int i = 0; i < 256; i++) {
            float v = (i - black) / (float) (white - black);
            if (v < 0f) v = 0f;
            if (v > 1f) v = 1f;
            v = (float) Math.pow(v, g);
            lut[i] = (int) (v * 255f + 0.5f);
        }
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int lum = (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
            int v = lut[lum];
            px[i] = 0xFF000000 | (v << 16) | (v << 8) | v;
        }
    }
}
