package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Operaciones sobre mascaras de 1 byte por pixel.
 * Todo separable (primero horizontal, luego vertical) para no morir
 * de lentitud en imagenes grandes.
 */
public final class MaskOps {

    private MaskOps() {
    }

    /** Expandir el borde. */
    public static void dilate(byte[] m, int w, int h, int r) {
        if (r <= 0) return;
        maxFilter(m, w, h, r);
    }

    /** Contraer el borde. */
    public static void erode(byte[] m, int w, int h, int r) {
        if (r <= 0) return;
        invert(m);
        maxFilter(m, w, h, r);
        invert(m);
    }

    /** Suavizar el borde (feather). Deja alfa intermedio, no escalonado. */
    public static void feather(byte[] m, int w, int h, int r) {
        if (r <= 0) return;
        boxBlur(m, w, h, r);
        boxBlur(m, w, h, r);
    }

    /**
     * Cierra los huecos chicos de la seleccion: primero engorda, despues
     * adelgaza lo mismo. Es lo que quita los puntitos que deja la trama
     * (screentone) del manga dentro de una zona ya seleccionada.
     */
    public static void closeHoles(byte[] m, int w, int h, int r) {
        if (r <= 0) return;
        threshold(m, 128);
        dilate(m, w, h, r);
        erode(m, w, h, r);
    }

    /**
     * Expande o contrae la seleccion con decimales, por ejemplo 1.5 px.
     * Es lo que se come el antialias del contorno y hace desaparecer los
     * cuadraditos blancos pegados a la linea.
     *
     * Positivo expande, negativo contrae. El borde queda con alfa
     * intermedio, no escalonado.
     */
    public static void expandSubpixel(final byte[] m, int w, int h, float px, Rect area) {
        if (px == 0f) return;
        final boolean grow = px > 0f;
        final float amount = Math.abs(px);
        int margin = (int) Math.ceil(amount) + 2;
        Rect r = area == null ? new Rect(0, 0, w, h) : new Rect(area);
        r.inset(-margin, -margin);

        DistanceTransform dt = DistanceTransform.build(w, h, r, new DistanceTransform.Source() {
            @Override
            public boolean isSource(int index) {
                int a = m[index] & 0xFF;
                return grow ? a >= 128 : a < 128;
            }
        }, false);
        if (dt == null) return;

        for (int y = 0; y < dt.rh; y++) {
            int row = y * dt.rw;
            int base = (dt.rect.top + y) * w + dt.rect.left;
            for (int x = 0; x < dt.rw; x++) {
                float d2 = dt.dist2[row + x];
                if (d2 >= 1e19f) continue;
                float d = (float) Math.sqrt(d2);
                int i = base + x;
                int cur = m[i] & 0xFF;
                if (grow) {
                    float a = amount + 0.5f - d;
                    if (a <= 0f) continue;
                    if (a > 1f) a = 1f;
                    int v = (int) (a * 255f);
                    if (v > cur) m[i] = (byte) v;
                } else {
                    float a = d - amount + 0.5f;
                    if (a >= 1f) continue;
                    if (a < 0f) a = 0f;
                    int v = (int) (cur * a);
                    m[i] = (byte) v;
                }
            }
        }
    }

    /**
     * Cierre de huecos por bola atrapada. Engorda la linea para tapar los
     * cortes, rellena, y devuelve el relleno a su grosor real. Es lo que
     * hace que el relleno no se escape por una linea abierta.
     */
    public static void closeGapsBarrier(byte[] barrier, int w, int h, int radius, byte[] out) {
        System.arraycopy(barrier, 0, out, 0, barrier.length);
        dilate(out, w, h, radius);
    }

    /**
     * Reconocimiento de zonas sin pintar. Busca los huecos que quedaron
     * dentro de la seleccion y los rellena, pero solo los que estan
     * encerrados de verdad: los que no tocan el borde de la imagen ni
     * salen al exterior. A diferencia de engordar y adelgazar, este no
     * deforma el contorno de afuera.
     */
    public static void fillEnclosed(byte[] m, int w, int h, int maxArea) {
        boolean[] outside = new boolean[w * h];
        // la pila arranca con sitio para todo el borde de la imagen
        int[] stack = new int[Math.max(4096, 2 * (w + h) + 16)];
        int sp = 0;

        // se empieza por todo el borde de la imagen
        for (int x = 0; x < w; x++) {
            sp = seed(m, outside, stack, sp, x);
            sp = seed(m, outside, stack, sp, (h - 1) * w + x);
        }
        for (int y = 0; y < h; y++) {
            sp = seed(m, outside, stack, sp, y * w);
            sp = seed(m, outside, stack, sp, y * w + w - 1);
        }
        int[] st = stack;
        while (sp > 0) {
            int i = st[--sp];
            int y = i / w;
            int x = i - y * w;
            if (x > 0) {
                int n = i - 1;
                if (!outside[n] && (m[n] & 0xFF) < 128) {
                    outside[n] = true;
                    if (sp == st.length) st = grow(st);
                    st[sp++] = n;
                }
            }
            if (x < w - 1) {
                int n = i + 1;
                if (!outside[n] && (m[n] & 0xFF) < 128) {
                    outside[n] = true;
                    if (sp == st.length) st = grow(st);
                    st[sp++] = n;
                }
            }
            if (y > 0) {
                int n = i - w;
                if (!outside[n] && (m[n] & 0xFF) < 128) {
                    outside[n] = true;
                    if (sp == st.length) st = grow(st);
                    st[sp++] = n;
                }
            }
            if (y < h - 1) {
                int n = i + w;
                if (!outside[n] && (m[n] & 0xFF) < 128) {
                    outside[n] = true;
                    if (sp == st.length) st = grow(st);
                    st[sp++] = n;
                }
            }
        }

        // lo que no es seleccion y tampoco salio afuera, es un hueco
        if (maxArea <= 0) {
            for (int i = 0; i < m.length; i++) {
                if ((m[i] & 0xFF) < 128 && !outside[i]) m[i] = (byte) 255;
            }
            return;
        }
        boolean[] seen = new boolean[w * h];
        int[] region = new int[Math.max(1024, maxArea + 8)];
        for (int i = 0; i < m.length; i++) {
            if (seen[i] || outside[i] || (m[i] & 0xFF) >= 128) continue;
            int n = collect(m, outside, seen, region, w, h, i, maxArea);
            if (n > 0 && n <= maxArea) {
                for (int k = 0; k < n; k++) m[region[k]] = (byte) 255;
            }
        }
    }

    private static int seed(byte[] m, boolean[] outside, int[] stack, int sp, int i) {
        if (outside[i] || (m[i] & 0xFF) >= 128) return sp;
        outside[i] = true;
        if (sp == stack.length) return sp; // el borde nunca llena la pila inicial
        stack[sp++] = i;
        return sp;
    }

    /** Junta un hueco. Devuelve 0 si pasa del maximo. */
    private static int collect(byte[] m, boolean[] outside, boolean[] seen, int[] region,
                               int w, int h, int start, int maxArea) {
        int n = 0;
        int[] st = new int[256];
        int sp = 0;
        st[sp++] = start;
        seen[start] = true;
        while (sp > 0) {
            int i = st[--sp];
            if (n >= region.length) return 0;
            region[n++] = i;
            if (n > maxArea) return 0;
            int y = i / w;
            int x = i - y * w;
            int[] nb = {x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1,
                    y > 0 ? i - w : -1, y < h - 1 ? i + w : -1};
            for (int k = 0; k < 4; k++) {
                int q = nb[k];
                if (q < 0 || seen[q] || outside[q] || (m[q] & 0xFF) >= 128) continue;
                seen[q] = true;
                if (sp == st.length) {
                    int[] b = new int[st.length * 2];
                    System.arraycopy(st, 0, b, 0, st.length);
                    st = b;
                }
                st[sp++] = q;
            }
        }
        return n;
    }

    private static int[] grow(int[] a) {
        int[] b = new int[a.length * 2];
        System.arraycopy(a, 0, b, 0, a.length);
        return b;
    }

    public static void invert(byte[] m) {
        for (int i = 0; i < m.length; i++) {
            m[i] = (byte) (255 - (m[i] & 0xFF));
        }
    }

    /** Corta los valores intermedios: todo o nada. */
    public static void threshold(byte[] m, int level) {
        for (int i = 0; i < m.length; i++) {
            m[i] = (byte) ((m[i] & 0xFF) >= level ? 255 : 0);
        }
    }

    public static void copyInto(byte[] dst, byte[] src) {
        System.arraycopy(src, 0, dst, 0, src.length);
    }

    /**
     * Pincel circular con borde suave. Devuelve el rectangulo tocado.
     * value 255 = pintar seleccion, 0 = borrar.
     */
    public static Rect stamp(byte[] m, int w, int h, float cx, float cy, float radius,
                             float hardness, boolean erase) {
        return stamp(m, w, h, cx, cy, radius, hardness, erase, 1f);
    }

    /** strength 0..1 es la opacidad del pincel o de la goma. */
    public static Rect stamp(byte[] m, int w, int h, float cx, float cy, float radius,
                             float hardness, boolean erase, float strength) {
        if (strength <= 0f) return null;
        if (strength > 1f) strength = 1f;
        int x0 = (int) Math.floor(cx - radius) - 1;
        int y0 = (int) Math.floor(cy - radius) - 1;
        int x1 = (int) Math.ceil(cx + radius) + 1;
        int y1 = (int) Math.ceil(cy + radius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return null;

        float inner = radius * hardness;
        float band = Math.max(1f, radius - inner);

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > radius) continue;
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (a <= 0f) continue;
                int cur = m[row + x] & 0xFF;
                int add = (int) (a * 255f * strength);
                if (erase) {
                    int v = cur - add;
                    m[row + x] = (byte) (v < 0 ? 0 : v);
                } else {
                    if (add > cur) m[row + x] = (byte) add;
                }
            }
        }
        return new Rect(x0, y0, x1, y1);
    }

    /**
     * Maximo en ventana por van Herk y Gil-Werman: tres comparaciones por
     * pixel, sin importar el radio. Antes costaba r veces mas.
     */
    private static void maxFilter(byte[] m, int w, int h, int r) {
        int win = 2 * r + 1;
        int n = Math.max(w, h);
        int[] line = new int[n];
        int[] g = new int[n + 2 * win];
        int[] hh = new int[n + 2 * win];

        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) line[x] = m[row + x] & 0xFF;
            vanHerk(line, w, win, g, hh);
            for (int x = 0; x < w; x++) m[row + x] = (byte) line[x];
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) line[y] = m[y * w + x] & 0xFF;
            vanHerk(line, h, win, g, hh);
            for (int y = 0; y < h; y++) m[y * w + x] = (byte) line[y];
        }
    }

    private static void vanHerk(int[] a, int n, int win, int[] g, int[] h) {
        int r = win / 2;
        int pad = win;
        int total = n + 2 * pad;
        // borde replicado para no inventar valores fuera de la imagen
        for (int i = 0; i < total; i++) {
            int src = i - pad;
            if (src < 0) src = 0;
            if (src >= n) src = n - 1;
            g[i] = a[src];
            h[i] = a[src];
        }
        for (int i = 0; i < total; i++) {
            if (i % win == 0) g[i] = g[i];
            else g[i] = Math.max(g[i - 1], g[i]);
        }
        for (int i = total - 1; i >= 0; i--) {
            if (i == total - 1 || (i + 1) % win == 0) h[i] = h[i];
            else h[i] = Math.max(h[i + 1], h[i]);
        }
        for (int i = 0; i < n; i++) {
            int c = i + pad;
            int lo = c - r;
            int hi = c + r;
            a[i] = Math.max(h[lo], g[hi]);
        }
    }

    private static void boxBlur(byte[] m, int w, int h, int r) {
        byte[] tmp = new byte[m.length];
        int win = r * 2 + 1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            int sum = 0;
            for (int i = -r; i <= r; i++) {
                sum += m[row + clamp(i, w)] & 0xFF;
            }
            for (int x = 0; x < w; x++) {
                tmp[row + x] = (byte) (sum / win);
                sum -= m[row + clamp(x - r, w)] & 0xFF;
                sum += m[row + clamp(x + r + 1, w)] & 0xFF;
            }
        }
        for (int x = 0; x < w; x++) {
            int sum = 0;
            for (int i = -r; i <= r; i++) {
                sum += tmp[clamp(i, h) * w + x] & 0xFF;
            }
            for (int y = 0; y < h; y++) {
                m[y * w + x] = (byte) (sum / win);
                sum -= tmp[clamp(y - r, h) * w + x] & 0xFF;
                sum += tmp[clamp(y + r + 1, h) * w + x] & 0xFF;
            }
        }
    }

    private static int clamp(int v, int max) {
        if (v < 0) return 0;
        if (v >= max) return max - 1;
        return v;
    }
}
