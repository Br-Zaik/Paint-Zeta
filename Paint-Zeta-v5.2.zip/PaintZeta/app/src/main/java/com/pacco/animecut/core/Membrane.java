package com.pacco.animecut.core;

/**
 * Pincel corrector (Perez, Gangnet y Blake, 2003).
 *
 * Lo copiado conserva su textura, pero su color se corrige para que en el
 * borde coincida con lo que habia. La correccion es una membrana suave que
 * vale la diferencia de color en el borde y se reparte hacia adentro. Asi no
 * se ve el escalon de tono que deja el clonar.
 */
public final class Membrane {

    public interface SourceMap {
        /** Pixel de origen que corresponde al destino (x, y), o -1. */
        int map(int x, int y);
    }

    private Membrane() {
    }

    /**
     * @param px     imagen ya clonada (se corrige aqui)
     * @param orig   imagen antes del trazo
     * @param src    imagen de donde se copio (la misma copia del inicio del trazo)
     * @param region pixeles pintados por el trazo
     */
    public static void heal(int[] px, int[] orig, int[] src, int w, int h, boolean[] region,
                            int left, int top, int right, int bottom, SourceMap map) {
        int rw = right - left, rh = bottom - top;
        if (rw <= 0 || rh <= 0) return;
        int[] id = new int[rw * rh];
        java.util.Arrays.fill(id, -1);
        int n = 0;
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                if (region[y * rw + x]) id[y * rw + x] = n++;
            }
        }
        if (n == 0) return;
        int[] gx = new int[n], gy = new int[n];
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                int k = id[y * rw + x];
                if (k < 0) continue;
                gx[k] = left + x;
                gy[k] = top + y;
            }
        }
        // vecinos: indice dentro de la region, o valor fijo del borde
        int[][] nb = new int[n][4];
        float[][][] fixed = new float[3][n][4];
        int[] dxs = {-1, 1, 0, 0}, dys = {0, 0, -1, 1};
        for (int k = 0; k < n; k++) {
            for (int d = 0; d < 4; d++) {
                int x = gx[k] + dxs[d], y = gy[k] + dys[d];
                int lx = x - left, ly = y - top;
                if (lx >= 0 && ly >= 0 && lx < rw && ly < rh && id[ly * rw + lx] >= 0) {
                    nb[k][d] = id[ly * rw + lx];
                } else {
                    nb[k][d] = -1;
                    int cx = Math.max(0, Math.min(w - 1, x)), cy = Math.max(0, Math.min(h - 1, y));
                    int o = orig[cy * w + cx];
                    int s = map.map(cx, cy);
                    int sc = s >= 0 ? src[s] : o;
                    // en el borde la correccion vale lo que falta para llegar al original
                    fixed[0][k][d] = ((o >> 16) & 0xFF) - ((sc >> 16) & 0xFF);
                    fixed[1][k][d] = ((o >> 8) & 0xFF) - ((sc >> 8) & 0xFF);
                    fixed[2][k][d] = (o & 0xFF) - (sc & 0xFF);
                }
            }
        }
        float[][] c = new float[3][n];
        int iters = Math.min(600, 80 + (int) Math.sqrt(n) * 6);
        float omega = 1.85f;
        for (int it = 0; it < iters; it++) {
            for (int ch = 0; ch < 3; ch++) {
                float[] cc = c[ch];
                float[][] fx = fixed[ch];
                for (int k = 0; k < n; k++) {
                    float s = 0;
                    for (int d = 0; d < 4; d++) {
                        int q = nb[k][d];
                        s += q >= 0 ? cc[q] : fx[k][d];
                    }
                    float v = s / 4f;
                    cc[k] += omega * (v - cc[k]);
                }
            }
        }
        for (int k = 0; k < n; k++) {
            int i = gy[k] * w + gx[k];
            int p = px[i];
            int r = clamp(((p >> 16) & 0xFF) + Math.round(c[0][k]));
            int g = clamp(((p >> 8) & 0xFF) + Math.round(c[1][k]));
            int b = clamp((p & 0xFF) + Math.round(c[2][k]));
            px[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
        }
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }
}
