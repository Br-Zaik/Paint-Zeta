package com.pacco.animecut.core;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Corre lo pesado en segundo plano para que la app no se congele. */
public final class Task {

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Task() {
    }

    public static void run(final Runnable background, final Runnable afterOnUi) {
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    background.run();
                } catch (final Throwable t) {
                    t.printStackTrace();
                }
                MAIN.post(afterOnUi);
            }
        });
    }
}
