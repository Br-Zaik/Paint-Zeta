package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Limpieza del borde recortado.
 *
 * Cuando sacas una parte de la imagen, los pixeles del filo son una mezcla
 * del dibujo con el fondo que habia detras. Al ponerlos sobre otro fondo en
 * Alight Motion, esa mezcla se ve como un halo blanco o gris alrededor.
 *
 * Aqui se arregla de dos maneras, que se pueden combinar:
 *
 *  1) Defringe: al pixel del filo se le pone el color del pixel opaco mas
 *     cercano de adentro. Es lo que hace Photoshop con "Defringe".
 *
 *  2) Quitar el fondo: si sabemos de que color era el fondo, se despeja la
 *     mezcla. El pixel visto es C = a*F + (1-a)*B, asi que el color real es
 *     F = (C - (1-a)*B) / a.
 */
public final class Defringe {

    private Defringe() {
    }

    /** Devuelve una copia de los pixeles con el borde limpio. */
    public static int[] clean(int[] pixels, final byte[] mask, int w, int h,
                              int radius, boolean removeBackground, int background) {
        int[] out = new int[pixels.length];
        System.arraycopy(pixels, 0, out, 0, pixels.length);

        Rect area = bounds(mask, w, h);
        if (area == null) return out;
        area.inset(-(radius + 2), -(radius + 2));

        DistanceTransform dt = DistanceTransform.build(w, h, area, new DistanceTransform.Source() {
            @Override
            public boolean isSource(int index) {
                return (mask[index] & 0xFF) >= 250;
            }
        }, true);
        if (dt == null) return out;

        float maxD2 = radius * (float) radius;

        for (int y = 0; y < dt.rh; y++) {
            int row = y * dt.rw;
            int base = (dt.rect.top + y) * w + dt.rect.left;
            for (int x = 0; x < dt.rw; x++) {
                int i = base + x;
                int a = mask[i] & 0xFF;
                if (a == 0 || a >= 250) continue;

                int c = out[i];

                if (removeBackground) {
                    c = unmultiply(c, a, background);
                }

                int src = dt.nearest[row + x];
                float d2 = dt.dist2[row + x];
                if (src >= 0 && d2 <= maxD2) {
                    // Se mezcla hacia el color de adentro: cuanto mas
                    // transparente es el pixel, mas contaminado esta.
                    float t = 1f - (a / 250f);
                    c = mix(c, out[src], t);
                }
                out[i] = c;
            }
        }
        return out;
    }

    /** Despeja el color real a partir de la mezcla con el fondo conocido. */
    private static int unmultiply(int c, int a, int bg) {
        float al = a / 255f;
        if (al < 0.02f) return c;
        int r = solve((c >> 16) & 0xFF, (bg >> 16) & 0xFF, al);
        int g = solve((c >> 8) & 0xFF, (bg >> 8) & 0xFF, al);
        int b = solve(c & 0xFF, bg & 0xFF, al);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int solve(int c, int bg, float a) {
        float f = (c - (1f - a) * bg) / a;
        int v = (int) (f + 0.5f);
        if (v < 0) v = 0;
        if (v > 255) v = 255;
        return v;
    }

    private static int mix(int dst, int src, float t) {
        if (t <= 0f) return dst;
        if (t > 1f) t = 1f;
        int it = (int) (t * 256f);
        int r = (((src >> 16) & 0xFF) * it + ((dst >> 16) & 0xFF) * (256 - it)) >> 8;
        int g = (((src >> 8) & 0xFF) * it + ((dst >> 8) & 0xFF) * (256 - it)) >> 8;
        int b = ((src & 0xFF) * it + (dst & 0xFF) * (256 - it)) >> 8;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /**
     * Adivina el color del fondo: promedia los pixeles que quedaron fuera
     * de la capa pero pegados a su borde.
     */
    public static int guessBackground(int[] pixels, byte[] mask, int w, int h) {
        long r = 0, g = 0, b = 0, n = 0;
        for (int y = 1; y < h - 1; y++) {
            int row = y * w;
            for (int x = 1; x < w - 1; x++) {
                int i = row + x;
                if ((mask[i] & 0xFF) != 0) continue;
                boolean touching = (mask[i - 1] & 0xFF) > 128 || (mask[i + 1] & 0xFF) > 128
                        || (mask[i - w] & 0xFF) > 128 || (mask[i + w] & 0xFF) > 128;
                if (!touching) continue;
                int c = pixels[i];
                r += (c >> 16) & 0xFF;
                g += (c >> 8) & 0xFF;
                b += c & 0xFF;
                n++;
            }
        }
        if (n == 0) return 0xFFFFFFFF;
        return 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    private static Rect bounds(byte[] mask, int w, int h) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (mask[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }
}
