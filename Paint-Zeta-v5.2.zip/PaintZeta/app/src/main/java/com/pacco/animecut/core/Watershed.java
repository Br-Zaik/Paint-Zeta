package com.pacco.animecut.core;

/**
 * Separar partes con rayones, como la Colorize Mask de Krita.
 *
 * Pintas un rayon de color en cada parte. Se inunda la imagen desde esos
 * rayones empezando por lo claro, y las lineas negras del dibujo quedan
 * para el final: por eso el limite entre partes cae justo sobre la linea.
 *
 * Es inundacion con marcadores (watershed) con una cola por cubos de 256
 * niveles: coste lineal, sin resolver ecuaciones.
 */
public final class Watershed {

    private Watershed() {
    }

    /**
     * @param labels   rayones del usuario: 0 sin marcar, 1..254 cada parte
     * @param gapClose cuanto se desenfoca la linea para tapar sus cortes
     * @param bgLabel  etiqueta del fondo; si no hay rayones de fondo, el borde
     *                 de la imagen se usa como fondo
     * @return una etiqueta por pixel
     */
    public static byte[] run(int[] px, int w, int h, byte[] labels, int gapClose, int bgLabel) {
        int n = w * h;

        // relieve: lo oscuro es alto, lo claro es bajo
        byte[] relief = new byte[n];
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int lum = (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
            relief[i] = (byte) (255 - lum);
        }
        if (gapClose > 0) {
            // el desenfoque rellena los cortes finos de la linea
            byte[] blurred = relief.clone();
            MaskOps.feather(blurred, w, h, gapClose);
            for (int i = 0; i < n; i++) {
                int a = relief[i] & 0xFF, b = blurred[i] & 0xFF;
                relief[i] = (byte) Math.max(a, b);
            }
        }

        byte[] out = labels.clone();
        boolean hasBg = false;
        for (int i = 0; i < n; i++) {
            if ((out[i] & 0xFF) == bgLabel) {
                hasBg = true;
                break;
            }
        }
        if (!hasBg) {
            for (int x = 0; x < w; x++) {
                if (out[x] == 0) out[x] = (byte) bgLabel;
                int b = (h - 1) * w + x;
                if (out[b] == 0) out[b] = (byte) bgLabel;
            }
            for (int y = 0; y < h; y++) {
                if (out[y * w] == 0) out[y * w] = (byte) bgLabel;
                int r = y * w + w - 1;
                if (out[r] == 0) out[r] = (byte) bgLabel;
            }
        }

        Buckets q = new Buckets();
        for (int i = 0; i < n; i++) {
            if (out[i] != 0) q.push(relief[i] & 0xFF, i);
        }

        while (true) {
            int lvl = q.level();
            if (lvl < 0) break;
            int p = q.pop();
            int lab = out[p];
            int y = p / w;
            int x = p - y * w;
            if (x > 0) visit(p - 1, lab, lvl, out, relief, q);
            if (x < w - 1) visit(p + 1, lab, lvl, out, relief, q);
            if (y > 0) visit(p - w, lab, lvl, out, relief, q);
            if (y < h - 1) visit(p + w, lab, lvl, out, relief, q);
        }
        return out;
    }

    private static void visit(int q, int lab, int lvl, byte[] out, byte[] relief, Buckets b) {
        if (out[q] != 0) return;
        out[q] = (byte) lab;
        int r = relief[q] & 0xFF;
        b.push(r > lvl ? r : lvl, q);
    }

    /** Cola por niveles: sacar siempre del nivel mas bajo con algo. */
    private static final class Buckets {
        private final int[][] a = new int[256][];
        private final int[] n = new int[256];
        private int cur = 0;

        void push(int level, int v) {
            int[] arr = a[level];
            if (arr == null) {
                arr = new int[1024];
                a[level] = arr;
            } else if (n[level] == arr.length) {
                int[] b = new int[arr.length * 2];
                System.arraycopy(arr, 0, b, 0, arr.length);
                a[level] = b;
                arr = b;
            }
            arr[n[level]++] = v;
            if (level < cur) cur = level;
        }

        int level() {
            while (cur < 256 && n[cur] == 0) cur++;
            return cur < 256 ? cur : -1;
        }

        int pop() {
            return a[cur][--n[cur]];
        }
    }
}
