package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Tampon de clonar: copia pixeles de una zona origen a donde arrastras el dedo,
 * manteniendo siempre la misma distancia entre origen y destino.
 * Sirve para tapar el hueco que queda al sacar una parte, o para rellenar
 * copiando un trozo del propio dibujo.
 *
 * El array de origen se captura UNA sola vez al empezar el trazo
 * (ver CanvasView), nunca dentro del bucle: copiar la imagen completa
 * en cada movimiento del dedo dejaria la app inusable.
 */
public final class CloneStamp {

    private CloneStamp() {
    }

    /**
     * @param dst  destino, se modifica
     * @param src  copia de los pixeles al empezar el trazo
     * @param offX destino - origen en X
     * @param offY destino - origen en Y
     */
    public static Rect stamp(int[] dst, int[] src, int w, int h, float cx, float cy,
                             float radius, float hardness, int offX, int offY) {
        int x0 = (int) Math.floor(cx - radius);
        int y0 = (int) Math.floor(cy - radius);
        int x1 = (int) Math.ceil(cx + radius) + 1;
        int y1 = (int) Math.ceil(cy + radius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return null;

        float inner = radius * hardness;
        float band = Math.max(1f, radius - inner);

        for (int y = y0; y < y1; y++) {
            float dy = y + 0.5f - cy;
            int row = y * w;
            int sy = y - offY;
            if (sy < 0 || sy >= h) continue;
            int srow = sy * w;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > radius) continue;
                int sx = x - offX;
                if (sx < 0 || sx >= w) continue;
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (a <= 0f) continue;
                dst[row + x] = mix(dst[row + x], src[srow + sx], a);
            }
        }
        return new Rect(x0, y0, x1, y1);
    }

    private static int mix(int dst, int src, float a) {
        int ia = (int) (a * 256f);
        int r = (((src >> 16) & 0xFF) * ia + ((dst >> 16) & 0xFF) * (256 - ia)) >> 8;
        int g = (((src >> 8) & 0xFF) * ia + ((dst >> 8) & 0xFF) * (256 - ia)) >> 8;
        int b = ((src & 0xFF) * ia + (dst & 0xFF) * (256 - ia)) >> 8;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
