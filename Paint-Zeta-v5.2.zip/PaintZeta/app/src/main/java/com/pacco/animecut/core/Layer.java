package com.pacco.animecut.core;

/**
 * Una capa = una mascara de opacidad del mismo tamano que la imagen original.
 * 1 byte por pixel (0 = transparente, 255 = opaco). Ocupa 4 veces menos
 * memoria que guardar un bitmap ARGB completo por capa.
 */
public class Layer {

    public String name;
    public boolean visible = true;
    /** 0 a 255. Se aplica al exportar. */
    public int opacity = 255;
    public byte[] mask;

    /**
     * Copia propia de los pixeles de la parte, solo en su rectangulo.
     * Aparece cuando se tapa el hueco debajo: la imagen de abajo se pinta
     * con piel, pero esta capa conserva su ojo original.
     */
    public int[] own;
    public android.graphics.Rect ownRect;

    /** Marca las capas creadas por "separar partes", para rehacerlas. */
    public int autoLabel = -1;

    /** Color de esta capa en el pixel i (x, y). */
    public int colorAt(int[] base, int i, int x, int y) {
        if (own != null && ownRect != null && ownRect.contains(x, y)) {
            return own[(y - ownRect.top) * ownRect.width() + (x - ownRect.left)];
        }
        return base[i];
    }

    public Layer(String name, byte[] mask) {
        this.name = name;
        this.mask = mask;
    }
}
