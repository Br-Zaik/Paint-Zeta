package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Refinado del borde de la seleccion (He, Sun y Tang).
 *
 * Toma la mascara dura y la imagen, y hace que el alfa siga el borde real
 * del dibujo. Sirve para pelo y bordes finos, donde una mascara de si o no
 * siempre queda mal.
 *
 * Se calcula en una version reducida y despues se estiran los coeficientes
 * a tamano completo, que es la version rapida del mismo filtro. Asi no hace
 * falta reservar decenas de MB.
 */
public final class GuidedFilter {

    private GuidedFilter() {
    }

    /**
     * @param radius radio del filtro en pixeles de la imagen completa
     * @param eps    cuanto respeta el borde; mas bajo, mas pegado al borde
     */
    public static void refine(byte[] mask, int[] pixels, int w, int h,
                              int radius, float eps, Rect area) {
        Rect r = area == null ? new Rect(0, 0, w, h) : new Rect(area);
        r.inset(-(radius * 2), -(radius * 2));
        if (r.left < 0) r.left = 0;
        if (r.top < 0) r.top = 0;
        if (r.right > w) r.right = w;
        if (r.bottom > h) r.bottom = h;
        int rw = r.width(), rh = r.height();
        if (rw < 8 || rh < 8) return;

        int scale = 4;
        int sw = Math.max(4, rw / scale);
        int sh = Math.max(4, rh / scale);
        int sr = Math.max(1, radius / scale);

        float[] I = new float[sw * sh];
        float[] P = new float[sw * sh];
        for (int y = 0; y < sh; y++) {
            int sy = r.top + Math.min(rh - 1, y * rh / sh);
            int base = sy * w;
            int row = y * sw;
            for (int x = 0; x < sw; x++) {
                int sx = r.left + Math.min(rw - 1, x * rw / sw);
                int c = pixels[base + sx];
                float lum = (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151
                        + (c & 0xFF) * 28) / 255f / 256f;
                I[row + x] = lum;
                P[row + x] = (mask[base + sx] & 0xFF) / 255f;
            }
        }

        float[] meanI = box(I, sw, sh, sr);
        float[] meanP = box(P, sw, sh, sr);
        float[] ip = new float[sw * sh];
        float[] ii = new float[sw * sh];
        for (int i = 0; i < ip.length; i++) {
            ip[i] = I[i] * P[i];
            ii[i] = I[i] * I[i];
        }
        float[] meanIP = box(ip, sw, sh, sr);
        float[] meanII = box(ii, sw, sh, sr);

        float[] a = new float[sw * sh];
        float[] b = new float[sw * sh];
        for (int i = 0; i < a.length; i++) {
            float cov = meanIP[i] - meanI[i] * meanP[i];
            float var = meanII[i] - meanI[i] * meanI[i];
            a[i] = cov / (var + eps);
            b[i] = meanP[i] - a[i] * meanI[i];
        }
        float[] meanA = box(a, sw, sh, sr);
        float[] meanB = box(b, sw, sh, sr);

        // se estiran los coeficientes a tamano completo
        for (int y = 0; y < rh; y++) {
            int sy = Math.min(sh - 1, y * sh / rh);
            int srow = sy * sw;
            int base = (r.top + y) * w;
            for (int x = 0; x < rw; x++) {
                int sx = Math.min(sw - 1, x * sw / rw);
                int i = base + r.left + x;
                int c = pixels[i];
                float lum = (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151
                        + (c & 0xFF) * 28) / 255f / 256f;
                float v = meanA[srow + sx] * lum + meanB[srow + sx];
                int q = (int) (v * 255f + 0.5f);
                if (q < 0) q = 0;
                if (q > 255) q = 255;
                mask[i] = (byte) q;
            }
        }
    }

    /** Media en ventana con sumas acumuladas: coste lineal. */
    private static float[] box(float[] src, int w, int h, int r) {
        float[] tmp = new float[w * h];
        float[] out = new float[w * h];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            float sum = 0;
            for (int x = 0; x <= Math.min(r, w - 1); x++) sum += src[row + x];
            for (int x = 0; x < w; x++) {
                int lo = x - r - 1, hi = x + r;
                if (hi < w) sum += src[row + hi];
                if (lo >= 0) sum -= src[row + lo];
                int n = Math.min(w - 1, x + r) - Math.max(0, x - r) + 1;
                tmp[row + x] = sum / n;
            }
        }
        for (int x = 0; x < w; x++) {
            float sum = 0;
            for (int y = 0; y <= Math.min(r, h - 1); y++) sum += tmp[y * w + x];
            for (int y = 0; y < h; y++) {
                int lo = y - r - 1, hi = y + r;
                if (hi < h) sum += tmp[hi * w + x];
                if (lo >= 0) sum -= tmp[lo * w + x];
                int n = Math.min(h - 1, y + r) - Math.max(0, y - r) + 1;
                out[y * w + x] = sum / n;
            }
        }
        return out;
    }
}
