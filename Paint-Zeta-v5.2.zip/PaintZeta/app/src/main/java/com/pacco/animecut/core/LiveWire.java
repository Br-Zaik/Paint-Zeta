package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Tijeras inteligentes. Vas tocando cerca del contorno y la linea se pega
 * sola al borde del dibujo.
 *
 * Por dentro es el metodo de Mortensen y Barrett: se arma un mapa donde
 * pasar por encima de un borde cuesta barato y pasar por una zona plana
 * cuesta caro, y se busca el camino mas barato desde el ultimo punto que
 * fijaste hasta donde tienes el dedo (Dijkstra).
 *
 * El calculo se hace en una ventana alrededor del punto fijado, no en toda
 * la imagen, para que responda al instante y no se coma la memoria.
 */
public final class LiveWire {

    private static final int INF = Integer.MAX_VALUE / 4;

    private final int w, h;
    /** Coste de entrar a cada pixel: 0 es borde fuerte, 255 zona plana. */
    private final byte[] cost;

    private Rect win;
    private int[] dist;
    private int[] prev;
    private int anchor = -1;

    public LiveWire(int[] pixels, int w, int h) {
        this.w = w;
        this.h = h;
        this.cost = buildCost(pixels, w, h);
    }

    /** Sobel sobre la luminancia. Donde hay borde, el coste baja. */
    private static byte[] buildCost(int[] px, int w, int h) {
        byte[] lum = new byte[w * h];
        for (int i = 0; i < lum.length; i++) {
            int c = px[i];
            lum[i] = (byte) ((((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151
                    + (c & 0xFF) * 28) >> 8);
        }
        byte[] out = new byte[w * h];
        int maxG = 1;
        int[] g = new int[w * h];
        for (int y = 1; y < h - 1; y++) {
            int row = y * w;
            for (int x = 1; x < w - 1; x++) {
                int i = row + x;
                int tl = lum[i - w - 1] & 0xFF, t = lum[i - w] & 0xFF, tr = lum[i - w + 1] & 0xFF;
                int l = lum[i - 1] & 0xFF, r = lum[i + 1] & 0xFF;
                int bl = lum[i + w - 1] & 0xFF, b = lum[i + w] & 0xFF, br = lum[i + w + 1] & 0xFF;
                int gx = (tr + 2 * r + br) - (tl + 2 * l + bl);
                int gy = (bl + 2 * b + br) - (tl + 2 * t + tr);
                int m = Math.abs(gx) + Math.abs(gy);
                g[i] = m;
                if (m > maxG) maxG = m;
            }
        }
        for (int i = 0; i < out.length; i++) {
            int v = 255 - (g[i] * 255) / maxG;
            out[i] = (byte) v;
        }
        return out;
    }

    /** Fija el punto de partida y prepara los caminos a su alrededor. */
    public void setAnchor(int ax, int ay, int windowRadius) {
        anchor = ay * w + ax;
        int l = Math.max(0, ax - windowRadius);
        int t = Math.max(0, ay - windowRadius);
        int r = Math.min(w, ax + windowRadius);
        int b = Math.min(h, ay + windowRadius);
        win = new Rect(l, t, r, b);
        int rw = win.width(), rh = win.height();
        dist = new int[rw * rh];
        prev = new int[rw * rh];
        java.util.Arrays.fill(dist, INF);
        java.util.Arrays.fill(prev, -1);

        int start = (ay - t) * rw + (ax - l);
        dist[start] = 0;

        LongHeap heap = new LongHeap();
        heap.push(pack(0, start));

        while (!heap.isEmpty()) {
            long top = heap.pop();
            int d = (int) (top >>> 32);
            int idx = (int) (top & 0xFFFFFFFFL);
            if (d > dist[idx]) continue;

            int y = idx / rw;
            int x = idx - y * rw;
            for (int dy = -1; dy <= 1; dy++) {
                int ny = y + dy;
                if (ny < 0 || ny >= rh) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int nx = x + dx;
                    if (nx < 0 || nx >= rw) continue;
                    int nIdx = ny * rw + nx;
                    int full = (t + ny) * w + (l + nx);
                    int step = (cost[full] & 0xFF) + 1;
                    // en diagonal el paso es mas largo
                    if (dx != 0 && dy != 0) step = (step * 7) / 5;
                    int nd = d + step;
                    if (nd < dist[nIdx]) {
                        dist[nIdx] = nd;
                        prev[nIdx] = idx;
                        heap.push(pack(nd, nIdx));
                    }
                }
            }
        }
    }

    public boolean hasAnchor() {
        return anchor >= 0 && win != null;
    }

    public int getAnchor() {
        return anchor;
    }

    /**
     * Camino desde el punto fijado hasta donde esta el dedo.
     * Devuelve indices de la imagen completa, del dedo hacia el ancla.
     */
    public int[] pathTo(int x, int y) {
        if (win == null) return null;
        int cx = Math.max(win.left, Math.min(win.right - 1, x));
        int cy = Math.max(win.top, Math.min(win.bottom - 1, y));
        int rw = win.width();
        int idx = (cy - win.top) * rw + (cx - win.left);
        if (dist[idx] >= INF) return null;

        int n = 0;
        int p = idx;
        while (p >= 0 && n < 200000) {
            n++;
            p = prev[p];
        }
        int[] out = new int[n];
        p = idx;
        for (int i = 0; i < n && p >= 0; i++) {
            int py = p / rw;
            int px = p - py * rw;
            out[i] = (win.top + py) * w + (win.left + px);
            p = prev[p];
        }
        return out;
    }

    private static long pack(int d, int idx) {
        return ((long) d << 32) | (idx & 0xFFFFFFFFL);
    }

    /** Monticulo binario de longs: coste arriba, indice abajo. */
    private static final class LongHeap {
        private long[] a = new long[1 << 14];
        private int n = 0;

        void push(long v) {
            if (n == a.length) {
                long[] b = new long[a.length * 2];
                System.arraycopy(a, 0, b, 0, a.length);
                a = b;
            }
            int i = n++;
            a[i] = v;
            while (i > 0) {
                int p = (i - 1) >> 1;
                if (a[p] <= a[i]) break;
                long t = a[p];
                a[p] = a[i];
                a[i] = t;
                i = p;
            }
        }

        long pop() {
            long top = a[0];
            a[0] = a[--n];
            int i = 0;
            while (true) {
                int l = i * 2 + 1, r = l + 1, m = i;
                if (l < n && a[l] < a[m]) m = l;
                if (r < n && a[r] < a[m]) m = r;
                if (m == i) break;
                long t = a[m];
                a[m] = a[i];
                a[i] = t;
                i = m;
            }
            return top;
        }

        boolean isEmpty() {
            return n == 0;
        }
    }
}
