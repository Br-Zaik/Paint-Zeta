package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Varita magica. Relleno por lineas (scanline), coste lineal, sin recursion.
 *
 * Novedad importante: la seleccion ya no es si o no. Los pixeles que se
 * parecen del todo entran con 255, y los que estan en el filo entran a
 * medias. Eso es lo que evita el borde escalonado, porque el contorno de un
 * dibujo tiene pixeles intermedios por el antialias.
 */
public final class FloodFill {

    private FloodFill() {
    }

    /**
     * @param tolerance hasta aqui el pixel entra completo
     * @param softness  franja extra donde el pixel entra a medias
     * @param mode      ver ColorDist
     */
    public static Rect contiguous(int[] px, int w, int h, byte[] out, byte[] barrier,
                                  int seedX, int seedY, int tolerance, int softness, int mode) {
        if (seedX < 0 || seedY < 0 || seedX >= w || seedY >= h) return null;
        int seed = seedY * w + seedX;
        if (barrier != null && barrier[seed] != 0) return null;

        final int target = px[seed];
        final int limit = tolerance + softness;

        boolean[] done = new boolean[w * h];
        IntStack stack = new IntStack();
        stack.push(seed);

        int minX = seedX, maxX = seedX, minY = seedY, maxY = seedY;

        while (!stack.isEmpty()) {
            int idx = stack.pop();
            if (done[idx]) continue;

            int y = idx / w;
            int x = idx - y * w;
            int row = y * w;

            int x1 = x;
            while (x1 >= 0 && ok(px, done, barrier, row + x1, target, limit, mode)) x1--;
            x1++;
            int x2 = x;
            while (x2 < w && ok(px, done, barrier, row + x2, target, limit, mode)) x2++;
            x2--;
            if (x2 < x1) continue;

            for (int i = x1; i <= x2; i++) {
                int id = row + i;
                done[id] = true;
                int a = alphaFor(px[id], target, tolerance, softness, mode);
                if (a > (out[id] & 0xFF)) out[id] = (byte) a;
            }

            if (x1 < minX) minX = x1;
            if (x2 > maxX) maxX = x2;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;

            if (y > 0) push(px, done, barrier, stack, row - w, x1, x2, target, limit, mode);
            if (y < h - 1) push(px, done, barrier, stack, row + w, x1, x2, target, limit, mode);
        }
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** Selecciona ese color en TODA la imagen, no solo lo que esta pegado. */
    public static Rect global(int[] px, int w, int h, byte[] out,
                              int seedX, int seedY, int tolerance, int softness, int mode) {
        if (seedX < 0 || seedY < 0 || seedX >= w || seedY >= h) return null;
        return globalColor(px, w, h, out, px[seedY * w + seedX], tolerance, softness, mode);
    }

    /** Igual que global pero dando el color a mano. Lo usa Gama de colores. */
    public static Rect globalColor(int[] px, int w, int h, byte[] out, int target,
                                   int tolerance, int softness, int mode) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int a = alphaFor(px[row + x], target, tolerance, softness, mode);
                if (a <= 0) continue;
                if (a > (out[row + x] & 0xFF)) out[row + x] = (byte) a;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** 255 si es el mismo color, 0 si esta fuera, y rampa suave en el filo. */
    private static int alphaFor(int c, int target, int tolerance, int softness, int mode) {
        int d = ColorDist.dist(c, target, mode);
        if (d <= tolerance) return 255;
        if (softness <= 0) return 0;
        int over = d - tolerance;
        if (over >= softness) return 0;
        return 255 - (over * 255) / softness;
    }

    private static void push(int[] px, boolean[] done, byte[] barrier, IntStack stack,
                             int row, int x1, int x2, int target, int limit, int mode) {
        boolean run = false;
        for (int i = x1; i <= x2; i++) {
            boolean good = ok(px, done, barrier, row + i, target, limit, mode);
            if (good && !run) {
                stack.push(row + i);
                run = true;
            } else if (!good) {
                run = false;
            }
        }
    }

    /** Pila que crece sola. Evita pasarse el indice entre metodos. */
    private static final class IntStack {
        private int[] a = new int[4096];
        private int n = 0;

        void push(int v) {
            if (n == a.length) {
                int[] b = new int[a.length * 2];
                System.arraycopy(a, 0, b, 0, a.length);
                a = b;
            }
            a[n++] = v;
        }

        int pop() {
            return a[--n];
        }

        boolean isEmpty() {
            return n == 0;
        }
    }

    private static boolean ok(int[] px, boolean[] done, byte[] barrier, int idx,
                              int target, int limit, int mode) {
        if (done[idx]) return false;
        if (barrier != null && barrier[idx] != 0) return false;
        return ColorDist.dist(px[idx], target, mode) <= limit;
    }

    public static boolean similar(int a, int b, int tol) {
        return ColorDist.dist(a, b, ColorDist.RGB) <= tol;
    }

}
