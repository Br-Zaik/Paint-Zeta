package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Continuar la trama del manga. Mide cada cuanto se repiten los puntos o
 * las lineas de la trama tocada (comparando la trama con ella misma
 * desplazada) y rellena el hueco copiando desde el mismo punto de esa
 * repeticion. Asi los puntos quedan alineados y no se nota el corte.
 */
public final class ToneFill {

    private ToneFill() {
    }

    /** @return el rectangulo tocado, o null si ahi no hay una trama regular */
    public static Rect fill(int[] px, int w, int h, byte[] region, int sx, int sy) {
        int half = 48;
        int x0 = Math.max(0, sx - half), y0 = Math.max(0, sy - half);
        int x1 = Math.min(w, sx + half), y1 = Math.min(h, sy + half);
        int ww = x1 - x0, wh = y1 - y0;
        if (ww < 24 || wh < 24) return null;

        // trama en blanco y negro
        long sum = 0;
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) sum += LineRepair.lum(px[y * w + x]);
        int mean = (int) (sum / ((long) ww * wh));
        boolean[] bin = new boolean[ww * wh];
        boolean[] usable = new boolean[ww * wh];
        for (int y = 0; y < wh; y++) {
            for (int x = 0; x < ww; x++) {
                int i = (y0 + y) * w + (x0 + x);
                bin[y * ww + x] = LineRepair.lum(px[i]) < mean;
                usable[y * ww + x] = region == null || (region[i] & 0xFF) <= 64;
            }
        }

        // se prueba cada desplazamiento: donde la trama casi coincide consigo misma, ahi se repite
        int maxS = 22;
        float best1 = 1f, best2 = 1f;
        int v1x = 0, v1y = 0, v2x = 0, v2y = 0;
        float[][] mis = new float[2 * maxS + 1][maxS + 1];
        for (int dy = 0; dy <= maxS; dy++) {
            for (int dx = -maxS; dx <= maxS; dx++) {
                if (dy == 0 && dx <= 0) {
                    mis[dx + maxS][dy] = 1f;
                    continue;
                }
                if (Math.abs(dx) < 2 && dy < 2) {
                    mis[dx + maxS][dy] = 1f;
                    continue;
                }
                int diff = 0, n = 0;
                for (int y = 0; y + dy < wh; y += 2) {
                    for (int x = Math.max(0, -dx); x < ww && x + dx < ww; x += 2) {
                        int a = y * ww + x, b = (y + dy) * ww + (x + dx);
                        if (!usable[a] || !usable[b]) continue;
                        if (bin[a] != bin[b]) diff++;
                        n++;
                    }
                }
                mis[dx + maxS][dy] = n < 50 ? 1f : diff / (float) n;
            }
        }
        // primer vector: el que mejor coincide (a igualdad, el mas corto)
        for (int dy = 0; dy <= maxS; dy++) {
            for (int dx = -maxS; dx <= maxS; dx++) {
                float m = mis[dx + maxS][dy] + (float) Math.hypot(dx, dy) * 0.002f;
                if (m < best1) {
                    best1 = m;
                    v1x = dx;
                    v1y = dy;
                }
            }
        }
        if (best1 > 0.22f || (v1x == 0 && v1y == 0)) return null;
        // segundo vector: el mejor que no vaya en la misma direccion
        float l1 = (float) Math.hypot(v1x, v1y);
        for (int dy = 0; dy <= maxS; dy++) {
            for (int dx = -maxS; dx <= maxS; dx++) {
                float l = (float) Math.hypot(dx, dy);
                if (l < 1f) continue;
                float cross = Math.abs(v1x * dy - v1y * dx) / (l1 * l);
                if (cross < 0.35f) continue;
                float m = mis[dx + maxS][dy] + l * 0.002f;
                if (m < best2) {
                    best2 = m;
                    v2x = dx;
                    v2y = dy;
                }
            }
        }
        if (best2 > 0.3f) {
            // trama de lineas: el segundo vector va a lo largo de la linea
            v2x = -v1y * 3;
            v2y = v1x * 3;
        }

        float det = v1x * v2y - v1y * v2x;
        if (Math.abs(det) < 0.5f) return null;
        Rect rb = region == null ? null : HoleFill.bounds(region, w, h);
        if (rb == null) return null;
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = rb.top; y < rb.bottom; y++) {
            for (int x = rb.left; x < rb.right; x++) {
                int i = y * w + x;
                if ((region[i] & 0xFF) <= 64) continue;
                // cuantas repeticiones hay que moverse para caer cerca del punto tocado
                float ddx = sx - x, ddy = sy - y;
                float a = (ddx * v2y - ddy * v2x) / det;
                float b = (v1x * ddy - v1y * ddx) / det;
                int ra = Math.round(a), rbb = Math.round(b);
                boolean done = false;
                for (int ka = -1; ka <= 1 && !done; ka++) {
                    for (int kb = -1; kb <= 1 && !done; kb++) {
                        int qx = x + (ra + ka) * v1x + (rbb + kb) * v2x;
                        int qy = y + (ra + ka) * v1y + (rbb + kb) * v2y;
                        if (qx < x0 || qy < y0 || qx >= x1 || qy >= y1) continue;
                        int q = qy * w + qx;
                        if ((region[q] & 0xFF) > 64) continue;
                        px[i] = px[q];
                        done = true;
                    }
                }
                if (!done) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }
}
