package com.pacco.animecut.core;

import android.graphics.Rect;

import java.util.Random;

/**
 * Rellenar copiando de una zona. Es el principio del relleno segun contenido
 * de Photoshop: el hueco se completa con trocitos de la zona que marcas, y
 * cada trocito se elige para que encaje con lo que tiene alrededor.
 *
 * Para buscar rapido los trocitos se usa PatchMatch (Barnes y otros, 2009):
 * cada pixel prueba el trocito de su vecino y unos cuantos al azar, y se
 * queda con el que mejor encaja. Si el hueco es grande se trabaja en una
 * copia reducida para no tardar.
 */
public final class PatchFill {

    private static final int R = 3; // trocitos de 7x7

    private PatchFill() {
    }

    /**
     * @param hole   lo que hay que rellenar
     * @param source zona marcada de donde copiar; null usa un anillo alrededor
     */
    public static Rect fill(int[] px, int w, int h, byte[] hole, byte[] source) {
        Rect hb = HoleFill.bounds(hole, w, h);
        if (hb == null) return null;
        int margin = 48;
        Rect crop = new Rect(Math.max(0, hb.left - margin), Math.max(0, hb.top - margin),
                Math.min(w, hb.right + margin), Math.min(h, hb.bottom + margin));
        if (source != null) {
            Rect sb = HoleFill.bounds(source, w, h);
            if (sb != null) crop.union(sb);
        }
        int holeArea = hb.width() * hb.height();
        int scale = holeArea > 90000 ? 2 : 1;
        if (holeArea > 360000) scale = 3;

        int cw = Math.max(1, crop.width() / scale), ch = Math.max(1, crop.height() / scale);
        int[] img = new int[cw * ch];
        boolean[] isHole = new boolean[cw * ch];
        boolean[] isSrc = new boolean[cw * ch];
        for (int y = 0; y < ch; y++) {
            for (int x = 0; x < cw; x++) {
                int gx = crop.left + x * scale, gy = crop.top + y * scale;
                int i = y * cw + x;
                img[i] = avg(px, w, h, gx, gy, scale);
                boolean hol = false, src = false;
                for (int dy = 0; dy < scale; dy++) {
                    for (int dx = 0; dx < scale; dx++) {
                        int qx = Math.min(w - 1, gx + dx), qy = Math.min(h - 1, gy + dy);
                        int q = qy * w + qx;
                        if ((hole[q] & 0xFF) > 64) hol = true;
                        if (source != null && (source[q] & 0xFF) > 64) src = true;
                    }
                }
                isHole[i] = hol;
                isSrc[i] = source == null ? !hol : (src && !hol);
            }
        }

        // centros validos: el trocito entero cae fuera del hueco y dentro de la zona marcada
        boolean[] valid = new boolean[cw * ch];
        int nValid = 0;
        for (int y = R; y < ch - R; y++) {
            for (int x = R; x < cw - R; x++) {
                boolean ok = true;
                for (int dy = -R; dy <= R && ok; dy++) {
                    for (int dx = -R; dx <= R; dx++) {
                        int q = (y + dy) * cw + (x + dx);
                        if (isHole[q] || !isSrc[q]) {
                            ok = false;
                            break;
                        }
                    }
                }
                if (ok) {
                    valid[y * cw + x] = true;
                    nValid++;
                }
            }
        }
        if (nValid == 0) return null;
        int[] validList = new int[nValid];
        int vi = 0;
        for (int i = 0; i < valid.length; i++) if (valid[i]) validList[vi++] = i;

        // lista de pixeles del hueco
        int nh = 0;
        for (boolean b : isHole) if (b) nh++;
        int[] holeList = new int[nh];
        int hi = 0;
        for (int i = 0; i < isHole.length; i++) if (isHole[i]) holeList[hi++] = i;

        // arranque: cada pixel del hueco toma el color de afuera mas cercano, por capas
        onionInit(img, isHole, cw, ch);

        Random rnd = new Random(12345);
        int[] nnf = new int[cw * ch];
        float[] cost = new float[cw * ch];
        for (int i : holeList) {
            nnf[i] = validList[rnd.nextInt(nValid)];
            cost[i] = dist(img, cw, ch, i, nnf[i], Float.MAX_VALUE);
        }

        int iters = 5;
        long[] ar = new long[cw * ch], ag = new long[cw * ch], ab = new long[cw * ch];
        int[] an = new int[cw * ch];
        for (int it = 0; it < iters; it++) {
            boolean fwd = (it & 1) == 0;
            for (int k = 0; k < nh; k++) {
                int p = holeList[fwd ? k : nh - 1 - k];
                int py = p / cw, pxx = p - py * cw;
                // propagacion desde el vecino ya revisado
                int step = fwd ? -1 : 1;
                int nbx = pxx + step, nby = py + step;
                if (nbx >= 0 && nbx < cw && isHole[py * cw + nbx]) {
                    int cand = nnf[py * cw + nbx] - step;
                    if (cand >= 0 && cand < valid.length && valid[cand]) tryCand(img, cw, ch, p, cand, nnf, cost);
                }
                if (nby >= 0 && nby < ch && isHole[nby * cw + pxx]) {
                    int cand = nnf[nby * cw + pxx] - step * cw;
                    if (cand >= 0 && cand < valid.length && valid[cand]) tryCand(img, cw, ch, p, cand, nnf, cost);
                }
                // busqueda al azar en ventana que se achica
                int by = nnf[p] / cw, bx = nnf[p] - by * cw;
                int rad = Math.max(cw, ch);
                while (rad >= 1) {
                    int cx = bx + rnd.nextInt(2 * rad + 1) - rad;
                    int cy = by + rnd.nextInt(2 * rad + 1) - rad;
                    if (cx >= 0 && cy >= 0 && cx < cw && cy < ch) {
                        int cand = cy * cw + cx;
                        if (valid[cand]) tryCand(img, cw, ch, p, cand, nnf, cost);
                    }
                    rad /= 2;
                }
            }
            // votacion: cada pixel del hueco es el promedio de los trocitos que lo cubren
            java.util.Arrays.fill(an, 0);
            for (int p : holeList) {
                int py = p / cw, pxx = p - py * cw;
                int q = nnf[p];
                int qy = q / cw, qx = q - qy * cw;
                for (int dy = -R; dy <= R; dy++) {
                    int ty = py + dy, sy = qy + dy;
                    if (ty < 0 || ty >= ch) continue;
                    for (int dx = -R; dx <= R; dx++) {
                        int tx = pxx + dx, sxx = qx + dx;
                        if (tx < 0 || tx >= cw) continue;
                        int t = ty * cw + tx;
                        if (!isHole[t]) continue;
                        int c = img[sy * cw + sxx];
                        ar[t] += (c >> 16) & 0xFF;
                        ag[t] += (c >> 8) & 0xFF;
                        ab[t] += c & 0xFF;
                        an[t]++;
                    }
                }
            }
            for (int t : holeList) {
                if (an[t] == 0) continue;
                img[t] = 0xFF000000 | ((int) (ar[t] / an[t]) << 16) | ((int) (ag[t] / an[t]) << 8)
                        | (int) (ab[t] / an[t]);
                ar[t] = ag[t] = ab[t] = 0;
            }
            for (int p : holeList) cost[p] = dist(img, cw, ch, p, nnf[p], Float.MAX_VALUE);
        }

        // devolver a la imagen completa, solo dentro del hueco
        for (int y = crop.top; y < crop.bottom; y++) {
            for (int x = crop.left; x < crop.right; x++) {
                int i = y * w + x;
                if ((hole[i] & 0xFF) <= 64) continue;
                float fx = (x - crop.left) / (float) scale, fy = (y - crop.top) / (float) scale;
                int c = bilinear(img, cw, ch, fx, fy);
                int a = hole[i] & 0xFF;
                px[i] = a >= 250 ? c : LineRepair.blend(px[i], c, a / 255f);
            }
        }
        return crop;
    }

    private static void tryCand(int[] img, int cw, int ch, int p, int cand, int[] nnf, float[] cost) {
        if (cand == nnf[p]) return;
        float d = dist(img, cw, ch, p, cand, cost[p]);
        if (d < cost[p]) {
            cost[p] = d;
            nnf[p] = cand;
        }
    }

    /** Diferencia entre dos trocitos de 7x7. Corta antes si ya es peor. */
    private static float dist(int[] img, int cw, int ch, int p, int q, float limit) {
        int py = p / cw, pxx = p - py * cw;
        int qy = q / cw, qx = q - qy * cw;
        float sum = 0;
        for (int dy = -R; dy <= R; dy++) {
            int ty = py + dy;
            if (ty < 0 || ty >= ch) continue;
            for (int dx = -R; dx <= R; dx++) {
                int tx = pxx + dx;
                if (tx < 0 || tx >= cw) continue;
                int a = img[ty * cw + tx], b = img[(qy + dy) * cw + (qx + dx)];
                int dr = ((a >> 16) & 0xFF) - ((b >> 16) & 0xFF);
                int dg = ((a >> 8) & 0xFF) - ((b >> 8) & 0xFF);
                int db = (a & 0xFF) - (b & 0xFF);
                sum += dr * dr + dg * dg + db * db;
            }
            if (sum > limit) return sum;
        }
        return sum;
    }

    private static void onionInit(int[] img, boolean[] isHole, int cw, int ch) {
        boolean[] known = new boolean[cw * ch];
        int remaining = 0;
        for (int i = 0; i < known.length; i++) {
            known[i] = !isHole[i];
            if (isHole[i]) remaining++;
        }
        int guard = 0;
        while (remaining > 0 && guard++ < 4000) {
            boolean[] next = known.clone();
            int filled = 0;
            for (int y = 0; y < ch; y++) {
                for (int x = 0; x < cw; x++) {
                    int i = y * cw + x;
                    if (known[i]) continue;
                    long r = 0, g = 0, b = 0;
                    int n = 0;
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dx = -1; dx <= 1; dx++) {
                            int qx = x + dx, qy = y + dy;
                            if (qx < 0 || qy < 0 || qx >= cw || qy >= ch) continue;
                            int q = qy * cw + qx;
                            if (!known[q]) continue;
                            int c = img[q];
                            r += (c >> 16) & 0xFF;
                            g += (c >> 8) & 0xFF;
                            b += c & 0xFF;
                            n++;
                        }
                    }
                    if (n == 0) continue;
                    img[i] = 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
                    next[i] = true;
                    filled++;
                }
            }
            known = next;
            remaining -= filled;
            if (filled == 0) break;
        }
    }

    private static int avg(int[] px, int w, int h, int gx, int gy, int s) {
        if (s == 1) return px[gy * w + gx];
        long r = 0, g = 0, b = 0;
        int n = 0;
        for (int dy = 0; dy < s; dy++) {
            for (int dx = 0; dx < s; dx++) {
                int qx = Math.min(w - 1, gx + dx), qy = Math.min(h - 1, gy + dy);
                int c = px[qy * w + qx];
                r += (c >> 16) & 0xFF;
                g += (c >> 8) & 0xFF;
                b += c & 0xFF;
                n++;
            }
        }
        return 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    private static int bilinear(int[] img, int cw, int ch, float fx, float fy) {
        int x0 = Math.max(0, Math.min(cw - 1, (int) fx)), y0 = Math.max(0, Math.min(ch - 1, (int) fy));
        int x1 = Math.min(cw - 1, x0 + 1), y1 = Math.min(ch - 1, y0 + 1);
        float ax = fx - x0, ay = fy - y0;
        if (ax < 0) ax = 0;
        if (ay < 0) ay = 0;
        int a = img[y0 * cw + x0], b = img[y0 * cw + x1], c = img[y1 * cw + x0], d = img[y1 * cw + x1];
        int r = lerp2((a >> 16) & 0xFF, (b >> 16) & 0xFF, (c >> 16) & 0xFF, (d >> 16) & 0xFF, ax, ay);
        int g = lerp2((a >> 8) & 0xFF, (b >> 8) & 0xFF, (c >> 8) & 0xFF, (d >> 8) & 0xFF, ax, ay);
        int bl = lerp2(a & 0xFF, b & 0xFF, c & 0xFF, d & 0xFF, ax, ay);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int lerp2(int a, int b, int c, int d, float x, float y) {
        float top = a + (b - a) * x, bot = c + (d - c) * x;
        return Math.max(0, Math.min(255, Math.round(top + (bot - top) * y)));
    }
}
