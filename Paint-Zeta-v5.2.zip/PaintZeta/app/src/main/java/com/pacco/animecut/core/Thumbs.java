package com.pacco.animecut.core;

import android.graphics.Bitmap;

/** Miniaturas de capa para el panel, con cuadros grises donde hay transparencia. */
public final class Thumbs {

    private Thumbs() {
    }

    public static Bitmap forMask(Project p, byte[] mask, int size) {
        int max = Math.max(p.w, p.h);
        float s = (float) size / max;
        int tw = Math.max(1, Math.round(p.w * s));
        int th = Math.max(1, Math.round(p.h * s));
        Bitmap b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        int[] row = new int[tw];
        for (int y = 0; y < th; y++) {
            int sy = Math.min(p.h - 1, y * p.h / th);
            int base = sy * p.w;
            for (int x = 0; x < tw; x++) {
                int sx = Math.min(p.w - 1, x * p.w / tw);
                int i = base + sx;
                int a = mask == null ? 255 : (mask[i] & 0xFF);
                int checker = (((x >> 2) + (y >> 2)) & 1) == 0 ? 0xFF555555 : 0xFF3A3A3A;
                if (a == 0) {
                    row[x] = checker;
                } else if (a == 255) {
                    row[x] = 0xFF000000 | (p.pixels[i] & 0xFFFFFF);
                } else {
                    row[x] = mix(checker, p.pixels[i], a);
                }
            }
            b.setPixels(row, 0, tw, 0, y, tw, 1);
        }
        return b;
    }

    /** Miniatura de una capa, usando su imagen propia si la tiene. */
    public static Bitmap forLayer(Project p, Layer l, int size) {
        int max = Math.max(p.w, p.h);
        float s = (float) size / max;
        int tw = Math.max(1, Math.round(p.w * s));
        int th = Math.max(1, Math.round(p.h * s));
        Bitmap b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        int[] row = new int[tw];
        for (int y = 0; y < th; y++) {
            int sy = Math.min(p.h - 1, y * p.h / th);
            for (int x = 0; x < tw; x++) {
                int sx = Math.min(p.w - 1, x * p.w / tw);
                int i = sy * p.w + sx;
                int a = l.mask[i] & 0xFF;
                int checker = (((x >> 2) + (y >> 2)) & 1) == 0 ? 0xFF555555 : 0xFF3A3A3A;
                row[x] = a == 0 ? checker : mix(checker, l.colorAt(p.pixels, i, sx, sy), a);
            }
            b.setPixels(row, 0, tw, 0, y, tw, 1);
        }
        return b;
    }

    private static int mix(int bg, int fg, int a) {
        int r = (((fg >> 16) & 0xFF) * a + ((bg >> 16) & 0xFF) * (255 - a)) / 255;
        int g = (((fg >> 8) & 0xFF) * a + ((bg >> 8) & 0xFF) * (255 - a)) / 255;
        int b = ((fg & 0xFF) * a + (bg & 0xFF) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
