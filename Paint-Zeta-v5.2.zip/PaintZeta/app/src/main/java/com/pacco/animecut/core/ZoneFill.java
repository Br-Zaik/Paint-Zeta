package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Rellenar por zona con color plano. Tocas dentro del hueco y la zona se
 * rellena, hasta las lineas, con el color que tiene esa zona justo afuera
 * del hueco. No mezcla colores: queda plano, como el dibujo.
 */
public final class ZoneFill {

    private ZoneFill() {
    }

    /**
     * @param hole  lo que hay que reconstruir
     * @param lines lineas nuevas dibujadas dentro del hueco (hacen de pared)
     */
    public static Rect fill(int[] px, int w, int h, byte[] hole, byte[] lines, int sx, int sy) {
        if (sx < 0 || sy < 0 || sx >= w || sy >= h) return null;
        int start = sy * w + sx;
        if ((hole[start] & 0xFF) <= 64) return null;
        if (lines != null && lines[start] != 0) return null;

        boolean[] in = new boolean[w * h];
        int[] st = new int[4096];
        int sp = 0;
        st[sp++] = start;
        in[start] = true;
        int minX = sx, maxX = sx, minY = sy, maxY = sy;
        int count = 0;
        // bordes de la zona que tocan la imagen de afuera: de ahi sale el color
        int[] hist = new int[4096];
        long[] sumR = new long[4096], sumG = new long[4096], sumB = new long[4096];

        while (sp > 0) {
            int i = st[--sp];
            count++;
            int y = i / w, x = i - y * w;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            int[] nb = {x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1};
            for (int q : nb) {
                if (q < 0 || in[q]) continue;
                if ((hole[q] & 0xFF) > 64) {
                    if (lines != null && lines[q] != 0) continue;
                    in[q] = true;
                    if (sp == st.length) {
                        int[] b = new int[st.length * 2];
                        System.arraycopy(st, 0, b, 0, st.length);
                        st = b;
                    }
                    st[sp++] = q;
                } else {
                    // pixel de afuera: si no es linea, vota por su color
                    int c = px[q];
                    if (LineRepair.lum(c) < LineRepair.DARK) continue;
                    int key = (((c >> 20) & 0xF) << 8) | (((c >> 12) & 0xF) << 4) | ((c >> 4) & 0xF);
                    hist[key]++;
                    sumR[key] += (c >> 16) & 0xFF;
                    sumG[key] += (c >> 8) & 0xFF;
                    sumB[key] += c & 0xFF;
                }
            }
        }
        int best = -1;
        for (int k = 0; k < hist.length; k++) {
            if (hist[k] > 0 && (best < 0 || hist[k] > hist[best])) best = k;
        }
        if (best < 0) return null;
        int n = hist[best];
        int color = 0xFF000000 | ((int) (sumR[best] / n) << 16) | ((int) (sumG[best] / n) << 8)
                | (int) (sumB[best] / n);

        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                int i = y * w + x;
                if (in[i]) px[i] = color;
            }
        }
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }
}
