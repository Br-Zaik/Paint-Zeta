package com.pacco.animecut.core;

import android.graphics.Rect;

import java.util.ArrayList;
import java.util.List;

/**
 * Continuar las lineas que quedaron cortadas por una parte.
 *
 * Busca la punta de la linea mas cercana a donde empieza y termina tu trazo,
 * mira hacia donde iba esa linea, y dibuja una curva suave que sale y llega
 * en esa misma direccion, con el grosor y el color de la linea original.
 */
public final class LineRepair {

    public static final int DARK = 110;

    private LineRepair() {
    }

    /** Punta de una linea: posicion, direccion hacia el hueco, grosor y color. */
    public static final class End {
        public float x, y, tx, ty, width;
        public int color;
        public boolean snapped;
    }

    public static int lum(int c) {
        return (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
    }

    /**
     * Busca la linea oscura mas cercana a (x, y) fuera del hueco.
     * @param dirX direccion aproximada del trazo, para orientar la tangente
     */
    public static End snap(int[] px, int w, int h, byte[] hole, float x, float y,
                           float dirX, float dirY, int radius) {
        End e = new End();
        e.x = x;
        e.y = y;
        float dl = (float) Math.hypot(dirX, dirY);
        e.tx = dl > 0 ? dirX / dl : 1f;
        e.ty = dl > 0 ? dirY / dl : 0f;
        e.width = 2.5f;
        e.color = 0xFF1C1C1C;

        int best = -1;
        float bestD = Float.MAX_VALUE;
        int cx = (int) x, cy = (int) y;
        for (int yy = Math.max(0, cy - radius); yy < Math.min(h, cy + radius + 1); yy++) {
            for (int xx = Math.max(0, cx - radius); xx < Math.min(w, cx + radius + 1); xx++) {
                int i = yy * w + xx;
                if (hole != null && (hole[i] & 0xFF) > 64) continue;
                if (lum(px[i]) >= DARK) continue;
                float d = (xx - x) * (xx - x) + (yy - y) * (yy - y);
                if (d < bestD) {
                    bestD = d;
                    best = i;
                }
            }
        }
        if (best < 0) return e;

        int bx = best % w, by = best / w;
        // direccion de la linea: eje principal de los pixeles oscuros cercanos
        double sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0, n = 0;
        long cr = 0, cg = 0, cb = 0, cn = 0;
        int r = 10;
        for (int yy = Math.max(0, by - r); yy < Math.min(h, by + r + 1); yy++) {
            for (int xx = Math.max(0, bx - r); xx < Math.min(w, bx + r + 1); xx++) {
                int i = yy * w + xx;
                if (hole != null && (hole[i] & 0xFF) > 64) continue;
                if (lum(px[i]) >= DARK) continue;
                sx += xx;
                sy += yy;
                sxx += xx * xx;
                syy += yy * yy;
                sxy += xx * yy;
                n++;
                if (Math.abs(xx - bx) <= 2 && Math.abs(yy - by) <= 2) {
                    int c = px[i];
                    cr += (c >> 16) & 0xFF;
                    cg += (c >> 8) & 0xFF;
                    cb += c & 0xFF;
                    cn++;
                }
            }
        }
        if (n >= 3) {
            double mx = sx / n, my = sy / n;
            double a = sxx / n - mx * mx, b = sxy / n - mx * my, c = syy / n - my * my;
            double ang = 0.5 * Math.atan2(2 * b, a - c);
            float tx = (float) Math.cos(ang), ty = (float) Math.sin(ang);
            // que apunte hacia donde va el trazo
            if (tx * e.tx + ty * e.ty < 0) {
                tx = -tx;
                ty = -ty;
            }
            e.tx = tx;
            e.ty = ty;
            // grosor: cuantos pixeles oscuros cruza la perpendicular
            float nx = -ty, ny = tx;
            int wcount = 0;
            for (int k = -8; k <= 8; k++) {
                int qx = Math.round(bx + nx * k), qy = Math.round(by + ny * k);
                if (qx < 0 || qy < 0 || qx >= w || qy >= h) continue;
                if (lum(px[qy * w + qx]) < DARK) wcount++;
            }
            e.width = Math.max(1f, Math.min(14f, wcount));
        }
        if (cn > 0) {
            e.color = 0xFF000000 | ((int) (cr / cn) << 16) | ((int) (cg / cn) << 8) | (int) (cb / cn);
        }
        e.x = bx;
        e.y = by;
        e.snapped = true;
        return e;
    }

    /**
     * Dibuja la curva entre dos puntas. Si las dos se engancharon a una
     * linea, sale y llega con la direccion de esa linea.
     * @param lines se marca 255 donde queda la linea nueva (sirve de pared)
     * @return rectangulo tocado
     */
    public static Rect drawCurve(int[] px, int w, int h, byte[] lines, End a, End b,
                                 float[] strokeXY) {
        List<float[]> pts = new ArrayList<float[]>();
        float width = (a.width + b.width) / 2f;
        int color = mixColor(a.color, b.color);

        if (a.snapped && b.snapped || strokeXY == null || strokeXY.length < 8) {
            float dx = b.x - a.x, dy = b.y - a.y;
            float len = (float) Math.hypot(dx, dy);
            float k = len / 3f;
            float p1x = a.x + a.tx * k, p1y = a.y + a.ty * k;
            // b.t apunta en el sentido del recorrido: se llega desde atras
            float p2x = b.x - b.tx * k, p2y = b.y - b.ty * k;
            int steps = Math.max(8, (int) (len * 2));
            for (int s = 0; s <= steps; s++) {
                float t = s / (float) steps, u = 1 - t;
                float x = u * u * u * a.x + 3 * u * u * t * p1x + 3 * u * t * t * p2x + t * t * t * b.x;
                float y = u * u * u * a.y + 3 * u * u * t * p1y + 3 * u * t * t * p2y + t * t * t * b.y;
                pts.add(new float[]{x, y});
            }
        } else {
            // sin enganche: se suaviza el trazo del dedo
            int n = strokeXY.length / 2;
            float[] xs = new float[n], ys = new float[n];
            for (int i = 0; i < n; i++) {
                xs[i] = strokeXY[i * 2];
                ys[i] = strokeXY[i * 2 + 1];
            }
            if (a.snapped) {
                xs[0] = a.x;
                ys[0] = a.y;
            }
            if (b.snapped) {
                xs[n - 1] = b.x;
                ys[n - 1] = b.y;
            }
            for (int pass = 0; pass < 4; pass++) {
                for (int i = 1; i < n - 1; i++) {
                    xs[i] = (xs[i - 1] + 2 * xs[i] + xs[i + 1]) / 4f;
                    ys[i] = (ys[i - 1] + 2 * ys[i] + ys[i + 1]) / 4f;
                }
            }
            for (int i = 0; i < n - 1; i++) {
                float dx = xs[i + 1] - xs[i], dy = ys[i + 1] - ys[i];
                int steps = Math.max(1, (int) (Math.hypot(dx, dy) * 2));
                for (int s = 0; s < steps; s++) {
                    float t = s / (float) steps;
                    pts.add(new float[]{xs[i] + dx * t, ys[i] + dy * t});
                }
            }
            pts.add(new float[]{xs[n - 1], ys[n - 1]});
        }
        return raster(px, w, h, lines, pts, width, color);
    }

    private static Rect raster(int[] px, int w, int h, byte[] lines, List<float[]> pts,
                               float width, int color) {
        float r = Math.max(0.6f, width / 2f);
        int minX = w, minY = h, maxX = -1, maxY = -1;
        // cobertura maxima por pixel, para no oscurecer de mas donde se solapan
        java.util.HashMap<Integer, Float> cov = new java.util.HashMap<Integer, Float>();
        for (float[] p : pts) {
            int x0 = (int) Math.floor(p[0] - r - 1), x1 = (int) Math.ceil(p[0] + r + 1);
            int y0 = (int) Math.floor(p[1] - r - 1), y1 = (int) Math.ceil(p[1] + r + 1);
            for (int y = Math.max(0, y0); y <= Math.min(h - 1, y1); y++) {
                for (int x = Math.max(0, x0); x <= Math.min(w - 1, x1); x++) {
                    float d = (float) Math.hypot(x + 0.5f - p[0], y + 0.5f - p[1]);
                    float a = r + 0.5f - d;
                    if (a <= 0f) continue;
                    if (a > 1f) a = 1f;
                    int i = y * w + x;
                    Float old = cov.get(i);
                    if (old == null || a > old) cov.put(i, a);
                }
            }
        }
        for (java.util.Map.Entry<Integer, Float> en : cov.entrySet()) {
            int i = en.getKey();
            float a = en.getValue();
            int x = i % w, y = i / w;
            px[i] = blend(px[i], color, a);
            if (lines != null && a > 0.45f) lines[i] = (byte) 255;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /**
     * Une solas las puntas que quedaron cortadas en el borde del hueco,
     * cuando dos puntas se miran de frente.
     */
    public static Rect autoJoin(int[] px, int w, int h, byte[] hole, byte[] lines) {
        Rect hb = HoleFill.bounds(hole, w, h);
        if (hb == null) return null;
        int m = 6;
        Rect area = new Rect(Math.max(0, hb.left - m), Math.max(0, hb.top - m),
                Math.min(w, hb.right + m), Math.min(h, hb.bottom + m));
        int aw = area.width(), ah = area.height();
        // anillo pegado al hueco, por fuera
        boolean[] ring = new boolean[aw * ah];
        for (int y = 0; y < ah; y++) {
            for (int x = 0; x < aw; x++) {
                int gx = area.left + x, gy = area.top + y;
                int i = gy * w + gx;
                if ((hole[i] & 0xFF) > 64) continue;
                if (lum(px[i]) >= DARK) continue;
                boolean near = false;
                for (int dy = -3; dy <= 3 && !near; dy++) {
                    for (int dx = -3; dx <= 3; dx++) {
                        int qx = gx + dx, qy = gy + dy;
                        if (qx < 0 || qy < 0 || qx >= w || qy >= h) continue;
                        if ((hole[qy * w + qx] & 0xFF) > 64) {
                            near = true;
                            break;
                        }
                    }
                }
                ring[y * aw + x] = near;
            }
        }
        // cada grupo de pixeles oscuros del anillo es una linea que entra al hueco
        List<End> ends = new ArrayList<End>();
        boolean[] seen = new boolean[aw * ah];
        float hcx = hb.exactCenterX(), hcy = hb.exactCenterY();
        int[] st = new int[aw * ah];
        for (int k = 0; k < ring.length; k++) {
            if (!ring[k] || seen[k]) continue;
            int sp = 0, cnt = 0;
            float sx = 0, sy = 0;
            st[sp++] = k;
            seen[k] = true;
            while (sp > 0) {
                int q = st[--sp];
                int qy = q / aw, qx = q - qy * aw;
                sx += qx;
                sy += qy;
                cnt++;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = qx + dx, ny = qy + dy;
                        if (nx < 0 || ny < 0 || nx >= aw || ny >= ah) continue;
                        int nq = ny * aw + nx;
                        if (!ring[nq] || seen[nq]) continue;
                        seen[nq] = true;
                        st[sp++] = nq;
                    }
                }
            }
            if (cnt < 2 || cnt > 400) continue;
            float ex = area.left + sx / cnt, ey = area.top + sy / cnt;
            End e = snap(px, w, h, hole, ex, ey, hcx - ex, hcy - ey, 3);
            if (!e.snapped) continue;
            ends.add(e);
        }
        // emparejar las que se miran de frente
        boolean[] used = new boolean[ends.size()];
        Rect total = null;
        while (true) {
            int bi = -1, bj = -1;
            float bestScore = Float.MAX_VALUE;
            for (int i = 0; i < ends.size(); i++) {
                if (used[i]) continue;
                for (int j = i + 1; j < ends.size(); j++) {
                    if (used[j]) continue;
                    End a = ends.get(i), b = ends.get(j);
                    float dx = b.x - a.x, dy = b.y - a.y;
                    float len = (float) Math.hypot(dx, dy);
                    if (len < 4f) continue;
                    float ux = dx / len, uy = dy / len;
                    float ca = a.tx * ux + a.ty * uy;
                    float cb = -(b.tx * ux + b.ty * uy);
                    if (ca < 0.35f || cb < 0.35f) continue;
                    // el tramo tiene que ir casi todo por dentro del hueco
                    int in = 0, tot = 0;
                    for (int s = 1; s < 20; s++) {
                        int qx = (int) (a.x + dx * s / 20f), qy = (int) (a.y + dy * s / 20f);
                        if (qx < 0 || qy < 0 || qx >= w || qy >= h) continue;
                        tot++;
                        if ((hole[qy * w + qx] & 0xFF) > 64) in++;
                    }
                    if (tot == 0 || in < tot * 0.6f) continue;
                    float score = len * (3f - ca - cb) + Math.abs(a.width - b.width) * 4f;
                    if (score < bestScore) {
                        bestScore = score;
                        bi = i;
                        bj = j;
                    }
                }
            }
            if (bi < 0) break;
            used[bi] = used[bj] = true;
            End a = ends.get(bi), b = ends.get(bj);
            // la punta de llegada se da vuelta para que la curva entre derecho
            End bb = new End();
            bb.x = b.x;
            bb.y = b.y;
            // su tangente mira hacia el hueco; el recorrido llega al reves
            bb.tx = -b.tx;
            bb.ty = -b.ty;
            bb.width = b.width;
            bb.color = b.color;
            bb.snapped = true;
            Rect r = drawCurve(px, w, h, lines, a, bb, null);
            if (r != null) {
                if (total == null) total = new Rect(r);
                else total.union(r);
            }
        }
        return total;
    }

    private static int mixColor(int a, int b) {
        int r = (((a >> 16) & 0xFF) + ((b >> 16) & 0xFF)) / 2;
        int g = (((a >> 8) & 0xFF) + ((b >> 8) & 0xFF)) / 2;
        int bl = ((a & 0xFF) + (b & 0xFF)) / 2;
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    static int blend(int dst, int src, float a) {
        int ia = (int) (a * 256f);
        if (ia <= 0) return dst;
        if (ia > 256) ia = 256;
        int r = (((src >> 16) & 0xFF) * ia + ((dst >> 16) & 0xFF) * (256 - ia)) >> 8;
        int g = (((src >> 8) & 0xFF) * ia + ((dst >> 8) & 0xFF) * (256 - ia)) >> 8;
        int b = ((src & 0xFF) * ia + (dst & 0xFF) * (256 - ia)) >> 8;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
