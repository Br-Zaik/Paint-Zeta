# Sin reglas especiales: el proyecto no usa reflexion.
