# Paint Zeta v8.32 — Borrar fondo con motor nuevo (Balde, Pincel protegido, Borrador, Restaurar, Escoba)

## Que se arreglo (tus 4 capturas)

1. **Papel junto al borde de la imagen que no se podia borrar.** Ahora los mapas siguen "afuera" del lienzo copiando el borde. El borde ya no cuenta como pared. Con el pincel junto al borde, v8.31 dejaba 218 de 220 px de una tira de 1 px, 438 de 440 de una de 2 px y 1093 de 1100 de una de 5 px. v8.32 deja 0. Tambien borra si el dedo va por fuera del lienzo y solo el circulo toca la tira.
2. **Se pasaba al otro lado de la linea negra (manga y color).** El Balde y el Pincel usan ahora el mismo analisis:
   - Las lineas son paredes.
   - La distancia a la pared se mide exacta.
   - Solo se avanza por donde cabe una "pelota" de radio R. Un corte de la linea mas chico que 2R no se cruza.
   - R sale del grosor real de las lineas de esa imagen.
   - Cruzando la linea 6 veces a proposito con el pincel, v8.31 borraba 2818 px del personaje y v8.32 borra 0.
3. **Borde negro dentado y distinto segun la resolucion.**
   - El alfa del borde sale de desmezclar cada pixel entre el color de la linea y el del fondo, asi se usa el antialias del propio dibujo.
   - El color del borde se descontamina (se le quita el tinte del fondo), asi no queda un filo blanco o gris.
   - El mismo dibujo en PNG, en JPEG malo, a 0,5x y a 2x da la misma mascara en 99,4 a 99,9 %. v8.31 daba 98,6 a 99,6 %.
4. **Ayuda con mucho texto y dibujo muy simple.**
   - Personaje nuevo propio, estilo anime: pelo en punta con brillo, ojos grandes, chaqueta. Tambien hay un fondo de manhwa.
   - Borrar fondo tiene una animacion de 5 escenas sin texto: Balde, Pincel, Borrador, Restaurar y Escoba. Cada escena lleva su icono.
   - El texto de la ayuda quedo en 3 lineas cortas.

## Barra de Borrar fondo (un toque, solo iconos)

- **Balde:** toca el fondo. Si tocas un rincon angosto (entre mechones), borra solo ese rincon.
- **Pincel protegido:** pasa junto a la linea; no la cruza. Si el dedo pasa por encima del personaje y vuelve al mismo fondo, sigue borrando.
- **Borrador** (nuevo en la barra): borra justo donde pasas, tambien restos que el pincel protegido no toca. La barra de abajo es su FUERZA; la dureza esta en ajustes avanzados. No cambia la Goma normal.
- **Restaurar**, **Escoba**, **Ojo**: igual que antes.

## Ajustes avanzados (Menu > Borrar fondo: ajustes avanzados)

- **Nuevo «Cerrar huecos de la linea»** (0,5x a 3x, normal 1x): para cortes de linea mas grandes.
- **Nuevo «Dureza del borrador»** y boton **«De fabrica»**.
- **Se quitaron** «Borde suave», «Disperso» y «Dilatacion»: el motor nuevo no los usa y solo confundian.

## Archivos cambiados

- **Nuevo** `app/.../core/BgEngine.java`: motor unico, en Java puro. Contiene:
  - medicion del grosor de linea (Otsu + crestas de la distancia; global y por zonas de 128 px);
  - distancia exacta (Felzenszwalb-Huttenlocher);
  - nucleo de pelota;
  - crecimiento hacia las puntas que no vuelve a ensancharse (con el ancho local M);
  - banda desmezclada que entra en la linea solo lo que mide su antialias;
  - motas y grietas encerradas;
  - trama como fondo (si tocas una trama, cuenta el gris promedio y frenan las lineas);
  - borde del lienzo en copia;
  - corte de ventana "no confiable".
- **Nuevo** `app/.../core/BgStroke.java`: un trazo del pincel protegido.
  - Lo aceptado se guarda con su ancho minimo, asi repasar no va abriendo un hueco.
  - Una region global del mismo fondo se calcula en otro hilo.
  - El color sigue al fondo de a poco: media tolerancia por estampa, el color del comienzo siempre vale y el tono no se va hacia el del personaje.
- **Nuevo** `app/.../core/ChibiArt.java`: dibujo original para la ayuda.
- `view/CanvasView.java`:
  - Balde y Pincel van al motor nuevo.
  - Borrador manual con dureza y fuerza.
  - La copia para Restaurar incorpora lo pintado despues.
  - Mapas liberados al salir de la herramienta; medicion de nuevo al deshacer o rehacer, en otro hilo.
  - Se borraron las rutas viejas del pincel y del balde (barrera de 64 px, cierres de 1/7/10 px, BG_NEAR, rincones de 300 px) para que no queden dos caminos distintos.
- `core/BgCleanup.java` (Escoba): sin mapa int[] (1 byte por pixel en vez de 4); tamaños segun el grosor de linea; solo rellena pinchazos, no rincones borrados a proposito.
- `MainActivity.java`: barra con el Borrador, segunda barra de abajo segun la sub-herramienta, ajustes nuevos, textos cortos.
- `view/ToolArt.java` y `view/ToolDemoView.java`: dibujos y animacion nuevos.
- `app/build.gradle`: version 8.32 (70).

## Pruebas (T1 a T12 y 7A): todas pasaron — detalle en `docs/RESULTADOS_PRUEBAS_8_32.txt`

- Corren en la JVM del PC sobre el MISMO codigo core de la app.
- «v8.31» es su codigo copiado (Balde y Pincel) con los mismos toques y trazos.
- Imagenes reales usadas: el manga de Ayanokouji (PNG y JPEG 1024x1536) y el duende de la cueva (JPEG 1052x1536). Lo demas son escenas sinteticas con verdad exacta.
- Resultados:
  - T1, linea cerrada de 1 a 8 px: personaje perdido 0 en todos; v8.31 perdia 242, 572 y 200 px con lineas de 1, 1,5 y 2 px.
  - T2, huecos de 1 a 15 px a 1x, 2x y 3x: dentro de la capacidad, 0 fugas en 18 de 18; v8.31 fugaba en 5. La capacidad crece con el grosor de linea (de 5 px con lineas finas a 19 px con lineas de 9 px). Para mas, usar «Cerrar huecos».
  - T3, pelo con puntas abiertas: pelo perdido 0, brillos del pelo intactos. Un rincon cerrado no se borra desde afuera; tocandolo, se borra solo el.
  - T4, trama: tocar el papel no toca la trama del personaje. Tocar una trama de fondo la borra entera (15 % a 38 %) sin tocar la linea; v8.31 se comia hasta 826 px de linea.
  - T5, duende: 5 toques en la cueva, piel perdida 348 px en v8.31 y 5 px en v8.32. Pincel por oreja, cabeza, brazo, barriga y taparrabo: 1 px en v8.31 y 1 px en v8.32.
  - T6, borde del lienzo: tiras de 1 a 15 px en los 4 lados borradas; una linea que llega al borde no se rodea.
  - T7: misma mascara en PNG, JPEG, 0,5x y 2x; borde de 0,6 a 1,8 px; sin dientes.
  - T8, pincel lento, rapido, repetido 30 veces y cruzando la linea: personaje perdido 0 en los 4 (v8.31: 276, 139, 425 y 2818 px).
  - T9, Escoba: motas 127 a 0 y halo 375 a 0; trama, punta fina y borde suave intactos.
  - T10: PNG exportado igual a lo que se ve, con transparencia real; mismo resultado al repetir; la seleccion se respeta.
  - T11, 12 MP: toque 1,9 s y estampa del pincel 4 ms como maximo en este PC; anduvo con la memoria limitada a 256 MB.
  - T12, color dificil sin linea: la cara no se borra.
  - 7A: tira de 1 px con el borrador; punto pegado a la linea; 50 cambios entre herramientas y Restaurar todo deja la imagen igual al original.

## Limites (verdad)

- **No se probo en un telefono.** Los tiempos son de este PC; en un telefono cuenta con 3 a 6 veces mas. Tampoco se probaron el historial de la app, guardar o abrir el proyecto, el zoom ni los gestos de dos dedos. El codigo de la app SI compila completo (641 clases) contra un android.jar real (API 33).
- **Lo que es del MISMO color que el fondo y no tiene linea no se puede separar solo.** Para eso estan Restaurar, el Lazo o la Seleccion y «Proteger el color elegido».
- **Cortes mas grandes que la capacidad pasan.** Es lo correcto para un dibujo abierto; para cerrarlos, «Cerrar huecos».
- **El pincel no salta solo a otra zona de color muy distinto** (del gris al marron del piso del duende). Hay que empezar el trazo sobre esa zona o tocarla con el Balde.
- **Con una trama muy densa,** puntos que casi se tocan, se detecta como trama solo si al tocarla se ven puntos separados.
- **No se modifico GitHub ni Actions.** Subes el ZIP como siempre.
