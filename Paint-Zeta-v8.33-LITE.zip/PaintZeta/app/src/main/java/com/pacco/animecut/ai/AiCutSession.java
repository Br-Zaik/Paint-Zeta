package com.pacco.animecut.ai;

import java.util.ArrayList;

/**
 * v8.33: una sesion de "Recortar con IA" sobre una COPIA de lectura de la capa. Nada se escribe
 * en la capa hasta Aplicar.
 *
 * Tres mascaras separadas:
 *  - ia:     resultado de la IA + post-proceso (se puede recalcular con otros ajustes SIN volver
 *            a correr la IA, porque se guarda la salida cruda del modelo);
 *  - add:    "Anadir personaje" (pincel o zona);
 *  - rem:    "Quitar fondo" (pincel, zona o "Solo este").
 * Alfa final = clamp(max(ia, add) - rem) x alfa original. Los retoques sobreviven a cambiar los
 * ajustes. Deshacer / Rehacer por trazo (copias por bloques de 64 px, poca memoria).
 * Java puro: lo usan la app y las pruebas.
 */
public final class AiCutSession {
    public final int[] px;
    public final int W, H;
    public final AiPrep prep;
    /** Salida cruda del modelo recortada (prep.w * prep.h, 0..255). */
    public final byte[] raw;
    public AiMatte.Params params;
    public AiMatte.Result res;
    private byte[] add, rem;
    public final boolean mono;

    public AiCutSession(int[] px, int W, int H, AiPrep prep, byte[] raw, AiMatte.Params p) {
        this.px = px; this.W = W; this.H = H; this.prep = prep; this.raw = raw;
        mono = AiPrep.meanSaturation(px, W, prep.cropX, prep.cropY, prep.cropW, prep.cropH) < 12;
        params = p != null ? p : defaults(mono);
        res = AiMatte.process(prep, raw, px, W, H, params);
    }

    /** Ajustes de fabrica: en blanco y negro / trama no se usa el filtro guiado ni la linea
     *  (siguen la textura de la trama); la forma la dan la IA y la limpieza. */
    public static AiMatte.Params defaults(boolean mono) {
        AiMatte.Params p = new AiMatte.Params();
        if (mono) { p.guided = false; p.lines = false; }
        return p;
    }

    /** Recalcula el post-proceso con otros ajustes (sin IA). Los retoques se conservan. */
    public void reprocess(AiMatte.Params p) {
        params = p.copy();
        res = AiMatte.process(prep, raw, px, W, H, params);
    }

    // ------------------------------------------------------------------ resultado
    public int alphaAt(int i) {
        int a = res.alpha[i] & 0xFF;
        if (add != null) { int ad = add[i] & 0xFF; if (ad > a) a = ad; }
        if (rem != null) { a -= rem[i] & 0xFF; if (a < 0) a = 0; }
        int oa = px[i] >>> 24;
        return oa >= 255 ? a : a * oa / 255;
    }

    /** Color final (RGB) del pixel: corregido en el borde de la IA; original si lo anadio el usuario. */
    public int rgbAt(int i) {
        int ai = res.alpha[i] & 0xFF;
        if (add != null && (add[i] & 0xFF) > ai) return px[i] & 0xFFFFFF;
        // solo el borde suave tiene color corregido (busqueda solo ahi: la vista es rapida)
        if (ai == 0 || ai >= 250) return px[i] & 0xFFFFFF;
        return res.colorAt(i, px[i]) & 0xFFFFFF;
    }

    public int argbAt(int i) { return (alphaAt(i) << 24) | rgbAt(i); }

    /** Escribe el resultado completo (W*H ARGB). El RGB de lo transparente se conserva. */
    public void exportTo(int[] dst) {
        for (int i = 0; i < W * H; i++) {
            int a = alphaAt(i);
            dst[i] = (a << 24) | (a == 0 ? (px[i] & 0xFFFFFF) : rgbAt(i));
        }
    }

    /** true si hay algo del personaje (para avisar si la IA no encontro nada). */
    public boolean anyVisible() {
        for (int i = 0; i < W * H; i++) if (alphaAt(i) > 0) return true;
        return false;
    }

    // ------------------------------------------------------------------ deshacer
    private static final int T = 64;
    private final int cols() { return (W + T - 1) / T; }

    private static final class Edit {
        final java.util.HashMap<Integer, byte[][]> tiles = new java.util.HashMap<>();
        String label;
    }

    private final ArrayList<Edit> undo = new ArrayList<>(), redo = new ArrayList<>();
    private Edit open;
    public static final int MAX_UNDO = 40;

    public void beginEdit() {
        if (open != null) endEdit(null);
        open = new Edit();
    }

    public void endEdit(String label) {
        if (open == null) return;
        if (!open.tiles.isEmpty()) {
            open.label = label;
            undo.add(open);
            if (undo.size() > MAX_UNDO) undo.remove(0);
            redo.clear();
        }
        open = null;
    }

    /** Cancela el trazo abierto (llego un segundo dedo): vuelve a como estaba. */
    public void cancelEdit() {
        if (open == null) return;
        swap(open);
        open = null;
    }

    public boolean canUndo() { return !undo.isEmpty() && open == null; }
    public boolean canRedo() { return !redo.isEmpty() && open == null; }

    public String undo() {
        if (!canUndo()) return null;
        Edit e = undo.remove(undo.size() - 1);
        swap(e);
        redo.add(e);
        return e.label;
    }

    public String redo() {
        if (!canRedo()) return null;
        Edit e = redo.remove(redo.size() - 1);
        swap(e);
        undo.add(e);
        return e.label;
    }

    /** Intercambia los bloques guardados con los actuales (sirve para deshacer y rehacer). */
    private void swap(Edit e) {
        ensure();
        int cols = cols();
        for (java.util.Map.Entry<Integer, byte[][]> en : e.tiles.entrySet()) {
            int key = en.getKey();
            int tx = key % cols, ty = key / cols;
            int x0 = tx * T, y0 = ty * T, tw = Math.min(T, W - x0), th = Math.min(T, H - y0);
            byte[][] b = en.getValue();
            for (int y = 0; y < th; y++) {
                int o = (y0 + y) * W + x0;
                for (int x = 0; x < tw; x++) {
                    byte t1 = add[o + x]; add[o + x] = b[0][y * tw + x]; b[0][y * tw + x] = t1;
                    byte t2 = rem[o + x]; rem[o + x] = b[1][y * tw + x]; b[1][y * tw + x] = t2;
                }
            }
        }
        dirty(0, 0, W, H);
    }

    private void ensure() {
        if (add == null) add = new byte[W * H];
        if (rem == null) rem = new byte[W * H];
    }

    private void backup(int x0, int y0, int x1, int y1) {
        ensure();
        if (open == null) return;
        int cols = cols();
        for (int ty = Math.max(0, y0) / T; ty <= Math.min(H - 1, y1 - 1) / T; ty++)
            for (int tx = Math.max(0, x0) / T; tx <= Math.min(W - 1, x1 - 1) / T; tx++) {
                int key = ty * cols + tx;
                if (open.tiles.containsKey(key)) continue;
                int bx = tx * T, by = ty * T, tw = Math.min(T, W - bx), th = Math.min(T, H - by);
                byte[] a = new byte[tw * th], r = new byte[tw * th];
                for (int y = 0; y < th; y++) {
                    System.arraycopy(add, (by + y) * W + bx, a, y * tw, tw);
                    System.arraycopy(rem, (by + y) * W + bx, r, y * tw, tw);
                }
                open.tiles.put(key, new byte[][]{a, r});
            }
    }

    // ------------------------------------------------------------------ zona cambiada
    public int dx0, dy0, dx1, dy1;
    private boolean anyDirty;

    private void dirty(int x0, int y0, int x1, int y1) {
        if (!anyDirty) { dx0 = x0; dy0 = y0; dx1 = x1; dy1 = y1; anyDirty = true; }
        else { dx0 = Math.min(dx0, x0); dy0 = Math.min(dy0, y0); dx1 = Math.max(dx1, x1); dy1 = Math.max(dy1, y1); }
    }

    /** Zona cambiada desde la ultima llamada (x0,y0,x1,y1) o null. */
    public int[] takeDirty() {
        if (!anyDirty) return null;
        anyDirty = false;
        return new int[]{Math.max(0, dx0), Math.max(0, dy0), Math.min(W, dx1), Math.min(H, dy1)};
    }

    // ------------------------------------------------------------------ pincel
    /**
     * Una estampa del pincel Anadir (addMode) o Quitar. hard 0..1. Sin raiz por pixel: el
     * interior duro se recorre por tramos (una raiz por fila) y solo el anillo del borde calcula
     * su caida.
     */
    public void stamp(float cx, float cy, float r, float hard, boolean addMode) {
        if (r < 0.5f) r = 0.5f;
        int x0 = Math.max(0, (int) Math.floor(cx - r - 1)), x1 = Math.min(W, (int) Math.ceil(cx + r + 2));
        int y0 = Math.max(0, (int) Math.floor(cy - r - 1)), y1 = Math.min(H, (int) Math.ceil(cy + r + 2));
        if (x0 >= x1 || y0 >= y1) return;
        backup(x0, y0, x1, y1);
        float inner = r * Math.max(0f, Math.min(1f, hard));
        float outer = r + 0.5f;
        byte[] on = addMode ? add : rem, off = addMode ? rem : add;
        for (int y = y0; y < y1; y++) {
            float dy = y + 0.5f - cy;
            float dy2 = dy * dy;
            if (dy2 > outer * outer) continue;
            float wo = (float) Math.sqrt(outer * outer - dy2);
            float wi = inner * inner > dy2 ? (float) Math.sqrt(inner * inner - dy2) : -1f;
            int xa = Math.max(x0, (int) Math.floor(cx - wo - 0.5f)), xb = Math.min(x1, (int) Math.ceil(cx + wo + 0.5f));
            int row = y * W;
            for (int x = xa; x < xb; x++) {
                float dx = x + 0.5f - cx;
                int f;
                if (wi >= 0f && Math.abs(dx) <= wi - 0.5f) f = 255;   // interior: sin raiz
                else {
                    float d = (float) Math.sqrt(dx * dx + dy2);
                    float v;
                    if (d <= inner) v = 1f;
                    else if (d >= outer) continue;
                    else if (outer - inner <= 1f) v = outer - d;
                    else { float u = (d - inner) / (outer - inner); v = 1f - u * u * (3f - 2f * u); }
                    f = Math.round(v * 255f);
                    if (f <= 0) continue;
                }
                int i = row + x;
                if ((on[i] & 0xFF) < f) on[i] = (byte) f;
                int lim = 255 - f;
                if ((off[i] & 0xFF) > lim) off[i] = (byte) lim;
            }
        }
        dirty(x0, y0, x1, y1);
    }

    // ------------------------------------------------------------------ zona
    /**
     * Toque "Quitar zona" / "Anadir zona" (relleno por parecido DENTRO del recorte actual):
     *  - avanza a un vecino si el paso de color es suave (sin borde fuerte: la linea negra de una
     *    mano corta el paso) y el color no se aleja demasiado del tocado (sigue degradados, como
     *    el brillo de una barra);
     *  - el borde suave que ya era dudoso (alfa bajo) tambien se va con la zona;
     *  - un anillo de 1 px queda a medias segun su parecido (sin dientes).
     * Quitar: solo dentro de lo que se ve. Anadir: solo en lo que no se ve del todo.
     * tol = parecido (como Borrar fondo, 46 de fabrica). Devuelve cuantos pixeles cambio.
     */
    public synchronized int zone(int x, int y, boolean addMode, int tol) {
        if (x < 0 || y < 0 || x >= W || y >= H) return 0;
        int s0 = y * W + x;
        if (!addMode && alphaAt(s0) == 0) return snapEdge(x, y, tol);
        if (!inDomain(s0, addMode)) return 0;
        // color de la zona: media 5x5 de lo que esta en el dominio
        long sr = 0, sg = 0, sb = 0, sn = 0;
        for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) {
            int xx = x + dx, yy = y + dy;
            if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
            int i = yy * W + xx;
            if (!inDomain(i, addMode)) continue;
            int c = px[i];
            sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255; sn++;
        }
        int seed = (int) (sr / sn) << 16 | (int) (sg / sn) << 8 | (int) (sb / sn);
        int tolG = Math.max(30, tol * 3 / 2), edgeT = Math.max(12, tol / 3);
        int n = W * H;
        if (zoneMark == null || zoneMark.length != n) zoneMark = new byte[n];
        byte[] mark = zoneMark;
        int[] q = new int[1 << 16];
        int qh = 0, qt = 0;
        mark[s0] = 1; q[qt++] = s0;
        int x0 = x, y0 = y, x1 = x + 1, y1 = y + 1;
        int[] list = new int[1 << 16];
        int ln = 0;
        while (qh < qt) {
            int i = q[qh++];
            if (ln == list.length) list = java.util.Arrays.copyOf(list, ln * 2);
            list[ln++] = i;
            int cx = i % W, cy = i / W;
            if (cx < x0) x0 = cx; if (cx >= x1) x1 = cx + 1; if (cy < y0) y0 = cy; if (cy >= y1) y1 = cy + 1;
            int ci = px[i];
            // solo avanza desde un pixel cuyo alrededor (3x3) tambien es de la zona: asi no se
            // escapa por un paso de 1-2 px en un borde debil (pantalon oscuro junto a un toldo)
            if (i != s0 && !core(cx, cy, seed, tolG, addMode)) continue;
            for (int k = 0; k < 4; k++) {
                int xx = cx + (k == 0 ? 1 : k == 1 ? -1 : 0), yy = cy + (k == 2 ? 1 : k == 3 ? -1 : 0);
                if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
                int j = yy * W + xx;
                if (mark[j] != 0 || !inDomain(j, addMode)) continue;
                int cj = px[j];
                boolean ok;
                int aj = alphaAt(j);
                boolean soft = addMode ? aj > 155 : aj < 100;
                if (soft) ok = maxDiff(cj, seed) <= tolG * 3 / 2;
                else {
                    // en lo oscuro los cambios de color son chicos en numeros: paso mas estricto
                    int et = (lum(ci) < 80 && lum(cj) < 80) ? Math.max(6, edgeT / 2) : edgeT;
                    ok = maxDiff(cj, ci) <= et && maxDiff(cj, seed) <= tolG;
                }
                if (!ok) continue;
                mark[j] = 1;
                if (qt == q.length) {
                    // cola circular simple: compactar
                    System.arraycopy(q, qh, q, 0, qt - qh); qt -= qh; qh = 0;
                    if (qt == q.length) q = java.util.Arrays.copyOf(q, q.length * 2);
                }
                q[qt++] = j;
            }
        }
        if (ln < 4) { for (int t = 0; t < ln; t++) mark[list[t]] = 0; return 0; }
        int bx0 = Math.max(0, x0 - 1), by0 = Math.max(0, y0 - 1), bx1 = Math.min(W, x1 + 1), by1 = Math.min(H, y1 + 1);
        backup(bx0, by0, bx1, by1);
        byte[] on = addMode ? add : rem, off = addMode ? rem : add;
        int changed = 0;
        for (int t = 0; t < ln; t++) {
            int i = list[t];
            if ((on[i] & 0xFF) < 255) { on[i] = (byte) 255; changed++; }
            off[i] = 0;
        }
        if (!addMode) {
            // tiras finas que quedan ENTRE lo quitado y el fondo que ya no se veia (el contorno de
            // la barra): grosor <= 5 px. El contorno de una mano o una carta tiene el personaje
            // del otro lado, no fondo: se queda.
            int sx0 = Math.max(0, x0 - 7), sy0 = Math.max(0, y0 - 7), sx1 = Math.min(W, x1 + 7), sy1 = Math.min(H, y1 + 7);
            int sw = sx1 - sx0, sh = sy1 - sy0;
            byte[] dR = new byte[sw * sh], dB = new byte[sw * sh];
            java.util.Arrays.fill(dR, (byte) 99);
            java.util.Arrays.fill(dB, (byte) 99);
            int[] qa = new int[sw * sh], qb = new int[sw * sh];
            int ah = 0, at = 0, bh = 0, bt = 0;
            for (int yy = sy0; yy < sy1; yy++)
                for (int xx = sx0; xx < sx1; xx++) {
                    int i = yy * W + xx, k = (yy - sy0) * sw + (xx - sx0);
                    if (mark[i] != 0) { dR[k] = 0; qa[at++] = k; }
                    else if (alphaAt(i) == 0) { dB[k] = 0; qb[bt++] = k; }
                }
            bfs(dR, qa, ah, at, sw, sh, 6);
            bfs(dB, qb, bh, bt, sw, sh, 6);
            for (int yy = sy0; yy < sy1; yy++)
                for (int xx = sx0; xx < sx1; xx++) {
                    int k = (yy - sy0) * sw + (xx - sx0);
                    int i = yy * W + xx;
                    if (mark[i] != 0 || dR[k] > 5 || dB[k] > 5 || dR[k] + dB[k] > 6) continue;
                    if (alphaAt(i) == 0) continue;
                    if ((on[i] & 0xFF) < 255) { on[i] = (byte) 255; changed++; }
                    off[i] = 0;
                }
        }
        // anillo de 1 px: a medias segun el parecido
        for (int t = 0; t < ln; t++) {
            int i = list[t];
            int cx = i % W, cy = i / W;
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                int xx = cx + dx, yy = cy + dy;
                if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
                int j = yy * W + xx;
                if (mark[j] != 0 || !inDomain(j, addMode)) continue;
                int d = maxDiff(px[j], seed);
                int f = Math.max(0, Math.min(255, 255 - d * 255 / Math.max(1, tolG * 2)));
                f = f / 2 + 32;
                if ((on[j] & 0xFF) < f) { on[j] = (byte) f; changed++; }
                int lim = 255 - f;
                if ((off[j] & 0xFF) > lim) off[j] = (byte) lim;
            }
        }
        for (int t = 0; t < ln; t++) mark[list[t]] = 0;
        dirty(bx0, by0, bx1, by1);
        return changed;
    }

    private byte[] zoneMark;
    private com.pacco.animecut.core.BgEngine eng;
    private com.pacco.animecut.core.BgEngine.Width width;

    /** Grosor de linea de la imagen (una vez; se puede pedir antes en otro hilo). */
    public synchronized com.pacco.animecut.core.BgEngine.Width width() {
        if (width == null) width = com.pacco.animecut.core.BgEngine.measure(px, null, W, H);
        return width;
    }

    /**
     * Toque sobre el FONDO ya quitado: el Balde de Borrar fondo (motor v8.32, no cruza la linea
     * negra, borde desmezclado) mide ese fondo; donde el Balde y la IA COINCIDEN manda el borde
     * del Balde (mas exacto, sobre todo en manga); donde no coinciden manda la IA.
     */
    synchronized int snapEdge(int x, int y, int tol) {
        int c = com.pacco.animecut.core.BgEngine.colorAt(px, null, W, H, x, y, 3);
        if (c == 0) return 0;
        if (eng == null) eng = new com.pacco.animecut.core.BgEngine();
        eng.setImage(px, null, W, H, width(), null);
        eng.ref = c | 0xFF000000;
        eng.tol = tol;
        eng.mode = com.pacco.animecut.core.ColorDist.HUE;
        eng.gapScale = 1f;
        eng.protect = false;
        if (!eng.tap(x, y)) return 0;
        int rx0 = eng.rx0, ry0 = eng.ry0, rx1 = eng.rx1, ry1 = eng.ry1;
        backup(rx0, ry0, rx1, ry1);
        int n = 0;
        for (int yy = ry0; yy < ry1; yy++)
            for (int xx = rx0; xx < rx1; xx++) {
                int i = yy * W + xx;
                int m = eng.keepAt(xx, yy);
                int cur = alphaAt(i);
                if ((cur >= 128) != (m >= 128) || cur == m) continue;
                int ai = res.alpha[i] & 0xFF;
                // forzar el valor m: max(ai, add) - rem = m
                if (m >= ai) { add[i] = (byte) m; rem[i] = 0; }
                else { add[i] = 0; rem[i] = (byte) (ai - m); }
                n++;
            }
        dirty(rx0, ry0, rx1, ry1);
        return n;
    }

    /** Distancia en pasos (4 vecinos) hasta lim, sobre un recuadro. */
    private static void bfs(byte[] d, int[] q, int qh, int qt, int w, int h, int lim) {
        while (qh < qt) {
            int k = q[qh++];
            int v = d[k];
            if (v >= lim) continue;
            int x = k % w, y = k / w;
            if (x > 0 && d[k - 1] > v + 1) { d[k - 1] = (byte) (v + 1); q[qt++] = k - 1; }
            if (x + 1 < w && d[k + 1] > v + 1) { d[k + 1] = (byte) (v + 1); q[qt++] = k + 1; }
            if (y > 0 && d[k - w] > v + 1) { d[k - w] = (byte) (v + 1); q[qt++] = k - w; }
            if (y + 1 < h && d[k + w] > v + 1) { d[k + w] = (byte) (v + 1); q[qt++] = k + w; }
        }
    }

    private boolean core(int x, int y, int seed, int tolG, boolean addMode) {
        for (int dy = -1; dy <= 1; dy++)
            for (int dx = -1; dx <= 1; dx++) {
                int xx = x + dx, yy = y + dy;
                if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
                int j = yy * W + xx;
                if (!inDomain(j, addMode)) continue;          // lo ya quitado no frena
                int a = alphaAt(j);
                boolean soft = addMode ? a > 155 : a < 100;
                if (soft) continue;
                if (maxDiff(px[j], seed) > tolG) return false;
            }
        return true;
    }

    private boolean inDomain(int i, boolean addMode) {
        int a = alphaAt(i);
        return addMode ? a < 255 && (px[i] >>> 24) > 0 : a > 0;
    }

    static int lum(int c) {
        return (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
    }

    static int maxDiff(int a, int b) {
        int dr = Math.abs(((a >> 16) & 255) - ((b >> 16) & 255));
        int dg = Math.abs(((a >> 8) & 255) - ((b >> 8) & 255));
        int db = Math.abs((a & 255) - (b & 255));
        return Math.max(dr, Math.max(dg, db));
    }

    /**
     * "Solo este personaje": se quitan las OTRAS piezas grandes que encontro la IA (las chicas
     * cercanas, como aros o mechones, se quedan). Si los personajes se tocan son una sola pieza:
     * en ese caso no hace nada (devuelve 0) y hay que usar Quitar.
     */
    public int keepOnly(int x, int y) {
        AiMatte.Result r = res;
        int me = r.compAt(x, y);
        if (me <= 0) return -1;
        int w = r.cw, h = r.ch;
        int big = Math.max(1, r.compArea[me] / 50);
        // duenos: cada celda toma la pieza mas cercana (hasta 3 celdas), para llevar su borde suave
        int[] own = new int[w * h];
        int[] q = new int[w * h];
        int[] st = new int[w * h];
        int qh = 0, qt = 0;
        for (int i = 0; i < w * h; i++) if (r.comp[i] > 0) { own[i] = r.comp[i]; q[qt++] = i; }
        while (qh < qt) {
            int i = q[qh++];
            if (st[i] >= 3) continue;
            int cx = i % w, cy = i / w;
            for (int k = 0; k < 4; k++) {
                int xx = cx + (k == 0 ? 1 : k == 1 ? -1 : 0), yy = cy + (k == 2 ? 1 : k == 3 ? -1 : 0);
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                int j = yy * w + xx;
                if (own[j] != 0) continue;
                own[j] = own[i];
                st[j] = st[i] + 1;
                q[qt++] = j;
            }
        }
        boolean any = false;
        for (int l = 1; l <= r.nComp; l++) if (l != me && r.compArea[l] >= big) { any = true; break; }
        if (!any) return 0;
        AiPrep p = prep;
        backup(p.cropX, p.cropY, p.cropX + p.cropW, p.cropY + p.cropH);
        int n = 0;
        for (int yy = 0; yy < p.cropH; yy++) {
            int cy = Math.min(h - 1, (int) ((yy + 0.5f) * h / p.cropH));
            for (int xx = 0; xx < p.cropW; xx++) {
                int cx = Math.min(w - 1, (int) ((xx + 0.5f) * w / p.cropW));
                int o = own[cy * w + cx];
                if (o == 0 || o == me || r.compArea[o] < big) continue;
                int i = (p.cropY + yy) * W + p.cropX + xx;
                if ((res.alpha[i] & 0xFF) == 0) continue;
                rem[i] = (byte) 255;
                add[i] = 0;
                n++;
            }
        }
        dirty(p.cropX, p.cropY, p.cropX + p.cropW, p.cropY + p.cropH);
        return n;
    }

    /**
     * Escoba del recorte: quita los pedazos SUELTOS que quedaron lejos del personaje (restos de
     * barras o brillos despues de usar Quitar). Se quedan: la pieza mayor, otras grandes (otro
     * personaje) y las chicas CERCANAS (aros, mechones). Con deshacer. Devuelve pixeles quitados.
     */
    public int cleanRemnants() {
        int c = Math.max(1, (Math.max(W, H) + 1023) / 1024);
        int gw = (W + c - 1) / c, gh = (H + c - 1) / c, n = gw * gh;
        float[] g = new float[n];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int a = alphaAt(y * W + x);
                int k = (y / c) * gw + x / c;
                if (a / 255f > g[k]) g[k] = a / 255f;
            }
        int[] lab = new int[n];
        int nc = AiMatte.label(g, gw, gh, lab, true);
        if (nc <= 1) return 0;
        int[] area = new int[nc + 1];
        for (int i = 0; i < n; i++) if (lab[i] > 0) area[lab[i]]++;
        int main = 1;
        for (int l = 2; l <= nc; l++) if (area[l] > area[main]) main = l;
        boolean[] keep = new boolean[nc + 1];
        for (int l = 1; l <= nc; l++) if (area[l] * 100L >= area[main] * 4L) keep[l] = true;
        int[] d2 = AiMatte.distToKept(lab, keep, gw, gh);
        int[] minD = new int[nc + 1];
        java.util.Arrays.fill(minD, Integer.MAX_VALUE);
        for (int i = 0; i < n; i++) { int l = lab[i]; if (l > 0 && d2[i] < minD[l]) minD[l] = d2[i]; }
        int near = Math.max(4, Math.round(0.025f * Math.max(gw, gh)));
        boolean any = false;
        for (int l = 1; l <= nc; l++) {
            if (keep[l]) continue;
            if (minD[l] <= near * near) keep[l] = true; else any = true;
        }
        if (!any) return 0;
        // cada pixel visible toma la pieza de su celda (o de la celda vecina con pieza)
        backup(0, 0, W, H);
        int removed = 0;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                if (alphaAt(i) == 0) continue;
                int cx = x / c, cy = y / c;
                int l = lab[cy * gw + cx];
                if (l == 0) {
                    for (int dy = -1; dy <= 1 && l == 0; dy++) for (int dx = -1; dx <= 1 && l == 0; dx++) {
                        int xx = cx + dx, yy = cy + dy;
                        if (xx >= 0 && yy >= 0 && xx < gw && yy < gh) l = lab[yy * gw + xx];
                    }
                }
                // l == 0: bruma suelta (nunca llega a 0,5) lejos de toda pieza: tambien se va
                if (l != 0 && keep[l]) continue;
                rem[i] = (byte) 255;
                add[i] = 0;
                removed++;
            }
        dirty(0, 0, W, H);
        return removed;
    }

    /** Borra todos los retoques (con deshacer). */
    public void clearTouches() {
        if (add == null) return;
        backup(0, 0, W, H);
        java.util.Arrays.fill(add, (byte) 0);
        java.util.Arrays.fill(rem, (byte) 0);
        dirty(0, 0, W, H);
    }

    /** Suelta memoria auxiliar. */
    public synchronized void release() {
        zoneMark = null;
        if (eng != null) eng.release();
        eng = null;
    }

    // pruebas
    public byte[] addMask() { return add; }
    public byte[] remMask() { return rem; }
}
