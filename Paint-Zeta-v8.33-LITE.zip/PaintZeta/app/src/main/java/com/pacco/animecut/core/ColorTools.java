package com.pacco.animecut.core;

/**
 * v8.33: utilidades del selector de color (Java puro, probadas en PC):
 *  - HSV <-> RGB y HEX;
 *  - mezcla de dos colores con proporcion, en luz LINEAL (como se mezcla la luz: el medio entre
 *    rojo y verde no sale marron oscuro) o en sRGB (como mezclar "a ojo" en la pantalla);
 *  - paleta de una imagen de referencia: corte por la mediana (determinista, rapido), ordenada
 *    por brillo, sin repetir colores casi iguales;
 *  - recientes (lista sin repetidos, el ultimo primero).
 */
public final class ColorTools {
    private ColorTools() { }

    // ------------------------------------------------------------------ HSV / HEX
    /** h 0..360, s 0..1, v 0..1 -> 0xFFRRGGBB */
    public static int hsvToRgb(float h, float s, float v) {
        h = ((h % 360f) + 360f) % 360f;
        s = Math.max(0f, Math.min(1f, s));
        v = Math.max(0f, Math.min(1f, v));
        float c = v * s, x = c * (1 - Math.abs((h / 60f) % 2 - 1)), m = v - c;
        float r, g, b;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        return 0xFF000000 | (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    /** -> {h 0..360, s 0..1, v 0..1} */
    public static float[] rgbToHsv(int c) {
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h;
        if (d == 0) h = 0;
        else if (max == r) h = 60 * (((g - b) / d) % 6);
        else if (max == g) h = 60 * ((b - r) / d + 2);
        else h = 60 * ((r - g) / d + 4);
        if (h < 0) h += 360;
        return new float[]{h, max == 0 ? 0 : d / max, max};
    }

    public static String toHex(int c) {
        return String.format(java.util.Locale.US, "#%06X", c & 0xFFFFFF);
    }

    /** "#RGB", "#RRGGBB", "RRGGBB" (con o sin #, espacios). null si no es valido. */
    public static Integer parseHex(String t) {
        if (t == null) return null;
        String s = t.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() == 3) s = "" + s.charAt(0) + s.charAt(0) + s.charAt(1) + s.charAt(1) + s.charAt(2) + s.charAt(2);
        if (s.length() != 6) return null;
        try { return 0xFF000000 | (int) Long.parseLong(s, 16); }
        catch (NumberFormatException e) { return null; }
    }

    // ------------------------------------------------------------------ mezcla
    private static float toLin(int v) {
        float c = v / 255f;
        return c <= 0.04045f ? c / 12.92f : (float) Math.pow((c + 0.055f) / 1.055f, 2.4f);
    }

    private static int fromLin(float l) {
        l = Math.max(0f, Math.min(1f, l));
        float c = l <= 0.0031308f ? l * 12.92f : (float) (1.055f * Math.pow(l, 1 / 2.4f) - 0.055f);
        return Math.round(c * 255f);
    }

    /**
     * Mezcla a y b. t = parte de b (0 = todo a, 1 = todo b). linear = en luz lineal (mas natural
     * para luces y brillos); si no, promedio en sRGB (lo que se ve "a ojo" en la pantalla).
     */
    public static int mix(int a, int b, float t, boolean linear) {
        t = Math.max(0f, Math.min(1f, t));
        int out = 0xFF000000;
        for (int sh = 16; sh >= 0; sh -= 8) {
            int va = (a >> sh) & 255, vb = (b >> sh) & 255;
            int v = linear ? fromLin(toLin(va) * (1 - t) + toLin(vb) * t) : Math.round(va * (1 - t) + vb * t);
            out |= v << sh;
        }
        return out;
    }

    // ------------------------------------------------------------------ paleta
    /**
     * Hasta k colores representativos de la imagen (corte por la mediana sobre una muestra), sin
     * transparentes, sin casi iguales (distancia < minDist), ordenados de oscuro a claro.
     */
    public static int[] palette(int[] px, int w, int h, int k, int minDist) {
        int n = w * h;
        int step = Math.max(1, (int) Math.sqrt(n / 40000.0));
        int[] s = new int[(w / step + 1) * (h / step + 1)];
        int m = 0;
        for (int y = 0; y < h; y += step)
            for (int x = 0; x < w; x += step) {
                int c = px[y * w + x];
                if ((c >>> 24) < 200) continue;
                s[m++] = c | 0xFF000000;
            }
        if (m == 0) return new int[0];
        java.util.ArrayList<int[]> boxes = new java.util.ArrayList<>();
        boxes.add(new int[]{0, m});
        // partir la caja de mayor rango x cantidad hasta tener 2k cajas
        while (boxes.size() < k * 2) {
            int bi = -1, bestScore = -1, bestCh = 0;
            for (int i = 0; i < boxes.size(); i++) {
                int[] bx = boxes.get(i);
                if (bx[1] - bx[0] < 2) continue;
                int[] rg = range(s, bx[0], bx[1]);
                int ch = rg[0] >= rg[1] && rg[0] >= rg[2] ? 16 : rg[1] >= rg[2] ? 8 : 0;
                int r = Math.max(rg[0], Math.max(rg[1], rg[2]));
                int score = r * (int) Math.sqrt(bx[1] - bx[0]);
                if (score > bestScore) { bestScore = score; bi = i; bestCh = ch; }
            }
            if (bi < 0 || bestScore <= 0) break;
            int[] bx = boxes.remove(bi);
            sortBy(s, bx[0], bx[1], bestCh);
            int mid = (bx[0] + bx[1]) / 2;
            boxes.add(new int[]{bx[0], mid});
            boxes.add(new int[]{mid, bx[1]});
        }
        // promedio de cada caja; despues se eligen variados: la mas poblada primero y luego la
        // que mas se aleja de las ya elegidas (pesando un poco cuanto ocupa). Asi un color con
        // menos area pero distinto (la chaqueta roja frente a mucho cielo) entra.
        int nb = boxes.size();
        int[] avg = new int[nb], pop = new int[nb];
        for (int i = 0; i < nb; i++) {
            int[] bx = boxes.get(i);
            long r = 0, g = 0, b = 0;
            int cnt = bx[1] - bx[0];
            pop[i] = cnt;
            if (cnt <= 0) continue;
            for (int j = bx[0]; j < bx[1]; j++) { r += (s[j] >> 16) & 255; g += (s[j] >> 8) & 255; b += s[j] & 255; }
            avg[i] = 0xFF000000 | ((int) (r / cnt) << 16) | ((int) (g / cnt) << 8) | (int) (b / cnt);
        }
        java.util.ArrayList<Integer> out = new java.util.ArrayList<>();
        boolean[] used = new boolean[nb];
        while (out.size() < k) {
            int best = -1;
            double bestScore = -1;
            for (int i = 0; i < nb; i++) {
                if (used[i] || pop[i] <= 0) continue;
                int md = 442;
                for (int o : out) md = Math.min(md, dist(o, avg[i]));
                if (!out.isEmpty() && md < minDist) continue;
                double score = (out.isEmpty() ? 1 : md) * Math.sqrt(pop[i]);
                if (score > bestScore) { bestScore = score; best = i; }
            }
            if (best < 0) break;
            used[best] = true;
            out.add(avg[best]);
        }
        out.sort((p, q) -> Integer.compare(lum(p), lum(q)));
        int[] res = new int[out.size()];
        for (int i = 0; i < res.length; i++) res[i] = out.get(i);
        return res;
    }

    static int lum(int c) { return (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000; }

    public static int dist(int a, int b) {
        int dr = ((a >> 16) & 255) - ((b >> 16) & 255), dg = ((a >> 8) & 255) - ((b >> 8) & 255), db = (a & 255) - (b & 255);
        return (int) Math.sqrt(dr * dr + dg * dg + db * db);
    }

    private static int[] range(int[] s, int a, int b) {
        int[] mn = {255, 255, 255}, mx = {0, 0, 0};
        for (int i = a; i < b; i++) {
            for (int k = 0; k < 3; k++) {
                int v = (s[i] >> (16 - 8 * k)) & 255;
                if (v < mn[k]) mn[k] = v;
                if (v > mx[k]) mx[k] = v;
            }
        }
        return new int[]{mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]};
    }

    private static void sortBy(int[] s, int a, int b, int sh) {
        long[] t = new long[b - a];
        for (int i = a; i < b; i++) t[i - a] = ((long) ((s[i] >> sh) & 255) << 32) | (s[i] & 0xFFFFFFFFL);
        java.util.Arrays.sort(t);
        for (int i = a; i < b; i++) s[i] = (int) t[i - a];
    }

    // ------------------------------------------------------------------ recientes
    /** Pone c primero, sin repetir, hasta max. Formato texto "RRGGBB,RRGGBB,...". */
    public static String pushRecent(String list, int c, int max) {
        StringBuilder sb = new StringBuilder(String.format(java.util.Locale.US, "%06X", c & 0xFFFFFF));
        int n = 1;
        if (list != null) for (String p : list.split(",")) {
            if (n >= max) break;
            Integer v = parseHex(p);
            if (v == null || (v & 0xFFFFFF) == (c & 0xFFFFFF)) continue;
            sb.append(',').append(String.format(java.util.Locale.US, "%06X", v & 0xFFFFFF));
            n++;
        }
        return sb.toString();
    }

    public static int[] parseList(String list) {
        if (list == null || list.isEmpty()) return new int[0];
        java.util.ArrayList<Integer> out = new java.util.ArrayList<>();
        for (String p : list.split(",")) { Integer v = parseHex(p); if (v != null) out.add(v); }
        int[] r = new int[out.size()];
        for (int i = 0; i < r.length; i++) r[i] = out.get(i);
        return r;
    }
}
