package com.pacco.animecut.core;

/**
 * v8.32: un trazo del PINCEL PROTEGIDO de Borrar fondo. Lo usan la app y las pruebas (el mismo
 * codigo), sobre el mismo motor que el Balde (BgEngine): no hay dos analisis distintos.
 *
 *  - Color del fondo: el del primer punto (color de antes, aunque ya este borrado). Si "solo al
 *    empezar" esta apagado, el color sigue cambios SUAVES del fondo (cueva que se aclara) en
 *    zonas parejas que el trazo ya acepto; nunca salta a la linea ni al personaje.
 *  - Alcance: solo se avanza desde lo aceptado en las estampas anteriores, desde lo ya borrado
 *    (si era fondo de ese color) y, al empezar, desde el dedo. Si el dedo cruza la linea a
 *    otra zona encerrada, ahi no se borra (para borrar ese hueco: tocar con el Balde o empezar
 *    otro trazo adentro).
 *  - Lo aceptado se guarda con su "m" (ancho minimo por donde paso), asi repasar mil veces el
 *    mismo hueco no lo va abriendo de a poco.
 */
public final class BgStroke {
    public final BgEngine eng = new BgEngine();
    private byte[] accept;
    private int ax0, ay0, ax1, ay1;
    private boolean any, started;
    private int[] cur, snap;
    private int W, H;
    public boolean once;
    public int refStart;
    public int dabs;
    public long msTotal, msMax;

    /** Empieza el trazo. false si no hay color de fondo para tomar. */
    public boolean begin(int[] cur, int[] snap, int w, int h, BgEngine.Width wd, byte[] sel,
                         int sx, int sy, int tol, int mode, float gapScale, int searchR) {
        this.cur = cur;
        this.snap = snap != null && snap.length == cur.length ? snap : null;
        W = w; H = h;
        eng.setImage(cur, this.snap, w, h, wd, sel);
        eng.tol = tol;
        eng.mode = mode;
        eng.gapScale = gapScale;
        // v8.33: empezar sobre una zona negra ANCHA toma el negro (como el Balde)
        int tc = BgEngine.tapColor(cur, this.snap, w, h, sx, sy);
        int ref = tc != 0 && inkAbs(tc) ? tc : sampleRef(sx, sy, Math.max(2, searchR));
        started = false;
        any = false;
        dabs = 0;
        msTotal = msMax = 0;
        if (accept == null || accept.length != w * h) accept = new byte[w * h];
        ax0 = ay0 = Integer.MAX_VALUE; ax1 = ay1 = Integer.MIN_VALUE;
        if (ref == 0) return false;
        eng.ref = ref | 0xFF000000;
        eng.tone = eng.detectTone(sx, sy);
        refStart = eng.ref;
        started = true;
        gsx = sx; gsy = sy;
        gen++;
        globalReady = false;
        eng.global = null;
        return true;
    }

    public boolean isStarted() { return started; }

    public int ref() { return eng.ref; }

    int sampleRef(int cx, int cy, int r) {
        return BgEngine.colorAt(cur, snap, W, H, cx, cy, r);
    }

    static boolean inkAbs(int c) {
        int l = BgEngine.lum(c);
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        int sat = Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
        return l < 45 || (l < 70 && sat < 60);
    }

    /**
     * Una estampa. Devuelve true si hay algo para aplicar (eng.keepAt / eng.applyTo, ya limitado
     * al circulo).
     */
    public boolean dab(float cx, float cy, float rad) {
        if (!started) return false;
        int cxi = Math.max(0, Math.min(W - 1, (int) cx)), cyi = Math.max(0, Math.min(H - 1, (int) cy));
        if (!once && any && cxi >= 0 && cyi >= 0 && cxi < W && cyi < H && accept[cyi * W + cxi] != 0) followColor(cxi, cyi);
        useGlobal();
        eng.drift = !once;
        eng.ref2 = eng.ref != refStart ? refStart : 0;
        boolean r = eng.dab(cx, cy, rad, !any, accept);
        dabs++;
        msTotal += eng.lastMs;
        msMax = Math.max(msMax, eng.lastMs);
        if (r || eng.claimed > 0 || eng.cored > 0) {
            any = true;
            int m = (int) Math.ceil(rad) + 3 * eng.maxRadius() + 8;
            ax0 = Math.min(ax0, Math.max(0, cxi - m));
            ay0 = Math.min(ay0, Math.max(0, cyi - m));
            ax1 = Math.max(ax1, Math.min(W, cxi + m + 1));
            ay1 = Math.max(ay1, Math.min(H, cyi + m + 1));
        }
        return r;
    }

    /** El color sigue al fondo solo con cambios suaves y en una zona pareja (5x5). */
    private void followColor(int x, int y) {
        int c = BgEngine.colorOf(cur, snap, y * W + x);
        if ((c >>> 24) <= 32) return;
        int ref = eng.ref;
        if (BgGuard.inkLike(c | 0xFF000000, ref)) return;
        // el dedo esta sobre algo que el trazo YA ACEPTO: el color cambia de a POCO por estampa
        // (media tolerancia; un salto al color del personaje parecido al fondo no se toma) y sin
        // alejarse mas que tolerancia + DRIFT del color del COMIENZO; zona pareja de 3x3
        if (eng.bgDist(c, ref) > Math.max(12, eng.tol / 2)) return;
        if (eng.bgDist(c, refStart) > eng.tol + BgEngine.DRIFT) return;
        int lim = Math.max(16, eng.tol * 2 / 3);
        for (int dy = -1; dy <= 1; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= H) return;
            for (int dx = -1; dx <= 1; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= W) return;
                int q = BgEngine.colorOf(cur, snap, yy * W + xx);
                if ((q >>> 24) < 32) continue;
                if (ColorDist.dist(q | 0xFF000000, c | 0xFF000000, ColorDist.RGB) > lim) return;
            }
        }
        eng.ref = c | 0xFF000000;
    }

    private BgEngine globalEng;
    private long[] globalBits;
    private int gsx, gsy;
    private volatile boolean globalReady;

    /**
     * Calcula (en otro hilo, si se quiere) la region de fondo unida al punto de comienzo con el
     * mismo analisis del Balde. Cuando esta lista, el pincel reconoce ese fondo aunque el dedo
     * haya pasado por encima del personaje. Sin memoria: el pincel sigue sin ella.
     */
    public int generation() { return gen; }

    private volatile int gen;

    public synchronized void computeGlobal(int myGen) {
        if (!started || myGen != gen) return;
        try {
            if (globalEng == null) globalEng = new BgEngine();
            BgEngine g = globalEng;
            g.setImage(cur, snap, W, H, eng.width(), null);
            g.tol = eng.tol; g.mode = eng.mode; g.gapScale = eng.gapScale; g.ref = refStart;
            g.toneFrom(eng);
            g.protect = eng.protect; g.protectColor = eng.protectColor; g.protectTol = eng.protectTol;
            int words = (W * H + 63) >>> 6;
            long[] b = new long[words];
            g.region(gsx, gsy, b);
            // los mapas grandes se sueltan enseguida (queda 1 bit por pixel)
            g.release();
            if (myGen != gen) return;
            globalBits = b;
            globalMs = g.lastMs;
            globalReady = true;
        } catch (OutOfMemoryError oom) {
            globalEng = null;
            globalBits = null;
        }
    }

    public long globalMs;

    /** Llamar en el hilo de la UI antes de cada estampa: activa la region global si ya esta. */
    void useGlobal() {
        eng.global = globalReady ? globalBits : null;
    }

    /** Termina el trazo: limpia lo aceptado (solo la caja usada). */
    public void end() {
        if (accept != null && ax1 > ax0) {
            for (int y = ay0; y < ay1; y++) java.util.Arrays.fill(accept, y * W + ax0, y * W + ax1, (byte) 0);
        }
        ax0 = ay0 = Integer.MAX_VALUE; ax1 = ay1 = Integer.MIN_VALUE;
        started = false;
        any = false;
        gen++;
        globalReady = false;
        eng.global = null;
    }

    /** Libera memoria (al salir de Borrar fondo). */
    public void release() {
        accept = null;
        eng.release();
        if (globalEng != null) globalEng.release();
        globalEng = null;
        globalBits = null;
    }
}
