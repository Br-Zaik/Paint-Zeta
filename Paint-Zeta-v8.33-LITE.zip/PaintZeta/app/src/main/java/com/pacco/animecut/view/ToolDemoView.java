package com.pacco.animecut.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Mini animacion que muestra la herramienta trabajando: un dedo se mueve por
 * el dibujo y, por donde pasa, aparece el resultado. Se repite sola.
 */
public class ToolDemoView extends View {

    private final int mode;
    private final boolean sub;
    /** Submodo de Especial: 0 arrastrar, 1 contraer, 2 expandir, 3 suavizar, 4 restaurar. */
    private final int variant;
    private Bitmap before, after, demoBlur;
    private float t = 0f;
    private ValueAnimator anim;
    private final Paint finger = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static final int KIND_BRUSH = 0, KIND_TAP = 1, KIND_TRACE = 2, KIND_FADE = 3,
            KIND_POINTS = 4, KIND_PAN = 5, KIND_BLUR = 6, KIND_LIQUIFY = 7, KIND_SMUDGE = 8;

    public ToolDemoView(Context c, int mode, boolean sub) {
        this(c, mode, sub, 0);
    }

    public ToolDemoView(Context c, int mode, boolean sub, int variant) {
        super(c);
        this.mode = mode;
        this.sub = sub;
        this.variant = Math.max(0, Math.min(4, variant));
        finger.setColor(0xDDFFFFFF);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(Color.WHITE);
        ring.setStrokeWidth(3f);
        frame.setStyle(Paint.Style.STROKE);
        frame.setColor(0x66FFFFFF);
        frame.setStrokeWidth(2f);
    }

    private int kind() {
        switch (mode) {
            case CanvasView.MODE_WAND:
            case CanvasView.MODE_BUCKET:
            case CanvasView.MODE_ZONE:
            case CanvasView.MODE_PICKER:
            case CanvasView.MODE_TONE:
                return KIND_TAP;
            case CanvasView.MODE_SCISSORS:
            case CanvasView.MODE_MAGNET:
            case CanvasView.MODE_LASSO:
                return KIND_TRACE;
            case CanvasView.MODE_CURVE:
            case CanvasView.MODE_POLY:
                return KIND_POINTS;
            case CanvasView.MODE_PAN:
                return KIND_PAN;
            case CanvasView.MODE_BLUR:
                return KIND_BLUR;
            case CanvasView.MODE_LIQUIFY:
                return KIND_LIQUIFY;
            case CanvasView.MODE_SMUDGE:
                return KIND_SMUDGE;
            case CanvasView.MODE_MOVE:
            case CanvasView.MODE_MARKER:
                return KIND_FADE;
            default:
                return KIND_BRUSH;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (before != null) before.recycle();
        if (after != null) after.recycle();
        if (demoBlur != null) demoBlur.recycle();
        before = ToolArt.panel(mode, sub, false, w, h);
        after = ToolArt.panel(mode, sub, true, w, h);
        if (mode == CanvasView.MODE_BGERASE) prepareBgSeq(w, h);
        demoBlur = mode == CanvasView.MODE_BLUR ? makeSoftBlur(before, w, h) : null;
        start();
    }

    private void start() {
        if (anim != null) anim.cancel();
        boolean seq = mode == CanvasView.MODE_BGERASE;
        anim = ValueAnimator.ofFloat(0f, seq ? 5f : 1.35f);
        anim.setDuration(seq ? 14000 : 3200);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    /** Recorrido del dedo para cada herramienta. */
    private Path route(float w, float h) {
        Path p = new Path();
        switch (mode) {
            case CanvasView.MODE_BGERASE:
                // borde del personaje, por afuera
                p.moveTo(w * 0.1f, h * 0.95f);
                p.lineTo(w * 0.12f, h * 0.2f);
                p.lineTo(w * 0.5f, h * 0.05f);
                p.lineTo(w * 0.88f, h * 0.2f);
                p.lineTo(w * 0.9f, h * 0.95f);
                break;
            case CanvasView.MODE_ERASER:
            case CanvasView.MODE_PAINT:
                p.moveTo(w * 0.25f, h * 0.85f);
                p.lineTo(w * 0.75f, h * 0.75f);
                p.lineTo(w * 0.3f, h * 0.95f);
                p.lineTo(w * 0.75f, h * 0.9f);
                break;
            case CanvasView.MODE_LINE:
                p.moveTo(w * 0.3f, h * 0.62f);
                p.cubicTo(w * 0.45f, h * 0.5f, w * 0.55f, h * 0.45f, w * 0.7f, h * 0.38f);
                break;
            default:
                // pasadas cortas sobre la zona de arriba (pelo y cara)
                p.moveTo(w * 0.3f, h * 0.2f);
                p.lineTo(w * 0.7f, h * 0.2f);
                p.lineTo(w * 0.3f, h * 0.35f);
                p.lineTo(w * 0.7f, h * 0.35f);
                p.lineTo(w * 0.35f, h * 0.52f);
                p.lineTo(w * 0.65f, h * 0.52f);
                p.lineTo(w * 0.5f, h * 0.8f);
                break;
        }
        return p;
    }

    private float[] tapPoint(float w, float h) {
        switch (mode) {
            case CanvasView.MODE_WAND:
                return new float[]{w * 0.5f, h * 0.2f};
            case CanvasView.MODE_TONE:
                return new float[]{w * 0.18f, h * 0.2f};
            default:
                return new float[]{w * 0.5f, h * 0.8f};
        }
    }

    private static float ease(float v) {
        v = Math.max(0f, Math.min(1f, v));
        return v * v * (3f - 2f * v);
    }

    /** Desenfoque pequeno solo para la animacion explicativa; se calcula una vez. */
    private static Bitmap makeSoftBlur(Bitmap src, int w, int h) {
        if (src == null || w <= 0 || h <= 0) return null;
        try {
            int n = w * h;
            int[] a = new int[n], b = new int[n];
            src.getPixels(a, 0, w, 0, 0, w, h);
            // Dos pasadas 3x3 dan un desenfoque visible sin depender de RenderEffect.
            for (int pass = 0; pass < 2; pass++) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int aa = 0, rr = 0, gg = 0, bb = 0, count = 0;
                        for (int oy = -1; oy <= 1; oy++) {
                            int sy = Math.max(0, Math.min(h - 1, y + oy));
                            int off = sy * w;
                            for (int ox = -1; ox <= 1; ox++) {
                                int sx = Math.max(0, Math.min(w - 1, x + ox));
                                int q = a[off + sx];
                                aa += q >>> 24;
                                rr += (q >> 16) & 255;
                                gg += (q >> 8) & 255;
                                bb += q & 255;
                                count++;
                            }
                        }
                        b[y * w + x] = ((aa / count) << 24) | ((rr / count) << 16)
                                | ((gg / count) << 8) | (bb / count);
                    }
                }
                int[] tmp = a; a = b; b = tmp;
            }
            Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            out.setPixels(a, 0, w, 0, 0, w, h);
            return out;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    private void drawBlurDemo(Canvas c, float w, float h, float p) {
        if (demoBlur == null) return;
        Path path = new Path();
        path.moveTo(w * .27f, h * .24f);
        path.cubicTo(w * .42f, h * .16f, w * .62f, h * .20f, w * .72f, h * .33f);
        path.cubicTo(w * .62f, h * .43f, w * .42f, h * .43f, w * .32f, h * .55f);
        PathMeasure pm = new PathMeasure(path, false);
        float len = pm.getLength(), drawn = Math.min(1f, p / .86f) * len;
        float br = h * .15f;
        Path reveal = new Path();
        float[] pos = new float[2];
        for (float d = 0; d <= drawn; d += Math.max(2f, br * .30f)) {
            pm.getPosTan(d, pos, null);
            reveal.addCircle(pos[0], pos[1], br, Path.Direction.CW);
        }
        c.save();
        c.clipPath(reveal);
        c.drawBitmap(demoBlur, 0, 0, null);
        c.restore();
        if (t < 1f && drawn > 0f) {
            pm.getPosTan(drawn, pos, null);
            c.drawCircle(pos[0], pos[1], br, ring);
            c.drawCircle(pos[0], pos[1], h * .035f, finger);
        }
    }

    private void drawSmudgeDemo(Canvas c, float w, float h, float p) {
        float e = ease(Math.min(1f, p / .84f));
        float sx = w * .30f, sy = h * .36f;
        float dx = w * .32f * e;
        float fx = sx + dx;
        float br = h * .16f;
        Path clip = new Path();
        clip.addCircle(fx, sy, br, Path.Direction.CW);
        Paint smear = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        c.save();
        c.clipPath(clip);
        for (int i = 1; i <= 4; i++) {
            smear.setAlpha(42 + i * 18);
            c.save();
            c.translate(dx * (i / 4f) * .55f, 0);
            c.drawBitmap(before, 0, 0, smear);
            c.restore();
        }
        c.restore();
        if (t < 1f) {
            c.drawCircle(fx, sy, br, ring);
            c.drawCircle(fx, sy, h * .035f, finger);
        }
    }

    /** Animacion real de los cinco submodos de Especial. */
    private void drawLiquifyDemo(Canvas c, float w, float h, float p) {
        float e = ease((p - .08f) / .78f);
        float cx = w * .50f, cy = h * .37f, br = h * .27f;
        float fx = cx, fy = cy;
        Path clip = new Path();
        Paint guide = new Paint(Paint.ANTI_ALIAS_FLAG);
        guide.setStyle(Paint.Style.STROKE);
        guide.setStrokeWidth(Math.max(2f, h * .012f));
        guide.setColor(0x99FFFFFF);

        c.save();
        if (variant == 0) {
            float dx = w * .24f * e;
            fx = w * .34f + dx;
            fy = cy;
            clip.addCircle(fx, fy, br, Path.Direction.CW);
            c.clipPath(clip);
            c.translate(dx, 0);
            c.drawBitmap(before, 0, 0, null);
        } else if (variant == 1) {
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            float sc = 1f - .28f * e;
            c.scale(sc, sc, cx, cy);
            c.drawBitmap(before, 0, 0, null);
        } else if (variant == 2) {
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            float sc = 1f + .32f * e;
            c.scale(sc, sc, cx, cy);
            c.drawBitmap(before, 0, 0, null);
        } else if (variant == 3) {
            // Suavizar: una deformacion fuerte se relaja progresivamente sin blur.
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            float u = 1f - e;
            c.translate(w * .08f * u, 0);
            c.rotate(10f * u, cx, cy);
            c.scale(1f + .10f * u, 1f - .04f * u, cx, cy);
            c.drawBitmap(before, 0, 0, null);
            fx = cx; fy = cy;
        } else {
            // Restaurar empieza deformado y vuelve progresivamente al original.
            float u = 1f - e;
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            c.translate(w * .10f * u, 0);
            c.rotate(18f * u, cx, cy);
            float sc = 1f + .18f * u;
            c.scale(sc, sc, cx, cy);
            c.drawBitmap(before, 0, 0, null);
            fx = cx + w * .10f * (1f - e);
        }
        c.restore();

        // Flechas simples ayudan a entender contraer/expandir sin texto adicional.
        if (variant == 1 || variant == 2) {
            float dir = variant == 1 ? -1f : 1f;
            for (int i = 0; i < 4; i++) {
                double a = i * Math.PI / 2.0;
                float ux = (float) Math.cos(a), uy = (float) Math.sin(a);
                float r0 = br * (variant == 1 ? .82f : .34f);
                float r1 = r0 + dir * br * .28f * Math.max(.25f, e);
                c.drawLine(cx + ux * r0, cy + uy * r0, cx + ux * r1, cy + uy * r1, guide);
            }
        }
        if (t < 1f) {
            c.drawCircle(fx, fy, br, ring);
            c.drawCircle(fx, fy, h * .035f, finger);
        }
    }

    // ================= v8.32: Borrar fondo en 5 escenas (sin texto) =================
    private Bitmap seqBg, seqChk, seqChr;
    private Path seqSil;
    private final Paint seqPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private void prepareBgSeq(int w, int h) {
        try {
            if (seqBg != null) seqBg.recycle();
            if (seqChk != null) seqChk.recycle();
            if (seqChr != null) seqChr.recycle();
            seqBg = ToolArt.backgroundOnly(1, w, h);
            seqChk = ToolArt.backgroundOnly(0, w, h);
            seqChr = ToolArt.characterOnly(w, h);
            seqSil = ToolArt.silhouette(new RectF(0, 0, w, h));
        } catch (OutOfMemoryError e) {
            seqBg = seqChk = seqChr = null;
        }
    }

    private static final int[] SEQ_ICONS = {com.pacco.animecut.R.drawable.ic_bucket, com.pacco.animecut.R.drawable.ic_bgerase,
            com.pacco.animecut.R.drawable.ic_eraser, com.pacco.animecut.R.drawable.ic_restore_brush, com.pacco.animecut.R.drawable.ic_broom};

    /** Recorrido de cada escena (fracciones del cuadro). */
    private Path seqRoute(int k, float w, float h) {
        Path p = new Path();
        if (k == 1) {            // pincel: pegado al contorno, a veces encima del pelo (no lo borra)
            p.moveTo(w * .12f, h * .95f);
            p.cubicTo(w * .10f, h * .55f, w * .14f, h * .20f, w * .40f, h * .06f);
            p.cubicTo(w * .62f, h * .00f, w * .86f, h * .12f, w * .84f, h * .45f);
            p.lineTo(w * .90f, h * .95f);
        } else if (k == 2) {     // borrador: sobre una mancha suelta junto al hombro
            p.moveTo(w * .90f, h * .62f);
            p.lineTo(w * .78f, h * .60f);
            p.lineTo(w * .90f, h * .70f);
        } else {                 // restaurar: por la izquierda
            p.moveTo(w * .10f, h * .15f);
            p.lineTo(w * .12f, h * .55f);
            p.lineTo(w * .20f, h * .85f);
        }
        return p;
    }

    private void drawBgSeq(Canvas c, float w, float h) {
        int k = Math.min(4, (int) t);
        float f = t - k;
        float pf = Math.min(1f, f / 0.8f);          // 0..1 la accion; el resto, pausa con el resultado
        float br = h * 0.11f;
        Path chr = seqSil;
        // fondo de base de la escena
        boolean bgFirst = k <= 1;                    // balde y pincel empiezan con el fondo puesto
        c.drawBitmap(bgFirst ? seqBg : seqChk, 0, 0, seqPaint);
        if (k == 0) {
            // BALDE: un toque y el fondo se va como una onda, sin tocar al chico
            float tx = w * .14f, ty = h * .88f;
            float grow = pf < .25f ? 0f : ease((pf - .25f) / .75f);
            if (grow > 0f) {
                c.save();
                Path clip = new Path();
                clip.addCircle(tx, ty, grow * Math.max(w, h) * 1.3f, Path.Direction.CW);
                c.clipPath(clip);
                c.drawBitmap(seqChk, 0, 0, seqPaint);
                c.restore();
            }
            c.drawBitmap(seqChr, 0, 0, seqPaint);
            if (pf < 1f) {
                float press = pf < .25f ? pf / .25f : 1f;
                c.drawCircle(tx, ty, h * .045f * (1.4f - press * .4f), finger);
                c.drawCircle(tx, ty, h * .09f * press, ring);
            }
        } else if (k == 1 || k == 2 || k == 3) {
            Path route = seqRoute(k, w, h);
            PathMeasure pm = new PathMeasure(route, false);
            float len = pm.getLength(), drawn = pf * len;
            Path reveal = new Path();
            float[] pos = new float[2];
            for (float d = 0; d <= drawn; d += br * .35f) {
                pm.getPosTan(d, pos, null);
                reveal.addCircle(pos[0], pos[1], br, Path.Direction.CW);
            }
            if (k == 2) {
                // una mancha suelta del fondo pegada al hombro: el borrador la quita (borra todo)
                c.drawBitmap(seqChr, 0, 0, seqPaint);
                Paint m = new Paint(Paint.ANTI_ALIAS_FLAG);
                m.setColor(0xFF9FB3CF);
                c.save();
                if (drawn > 0) c.clipOutPath(reveal);
                c.drawCircle(w * .84f, h * .63f, h * .05f, m);
                c.drawCircle(w * .80f, h * .66f, h * .025f, m);
                c.restore();
            } else {
                Bitmap under = k == 1 ? seqChk : seqBg;   // pincel: aparece la transparencia; restaurar: vuelve el fondo
                if (drawn > 0) {
                    c.save();
                    c.clipPath(reveal);
                    c.clipOutPath(chr);   // nunca dentro del personaje
                    c.drawBitmap(under, 0, 0, seqPaint);
                    c.restore();
                }
                c.drawBitmap(seqChr, 0, 0, seqPaint);
            }
            if (pf < 1f && drawn > 0) {
                pm.getPosTan(drawn, pos, null);
                c.drawCircle(pos[0], pos[1], br, ring);
                c.drawCircle(pos[0], pos[1], h * .03f, finger);
            }
        } else {
            // ESCOBA: puntitos sueltos alrededor que se van con una pasada
            c.drawBitmap(seqChr, 0, 0, seqPaint);
            Paint d = new Paint(Paint.ANTI_ALIAS_FLAG);
            int alpha = (int) (255 * Math.max(0f, 1f - ease((pf - .3f) / .5f)));
            float[][] specks = {{.08f, .30f}, {.16f, .62f}, {.90f, .28f}, {.86f, .52f}, {.22f, .10f}, {.76f, .08f}, {.06f, .80f}, {.93f, .86f}};
            for (int i = 0; i < specks.length; i++) {
                d.setColor((i % 2 == 0 ? 0x00FFFFFF : 0x009FB3CF) | (alpha << 24));
                c.drawCircle(w * specks[i][0], h * specks[i][1], h * (.012f + .008f * (i % 3)), d);
            }
            if (pf < .85f) {
                float bx = w * (.05f + .9f * ease(pf / .85f)), by = h * .5f + (float) Math.sin(pf * 12) * h * .05f;
                drawIcon(c, SEQ_ICONS[4], bx - h * .07f, by - h * .07f, h * .14f, 0xFFFFFFFF);
            }
        }
        // icono de la herramienta de esta escena + 5 puntitos de avance (sin texto)
        Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
        badge.setColor(0xCC1F2230);
        float bs = h * .16f;
        c.drawRoundRect(new RectF(h * .03f, h * .03f, h * .03f + bs, h * .03f + bs), bs * .25f, bs * .25f, badge);
        drawIcon(c, SEQ_ICONS[k], h * .03f + bs * .14f, h * .03f + bs * .14f, bs * .72f, 0xFFFFFFFF);
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        for (int i = 0; i < 5; i++) {
            dot.setColor(i == k ? 0xFFFFFFFF : 0x66FFFFFF);
            c.drawCircle(w / 2f + (i - 2) * h * .05f, h * .95f, h * (i == k ? .014f : .01f), dot);
        }
    }

    private void drawIcon(Canvas c, int res, float x, float y, float s, int tint) {
        try {
            android.graphics.drawable.Drawable d = getContext().getDrawable(res);
            if (d == null) return;
            d = d.mutate();
            d.setTint(tint);
            d.setBounds((int) x, (int) y, (int) (x + s), (int) (y + s));
            d.draw(c);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (before == null || after == null) return;
        float w = getWidth(), h = getHeight();
        if (mode == CanvasView.MODE_BGERASE && seqBg != null && seqChr != null && seqChk != null && seqSil != null) {
            drawBgSeq(c, w, h);
            c.drawRect(new RectF(1, 1, w - 1, h - 1), frame);
            return;
        }
        float p = Math.min(1f, t); // lo que pasa despues de 1 es la pausa con el resultado
        c.drawBitmap(before, 0, 0, null);

        switch (kind()) {
            case KIND_TAP: {
                float[] tp = tapPoint(w, h);
                float grow = p < 0.3f ? 0f : (p - 0.3f) / 0.7f;
                if (grow > 0f) {
                    Path clip = new Path();
                    clip.addCircle(tp[0], tp[1], grow * Math.max(w, h) * 1.2f, Path.Direction.CW);
                    c.save();
                    c.clipPath(clip);
                    c.drawBitmap(after, 0, 0, null);
                    c.restore();
                }
                if (t < 1f) {
                    float press = p < 0.3f ? p / 0.3f : 1f;
                    c.drawCircle(tp[0], tp[1], h * 0.05f * (1.4f - press * 0.4f), finger);
                    c.drawCircle(tp[0], tp[1], h * 0.09f * press, ring);
                }
                break;
            }
            case KIND_TRACE: {
                Path route = new Path();
                route.addCircle(w * 0.5f, h * 0.33f, h * 0.26f, Path.Direction.CW);
                PathMeasure pm = new PathMeasure(route, false);
                float len = pm.getLength();
                float drawn = Math.min(1f, p / 0.75f) * len;
                Path part = new Path();
                pm.getSegment(0, drawn, part, true);
                Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
                g.setStyle(Paint.Style.STROKE);
                g.setColor(0xFF32D74B);
                g.setStrokeWidth(h * 0.025f);
                if (p >= 0.8f) {
                    c.drawBitmap(after, 0, 0, null);
                } else {
                    c.drawPath(part, g);
                    float[] pos = new float[2];
                    pm.getPosTan(drawn, pos, null);
                    c.drawCircle(pos[0], pos[1], h * 0.045f, finger);
                }
                break;
            }
            case KIND_POINTS:
                drawPoints(c, w, h, p);
                break;
            case KIND_PAN: {
                // la mano arrastra el dibujo: se mueve junto con el dedo
                float e = p < 0.15f ? 0f : Math.min(1f, (p - 0.15f) / 0.6f);
                e = e * e * (3f - 2f * e);
                float dx = -w * 0.22f * e, dy = -h * 0.1f * e;
                c.drawColor(0xFF2A2A30);
                c.save();
                c.translate(dx, dy);
                c.drawBitmap(before, 0, 0, null);
                c.restore();
                if (t < 1f) {
                    float fx = w * 0.62f + dx, fy = h * 0.55f + dy;
                    c.drawCircle(fx, fy, h * 0.05f, finger);
                    c.drawCircle(fx, fy, h * 0.08f, ring);
                }
                break;
            }
            case KIND_FADE: {
                Paint a = new Paint();
                a.setAlpha((int) (255 * Math.max(0f, Math.min(1f, (p - 0.35f) / 0.4f))));
                c.drawBitmap(after, 0, 0, a);
                if (t < 1f && p < 0.5f) {
                    float fx = w * (0.4f + p * 0.3f), fy = h * 0.5f;
                    c.drawCircle(fx, fy, h * 0.045f, finger);
                }
                break;
            }
            case KIND_BLUR:
                drawBlurDemo(c, w, h, p);
                break;
            case KIND_LIQUIFY:
                drawLiquifyDemo(c, w, h, p);
                break;
            case KIND_SMUDGE:
                drawSmudgeDemo(c, w, h, p);
                break;
            default: {
                // pincel: por donde pasa el dedo aparece el resultado
                Path route = route(w, h);
                PathMeasure pm = new PathMeasure(route, false);
                float len = pm.getLength();
                float drawn = p * len;
                float brush = h * 0.13f;
                Path reveal = new Path();
                float[] pos = new float[2];
                for (float d = 0; d <= drawn; d += brush * 0.35f) {
                    pm.getPosTan(d, pos, null);
                    reveal.addCircle(pos[0], pos[1], brush, Path.Direction.CW);
                }
                if (t >= 1f) {
                    c.drawBitmap(after, 0, 0, null);
                } else if (drawn > 0) {
                    c.save();
                    c.clipPath(reveal);
                    c.drawBitmap(after, 0, 0, null);
                    c.restore();
                    pm.getPosTan(drawn, pos, null);
                    c.drawCircle(pos[0], pos[1], brush, ring);
                    c.drawCircle(pos[0], pos[1], h * 0.035f, finger);
                }
                break;
            }
        }
        c.drawRect(new RectF(1, 1, w - 1, h - 1), frame);
    }

    private final Paint shapeLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeGuide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * Curva y Polilinea: el dedo pone 4 puntos, la linea aparece entre ellos,
     * despues arrastra un punto para acomodarla y toca el check.
     */
    private void drawPoints(Canvas c, float w, float h, float p) {
        boolean curve = mode == CanvasView.MODE_CURVE;
        float[][] pts = {{0.14f, 0.78f}, {0.36f, 0.26f}, {0.62f, 0.64f}, {0.86f, 0.24f}};
        // punto 3 se arrastra hacia abajo entre 0.5 y 0.72
        float drag = p < 0.5f ? 0f : Math.min(1f, (p - 0.5f) / 0.22f);
        drag = drag * drag * (3f - 2f * drag);
        float[][] q = new float[4][2];
        for (int i = 0; i < 4; i++) {
            q[i][0] = pts[i][0] * w;
            q[i][1] = pts[i][1] * h;
        }
        q[2][0] -= w * 0.06f * drag;
        q[2][1] += h * 0.2f * drag;
        int shown = Math.min(4, (int) (p / 0.11f) + 1);
        boolean done = p >= 0.86f;

        shapeLine.setStyle(Paint.Style.STROKE);
        shapeLine.setStrokeCap(Paint.Cap.ROUND);
        shapeLine.setStrokeJoin(Paint.Join.ROUND);
        shapeLine.setColor(0xFF6A4CE0);
        shapeLine.setStrokeWidth(h * 0.035f);
        if (shown >= 2) {
            Path path = new Path();
            path.moveTo(q[0][0], q[0][1]);
            for (int i = 0; i < shown - 1; i++) {
                if (curve && shown >= 3) {
                    float[] p0 = q[Math.max(0, i - 1)], p1 = q[i], p2 = q[i + 1], p3 = q[Math.min(shown - 1, i + 2)];
                    path.cubicTo(p1[0] + (p2[0] - p0[0]) / 6f, p1[1] + (p2[1] - p0[1]) / 6f,
                            p2[0] - (p3[0] - p1[0]) / 6f, p2[1] - (p3[1] - p1[1]) / 6f, p2[0], p2[1]);
                } else {
                    path.lineTo(q[i + 1][0], q[i + 1][1]);
                }
            }
            c.drawPath(path, shapeLine);
            if (curve && !done && shown >= 3) {
                shapeGuide.setStyle(Paint.Style.STROKE);
                shapeGuide.setColor(0xAA000000);
                shapeGuide.setStrokeWidth(Math.max(1f, h * 0.006f));
                shapeGuide.setPathEffect(new android.graphics.DashPathEffect(new float[]{h * 0.03f, h * 0.02f}, 0));
                Path g = new Path();
                g.moveTo(q[0][0], q[0][1]);
                for (int i = 1; i < shown; i++) g.lineTo(q[i][0], q[i][1]);
                c.drawPath(g, shapeGuide);
            }
        }
        if (!done) {
            float r = h * 0.032f;
            int sel = drag > 0f ? 2 : shown - 1;
            for (int i = 0; i < shown; i++) {
                dot.setStyle(Paint.Style.FILL);
                dot.setColor(i == sel ? 0xFFE53935 : 0xFF1E6FE0);
                c.drawCircle(q[i][0], q[i][1], r, dot);
                dot.setStyle(Paint.Style.STROKE);
                dot.setStrokeWidth(Math.max(1.5f, h * 0.008f));
                dot.setColor(0xFFFFFFFF);
                c.drawCircle(q[i][0], q[i][1], r, dot);
            }
            // boton check abajo a la derecha
            if (p >= 0.72f) {
                float cx = w * 0.86f, cy = h * 0.86f, cr = h * 0.07f;
                dot.setStyle(Paint.Style.FILL);
                dot.setColor(0xFF2F6BD8);
                c.drawCircle(cx, cy, cr, dot);
                dot.setStyle(Paint.Style.STROKE);
                dot.setColor(0xFFFFFFFF);
                dot.setStrokeWidth(h * 0.012f);
                Path ck = new Path();
                ck.moveTo(cx - cr * 0.45f, cy);
                ck.lineTo(cx - cr * 0.1f, cy + cr * 0.35f);
                ck.lineTo(cx + cr * 0.5f, cy - cr * 0.35f);
                c.drawPath(ck, dot);
            }
            // el dedo
            float fx, fy;
            if (p < 0.5f) {
                int k = Math.min(3, (int) (p / 0.11f));
                fx = q[k][0];
                fy = q[k][1];
            } else if (p < 0.72f) {
                fx = q[2][0];
                fy = q[2][1];
            } else {
                fx = w * 0.86f;
                fy = h * 0.86f;
            }
            c.drawCircle(fx, fy, h * 0.045f, finger);
        }
    }
}
