package com.pacco.animecut.core;

import java.util.ArrayList;
import java.util.List;

/**
 * v8.32: dibujo ORIGINAL estilo anime/manhwa para las animaciones de ayuda (personaje propio,
 * sin copiar a nadie). Java puro: una "lista de dibujo" en coordenadas 0..1 que la app pinta con
 * Canvas (ToolArt) y las pruebas con Java2D (para ver como queda sin telefono).
 *
 * Personaje: chico de pelo negro azulado con mechones en punta y brillo de anillo, ojos grandes
 * con dos brillos, mejillas, camisa con cuello y chaqueta; linea negra de contorno.
 */
public final class ChibiArt {

    /** Una operacion: camino (MOVE/LINE/CUBIC/CLOSE) relleno o con linea. */
    public static final class Op {
        public final float[] path;      // codigos y coordenadas
        public final int color;
        public final float stroke;      // 0 = relleno; > 0 = ancho de linea (fraccion de la altura)
        public final int part;          // PART_* (para recortar: pelo, cara, cuerpo)
        Op(float[] path, int color, float stroke, int part) { this.path = path; this.color = color; this.stroke = stroke; this.part = part; }
    }

    public static final float MOVE = 0, LINE = 1, CUBIC = 2, CLOSE = 3;
    public static final int PART_BODY = 1, PART_HEAD = 2, PART_HAIR = 3, PART_FX = 4;

    static final int INK = 0xFF15131A, SKIN = 0xFFFBE0CF, SKIN_SH = 0xFFEDBFA8, BLUSH = 0x66FF8A8A,
            HAIR = 0xFF2A2F4A, HAIR_SH = 0xFF1B1E33, HAIR_HI = 0xFF5D6A9E, EYE_W = 0xFFFFFFFF,
            IRIS = 0xFF3D7BE0, IRIS_D = 0xFF1E3F8C, JACKET = 0xFF2E3A59, JACKET_SH = 0xFF222B44, MOUTH = 0xFF9E3B3B;

    private ChibiArt() { }

    private static final class B {
        final List<Float> f = new ArrayList<>();
        B m(float x, float y) { f.add(MOVE); f.add(x); f.add(y); return this; }
        B l(float x, float y) { f.add(LINE); f.add(x); f.add(y); return this; }
        B c(float x1, float y1, float x2, float y2, float x, float y) { f.add(CUBIC); f.add(x1); f.add(y1); f.add(x2); f.add(y2); f.add(x); f.add(y); return this; }
        B z() { f.add(CLOSE); return this; }
        float[] a() { float[] r = new float[f.size()]; for (int i = 0; i < r.length; i++) r[i] = f.get(i); return r; }
    }

    static B ellipse(float cx, float cy, float rx, float ry) {
        float k = 0.5523f;
        return new B().m(cx + rx, cy)
                .c(cx + rx, cy + ry * k, cx + rx * k, cy + ry, cx, cy + ry)
                .c(cx - rx * k, cy + ry, cx - rx, cy + ry * k, cx - rx, cy)
                .c(cx - rx, cy - ry * k, cx - rx * k, cy - ry, cx, cy - ry)
                .c(cx + rx * k, cy - ry, cx + rx, cy - ry * k, cx + rx, cy).z();
    }

    /** El personaje completo (busto). shirt = color de la camisa. */
    public static List<Op> character(int shirt) {
        List<Op> o = new ArrayList<>();
        float LW = 0.012f;
        // ---- cuerpo: chaqueta + camisa con cuello ----
        float[] body = new B().m(0.18f, 1.02f).c(0.18f, 0.82f, 0.30f, 0.70f, 0.42f, 0.66f).l(0.58f, 0.66f)
                .c(0.70f, 0.70f, 0.82f, 0.82f, 0.82f, 1.02f).z().a();
        o.add(new Op(body, JACKET, 0, PART_BODY));
        o.add(new Op(new B().m(0.62f, 0.70f).c(0.74f, 0.76f, 0.80f, 0.88f, 0.80f, 1.02f).l(0.70f, 1.02f).c(0.70f, 0.88f, 0.66f, 0.78f, 0.60f, 0.72f).z().a(), JACKET_SH, 0, PART_BODY));
        float[] shirtV = new B().m(0.42f, 0.66f).l(0.50f, 0.86f).l(0.58f, 0.66f).z().a();
        o.add(new Op(shirtV, shirt, 0, PART_BODY));
        o.add(new Op(new B().m(0.42f, 0.66f).l(0.47f, 0.75f).l(0.40f, 0.72f).z().a(), 0xFFFFFFFF, 0, PART_BODY));
        o.add(new Op(new B().m(0.58f, 0.66f).l(0.53f, 0.75f).l(0.60f, 0.72f).z().a(), 0xFFFFFFFF, 0, PART_BODY));
        o.add(new Op(body, INK, LW, PART_BODY));
        o.add(new Op(shirtV, INK, LW * 0.7f, PART_BODY));
        // ---- cuello y cara (barbilla en punta, estilo anime) ----
        o.add(new Op(new B().m(0.45f, 0.58f).l(0.55f, 0.58f).l(0.56f, 0.68f).l(0.44f, 0.68f).z().a(), SKIN_SH, 0, PART_HEAD));
        float[] face = new B().m(0.30f, 0.34f).c(0.30f, 0.50f, 0.38f, 0.58f, 0.50f, 0.635f)
                .c(0.62f, 0.58f, 0.70f, 0.50f, 0.70f, 0.34f).c(0.70f, 0.20f, 0.30f, 0.20f, 0.30f, 0.34f).z().a();
        o.add(new Op(face, SKIN, 0, PART_HEAD));
        o.add(new Op(face, INK, LW, PART_HEAD));
        // orejas
        float[] earL = new B().m(0.305f, 0.38f).c(0.26f, 0.37f, 0.26f, 0.46f, 0.315f, 0.46f).z().a();
        float[] earR = new B().m(0.695f, 0.38f).c(0.74f, 0.37f, 0.74f, 0.46f, 0.685f, 0.46f).z().a();
        o.add(new Op(earL, SKIN, 0, PART_HEAD)); o.add(new Op(earL, INK, LW * 0.8f, PART_HEAD));
        o.add(new Op(earR, SKIN, 0, PART_HEAD)); o.add(new Op(earR, INK, LW * 0.8f, PART_HEAD));
        // ojos grandes: blanco, iris, pupila, 2 brillos, pestana
        for (int s = -1; s <= 1; s += 2) {
            float ex = 0.50f + s * 0.095f, ey = 0.43f;
            o.add(new Op(ellipse(ex, ey, 0.052f, 0.06f).a(), EYE_W, 0, PART_HEAD));
            o.add(new Op(ellipse(ex, ey + 0.006f, 0.038f, 0.052f).a(), IRIS, 0, PART_HEAD));
            o.add(new Op(ellipse(ex, ey + 0.016f, 0.026f, 0.036f).a(), IRIS_D, 0, PART_HEAD));
            o.add(new Op(ellipse(ex - s * 0.012f, ey - 0.018f, 0.013f, 0.016f).a(), 0xFFFFFFFF, 0, PART_HEAD));
            o.add(new Op(ellipse(ex + s * 0.016f, ey + 0.028f, 0.006f, 0.007f).a(), 0xFFFFFFFF, 0, PART_HEAD));
            o.add(new Op(new B().m(ex - 0.06f, ey - 0.045f).c(ex - 0.03f, ey - 0.075f, ex + 0.03f, ey - 0.075f, ex + 0.062f, ey - 0.04f).a(), INK, LW * 1.3f, PART_HEAD));
            o.add(new Op(ellipse(ex + s * 0.01f, ey + 0.085f, 0.03f, 0.012f).a(), BLUSH, 0, PART_HEAD));
        }
        // nariz y boca
        o.add(new Op(new B().m(0.505f, 0.50f).l(0.495f, 0.515f).a(), INK, LW * 0.6f, PART_HEAD));
        o.add(new Op(new B().m(0.47f, 0.555f).c(0.49f, 0.575f, 0.51f, 0.575f, 0.53f, 0.555f).z().a(), MOUTH, 0, PART_HEAD));
        o.add(new Op(new B().m(0.47f, 0.555f).c(0.49f, 0.575f, 0.51f, 0.575f, 0.53f, 0.555f).a(), INK, LW * 0.6f, PART_HEAD));
        // ---- pelo: mechones en punta, sombra y brillo de anillo ----
        float[] hair = new B().m(0.27f, 0.42f).c(0.22f, 0.22f, 0.34f, 0.08f, 0.50f, 0.075f)
                .c(0.66f, 0.08f, 0.79f, 0.20f, 0.74f, 0.44f)
                .l(0.70f, 0.33f).l(0.66f, 0.40f).l(0.63f, 0.27f).l(0.585f, 0.37f).l(0.55f, 0.26f)
                .l(0.50f, 0.39f).l(0.465f, 0.26f).l(0.42f, 0.36f).l(0.39f, 0.26f).l(0.35f, 0.40f).l(0.32f, 0.31f).z().a();
        o.add(new Op(hair, HAIR, 0, PART_HAIR));
        o.add(new Op(new B().m(0.62f, 0.12f).c(0.72f, 0.16f, 0.77f, 0.26f, 0.74f, 0.44f).l(0.70f, 0.33f).l(0.66f, 0.40f).l(0.63f, 0.27f).c(0.66f, 0.22f, 0.66f, 0.16f, 0.62f, 0.12f).z().a(), HAIR_SH, 0, PART_HAIR));
        o.add(new Op(new B().m(0.36f, 0.16f).c(0.44f, 0.12f, 0.56f, 0.12f, 0.64f, 0.16f).c(0.56f, 0.15f, 0.44f, 0.15f, 0.36f, 0.19f).z().a(), HAIR_HI, 0, PART_HAIR));
        o.add(new Op(hair, INK, LW, PART_HAIR));
        // mechon de arriba (ahoge) y mechones a los lados de la cara: puntas abiertas
        float[] ahoge = new B().m(0.50f, 0.085f).c(0.50f, 0.03f, 0.57f, -0.005f, 0.63f, 0.02f)
                .c(0.58f, 0.03f, 0.55f, 0.055f, 0.545f, 0.085f).z().a();
        o.add(new Op(ahoge, HAIR, 0, PART_HAIR));
        o.add(new Op(ahoge, INK, LW * 0.8f, PART_HAIR));
        float[] sideL = new B().m(0.285f, 0.30f).c(0.27f, 0.40f, 0.28f, 0.50f, 0.30f, 0.56f).c(0.31f, 0.48f, 0.32f, 0.40f, 0.33f, 0.33f).z().a();
        float[] sideR = new B().m(0.715f, 0.30f).c(0.73f, 0.40f, 0.72f, 0.50f, 0.70f, 0.56f).c(0.69f, 0.48f, 0.68f, 0.40f, 0.67f, 0.33f).z().a();
        o.add(new Op(sideL, HAIR, 0, PART_HAIR)); o.add(new Op(sideL, INK, LW * 0.8f, PART_HAIR));
        o.add(new Op(sideR, HAIR, 0, PART_HAIR)); o.add(new Op(sideR, INK, LW * 0.8f, PART_HAIR));
        return o;
    }

    /** Fondo de manhwa: cielo con degradado en bandas, sol y nubes, edificios a lo lejos. */
    public static List<Op> scenery() {
        List<Op> o = new ArrayList<>();
        int[] sky = {0xFF8EC5FF, 0xFFA3D0FF, 0xFFB9DCFF, 0xFFCFE8FF, 0xFFE3F1FF};
        for (int k = 0; k < sky.length; k++) {
            float y0 = k / (float) sky.length - 0.01f, y1 = (k + 1) / (float) sky.length + 0.01f;
            o.add(new Op(new B().m(-0.05f, y0).l(1.05f, y0).l(1.05f, y1).l(-0.05f, y1).z().a(), sky[k], 0, PART_FX));
        }
        o.add(new Op(ellipse(0.86f, 0.14f, 0.07f, 0.07f).a(), 0xFFFFF3B0, 0, PART_FX));
        float[][] clouds = {{0.14f, 0.18f}, {0.80f, 0.36f}};
        for (float[] cl : clouds) {
            o.add(new Op(ellipse(cl[0], cl[1], 0.09f, 0.035f).a(), 0xEEFFFFFF, 0, PART_FX));
            o.add(new Op(ellipse(cl[0] + 0.05f, cl[1] - 0.02f, 0.06f, 0.035f).a(), 0xEEFFFFFF, 0, PART_FX));
        }
        float[] bx = {0.00f, 0.10f, 0.18f, 0.80f, 0.88f, 0.95f};
        float[] bh = {0.55f, 0.62f, 0.50f, 0.58f, 0.48f, 0.60f};
        for (int k = 0; k < bx.length; k++)
            o.add(new Op(new B().m(bx[k], 1.02f).l(bx[k], bh[k]).l(bx[k] + 0.09f, bh[k]).l(bx[k] + 0.09f, 1.02f).z().a(), 0xFF9FB3CF, 0, PART_FX));
        return o;
    }
}
