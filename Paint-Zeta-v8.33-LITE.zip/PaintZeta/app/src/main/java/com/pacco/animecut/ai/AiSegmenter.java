package com.pacco.animecut.ai;

import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Collections;
import java.util.Map;

/**
 * v8.33: corre ISNet-Anime con ONNX Runtime (CPU), 100 % en el telefono. Sin red.
 *  - La sesion se crea desde el ARCHIVO (no se copia el modelo de 168 MB al heap de Java).
 *  - Se reutiliza mientras la app la tenga; close() la suelta.
 *  - Buffers directos (memoria nativa) para la entrada.
 *  - cancel() corta la inferencia en curso (RunOptions.setTerminate).
 *  - Si la libreria nativa no existe para el procesador, available() da false con un motivo:
 *    la app no se cierra.
 * Lo usan la app y las pruebas de PC con el mismo API (ai.onnxruntime 1.20).
 */
public final class AiSegmenter implements AutoCloseable {
    private static String loadError;
    private static Boolean ok;

    /** true si ONNX Runtime cargo en este aparato. */
    public static synchronized boolean available() {
        if (ok != null) return ok;
        try {
            OrtEnvironment.getEnvironment();
            ok = true;
        } catch (Throwable t) {   // UnsatisfiedLinkError, NoClassDefFoundError...
            loadError = t.getClass().getSimpleName() + ": " + t.getMessage();
            ok = false;
        }
        return ok;
    }

    public static String loadError() { return loadError; }

    private final OrtEnvironment env;
    private final OrtSession session;
    private final String inputName;
    private final int size;
    private volatile OrtSession.RunOptions running;
    private volatile boolean cancelled;
    private FloatBuffer input;
    public long lastMs;

    /** @param threads hilos de calculo (1..4 recomendado en telefonos) */
    public AiSegmenter(File model, int threads) throws OrtException {
        env = OrtEnvironment.getEnvironment();
        OrtSession.SessionOptions so = new OrtSession.SessionOptions();
        try {
            so.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
            so.setIntraOpNumThreads(Math.max(1, threads));
            so.setInterOpNumThreads(1);
            // menos memoria retenida entre corridas (telefonos de 3-4 GB)
            so.setCPUArenaAllocator(false);
            so.setMemoryPatternOptimization(false);
            session = env.createSession(model.getAbsolutePath(), so);
        } finally {
            so.close();
        }
        Map<String, NodeInfo> in = session.getInputInfo();
        inputName = in.keySet().iterator().next();
        long[] shape = ((TensorInfo) in.get(inputName).getInfo()).getShape();
        // [1, 3, S, S]; si el modelo es de tamano libre (-1) se usa 1024
        int s = shape.length == 4 && shape[2] > 0 ? (int) shape[2] : 1024;
        size = s;
    }

    /** Lado de entrada que exige el modelo (1024 para el archivo original). */
    public int inputSize() { return size; }

    /** Buffer de entrada reutilizable (3*S*S floats, memoria nativa). */
    public synchronized FloatBuffer inputBuffer() {
        if (input == null) {
            input = ByteBuffer.allocateDirect(3 * size * size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        }
        input.clear();
        return input;
    }

    /**
     * Corre el modelo. Devuelve S*S valores 0..1 (ya con sigmoide) o null si se cancelo.
     * Se copia la salida a un buffer propio antes de cerrar el resultado.
     */
    public FloatBuffer run(FloatBuffer in) throws OrtException {
        cancelled = false;
        long t0 = System.nanoTime();
        OrtSession.RunOptions ro = new OrtSession.RunOptions();
        running = ro;
        try (OnnxTensor t = OnnxTensor.createTensor(env, in, new long[]{1, 3, size, size});
             OrtSession.Result r = session.run(Collections.singletonMap(inputName, t), ro)) {
            if (cancelled) return null;
            FloatBuffer out = ((OnnxTensor) r.get(0)).getFloatBuffer();
            FloatBuffer copy = FloatBuffer.allocate(size * size);
            out.rewind();
            if (out.remaining() < size * size) throw new IllegalStateException("salida corta");
            out.limit(size * size);
            copy.put(out);
            copy.rewind();
            lastMs = (System.nanoTime() - t0) / 1_000_000L;
            return copy;
        } catch (OrtException e) {
            if (cancelled) return null;
            throw e;
        } finally {
            running = null;
            ro.close();
        }
    }

    /** Corta la inferencia en curso (desde otro hilo). */
    public void cancel() {
        cancelled = true;
        OrtSession.RunOptions ro = running;
        if (ro != null) {
            try { ro.setTerminate(true); } catch (Throwable ignored) { }
        }
    }

    @Override
    public synchronized void close() {
        try { session.close(); } catch (Throwable ignored) { }
        input = null;
    }
}
