package com.pacco.animecut.core;

/**
 * v8.33: "Sombra automatica" por direccion de luz (sin IA, Java puro). Da una base de sombra
 * tipo anime (cel) que despues se corrige con la Brocha / Goma en su propia capa:
 *  - se toma lo visible de la capa (alfa >= 50 %);
 *  - "por partes": cada zona encerrada por la linea negra (cara, pelo, ropa) se sombrea sola, del
 *    lado CONTRARIO a la luz: un pixel queda en sombra si al moverse hacia donde va la luz
 *    (a 1/2 y 1 ancho) sale de su zona;
 *  - borde suave de 1 px; nunca sale de lo visible.
 * Devuelve el alfa de la sombra (0..255) del tamano de la capa.
 */
public final class AutoShade {
    private AutoShade() { }

    /**
     * @param lx,ly  direccion en la que VIAJA la luz (de la luz hacia el dibujo), p. ej. (1,1) =
     *               luz arriba a la izquierda
     * @param width  ancho de la franja de sombra en pixeles
     * @param lines  linea del dibujo (!= 0 = linea) o null para no separar por partes
     */
    public static byte[] shade(int[] px, int w, int h, float lx, float ly, int width, byte[] lines) {
        int n = w * h;
        float len = (float) Math.hypot(lx, ly);
        if (len < 1e-3f) { lx = 1; ly = 1; len = (float) Math.sqrt(2); }
        lx /= len; ly /= len;
        width = Math.max(1, width);
        int[] reg = new int[n];
        // zonas: visible y no linea, 4-conexas
        int[] q = new int[n];
        int next = 0;
        for (int s = 0; s < n; s++) {
            if (reg[s] != 0 || (px[s] >>> 24) < 128 || (lines != null && lines[s] != 0)) continue;
            next++;
            int qh = 0, qt = 0;
            q[qt++] = s; reg[s] = next;
            while (qh < qt) {
                int i = q[qh++];
                int x = i % w, y = i / w;
                for (int k = 0; k < 4; k++) {
                    int xx = x + (k == 0 ? 1 : k == 1 ? -1 : 0), yy = y + (k == 2 ? 1 : k == 3 ? -1 : 0);
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                    int j = yy * w + xx;
                    if (reg[j] != 0 || (px[j] >>> 24) < 128 || (lines != null && lines[j] != 0)) continue;
                    reg[j] = next;
                    q[qt++] = j;
                }
            }
        }
        int[] area = new int[next + 1];
        for (int i = 0; i < n; i++) if (reg[i] > 0) area[reg[i]]++;
        byte[] out = new byte[n];
        int dx1 = Math.round(lx * width), dy1 = Math.round(ly * width);
        int dx2 = Math.round(lx * width * 0.5f), dy2 = Math.round(ly * width * 0.5f);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int r = reg[i];
                if (r == 0) continue;
                if (outside(px, reg, area, w, h, x + dx1, y + dy1, r) || outside(px, reg, area, w, h, x + dx2, y + dy2, r)) out[i] = (byte) 255;
            }
        // linea entre dos zonas en sombra: tambien (que no quede un filo claro)
        if (lines != null) {
            for (int y = 1; y < h - 1; y++)
                for (int x = 1; x < w - 1; x++) {
                    int i = y * w + x;
                    if (lines[i] == 0 || (px[i] >>> 24) < 128) continue;
                    int c = 0;
                    if (out[i - 1] != 0) c++; if (out[i + 1] != 0) c++; if (out[i - w] != 0) c++; if (out[i + w] != 0) c++;
                    if (c >= 2) out[i] = (byte) 255;
                }
        }
        // borde suave de 1 px y siempre dentro de lo visible
        byte[] soft = new byte[n];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int s = 0, cnt = 0;
                for (int yy = Math.max(0, y - 1); yy <= Math.min(h - 1, y + 1); yy++)
                    for (int xx = Math.max(0, x - 1); xx <= Math.min(w - 1, x + 1); xx++) { s += out[yy * w + xx] & 0xFF; cnt++; }
                int i = y * w + x;
                int v = s / cnt;
                soft[i] = (byte) (v * (px[i] >>> 24) / 255);
            }
        return soft;
    }

    /**
     * true si el punto ya no es de la zona r: fuera del dibujo, o en OTRA zona grande (pelo junto
     * a la cara). Caer sobre una linea o en un detalle chico (ojo, boca dentro de la cara) no
     * decide: asi no salen rayas de sombra junto a cada detalle.
     */
    private static boolean outside(int[] px, int[] reg, int[] area, int w, int h, int x, int y, int r) {
        if (x < 0 || y < 0 || x >= w || y >= h) return true;
        int i = y * w + x;
        if ((px[i] >>> 24) < 128) return true;
        int o = reg[i];
        if (o == 0 || o == r) return false;
        return area[o] * 10L >= area[r];
    }
}
