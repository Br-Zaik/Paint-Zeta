package com.pacco.animecut.ai;

import java.nio.FloatBuffer;

/**
 * v8.33: entrada del modelo ISNet-Anime (SkyTNT/anime-segmentation), igual que su inference.py:
 *  - RGB / 255 (sin restar media);
 *  - letterbox: se escala SIN deformar hasta que el lado mayor mide S y el resto queda en 0
 *    (negro), centrado con (S - lado) / 2 truncado, como "ph // 2" del original;
 *  - tensor [1, 3, S, S] en orden de canales R, G, B.
 * La salida (ya con sigmoide) se recorta con el mismo desplazamiento y se lleva al tamano real.
 *
 * Diferencia documentada: al REDUCIR se promedia por area (como cv2.INTER_AREA) en vez del
 * bilineal sin filtro del original; asi las tramas del manga no hacen moire. Al AMPLIAR se usa
 * el bilineal de cv2 (centros de pixel). Lo transparente entra como si estuviera sobre blanco.
 * Java puro: lo usan la app y las pruebas de PC.
 */
public final class AiPrep {
    /** Lado del cuadrado de entrada. */
    public final int S;
    /** Zona de la imagen que se mira (en pixeles de la capa). */
    public final int cropX, cropY, cropW, cropH;
    /** Tamano escalado dentro del cuadrado y su desplazamiento. */
    public final int w, h, padX, padY;

    private AiPrep(int S, int cx, int cy, int cw, int ch) {
        this.S = S;
        cropX = cx; cropY = cy; cropW = cw; cropH = ch;
        int ww, hh;
        if (ch > cw) { hh = S; ww = (int) ((long) S * cw / ch); }
        else { ww = S; hh = (int) ((long) S * ch / cw); }
        w = Math.max(1, ww);
        h = Math.max(1, hh);
        padX = (S - w) / 2;
        padY = (S - h) / 2;
    }

    public static AiPrep plan(int S, int cropX, int cropY, int cropW, int cropH) {
        if (S < 16 || cropW < 1 || cropH < 1) throw new IllegalArgumentException("tamano");
        return new AiPrep(S, cropX, cropY, cropW, cropH);
    }

    /** Llena out (3*S*S floats, CHW) desde px (ARGB, ancho stride). blur=1 suaviza tramas (manga). */
    public void fill(int[] px, int stride, FloatBuffer out, boolean blur) {
        int n = S * S;
        float[] r = new float[w * h], g = new float[w * h], b = new float[w * h];
        resample(px, stride, r, g, b);
        if (blur) { box3(r); box3(g); box3(b); }
        out.clear();
        float[][] ch = {r, g, b};
        for (int c = 0; c < 3; c++) {
            float[] src = ch[c];
            for (int y = 0; y < S; y++) {
                int sy = y - padY;
                for (int x = 0; x < S; x++) {
                    int sx = x - padX;
                    float v = (sy >= 0 && sy < h && sx >= 0 && sx < w) ? src[sy * w + sx] : 0f;
                    out.put(v);
                }
            }
        }
        out.rewind();
        if (out.remaining() != 3 * n) throw new IllegalStateException("buffer");
    }

    /** Color sobre blanco segun su alfa, en 0..1. */
    private static float comp(int c, int shift) {
        int a = c >>> 24;
        int v = (c >> shift) & 0xFF;
        if (a >= 255) return v / 255f;
        return (v * a + 255 * (255 - a)) / (255f * 255f);
    }

    private void resample(int[] px, int stride, float[] R, float[] G, float[] B) {
        boolean shrinkX = cropW >= w, shrinkY = cropH >= h;
        // separable: primero filas (x), despues columnas (y)
        float[] tr = new float[w * cropH], tg = new float[w * cropH], tb = new float[w * cropH];
        float fx = cropW / (float) w;
        for (int y = 0; y < cropH; y++) {
            int base = (cropY + y) * stride + cropX;
            int o = y * w;
            for (int x = 0; x < w; x++) {
                float sr = 0, sg = 0, sb = 0;
                if (shrinkX) {
                    float x0 = x * fx, x1 = x0 + fx, wsum = 0;
                    int i0 = (int) Math.floor(x0), i1 = Math.min(cropW, (int) Math.ceil(x1));
                    for (int i = i0; i < i1; i++) {
                        float wgt = Math.min(x1, i + 1) - Math.max(x0, i);
                        if (wgt <= 0) continue;
                        int c = px[base + i];
                        sr += wgt * comp(c, 16); sg += wgt * comp(c, 8); sb += wgt * comp(c, 0);
                        wsum += wgt;
                    }
                    sr /= wsum; sg /= wsum; sb /= wsum;
                } else {
                    float sx = (x + 0.5f) * fx - 0.5f;
                    int i0 = (int) Math.floor(sx);
                    float t = sx - i0;
                    int a0 = Math.max(0, Math.min(cropW - 1, i0)), a1 = Math.max(0, Math.min(cropW - 1, i0 + 1));
                    int c0 = px[base + a0], c1 = px[base + a1];
                    sr = comp(c0, 16) * (1 - t) + comp(c1, 16) * t;
                    sg = comp(c0, 8) * (1 - t) + comp(c1, 8) * t;
                    sb = comp(c0, 0) * (1 - t) + comp(c1, 0) * t;
                }
                tr[o + x] = sr; tg[o + x] = sg; tb[o + x] = sb;
            }
        }
        float fy = cropH / (float) h;
        for (int y = 0; y < h; y++) {
            int o = y * w;
            if (shrinkY) {
                float y0 = y * fy, y1 = y0 + fy;
                int j0 = (int) Math.floor(y0), j1 = Math.min(cropH, (int) Math.ceil(y1));
                for (int x = 0; x < w; x++) { R[o + x] = 0; G[o + x] = 0; B[o + x] = 0; }
                float wsum = 0;
                for (int j = j0; j < j1; j++) {
                    float wgt = Math.min(y1, j + 1) - Math.max(y0, j);
                    if (wgt <= 0) continue;
                    wsum += wgt;
                    int s = j * w;
                    for (int x = 0; x < w; x++) {
                        R[o + x] += wgt * tr[s + x]; G[o + x] += wgt * tg[s + x]; B[o + x] += wgt * tb[s + x];
                    }
                }
                for (int x = 0; x < w; x++) { R[o + x] /= wsum; G[o + x] /= wsum; B[o + x] /= wsum; }
            } else {
                float sy = (y + 0.5f) * fy - 0.5f;
                int j0 = (int) Math.floor(sy);
                float t = sy - j0;
                int a0 = Math.max(0, Math.min(cropH - 1, j0)) * w, a1 = Math.max(0, Math.min(cropH - 1, j0 + 1)) * w;
                for (int x = 0; x < w; x++) {
                    R[o + x] = tr[a0 + x] * (1 - t) + tr[a1 + x] * t;
                    G[o + x] = tg[a0 + x] * (1 - t) + tg[a1 + x] * t;
                    B[o + x] = tb[a0 + x] * (1 - t) + tb[a1 + x] * t;
                }
            }
        }
    }

    /** Promedio 3x3 (solo para la entrada de la IA en manga con trama). */
    private void box3(float[] a) {
        float[] t = new float[a.length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                float s = 0; int n = 0;
                for (int dx = -1; dx <= 1; dx++) { int xx = x + dx; if (xx >= 0 && xx < w) { s += a[y * w + xx]; n++; } }
                t[y * w + x] = s / n;
            }
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                float s = 0; int n = 0;
                for (int dy = -1; dy <= 1; dy++) { int yy = y + dy; if (yy >= 0 && yy < h) { s += t[yy * w + x]; n++; } }
                a[y * w + x] = s / n;
            }
    }

    /**
     * Recorta la salida del modelo (S*S, 0..1) a la zona sin relleno y la cuantiza a 0..255
     * (tamano w*h, todavia en la resolucion del modelo).
     */
    public byte[] cropOutput(FloatBuffer outSS) {
        byte[] m = new byte[w * h];
        for (int y = 0; y < h; y++) {
            int src = (y + padY) * S + padX;
            for (int x = 0; x < w; x++) {
                float v = outSS.get(src + x);
                if (!(v > 0f)) v = 0f;   // tambien NaN
                if (v > 1f) v = 1f;
                m[y * w + x] = (byte) Math.round(v * 255f);
            }
        }
        return m;
    }

    /** Media de saturacion (0..255) de la zona: casi 0 = blanco y negro / trama. */
    public static int meanSaturation(int[] px, int stride, int x0, int y0, int cw, int ch) {
        long s = 0, n = 0;
        int step = Math.max(1, (int) Math.sqrt((double) cw * ch / 250000.0));
        for (int y = y0; y < y0 + ch; y += step)
            for (int x = x0; x < x0 + cw; x += step) {
                int c = px[y * stride + x];
                if ((c >>> 24) < 128) continue;
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                s += Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
                n++;
            }
        return n == 0 ? 0 : (int) (s / n);
    }
}
