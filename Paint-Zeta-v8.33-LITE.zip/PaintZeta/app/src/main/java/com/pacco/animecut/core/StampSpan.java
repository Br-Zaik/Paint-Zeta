package com.pacco.animecut.core;

/**
 * v8.33: pinceles grandes sin raiz cuadrada por pixel. Para cada fila del circulo se calcula UNA
 * vez el tramo donde la cobertura es exactamente 1 (interior duro); solo los pixeles del anillo
 * del borde calculan su caida. El resultado es el MISMO que antes (no baja la calidad).
 */
public final class StampSpan {
    private StampSpan() { }

    /**
     * Medio ancho (en x, desde el centro) del tramo con cobertura 1 en la fila dy, o -1 si no hay.
     * Coincide con CanvasView.falloff: cobertura 1 si d <= min(br*hardness, br-0.5) y br >= 2.5.
     */
    public static float solid(float br, float hardness, float dy) {
        if (br < 2.5f) return -1f;
        float rin = Math.min(br * hardness, br - 0.5f);
        if (rin <= 0f) return -1f;
        float q = rin * rin - dy * dy;
        return q < 0f ? -1f : (float) Math.sqrt(q);
    }

    /** Medio ancho de la fila hasta donde la cobertura puede ser > 0 (radio br + 0.75). */
    public static float reach(float br, float dy) {
        float ro = br + 0.75f;
        float q = ro * ro - dy * dy;
        return q < 0f ? -1f : (float) Math.sqrt(q);
    }
}
