# Paint Zeta v8.33 — Recortar con IA (local y gratis) + arreglos de Balde, Separar, pinceles y color

## 1. Recortar con IA (nuevo, en Borrar fondo)

- **Boton nuevo** (icono de silueta con destellos, el primero y resaltado de la barra de Borrar fondo). No reemplaza al Balde, Pincel protegido, Borrador, Restaurar ni Escoba: siguen igual.
- **Modelo**: ISNet-Anime de SkyTNT (`isnetis.onnx`, Apache-2.0), corrido con **ONNX Runtime 1.20.0** (Microsoft, MIT) en el telefono.
  - Sin cuentas, sin pagos, sin API.
  - Tus imagenes **no salen del telefono**.
- **Descarga una sola vez (168 MB)**. Despues funciona **sin internet**.
  - Progreso, Cancelar y Continuar (lo bajado se guarda).
  - Se verifica el **SHA-256** fijo `f15622d8…e99` (176.069.933 bytes). Un archivo distinto se borra.
  - Origenes, en orden:
    1. tu enlace propio (opcional, solo https);
    2. Hugging Face, revision fija `43f9004…`;
    3. la copia identica de rembg en GitHub Releases.
  - Antes de bajar se revisa el espacio libre.
  - Permiso nuevo: INTERNET. Se usa solo para esta descarga.
- **La IA corre en otro hilo**: la pantalla no se congela.
  - Se puede **cancelar** a mitad. En PC la cancelacion se midio en 0,33 s.
  - Al terminar se cierra la sesion del modelo, para que no queden unos 300 MB ocupados mientras editas.
  - Si el telefono tiene menos de 3 GB, o menos de 900 MB libres, avisa antes de empezar.
- **Entrada igual al original de SkyTNT**:
  - RGB/255 sin restar media;
  - letterbox sin deformar, relleno negro, centrado con `//2`;
  - salida con sigmoide.
  - Al reducir se promedia por area (como cv2.INTER_AREA). Asi la trama del manga no hace moire.
  - **Verificado contra Python/cv2**: entrada con diferencia maxima de 0,00005 y salida de 0,0001.
- **Solo 1024 px**: el archivo original tiene la forma fija [1,3,1024,1024]. Para 768 o 640 haria falta reexportar el modelo con PyTorch, y este entorno no lo tiene. **No** se cambio la forma con un simple reescalado de imagen. FP16 e int8 no se usan porque no hubo como comparar su calidad contra fp32.
- **Reabrir sin repetir la IA**: la salida cruda se guarda en cache (las ultimas 6). La clave es un resumen de los pixeles: si la capa cambia, se vuelve a calcular.
- **Si hay algo marcado en azul**, la IA mira solo ese recuadro. Asi gana detalle en un personaje chico.

### Post-proceso nuevo (`ai/AiMatte.java`), por etapas que se prenden o apagan en Ajustes

1. **Manchas dudosas gruesas** (vidrio, luz, barras a medias): se bajan.
   - Solo si son **grandes** (al menos 400 celdas o el 0,2 % de la imagen).
   - Un aro o adorno chico que la IA vio a medias se respeta.
2. **Curva de alfa** (Dureza). La mascara sigue suave, de 0 a 255.
3. **Islas**: queda la pieza mayor.
   - Tambien quedan otras piezas grandes (otro personaje) y las chicas **cercanas** (aros, mechones, cintas).
   - Las lejanas o dudosas se quitan.
   - **No se borran islas pequenas a ciegas.**
4. **Agujeros**: solo se rellenan los diminutos, o los chicos donde la IA dudaba y cuyo color **no** es el del fondo. Un hueco real entre brazo y cuerpo se respeta.
5. **Ampliado suave** y **filtro guiado por el COLOR** de la imagen original (He et al.): el borde se pega al dibujo real.
6. **Linea del dibujo**: el contorno oscuro pegado al recorte entra, con su antialias desmezclado. Solo si es mas oscuro que el fondo de al lado: en fondo oscuro no agrega nada.
7. **Desplazar borde** de -3 a +3 px.
8. **Color del borde sin el tinte del fondo** (sin halo blanco ni celeste).
9. En **blanco y negro / trama**, de fabrica no se usan el filtro guiado ni la linea. Medido: siguen la trama y empeoran el borde.

### Editor del recorte (vista previa NO destructiva, `view/AiCutView.java` + `AiCutFlow.java`)

- **Ver** sobre cuadros, blanco, negro o magenta. Es solo para ver: **nunca** se exporta.
- **Mantener el ojo de comparar**: muestra el original.
- **Pincel Quitar / Anadir**, con tamano y bordes suaves.
- **Quitar zona** (toque): quita lo que sobra, como una barra o el edificio.
  - Relleno por parecido dentro del recorte.
  - No pasa por pasos de 1-2 px en bordes debiles.
  - Las tiras finas que quedan entre lo quitado y el fondo tambien se van.
- **Quitar zona tocando el FONDO ya transparente**: el Balde de v8.32 ajusta el borde. Donde la IA y el Balde coinciden manda el borde del Balde, que es mas exacto en manga.
- **Anadir zona**: devuelve con un toque lo que falta.
- **Solo este**: tocas un personaje y se quitan los otros. Si los personajes se tocan, avisa "Se tocan: usa Quitar".
- **Escoba del recorte**: quita los pedazos sueltos lejos del personaje.
- **Deshacer / Rehacer** por trazo (40 pasos).
  - Un **segundo dedo** a mitad de un trazo lo deshace (sin trazos fantasma).
  - Con dos dedos haces zoom y mueves la vista.
- **Ajustes**: Dureza, Borde, Parecido de zona y las 6 etapas. Cambiarlos **no vuelve a correr la IA** y **conserva tus retoques**.
- **Tres mascaras separadas**: IA, Anadir y Quitar. Alfa final = max(IA, Anadir) - Quitar, multiplicado por el alfa original.
- **Aplicar**:
  - en **capa nueva "Recorte IA"** (la original queda intacta y oculta);
  - o en la misma capa.
  - En los dos casos, **un solo Deshacer**.
- **Licencias** visibles desde la ventana de descarga.

## 2. Balde de Borrar fondo: tocar lo negro

- Si tocas una **zona negra ANCHA** (7x7 casi todo tinta), el Balde toma **ese** negro y lo borra. Antes saltaba al papel de al lado y decia "No encontre fondo...". El Pincel protegido hace lo mismo al empezar.
- Si tocas una **linea fina**, sigue tomando el fondo de al lado, como antes: asi no se come la linea.
- **Mensajes cortos**:
  - "Nada que borrar aqui";
  - "Ya esta borrado" (si tocas lo transparente).

## 3. Separar: que hace y que se arreglo

- **Que hace** (revisado en el codigo):
  - rayas cada parte con un color;
  - el Check saca cada parte a **su capa**, con sus **colores reales** (copia los pixeles originales);
  - el boton Borrador quita el fondo marcado en gris.
  - **No pinta**: el rosa o rojo que viste era la **vista previa**.
- **Nombre corto**: "Separar" (antes se cortaba "Separar y...").
- **Al empezar la vista previa** aparece: "Vista previa: cada color es una parte (no pinta la imagen)".
- **Con UNA sola raya** (tu caso del ojo), la parte toma solo lo cercano y encerrado: el limite cae en el borde mas fuerte. El resto queda como "el resto" (no se separa ni se tine).
  - Medido en tu manga ya transparente: v8.32 se llevaba 150.661 px (13,5 % del personaje); v8.33 se lleva 545 px (el iris).
- **Lo transparente de la capa** cuenta como fondo: no se vuelve a meter ni une partes.
- Con **2 o mas partes**, Separar funciona igual que antes.

## 4. Pincel y Goma grandes: menos lag

- **Brocha, Goma y Borrador de Borrar fondo**:
  - una raiz cuadrada por FILA en el interior duro (antes, una por pixel);
  - el original del trazo se lee por bloque en cache (antes, una busqueda por pixel);
  - la Goma y el Borrador saltan lo que ya es transparente.
- **Resultado identico** (comprobado pixel a pixel).
- Bucle de la Goma medido en PC, 12 MP, dureza 1:
  - radio 80: 676 → 99 µs por estampa;
  - radio 300: 1599 → 230 µs;
  - segunda pasada sobre lo borrado: hasta 14 veces mas rapido.
  - Con dureza 0,5 la mejora es de 1,4 a 2,2 veces.

## 5. Selector de color nuevo

- **Cuadrado S/V** dentro del aro de tono. El rombo de antes **no llegaba al blanco ni al negro puros**: por eso "no habia blanco".
- Los grises no pierden el tono.
- **A un toque**: blanco, 5 grises y negro.
- **Recientes**: 12, se guardan solos.
- **Paleta** de la obra y global: + guarda, mantener pulsado quita.
- **HEX** (acepta #RGB y #RRGGBB) y barras **RGB o HSV** (boton para cambiar).
- **Mezclar dos colores** con proporcion y vista previa:
  - "Pintura": promedio en pantalla;
  - "Luz": mezcla lineal, el medio no se oscurece.
- **Imagen de referencia para sacar colores**: no es una capa y no se exporta. Tiene Tomar color, **Sacar paleta** (12 colores variados, corte por la mediana), Cambiar y Quitar.
- **Gotero con lupa**: el de siempre.

## 6. Pintura: Sombra automatica (nuevo, en la barra de la Brocha)

- Eliges de donde viene la luz (8 flechas) y el ancho.
- Se crea una **capa aparte** recortada en Multiplicar 60 %, con la sombra del lado contrario.
  - Va **por partes**: cara, pelo y ropa por separado, respetando la linea.
  - Los detalles chicos (ojo, boca) no hacen rayas.
- No toca tu dibujo. Se corrige con Brocha o Goma en su capa, o se quita con Deshacer.
- Es una **base**, no una sombra final.
- No se agrego degradado ni pinceles nuevos: no habia como probarlos bien en esta etapa.

## Archivos

- **Nuevos**:
  - `ai/AiPrep.java`, `ai/AiSegmenter.java`, `ai/AiMatte.java`, `ai/AiCutSession.java`, `ai/ModelStore.java`, `ai/AiCache.java`
  - `AiCutFlow.java`, `view/AiCutView.java`
  - `core/ColorTools.java`, `core/StampSpan.java`, `core/AutoShade.java`
  - iconos `ic_ai`, `ic_ai_zone_remove`, `ic_ai_zone_add`
  - `assets/LICENCIAS_IA.txt`
- **Cambiados**:
  - `MainActivity.java`: boton IA, selector de color, Sombra automatica, texto de Separar.
  - `view/CanvasView.java`: aplicar IA, Balde en negro y mensajes, Separar, bucles de pincel, Sombra automatica.
  - `core/BgEngine.java`: tapColor.
  - `core/BgStroke.java`: color al empezar.
  - `core/Watershed.java`: una sola parte.
  - `view/ColorPickerView.java`: cuadrado S/V.
  - `AndroidManifest.xml`: INTERNET.
  - `app/build.gradle`: version 8.33 (71), dependencia `com.microsoft.onnxruntime:onnxruntime-android:1.20.0`, librerias nativas comprimidas.
- **Sin cambios**: `.github/workflows/build.yml`.

## Pendiente y limites (verdad)

- **No se probo en un telefono ni en un emulador.** Todo lo medido fue en este PC (JVM):
  - IA real con ONNX Runtime 1.20.0 en CPU x86 de 2 nucleos: unos 2 s por imagen y pico de unos 980 MB de memoria nativa;
  - el codigo de la app compila completo contra un android.jar real (726 clases).
  - En un telefono cuenta con varias veces mas tiempo. No se midio el uso de memoria en un telefono.
- **El APK no se compilo aqui** (no hay Gradle con red). Lo compila tu GitHub Actions, que baja ONNX Runtime de Maven Central. Esa version existe: 1.20.0, 31-oct-2024.
- **Descarga real comprobada desde GitHub (rembg)**: 168 MB en 8 s y SHA correcto. Hugging Face **no** se pudo probar desde aqui (el entorno lo bloquea); por eso hay un segundo origen.
- **Barras, edificios o luces pegados al personaje**: la IA los toma como parte. Se quitan con 3 a 10 toques de "Quitar zona" mas la Escoba (medido en tus 2 imagenes).
- **Si el fondo y la ropa tienen casi el mismo color** (pantalon iluminado de violeta junto al toldo violeta), Quitar zona con un parecido de 46 se llevaba parte del pantalon. Por eso de fabrica queda en **30**. Si pasa: Deshacer, o pincel Anadir.
- **Manga B/N**: no hay IA libre entrenada para trama. Aqui la IA funciono bien en tu manga, pero es una propuesta: el borde mas exacto lo da tocar el papel (Balde).
- **Telefonos de 3-4 GB**: la IA puede cerrarse por memoria (avisa antes).
- **Hugging Face** dice "Apache-2.0" en la respuesta del autor (discusion #4), pero la ficha del modelo todavia no lo declara. Para una app gratuita el riesgo es bajo; revisalo si un dia la vendes.
