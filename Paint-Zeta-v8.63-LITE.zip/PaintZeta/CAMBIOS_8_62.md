# Paint Zeta v8.62: celulares de gama baja, Android 16 y limpieza

## 1. Se adapta a cada celular (gama baja, media, alta)
- **Causa**: la app trataba igual a todos. Abría imágenes de 8 millones de píxeles como mínimo
  aunque la memoria no alcanzara, usaba hasta 7 hilos a la vez y 64 MB para Deshacer.
- **Ahora**: al abrir mira la RAM del celular, si Android lo marca como "poca memoria" y los núcleos:
  - Gama baja (menos de 3 GB): abre hasta ~4 millones de píxeles, 2 hilos, Deshacer 16-24 MB.
  - Gama media (3 a 6 GB): hasta lo que da la memoria (mínimo 6 MP), 3 hilos, Deshacer 24-48 MB.
  - Gama alta: como antes.
  - El zoom fino usa un hilo menos que los cálculos pesados: no se pelean.
- **Registro de errores**: si la app se cierra por un error, la próxima vez que la abras sale
  "La app se cerró por un error" con un botón **Copiar**: pégalo en el chat y lo arreglo.

## 2. Android 16 (lo exige Google Play)
- La app apunta a Android 16.
- **Botón Atrás**: funciona como antes (en Android 16 hay que pedirlo; si no, la app no se
  enteraba del Atrás).
- **Pantalla**: en Android 15 y 16 la app se dibuja debajo de las barras del sistema. Ahora deja
  el espacio justo: los botones de arriba y de abajo no quedan tapados. Iconos de las barras en claro.

## 3. Limpieza (sin cambiar nada que se vea)
- Se quitó un borrador de fondo viejo que no estaba conectado a nada (371 líneas).
- Se quitaron los restos del paso "Sombra" viejo de Colorear.
- Las "cuentas repetidas" se revisaron: dan lo mismo o hacen cosas distintas a propósito. No son
  un fallo; unirlas no cambia nada para ti, así que se dejaron (cero riesgo).

## No se tocó
La IA (Recortar con IA, Mejorar imagen), Acabado, Marioneta, Luz, Colorear, Capas, pinceles.

## Pendiente importante (IA y Google Play)
La librería de la IA (versión 1.20) no cumple el requisito de "páginas de 16 KB" de Google Play.
Desde el 1 de febrero de 2027 las actualizaciones sin eso no se pueden publicar. Hay que
actualizar la librería de la IA en una versión aparte, probándola bien.

## Cómo probarlo
1. Abre la app: todo debe verse igual, sin botones tapados arriba ni abajo.
2. Botón Atrás: en una obra debe hacer lo mismo que antes.
3. Abre una imagen grande en un celular de gama baja: no debe cerrarse.
4. Marioneta, Acabado, IA: igual que en la 8.61.
