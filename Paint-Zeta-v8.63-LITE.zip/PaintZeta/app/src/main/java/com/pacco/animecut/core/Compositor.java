package com.pacco.animecut.core;

import java.util.Arrays;
import java.util.List;

/**
 * v8.26: UNA sola forma de juntar capas para exportar y comparar (misma regla que
 * la pantalla): modo de mezcla W3C, opacidad, recorte (con base oculta), bloqueo
 * de nada, y "Cambiar color" no destructivo. Todo en Java, pixel por pixel: no usa
 * PorterDuff ni BlendMode de Android, asi da lo mismo en Android 8 que en 14.
 *
 * Empieza en transparente: donde ninguna capa tiene dibujo, el resultado es alfa 0.
 */
public final class Compositor {
    private Compositor() { }

    /**
     * Junta las capas [0, end) en el rectangulo (rx,ry,rw,rh). out debe tener rw*rh.
     */
    public static void composite(List<Layer> layers, int end, int w, int h,
                                 int rx, int ry, int rw, int rh, int[] out) {
        int n = rw * rh;
        Arrays.fill(out, 0, n, 0);
        end = Math.min(end, layers.size());
        boolean anyClip = false;
        for (int k = 0; k < end; k++) if (layers.get(k).clip) anyClip = true;
        byte[] base = anyClip ? new byte[n] : null;
        int[] tmp = new int[n];
        boolean baseSeen = false, baseHidden = false;
        for (int k = 0; k < end; k++) {
            Layer l = layers.get(k);
            boolean clipped = l.clip && baseSeen;
            if (!clipped) {
                baseSeen = true;
                baseHidden = !l.visible || l.opacity <= 0;
            }
            if (clipped && baseHidden) continue;
            boolean isBase = base != null && !clipped;
            if (isBase) Arrays.fill(base, (byte) 0);
            if (!l.visible || l.opacity <= 0) continue;
            l.read(rx, ry, rw, rh, tmp, w, h);
            ColorAdjust adj = l.adjuster();
            int op = l.opacity, md = l.mode;
            for (int i = 0; i < n; i++) {
                int c = tmp[i];
                int ca = c >>> 24;
                if (isBase) base[i] = (byte) ca;
                if (ca == 0) continue;
                if (adj != null) c = adj.apply(c);
                if (clipped) ca = ca * (base[i] & 0xFF) / 255;
                int sa = (ca * op) / 255;
                if (sa == 0) continue;
                out[i] = Project.blend(out[i], c, md, sa);
            }
        }
    }

    /** Todo el lienzo, todas las capas visibles (lo que se exporta como "Imagen completa"). */
    public static int[] flatten(Project p) {
        int[] out = new int[p.w * p.h];
        composite(p.layers, p.layers.size(), p.w, p.h, 0, 0, p.w, p.h, out);
        return out;
    }

    /** Un pixel de lo que se ve (sin fondo): para el gotero "Visible". */
    public static int pixel(Project p, int x, int y) {
        int[] o = new int[1];
        composite(p.layers, p.layers.size(), p.w, p.h, x, y, 1, 1, o);
        return o[0];
    }

    /** Resultado sobre un fondo opaco (como en pantalla sobre el papel/cuadros). */
    public static int overOpaque(int bg, int c) {
        int a = c >>> 24;
        if (a == 0) return bg | 0xFF000000;
        return Project.over(bg | 0xFF000000, c, a) | 0xFF000000;
    }
}
