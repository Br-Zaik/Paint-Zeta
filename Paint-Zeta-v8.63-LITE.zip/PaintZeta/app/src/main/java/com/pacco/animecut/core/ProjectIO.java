package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Guarda y abre la obra. Por dentro es un ZIP con un PNG por capa (con su
 * transparencia), la seleccion y los datos de cada capa.
 *
 * Tambien abre las obras de la version anterior, donde las capas eran
 * recortes de la imagen, y las convierte a capas de verdad.
 */
public final class ProjectIO {

    public static class Loaded {
        public Project project;
        public int color;
    }

    private ProjectIO() {
    }

    /**
     * v3: cada capa se guarda solo con su recorte (x, y, ancho, alto). Es mas
     * rapido y liviano que guardar el lienzo entero por cada capa.
     */
    public static void save(OutputStream out, Project p, int color) throws IOException {
        ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(out));
        z.setLevel(1);
        try {
            java.util.List<Layer> layers = new java.util.ArrayList<Layer>(p.layers);
            int w = p.w, h = p.h;
            Layer.Packed[] snaps = new Layer.Packed[layers.size()];
            // v8.53: capas abiertas (las que se pintan): PNG rapido directo de los pixeles y, si la
            // capa no cambio desde el ultimo guardado, el mismo PNG de antes (no se comprime de nuevo)
            Saved[] fast = new Saved[layers.size()];
            StringBuilder m = new StringBuilder();
            m.append("v3\n");
            m.append(w).append(' ').append(h).append('\n');
            m.append(color).append('\n');
            m.append(p.active).append('\n');
            m.append(layers.size()).append('\n');
            for (int i = 0; i < layers.size(); i++) {
                Layer l = layers.get(i);
                Saved sv = fastSave(l, w, h);
                Layer.Packed pk = sv == null ? l.snapshot(w, h) : null;
                snaps[i] = pk;
                fast[i] = sv;
                int bx = sv != null ? sv.x : pk.x, by = sv != null ? sv.y : pk.y;
                int bw = sv != null ? sv.w : pk.w, bh = sv != null ? sv.h : pk.h;
                m.append(l.visible ? 1 : 0).append('|').append(l.opacity).append('|')
                        .append(bx).append('|').append(by).append('|')
                        .append(bw).append('|').append(bh).append('|')
                        .append(l.name.replace('|', '_').replace('\n', ' ')).append('\n');
            }
            // modo de mezcla, recorte y alfa bloqueado (las versiones viejas lo ignoran)
            m.append("fx");
            for (Layer l : layers) {
                m.append(' ').append(l.mode).append(',').append(l.clip ? 1 : 0).append(',').append(l.alphaLock ? 1 : 0).append(',').append(l.reference ? 1 : 0)
                        // v8.26: bloqueo total, papel en el preset manga y Cambiar color (H,S,L)
                        .append(',').append(l.locked ? 1 : 0).append(',').append(l.role)
                        .append(',').append(l.hue).append(',').append(l.sat).append(',').append(l.lit);
            }
            m.append('\n');
            // v8.26: preset "Colorear manga" activo
            m.append("manga ").append(p.mangaMode ? 1 : 0).append('\n');
            // v8.39: fondo de vista de la obra (verde, negro...)
            if (p.viewBg >= 0) m.append("vista ").append(p.viewBg).append('\n');
            // v8.39: copia para Restaurar (capa a la que pertenece)
            byte[] restorePng = restoreBytes(p, layers, w, h);
            int restoreIdx = restorePng == null ? -1 : layers.indexOf(p.restoreLayer);
            if (restoreIdx >= 0) m.append("restaurar ").append(restoreIdx).append('\n');
            // v8.40: Color por zonas (modo y luces/fondo); las zonas van en zonas.bin
            m.append("zonas ").append(p.zoneMode ? 1 : 0);
            for (int v : p.zoneFx) m.append(' ').append(v);
            m.append('\n');
            byte[] zonesBin = ZoneTone.encode(new java.util.ArrayList<ZoneTone.Zone>(p.zones), p.zoneStyle,
                    new java.util.ArrayList<ZoneTone.Group>(p.zonePalette));
            z.putNextEntry(new ZipEntry("meta.txt"));
            z.write(m.toString().getBytes("UTF-8"));
            z.closeEntry();

            for (int i = 0; i < snaps.length; i++) {
                Layer.Packed pk = snaps[i];
                Saved sv = fast[i];
                snaps[i] = null;
                fast[i] = null;
                byte[] png;
                if (sv != null) {
                    if (sv.png == null) continue;   // capa vacia
                    png = sv.png;
                } else {
                    if (pk.empty()) continue;
                    png = pngFor(pk.bmp);
                }
                z.putNextEntry(new ZipEntry(String.format(Locale.US, "layer_%03d.png", i)));
                z.write(png);
                z.closeEntry();
            }
            z.putNextEntry(new ZipEntry("seleccion.bin"));
            z.write(p.selection);
            z.closeEntry();
            // v8.26: zonas protegidas "No colorear"
            byte[] prot = p.protect;
            if (prot != null && prot.length == w * h && anySet(prot)) {
                z.putNextEntry(new ZipEntry("proteger.bin"));
                z.write(prot);
                z.closeEntry();
            }
            // v8.26: paleta de la obra (nombre y color por linea)
            if (!p.swatches.isEmpty()) {
                z.putNextEntry(new ZipEntry("paleta.txt"));
                z.write(paletteText(p.swatches).getBytes("UTF-8"));
                z.closeEntry();
            }
            // v8.26: copia reducida de la referencia de colores (solo si el usuario lo pidio)
            if (zonesBin != null) {
                z.putNextEntry(new ZipEntry("zonas.bin"));
                z.write(zonesBin);
                z.closeEntry();
            }
            if (restoreIdx >= 0) {
                z.putNextEntry(new ZipEntry("restaurar.png"));
                z.write(restorePng);
                z.closeEntry();
            }
            byte[] refPng = p.refImagePng;
            if (refPng != null && refPng.length > 0) {
                z.putNextEntry(new ZipEntry("referencia.png"));
                z.write(refPng);
                z.closeEntry();
            }
            z.finish();
        } finally {
            try {
                z.close();
            } catch (IOException ignored) {
            }
        }
    }

    private static boolean anySet(byte[] b) {
        for (byte v : b) if (v != 0) return true;
        return false;
    }

    /** "#AARRGGBB nombre" por linea. */
    public static String paletteText(java.util.List<Project.Swatch> list) {
        StringBuilder sb = new StringBuilder();
        for (Project.Swatch sw : list) {
            sb.append(String.format(Locale.US, "#%08X", sw.color)).append(' ')
                    .append(sw.name.replace('\n', ' ')).append('\n');
        }
        return sb.toString();
    }

    public static void parsePalette(String txt, java.util.List<Project.Swatch> out) {
        for (String ln : txt.split("\n")) {
            ln = ln.trim();
            if (ln.length() < 9 || ln.charAt(0) != '#') continue;
            try {
                int c = (int) Long.parseLong(ln.substring(1, 9), 16);
                String name = ln.length() > 10 ? ln.substring(10).trim() : "";
                out.add(new Project.Swatch(name, c));
            } catch (NumberFormatException ignored) {
            }
        }
    }

    /** v8.26: lee lo nuevo (si existe). Las obras viejas no lo tienen y abren igual. */
    private static void readExtras(String[] lines, Map<String, byte[]> blobs, Project p) throws IOException {
        for (String ln : lines) {
            ln = ln.trim();
            if (ln.startsWith("manga ")) p.mangaMode = "1".equals(ln.substring(6).trim());
            if (ln.startsWith("restaurar ")) {
                try {
                    int ri = Integer.parseInt(ln.substring(10).trim());
                    byte[] rp = blobs.get("restaurar.png");
                    if (rp != null && rp.length > 0 && ri >= 0 && ri < p.layers.size()) {
                        p.restoreLayer = p.layers.get(ri);
                        p.restorePng = rp;
                        p.restorePx = null;
                        p.restorePngVer = p.restoreVer;
                    }
                } catch (NumberFormatException ignored) { }
            }
            if (ln.startsWith("zonas ")) {
                String[] v = ln.substring(6).trim().split(" ");
                try {
                    p.zoneMode = "1".equals(v[0]);
                    for (int k = 0; k < p.zoneFx.length && k + 1 < v.length; k++) p.zoneFx[k] = Integer.parseInt(v[k + 1]);
                } catch (RuntimeException ignored) { }
            }
            if (ln.startsWith("vista ")) {
                try { p.viewBg = Integer.parseInt(ln.substring(6).trim()); } catch (NumberFormatException ignored) { }
            }
        }
        byte[] prot = blobs.get("proteger.bin");
        if (prot != null && prot.length == p.w * p.h) p.protect = prot;
        byte[] pal = blobs.get("paleta.txt");
        if (pal != null) parsePalette(new String(pal, "UTF-8"), p.swatches);
        byte[] ref = blobs.get("referencia.png");
        if (ref != null && ref.length > 0) p.refImagePng = ref;
        byte[] zb = blobs.get("zonas.bin");
        if (zb != null) {
            ZoneTone.Saved sv = ZoneTone.decode(zb, p.w, p.h);
            p.zones = sv.zones;
            p.zoneStyle = sv.current;
            p.zonePalette = sv.palette;
        }
    }

    /**
     * Guardado rapido: las capas que no cambiaron ya tienen su PNG hecho de la
     * vez anterior, asi que solo se comprime la capa que se esta pintando.
     */
    private static final Map<Bitmap, byte[]> PNG_CACHE = new java.util.WeakHashMap<Bitmap, byte[]>();

    /** v8.53: lo guardado de una capa abierta: su huella, su recorte y su PNG. */
    private static final class Saved {
        long hash;
        int x, y, w, h;
        byte[] png;
    }

    private static final Map<Layer, Saved> FAST_CACHE = new java.util.WeakHashMap<Layer, Saved>();

    /** null si la capa esta empacada (ahi sirve el PNG que ya tiene en cache). */
    private static Saved fastSave(Layer l, int w, int h) {
        int[] d = l.denseOrNull();
        if (d == null || d.length != w * h) return null;
        long hs = FastPng.hash(d);
        synchronized (FAST_CACHE) {
            Saved old = FAST_CACHE.get(l);
            if (old != null && old.hash == hs) return old;
        }
        Saved sv = new Saved();
        sv.hash = hs;
        android.graphics.Rect b = l.bounds(w, h);
        if (b == null) {
            sv.x = sv.y = sv.w = sv.h = 0;
            sv.png = null;
        } else {
            sv.x = b.left; sv.y = b.top; sv.w = b.width(); sv.h = b.height();
            sv.png = FastPng.encode(d, w, sv.x, sv.y, sv.w, sv.h);
            if (sv.png == null) return null;
        }
        synchronized (FAST_CACHE) { FAST_CACHE.put(l, sv); }
        return sv;
    }

    private static byte[] pngFor(Bitmap b) {
        synchronized (PNG_CACHE) {
            byte[] c = PNG_CACHE.get(b);
            if (c != null) return c;
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 16);
        b.compress(Bitmap.CompressFormat.PNG, 100, bo);
        byte[] out = bo.toByteArray();
        synchronized (PNG_CACHE) {
            PNG_CACHE.put(b, out);
        }
        return out;
    }

    public static Loaded load(InputStream in) throws IOException {
        Map<String, byte[]> blobs = new HashMap<String, byte[]>();
        ZipInputStream z = new ZipInputStream(new BufferedInputStream(in));
        try {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                blobs.put(e.getName(), readAll(z));
                z.closeEntry();
            }
        } finally {
            try {
                z.close();
            } catch (IOException ignored) {
            }
        }
        byte[] meta = blobs.get("meta.txt");
        if (meta == null) throw new IOException("No es una obra de Paint Zeta");
        String[] lines = new String(meta, "UTF-8").split("\n");
        if (lines.length > 0 && lines[0].trim().equals("v3")) return loadV3(lines, blobs);
        if (lines.length > 0 && lines[0].trim().equals("v2")) return loadV2(lines, blobs);
        return loadV1(lines, blobs);
    }

    private static Loaded loadV2(String[] lines, Map<String, byte[]> blobs) throws IOException {
        String[] wh = lines[1].trim().split(" ");
        int w = parse(wh[0], 1), h = parse(wh[1], 1);
        Project p = new Project(w, h);
        int color = parse(lines[2], 0xFFE05A5A);
        int active = parse(lines[3], 0);
        int n = parse(lines[4], 0);
        for (int i = 0; i < n && 5 + i < lines.length; i++) {
            String[] parts = lines[5 + i].split("\\|", 3);
            byte[] png = blobs.get(String.format(Locale.US, "layer_%03d.png", i));
            if (png == null) continue;
            int[] px = decode(png, w, h);
            if (px == null) continue;
            Layer l = new Layer(parts.length >= 3 ? parts[2] : "capa_" + (i + 1), px);
            l.visible = parts.length < 1 || "1".equals(parts[0]);
            l.opacity = parts.length >= 2 ? parse(parts[1], 255) : 255;
            l.pack(w, h);
            p.layers.add(l);
            blobs.remove(String.format(Locale.US, "layer_%03d.png", i));
        }
        if (p.layers.isEmpty()) throw new IOException("La obra no tiene capas");
        byte[] sel = blobs.get("seleccion.bin");
        if (sel != null && sel.length == w * h) System.arraycopy(sel, 0, p.selection, 0, sel.length);
        p.active = active >= Project.SEL && active < p.layers.size() ? active : 0;
        p.markDirty();
        Loaded r = new Loaded();
        r.project = p;
        r.color = color;
        return r;
    }

    /** Lee la linea "fx" (modo, recorte, alfa bloqueado) si la obra la tiene. */
    private static void readFx(String[] lines, int at, Project p) {
        for (int k = at; k < lines.length; k++) {
            String ln = lines[k].trim();
            if (!ln.startsWith("fx")) continue;
            String[] items = ln.substring(2).trim().split(" ");
            for (int i = 0; i < items.length && i < p.layers.size(); i++) {
                String[] v = items[i].split(",");
                if (v.length < 3) continue;
                Layer l = p.layers.get(i);
                int md = parse(v[0], 0);
                l.mode = md >= 0 && md < Layer.MODE_NAMES.length ? md : 0;
                l.clip = "1".equals(v[1]);
                l.alphaLock = "1".equals(v[2]);
                // v8.24 (las versiones viejas ignoran este cuarto valor)
                l.reference = v.length >= 4 && "1".equals(v[3]);
                // v8.26
                l.locked = v.length >= 5 && "1".equals(v[4]);
                l.role = v.length >= 6 ? Math.max(0, Math.min(Layer.ROLE_MAX, parse(v[5], 0))) : 0;
                l.hue = v.length >= 7 ? Math.max(-180, Math.min(180, parse(v[6], 0))) : 0;
                l.sat = v.length >= 8 ? Math.max(-100, Math.min(100, parse(v[7], 0))) : 0;
                l.lit = v.length >= 9 ? Math.max(-100, Math.min(100, parse(v[8], 0))) : 0;
            }
            return;
        }
    }

    private static Loaded loadV3(String[] lines, Map<String, byte[]> blobs) throws IOException {
        String[] wh = lines[1].trim().split(" ");
        int w = parse(wh[0], 1), h = parse(wh[1], 1);
        Project p = new Project(w, h);
        int color = parse(lines[2], 0xFFE05A5A);
        int active = parse(lines[3], 0);
        int n = parse(lines[4], 0);
        for (int i = 0; i < n && 5 + i < lines.length; i++) {
            String[] parts = lines[5 + i].split("\\|", 7);
            if (parts.length < 7) continue;
            int x = parse(parts[2], 0), y = parse(parts[3], 0), cw = parse(parts[4], 0), ch = parse(parts[5], 0);
            String name = parts[6];
            Layer l;
            String key = String.format(Locale.US, "layer_%03d.png", i);
            byte[] png = blobs.get(key);
            if (png == null || cw <= 0 || ch <= 0) {
                l = new Layer(name, w, h);
            } else {
                Bitmap cb = decodeBitmap(png, cw, ch);
                blobs.remove(key);
                if (cb == null || x < 0 || y < 0 || x + cw > w || y + ch > h) continue;
                l = Layer.fromBitmap(name, x, y, cb, w, h);
                synchronized (PNG_CACHE) {
                    PNG_CACHE.put(cb, png);
                }
            }
            l.visible = "1".equals(parts[0]);
            l.opacity = parse(parts[1], 255);
            p.layers.add(l);
        }
        if (p.layers.isEmpty()) throw new IOException("La obra no tiene capas");
        readFx(lines, 5 + n, p);
        readExtras(lines, blobs, p);
        byte[] sel = blobs.get("seleccion.bin");
        if (sel != null && sel.length == w * h) System.arraycopy(sel, 0, p.selection, 0, sel.length);
        p.active = active >= Project.SEL && active < p.layers.size() ? active : 0;
        p.markDirty();
        Loaded r = new Loaded();
        r.project = p;
        r.color = color;
        return r;
    }

    /** Obras de la version anterior: imagen + recortes. Se pasan a capas de verdad. */
    private static Loaded loadV1(String[] lines, Map<String, byte[]> blobs) throws IOException {
        byte[] basePng = blobs.get("base.png");
        if (basePng == null) throw new IOException("Obra incompleta");
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap base = BitmapFactory.decodeByteArray(basePng, 0, basePng.length, o);
        if (base == null) throw new IOException("No se pudo leer la imagen");
        int w = base.getWidth(), h = base.getHeight();
        int[] img = new int[w * h];
        base.getPixels(img, 0, w, 0, 0, w, h);
        base.recycle();

        Project p = new Project(w, h);
        boolean baseVisible = true;
        byte[] st = blobs.get("estado.txt");
        if (st != null) {
            String[] parts = new String(st, "UTF-8").trim().split(" ");
            if (parts.length >= 1) baseVisible = "1".equals(parts[0]);
        }
        Layer imagen = new Layer("imagen", img);
        imagen.visible = baseVisible;
        p.layers.add(imagen);

        int color = lines.length > 2 ? parse(lines[2], 0xFFE05A5A) : 0xFFE05A5A;
        int n = lines.length > 3 ? parse(lines[3], 0) : 0;
        for (int i = 0; i < n && 4 + i < lines.length; i++) {
            byte[] mask = blobs.get(String.format(Locale.US, "capa_%03d.bin", i));
            if (mask == null || mask.length != w * h) continue;
            String[] parts = lines[4 + i].split("\\|", 3);
            int[] src = img;
            byte[] opng = blobs.get(String.format(Locale.US, "capa_%03d_px.png", i));
            byte[] otxt = blobs.get(String.format(Locale.US, "capa_%03d_px.txt", i));
            if (opng != null && otxt != null) {
                String[] r = new String(otxt, "UTF-8").trim().split(" ");
                Bitmap ob = BitmapFactory.decodeByteArray(opng, 0, opng.length);
                if (r.length == 4 && ob != null) {
                    int l = parse(r[0], 0), t = parse(r[1], 0), rw = ob.getWidth(), rh = ob.getHeight();
                    src = img.clone();
                    int[] row = new int[rw];
                    for (int y = 0; y < rh && t + y < h; y++) {
                        ob.getPixels(row, 0, rw, 0, y, rw, 1);
                        for (int x = 0; x < rw && l + x < w; x++) src[(t + y) * w + l + x] = row[x];
                    }
                    ob.recycle();
                }
            }
            int[] px = new int[w * h];
            for (int k = 0; k < px.length; k++) {
                int a = mask[k] & 0xFF;
                px[k] = a == 0 ? 0 : ((a << 24) | (src[k] & 0x00FFFFFF));
            }
            Layer lay = new Layer(parts.length >= 3 ? parts[2] : "capa_" + (i + 1), px);
            lay.visible = parts.length < 1 || "1".equals(parts[0]);
            lay.opacity = parts.length >= 2 ? parse(parts[1], 255) : 255;
            lay.pack(w, h);
            p.layers.add(lay);
        }
        byte[] sel = blobs.get("seleccion.bin");
        if (sel != null && sel.length == w * h) System.arraycopy(sel, 0, p.selection, 0, sel.length);
        p.active = p.layers.size() - 1;
        p.markDirty();
        Loaded r = new Loaded();
        r.project = p;
        r.color = color;
        return r;
    }

    /** PNG a Bitmap sin premultiplicar, para usar como recorte de capa. */
    private static Bitmap decodeBitmap(byte[] png, int w, int h) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        o.inPremultiplied = false;
        Bitmap b = BitmapFactory.decodeByteArray(png, 0, png.length, o);
        if (b == null) return null;
        if (b.getWidth() != w || b.getHeight() != h || b.getConfig() != Bitmap.Config.ARGB_8888) {
            b.recycle();
            return null;
        }
        return b;
    }

    /**
     * v8.39: PNG de la copia para Restaurar. Solo se vuelve a comprimir si la copia cambio
     * desde el ultimo guardado; si no, se reusan los bytes de antes.
     */
    private static byte[] restoreBytes(Project p, java.util.List<Layer> layers, int w, int h) {
        try {
            Layer rl = p.restoreLayer;
            if (rl == null || !layers.contains(rl)) return null;
            int[] px = p.restorePx;
            int ver = p.restoreVer;
            if (px != null && px.length == w * h && (p.restorePng == null || p.restorePngVer != ver)) {
                // v8.53: PNG rapido directo de los pixeles (sin Bitmap de toda la imagen)
                byte[] png = FastPng.encode(px, w, 0, 0, w, h);
                if (png == null) return p.restorePng;
                p.restorePng = png;
                p.restorePngVer = ver;
            }
            return p.restorePng;
        } catch (Throwable t) {
            return null;      // sin memoria: la obra se guarda igual, sin la copia
        }
    }

    /** v8.39: abre la copia para Restaurar guardada con la obra. */
    public static int[] decodeFull(byte[] png, int w, int h) {
        try {
            return png == null ? null : decode(png, w, h);
        } catch (Throwable t) {
            return null;
        }
    }

    private static int[] decode(byte[] png, int w, int h) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        o.inPremultiplied = false;
        Bitmap b = BitmapFactory.decodeByteArray(png, 0, png.length, o);
        if (b == null || b.getWidth() != w || b.getHeight() != h) return null;
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        b.recycle();
        return px;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    private static int parse(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }
}
