package com.pacco.animecut.core;

/**
 * v8.32: MOTOR UNICO de Borrar fondo (Balde, Pincel protegido). Java puro, sin Android.
 *
 * Reemplaza las reglas de tamano fijo de v8.27-v8.31 (tramos oscuros de 7 px, cierre de 1 px,
 * cierre de 10 px, ventanas de 64 px con margen 16) por un analisis geometrico que depende del
 * GROSOR REAL de las lineas del dibujo (implementacion propia, apoyada en los articulos de
 * "trapped-ball" [Zhang et al. 2009] y de Fourey, Tschumperle y Revoy (VMV 2018); no copia codigo
 * GPL de GIMP/Krita/MyPaint):
 *
 *  1) MUROS: lo que no es fondo (color lejos del fondo tomado), mas las lineas oscuras finas
 *     aunque su color quede dentro de la tolerancia (fondo oscuro de cueva).
 *  2) DISTANCIA EXACTA (EDT, Felzenszwalb-Huttenlocher) de cada pixel libre al muro mas cercano.
 *  3) NUCLEO: pixeles donde cabe una pelota de radio R (D > R). Un hueco de la linea de menos de
 *     2R px no tiene nucleo, asi que el relleno del nucleo NO lo cruza. R = 1,5 * medio grosor de
 *     linea + 1, medido en la imagen (y por zonas de 128 px): igual en 1000 px que en 4000 px.
 *  4) CRECIMIENTO hacia las puntas finas (rincones entre mechones abiertos hacia afuera): solo
 *     mientras el espacio se ANGOSTA; cuando vuelve a ensancharse (salir por un hueco al otro
 *     lado) se frena. En un pasillo de ancho parejo solo avanza medio grosor de linea. Asi la
 *     expansion posterior tampoco vuelve a unir las dos regiones.
 *  5) BORDE: en la banda junto al muro el alfa sale de DESMEZCLAR el color del pixel entre el
 *     color local del dibujo (lo mas distinto del fondo cerca) y el color del fondo; el RGB se
 *     descontamina (sin halo blanco). Si la mezcla no se explica con esos dos colores (otro
 *     color, referencia mala) el pixel del dibujo se CONSERVA. La banda entra en la linea solo
 *     hasta su parte mas oscura.
 *  6) BORDE DEL LIENZO: los mapas se extienden con copia del borde (no es un muro). Una tira de
 *     papel de 1-15 px pegada al limite se borra; una linea que llega al limite sigue siendo
 *     muro afuera (no se la rodea).
 *
 * Memoria: 3 bytes por pixel de la zona analizada (estado, distancia, alfa) + colas chicas.
 */
public final class BgEngine {

    // ================== grosor de linea ==================

    public static final int TILE = 128;

    /** Medio grosor de linea medido (global y por zonas de TILE px). */
    public static final class Width {
        public float hGlobal = 1.5f;
        public int tw, th;
        /** medio grosor por zona en cuartos de px (0 = sin datos: usa el global) */
        public byte[] hq;
        public int samples, inkThreshold;
        public long ms;

        public float hAt(int x, int y) {
            if (hq == null) return hGlobal;
            int tx = Math.max(0, Math.min(tw - 1, x / TILE)), ty = Math.max(0, Math.min(th - 1, y / TILE));
            int q = hq[ty * tw + tx] & 0xFF;
            return q == 0 ? hGlobal : Math.max(hGlobal, q / 4f);
        }
    }

    static int lum(int c) {
        return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
    }

    /** Color "de antes" del pixel: si esta mas borrado que en la copia, el de la copia. */
    static int colorOf(int[] cur, int[] snap, int i) {
        int c = cur[i];
        if (snap != null) {
            int s = snap[i];
            if ((c >>> 24) < (s >>> 24)) return s;
        }
        return c;
    }

    /**
     * Mide el medio grosor de las lineas: umbral de Otsu (acotado) para la tinta, distancia
     * dentro de la tinta, y la mediana de la distancia en las crestas (centro de cada trazo).
     */
    public static Width measure(int[] cur, int[] snap, int w, int h) {
        long t0 = System.nanoTime();
        Width wd = new Width();
        int n = w * h;
        byte[] L = new byte[n];
        int[] hist = new int[256];
        int cnt = 0;
        for (int i = 0; i < n; i++) {
            int c = colorOf(cur, snap, i);
            int l = (c >>> 24) < 32 ? 255 : lum(c);
            L[i] = (byte) l;
            if ((c >>> 24) >= 32) { hist[l]++; cnt++; }
        }
        wd.tw = (w + TILE - 1) / TILE;
        wd.th = (h + TILE - 1) / TILE;
        if (cnt < 16) { wd.ms = (System.nanoTime() - t0) / 1000000; return wd; }
        // la tinta suele ser poca (un dibujo de lineas sobre papel): el oscuro se mide en el 0,5 %
        int p05 = pct(hist, cnt, 0.005), p95 = pct(hist, cnt, 0.95);
        if (p95 - p05 < 40) { wd.ms = (System.nanoTime() - t0) / 1000000; return wd; }
        int T = otsu(hist);
        T = Math.max(p05 + (p95 - p05) * 35 / 100, Math.min(p05 + (p95 - p05) * 65 / 100, T));
        wd.inkThreshold = T;
        // tinta = oscura (Otsu) Y mas oscura que lo que la rodea (8 px): asi un fondo oscuro
        // parejo (cueva) no cuenta como "linea gruesa". Lo no-tinta es el rasgo de la distancia.
        byte[] mx = new byte[n];
        maxFilterFull(L, mx, w, h, 8);
        byte[] feat = new byte[n];
        int ink = 0;
        for (int i = 0; i < n; i++) {
            int l = L[i] & 0xFF;
            if (l >= T || l + 40 > (mx[i] & 0xFF)) feat[i] = 1;
            else ink++;
        }
        L = null;
        mx = null;
        if (ink < 16) { wd.ms = (System.nanoTime() - t0) / 1000000; return wd; }
        byte[] D = new byte[n];
        edt(feat, w, h, D);
        int[] gh = new int[256];
        int[][] th = new int[wd.tw * wd.th][];
        int[] tcnt = new int[wd.tw * wd.th];
        int gcnt = 0;
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                if (feat[i] != 0) continue;
                int d = D[i] & 0xFF;
                if (d < 2) continue;
                boolean ridge = true;
                for (int dy = -1; dy <= 1 && ridge; dy++)
                    for (int dx = -1; dx <= 1; dx++)
                        if ((D[i + dy * w + dx] & 0xFF) > d) { ridge = false; break; }
                if (!ridge) continue;
                gh[d]++;
                gcnt++;
                int tk = (y / TILE) * wd.tw + x / TILE;
                if (th[tk] == null) th[tk] = new int[256];
                th[tk][d]++;
                tcnt[tk]++;
            }
        }
        wd.samples = gcnt;
        float hmax = maxHalfWidth(w, h);
        if (gcnt >= 16) wd.hGlobal = Math.min(hmax, Math.max(0.75f, pct(gh, gcnt, 0.5) / 4f - 0.25f));
        wd.hq = new byte[wd.tw * wd.th];
        for (int k = 0; k < th.length; k++) {
            if (th[k] == null || tcnt[k] < 24) continue;
            float hv = Math.min(hmax, Math.max(0.75f, pct(th[k], tcnt[k], 0.5) / 4f - 0.25f));
            wd.hq[k] = (byte) Math.max(1, Math.min(255, Math.round(hv * 4)));
        }
        wd.ms = (System.nanoTime() - t0) / 1000000;
        return wd;
    }

    /** Tope del medio grosor medido (una mancha negra grande no es una linea). */
    static float maxHalfWidth(int w, int h) {
        return Math.max(3f, Math.min(w, h) / 120f);
    }

    /** Maximo local (cuadrado de radio r) de toda la imagen, separable. */
    static void maxFilterFull(byte[] src, byte[] dst, int w, int h, int r) {
        int L = Math.max(w, h);
        int[] line = new int[L], out = new int[L], f = new int[L + 2 * r + 2], b = new int[L + 2 * r + 2];
        for (int y = 0; y < h; y++) {
            int off = y * w;
            for (int x = 0; x < w; x++) line[x] = src[off + x] & 0xFF;
            maxLineS(line, w, r, out, f, b);
            for (int x = 0; x < w; x++) dst[off + x] = (byte) out[x];
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) line[y] = dst[y * w + x] & 0xFF;
            maxLineS(line, h, r, out, f, b);
            for (int y = 0; y < h; y++) dst[y * w + x] = (byte) out[y];
        }
    }

    /** van Herk / Gil-Werman: maximo deslizante de ancho 2r+1 en O(n). */
    static void maxLineS(int[] a, int n, int r, int[] out, int[] f, int[] b) {
        int k = 2 * r + 1;
        int m = n + 2 * r;
        for (int e = 0; e < m; e++) {
            int v = (e - r >= 0 && e - r < n) ? a[e - r] : 0;
            f[e] = (e % k == 0) ? v : Math.max(f[e - 1], v);
        }
        for (int e = m - 1; e >= 0; e--) {
            int v = (e - r >= 0 && e - r < n) ? a[e - r] : 0;
            b[e] = (e == m - 1 || (e + 1) % k == 0) ? v : Math.max(b[e + 1], v);
        }
        for (int i = 0; i < n; i++) out[i] = Math.max(b[i], f[i + 2 * r]);
    }

    static int pct(int[] hist, int total, double p) {
        long want = (long) Math.ceil(total * p);
        long acc = 0;
        for (int v = 0; v < hist.length; v++) {
            acc += hist[v];
            if (acc >= want && hist[v] > 0) return v;
        }
        return hist.length - 1;
    }

    static int otsu(int[] hist) {
        long total = 0, sum = 0;
        for (int v = 0; v < 256; v++) { total += hist[v]; sum += (long) v * hist[v]; }
        long wB = 0, sumB = 0;
        double best = -1;
        int T = 128;
        for (int t = 0; t < 256; t++) {
            wB += hist[t];
            if (wB == 0) continue;
            long wF = total - wB;
            if (wF == 0) break;
            sumB += (long) t * hist[t];
            double mB = sumB / (double) wB, mF = (sum - sumB) / (double) wF;
            double between = (double) wB * wF * (mB - mF) * (mB - mF);
            if (between > best) { best = between; T = t + 1; }
        }
        return T;
    }

    // ================== distancia exacta ==================

    private static final byte[] QTAB = new byte[4096];
    static {
        for (int d2 = 0; d2 < 4096; d2++) QTAB[d2] = (byte) Math.min(255, (int) (4 * Math.sqrt(d2) + 0.5));
    }

    private int[] eF, eV;
    private float[] eZ;
    private int[] eRow;

    /** Distancia euclidiana exacta (cuartos de px, tope 255 = 63,75 px) de cada celda al rasgo != 0. */
    static void edt(byte[] feat, int w, int h, byte[] out) {
        new BgEngine().edtI(feat, w, h, out);
    }

    void edtI(byte[] feat, int w, int h, byte[] out) {
        // fase 1: columnas (distancia vertical, tope 255 = infinito)
        for (int x = 0; x < w; x++) {
            int g = 255;
            for (int y = 0; y < h; y++) {
                int i = y * w + x;
                if (feat[i] != 0) g = 0;
                else if (g < 255) g++;
                out[i] = (byte) g;
            }
            g = 255;
            for (int y = h - 1; y >= 0; y--) {
                int i = y * w + x;
                int v = out[i] & 0xFF;
                if (v == 0) g = 0;
                else if (g < 255) g++;
                if (g < v) out[i] = (byte) g;
            }
        }
        // fase 2: filas (envolvente inferior de parabolas)
        if (eF == null || eF.length < w) { eF = new int[w]; eV = new int[w]; eZ = new float[w + 1]; eRow = new int[w]; }
        int[] f = eF, v = eV, row = eRow;
        float[] z = eZ;
        for (int y = 0; y < h; y++) {
            int off = y * w;
            for (int x = 0; x < w; x++) {
                int g = out[off + x] & 0xFF;
                f[x] = g >= 255 ? 1 << 20 : g * g;
            }
            int k = 0;
            v[0] = 0;
            z[0] = Float.NEGATIVE_INFINITY;
            z[1] = Float.POSITIVE_INFINITY;
            for (int q = 1; q < w; q++) {
                float s;
                while (true) {
                    int p = v[k];
                    s = ((f[q] + q * q) - (float) (f[p] + p * p)) / (2f * (q - p));
                    if (s <= z[k] && k > 0) { k--; continue; }
                    if (s <= z[k]) { k = -1; }
                    break;
                }
                k++;
                v[k] = q;
                z[k] = k == 0 ? Float.NEGATIVE_INFINITY : s;
                z[k + 1] = Float.POSITIVE_INFINITY;
            }
            k = 0;
            for (int q = 0; q < w; q++) {
                while (z[k + 1] < q) k++;
                int p = v[k];
                int d2 = (q - p) * (q - p) + f[p];
                row[q] = d2;
            }
            for (int q = 0; q < w; q++) {
                int d2 = row[q];
                out[off + q] = d2 < 4096 ? QTAB[d2] : (byte) 255;
            }
        }
    }

    // ================== operacion (toque / estampa) ==================

    static final int WALL = 1, CORE = 2, ACL = 4, WVIS = 8, SOFT = 16, PAD = 32, SEEN = 64, BAD = 128;

    /** Clases de crecimiento: desde nucleo, bolsillo tocado a proposito, puente (ya borrado). */
    static final int CLS_NORMAL = 0, CLS_POCKET = 1, CLS_BRIDGE = 2;

    // entrada
    private int[] cur, snap;
    private byte[] sel;
    private int W, H;
    private Width wd;
    public int ref = 0xFFFFFFFF, tol = 46, mode = ColorDist.HUE;
    /** pincel: el color del COMIENZO del trazo tambien vale como fondo (0 = no) */
    public int ref2;
    /** escala de "Cerrar huecos" (1 = R normal) */
    public float gapScale = 1f;
    public boolean protect;
    public int protectColor, protectTol = 20;

    // rejilla
    public int gx0, gy0, gw, gh;
    private int wx0, wy0, wx1, wy1;
    private byte[] S, D, K, M;
    private int[] rqTile;
    private float hRef = 1.5f;

    // resultado
    public int rx0, ry0, rx1, ry1;
    public int claimed, banded, cored;
    public long lastMs;

    /**
     * v8.32: TRAMA COMO FONDO. Si tocas (o empiezas el pincel) sobre una trama de puntos, los
     * puntitos chicos cuentan como fondo y solo frenan las lineas (grupos de tinta grandes). Si
     * tocas el papel blanco, la trama sigue siendo dibujo (no se borra la trama del personaje).
     */
    public boolean tone, autoTone = true;
    private int toneThr = 128, toneR = 2, toneRefL = 128;

    /** Hay trama de puntos alrededor de (x,y)? (13x13: muchos puntitos chicos separados) */
    public boolean detectTone(int x0, int y0) {
        int r = 8;
        int xa = Math.max(0, x0 - r), xb = Math.min(W, x0 + r + 1), ya = Math.max(0, y0 - r), yb = Math.min(H, y0 + r + 1);
        int ww = xb - xa, wh = yb - ya;
        if (ww < 9 || wh < 9) return false;
        int[] L = new int[ww * wh];
        int mn = 255, mx = 0;
        for (int y = ya; y < yb; y++)
            for (int x = xa; x < xb; x++) {
                int c = colorOf(cur, snap, y * W + x);
                int l = (c >>> 24) < 32 ? 255 : lum(c);
                L[(y - ya) * ww + x - xa] = l;
                if (l < mn) mn = l;
                if (l > mx) mx = l;
            }
        if (mx - mn < 60) return false;
        int thr = (mx + mn) / 2;
        int ink = 0;
        for (int v : L) if (v < thr) ink++;
        int n = ww * wh;
        if (ink * 100 < n * 5 || ink * 100 > n * 65) return false;
        int adot = dotArea();
        byte[] seen = new byte[n];
        int[] st = new int[n];
        int comps = 0, big = 0;
        for (int s0 = 0; s0 < n; s0++) {
            if (seen[s0] != 0 || L[s0] >= thr) continue;
            int sp = 0, a = 0;
            st[sp++] = s0;
            seen[s0] = 1;
            while (sp > 0) {
                int q = st[--sp];
                a++;
                int qx = q % ww, qy = q / ww;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = qx + dx, yy = qy + dy;
                        if (xx < 0 || yy < 0 || xx >= ww || yy >= wh) continue;
                        int j = yy * ww + xx;
                        if (seen[j] != 0 || L[j] >= thr) continue;
                        seen[j] = 1;
                        st[sp++] = j;
                    }
            }
            comps++;
            if (a > adot) big++;
        }
        if (comps < 5 || big * 4 > comps) return false;
        toneThr = thr;
        // radio del promedio ~ separacion de los puntos; el gris de la trama tocada es la referencia
        double spacing = Math.sqrt(n / (double) comps);
        toneR = Math.max(2, Math.min(7, (int) Math.round(spacing)));
        long sum = 0;
        int cnt = 0;
        for (int y = Math.max(0, y0 - toneR); y <= Math.min(H - 1, y0 + toneR); y++)
            for (int x = Math.max(0, x0 - toneR); x <= Math.min(W - 1, x0 + toneR); x++) {
                int c = colorOf(cur, snap, y * W + x);
                sum += (c >>> 24) < 32 ? 255 : lum(c);
                cnt++;
            }
        toneRefL = (int) (sum / Math.max(1, cnt));
        return true;
    }

    /** Copia la trama detectada por otro motor (region global del pincel). */
    public void toneFrom(BgEngine o) { tone = o.tone; toneThr = o.toneThr; toneR = o.toneR; toneRefL = o.toneRefL; autoTone = false; }

    /**
     * Trama: marca en out (1) las LINEAS = grupos de tinta muy oscura (el tercio mas oscuro) mas
     * grandes que un punto de trama. Los nucleos oscuros de los puntos quedan separados aunque
     * la trama sea densa; las lineas del dibujo siguen unidas y frenan.
     */
    private void markLines(byte[] L, byte[] out) {
        int ww = wx1 - wx0, wh = wy1 - wy0;
        java.util.Arrays.fill(out, 0, gw * gh, (byte) 0);
        int dark = Math.max(20, toneThr - (255 - toneThr) / 3);
        int adot = dotArea();
        int[] st = new int[1024];
        int[] list = new int[adot + 2];
        for (int y = wy0; y < wy1; y++)
            for (int x = wx0; x < wx1; x++) {
                int g = gidx(x, y);
                if (out[g] != 0 || (L[g] & 0xFF) >= dark) continue;
                int sp = 0, a = 0;
                st[sp++] = g;
                out[g] = 2;
                while (sp > 0) {
                    int q = st[--sp];
                    if (a < list.length) list[a] = q;
                    a++;
                    int qx = q % gw + gx0, qy = q / gw + gy0;
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = qx + dx, yy = qy + dy;
                            if (xx < wx0 || yy < wy0 || xx >= wx1 || yy >= wy1) continue;
                            int j = gidx(xx, yy);
                            if (out[j] != 0 || (L[j] & 0xFF) >= dark) continue;
                            out[j] = 2;
                            if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                            st[sp++] = j;
                        }
                }
                // grande = linea (1); chico = punto de trama (3)
                if (a <= adot) for (int k = 0; k < a; k++) out[list[k]] = 3;
            }
        for (int g = 0; g < gw * gh; g++) if (out[g] == 2) out[g] = 1;
    }

    /** Promedio en un cuadrado de radio r (separable) dentro de la ventana. */
    private void boxMean(byte[] src, byte[] dst, int r) {
        int ww = wx1 - wx0, wh = wy1 - wy0;
        int[] tmp = new int[ww * wh];
        // borde en ESPEJO: una trama de puntos sigue igual de densa junto al limite (copiar la
        // ultima fila la oscurecia o aclaraba segun cayera un punto)
        int k = 2 * r + 1;
        for (int y = 0; y < wh; y++) {
            int g = gidx(wx0, wy0 + y);
            int acc = 0;
            for (int x = -r; x <= r; x++) acc += src[g + refl(x, ww)] & 0xFF;
            for (int x = 0; x < ww; x++) {
                tmp[y * ww + x] = acc * 16 / k;
                acc += (src[g + refl(x + r + 1, ww)] & 0xFF) - (src[g + refl(x - r, ww)] & 0xFF);
            }
        }
        for (int x = 0; x < ww; x++) {
            int acc = 0;
            for (int y = -r; y <= r; y++) acc += tmp[refl(y, wh) * ww + x];
            for (int y = 0; y < wh; y++) {
                dst[gidx(wx0 + x, wy0 + y)] = (byte) Math.min(255, acc / k / 16);
                acc += tmp[refl(y + r + 1, wh) * ww + x] - tmp[refl(y - r, wh) * ww + x];
            }
        }
    }

    static int refl(int i, int n) {
        if (n == 1) return 0;
        while (i < 0 || i >= n) i = i < 0 ? -i - 1 : 2 * n - 1 - i;
        return i;
    }

    /** Tamano maximo de un puntito de trama (px). */
    int dotArea() {
        int d = Math.round(3 * wd.hGlobal);
        return Math.max(12, d * d);
    }

    /** tipo de semilla usada en el ultimo toque: 0 nada, 1 nucleo, 2 bolsillo */
    public int seedKind;

    // colas
    private int[] qa = new int[1 << 14], qb = new int[1 << 14];
    private int qh, qt;

    public void setImage(int[] cur, int[] snap, int w, int h, Width wd, byte[] sel) {
        this.cur = cur;
        this.snap = snap != null && snap.length == cur.length ? snap : null;
        this.W = w;
        this.H = h;
        this.wd = wd != null ? wd : new Width();
        this.sel = sel;
    }

    public Width width() { return wd; }

    /** Radio de la pelota (px) para la zona de (x,y). */
    public int radiusAt(int x, int y) {
        float hh = wd.hAt(x, y);
        int rmax = Math.max(6, Math.min(W, H) / 60);
        // hueco que se cierra ~ 2 veces el grosor de la linea + 2 px (minimo 5 px)
        int r = Math.round((2f * hh + 1.5f) * gapScale);
        return Math.max(gapScale < 0.95f ? 2 : 3, Math.min(rmax, r));
    }

    int maxRadius() {
        int rmax = Math.max(6, Math.min(W, H) / 60);
        return Math.max(3, Math.min(rmax, Math.round((2f * maxH() + 1.5f) * gapScale)));
    }

    float maxH() {
        float m = wd.hGlobal;
        if (wd.hq != null) for (byte b : wd.hq) m = Math.max(m, (b & 0xFF) / 4f);
        return m;
    }

    private boolean ensure(int n) {
        if (S == null || S.length < n) {
            S = null; D = null; K = null; M = null;
            S = new byte[n];
            D = new byte[n];
            K = new byte[n];
            M = new byte[n];
            return true;
        }
        return false;
    }

    /** Libera la memoria grande (al salir de Borrar fondo). */
    public void release() {
        S = D = K = M = null;
        qa = new int[1 << 14];
        qb = new int[1 << 14];
    }

    /** Toque: todo el fondo unido al punto, sin cruzar lineas ni huecos chicos. */
    public boolean tap(int sx, int sy) {
        long t0 = System.nanoTime();
        if (autoTone) tone = detectTone(sx, sy);
        int P = maxRadius() + 3;
        setup(0, 0, W, H, P);
        classify();
        edtI(walls(), gw, gh, D);
        markCore();
        localWidth();
        int s = seedFrom(sx, sy, true);
        boolean ok = s >= 0;
        if (ok) {
            grow();
            output(null);
        } else {
            rx0 = ry0 = 0; rx1 = ry1 = 0;
        }
        lastMs = (System.nanoTime() - t0) / 1000000;
        return ok && rx1 > rx0;
    }

    /**
     * Solo el analisis del toque (sin alfa): marca en bits (W*H) la region de fondo unida a
     * (sx,sy). Lo usa el pincel para reconocer el MISMO fondo cuando el dedo vuelve a el despues
     * de pasar por encima del personaje. Devuelve la cantidad de pixeles marcados.
     */
    public int region(int sx, int sy, long[] bits) {
        long t0 = System.nanoTime();
        int P = maxRadius() + 3;
        setup(0, 0, W, H, P);
        classify();
        edtI(walls(), gw, gh, D);
        markCore();
        localWidth();
        int cnt = 0;
        if (seedFrom(sx, sy, true) >= 0) {
            growQueue();
            for (int y = 0; y < H; y++) {
                int g = gidx(0, y), off = y * W;
                for (int x = 0; x < W; x++, g++)
                    if ((S[g] & ACL) != 0) { int i = off + x; bits[i >>> 6] |= 1L << (i & 63); cnt++; }
            }
        }
        lastMs = (System.nanoTime() - t0) / 1000000;
        return cnt;
    }

    static boolean bit(long[] b, int i) { return (b[i >>> 6] & (1L << (i & 63))) != 0; }

    /** Region global (del toque) que el pincel puede usar como semilla; null = no hay. */
    public long[] global;

    /**
     * Estampa del pincel protegido: analiza una ventana alrededor del circulo. accept (W*H, puede
     * ser null) guarda lo aceptado en las estampas anteriores del mismo trazo (1 + "m" en cuartos
     * de px, 255 = nucleo): solo se avanza desde ahi, desde lo ya borrado y, en la primera estampa,
     * desde el dedo. Devuelve true si hay algo que borrar dentro del circulo.
     */
    public boolean dab(float cx, float cy, float rad, boolean first, byte[] accept) {
        return dabSeg(cx, cy, cx, cy, rad, first, accept);
    }

    /**
     * v8.49b: un TRAMO del pincel (capsula del punto a al punto b) analizado de una vez. Antes cada
     * estampa (cada medio radio) analizaba su propia ventana y las ventanas se pisaban casi enteras:
     * el mismo trabajo se repetia 2-3 veces. El resultado es el mismo trazo continuo, sin huecos.
     */
    public boolean dabSeg(float ax, float ay, float cx, float cy, float rad, boolean first, byte[] accept) {
        long t0 = System.nanoTime();
        int R = maxRadius();
        int MG = Math.max(8, 3 * R + 4);
        int x0 = Math.max(0, (int) Math.floor(Math.min(ax, cx) - rad) - MG), y0 = Math.max(0, (int) Math.floor(Math.min(ay, cy) - rad) - MG);
        int x1 = Math.min(W, (int) Math.ceil(Math.max(ax, cx) + rad) + 1 + MG), y1 = Math.min(H, (int) Math.ceil(Math.max(ay, cy) + rad) + 1 + MG);
        if (x1 <= x0 || y1 <= y0) return false;
        setup(x0, y0, x1, y1, R + 3);
        classify();
        edtI(walls(), gw, gh, D);
        markCore();
        localWidth();
        boolean any = false;
        qh = qt = 0;
        // semillas: lo aceptado antes en este trazo
        if (accept != null) {
            for (int y = wy0; y < wy1; y++) {
                int off = y * W;
                for (int x = wx0; x < wx1; x++) {
                    int a = accept[off + x] & 0xFF;
                    if (a == 0) continue;
                    int g = gidx(x, y);
                    int st = S[g];
                    if ((st & (WALL | ACL | PAD)) != 0) continue;
                    if ((st & CORE) != 0) { floodCore(g); any = true; continue; }
                    int mm = a >= 255 ? M[g] & 0xFF : Math.min(a - 1, M[g] & 0xFF);
                    S[g] |= ACL;
                    push(g, pack(D[g] & 0xFF, mm, 0, CLS_NORMAL));
                    any = true;
                }
            }
        }
        // puente: lo ya borrado (que era fondo de este color) y la region global del mismo fondo
        long[] gb = global;
        for (int y = wy0; y < wy1; y++) {
            int off = y * W;
            for (int x = wx0; x < wx1; x++) {
                if ((cur[off + x] >>> 24) >= 32 && (gb == null || !bit(gb, off + x))) continue;
                int g = gidx(x, y);
                int st = S[g];
                if ((st & (WALL | ACL | PAD)) != 0) continue;
                if ((st & CORE) != 0) { floodCore(g); any = true; continue; }
                S[g] |= ACL;
                push(g, pack(D[g] & 0xFF, M[g] & 0xFF, 0, CLS_BRIDGE));
                any = true;
            }
        }
        if (first && !any) {
            // el dedo puede ir por fuera del lienzo, pegado al borde: se empieza en el punto mas cercano
            int cxi = Math.max(0, Math.min(W - 1, (int) cx)), cyi = Math.max(0, Math.min(H - 1, (int) cy));
            if (seedFrom(cxi, cyi, false) >= 0) any = true;
        }
        if (!any) { rx1 = rx0; lastMs = (System.nanoTime() - t0) / 1000000; return false; }
        growQueue();
        // lo aceptado de esta ventana queda para la estampa siguiente
        if (accept != null) {
            for (int y = wy0; y < wy1; y++) {
                int off = y * W;
                int g = gidx(wx0, y);
                for (int x = wx0; x < wx1; x++, g++) {
                    int st = S[g];
                    if ((st & ACL) == 0) continue;
                    int v = (st & CORE) != 0 ? 255 : Math.min(254, 1 + (K[g] & 0xFF));
                    int old = accept[off + x] & 0xFF;
                    // nucleo en alguna ventana -> nucleo; si no, el "m" mas chico (no sube trazo a trazo)
                    int nv = old == 0 ? v : (old == 255 || v == 255) ? 255 : Math.min(old, v);
                    accept[off + x] = (byte) nv;
                }
            }
        }
        output(new float[]{ax, ay, cx, cy, rad});
        lastMs = (System.nanoTime() - t0) / 1000000;
        return rx1 > rx0;
    }

    private void setup(int x0, int y0, int x1, int y1, int P) {
        wx0 = x0; wy0 = y0; wx1 = x1; wy1 = y1;
        gx0 = x0 - P; gy0 = y0 - P;
        gw = (x1 - x0) + 2 * P;
        gh = (y1 - y0) + 2 * P;
        ensure(gw * gh);
        java.util.Arrays.fill(S, 0, gw * gh, (byte) 0);
        java.util.Arrays.fill(K, 0, gw * gh, (byte) 255);
        hRef = (x0 == 0 && y0 == 0 && x1 == W && y1 == H) ? wd.hGlobal : wd.hAt((x0 + x1) / 2, (y0 + y1) / 2);
        hRef = Math.min(hRef, maxHalfWidth(W, H));
        claimed = banded = cored = 0;
        seedKind = 0;
        qh = qt = 0;
    }

    int gidx(int x, int y) { return (y - gy0) * gw + (x - gx0); }

    private byte[] walls() {
        // D se usa como rasgo de entrada (1 = muro) y luego se sobrescribe con la distancia
        int n = gw * gh;
        byte[] f = K;
        for (int g = 0; g < n; g++) f[g] = (byte) ((S[g] & WALL) != 0 ? 1 : 0);
        return f;
    }

    /** Clasifica fondo / muro en la ventana y rellena el margen (copia en el borde del lienzo). */
    private void classify() {
        int lr = lum(ref | 0xFF000000);
        int lim = tol;
        int rb = Math.max(2, Math.min(12, (int) Math.ceil(2 * hRef) + 1));
        int DB = 30;
        // brillo de la ventana (los ya borrados cuentan como el fondo) y su maximo local
        int ww = wx1 - wx0, wh = wy1 - wy0;
        byte[] Lb = K, Mx = D;
        for (int y = wy0; y < wy1; y++) {
            int g = gidx(wx0, y);
            for (int x = wx0; x < wx1; x++, g++) {
                int i = y * W + x;
                int c = colorOf(cur, snap, i);
                // lo ya borrado cuenta como el fondo (en trama: como el gris de la trama)
                Lb[g] = (byte) ((c >>> 24) < 32 || (tone && (cur[i] >>> 24) < 32) ? (tone ? toneRefL : lr) : lum(c));
            }
        }
        if (tone) { boxMean(Lb, M, toneR); markLines(Lb, Mx); }
        else maxFilter(Lb, Mx, rb);
        boolean dr = drift && !tone;
        if (dr) java.util.Arrays.fill(M, 0, gw * gh, (byte) 0);
        int nCand = 0;
        for (int y = wy0; y < wy1; y++) {
            int g = gidx(wx0, y);
            for (int x = wx0; x < wx1; x++, g++) {
                int i = y * W + x;
                int st = 0;
                int c = colorOf(cur, snap, i);
                int ca = cur[i] >>> 24;
                if ((c >>> 24) < 32) {
                    st = 0;                       // transparente desde antes: libre
                } else if (tone && ca < 32) {
                    st = 0;                       // trama: lo ya borrado es fondo
                } else if (tone) {
                    // trama tocada: se compara el GRIS PROMEDIO (puntos + papel) con el de la trama;
                    // una linea (mas oscura en promedio) o el papel blanco quedan como muro
                    st = Math.abs((M[g] & 0xFF) - toneRefL) > lim * 3 / 5 || Mx[g] == 1 ? WALL : 0;
                } else {
                    int d = bgDist(c, ref);
                    if (ref2 != 0) {
                        // color seguido por el pincel: vale con 3/4 de la tolerancia (el del comienzo,
                        // entera). Asi el color seguido no se come algo del personaje casi igual al fondo.
                        int d2 = bgDist(c, ref2);
                        d = d2 <= lim ? d2 : (d * 4 + 2) / 3;
                    }
                    if (d > lim) {
                        st = WALL;
                        // pincel: candidato a fondo que cambia DE A POCO (cueva que se aclara)
                        // (solo cambia el BRILLO o poco el tono: la mano verde oscura no es "cueva mas oscura")
                        if (dr && d <= lim + DRIFT && hueDist(c, ref2 != 0 ? ref2 : ref) <= lim * 3 / 4 && hueDist(c, ref) <= lim * 3 / 4) {
                            int l = Lb[g] & 0xFF, mx = Mx[g] & 0xFF;
                            if (!(l + DB <= mx && l + DB / 2 <= lr && l * 10 <= mx * 6)) { M[g] = 1; nCand++; }
                        }
                    } else {
                        int l = Lb[g] & 0xFF, mx = Mx[g] & 0xFF;
                        // linea oscura fina con color "de fondo" (cueva oscura): tambien es muro
                        if (!tone && l + DB <= mx && l + DB / 2 <= lr && l * 10 <= mx * 6) st = WALL | SOFT;
                    }
                    if (st == 0 && protect && ColorDist.dist(c | 0xFF000000, protectColor | 0xFF000000, mode) <= protectTol) st = WALL;
                    if (ca < 32 && (st & WALL) != 0 && (st & SOFT) == 0) {
                        // ya borrado pero era de otro color: no sirve de puente
                        st = WALL;
                    }
                }
                if (sel != null && (sel[i] & 0xFF) == 0) { st = WALL; if (dr) M[g] = 0; }
                if (dr && M[g] == 1 && protect && ColorDist.dist(c | 0xFF000000, protectColor | 0xFF000000, mode) <= protectTol) M[g] = 0;
                S[g] = (byte) st;
            }
        }
        if (dr && nCand > 0) driftFree();
        // MARGEN. En el borde del lienzo: copia del borde (el papel sigue afuera; una linea que
        // llega al borde sigue siendo muro afuera). En un corte INTERIOR de la ventana del pincel
        // no se sabe que hay: se marca "no confiable" (PAD) junto con la franja de 2R+2 px de
        // adentro. Lo no confiable no se recorre (no une regiones por fuera ni parece angosto) y
        // para la distancia cuenta como libre (no inventa paredes).
        int T = 2 * maxRadius() + 2;
        boolean cutL = wx0 > 0, cutR = wx1 < W, cutT = wy0 > 0, cutB = wy1 < H;
        for (int gy = 0; gy < gh; gy++) {
            int y = gy + gy0;
            boolean outY = y < wy0 || y >= wy1;
            for (int gx = 0; gx < gw; gx++) {
                int x = gx + gx0;
                boolean outX = x < wx0 || x >= wx1;
                int g = gy * gw + gx;
                if (!outX && !outY) {
                    if ((cutL && x < wx0 + T) || (cutR && x >= wx1 - T) || (cutT && y < wy0 + T) || (cutB && y >= wy1 - T))
                        S[g] = (byte) (S[g] | PAD);
                    continue;
                }
                boolean cut = (x < wx0 && cutL) || (x >= wx1 && cutR) || (y < wy0 && cutT) || (y >= wy1 && cutB);
                int st;
                if (cut) st = PAD;
                else {
                    int cx = Math.max(wx0, Math.min(wx1 - 1, x)), cy = Math.max(wy0, Math.min(wy1 - 1, y));
                    st = (S[gidx(cx, cy)] & (WALL | SOFT | PAD));
                }
                S[g] = (byte) st;
            }
        }
    }

    /** v8.32: el pincel sigue un fondo que cambia de a poco (hasta tolerancia + DRIFT del color tomado). */
    public boolean drift;
    static final int DRIFT = 42, DRIFT_STEP = 12;

    /**
     * Candidatos (M = 1) que se unen al fondo libre por pasos de color de hasta DRIFT_STEP entre
     * vecinos: un degradado suave del fondo pasa; el borde del personaje (salto de color) no.
     */
    private void driftFree() {
        qh = qt = 0;
        for (int y = wy0; y < wy1; y++) {
            int g = gidx(wx0, y);
            for (int x = wx0; x < wx1; x++, g++) {
                if ((S[g] & WALL) != 0) continue;
                int gx = g % gw, gy = g / gw;
                if ((gx > 0 && M[g - 1] == 1) || (gx < gw - 1 && M[g + 1] == 1) || (gy > 0 && M[g - gw] == 1) || (gy < gh - 1 && M[g + gw] == 1))
                    push(g, 0);
            }
        }
        while (qh < qt) {
            int g = qa[qh++];
            int gx = g % gw, gy = g / gw;
            int x = gx + gx0, y = gy + gy0;
            int c = colorOf(cur, snap, y * W + x);
            for (int k = 0; k < 4; k++) {
                int nx = gx + (k == 0 ? -1 : k == 1 ? 1 : 0), ny = gy + (k == 2 ? -1 : k == 3 ? 1 : 0);
                if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
                int j = ny * gw + nx;
                if (M[j] != 1) continue;
                int xx = nx + gx0, yy = ny + gy0;
                int q = colorOf(cur, snap, yy * W + xx);
                // paso medido con tono (un borde de color con poco contraste NO es un paso suave)
                if (bgDist(q, c) > DRIFT_STEP) continue;
                M[j] = 2;
                S[j] = (byte) (S[j] & ~WALL);
                push(j, 0);
            }
        }
        qh = qt = 0;
    }

    private int[] mfA, mfB;

    /** Maximo en un cuadrado de radio r (separable, van Herk/Gil-Werman) solo dentro de la ventana. */
    private void maxFilter(byte[] src, byte[] dst, int r) {
        int ww = wx1 - wx0, wh = wy1 - wy0;
        int L = Math.max(ww, wh) + 4 * r + 4;
        if (mfA == null || mfA.length < L) { mfA = new int[L]; mfB = new int[L]; }
        int[] line = new int[Math.max(ww, wh)];
        int[] outl = new int[Math.max(ww, wh)];
        // filas -> dst
        for (int y = wy0; y < wy1; y++) {
            int g = gidx(wx0, y);
            for (int x = 0; x < ww; x++) line[x] = src[g + x] & 0xFF;
            maxLine(line, ww, r, outl);
            for (int x = 0; x < ww; x++) dst[g + x] = (byte) outl[x];
        }
        // columnas (en dst)
        for (int x = wx0; x < wx1; x++) {
            int g = gidx(x, wy0);
            for (int y = 0; y < wh; y++) line[y] = dst[g + y * gw] & 0xFF;
            maxLine(line, wh, r, outl);
            for (int y = 0; y < wh; y++) dst[g + y * gw] = (byte) outl[y];
        }
    }

    private void maxLine(int[] a, int n, int r, int[] out) {
        maxLineS(a, n, r, out, mfA, mfB);
    }

    /**
     * Ancho local M = la distancia mas grande cerca (radio ~R/2). El crecimiento hacia las puntas
     * mira M y no D: despues de pasar por un hueco, pegado a la pared del otro lado D es chico
     * (parece que "se sigue angostando") pero M ya ve lo ancho de adentro y frena.
     */
    private void localWidth() {
        int r = Math.max(2, (maxRadius() + 1) / 2 + 1);
        int L = Math.max(gw, gh) + 2 * r + 4;
        if (mfA == null || mfA.length < L) { mfA = new int[L]; mfB = new int[L]; }
        int[] line = new int[Math.max(gw, gh)], out = new int[Math.max(gw, gh)];
        for (int y = 0; y < gh; y++) {
            int off = y * gw;
            for (int x = 0; x < gw; x++) line[x] = (S[off + x] & WALL) != 0 ? 0 : D[off + x] & 0xFF;
            maxLineS(line, gw, r, out, mfA, mfB);
            for (int x = 0; x < gw; x++) M[off + x] = (byte) out[x];
        }
        for (int x = 0; x < gw; x++) {
            for (int y = 0; y < gh; y++) line[y] = M[y * gw + x] & 0xFF;
            maxLineS(line, gh, r, out, mfA, mfB);
            for (int y = 0; y < gh; y++) M[y * gw + x] = (byte) out[y];
        }
    }

    private void markCore() {
        // radio por zona (cuartos de px)
        int tw = wd.tw > 0 ? wd.tw : 1;
        for (int gy = 0; gy < gh; gy++) {
            int y = Math.max(0, Math.min(H - 1, gy + gy0));
            int off = gy * gw;
            int lastTx = -1, rq = 0;
            for (int gx = 0; gx < gw; gx++) {
                int g = off + gx;
                int st = S[g];
                if ((st & (WALL | PAD)) != 0) continue;
                int x = Math.max(0, Math.min(W - 1, gx + gx0));
                int tx = x / TILE;
                if (tx != lastTx) { lastTx = tx; rq = 4 * radiusAt(x, y); }
                if ((D[g] & 0xFF) > rq) S[g] = (byte) (st | CORE);
            }
        }
    }

    /** Estado del crecimiento: m = D minima, mm = ancho local M minimo, f = pasos parejos, clase. */
    private static int pack(int m, int mm, int f, int cls) { return (m & 0xFF) | ((mm & 0xFF) << 8) | (Math.min(f, 63) << 16) | (cls << 22); }

    private void push(int g, int v) {
        if (qt == qa.length) {
            if (qh > 0 && qh >= qa.length / 2) {
                System.arraycopy(qa, qh, qa, 0, qt - qh);
                System.arraycopy(qb, qh, qb, 0, qt - qh);
                qt -= qh; qh = 0;
            } else {
                qa = java.util.Arrays.copyOf(qa, qa.length * 2);
                qb = java.util.Arrays.copyOf(qb, qb.length * 2);
            }
        }
        qa[qt] = g;
        qb[qt] = v;
        qt++;
    }

    /** Rellena todo el nucleo unido a g (4 vecinos) y marca ACL. */
    private void floodCore(int g0) {
        int[] st = new int[1024];
        int sp = 0;
        st[sp++] = g0;
        S[g0] |= ACL;
        while (sp > 0) {
            int g = st[--sp];
            cored++;
            int gx = g % gw, gy = g / gw;
            for (int k = 0; k < 4; k++) {
                int nx = gx + (k == 0 ? -1 : k == 1 ? 1 : 0), ny = gy + (k == 2 ? -1 : k == 3 ? 1 : 0);
                if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
                int j = ny * gw + nx;
                int s = S[j];
                if ((s & CORE) == 0 || (s & ACL) != 0) continue;
                S[j] = (byte) (s | ACL);
                if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                st[sp++] = j;
            }
        }
    }

    /**
     * Punto inicial del toque (o primera estampa): en el nucleo -> todo su nucleo; en un lugar
     * angosto -> sube por la distancia hasta el centro del bolsillo (o hasta un nucleo).
     */
    private int seedFrom(int sx, int sy, boolean tap) {
        if (sx < wx0 || sy < wy0 || sx >= wx1 || sy >= wy1) return -1;
        int g = gidx(sx, sy);
        if ((S[g] & WALL) != 0) {
            // tocaste la linea: el libre mas cercano en 2 px (no se adivina mas lejos)
            int best = -1, bd = 99;
            for (int dy = -2; dy <= 2; dy++)
                for (int dx = -2; dx <= 2; dx++) {
                    int x = sx + dx, y = sy + dy;
                    if (x < wx0 || y < wy0 || x >= wx1 || y >= wy1) continue;
                    int j = gidx(x, y);
                    if ((S[j] & (WALL | PAD)) != 0) continue;
                    int d = dx * dx + dy * dy;
                    if (d < bd) { bd = d; best = j; }
                }
            if (best < 0) return -1;
            g = best;
        }
        // subir por la distancia
        for (int it = 0; it < 4096; it++) {
            if ((S[g] & CORE) != 0) break;
            int gx = g % gw, gy = g / gw, bestJ = -1, bv = D[g] & 0xFF;
            for (int dy = -1; dy <= 1; dy++)
                for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int nx = gx + dx, ny = gy + dy;
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
                    if (dx != 0 && dy != 0) {
                        // diagonal solo si no pasa entre dos muros que se tocan
                        if ((S[gy * gw + nx] & WALL) != 0 && (S[ny * gw + gx] & WALL) != 0) continue;
                    }
                    int j = ny * gw + nx;
                    if ((S[j] & (WALL | PAD)) != 0) continue;
                    int v = D[j] & 0xFF;
                    if (v > bv) { bv = v; bestJ = j; }
                }
            if (bestJ < 0) break;
            g = bestJ;
        }
        qh = qt = 0;
        if ((S[g] & CORE) != 0) {
            floodCore(g);
            seedKind = 1;
        } else {
            S[g] |= ACL;
            push(g, pack(D[g] & 0xFF, M[g] & 0xFF, 0, CLS_POCKET));
            seedKind = 2;
        }
        return g;
    }

    /** Crecimiento desde el nucleo aceptado (y semillas en cola). */
    private void grow() {
        growQueue();
    }

    private void growQueue() {
        int n = gw * gh;
        // frente del nucleo aceptado
        for (int g = 0; g < n; g++) {
            int st = S[g];
            if ((st & (ACL | CORE)) != (ACL | CORE)) continue;
            int gx = g % gw, gy = g / gw;
            boolean front = false;
            if (gx > 0 && (S[g - 1] & (CORE | WALL | ACL)) == 0) front = true;
            else if (gx < gw - 1 && (S[g + 1] & (CORE | WALL | ACL)) == 0) front = true;
            else if (gy > 0 && (S[g - gw] & (CORE | WALL | ACL)) == 0) front = true;
            else if (gy < gh - 1 && (S[g + gw] & (CORE | WALL | ACL)) == 0) front = true;
            if (front) push(g, pack(D[g] & 0xFF, M[g] & 0xFF, 0, CLS_NORMAL));
        }
        int flatN = (int) Math.ceil(hRef) + 2;
        while (qh < qt) {
            int g = qa[qh], v = qb[qh];
            qh++;
            int m = v & 0xFF, mm = (v >>> 8) & 0xFF, f = (v >>> 16) & 63, cls = v >>> 22;
            // para la estampa siguiente: guarda mm (cuartos de px) en K mientras crece
            if ((S[g] & CORE) == 0) K[g] = (byte) Math.min(254, mm);
            int gx = g % gw, gy = g / gw;
            int slack = cls == CLS_BRIDGE ? 0 : 2;
            int fmax = cls == CLS_POCKET ? 64 : flatN;
            for (int k = 0; k < 4; k++) {
                int nx = gx + (k == 0 ? -1 : k == 1 ? 1 : 0), ny = gy + (k == 2 ? -1 : k == 3 ? 1 : 0);
                if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
                int j = ny * gw + nx;
                int s = S[j];
                if ((s & (WALL | CORE | ACL | PAD)) != 0) continue;
                // 1) distancia D: puede angostarse; pareja solo unos pasos (pasillo); no ensancharse
                int dq = D[j] & 0xFF;
                int m2, f2;
                if (dq < m) { m2 = dq; f2 = 0; }
                else if (dq <= m + slack) { m2 = m; f2 = f + 1; if (f2 > fmax) continue; }
                else continue;
                // 2) ancho local M: nunca vuelve a ensancharse (salir por un hueco pegado a la pared)
                int mq = M[j] & 0xFF;
                if (mq > mm + 2) continue;
                int mm2 = Math.min(mm, mq);
                S[j] = (byte) (s | ACL);
                claimed++;
                push(j, pack(m2, mm2, Math.min(f2, 63), cls));
            }
        }
        qh = qt = 0;
    }

    /** Alfa final: banda desmezclada junto al muro y la linea hasta su parte mas oscura. */
    private void output(float[] disc) {
        int n = gw * gh;
        int lr = ref | 0xFF000000;
        float h = hRef;
        int bandQ = (int) (4 * (h + 1.5f));
        // la banda entra en la linea/borde solo lo que mide su antialias (1 px; 2 si la imagen es grande):
        // mas adentro una SOMBRA del personaje parecia "mezcla con el fondo" y se mordia (nariz del duende)
        int nw = Math.max(1, Math.round(0.6f * h));
        rx0 = Integer.MAX_VALUE; ry0 = Integer.MAX_VALUE; rx1 = Integer.MIN_VALUE; ry1 = Integer.MIN_VALUE;
        // disco {x, y, r} o capsula {ax, ay, bx, by, r}
        float dax = 0, day = 0, dcx = 0, dcy = 0, rr = 0, sx = 0, sy = 0, sl2 = 0;
        if (disc != null) {
            boolean cap = disc.length >= 5;
            dax = disc[0]; day = disc[1];
            dcx = cap ? disc[2] : disc[0]; dcy = cap ? disc[3] : disc[1];
            float r = cap ? disc[4] : disc[2];
            rr = (r + 0.5f) * (r + 0.5f);
            sx = dcx - dax; sy = dcy - day; sl2 = sx * sx + sy * sy;
        }
        // K todavia tiene "m"; se reinicia a 255 (conservar) y se llena
        java.util.Arrays.fill(K, 0, n, (byte) 255);
        // primero los restos encerrados (motas, grietas): asi no sirven de "color del dibujo"
        // para desmezclar el papel de al lado (dejaban puntitos a medio borrar)
        softCracks();
        qh = qt = 0;
        for (int y = wy0; y < wy1; y++) {
            int g = gidx(wx0, y);
            for (int x = wx0; x < wx1; x++, g++) {
                int st = S[g];
                if ((st & ACL) == 0) continue;
                int i = y * W + x;
                int k;
                if ((cur[i] >>> 24) < 32) k = 0;
                else if ((D[g] & 0xFF) <= bandQ) { k = unmixKeep(g, x, y, true); banded++; }
                else k = 0;
                K[g] = (byte) k;
                // a la linea vecina
                int gx = g % gw, gy = g / gw;
                for (int q = 0; q < 4; q++) {
                    int nx = gx + (q == 0 ? -1 : q == 1 ? 1 : 0), ny = gy + (q == 2 ? -1 : q == 3 ? 1 : 0);
                    int j = ny * gw + nx;
                    int s = S[j];
                    if ((s & WALL) == 0 || (s & (WVIS | PAD)) != 0) continue;
                    int xx = nx + gx0, yy = ny + gy0;
                    if (xx < wx0 || yy < wy0 || xx >= wx1 || yy >= wy1) continue;
                    S[j] = (byte) (s | WVIS);
                    int dB = dist2(colorOf(cur, snap, yy * W + xx), lr);
                    push(j, (1 << 24) | Math.min(0xFFFFFF, dB));
                }
            }
        }
        // linea: hasta nw pasos, mientras se aleja del color del fondo (no pasa la cresta)
        while (qh < qt) {
            int g = qa[qh], v = qb[qh];
            qh++;
            int depth = v >>> 24, dB = v & 0xFFFFFF;
            int gx = g % gw, gy = g / gw;
            int x = gx + gx0, y = gy + gy0;
            int k = unmixKeep(g, x, y, false);
            if (k < (K[g] & 0xFF)) K[g] = (byte) k;
            banded++;
            if (k >= 250 || depth >= nw) continue;
            for (int q = 0; q < 4; q++) {
                int nx = gx + (q == 0 ? -1 : q == 1 ? 1 : 0), ny = gy + (q == 2 ? -1 : q == 3 ? 1 : 0);
                int j = ny * gw + nx;
                int s = S[j];
                if ((s & WALL) == 0 || (s & (WVIS | PAD)) != 0) continue;
                int xx = nx + gx0, yy = ny + gy0;
                if (xx < wx0 || yy < wy0 || xx >= wx1 || yy >= wy1) continue;
                int d2 = dist2(colorOf(cur, snap, yy * W + xx), lr);
                // cresta: si vuelve a parecerse al fondo, ya es el otro lado de la linea
                if (Math.sqrt(d2) + 6 < Math.sqrt(dB)) continue;
                S[j] = (byte) (s | WVIS);
                push(j, ((depth + 1) << 24) | Math.min(0xFFFFFF, d2));
            }
        }
        qh = qt = 0;
        // caja de cambios (y circulo del pincel)
        for (int y = wy0; y < wy1; y++) {
            int g = gidx(wx0, y);
            for (int x = wx0; x < wx1; x++, g++) {
                if ((K[g] & 0xFF) == 255) continue;
                if (disc != null) {
                    float px = x + 0.5f - dax, py = y + 0.5f - day;
                    float t = sl2 > 1e-6f ? Math.max(0f, Math.min(1f, (px * sx + py * sy) / sl2)) : 0f;
                    float dx = px - sx * t, dy = py - sy * t;
                    if (dx * dx + dy * dy > rr) { K[g] = (byte) 255; continue; }
                }
                if (x < rx0) rx0 = x;
                if (y < ry0) ry0 = y;
                if (x >= rx1) rx1 = x + 1;
                if (y >= ry1) ry1 = y + 1;
            }
        }
        if (rx1 < rx0) { rx0 = ry0 = rx1 = ry1 = 0; }
    }

    /**
     * Restos encerrados por el fondo aceptado (todo lo que los rodea es fondo aceptado):
     *  - grietas oscuras del fondo (muro solo por "linea oscura", color parecido al fondo), polvo
     *    claro y papel suelto encerrado por ese polvo, hasta 4096 px: son del fondo, se borran;
     *  - motas de otro color (ruido del JPEG, puntitos) de hasta (1,5 h)^2 px (minimo 6).
     * Un grupo que toca algo no aceptado (el dibujo) o el corte de la ventana se conserva siempre.
     */
    private void softCracks() {
        int n = gw * gh;
        int cap = 4096;
        int hr = Math.round(1.5f * hRef);
        int speck = Math.max(6, hr * hr);
        if (tone) speck = Math.max(speck, dotArea());
        int[] st = new int[256];
        int[] list = new int[256];
        for (int g0 = 0; g0 < n; g0++) {
            int s0 = S[g0];
            if ((s0 & (ACL | SEEN | PAD)) != 0) continue;
            int gx0 = g0 % gw, gy0 = g0 / gw;
            // solo grupos pegados al fondo aceptado
            boolean touch = (gx0 > 0 && (S[g0 - 1] & ACL) != 0) || (gx0 < gw - 1 && (S[g0 + 1] & ACL) != 0)
                    || (gy0 > 0 && (S[g0 - gw] & ACL) != 0) || (gy0 < gh - 1 && (S[g0 + gw] & ACL) != 0);
            if (!touch) continue;
            int cn = 0, sp = 0;
            boolean ok = true, hard = false;
            st[sp++] = g0;
            S[g0] |= SEEN;
            while (sp > 0) {
                int g = st[--sp];
                if (cn == list.length) list = java.util.Arrays.copyOf(list, cn * 2);
                list[cn++] = g;
                int sg = S[g];
                if ((sg & WALL) != 0 && (sg & SOFT) == 0) hard = true;
                if (cn > (hard ? speck : cap)) { ok = false; break; }
                int gx = g % gw, gy = g / gw;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        int nx = gx + dx, ny = gy + dy;
                        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) { ok = false; continue; }
                        int j = ny * gw + nx;
                        int s = S[j];
                        if ((s & ACL) != 0) continue;
                        if ((s & PAD) != 0 || (s & BAD) != 0) { ok = false; continue; }
                        if ((s & SEEN) != 0) continue;
                        S[j] = (byte) (s | SEEN);
                        if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                        st[sp++] = j;
                    }
            }
            if (!ok) {
                // grupo grande o que toca el dibujo: todo lo visto queda marcado (no se reparte)
                while (sp > 0) S[st[--sp]] |= (byte) (SEEN | BAD);
                for (int q = 0; q < cn; q++) S[list[q]] |= (byte) BAD;
                continue;
            }
            for (int q = 0; q < cn; q++) K[list[q]] = 0;
        }
    }

    /**
     * Distancia al color del fondo. Con el modo de tono (el normal de Borrar fondo) el TONO pesa
     * hasta 3 veces si hay algo de color: en colores oscuros la diferencia de tono es chica en
     * numeros pero se ve (la mano verde oscura del duende contra la cueva gris). En grises casi
     * puros pesa 1 vez (el ruido de color del JPEG no es borde).
     */
    int bgDist(int c, int r) {
        if (mode != ColorDist.HUE) return ColorDist.dist(c | 0xFF000000, r | 0xFF000000, mode);
        int ar = (c >> 16) & 255, ag = (c >> 8) & 255, ab = c & 255;
        int br = (r >> 16) & 255, bg = (r >> 8) & 255, bb = r & 255;
        int m = Math.max(Math.abs(ar - br), Math.max(Math.abs(ag - bg), Math.abs(ab - bb)));
        int h1 = Math.abs((ar - ag) - (br - bg)), h2 = Math.abs((ab - ag) - (bb - bg)), h3 = Math.abs((ar - ab) - (br - bb));
        // el tono solo pesa cuando hay color: en grises el JPEG inventa tono (ruido de croma)
        int sa = Math.max(ar, Math.max(ag, ab)) - Math.min(ar, Math.min(ag, ab));
        int sb = Math.max(br, Math.max(bg, bb)) - Math.min(br, Math.min(bg, bb));
        int sat = Math.max(sa, sb);
        int wq = Math.max(4, Math.min(12, (sat - 6) * 4 / 6));      // peso del tono x4: 1 .. 3
        int hh = wq * Math.max(h1, Math.max(h2, h3)) / 4;
        return Math.min(255, Math.max(m, hh));
    }

    /** Solo la parte de TONO de bgDist (con el mismo peso segun cuanto color hay). */
    int hueDist(int c, int r) {
        int ar = (c >> 16) & 255, ag = (c >> 8) & 255, ab = c & 255;
        int br = (r >> 16) & 255, bg = (r >> 8) & 255, bb = r & 255;
        int h1 = Math.abs((ar - ag) - (br - bg)), h2 = Math.abs((ab - ag) - (bb - bg)), h3 = Math.abs((ar - ab) - (br - bb));
        int sa = Math.max(ar, Math.max(ag, ab)) - Math.min(ar, Math.min(ag, ab));
        int sb = Math.max(br, Math.max(bg, bb)) - Math.min(br, Math.min(bg, bb));
        int wq = Math.max(4, Math.min(12, (Math.max(sa, sb) - 6) * 4 / 6));
        return wq * Math.max(h1, Math.max(h2, h3)) / 4;
    }

    static int dist2(int a, int b) {
        int dr = ((a >> 16) & 255) - ((b >> 16) & 255), dg = ((a >> 8) & 255) - ((b >> 8) & 255), db = (a & 255) - (b & 255);
        return dr * dr + dg * dg + db * db;
    }

    /**
     * Cuanto CONSERVAR (0..255) de un pixel de la banda: mezcla entre el color local del dibujo
     * F (lo mas distinto del fondo cerca) y el fondo B. Referencia mala o mezcla que no cuadra:
     * libre -> se borra, muro -> se conserva.
     */
    private int unmixKeep(int g, int x, int y, boolean free) {
        int i = y * W + x;
        int C = colorOf(cur, snap, i);
        int B = ref | 0xFF000000;
        int rf = (int) Math.ceil(hRef) + 2;
        int best = -1, bd = -1;
        int gx = g % gw, gy = g / gw;
        for (int dy = -rf; dy <= rf; dy++) {
            int ny = gy + dy;
            int yy = ny + gy0;
            if (yy < wy0 || yy >= wy1) continue;
            for (int dx = -rf; dx <= rf; dx++) {
                int nx = gx + dx;
                int xx = nx + gx0;
                if (xx < wx0 || xx >= wx1) continue;
                int j = ny * gw + nx;
                if ((S[j] & WALL) == 0 || (S[j] & SOFT) != 0 && free || K[j] == 0) continue;
                int q = colorOf(cur, snap, yy * W + xx);
                if ((q >>> 24) < 32) continue;
                int d = dist2(q, B);
                if (d > bd) { bd = d; best = q; }
            }
        }
        if (best == -1 || bd < 40 * 40) return free ? 0 : 255;
        int F = best;
        float fr = (F >> 16) & 255, fg = (F >> 8) & 255, fb = F & 255;
        float br = (B >> 16) & 255, bgc = (B >> 8) & 255, bb = B & 255;
        float cr = (C >> 16) & 255, cg = (C >> 8) & 255, cb = C & 255;
        float vr = br - fr, vg = bgc - fg, vb = bb - fb;
        float L2 = vr * vr + vg * vg + vb * vb;
        float t = ((cr - fr) * vr + (cg - fg) * vg + (cb - fb) * vb) / L2;
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        float er = cr - (fr + t * vr), eg = cg - (fg + t * vg), eb = cb - (fb + t * vb);
        float res2 = er * er + eg * eg + eb * eb;
        if (res2 > Math.max(30f * 30f, 0.12f * L2)) return free ? 0 : 255;
        if (t >= 0.9f) return 0;
        if (t <= 0.1f) return 255;
        return Math.round((0.9f - t) / 0.8f * 255f);
    }

    /** Color "de antes" mas cercano a (x,y) que no sea tinta (0 si no hay). */
    public static int colorAt(int[] cur, int[] snap, int w, int h, int x, int y, int r) {
        for (int pass = 0; pass < 2; pass++)
            for (int rad = 0; rad <= r; rad++)
                for (int dy = -rad; dy <= rad; dy++)
                    for (int dx = -rad; dx <= rad; dx++) {
                        if (Math.max(Math.abs(dx), Math.abs(dy)) != rad) continue;
                        int xx = x + dx, yy = y + dy;
                        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                        int c = colorOf(cur, snap != null && snap.length == cur.length ? snap : null, yy * w + xx);
                        if ((c >>> 24) <= 32) continue;
                        if (pass == 0 && BgStroke.inkAbs(c)) continue;
                        return c | 0xFF000000;
                    }
        return 0;
    }

    /**
     * v8.33: color para el BALDE. Si tocaste una zona OSCURA ANCHA (7x7 casi todo tinta: una
     * franja negra, no una linea fina) se toma ESE color: querias borrar lo negro. Si no, como
     * antes: el fondo mas cercano saltando la linea (un toque que cae sobre una linea fina).
     * 0 = no hay nada visible.
     */
    public static int tapColor(int[] cur, int[] snap, int w, int h, int x, int y) {
        if (x < 0 || y < 0 || x >= w || y >= h) return 0;
        int[] s2 = snap != null && snap.length == cur.length ? snap : null;
        int ink = 0, vis = 0, n = 0;
        int[] lum = new int[49];
        int[] col = new int[49];
        for (int dy = -3; dy <= 3; dy++)
            for (int dx = -3; dx <= 3; dx++) {
                int xx = x + dx, yy = y + dy;
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                n++;
                int c = colorOf(cur, s2, yy * w + xx);
                if ((c >>> 24) <= 32) continue;
                vis++;
                if (BgStroke.inkAbs(c)) { lum[ink] = lum(c | 0xFF000000); col[ink] = c; ink++; }
            }
        if (n > 0 && vis * 100 >= n * 85 && ink * 100 >= vis * 85) {
            // mediana por brillo de lo oscuro
            int k = ink / 2;
            for (int i = 0; i <= k; i++) {
                int mi = i;
                for (int j = i + 1; j < ink; j++) if (lum[j] < lum[mi]) mi = j;
                int t = lum[i]; lum[i] = lum[mi]; lum[mi] = t;
                t = col[i]; col[i] = col[mi]; col[mi] = t;
            }
            return col[k] | 0xFF000000;
        }
        return colorAt(cur, s2, w, h, x, y, 4);
    }

    /** true si el punto ya es transparente (antes y ahora). */
    public static boolean clearAt(int[] cur, int w, int x, int y) {
        return x >= 0 && y >= 0 && (cur[y * w + x] >>> 24) < 8;
    }

    /** Cuanto conservar en (x,y) segun la ultima operacion (255 = no se toca). */
    public int keepAt(int x, int y) {
        if (x < rx0 || y < ry0 || x >= rx1 || y >= ry1) return 255;
        return K[gidx(x, y)] & 0xFF;
    }

    /** Color descontaminado de un pixel que queda a medias (sin el tinte del fondo). */
    public static int decontaminate(int c, int ref, int keep) {
        if (keep >= 255 || keep <= 0) return c & 0x00FFFFFF;
        float a = keep / 255f, t = 1f - a;
        int r = clamp(Math.round((((c >> 16) & 255) - t * ((ref >> 16) & 255)) / a));
        int g = clamp(Math.round((((c >> 8) & 255) - t * ((ref >> 8) & 255)) / a));
        int b = clamp(Math.round(((c & 255) - t * (ref & 255)) / a));
        return (r << 16) | (g << 8) | b;
    }

    static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    /**
     * Aplica el resultado a la capa. base = alfa de antes (copia); con seleccion, solo lo azul.
     * Nunca SUBE el alfa. Devuelve cuantos pixeles cambiaron.
     */
    public int applyTo(int[] px, byte[] selMask) {
        return applyTo(px, selMask, snap, ref);
    }

    /**
     * v8.37 (B/N): el analisis se hizo sobre una COPIA (gris); se aplica a la capa real con SU
     * copia de antes (realSnap) y el color de fondo real (realRef) para el borde: la capa queda
     * con sus colores originales.
     */
    public int applyTo(int[] px, byte[] selMask, int[] realSnap, int realRef) {
        int[] snap = realSnap != null && realSnap.length == px.length ? realSnap : null;
        int changed = 0;
        int B = realRef | 0xFF000000;
        for (int y = ry0; y < ry1; y++) {
            int g = gidx(rx0, y);
            for (int x = rx0; x < rx1; x++, g++) {
                int k = K[g] & 0xFF;
                if (k == 255) continue;
                int i = y * W + x;
                if (selMask != null) {
                    int sv = selMask[i] & 0xFF;
                    if (sv == 0) continue;
                    k = 255 - (255 - k) * sv / 255;
                }
                int c = px[i];
                int ca = c >>> 24;
                if (ca == 0) continue;
                int o = colorOf(px, snap, i);
                int base = o >>> 24;
                int na = base * k / 255;
                if (na >= ca) continue;
                int rgb = k == 0 ? (c & 0x00FFFFFF) : decontaminate(o, B, k);
                px[i] = (na << 24) | rgb;
                changed++;
            }
        }
        return changed;
    }
}
