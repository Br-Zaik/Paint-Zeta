package com.pacco.animecut.core;

/**
 * Convierte las lineas oscuras del dibujo en una barrera para el relleno.
 * Es lo que hace que la varita magica funcione bien en manga blanco y negro:
 * el relleno se para en la linea en vez de escaparse por toda la pagina.
 */
public final class LineArt {

    private LineArt() {
    }

    /**
     * @param threshold luminancia por debajo de la cual el pixel es "linea" (0..255)
     * @param closeGap  cuantos pixeles engordar la linea para cerrar huecos
     */
    public static byte[] build(int[] px, int w, int h, int threshold, int closeGap) {
        byte[] b = new byte[w * h];
        for (int i = 0; i < b.length; i++) {
            int c = px[i];
            int r = (c >> 16) & 0xFF;
            int g = (c >> 8) & 0xFF;
            int bl = c & 0xFF;
            int lum = (r * 77 + g * 151 + bl * 28) >> 8;
            b[i] = (byte) (lum < threshold ? 255 : 0);
        }
        if (closeGap > 0) MaskOps.dilate(b, w, h, closeGap);
        return b;
    }

    // ------------------------------------------------------------------
    // v8.24 "Lineas": separar las lineas del dibujo en una capa transparente.
    // Une el "Lineas" de v8.23 y el antiguo "Preparar para colorear".
    // ------------------------------------------------------------------

    /** Ajustes de la extraccion. */
    public static final class Extract {
        /** true: imagen a color (detecta trazos finos oscuros, no zonas oscuras). */
        public boolean colored;
        /** Blanco y negro: brillo que queda transparente / brillo que queda linea llena. */
        public int white = 240, black = 60;
        /** A color: grosor maximo de linea (px) e intensidad minima del trazo. */
        public int maxWidth = 6, contrast = 40;
    }

    /**
     * Imagen a color si mas del 10 % de los pixeles tienen color de verdad (no gris,
     * ni casi negro ni casi blanco). Con muestreo: rapido aunque sea grande.
     */
    public static boolean isColored(int[] px) {
        int step = Math.max(1, px.length / 40000), n = 0, col = 0;
        for (int i = 0; i < px.length; i += step) {
            int c = px[i];
            if ((c >>> 24) < 128) continue;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
            n++;
            if (mx - mn > 40 && mx > 50 && mn < 225) col++;
        }
        return n > 0 && col * 10 > n;
    }

    public static int[] extract(int[] src, int w, int h, Extract e) {
        return e.colored ? extractColored(src, w, h, e) : extractBW(src, w, h, e);
    }

    /**
     * Blanco y negro: "color a alfa" contra el papel. Lo mas claro que 'white'
     * queda transparente, lo mas oscuro que 'black' queda linea llena, y el
     * antialias en medio queda semitransparente con el color real de la linea.
     */
    public static int[] extractBW(int[] src, int w, int h, Extract e) {
        // v8.57: mismo motor que el filtro "Extraer lineas": corrige el papel amarillo y las
        // manchas del escaneo antes de volver transparente el blanco (antialias suave).
        return Fx.extractLines(src, w, h, e.white, e.black, true, 0);
    }

    /**
     * A color: solo TRAZOS finos y oscuros (transformacion "top-hat" negra: cierre
     * morfologico del brillo menos el brillo). Una linea de hasta 'maxWidth' px
     * resalta; una zona oscura grande (pelo, ropa) o una sombra suave no.
     * El color de la linea es el de su centro (el pixel mas oscuro cercano).
     */
    public static int[] extractColored(int[] src, int w, int h, Extract e) {
        int n = w * h;
        int[] lum = new int[n];
        for (int i = 0; i < n; i++) {
            int c = src[i];
            lum[i] = (c >>> 24) < 128 ? 255 : (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
        }
        int r = Math.max(1, (e.maxWidth + 1) / 2);
        int[] closed = minFilter(maxFilter(lum, w, h, r), w, h, r);
        int lo = Math.max(5, e.contrast), hi = lo + 60;
        int[] out = new int[n];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int th = closed[i] - lum[i];
                if (th <= lo) continue;
                float a = Math.min(1f, (th - lo) / (float) (hi - lo));
                // color del centro de la linea
                int core = src[i], best = lum[i];
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        if (lum[yy * w + xx] < best) { best = lum[yy * w + xx]; core = src[yy * w + xx]; }
                    }
                }
                int al = Math.round(a * (src[i] >>> 24));
                if (al > 0) out[i] = (al << 24) | (core & 0xFFFFFF);
            }
        }
        return out;
    }

    /** Maximo en una ventana cuadrada de radio r (separable). */
    private static int[] maxFilter(int[] in, int w, int h, int r) {
        int[] tmp = new int[in.length], out = new int[in.length];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int m = 0;
                for (int k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) m = Math.max(m, in[row + k]);
                tmp[row + x] = m;
            }
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int m = 0;
                for (int k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) m = Math.max(m, tmp[k * w + x]);
                out[y * w + x] = m;
            }
        }
        return out;
    }

    /** Minimo en una ventana cuadrada de radio r (separable). */
    private static int[] minFilter(int[] in, int w, int h, int r) {
        int[] tmp = new int[in.length], out = new int[in.length];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int m = 255;
                for (int k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) m = Math.min(m, in[row + k]);
                tmp[row + x] = m;
            }
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int m = 255;
                for (int k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) m = Math.min(m, tmp[k * w + x]);
                out[y * w + x] = m;
            }
        }
        return out;
    }

    private static int clamp(float v) { return v < 0 ? 0 : v > 255 ? 255 : (int) (v + .5f); }
}
