package com.pacco.animecut.core;

/**
 * v8.52 Toques suaves (la tecnica de Procreate / Ibis para piel natural): manchas de color
 * que se funden. Se difumina SOLO lo que agrego el ultimo trazo (la diferencia entre antes y
 * despues), asi las manchas viejas no se vuelven cada vez mas borrosas.
 * Todo en color premultiplicado (no salen bordes oscuros) y, si el difuminado es grande,
 * se calcula en pequeno y se agranda (rapido aun con pinceles enormes).
 */
public final class SoftBlend {
    private SoftBlend() { }

    /**
     * px: capa entera (ancho W). La zona (x0, y0, rw, rh) se reemplaza por
     * original + difuminado(px - original). orig = la zona como estaba antes (null = vacia,
     * o sea difuminar todo lo que hay). sigma = cuanto se difumina, en pixeles.
     */
    public static void apply(int[] px, int W, int x0, int y0, int rw, int rh, int[] orig, float sigma) {
        if (rw <= 0 || rh <= 0) return;
        int n = rw * rh;
        int f = sigma >= 24f ? 4 : sigma >= 10f ? 2 : 1;
        int sw = (rw + f - 1) / f, sh = (rh + f - 1) / f;
        int rb = Math.max(1, Math.round(sigma / f));
        int[] small = new int[sw * sh];
        int[] tmp = new int[sw * sh];
        int[] out = new int[n];
        for (int ch = 0; ch < 4; ch++) {
            int shift = ch == 0 ? 24 : ch == 1 ? 16 : ch == 2 ? 8 : 0;
            java.util.Arrays.fill(small, 0);
            for (int y = 0; y < rh; y++) {
                int row = (y0 + y) * W + x0, sRow = (y / f) * sw;
                for (int x = 0; x < rw; x++) {
                    int a = px[row + x];
                    int o = orig == null ? 0 : orig[y * rw + x];
                    int d = pm(a, ch, shift) - pm(o, ch, shift);
                    if (d != 0) small[sRow + x / f] += d;
                }
            }
            if (f > 1) {
                for (int by = 0; by < sh; by++) {
                    int ch2 = Math.min(f, rh - by * f);
                    for (int bx = 0; bx < sw; bx++) {
                        int cnt = ch2 * Math.min(f, rw - bx * f);
                        int k = by * sw + bx;
                        if (small[k] != 0) small[k] = div(small[k], cnt);
                    }
                }
            }
            blur3(small, tmp, sw, sh, rb);
            for (int y = 0; y < rh; y++) {
                float fy = f == 1 ? y : (y + 0.5f) / f - 0.5f;
                int yA = (int) Math.floor(fy);
                float ty = fy - yA;
                int y1 = clamp(yA, 0, sh - 1), y2 = clamp(yA + 1, 0, sh - 1);
                for (int x = 0; x < rw; x++) {
                    int k = y * rw + x;
                    float dv;
                    if (f == 1) dv = small[y * sw + x];
                    else {
                        float fx = (x + 0.5f) / f - 0.5f;
                        int xA = (int) Math.floor(fx);
                        float tx = fx - xA;
                        int x1 = clamp(xA, 0, sw - 1), x2 = clamp(xA + 1, 0, sw - 1);
                        float top = small[y1 * sw + x1] * (1f - tx) + small[y1 * sw + x2] * tx;
                        float bot = small[y2 * sw + x1] * (1f - tx) + small[y2 * sw + x2] * tx;
                        dv = top * (1f - ty) + bot * ty;
                    }
                    int o = orig == null ? 0 : orig[k];
                    int v = pm(o, ch, shift) + Math.round(dv);
                    v = v < 0 ? 0 : v > 255 ? 255 : v;
                    out[k] |= v << shift;
                }
            }
        }
        for (int y = 0; y < rh; y++) {
            int row = (y0 + y) * W + x0;
            for (int x = 0; x < rw; x++) {
                int c = out[y * rw + x];
                int a = c >>> 24;
                if (a == 0) { px[row + x] = 0; continue; }
                int r = Math.min(255, (((c >> 16) & 0xFF) * 255 + a / 2) / a);
                int g = Math.min(255, (((c >> 8) & 0xFF) * 255 + a / 2) / a);
                int b = Math.min(255, ((c & 0xFF) * 255 + a / 2) / a);
                px[row + x] = (a << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }

    /** Canal premultiplicado (0 = alfa). */
    private static int pm(int c, int ch, int shift) {
        int a = c >>> 24;
        if (ch == 0) return a;
        if (a == 0) return 0;
        return (((c >> shift) & 0xFF) * a + 127) / 255;
    }

    private static int clamp(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

    /** Division redondeada que funciona con negativos. */
    private static int div(int s, int d) {
        return s >= 0 ? (s + d / 2) / d : -((-s + d / 2) / d);
    }

    /** Tres pasadas de caja horizontal + vertical (casi gaussiano). Afuera cuenta como 0. */
    static void blur3(int[] a, int[] t, int w, int h, int r) {
        for (int p = 0; p < 3; p++) {
            boxH(a, t, w, h, r);
            boxV(t, a, w, h, r);
        }
    }

    private static void boxH(int[] s, int[] d, int w, int h, int r) {
        int div = 2 * r + 1;
        for (int y = 0; y < h; y++) {
            int o = y * w, sum = 0;
            for (int x = 0; x <= Math.min(r, w - 1); x++) sum += s[o + x];
            for (int x = 0; x < w; x++) {
                d[o + x] = div(sum, div);
                int add = x + r + 1, rem = x - r;
                if (add < w) sum += s[o + add];
                if (rem >= 0) sum -= s[o + rem];
            }
        }
    }

    private static void boxV(int[] s, int[] d, int w, int h, int r) {
        int div = 2 * r + 1;
        for (int x = 0; x < w; x++) {
            int sum = 0;
            for (int y = 0; y <= Math.min(r, h - 1); y++) sum += s[y * w + x];
            for (int y = 0; y < h; y++) {
                d[y * w + x] = div(sum, div);
                int add = y + r + 1, rem = y - r;
                if (add < h) sum += s[add * w + x];
                if (rem >= 0) sum -= s[rem * w + x];
            }
        }
    }

    /**
     * v8.53 "Sacar lineas" (el Extraer dibujo lineal de Ibis): blanco, negro y medio en 0..100.
     * Lo mas claro que 'white' queda transparente, lo mas oscuro que 'black' queda opaco y 'mid'
     * cambia los grises del medio (50 = parejo; mas = lineas mas llenas). keepColor: las lineas
     * guardan su color; si no, quedan en negro.
     */
    public static void extractLines(int[] src, int[] dst, int white, int black, int mid, boolean keepColor) {
        float W = Math.max(white, black + 1) * 2.55f, B = Math.min(black, white - 1) * 2.55f;
        float gamma = (float) Math.pow(2.0, (50 - mid) / 25.0);
        int[] lut = new int[256];
        for (int L = 0; L < 256; L++) {
            float t = (W - L) / Math.max(1f, W - B);
            t = t < 0f ? 0f : t > 1f ? 1f : t;
            lut[L] = Math.round(255f * (float) Math.pow(t, gamma));
        }
        for (int i = 0; i < src.length; i++) {
            int c = src[i];
            int a = c >>> 24;
            if (a == 0) { dst[i] = 0; continue; }
            int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            int lum = (r * 299 + g * 587 + b * 114) / 1000;
            if (a < 255) lum = 255 - a * (255 - lum) / 255;   // lo semitransparente, como sobre papel blanco
            int na = lut[lum];
            dst[i] = na == 0 ? 0 : (na << 24) | (keepColor ? (c & 0xFFFFFF) : 0);
        }
    }

    /**
     * v8.52 "Quitar blanco" (el Blanco claro de Ibis): lo blanco se vuelve transparente.
     * keepColor=false: queda solo la linea en negro (escala de grises).
     * keepColor=true: se quita el blanco pero se guarda el color de las lineas.
     */
    public static void whiteToAlpha(int[] px, boolean keepColor) {
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int a = c >>> 24;
            if (a == 0) continue;
            int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            if (!keepColor) {
                int lum = (r * 299 + g * 587 + b * 114) / 1000;
                int na = a * (255 - lum) / 255;
                px[i] = na << 24;
                continue;
            }
            int k = Math.max(255 - r, Math.max(255 - g, 255 - b));
            if (k <= 0) { px[i] = 0; continue; }
            int nr = 255 - (255 - r) * 255 / k, ng = 255 - (255 - g) * 255 / k, nb = 255 - (255 - b) * 255 / k;
            nr = nr < 0 ? 0 : nr; ng = ng < 0 ? 0 : ng; nb = nb < 0 ? 0 : nb;
            int na = a * k / 255;
            px[i] = na == 0 ? 0 : (na << 24) | (nr << 16) | (ng << 8) | nb;
        }
    }
}
