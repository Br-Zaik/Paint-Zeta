package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * v8.45: animacion corta de Colorear facil (sin texto): muestra con una carita que hace cada paso.
 * kind: 0 = tocar zonas, 1 = rayar partes, 2 = sombras, 3 = luz y fondo. Se repite sola.
 */
public class EasyDemoView extends View {
    private final int kind;
    private final long t0 = System.currentTimeMillis();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG),
            finger = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path hair = new Path(), face = new Path(), body = new Path(), shadow = new Path();
    private static final int SKIN = 0xFFFFDCC8, HAIR = 0xFF3B3F66, SHIRT = 0xFFB0303A;

    public EasyDemoView(Context c, int kind) {
        super(c);
        this.kind = kind;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(0xFF111111);
        finger.setColor(0x88FFFFFF);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float s = Math.min(w, h) / 100f, ox = (w - 100 * s) / 2f, oy = (h - 100 * s) / 2f;
        face.reset();
        face.addOval(new RectF(ox + 30 * s, oy + 18 * s, ox + 70 * s, oy + 62 * s), Path.Direction.CW);
        hair.reset();
        hair.moveTo(ox + 26 * s, oy + 44 * s);
        hair.cubicTo(ox + 22 * s, oy + 8 * s, ox + 78 * s, oy + 8 * s, ox + 74 * s, oy + 44 * s);
        hair.lineTo(ox + 66 * s, oy + 30 * s);
        hair.lineTo(ox + 56 * s, oy + 36 * s);
        hair.lineTo(ox + 48 * s, oy + 28 * s);
        hair.lineTo(ox + 38 * s, oy + 36 * s);
        hair.lineTo(ox + 32 * s, oy + 30 * s);
        hair.close();
        body.reset();
        body.moveTo(ox + 22 * s, oy + 96 * s);
        body.cubicTo(ox + 24 * s, oy + 70 * s, ox + 36 * s, oy + 64 * s, ox + 50 * s, oy + 64 * s);
        body.cubicTo(ox + 64 * s, oy + 64 * s, ox + 76 * s, oy + 70 * s, ox + 78 * s, oy + 96 * s);
        body.close();
        shadow.reset();
        shadow.moveTo(ox + 31 * s, oy + 36 * s);
        shadow.lineTo(ox + 69 * s, oy + 36 * s);
        shadow.lineTo(ox + 69 * s, oy + 42 * s);
        shadow.cubicTo(ox + 60 * s, oy + 46 * s, ox + 40 * s, oy + 46 * s, ox + 31 * s, oy + 42 * s);
        shadow.close();
        shadow.addRect(ox + 60 * s, oy + 64 * s, ox + 80 * s, oy + 98 * s, Path.Direction.CW);
        line.setStrokeWidth(Math.max(2f, 1.6f * s));
        sc = s; sx = ox; sy = oy;
    }

    private float sc = 1, sx, sy;

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    private void fillPath(Canvas c, Path p, int color, float a) {
        if (a <= 0f) return;
        fill.setShader(null);
        fill.setColor(color);
        fill.setAlpha(Math.round(255 * clamp01(a)));
        c.drawPath(p, fill);
    }

    @Override protected void onDraw(Canvas c) {
        float t = ((System.currentTimeMillis() - t0) % 4200L) / 4200f;   // 0..1, 4,2 s
        c.drawColor(0xFF2A2A30);
        float paperA = 1f;
        fill.setShader(null);
        fill.setColor(0xFFFFFFFF);
        c.drawRect(sx, sy, sx + 100 * sc, sy + 100 * sc, fill);
        if (kind == 3) {   // fondo degradado que aparece
            float a = clamp01((t - 0.15f) / 0.3f);
            fill.setShader(new LinearGradient(0, sy, 0, sy + 100 * sc, 0xFFDDE6F4, 0xFF8E9BB8, Shader.TileMode.CLAMP));
            fill.setAlpha(Math.round(255 * a));
            c.drawRect(sx, sy, sx + 100 * sc, sy + 100 * sc, fill);
            fill.setShader(null);
        }
        float fh, ff, fb;
        float fx = -1, fy = -1;
        if (kind == 0) {   // tocar: el dedo va a cada parte y la llena
            fh = clamp01((t - 0.15f) / 0.08f); ff = clamp01((t - 0.40f) / 0.08f); fb = clamp01((t - 0.65f) / 0.08f);
            if (t < 0.35f) { fx = 50; fy = 20; } else if (t < 0.6f) { fx = 50; fy = 52; } else if (t < 0.9f) { fx = 40; fy = 84; }
        } else if (kind == 1) {   // rayar: tres rayones y despues todo junto
            fh = ff = fb = clamp01((t - 0.72f) / 0.1f);
        } else {
            fh = ff = fb = 1f;
        }
        fillPath(c, face, SKIN, ff);
        fillPath(c, body, SHIRT, fb);
        fillPath(c, hair, HAIR, fh);
        if (kind == 2 || kind == 3) {   // sombra: aparece suave (y en 3 ya esta)
            float a = kind == 3 ? 1f : clamp01((t - 0.2f) / 0.35f);
            c.save();
            c.clipPath(face);
            fillPath(c, shadow, 0xFFE0A090, a * 0.9f);
            c.restore();
            c.save();
            c.clipPath(body);
            fillPath(c, shadow, 0xFF7A1A2A, a * 0.8f);
            c.restore();
        }
        c.drawPath(face, line);
        c.drawPath(body, line);
        c.drawPath(hair, line);
        if (kind == 3) {   // brillo de borde a la derecha
            float a = clamp01((t - 0.45f) / 0.3f);
            Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(3 * sc);
            rim.setColor(0xFFFFE2B0);
            rim.setAlpha(Math.round(220 * a));
            c.save();
            c.clipRect(sx + 60 * sc, sy, sx + 100 * sc, sy + 100 * sc);
            c.drawPath(face, rim);
            c.drawPath(body, rim);
            c.restore();
        }
        if (kind == 1 && t < 0.72f) {   // los rayones de color
            Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
            st.setStyle(Paint.Style.STROKE);
            st.setStrokeCap(Paint.Cap.ROUND);
            st.setStrokeWidth(3.5f * sc);
            int[] cols = {HAIR, 0xFFF0B090, SHIRT};
            float[][] ys = {{24, 26}, {50, 52}, {82, 84}};
            for (int k = 0; k < 3; k++) {
                float p = clamp01((t - k * 0.22f) / 0.2f);
                if (p <= 0) continue;
                st.setColor(cols[k]);
                float x0 = sx + 38 * sc, x1 = sx + (38 + 24 * p) * sc;
                c.drawLine(x0, sy + ys[k][0] * sc, x1, sy + ys[k][1] * sc, st);
                if (p < 1f) { fx = 38 + 24 * p; fy = ys[k][1]; }
            }
        }
        if (fx >= 0) c.drawCircle(sx + fx * sc, sy + fy * sc, 6 * sc, finger);
        postInvalidateOnAnimation();
    }
}
