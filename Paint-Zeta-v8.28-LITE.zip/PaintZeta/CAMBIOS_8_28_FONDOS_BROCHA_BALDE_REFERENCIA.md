# Paint Zeta v8.28 — Quitar fondo, Brocha, Balde y Referencia de color

Versión 8.28 (versionCode 66). Base: la v8.27 que entregué antes («Corrección integral»). No se quitó ninguna función. No se tocó GitHub ni el flujo de GitHub Actions. Sin IA ni librerías nuevas.

Cómo leer este documento:

- **CONFIRMADO** = lo reproduje con el código real de la app (el mismo lienzo, dentro de un Android simulado) y hay un número que lo prueba.
- **HIPÓTESIS** = probable, pero no lo pude reproducir exactamente.
- Todas las pruebas corrieron en un servidor con Android simulado. **No es un teléfono.** No afirmo FPS ni ausencia de tirones en ningún teléfono.
- Las capturas 1 a 5 son fotos de pantalla. Sirvieron para encontrar las fallas. Las imágenes 6 (duende a color) y 7 (manga del chico con la mano) llegaron como JPG de 1052x1536 y 1024x1536. Las usé tal cual en las pruebas: están en `tests/assets/duende_color_imagen6.jpg` y `tests/assets/manga_mano_imagen7.jpg`.

---

## 1. Qué cambia para ti

**Quitar fondo con el pincel** (capturas 1 y 2):

- La línea negra del contorno frena el borrado: el pincel ya no la cruza ni le hace mordiscos.
- Si pasas el dedo por encima del personaje, no se borra. El borrado sigue solo cuando vuelves al fondo que ya estabas borrando. Para borrar otro fondo (del otro lado del personaje), toca de nuevo allí.
- El borde del pincel de Borrar fondo es duro. Ya no deja fondo a medio borrar ni manchas claras.
- El borde de la línea conserva su parte de tinta (sin el color del fondo viejo). Así la línea no queda más fina ni con halo.
- Las motas sueltas de fondo (puntitos blancos o grises) se borran mientras pasas el dedo. Los detalles con color o de tinta no se tocan.

**Quitar fondo con un toque:**

- El borrado avanza solo por los colores parecidos al que tocaste. Antes también avanzaba por la «franja suave» y de ahí se metía al personaje.
- En fondos de color medio u oscuro (como la cueva del duende), el borrado no pasa por los bordes nítidos del dibujo ni por cortes de la línea de hasta unos 8 píxeles. Lo que quede del otro lado de un corte se borra con otro toque.

**Revisar el recorte:** en la barra de Borrar fondo hay un botón «Ver: …». Cambia el fondo de la vista entre cuadros, blanco, negro, gris y verde. Es solo para mirar: el PNG guarda la transparencia real.

**Separar y quitar fondo con rayas:**

- La línea negra pegada al personaje queda con el personaje.
- El borde sale sin el color del fondo.

**Balde** (captura 5):

- Si ya borraste el fondo del dibujo y tocas la cara, lo transparente cuenta como pared. El color no se sale al fondo aunque la línea tenga un corte.
- Si pintas color sobre un manga en blanco y negro en una capa Normal, la app pregunta ANTES de pintar si quieres usar Multiplicar. En Multiplicar se siguen viendo las tramas, los grises y las sombras debajo del color. Pregunta una vez por capa, y se puede elegir «No preguntar más».

**Brocha:** en su barra hay un botón «Plano / Suave». «Plano» es color parejo con borde definido. «Suave» es borde difuminado para sombras y degradados. Cambiar no toca el tamaño.

**Referencia de color** (captura 3):

- Volvió a estar a la vista: botón «Ref. color» en la barra de Capas, y también en la barra de la Brocha y del Balde.
- Abre otra imagen en una ventanita aparte que no es una capa. Se puede mover, plegar y cerrar.
- Tocas un color y con «Usar» queda listo para la Brocha y el Balde. «Guardar» lo agrega a tu paleta.
- La referencia nunca aparece en el PNG.

---

## 2. Causas encontradas

### Capturas 1 y 2: el pincel de Borrar fondo cruza y muerde la línea, deja restos

**CONFIRMADO.** El pincel elegía como punto de partida el centro del dedo en cada toque. Además avanzaba por la tolerancia más la suavidad (46 + 42 de fábrica). Si el centro pasaba por la línea o por el personaje con un color parecido, los borraba. El verde del duende y la cueva se diferencian solo 23, menos que la tolerancia 46.

Medido con v8.27 en las imágenes 6 y 7, con el dedo yendo y viniendo sobre el borde:

- Duende: línea comida 40 % (333 de 826 píxeles) y 477 píxeles del duende borrados.
- Manga, con «toma el color todo el rato»: tinta del pelo comida 27 %.

**CONFIRMADO.** Con «toma el color todo el rato», el color de referencia pasaba a ser la línea o el personaje apenas el dedo los tocaba.

**CONFIRMADO.** El borde suave del pincel (dureza 35 %) dejaba fondo a medio borrar bajo el pincel:

- Manga: quedaban de 599 a 1560 de 4757 píxeles.
- Duende: quedaban de 583 a 1408 de 2789 píxeles.

### Captura 3: no se encuentra la Referencia de color

**CONFIRMADO.** No se había roto: en v8.27 yo la moví a Capas > Más, y quedó escondida. Ahora tiene botón propio y ya no se repite dentro de «Más».

### Captura 4: manchas blancas sueltas después de quitar el fondo

**CONFIRMADO** con un caso equivalente: papel con 34 grupos de motas grises de 1 a 6 píxeles. Con el pincel en v8.27 quedaban 70 píxeles de motas.

- Al quitar el color del fondo del borde, una mota gris quedaba negra y casi transparente. Así contaba como «tinta» y nunca se limpiaba.
- Las motas a medio borrar quedaban sueltas junto a la línea.

### Captura 5: el balde pinta la cara y todo el fondo

**CONFIRMADO.** El balde trataba lo transparente como papel blanco. Con el fondo ya borrado, un corte de la línea alcanzaba para que el color se saliera a todo el fondo.

En la reproducción (imagen 7 con el fondo borrado y la línea de la mandíbula cortada con la goma), v8.27 pintó **229 974 píxeles sobre el fondo transparente**. v8.28 pintó **0**.

**HIPÓTESIS** sobre el corte de la línea en tu dibujo: lo más probable es que lo hiciera el pincel de Borrar fondo de v8.27 (capturas 1 y 2). Eso también quedó corregido.

### Quitar fondo con un toque en un fondo parecido al personaje (imagen 6)

**CONFIRMADO.** El toque avanzaba por la franja suave, de píxel a medias en píxel a medias. Así cruzaba el antialias de la línea y las sombras.

Con 9 toques en la cueva, v8.27 se comió el **99,7 %** de cuatro zonas de adentro del duende (pecho, panza, cabeza y puño). v8.28 pierde el **1,7 %**.

### Separar y quitar fondo con rayas

**CONFIRMADO.** El borde se suavizaba 1 píxel a ciegas. El límite caía a veces en medio de la línea negra.

En la prueba del duende, v8.27 conservó 0 de 107 píxeles del contorno pegado al personaje. v8.28 conserva 750 de 784.

---

## 3. Qué se cambió (técnico)

**`core/BgGuard` (nuevo)**

- **Barrera de línea:** un píxel es «línea» si es oscuro como tinta comparado con el fondo y forma un trazo fino (7 píxeles o menos en alguna dirección). Los cortes de 1 píxel se cierran.
- **Borde nítido (tipo 3):** con fondo de tono medio u oscuro, un salto de brillo de 44 o más en 2 píxeles. Se borra si es fondo, pero el borrado no avanza por ahí.
- **Motas:** grupos chicos rodeados de transparencia. Se borran si se parecen al fondo, si son casi invisibles o si son papel gris claro sin color, mirando el color de antes del trazo. Con el pincel, también los restos chicos de papel claro pegados a una línea y tocando lo ya borrado. Nunca un grupo con tinta oscura de más de 2 píxeles.

**`CanvasView` — pincel de Borrar fondo**

- La barrera se calcula por bloques de 64x64 una vez por trazo, con los píxeles de antes del trazo.
- El relleno avanza solo por píxeles claramente de fondo, sin pasar junto a la línea.
- Los puntos de partida son el fondo del toque anterior o lo que este trazo ya borró. Nunca el centro del dedo una vez empezado el trazo.
- Borde duro con antialias de 1 píxel.
- «Hombro» de la línea: el píxel mezcla de tinta y fondo conserva su parte de tinta (alfa = (fondo − píxel) / (fondo − tinta)).
- El color de referencia continuo no toma la línea ni colores lejanos del inicio.
- Filo y motas se procesan una vez por evento del dedo, no en cada estampa.

**`FloodFill.contiguousStrict` (toque)**

- Avanza solo dentro de la tolerancia. La suavidad se aplica en 1 píxel de borde.
- Con fondo oscuro o medio, corta en los pasos angostos, con el mismo método del balde.
- La línea fina y el borde nítido frenan.

**`core/EdgeMatte` (nuevo, Separar y quitar fondo):** rescata la línea pegada al personaje. Calcula el alfa del filo como mezcla entre el color del fondo cercano y el del personaje, y le quita el color del fondo.

**`BucketFill`:** si el punto tocado es opaco, lo transparente (alfa menor que 128) cuenta como pared y no como papel. Si tocas algo transparente (líneas sueltas en una capa transparente), todo sigue como antes.

**`CanvasView` y `MainActivity` — balde y brocha**

- El aviso de Multiplicar se hace antes del relleno: el relleno espera la respuesta.
- Si no hace falta preguntar, se recuerda para no revisar la imagen en cada trazo.
- Botón Plano / Suave en la Brocha.
- Botón «Ref. color» en Capas, Brocha y Balde.
- Botón «Ver: …» en Borrar fondo.

---

## 4. Pruebas A-R (resultados reales)

Salida completa en `docs/RESULTADOS_PRUEBAS_8_28.txt` (toda la batería: v8.22 a v8.28, salida 0). Imágenes en `docs/qa828/`. Las comparaciones ANTES/AHORA son los archivos `ANTES_DESPUES_*.png`.

**Quitar fondo**

- **A. Manga B/N (imagen 7)**
  - 2 toques en el fondo: tinta perdida 0 de 295 158; motas claras sueltas 0; halo claro 4 píxeles.
  - Pincel repasando el pelo, tinta comida 0 %, con color «una vez» y «todo el rato» (v8.27: 0 % y 27 %).
  - Fondo que queda bajo el pincel: 66 y 62 de 4757 (v8.27: 599 y 1560).
- **B. Duende a color (imagen 6)**
  - Pincel junto a la panza: línea comida 1,3 % y 0 % (v8.27: 40,3 % y 43,9 %); duende comido 0 píxeles (v8.27: 477 y 408).
  - 9 toques en la cueva: adentro del duende perdido 1,7 % (v8.27: 99,7 %).
  - Rayas: contorno conservado 95,7 % (v8.27: 0 %).
- **C. Dedos, oreja en punta y mechones** (caso equivalente con relleno parecido al fondo; no hay foto con dedos sobre fondo): pincel en zigzag por todo, personaje comido 0 de 22 853 (v8.27: todo). Queda 2,2 % de fondo entre dedos y mechones.
- **D. Motas:** 34 grupos de motas grises. Quedan 0 píxeles con toque y con pincel (v8.27: 4 y 70). Estrella roja (41 de 41) y punto de tinta (16 de 16) conservados.
- **E/F. Vista y PNG:** cambiar el fondo de vista 5 veces cambia 0 píxeles de la capa. PNG exportado: alfa igual a la capa (0 distintos) y 0 píxeles de borde casi blancos. Los cuadros no están en el PNG.

**Pintado**

- **G. Brocha Plana:** alfa 255 en el centro y en el cruce del trazo consigo mismo; 0 huecos.
- **H. Brocha Suave:** alfa 127 en el centro y 127 en el cruce (sin mancha más oscura); 0 huecos.
- **I. Balde**
  - Cara: 0 de fuga.
  - Contorno con un corte de 5 píxeles: 0 de fuga.
  - Ojo de radio 5: lleno, 37 de 37.
  - **Fondo borrado más línea cortada: 0 píxeles fuera** (v8.27: 229 974).
- **J/K. Tramas** (balde «Por líneas» en la chaqueta, 68 629 píxeles)
  - Parecido con la trama original: 0,58 con «Dejar Normal» (el color tapa) y **1,00 con «Usar Multiplicar»**.
  - Tinta negra que dejó de verse negra: 0 de 9427.
  - La pregunta sale una vez por capa, antes de pintar.
- **L. Capa elegida:** 30 toques alternando brocha y balde; capas «imagen | capa_1», activa capa_1, original cambiado 0.

**Referencia de color**

- **M.** El cuentagotas con promedio 3x3 da exactamente el color esperado en el ojo, la piel y la sombra del duende.
- **N.** La brocha y el balde pintan exactamente ese color.
- **O.** Guardar y abrir: la referencia se guarda con la obra y el PNG exportado solo tiene las capas (0 píxeles distintos).

**Estabilidad**

- **P.** Deshacer y rehacer exactos (0 distintos). Dos dedos en Borrar fondo: 0 cambios. Guardar y abrir: 0 distintos.
- **Q.** Toda la batería anterior pasa: Especial, herramientas, pinceles, balde, Marioneta, Colorear manga y aceptación de v8.27 (T01-T13). La compilación sin SDK pasa: 624 clases sin errores.
- **R. Tiempos y memoria, en el servidor** (no es un teléfono):
  - Pincel de Borrar fondo por evento, p95: 0,6 ms (tamaño 20), 1,9 ms (60) y 2,6 ms (120). v8.27 en la misma prueba: 2,0 y 2,4 ms con 60 y 120.
  - Toque en 1024x1536: 120 ms de trabajo en segundo plano y unos 20 MB extra como máximo (v8.27: 195 ms y 14 MB).
  - Balde en la cara: unos 21 MB extra.

Pruebas no ejecutadas:

- En un teléfono real (no tengo acceso).
- Con las capturas 1 a 5 como archivos originales, porque son fotos de pantalla. Para eso usé casos equivalentes y las imágenes 6 y 7.

---

## 5. Limitaciones que quedan (dicho claro)

- **Fondo tan oscuro como la línea:** si tocas un fondo casi negro (por ejemplo una sombra de la cueva de brillo 18), el color no distingue el fondo de la tinta. En la prueba, el duende quedó casi entero, pero se borraron trocitos de algunas líneas negras de adentro (pecho, brazo, mango). Mejor tocar zonas de fondo de tono medio, o usar el pincel con «toma el color una vez», o el lazo. Deshacer devuelve todo.
- **Pasos angostos entre mechones:** el pincel no avanza por pasos de menos de unos 3 píxeles junto a la línea. En la imagen 7, con «todo el rato», quedan unos puntitos blancos entre mechones muy juntos. Se quitan con el modo «Disperso», con la goma o con otra pasada.
- **Toque en fondo oscuro o de color:** no cruza cortes de hasta unos 8 píxeles. El fondo del otro lado se borra con otro toque.
- Las puntas muy finas de algunos mechones quedan como trocitos de tinta sueltos (2 en la imagen 7). Son dibujo, no fondo.
- **Rayas (Separar y quitar fondo):** si una zona de fondo queda sin raya gris, el método puede unirla al personaje. Hay que agregar otra raya gris.
- **Balde «Por líneas» sobre trama muy tupida:** la toma como línea y deja bordes grises sin color. Se completan con la brocha (con «Proteger contornos») o con Lazo y Rellenar selección.

---

## 6. Pasos para probar en tu teléfono

1. Sube **Paint-Zeta-v8.28-LITE.zip** a GitHub (como siempre) y descarga el APK de Actions.
2. **Pincel de Borrar fondo:**
   - Abre la imagen del duende, elige Borrar fondo en modo pincel y «toma el color todo el rato».
   - Pasa el dedo a lo largo de la panza, aunque el dedo pise la línea: la línea debe quedar entera y el duende sin agujeros.
   - Toca «Ver: …» hasta «Negro» y luego «Blanco»: no deben verse filos claros ni manchas.
3. **Toque:** toca la cueva en 3 o 4 lugares de tono medio. El duende debe quedar entero. Si queda algo de cueva detrás de un corte, tócalo.
4. **Manga (imagen 7):**
   - Borra el fondo con toques y repasa el pelo con el pincel.
   - Crea una capa, elige el balde, toca la cara y responde «Usar Multiplicar».
   - El color no debe salirse al fondo y deben verse las sombras y tramas.
5. **Brocha:** toca «Plano / Suave» y pinta. Plano debe dar borde definido; Suave, borde difuminado.
6. **Referencia:**
   - Capas > «Ref. color», elige otra imagen y toca un color.
   - «Usar», y pinta con la brocha y con el balde.
   - Mueve, pliega y cierra la ventanita.
   - Exporta el PNG: la referencia no debe salir.
7. Si algo falla, mándame una captura y dime qué botón tocaste. Menú > «Medir rendimiento» da los tiempos reales de tu teléfono.
