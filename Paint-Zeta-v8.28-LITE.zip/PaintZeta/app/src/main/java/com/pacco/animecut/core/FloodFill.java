package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Varita magica. Relleno por lineas (scanline), coste lineal, sin recursion.
 *
 * Novedad importante: la seleccion ya no es si o no. Los pixeles que se
 * parecen del todo entran con 255, y los que estan en el filo entran a
 * medias. Eso es lo que evita el borde escalonado, porque el contorno de un
 * dibujo tiene pixeles intermedios por el antialias.
 */
public final class FloodFill {

    private FloodFill() {
    }

    /**
     * @param tolerance hasta aqui el pixel entra completo
     * @param softness  franja extra donde el pixel entra a medias
     * @param mode      ver ColorDist
     */
    public static Rect contiguous(int[] px, int w, int h, byte[] out, byte[] barrier,
                                  int seedX, int seedY, int tolerance, int softness, int mode) {
        if (seedX < 0 || seedY < 0 || seedX >= w || seedY >= h) return null;
        int seed = seedY * w + seedX;
        if (barrier != null && barrier[seed] != 0) return null;

        final int target = px[seed];
        final int limit = tolerance + softness;

        boolean[] done = new boolean[w * h];
        IntStack stack = new IntStack();
        stack.push(seed);

        int minX = seedX, maxX = seedX, minY = seedY, maxY = seedY;

        while (!stack.isEmpty()) {
            int idx = stack.pop();
            if (done[idx]) continue;

            int y = idx / w;
            int x = idx - y * w;
            int row = y * w;

            int x1 = x;
            while (x1 >= 0 && ok(px, done, barrier, row + x1, target, limit, mode)) x1--;
            x1++;
            int x2 = x;
            while (x2 < w && ok(px, done, barrier, row + x2, target, limit, mode)) x2++;
            x2--;
            if (x2 < x1) continue;

            for (int i = x1; i <= x2; i++) {
                int id = row + i;
                done[id] = true;
                int a = alphaFor(px[id], target, tolerance, softness, mode);
                if (a > (out[id] & 0xFF)) out[id] = (byte) a;
            }

            if (x1 < minX) minX = x1;
            if (x2 > maxX) maxX = x2;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;

            if (y > 0) push(px, done, barrier, stack, row - w, x1, x2, target, limit, mode);
            if (y < h - 1) push(px, done, barrier, stack, row + w, x1, x2, target, limit, mode);
        }
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /**
     * v8.28 (Borrar fondo con un toque): el relleno AVANZA solo por pixeles dentro de la
     * tolerancia. La franja de suavidad se aplica solo al borde (1 px alrededor de lo que se
     * relleno), sin seguir de largo. Antes avanzaba tambien por la franja (46 + 42 de fabrica):
     * de pixel a medias en pixel a medias cruzaba el antialias de la linea y las sombras oscuras
     * hasta comerse al personaje cuando su color se parecia al fondo.
     */
    public static Rect contiguousStrict(int[] px, int w, int h, byte[] out, byte[] barrier,
                                        int seedX, int seedY, int tolerance, int softness, int mode) {
        return contiguousStrict(px, w, h, out, barrier, seedX, seedY, tolerance, softness, mode, 0);
    }

    /**
     * gap > 0: ademas, si el fondo tocado se une a otra zona grande solo por un paso angosto
     * (un corte de la linea de hasta ~2*gap px, como el puno del duende), esa otra zona NO se
     * borra: se corta en lo mas angosto del paso (mismo metodo que el balde, BucketFill).
     * Para borrar tambien la otra zona basta tocarla.
     */
    public static Rect contiguousStrict(int[] px, int w, int h, byte[] out, byte[] barrier,
                                        int seedX, int seedY, int tolerance, int softness, int mode, int gap) {
        Rect r = contiguous(px, w, h, out, barrier, seedX, seedY, tolerance, 0, mode);
        if (r == null) return r;
        if (gap > 0) r = splitGaps(out, w, h, r, seedX, seedY, gap);
        if (r == null) return null;
        int target = px[seedY * w + seedX];
        int x0 = Math.max(0, r.left - 1), y0 = Math.max(0, r.top - 1);
        int x1 = Math.min(w, r.right + 1), y1 = Math.min(h, r.bottom + 1);
        int minX = r.left, minY = r.top, maxX = r.right - 1, maxY = r.bottom - 1;
        java.util.ArrayList<int[]> ring = new java.util.ArrayList<int[]>();
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                int i = y * w + x;
                if (out[i] == (byte) 255) continue;
                // tipo 3 (borde nitido, BgGuard): se borra si es fondo, sin avanzar
                if (barrier != null && barrier[i] != 0 && barrier[i] != 3) continue;
                boolean near = false;
                for (int dy = -1; dy <= 1 && !near; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w || (dx == 0 && dy == 0)) continue;
                        if (out[yy * w + xx] == (byte) 255) { near = true; break; }
                    }
                }
                if (!near) continue;
                int a = alphaFor(px[i], target, tolerance, Math.max(0, softness), mode);
                if (a > (out[i] & 0xFF)) ring.add(new int[]{i, a});
            }
        }
        for (int[] q : ring) {
            out[q[0]] = (byte) q[1];
            int x = q[0] % w, y = q[0] / w;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    private static Rect splitGaps(byte[] out, int w, int h, Rect r, int sx, int sy, int g) {
        int m = g + 3;
        int rx0 = Math.max(0, r.left - m), ry0 = Math.max(0, r.top - m);
        int rx1 = Math.min(w, r.right + m), ry1 = Math.min(h, r.bottom + m);
        int rw = rx1 - rx0, rh = ry1 - ry0;
        short[] d = BucketFill.chamfer(out, w, rx0, ry0, rw, rh, (g + 2) * 3);
        int cx = sx - rx0, cy = sy - ry0;
        for (int step = 0; step < 64; step++) {
            int best = d[cy * rw + cx], bx = cx, by = cy;
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                int nx = cx + dx, ny = cy + dy;
                if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                if (out[(ny + ry0) * w + nx + rx0] == 0) continue;
                if (d[ny * rw + nx] > best) { best = d[ny * rw + nx]; bx = nx; by = ny; }
            }
            if (bx == cx && by == cy) break;
            cx = bx; cy = by;
        }
        int rad = Math.min(g, d[cy * rw + cx] / 3 - 1);
        if (rad < 1) return r;
        byte[] other = BucketFill.splitAtGaps(out, w, rx0, ry0, rw, rh, d, rad * 3, cx, cy);
        if (other == null) return r;
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = ry0; y < ry1; y++)
            for (int x = rx0; x < rx1; x++) {
                if (out[y * w + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** Selecciona ese color en TODA la imagen, no solo lo que esta pegado. */
    public static Rect global(int[] px, int w, int h, byte[] out,
                              int seedX, int seedY, int tolerance, int softness, int mode) {
        if (seedX < 0 || seedY < 0 || seedX >= w || seedY >= h) return null;
        return globalColor(px, w, h, out, px[seedY * w + seedX], tolerance, softness, mode);
    }

    /** Igual que global pero dando el color a mano. Lo usa Gama de colores. */
    public static Rect globalColor(int[] px, int w, int h, byte[] out, int target,
                                   int tolerance, int softness, int mode) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int a = alphaFor(px[row + x], target, tolerance, softness, mode);
                if (a <= 0) continue;
                if (a > (out[row + x] & 0xFF)) out[row + x] = (byte) a;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** 255 si es el mismo color, 0 si esta fuera, y rampa suave en el filo. */
    private static int alphaFor(int c, int target, int tolerance, int softness, int mode) {
        int d = ColorDist.dist(c, target, mode);
        if (d <= tolerance) return 255;
        if (softness <= 0) return 0;
        int over = d - tolerance;
        if (over >= softness) return 0;
        return 255 - (over * 255) / softness;
    }

    private static void push(int[] px, boolean[] done, byte[] barrier, IntStack stack,
                             int row, int x1, int x2, int target, int limit, int mode) {
        boolean run = false;
        for (int i = x1; i <= x2; i++) {
            boolean good = ok(px, done, barrier, row + i, target, limit, mode);
            if (good && !run) {
                stack.push(row + i);
                run = true;
            } else if (!good) {
                run = false;
            }
        }
    }

    /** Pila que crece sola. Evita pasarse el indice entre metodos. */
    private static final class IntStack {
        private int[] a = new int[4096];
        private int n = 0;

        void push(int v) {
            if (n == a.length) {
                int[] b = new int[a.length * 2];
                System.arraycopy(a, 0, b, 0, a.length);
                a = b;
            }
            a[n++] = v;
        }

        int pop() {
            return a[--n];
        }

        boolean isEmpty() {
            return n == 0;
        }
    }

    private static boolean ok(int[] px, boolean[] done, byte[] barrier, int idx,
                              int target, int limit, int mode) {
        if (done[idx]) return false;
        if (barrier != null && barrier[idx] != 0) return false;
        return ColorDist.dist(px[idx], target, mode) <= limit;
    }

    public static boolean similar(int a, int b, int tol) {
        return ColorDist.dist(a, b, ColorDist.RGB) <= tol;
    }

}
