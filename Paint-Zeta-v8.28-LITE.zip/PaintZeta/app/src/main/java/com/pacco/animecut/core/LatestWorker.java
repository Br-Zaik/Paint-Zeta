package com.pacco.animecut.core;

/**
 * Un hilo propio que ejecuta SOLO el ultimo trabajo pedido. Si mientras
 * calcula llegan 10 pedidos, al terminar hace solo el mas reciente. Asi la
 * vista previa de Marioneta nunca se atrasa ni bloquea el dedo.
 */
public final class LatestWorker {
    private final Object lock = new Object();
    private Runnable pending;
    private boolean running, stopped;
    private final Thread thread;

    public LatestWorker(String name) {
        thread = new Thread(new Runnable() {
            @Override public void run() { loop(); }
        }, name);
        thread.setDaemon(true);
        try { thread.setPriority(Thread.NORM_PRIORITY - 1); } catch (Throwable ignored) {}
        thread.start();
    }

    private void loop() {
        while (true) {
            Runnable job;
            synchronized (lock) {
                while (pending == null && !stopped) {
                    try { lock.wait(); } catch (InterruptedException e) { return; }
                }
                if (stopped) { running = false; lock.notifyAll(); return; }
                job = pending;
                pending = null;
                running = true;
            }
            try {
                job.run();
            } catch (Throwable t) {
                // Un fallo de la vista previa nunca debe cerrar la app.
            }
            synchronized (lock) {
                running = false;
                lock.notifyAll();
            }
        }
    }

    public void submit(Runnable job) {
        synchronized (lock) {
            if (stopped) return;
            pending = job;
            lock.notifyAll();
        }
    }

    /** Descarta lo pendiente y espera a que termine lo que se esta haciendo. */
    public boolean cancelAndWait(long maxMs) {
        long end = System.currentTimeMillis() + maxMs;
        synchronized (lock) {
            pending = null;
            while (running) {
                long left = end - System.currentTimeMillis();
                if (left <= 0) return false;
                try { lock.wait(left); } catch (InterruptedException e) { return false; }
            }
        }
        return true;
    }

    public boolean isBusy() {
        synchronized (lock) { return running || pending != null; }
    }

    public void stop() {
        synchronized (lock) {
            stopped = true;
            pending = null;
            lock.notifyAll();
        }
    }
}
