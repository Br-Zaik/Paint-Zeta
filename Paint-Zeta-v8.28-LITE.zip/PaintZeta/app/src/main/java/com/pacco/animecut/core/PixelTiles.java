package com.pacco.animecut.core;

/**
 * Lectura por bloques de 64x64 de una imagen que NO esta en un int[] de Java
 * (por ejemplo el Bitmap de Transformar). Guarda como maximo {@code maxTiles}
 * bloques: en una imagen de 4960x7016 no se crea otra copia completa.
 *
 * Fuera de la imagen devuelve 0 (transparente). Una instancia por hilo.
 */
public final class PixelTiles {
    public static final int TILE = 64, SHIFT = 6, MASK = 63;

    /** Origen de los pixeles: copia el rectangulo pedido en dst (ARGB, sin premultiplicar). */
    public interface Reader {
        void read(int x, int y, int w, int h, int[] dst, int offset, int stride);
    }

    /** Lector sobre un int[] (pruebas y capas de Java). */
    public static Reader of(final int[] px, final int width) {
        return new Reader() {
            @Override public void read(int x, int y, int w, int h, int[] dst, int offset, int stride) {
                for (int j = 0; j < h; j++) System.arraycopy(px, (y + j) * width + x, dst, offset + j * stride, w);
            }
        };
    }

    public final int width, height, tilesX, tilesY;
    private final Reader reader;
    private final int[][] tiles;
    private final long[] lru;     // ultima "hora" de uso de cada bloque
    private final int maxTiles;
    private int loaded;
    private long clock;
    private final int[] keysLoaded;

    public PixelTiles(Reader reader, int width, int height, int maxTiles) {
        this.reader = reader;
        this.width = width;
        this.height = height;
        this.tilesX = (width + TILE - 1) / TILE;
        this.tilesY = (height + TILE - 1) / TILE;
        this.tiles = new int[tilesX * tilesY][];
        this.lru = new long[tilesX * tilesY];
        this.maxTiles = Math.max(8, maxTiles);
        this.keysLoaded = new int[this.maxTiles];
    }

    private int[] load(int key) {
        int[] t;
        if (loaded >= maxTiles) {
            // Expulsa el bloque usado hace mas tiempo (la lista es corta).
            int bi = 0;
            long best = Long.MAX_VALUE;
            for (int i = 0; i < loaded; i++) {
                int k = keysLoaded[i];
                if (lru[k] < best) { best = lru[k]; bi = i; }
            }
            int old = keysLoaded[bi];
            t = tiles[old];
            tiles[old] = null;
            keysLoaded[bi] = key;
        } else {
            t = new int[TILE * TILE];
            keysLoaded[loaded++] = key;
        }
        int tx = key % tilesX, ty = key / tilesX;
        int left = tx * TILE, top = ty * TILE;
        int tw = Math.min(TILE, width - left), th = Math.min(TILE, height - top);
        if (tw < TILE || th < TILE) java.util.Arrays.fill(t, 0);
        reader.read(left, top, tw, th, t, 0, TILE);
        tiles[key] = t;
        return t;
    }

    /** Pixel ARGB; 0 fuera de la imagen. */
    public int get(int x, int y) {
        if (x < 0 || y < 0 || x >= width || y >= height) return 0;
        int key = (y >> SHIFT) * tilesX + (x >> SHIFT);
        int[] t = tiles[key];
        if (t == null) t = load(key);
        lru[key] = ++clock;
        return t[((y & MASK) << SHIFT) | (x & MASK)];
    }

    /** Solo el alfa. */
    public int alpha(int x, int y) {
        return get(x, y) >>> 24;
    }
}
