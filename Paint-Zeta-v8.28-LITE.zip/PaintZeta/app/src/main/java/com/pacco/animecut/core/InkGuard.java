package com.pacco.animecut.core;

/**
 * v8.27 "Proteger contornos" de la brocha: que pixeles son TINTA (no se tapan).
 *
 * Fallos medidos en v8.26 con el manga real (capa_1 encima del dibujo):
 *  - La linea se buscaba con AutoLines sobre TODO el dibujo: los puntitos de la
 *    trama contaban como linea y la brocha dejaba manchitas blancas sin pintar.
 *  - La referencia incluia la propia capa donde se pinta: un brochazo rojo anterior
 *    (brillo 89) contaba como "linea" y cortaba el siguiente brochazo.
 *
 * Aqui:
 *  1. Tinta = oscuro (brillo menor que el umbral) Y poco saturado; o muy oscuro
 *     (brillo < 60, contorno marron o azul oscuro). Un color de relleno vivo
 *     (rojo, piel, azul) NUNCA es tinta.
 *  2. Los puntitos de trama (componentes chicas aisladas) no son tinta: se reutiliza
 *     el mapa de tinta del balde manga (MangaFill.lineMap, modo trama).
 */
public final class InkGuard {
    private InkGuard() { }

    /** Tinta segun brillo y saturacion (ver arriba). c opaco (compuesto sobre papel). */
    public static boolean inkLike(int c, int darkThr) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        int lum = (r * 77 + g * 151 + b * 28) >> 8;
        if (lum >= darkThr) return false;
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        return lum < 60 || mx - mn < 90;
    }

    /**
     * Mapa de tinta de una region (ref compuesto sobre papel blanco, w x h).
     * @return 1 = tinta (linea), 0 = se puede pintar
     */
    public static byte[] inkMap(int[] ref, int w, int h, int darkThr) {
        int n = w * h;
        int[] tmp = new int[n];
        for (int i = 0; i < n; i++) tmp[i] = inkLike(ref[i], darkThr) ? ref[i] : 0xFFFFFFFF;
        MangaFill.Params p = new MangaFill.Params();
        p.darkThr = darkThr;
        p.tone = true;
        return MangaFill.lineMap(tmp, w, h, p);
    }
}
