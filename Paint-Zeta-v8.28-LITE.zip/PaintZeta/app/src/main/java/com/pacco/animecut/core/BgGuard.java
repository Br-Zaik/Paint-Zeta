package com.pacco.animecut.core;

/**
 * v8.28: protecciones de Borrar fondo (pincel y toque).
 *
 * 1) LINEA DEL CONTORNO como barrera: un pixel es "linea" si es claramente mas oscuro que
 *    el fondo que se borra (y poco saturado o muy oscuro) Y forma un trazo FINO (en alguna
 *    direccion la parte oscura mide 7 px o menos). Asi una zona oscura ancha del fondo
 *    (una roca de la cueva) no frena el borrado, pero la linea negra del dibujo si.
 *    Los cortes de 1 px de la linea (JPEG, antialias) se cierran.
 *    Con fondo de tono medio u oscuro se agrega el BORDE NITIDO (tipo 3): se borra si es fondo,
 *    pero el borrado no avanza por ahi.
 *    Caso real (imagen 6): verde del duende (74,82,58) vs cueva (93,90,81): diferencia 23,
 *    dentro de la tolerancia 46. La linea (47,46,41) vs cueva: 46 = la tolerancia -> antes
 *    se borraba y el borrado cruzaba al personaje. Ahora la linea frena el borrado.
 * 2) MOTAS: grupos chicos que quedan sueltos, rodeados de transparencia por todos lados,
 *    parecidos al fondo (o casi invisibles). Nunca se borra una linea oscura de mas de 2 px.
 */
public final class BgGuard {
    private BgGuard() { }

    public static int luma(int c) {
        return (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
    }

    private static int sat(int c) {
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        return mx - mn;
    }

    /** Oscuro como tinta comparado con el fondo de referencia. */
    public static boolean inkLike(int c, int ref) {
        if ((c >>> 24) < 128) return false;
        int l = luma(c), lr = luma(ref);
        if (l > lr - 28 || l >= 110) return false;
        return l < 60 || sat(c) < 90;
    }

    /**
     * Barrera de linea para una ventana de pixeles ORIGINALES (ww x wh).
     * out[j] = 1 si el pixel es linea fina del contorno (o tapa un corte de 1 px).
     */
    public static void barrier(int[] win, int ww, int wh, int ref, byte[] ink, byte[] out) {
        int n = ww * wh;
        for (int j = 0; j < n; j++) { ink[j] = (byte) (inkLike(win[j], ref) ? 1 : 0); out[j] = 0; }
        // trazo fino: en alguna direccion el tramo oscuro mide 7 px o menos (4 pasadas O(n);
        // un tramo que toca el borde de la ventana cuenta como largo)
        runs(ink, ww, wh, 1, 0, out);
        runs(ink, ww, wh, 0, 1, out);
        runs(ink, ww, wh, 1, 1, out);
        runs(ink, ww, wh, 1, -1, out);
        // v8.28: fondo de color o de tono medio/oscuro (cueva): la linea del dibujo no siempre es
        // mucho mas oscura que el fondo, pero si tiene BORDE NITIDO (salto de brillo fuerte en 2 px)
        // mientras que un fondo pintado o desenfocado cambia suave. Esos pixeles de borde (tipo 3)
        // se pueden borrar si son fondo, pero el borrado no avanza por ellos. Con fondo de papel
        // claro no se usa (las tramas tienen bordes nitidos por todos lados).
        int lref0 = luma(ref);
        if (lref0 < 170) {
            for (int y = 1; y < wh - 1; y++) {
                for (int x = 1; x < ww - 1; x++) {
                    int j = y * ww + x;
                    if (out[j] != 0) continue;
                    int ex = Math.abs(luma(win[j + 1]) - luma(win[j - 1]));
                    int ey = Math.abs(luma(win[j + ww]) - luma(win[j - ww]));
                    if (ex >= EDGE || ey >= EDGE) out[j] = 3;
                }
            }
        }
        // cerrar cortes de 1 px: un pixel no-linea entre dos pixeles de linea opuestos, SOLO si
        // el mismo es algo oscuro (linea debil de JPEG). Un pixel de papel entre dos lineas es un
        // pasillo de fondo de verdad y no se tapa (si no, quedaba papel blanco encerrado).
        int lr = luma(ref);
        for (int y = 1; y < wh - 1; y++) {
            for (int x = 1; x < ww - 1; x++) {
                int j = y * ww + x;
                if (out[j] != 0) continue;
                if (luma(win[j]) > lr - 10) continue;
                if ((out[j - 1] == 1 && out[j + 1] == 1) || (out[j - ww] == 1 && out[j + ww] == 1)
                        || (out[j - ww - 1] == 1 && out[j + ww + 1] == 1)
                        || (out[j - ww + 1] == 1 && out[j + ww - 1] == 1))
                    out[j] = 2;
            }
        }
    }

    /** Salto de brillo en 2 px que cuenta como borde nitido (tipo 3). */
    public static final int EDGE = 44;

    /** Marca out=1 en los tramos de tinta de largo <= 7 en la direccion (dx,dy). */
    private static void runs(byte[] ink, int ww, int wh, int dx, int dy, byte[] out) {
        // puntos de inicio de cada recta en esa direccion
        int starts = dy == 0 ? wh : dx == 0 ? ww : ww + wh - 1;
        for (int s = 0; s < starts; s++) {
            int x, y;
            if (dy == 0) { x = 0; y = s; }
            else if (dx == 0) { x = s; y = 0; }
            else if (dy == 1) { if (s < ww) { x = s; y = 0; } else { x = 0; y = s - ww + 1; } }
            else { if (s < ww) { x = s; y = wh - 1; } else { x = 0; y = wh - 1 - (s - ww + 1); } }
            int runStart = -1, rx = 0, ry = 0, len = 0;
            boolean atBorder = false;
            while (x >= 0 && y >= 0 && x < ww && y < wh) {
                int j = y * ww + x;
                if (ink[j] != 0) {
                    if (runStart < 0) {
                        runStart = j; rx = x; ry = y; len = 0;
                        atBorder = x - dx < 0 || y - dy < 0 || x - dx >= ww || y - dy >= wh;
                    }
                    len++;
                } else if (runStart >= 0) {
                    if (len <= 7 && !atBorder) mark(out, ww, rx, ry, dx, dy, len);
                    runStart = -1;
                }
                x += dx; y += dy;
            }
            // tramo que llega al borde: largo (no se marca)
        }
    }

    private static void mark(byte[] out, int ww, int x, int y, int dx, int dy, int len) {
        for (int k = 0; k < len; k++) { out[(y + dy * k) * ww + x + dx * k] = 1; }
    }

    private static int alphaAt(int[] px, int w, byte[] alphaWin, int ww, int x0, int y0, int x, int y) {
        if (alphaWin != null) return alphaWin[(y - y0) * ww + x - x0] & 0xFF;
        return px[y * w + x] >>> 24;
    }

    /** Barrera de linea para toda la imagen (Borrar fondo con un toque; va en otro hilo). */
    public static byte[] barrierFull(int[] px, int w, int h, int ref) {
        byte[] ink = new byte[w * h], out = new byte[w * h];
        barrier(px, w, h, ref, ink, out);
        return out;
    }

    /**
     * Motas: componentes (8 vecinos) de pixeles con alfa > 0 dentro de [x0,x1)x[y0,y1) que
     * no tocan el borde de esa ventana (ni el de la imagen), y por eso estan rodeadas de
     * transparencia. Se borran si son chicas y parecidas al fondo, o casi invisibles,
     * o diminutas (<= 3 px) sin tinta. Devuelve los indices a borrar (sin repetir).
     */
    public static int[] specks(int[] px, int w, int h, int x0, int y0, int x1, int y1, int ref,
                               int bgLike, int maxPx, int colorMode) {
        return specks(px, w, h, x0, y0, x1, y1, null, null, ref, bgLike, maxPx, colorMode, false);
    }

    public static int[] specks(int[] px, int w, int h, int x0, int y0, int x1, int y1, byte[] alphaWin,
                               int ref, int bgLike, int maxPx, int colorMode) {
        return specks(px, w, h, x0, y0, x1, y1, alphaWin, null, ref, bgLike, maxPx, colorMode, false);
    }

    /**
     * Igual, pero con el alfa NUEVO de la ventana en alphaWin (Borrar fondo con un toque lo
     * calcula en otro hilo antes de tocar la capa). alphaWin == null: se usa el alfa de px.
     */
    /**
     * colWin (puede ser null): colores ORIGINALES de la ventana (fila a fila, ancho x1-x0). Con el
     * pincel, el filo ya descontaminado tiene color de tinta y poco alfa: para decidir si una mota
     * es tinta o papel se mira el color que tenia antes del trazo.
     */
    public static int[] specks(int[] px, int w, int h, int x0, int y0, int x1, int y1, byte[] alphaWin,
                               int[] colWin, int ref, int bgLike, int maxPx, int colorMode, boolean paperBits) {
        int ox0 = x0, oy0 = y0, oww = x1 - x0;
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(w, x1); y1 = Math.min(h, y1);
        int ww = x1 - x0, wh = y1 - y0;
        if (ww <= 2 || wh <= 2) return new int[0];
        byte[] seen = new byte[ww * wh];
        int[] stack = new int[Math.max(16, maxPx * 9 + 16)];
        int[] comp = new int[maxPx + 1];
        int[] kill = new int[64];
        int nk = 0;
        for (int sy = y0; sy < y1; sy++) {
            for (int sx = x0; sx < x1; sx++) {
                int sj = (sy - y0) * ww + sx - x0;
                if (seen[sj] != 0 || alphaAt(px, w, alphaWin, ww, x0, y0, sx, sy) == 0) continue;
                // recorrido; si crece mas de maxPx o toca el borde, se marca entero como visto
                int sp = 0, cnt = 0;
                boolean big = false;
                stack[sp++] = sj;
                seen[sj] = 1;
                while (sp > 0) {
                    int j = stack[--sp];
                    int ly = j / ww, lx = j - ly * ww;
                    if (cnt <= maxPx) comp[Math.min(cnt, maxPx)] = j;
                    cnt++;
                    if (cnt > maxPx) big = true;
                    if (lx == 0 || ly == 0 || lx == ww - 1 || ly == wh - 1) big = true;
                    for (int dy = -1; dy <= 1; dy++) {
                        int yy = ly + dy;
                        if (yy < 0 || yy >= wh) continue;
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = lx + dx;
                            if (xx < 0 || xx >= ww || (dx == 0 && dy == 0)) continue;
                            int q = yy * ww + xx;
                            if (seen[q] != 0 || alphaAt(px, w, alphaWin, ww, x0, y0, x0 + xx, y0 + yy) == 0) continue;
                            seen[q] = 1;
                            if (sp >= stack.length) {
                                int[] ns = new int[stack.length * 2];
                                System.arraycopy(stack, 0, ns, 0, sp);
                                stack = ns;
                            }
                            stack[sp++] = q;
                        }
                    }
                }
                if (big) continue;
                int inkN = 0, likeN = 0, maxA = 0, paleN = 0;
                int lref = luma(ref);
                for (int k = 0; k < cnt; k++) {
                    int j = comp[k];
                    int c = px[(y0 + j / ww) * w + x0 + j % ww];
                    int a = alphaWin != null ? alphaWin[j] & 0xFF : c >>> 24;
                    if (colWin != null) c = colWin[(y0 + j / ww - oy0) * oww + x0 + j % ww - ox0];
                    maxA = Math.max(maxA, a);
                    int l = luma(c | 0xFF000000);
                    if (l <= lref - 28 && l < 110) inkN++;
                    if (ColorDist.dist(c | 0xFF000000, ref | 0xFF000000, colorMode) <= bgLike) likeN++;
                    // papel gris claro (JPEG, trama suelta del fondo): claro y sin color
                    if (l >= 110 && l >= lref - 90 && sat(c) < 48) paleN++;
                }
                boolean remove;
                if (inkN > 2) remove = false;                       // una linea o un detalle oscuro
                else if (maxA < 64) remove = true;                  // casi invisible
                else if (likeN * 10 >= cnt * 7) remove = true;      // parecido al fondo
                else if (paleN * 10 >= cnt * 9) remove = true;      // v8.28: mota clara sin color (captura 4)
                else remove = cnt <= 3 && inkN == 0;                // ruido diminuto
                if (!remove) continue;
                for (int k = 0; k < cnt; k++) {
                    if (nk >= kill.length) {
                        int[] nkl = new int[kill.length * 2];
                        System.arraycopy(kill, 0, nkl, 0, nk);
                        kill = nkl;
                    }
                    int j = comp[k];
                    kill[nk++] = (y0 + j / ww) * w + x0 + j % ww;
                }
            }
        }
        // 2) v8.28: restos de papel pegados a una linea (capturas 2 y 4): grupo chico de pixeles
        //    CLAROS sin color (sin contar la tinta vecina) que toca lo ya borrado. El papel propio
        //    del personaje (camisa, brillos) esta encerrado por la linea o es grande: no se toca.
        if (!paperBits) {
            int[] r0 = new int[nk];
            System.arraycopy(kill, 0, r0, 0, nk);
            return r0;
        }
        java.util.Arrays.fill(seen, (byte) 0);
        int lref = luma(ref);
        for (int k = 0; k < nk; k++) {
            int i = kill[k], yy = i / w - y0, xx = i % w - x0;
            seen[yy * ww + xx] = 1;   // ya se borra
        }
        for (int sy = y0; sy < y1; sy++) {
            for (int sx = x0; sx < x1; sx++) {
                int sj = (sy - y0) * ww + sx - x0;
                if (seen[sj] != 0 || !pale(px, w, alphaWin, colWin, ww, x0, y0, ox0, oy0, oww, sx, sy, lref)) continue;
                int sp = 0, cnt = 0;
                boolean big = false, touchesClear = false;
                stack[sp++] = sj;
                seen[sj] = 1;
                while (sp > 0) {
                    int j = stack[--sp];
                    int ly = j / ww, lx = j - ly * ww;
                    if (cnt <= maxPx) comp[Math.min(cnt, maxPx)] = j;
                    cnt++;
                    if (cnt > maxPx) big = true;
                    if (lx == 0 || ly == 0 || lx == ww - 1 || ly == wh - 1) big = true;
                    for (int dy = -1; dy <= 1; dy++) {
                        int yy = ly + dy;
                        if (yy < 0 || yy >= wh) continue;
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = lx + dx;
                            if (xx < 0 || xx >= ww || (dx == 0 && dy == 0)) continue;
                            int q = yy * ww + xx;
                            if (alphaAt(px, w, alphaWin, ww, x0, y0, x0 + xx, y0 + yy) == 0) { touchesClear = true; continue; }
                            if (seen[q] != 0 || !pale(px, w, alphaWin, colWin, ww, x0, y0, ox0, oy0, oww, x0 + xx, y0 + yy, lref)) continue;
                            seen[q] = 1;
                            if (sp >= stack.length) {
                                int[] ns = new int[stack.length * 2];
                                System.arraycopy(stack, 0, ns, 0, sp);
                                stack = ns;
                            }
                            stack[sp++] = q;
                        }
                    }
                }
                if (big || !touchesClear || cnt > Math.max(6, maxPx / 2)) continue;
                for (int k = 0; k < cnt; k++) {
                    if (nk >= kill.length) {
                        int[] nkl = new int[kill.length * 2];
                        System.arraycopy(kill, 0, nkl, 0, nk);
                        kill = nkl;
                    }
                    int j = comp[k];
                    kill[nk++] = (y0 + j / ww) * w + x0 + j % ww;
                }
            }
        }
        int[] r = new int[nk];
        System.arraycopy(kill, 0, r, 0, nk);
        return r;
    }

    /** Pixel visible cuyo color (original si hay colWin) es papel claro sin color. */
    private static boolean pale(int[] px, int w, byte[] alphaWin, int[] colWin, int ww, int x0, int y0,
                                int ox0, int oy0, int oww, int x, int y, int lref) {
        if (alphaAt(px, w, alphaWin, ww, x0, y0, x, y) == 0) return false;
        int c = colWin != null ? colWin[(y - oy0) * oww + x - ox0] : px[y * w + x];
        int l = luma(c | 0xFF000000);
        return l >= 150 && l >= lref - 60 && sat(c) < 40;
    }
}
