package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * v8.27 "Refinar borde" (Borrar fondo): limpia el filo de una capa YA recortada
 * (o recien borrada), con vista previa. Sin IA: solo color, alfa y distancias.
 *
 * Problema que resuelve (captura 5): alrededor del personaje queda un filo blanco o
 * gris irregular. Son pixeles del antialias entre el contorno y el fondo viejo: tienen
 * color de fondo mezclado (C = a*F + (1-a)*B) y alfa alto. Sobre otro fondo se ven
 * como una franja clara.
 *
 * Pasos (todos se pueden apagar o graduar):
 *  1. RESTOS SUELTOS: grupos de pixeles visibles de hasta 'speckle' px, rodeados de
 *     transparencia (motas del fondo viejo), se borran.
 *  2. DESCONTAMINAR (franja de 3 px pegada a lo transparente): el pixel se mira como
 *     se veia sobre el fondo original B. Si mas adentro hay tinta oscura y el pixel es
 *     mezcla de esa tinta con B, su alfa pasa a ser la parte de tinta y su color el de
 *     la tinta. Si el pixel es casi del color de B, es resto de fondo: "color a alfa".
 *     Nunca se SUBE el alfa, y un pixel que no es mezcla con B no se toca (asi no se
 *     pone todo el borde negro ni transparente).
 *  3. CONTRAER / EXPANDIR (-2..+2 px, con fracciones): + come el filo, - lo devuelve
 *     (con el color del pixel visible mas cercano, no con el del fondo viejo). Con
 *     "proteger lineas oscuras" el contraer no se come la tinta.
 *  4. SUAVIZAR solo en la franja del borde (0..1).
 *
 * No modifica 'px': devuelve la zona nueva para mostrarla como vista previa.
 */
public final class EdgeRefine {
    private EdgeRefine() { }

    public static final class Params {
        /** Color del fondo que habia (blanco de fabrica). */
        public int bg = 0xFFFFFFFF;
        /** 0..1 cuanto se descontamina. */
        public float decontam = 1f;
        /** -2..+2 px: + contrae (come el filo), - expande. */
        public float shift = 0f;
        /** 0..1 suavizado del alfa en el borde. */
        public float smooth = 0f;
        /** Restos sueltos de hasta este tamano se borran (0 = no). */
        public int speckle = 12;
        /** Contraer no se come los pixeles oscuros (contornos). */
        public boolean keepDark = true;
    }

    public static final class Result {
        public Rect r;
        /** Pixeles nuevos de la zona r (fila por fila). */
        public int[] px;
        public int changed, decontaminated, speckles, contracted, expanded, smoothed;
    }

    static int lum(int c) {
        return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
    }

    /** Recuadro con todo lo visible de la capa, mas un margen (null si no hay nada). */
    public static Rect visibleBounds(int[] px, int w, int h, int margin) {
        int x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if ((px[row + x] >>> 24) == 0) continue;
                if (x < x0) x0 = x;
                if (x > x1) x1 = x;
                if (y < y0) y0 = y;
                if (y > y1) y1 = y;
            }
        }
        if (x1 < 0) return null;
        return new Rect(Math.max(0, x0 - margin), Math.max(0, y0 - margin), Math.min(w, x1 + 1 + margin), Math.min(h, y1 + 1 + margin));
    }

    public static Result run(int[] src, int w, int h, Rect roi, Params p) {
        Result res = new Result();
        res.r = new Rect(roi);
        int rw = roi.width(), rh = roi.height(), n = rw * rh;
        int[] out = new int[n];
        for (int y = 0; y < rh; y++) System.arraycopy(src, (roi.top + y) * w + roi.left, out, y * rw, rw);
        res.px = out;
        if (n == 0) return res;
        int[] orig = out.clone();

        // ---- 1. restos sueltos ----
        if (p.speckle > 0) res.speckles = removeSpeckles(out, rw, rh, p.speckle);

        // distancia (pasos, 8 vecinos) a lo transparente (alfa < 8), tope 6
        byte[] d = distToClear(out, rw, rh, 6);

        // ---- 2. descontaminar (2 pasadas: quitar el resto del fondo deja al descubierto
        //      el antialias del contorno que estaba detras, y ese tambien se limpia) ----
        for (int pass = 0; pass < 2 && p.decontam > 0f; pass++) {
            int B = p.bg;
            int br = (B >> 16) & 255, bgc = (B >> 8) & 255, bb = B & 255, bl = lum(B);
            int[] snap = out.clone();
            int before = res.decontaminated;
            for (int y = 0; y < rh; y++) {
                for (int x = 0; x < rw; x++) {
                    int k = y * rw + x;
                    int dk = d[k];
                    if (dk < 1 || dk > 3) continue;
                    int c = snap[k], A = c >>> 24;
                    if (A == 0) continue;
                    // como se veia sobre el fondo original
                    float af = A / 255f;
                    float vr = ((c >> 16) & 255) * af + br * (1 - af);
                    float vg = ((c >> 8) & 255) * af + bgc * (1 - af);
                    float vb = (c & 255) * af + bb * (1 - af);
                    int lv = (int) ((vr * 77 + vg * 151 + vb * 28) / 256f);
                    // tinta mas adentro
                    int ink = -1, inkL = 256;
                    for (int dy = -3; dy <= 3; dy++) {
                        int yy = y + dy;
                        if (yy < 0 || yy >= rh) continue;
                        for (int dx = -3; dx <= 3; dx++) {
                            int xx = x + dx;
                            if (xx < 0 || xx >= rw) continue;
                            int j = yy * rw + xx;
                            // tinta mas adentro (radio 3) o, en lineas finas de 1-2 px (mechones),
                            // a la misma distancia del borde y pegada (radio 1)
                            boolean near1 = dx >= -1 && dx <= 1 && dy >= -1 && dy <= 1;
                            if ((d[j] < dk || (d[j] == dk && !near1)) || (snap[j] >>> 24) < 230) continue;
                            int l = lum(snap[j]);
                            if (l < inkL) { inkL = l; ink = snap[j]; }
                        }
                    }
                    // Mas AFUERA (hacia lo transparente) hay algo oscuro? Entonces este pixel esta
                    // DETRAS del contorno (papel o trama del interior): no es filo, no se toca.
                    boolean shallowDark = false;
                    for (int dy = -2; dy <= 2 && !shallowDark; dy++) {
                        int yy = y + dy;
                        if (yy < 0 || yy >= rh) continue;
                        for (int dx = -2; dx <= 2; dx++) {
                            int xx = x + dx;
                            if (xx < 0 || xx >= rw) continue;
                            int j = yy * rw + xx;
                            if (d[j] >= dk || (snap[j] >>> 24) < 128) continue;
                            if (lum(snap[j]) < lv - 40) { shallowDark = true; break; }
                        }
                    }
                    if (shallowDark) continue;
                    float t = -1f;
                    int rgb = c & 0xFFFFFF;
                    if (ink != -1 && inkL < 110 && inkL + 30 < lv && Math.abs(bl - lv) >= 12) {
                        float fr = ((ink >> 16) & 255) - br, fg = ((ink >> 8) & 255) - bgc, fb = (ink & 255) - bb;
                        float ur = vr - br, ug = vg - bgc, ub = vb - bb;
                        float f2 = fr * fr + fg * fg + fb * fb;
                        if (f2 >= 900f) {
                            float tt = (ur * fr + ug * fg + ub * fb) / f2;
                            float tc = Math.max(0f, Math.min(1f, tt));
                            float er = ur - tc * fr, eg = ug - tc * fg, eb = ub - tc * fb;
                            // tc < 0,12: casi puro fondo; eso lo decide el paso de "color a alfa"
                            // (con reglas mas estrictas), no este.
                            if (er * er + eg * eg + eb * eb <= Math.max(500f, f2 * .05f) && tc < .97f && tc >= .12f) {
                                t = tc;
                                rgb = t >= .5f ? unmix(vr, vg, vb, br, bgc, bb, t) : ink & 0xFFFFFF;
                            }
                        }
                    }
                    // vecino inmediato mas adentro y mas oscuro: es el antialias del contorno (un
                    // filo fino). Si detras sigue el blanco, es un hueco de papel sin borrar: no se toca.
                    boolean darkerBehind = false;
                    for (int dy = -1; dy <= 1 && !darkerBehind; dy++) {
                        int yy = y + dy;
                        if (yy < 0 || yy >= rh) continue;
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx;
                            if (xx < 0 || xx >= rw || (dx == 0 && dy == 0)) continue;
                            int j = yy * rw + xx;
                            if (d[j] > dk && (snap[j] >>> 24) >= 128 && lum(snap[j]) < lv - 25) { darkerBehind = true; break; }
                        }
                    }
                    // y es un filo FINO (1-2 px): si alrededor hay mucho color de fondo opaco, es
                    // papel sin borrar (un hueco entre mechones), no un halo: se deja como esta.
                    int bgLike = 0;
                    if (t < 0f && inkL < 110 && darkerBehind) {
                        for (int dy = -2; dy <= 2; dy++) {
                            int yy = y + dy;
                            if (yy < 0 || yy >= rh) continue;
                            for (int dx = -2; dx <= 2; dx++) {
                                int xx = x + dx;
                                if (xx < 0 || xx >= rw) continue;
                                int q = snap[yy * rw + xx];
                                if ((q >>> 24) < 128) continue;
                                int qr = (q >> 16) & 255, qg = (q >> 8) & 255, qb = q & 255;
                                if (Math.max(Math.abs(qr - br), Math.max(Math.abs(qg - bgc), Math.abs(qb - bb))) <= 40) bgLike++;
                            }
                        }
                    }
                    if (t < 0f && dk == 1 && inkL < 110 && darkerBehind && bgLike <= 12) {
                        // casi del color del fondo, PEGADO a lo transparente y con el contorno justo
                        // detras: resto del fondo en el filo (color a alfa). Una zona clara sin tinta
                        // cerca (camisa blanca, papel que el usuario no borro) no se toca.
                        float dr = Math.abs(vr - br), dg = Math.abs(vg - bgc), db = Math.abs(vb - bb);
                        if (Math.max(dr, Math.max(dg, db)) <= 40f) {
                            t = Math.max(chA(vr, br), Math.max(chA(vg, bgc), chA(vb, bb)));
                            rgb = t <= 0f ? c & 0xFFFFFF : unmix(vr, vg, vb, br, bgc, bb, t);
                        }
                    }
                    if (t < 0f) continue;
                    int na = Math.round(A + (t * 255f - A) * p.decontam);
                    if (na >= A) continue;
                    out[k] = (Math.max(0, na) << 24) | rgb;
                    res.decontaminated++;
                }
            }
            d = distToClear(out, rw, rh, 6);
            if (res.decontaminated == before) break;
        }

        // ---- 3. contraer / expandir ----
        if (p.shift > 0f) {
            float s = Math.min(2f, p.shift);
            for (int k = 0; k < n; k++) {
                int a = out[k] >>> 24;
                if (a == 0) continue;
                int dk = d[k];
                if (dk > 3) continue;
                if (p.keepDark && lum(out[k]) < 80) continue;
                float f = Math.max(0f, Math.min(1f, dk - s));
                if (f >= 1f) continue;
                int na = Math.round(a * f);
                out[k] = (na << 24) | (out[k] & 0xFFFFFF);
                res.contracted++;
            }
        } else if (p.shift < 0f) {
            float s = Math.min(2f, -p.shift);
            res.expanded = expand(out, rw, rh, s);
        }

        // ---- 4. suavizar en el borde ----
        if (p.smooth > 0f) {
            byte[] dd = distToClear(out, rw, rh, 3);
            int[] snap = out.clone();
            for (int y = 0; y < rh; y++) {
                for (int x = 0; x < rw; x++) {
                    int k = y * rw + x;
                    int a = snap[k] >>> 24;
                    boolean band = dd[k] >= 1 && dd[k] <= 2;
                    if (!band && a == 0) {
                        // pixel transparente pegado al borde: puede recibir un poco
                        boolean nb = false;
                        for (int dy = -1; dy <= 1 && !nb; dy++) for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx, yy = y + dy;
                            if (xx < 0 || yy < 0 || xx >= rw || yy >= rh) continue;
                            if ((snap[yy * rw + xx] >>> 24) >= 8) { nb = true; break; }
                        }
                        band = nb;
                    }
                    if (!band) continue;
                    int sum = 0, cnt = 0, nearC = -1, nearA = -1;
                    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx, yy = y + dy;
                        if (xx < 0 || yy < 0 || xx >= rw || yy >= rh) continue;
                        int q = snap[yy * rw + xx];
                        sum += q >>> 24;
                        cnt++;
                        if ((q >>> 24) > nearA) { nearA = q >>> 24; nearC = q; }
                    }
                    float avg = sum / (float) cnt;
                    int na = Math.round(a + (avg - a) * p.smooth);
                    if (na == a) continue;
                    int rgb = a == 0 ? nearC & 0xFFFFFF : snap[k] & 0xFFFFFF;
                    out[k] = (Math.max(0, Math.min(255, na)) << 24) | rgb;
                    res.smoothed++;
                }
            }
        }
        for (int k = 0; k < n; k++) if (out[k] != orig[k]) res.changed++;
        return res;
    }

    /** Pasos (8 vecinos) hasta un pixel con alfa < 8 (0 = ese pixel lo es). */
    static byte[] distToClear(int[] px, int w, int h, int cap) {
        int n = w * h;
        byte[] d = new byte[n];
        java.util.Arrays.fill(d, (byte) cap);
        int[] q = new int[n];
        int qh = 0, qt = 0;
        for (int k = 0; k < n; k++) if ((px[k] >>> 24) < 8) { d[k] = 0; q[qt++] = k; }
        // el borde del recuadro cuenta como transparente (margen agregado por el llamante)
        while (qh < qt) {
            int k = q[qh++];
            int dk = d[k];
            if (dk + 1 >= cap) continue;
            int x = k % w, y = k / w;
            for (int dy = -1; dy <= 1; dy++) {
                int yy = y + dy;
                if (yy < 0 || yy >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= w) continue;
                    int j = yy * w + xx;
                    if (d[j] <= dk + 1) continue;
                    d[j] = (byte) (dk + 1);
                    q[qt++] = j;
                }
            }
        }
        return d;
    }

    /** Borra grupos visibles (8 vecinos, alfa >= 8) de hasta max px. @return pixeles borrados */
    static int removeSpeckles(int[] px, int w, int h, int max) {
        int n = w * h;
        byte[] seen = new byte[n];
        int[] st = new int[256];
        int[] comp = new int[max + 1];
        int removed = 0;
        for (int k0 = 0; k0 < n; k0++) {
            if (seen[k0] != 0 || (px[k0] >>> 24) < 8) continue;
            int sp = 0, cnt = 0;
            st[sp++] = k0;
            seen[k0] = 1;
            while (sp > 0) {
                int k = st[--sp];
                if (cnt <= max) comp[Math.min(cnt, max)] = k;
                cnt++;
                int x = k % w, y = k / w;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int j = yy * w + xx;
                        if (seen[j] != 0 || (px[j] >>> 24) < 8) continue;
                        seen[j] = 1;
                        if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                        st[sp++] = j;
                    }
                }
            }
            if (cnt <= max) {
                for (int c = 0; c < cnt; c++) px[comp[c]] &= 0x00FFFFFF;
                removed += cnt;
            }
        }
        return removed;
    }

    /** Devuelve hasta s px de borde con el color del pixel visible mas cercano. */
    static int expand(int[] px, int w, int h, float s) {
        int n = w * h;
        int[] near = new int[n];
        byte[] d = new byte[n];
        int cap = (int) Math.ceil(s) + 1;
        java.util.Arrays.fill(d, (byte) cap);
        java.util.Arrays.fill(near, -1);
        int[] q = new int[n];
        int qh = 0, qt = 0;
        for (int k = 0; k < n; k++) if ((px[k] >>> 24) >= 128) { d[k] = 0; near[k] = k; q[qt++] = k; }
        while (qh < qt) {
            int k = q[qh++];
            int dk = d[k];
            if (dk + 1 >= cap) continue;
            int x = k % w, y = k / w;
            for (int dy = -1; dy <= 1; dy++) {
                int yy = y + dy;
                if (yy < 0 || yy >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= w) continue;
                    int j = yy * w + xx;
                    if (d[j] <= dk + 1) continue;
                    d[j] = (byte) (dk + 1);
                    near[j] = near[k];
                    q[qt++] = j;
                }
            }
        }
        int changed = 0;
        int[] snap = px.clone();
        for (int k = 0; k < n; k++) {
            if (d[k] == 0 || near[k] < 0) continue;
            float f = Math.max(0f, Math.min(1f, s - d[k] + 1f));
            if (f <= 0f) continue;
            int src = snap[near[k]];
            int want = Math.round((src >>> 24) * f);
            int a = snap[k] >>> 24;
            if (want <= a) continue;
            px[k] = (want << 24) | (src & 0xFFFFFF);
            changed++;
        }
        return changed;
    }

    private static float chA(float c, int b) {
        if (c < b) return (b - c) / (float) Math.max(1, b);
        if (c > b) return (c - b) / (float) Math.max(1, 255 - b);
        return 0f;
    }

    private static int unmix(float cr, float cg, float cb, int br, int bg, int bb, float a) {
        float k = 1f / Math.max(.02f, a);
        int r = clamp(br + (cr - br) * k), g = clamp(bg + (cg - bg) * k), b = clamp(bb + (cb - bb) * k);
        return (r << 16) | (g << 8) | b;
    }

    private static int clamp(float v) { return v < 0 ? 0 : v > 255 ? 255 : (int) (v + .5f); }
}
