package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Visor ligero de referencia: pan/zoom independiente del lienzo y toque rapido
 * para tomar un color. No pertenece al Project, por lo que nunca se exporta.
 *
 * v8.26: mantener pulsado muestra una LUPA con cruz (se mueve el dedo para afinar
 * y al soltar toma ese pixel); opcion de PROMEDIO 3x3 que ignora los pixeles muy
 * distintos (ruido JPEG o el borde de una linea). El toque solo entrega la MUESTRA:
 * la ventana decide cuando se usa ("Usar este color"), asi nunca se pinta por accidente.
 */
public class ReferenceImageView extends View {
    public interface Listener { void onColor(int color); }

    private Bitmap bitmap;
    private Listener listener;
    private final Matrix matrix = new Matrix();
    private final Matrix inverse = new Matrix();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final Paint loupePaint = new Paint();
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cross = new Paint();
    private float lastX, lastY, downX, downY;
    private float oldDist, oldMidX, oldMidY;
    private boolean multi, moved, fitted;
    private boolean average3 = true;
    /** Lupa activa (mantener pulsado). */
    private boolean loupe;
    private float loupeX, loupeY;
    private final Runnable loupeStart = new Runnable() {
        @Override public void run() {
            if (multi || moved) return;
            loupe = true;
            loupeX = downX;
            loupeY = downY;
            invalidate();
        }
    };

    public ReferenceImageView(Context c) { super(c); init(); }
    public ReferenceImageView(Context c, AttributeSet a) { super(c, a); init(); }
    private void init() {
        setBackgroundColor(0xFF151518);
        paint.setFilterBitmap(true);
        loupePaint.setFilterBitmap(false);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(3f);
        ring.setColor(0xFFFFFFFF);
        cross.setColor(0xFFFF3B3B);
        cross.setStrokeWidth(2f);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    public void setBitmap(Bitmap b) { bitmap = b; fitted = false; invalidate(); }
    public void setListener(Listener l) { listener = l; }
    public void setAverage3(boolean on) { average3 = on; }
    public boolean isAverage3() { return average3; }

    /** Vuelve a encuadrar la imagen completa. */
    public void refit() { fitted = false; invalidate(); }

    private void fit() {
        if (bitmap == null || getWidth() <= 0 || getHeight() <= 0) return;
        float s = Math.min((float)getWidth() / bitmap.getWidth(), (float)getHeight() / bitmap.getHeight());
        matrix.reset();
        matrix.postScale(s, s);
        matrix.postTranslate((getWidth() - bitmap.getWidth() * s) * .5f,
                (getHeight() - bitmap.getHeight() * s) * .5f);
        fitted = true;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        // Solo reencuadra la primera vez. Al redimensionar la ventana conserva
        // el zoom/pan que el usuario ya habia elegido.
        if (ow <= 0 || oh <= 0) fitted = false;
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (bitmap == null || bitmap.isRecycled()) return;
        if (!fitted) fit();
        c.drawBitmap(bitmap, matrix, paint);
        if (loupe) drawLoupe(c);
    }

    /** Lupa: 11x11 pixeles ampliados con una cruz en el pixel que se tomara. */
    private void drawLoupe(Canvas c) {
        int[] p = imagePixel(loupeX, loupeY);
        if (p == null) return;
        float d = getResources().getDisplayMetrics().density;
        float size = Math.min(110 * d, Math.min(getWidth(), getHeight()) * .6f);
        // arriba del dedo; si no entra, abajo
        float cx = loupeX, cy = loupeY - size * .75f;
        if (cy - size / 2 < 0) cy = loupeY + size * .75f;
        cx = Math.max(size / 2, Math.min(getWidth() - size / 2, cx));
        int n = 11, half = n / 2;
        Rect src = new Rect(p[0] - half, p[1] - half, p[0] + half + 1, p[1] + half + 1);
        RectF dst = new RectF(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2);
        c.save();
        c.clipRect(dst);
        c.drawColor(0xFF000000);
        c.drawBitmap(bitmap, src, dst, loupePaint);
        float cell = size / n;
        float x0 = dst.left + half * cell, y0 = dst.top + half * cell;
        c.drawLine(x0, y0, x0 + cell, y0, cross);
        c.drawLine(x0, y0 + cell, x0 + cell, y0 + cell, cross);
        c.drawLine(x0, y0, x0, y0 + cell, cross);
        c.drawLine(x0 + cell, y0, x0 + cell, y0 + cell, cross);
        if (average3) {
            Paint p3 = new Paint(cross);
            p3.setAlpha(110);
            c.drawLine(x0 - cell, y0 - cell, x0 + 2 * cell, y0 - cell, p3);
            c.drawLine(x0 - cell, y0 + 2 * cell, x0 + 2 * cell, y0 + 2 * cell, p3);
            c.drawLine(x0 - cell, y0 - cell, x0 - cell, y0 + 2 * cell, p3);
            c.drawLine(x0 + 2 * cell, y0 - cell, x0 + 2 * cell, y0 + 2 * cell, p3);
        }
        c.restore();
        c.drawRect(dst, ring);
    }

    private static float dist(MotionEvent e) {
        if (e.getPointerCount() < 2) return 0f;
        return (float)Math.hypot(e.getX(1) - e.getX(0), e.getY(1) - e.getY(0));
    }

    private int[] imagePixel(float sx, float sy) {
        if (bitmap == null || !matrix.invert(inverse)) return null;
        float[] p = {sx, sy};
        inverse.mapPoints(p);
        int x = (int) Math.floor(p[0]), y = (int) Math.floor(p[1]);
        if (x < 0 || y < 0 || x >= bitmap.getWidth() || y >= bitmap.getHeight()) return null;
        return new int[]{x, y};
    }

    private void pick(float sx, float sy) {
        if (bitmap == null || listener == null) return;
        int[] p = imagePixel(sx, sy);
        if (p == null) return;
        listener.onColor(sample(bitmap, p[0], p[1], average3));
    }

    /**
     * Color en (x,y). Con promedio 3x3: se promedian los vecinos cuyo brillo esta
     * cerca de la mediana (no mezcla de golpe una linea negra con la piel).
     */
    public static int sample(Bitmap b, int x, int y, boolean avg) {
        if (!avg) return b.getPixel(x, y) | 0xFF000000;
        int[] cs = new int[9];
        int[] ls = new int[9];
        int n = 0;
        for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
            int xx = x + dx, yy = y + dy;
            if (xx < 0 || yy < 0 || xx >= b.getWidth() || yy >= b.getHeight()) continue;
            int c = b.getPixel(xx, yy);
            cs[n] = c;
            ls[n] = (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
            n++;
        }
        return average(cs, ls, n);
    }

    /** Promedio de los colores con brillo a 40 o menos de la mediana (sirve para pruebas). */
    public static int average(int[] cs, int[] ls, int n) {
        int[] sorted = java.util.Arrays.copyOf(ls, n);
        java.util.Arrays.sort(sorted);
        int med = sorted[n / 2];
        long r = 0, g = 0, bl = 0;
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (Math.abs(ls[i] - med) > 40) continue;
            r += (cs[i] >> 16) & 255;
            g += (cs[i] >> 8) & 255;
            bl += cs[i] & 255;
            k++;
        }
        if (k == 0) return cs[0] | 0xFF000000;
        return 0xFF000000 | (int) ((r + k / 2) / k) << 16 | (int) ((g + k / 2) / k) << 8 | (int) ((bl + k / 2) / k);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            multi = false; moved = false; loupe = false;
            downX = lastX = e.getX(); downY = lastY = e.getY();
            removeCallbacks(loupeStart);
            postDelayed(loupeStart, 380);
            return true;
        }
        if (a == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() >= 2) {
            multi = true; moved = true;
            removeCallbacks(loupeStart);
            if (loupe) { loupe = false; invalidate(); }
            oldDist = Math.max(1f, dist(e));
            oldMidX = (e.getX(0) + e.getX(1)) * .5f;
            oldMidY = (e.getY(0) + e.getY(1)) * .5f;
            return true;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            if (loupe && e.getPointerCount() == 1) {
                loupeX = e.getX();
                loupeY = e.getY();
                invalidate();
                return true;
            }
            if (e.getPointerCount() >= 2) {
                float nd = Math.max(1f, dist(e));
                float mx = (e.getX(0) + e.getX(1)) * .5f;
                float my = (e.getY(0) + e.getY(1)) * .5f;
                float scale = Math.max(.6f, Math.min(1.7f, nd / oldDist));
                matrix.postTranslate(mx - oldMidX, my - oldMidY);
                matrix.postScale(scale, scale, mx, my);
                oldDist = nd; oldMidX = mx; oldMidY = my;
                invalidate();
            } else if (!multi) {
                float x = e.getX(), y = e.getY();
                if (Math.hypot(x - downX, y - downY) > 8f) {
                    moved = true;
                    removeCallbacks(loupeStart);
                }
                matrix.postTranslate(x - lastX, y - lastY);
                lastX = x; lastY = y;
                invalidate();
            }
            return true;
        }
        if (a == MotionEvent.ACTION_POINTER_UP) { multi = true; return true; }
        if (a == MotionEvent.ACTION_UP) {
            removeCallbacks(loupeStart);
            if (loupe) {
                loupe = false;
                pick(loupeX, loupeY);
                invalidate();
            } else if (!multi && !moved) {
                pick(e.getX(), e.getY());
            }
            multi = false;
            return true;
        }
        if (a == MotionEvent.ACTION_CANCEL) {
            removeCallbacks(loupeStart);
            multi = false;
            if (loupe) { loupe = false; invalidate(); }
            return true;
        }
        return true;
    }
}
