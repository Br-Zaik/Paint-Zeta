package com.pacco.animecut.core;

/**
 * v8.27: tiempos reales medidos DENTRO de la app (sin librerias). Cada herramienta
 * anota cuanto tardo cada evento; el informe da p50/p95/p99, maximo y cuantos
 * pasaron de 16,7 ms (un cuadro a 60 Hz), 33 ms y 700 ms (pausa visible).
 *
 * Es barato: un arreglo circular de 1024 tiempos por medida. Sirve en el telefono
 * (Menu > Medir rendimiento) y en las pruebas de la computadora (Android simulado).
 * Los numeros de la computadora NO son los de un telefono.
 */
public final class PerfStats {
    private PerfStats() { }

    public static final int FRAME = 0, TOUCH = 1, BRUSH = 2, BUCKET = 3, COMPOSE = 4,
            PUPPET = 5, PUPPET_SOLVE = 6, BGERASE = 7, EDGE_REFINE = 8, STROKE_BEGIN = 9;
    public static final String[] NAMES = {
            "Dibujar pantalla (onDraw)", "Evento tactil completo", "Pincel: trazo por evento", "Balde: calculo + pintar",
            "Recomponer zona de pantalla", "Marioneta: vista previa", "Marioneta: resolver malla", "Borrar fondo",
            "Refinar borde", "Pincel: inicio de trazo"};
    private static final int N = NAMES.length, CAP = 1024;
    private static final long[][] ring = new long[N][CAP];
    private static final int[] count = new int[N];
    private static final long[] max = new long[N];
    public static volatile boolean enabled = true;

    public static void add(int kind, long nanos) {
        if (!enabled || kind < 0 || kind >= N || nanos < 0) return;
        synchronized (ring) {
            ring[kind][count[kind] % CAP] = nanos;
            count[kind]++;
            if (nanos > max[kind]) max[kind] = nanos;
        }
    }

    public static void reset() {
        synchronized (ring) {
            for (int k = 0; k < N; k++) { count[k] = 0; max[k] = 0; }
        }
    }

    public static int count(int kind) {
        synchronized (ring) { return count[kind]; }
    }

    /** Ultimas muestras (hasta 1024), ordenadas, en nanosegundos. */
    public static long[] sorted(int kind) {
        long[] a;
        synchronized (ring) {
            int n = Math.min(CAP, count[kind]);
            a = new long[n];
            System.arraycopy(ring[kind], 0, a, 0, n);
        }
        java.util.Arrays.sort(a);
        return a;
    }

    /** Percentil p (0..100) de un arreglo ORDENADO (metodo del rango mas cercano). */
    public static long pct(long[] s, double p) {
        if (s.length == 0) return 0;
        int i = (int) Math.ceil(p / 100.0 * s.length) - 1;
        return s[Math.max(0, Math.min(s.length - 1, i))];
    }

    public static String ms(long ns) {
        double v = ns / 1e6;
        return v >= 100 ? String.valueOf(Math.round(v)) : String.format(java.util.Locale.US, "%.1f", v);
    }

    /** Una linea por medida con muestras. */
    public static String report() {
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < N; k++) {
            long[] s = sorted(k);
            if (s.length == 0) continue;
            int over16 = 0, over33 = 0, over700 = 0;
            for (long v : s) {
                if (v > 16_700_000L) over16++;
                if (v > 33_000_000L) over33++;
                if (v > 700_000_000L) over700++;
            }
            long mx;
            synchronized (ring) { mx = max[k]; }
            sb.append(NAMES[k]).append(": n=").append(count(k))
                    .append(" p50=").append(ms(pct(s, 50))).append(" p95=").append(ms(pct(s, 95)))
                    .append(" p99=").append(ms(pct(s, 99))).append(" max=").append(ms(mx)).append(" ms")
                    .append(" | >16,7ms: ").append(over16).append(" >33ms: ").append(over33)
                    .append(" >700ms: ").append(over700).append('\n');
        }
        return sb.toString();
    }
}
