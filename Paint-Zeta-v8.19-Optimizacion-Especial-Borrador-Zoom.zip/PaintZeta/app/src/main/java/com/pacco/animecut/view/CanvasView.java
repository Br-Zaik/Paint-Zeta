package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.pacco.animecut.core.AutoLines;
import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Filters;
import com.pacco.animecut.core.FloodFill;
import com.pacco.animecut.core.GuidedFilter;
import com.pacco.animecut.core.HoleFill;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.LineArt;
import com.pacco.animecut.core.LineRepair;
import com.pacco.animecut.core.LiveWire;
import com.pacco.animecut.core.MaskOps;
import com.pacco.animecut.core.Membrane;
import com.pacco.animecut.core.PatchFill;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.ToneFill;
import com.pacco.animecut.core.UndoManager;
import com.pacco.animecut.core.Watershed;
import com.pacco.animecut.core.ZoneFill;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * El lienzo, trabajando igual que Ibis: capas de verdad con transparencia,
 * una capa de seleccion (lo azul), y dos dedos que solo mueven y hacen zoom.
 */
public class CanvasView extends View {

    public static final int MODE_PAN = 0;
    public static final int MODE_WAND = 1;
    public static final int MODE_BRUSH = 2;
    public static final int MODE_ERASER = 3;
    public static final int MODE_LASSO = 4;
    public static final int MODE_CLONE = 5;
    public static final int MODE_PAINT = 6;
    public static final int MODE_BUCKET = 7;
    public static final int MODE_PICKER = 8;
    public static final int MODE_SCISSORS = 9;
    public static final int MODE_MOVE = 10;
    public static final int MODE_BGERASE = 11;
    public static final int MODE_MARKER = 12;
    public static final int MODE_MAGNET = 13;
    public static final int MODE_LINE = 14;
    public static final int MODE_ZONE = 15;
    public static final int MODE_PATCH = 16;
    public static final int MODE_HEAL = 17;
    public static final int MODE_TONE = 18;
    /** Curva Bezier: puntos que se unen con una curva suave. */
    public static final int MODE_CURVE = 19;
    /** Polilinea: puntos que se unen con lineas rectas. */
    public static final int MODE_POLY = 20;
    /** Difuminar: arrastra y mezcla pixeles siguiendo el dedo. */
    public static final int MODE_SMUDGE = 21;
    /** Borrosidad: desenfoque local solo bajo el pincel. */
    public static final int MODE_BLUR = 22;
    /** Especial: licuar con arrastrar/contraer/expandir/suavizar/restaurar. */
    public static final int MODE_LIQUIFY = 23;
    /** Transformar: mover/escala/giro, perspectiva, malla y puntos/anclajes. */
    public static final int MODE_TRANSFORM = 24;

    public static final String[] LABEL_NAMES = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "fondo"};
    public static final int[] LABEL_COLORS = {
            0xFFFF5A5F, 0xFFFFC94A, 0xFF1ED6A0, 0xFF1A9BFF, 0xFFFF4FA3, 0xFFB9794A,
            0xFF8B5CF6, 0xFF3B82F6, 0xFFFB7A1B, 0xFF84CC16, 0xFFF9A8D4, 0xFF8A8A8A
    };
    public static final int BG_LABEL = 12;

    /** Fondos para mirar: cuadros claros, cuadros oscuros, blanco, negro, verde. */
    public static final int[][] VIEW_BG = {
            {0xFFFFFFFF, 0xFFD6D6D6}, {0xFF4A4A50, 0xFF33333A}, {0xFFFFFFFF, 0xFFFFFFFF},
            {0xFF1A1A1A, 0xFF000000}, {0xFF17C964, 0xFF0E9B4C}
    };

    public interface Callback {
        void onBusy(boolean busy);

        void onChanged();

        void onMessage(String msg);

        void onColorPicked(int color);

        void onUndoGesture();

        void onRedoGesture();

        void onLassoCompleted();
    }

    private Project project;
    private UndoManager undo;
    private Callback callback;
    /** Ultima capa normal elegida; permite crear una parte aunque ahora este activa Seleccion. */
    private Layer lastNormalLayer;

    // pantalla
    private Bitmap display;
    private float dispScale = 1f;
    private Bitmap overlay, markersOverlay, patchOverlay;
    private int ovScale = 1;
    private final Matrix view = new Matrix();
    private final Matrix inverse = new Matrix();
    private final Matrix transformMatrix = new Matrix();
    private final float[] point = new float[2];
    private ScaleGestureDetector scaleDetector;
    private int insetTop, insetBottom;
    private int viewBg = 0;

    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ovPaint = new Paint();
    private final Paint lassoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wirePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint loupeEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint aimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePreview = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghostPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint transformPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint transformGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint transformAnchorFixedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint transformAnchorMovePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint transformAnchorEdgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ajustes de herramienta
    private int mode = MODE_PAINT;
    private float brushRadius = 20f;
    private float hardness = 0.7f;
    private float brushOpacity = 1f;
    private int paintColor = 0xFFE05A5A;
    private int tolerance = 28, softness = 24, colorMode = ColorDist.RGB;
    private float expansion = 1.5f;
    private boolean gapOn = false;
    private int gapRadius = 4;
    private boolean wandGlobal = false, useBarrier = false, subtract = false, smart = false;
    private float stabilizer = 0f;
    private boolean aimOn = false;
    private float aimDx = 0f, aimDy = -110f;
    private boolean bgOnce = true;
    private boolean bgBucket = true;
    private int bgLimit = 0;
    private int bgTolerance = 46, bgSoftness = 42;
    private boolean protectOn = false;
    private int protectColor = 0;
    private int markerLabel = 1, gapClose = 2;
    private boolean cloneMirror = false;
    private float cloneAngle = 0f;
    private boolean busy = false;

    // efectos de pincel: se procesan solo dentro del disco afectado
    private float effectStrength = 0.32f;
    /** Suavidad propia de Especial/Licuar. 0 = concentrado, 1 = transicion muy suave. */
    private float effectSoftness = 0.72f;
    /** 0 arrastrar, 1 contraer, 2 expandir, 3 suavizar, 4 restaurar. */
    private int liquifyType = 0;
    private int[] effectTmp;
    // Especial v8.11: el bitmap deformado NUNCA vuelve a ser la fuente. Se conserva
    // una fuente estable por bloques y un campo de desplazamiento ligero. Cada frame
    // se reconstruye desde esa fuente con remapeo inverso + interpolacion bilinear.
    private static final int LIQUIFY_TILE = 64;
    private final SparseArray<int[]> liquifyBaseTiles = new SparseArray<int[]>();
    private Layer liquifyBaseLayer;
    private float[] liquifyDx, liquifyDy, liquifyDxTmp, liquifyDyTmp;
    private int liquifyGridCols, liquifyGridRows;
    private float liquifyGridStep = 24f;
    private boolean liquifyFieldReady;
    private float liquifyMaxDisplacement;
    // v8.16: preview y resultado final utilizan el MISMO remapeador por pixel.
    // Las regiones anteriores del trazo permanecen visibles en la capa hasta el commit.
    // Presupuesto adaptable: dibujos pequeños responden con mayor frecuencia,
    // los grandes dejan tiempo al hilo UI entre remuestreos.
    private static final long LIQUIFY_PREVIEW_MIN_MS = 38L;
    private long liquifyPreviewIntervalMs = LIQUIFY_PREVIEW_MIN_MS;
    private long liquifyLastPreviewMs;
    private final Rect liquifyPreviewDirty = new Rect();
    private boolean liquifyPreviewDirtyValid;
    // Contraer/Expandir/Suavizar/Restaurar actuan tambien al dejar el dedo fijo.
    // Un solo temporizador se cancela al levantar un dedo o comenzar zoom.
    private static final long LIQUIFY_HOLD_MS = 165L;
    private final Runnable liquifyHold = new Runnable() {
        @Override public void run() {
            if (!drawing || multi || mode != MODE_LIQUIFY || liquifyType == 0 || busy
                    || project == null || strokeLayer == null) return;
            beginBatch();
            try { stampEffect(lastX, lastY, 0f, 0f); }
            finally { endBatch(); }
            invalidate();
            handler.postDelayed(this, LIQUIFY_HOLD_MS);
        }
    };
    private final SparseArray<Boolean> liquifyDirtyTiles = new SparseArray<Boolean>();
    private int[] liquifySourceBuffer;
    private final Rect liquifySourceBufferRect = new Rect();
    private int liquifySourceBufferW, liquifySourceBufferH;

    // Respaldo LOCAL del trazo para Difuminar/Borrosidad/Especial. Antes se copiaba
    // la capa completa al tocar el lienzo (varios MB en 2K/4K) y eso provocaba el
    // tiron inicial. Ahora solo se guardan los bloques que realmente toca el pincel.
    private final SparseArray<int[]> effectStrokeBackupTiles = new SparseArray<int[]>();
    private Layer effectStrokeBackupLayer;
    private boolean effectStrokeBackupFailed;

    // Seleccion: respaldo por bloques, igual que las capas. Antes cada trazo azul
    // copiaba w*h bytes aunque solo se tocara una zona pequena.
    private final SparseArray<byte[]> selectionStrokeBackupTiles = new SparseArray<byte[]>();
    private boolean selectionStrokeBackupFailed;

    // Buffers pequenos reutilizados por Borrosidad. Evitan crear arreglos y reducen
    // el desenfoque 3x3 de 9 lecturas por pixel a una suma vertical + horizontal.
    private int[] blurColA, blurColR, blurColG, blurColB;

    // buffers que se reutilizan
    private byte[] scratch, selBackup, gapBarrier, gradient, markers, patchSource, repairLines;
    private int[] pxBackup;
    // Reutilizados por Borrar fondo para no crear arreglos en cada movimiento del dedo.
    private byte[] bgSeen, dilMask;
    private int[] bgStack;
    /** Cuanto se pinto ya cada pixel en este trazo, para que repasar no aclare. */
    private byte[] cov;

    // toque
    private final Handler handler = new Handler(Looper.getMainLooper());
    private float downX, downY, lastSX, lastSY;
    private long downTime, strokeStart;
    private boolean pendingStroke, pendingTap, multi, drawing, panning, midValid;
    private float tapX, tapY, lastMidX, lastMidY, lastAngle, lastPanX, lastPanY;
    private float lastPinchDistance;
    private int gestureMax;
    private float gestureMoved;
    private float touchSlop;
    private final Runnable startPending = new Runnable() {
        @Override
        public void run() {
            if (pendingStroke && !multi) beginPending();
        }
    };

    // trazo
    private float lastX, lastY, smoothX, smoothY;
    private boolean smoothInit;
    private Rect strokeRect;
    private Layer strokeLayer;
    private boolean strokeOnSelection, strokeErase, selectionActive;
    private int painted, bgRef, refColor;
    private boolean showRing;
    private float ringX, ringY;

    // lazo, tijeras, magnetico, linea
    private final Path lasso = new Path();
    private LiveWire wire;
    private final Path wirePath = new Path();
    private int[] livePath;
    private int firstAnchor = -1;
    private boolean wireStarted;
    private final ArrayList<float[]> linePts = new ArrayList<float[]>();

    // clonar
    private boolean cloneSrcSet;
    private float cloneSrcX, cloneSrcY, cloneDestX, cloneDestY;

    // mover
    private int[] moveBackup;
    private byte[] moveSelBackup;
    private float moveFromX, moveFromY;
    private int moveDx, moveDy;
    private long lastMoveApply;

    // transformar: el original se aparta una sola vez y se dibuja como previsualizacion
    private boolean transformActive;
    private boolean transformApplying;
    /** Muestra la malla al instante mientras se prepara el bitmap pesado. */
    private boolean transformPreparing;
    /** 0 mover/escala/giro, 1 perspectiva, 2 malla, 3 puntos/anclajes. */
    private int transformType = 0;
    private int transformMeshX = 4, transformMeshY = 4;
    /** Puntos: [origenX, origenY, actualX, actualY, tipo(0=fijo,1=movil)]. */
    private final ArrayList<float[]> transformAnchors = new ArrayList<float[]>();
    private int transformAnchorNode = -1;
    private int transformAnchorAddMode = 1;
    private float transformAnchorRadius = 260f;
    private float transformAnchorStrength = 1f;
    private boolean transformNavMidValid;
    private float transformNavMidX, transformNavMidY;
    /** Suavidad real de la malla: 0 = lineal, 1 = Catmull-Rom muy suave. */
    private float transformMeshSmoothness = 0.72f;
    private int transformRenderMeshX, transformRenderMeshY;
    private float[] transformRenderVerts;
    private boolean transformRenderDirty = true;
    private Layer transformLayer;
    private int[] transformBackup;
    private byte[] transformSelectionBackup;
    private Bitmap transformBitmap, transformMaskBitmap;
    private Rect transformSrcRect;
    private float transformTx, transformTy, transformScale = 1f, transformRotation;
    private float[] transformVerts, transformVertsStart;
    // Reutilizados durante gestos/dibujo para no generar basura por frame.
    private final float[] transformPoint0 = new float[2];
    private final float[] transformPoint1 = new float[2];
    private final float[] transformAffineCorners = new float[8];
    private final float[] transformPerspectiveSrc = new float[8];
    private int transformNode = -1;
    private float transformDownX, transformDownY, transformStartTx, transformStartTy;
    private float transformGestureDist, transformGestureAngle, transformGestureMidX, transformGestureMidY;
    private float transformStartScale, transformStartRotation, transformGestureStartTx, transformGestureStartTy;

    /** Una pieza no solapada del estado anterior a Transformar. */
    private static final class TransformUndoPiece {
        final Rect r;
        final int[] layer;
        final Bitmap layerBitmap;
        final byte[] selection;
        TransformUndoPiece(Rect r, int[] layer, byte[] selection) {
            this.r = r;
            this.layer = layer;
            this.layerBitmap = null;
            this.selection = selection;
        }
        TransformUndoPiece(Rect r, Bitmap layerBitmap) {
            this.r = r;
            this.layer = null;
            this.layerBitmap = layerBitmap;
            this.selection = null;
        }
    }

    private static final class TransformApplyResult {
        final ArrayList<TransformUndoPiece> undoPieces = new ArrayList<TransformUndoPiece>();
        Throwable error;
    }

    // cuentagotas rapido
    private boolean quickPick, quickArmed;
    private float pickX, pickY;
    private int pickColor;
    private Runnable quickRunnable;

    // avisos
    private String hud;
    private long hudUntil;
    private boolean hintedHidden;
    private Rect lastFillRect;
    private byte[] previewBackup;

    public CanvasView(Context c) {
        super(c);
        init(c);
    }

    public CanvasView(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        float d = getResources().getDisplayMetrics().density;
        touchSlop = 7f * d;
        aimDy = -46f * d;
        ovPaint.setFilterBitmap(false);
        lassoPaint.setStyle(Paint.Style.STROKE);
        lassoPaint.setColor(0xFF3D7BFF);
        lassoPaint.setStrokeWidth(3f);
        markPaint.setStyle(Paint.Style.STROKE);
        markPaint.setColor(0xFFFF5252);
        markPaint.setStrokeWidth(3f);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(0xCC888888);
        ringPaint.setStrokeWidth(2f);
        hudBg.setColor(0xCC000000);
        hudText.setColor(Color.WHITE);
        hudText.setTextSize(d * 14f);
        hudText.setTextAlign(Paint.Align.CENTER);
        pinEdge.setColor(0xFFF0F0F0);
        wirePaint.setStyle(Paint.Style.STROKE);
        wirePaint.setColor(0xFF32D74B);
        wirePaint.setStrokeWidth(3f);
        loupeEdge.setStyle(Paint.Style.STROKE);
        loupeEdge.setColor(Color.WHITE);
        loupeEdge.setStrokeWidth(3f * d);
        aimPaint.setStyle(Paint.Style.STROKE);
        aimPaint.setColor(0xFFFF3B30);
        aimPaint.setStrokeWidth(2f * d);
        linePreview.setStyle(Paint.Style.STROKE);
        linePreview.setColor(0xFFFF9F0A);
        linePreview.setStrokeWidth(3f * d);
        linePreview.setStrokeCap(Paint.Cap.ROUND);
        ghostPaint.setAlpha(150);
        transformGridPaint.setStyle(Paint.Style.STROKE);
        transformGridPaint.setStrokeWidth(2f * d);
        transformGridPaint.setColor(0xFFEFEFEF);
        transformAnchorFixedPaint.setStyle(Paint.Style.FILL);
        transformAnchorFixedPaint.setColor(0xFF42A5F5);
        transformAnchorMovePaint.setStyle(Paint.Style.FILL);
        transformAnchorMovePaint.setColor(0xFFFFA726);
        transformAnchorEdgePaint.setStyle(Paint.Style.STROKE);
        transformAnchorEdgePaint.setStrokeWidth(2f * d);
        transformAnchorEdgePaint.setColor(0xFFFFFFFF);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector det) {
                float f = det.getScaleFactor();
                float cur = currentScale();
                if (cur * f < 0.03f || cur * f > 60f) return true;
                view.postScale(f, f, det.getFocusX(), det.getFocusY());
                showHud(Math.round(currentScale() * dispScale * 100f) + "%");
                return true;
            }
        });
    }

    // ==================================================================
    // Proyecto
    // ==================================================================

    public void setCallback(Callback cb) {
        callback = cb;
    }

    public void setProject(Project p) {
        dropDetail();
        clearTransformState(true);
        if (undo != null) undo.clear();
        project = p;
        undo = p == null ? null : new UndoManager(p);
        lastNormalLayer = p != null && p.active >= 0 && p.active < p.layers.size()
                ? p.layers.get(p.active) : (p != null && !p.layers.isEmpty() ? p.layers.get(0) : null);
        scratch = selBackup = gapBarrier = gradient = markers = patchSource = repairLines = null;
        pxBackup = null;
        bgSeen = dilMask = null;
        bgStack = null;
        dilBuf = null;
        dilRect = null;
        wire = null;
        cloneSrcSet = false;
        subtract = false;
        hintedHidden = false;
        mode = MODE_PAINT;
        lasso.reset();
        wirePath.reset();
        linePts.clear();
        if (markersOverlay != null) markersOverlay.recycle();
        if (patchOverlay != null) patchOverlay.recycle();
        markersOverlay = patchOverlay = null;
        fitted = false;
        shapePts.clear();
        shapeSel = -1;
        shapeDrag = -1;
        resetLiquifySession();
        clearEffectStrokeBackup();
        clearSelectionStrokeBackup();
        effectTmp = null;
        blurColA = blurColR = blurColG = blurColB = null;
        if (p != null) {
            buildDisplay();
            buildOverlay();
            // se ajusta antes del primer dibujo: asi no se ve un salto de zoom al abrir
            if (getWidth() > 0) fit();
            else post(new Runnable() {
                @Override
                public void run() {
                    fit();
                }
            });
        }
        invalidate();
    }

    /** true cuando la imagen ya quedo ajustada a la pantalla; antes no se dibuja. */
    private boolean fitted;

    public Project getProject() {
        return project;
    }

    /** La capa donde se pinta, o null si esta activa la capa de seleccion. */
    private Layer target() {
        return project == null ? null : project.activeLayer();
    }

    private boolean paintsSelection() {
        return project != null && project.isSelectionLayerActive();
    }

    /** Revisa que haya una capa normal elegida y visible. */
    private Layer needLayer() {
        Layer t = target();
        if (t == null) {
            msg("Toca una capa en Capas: ahora esta elegida la capa de seleccion");
            return null;
        }
        if (!t.visible && !hintedHidden) {
            hintedHidden = true;
            showHud("Esa capa esta oculta: prendele el ojo en Capas");
        }
        return t;
    }

    // ==================================================================
    // Pantalla
    // ==================================================================

    private void buildDisplay() {
        asyncGen++;
        spare = null;
        Bitmap old = display;
        float oldScale = dispScale;
        int max = Math.max(project.w, project.h);
        float s = max > 2048 ? max / 2048f : 1f;
        int dw = Math.max(1, Math.round(project.w / s)), dh = Math.max(1, Math.round(project.h / s));
        display = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        dispScale = (float) project.w / dw;
        composeRegion(0, 0, dw, dh);
        boolean sameSize = old != null && !old.isRecycled() && old.getWidth() == dw && old.getHeight() == dh
                && oldScale == dispScale && detailRect != null
                && detailRect.right <= project.w && detailRect.bottom <= project.h;
        if (old != null && !old.isRecycled()) old.recycle();
        if (sameSize) staleDetail();
        else invalidateDetail();
        scheduleDetail();
    }

    public void refreshDisplay() {
        if (project == null) return;
        buildDisplay();
        invalidate();
    }

    // ------------------------------------------------------------------
    // Vista armada en segundo plano: ojo, opacidad, orden de capas y fondo
    // ya no congelan la pantalla. Se arma en otro Bitmap y se cambia de golpe.
    // ------------------------------------------------------------------

    private static final java.util.concurrent.ExecutorService COMPOSE =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private int asyncGen;
    private boolean asyncRunning, asyncAgain;
    private Bitmap spare;

    public void refreshDisplayAsync() {
        if (project == null || display == null) return;
        if (asyncRunning) {
            asyncAgain = true;
            return;
        }
        startAsyncCompose();
    }

    private void startAsyncCompose() {
        final int dw = display.getWidth(), dh = display.getHeight();
        Bitmap t = spare;
        spare = null;
        if (t == null || t.isRecycled() || t.getWidth() != dw || t.getHeight() != dh) {
            try {
                t = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
            } catch (OutOfMemoryError e) {
                refreshDisplay();
                return;
            }
        }
        final Bitmap target = t;
        final LayerSrc[] src = layerSources();
        final int[] bg = VIEW_BG[viewBg];
        final float ds = dispScale;
        final int pw = project.w, ph = project.h;
        final Project owner = project;
        final int gen = ++asyncGen;
        asyncRunning = true;
        asyncAgain = false;
        COMPOSE.execute(new Runnable() {
            @Override
            public void run() {
                boolean ok = true;
                try {
                    composeInto(target, src, bg, ds, pw, ph, 0, 0, dw, dh);
                } catch (Throwable e) {
                    ok = false;
                }
                final boolean fine = ok;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        asyncRunning = false;
                        if (fine && owner == project && gen == asyncGen && display != null
                                && display.getWidth() == dw && display.getHeight() == dh) {
                            final Bitmap old = display;
                            display = target;
                            staleDetail();
                            scheduleDetail();
                            invalidate();
                            // el viejo se reusa cuando ya salio de pantalla
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (old != display && !old.isRecycled()) spare = old;
                                }
                            }, 80);
                        } else if (target != display && !target.isRecycled()) {
                            spare = target;
                        }
                        if (asyncAgain && project != null && display != null) {
                            asyncAgain = false;
                            startAsyncCompose();
                        }
                    }
                });
            }
        });
    }

    /** Como layersChanged, pero sin congelar: para ojo, opacidad y orden. */
    public void layersChangedAsync() {
        if (project == null) return;
        project.markDirty();
        wire = null;
        refreshDisplayAsync();
        changed();
    }

    /** Pasa la capa de la posicion from a la posicion to (arrastrar en Capas). */
    public void moveLayer(int from, int to) {
        if (project == null) return;
        int n = project.layers.size();
        if (from < 0 || to < 0 || from >= n || to >= n || from == to) return;
        undo.setLabel("Ordenar capas");
        undo.recordStruct();
        Layer l = project.layers.remove(from);
        project.layers.add(to, l);
        project.active = to;
        layersChangedAsync();
    }

    /** Todas las capas visibles, una encima de otra, sobre el fondo de vista. */
    private void composeRegion(int x0, int y0, int x1, int y1) {
        if (display == null || project == null) return;
        if (asyncRunning) asyncAgain = true;
        composeInto(display, layerSources(), VIEW_BG[viewBg], dispScale, project.w, project.h, x0, y0, x1, y1);
    }

    /** Arma la vista en el Bitmap que le des. No toca campos: sirve en segundo plano. */
    private static void composeInto(Bitmap display, LayerSrc[] src, int[] bg, float dispScale, int w, int h,
                                    int x0, int y0, int x1, int y1) {
        int dw = display.getWidth(), dh = display.getHeight();
        x0 = Math.max(0, x0);
        y0 = Math.max(0, y0);
        x1 = Math.min(dw, x1);
        y1 = Math.min(dh, y1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        int cs = 8;
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(h - 1, (int) (y * dispScale));
            for (int x = x0; x < x1; x++) {
                int sx = Math.min(w - 1, (int) (x * dispScale));
                int c = (((x / cs) + (y / cs)) & 1) == 0 ? bg[0] : bg[1];
                row[x - x0] = over(src, c, sx, sy, w);
            }
            display.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    /** Lo que se necesita para leer una capa rapido, dense o recortada. */
    private static final class LayerSrc {
        int[] dense;
        Layer.Packed packed;
        int op;
        int mode;
        boolean clip;
        /** base vacia u oculta: siempre transparente. */
        boolean zero;
        int[] rowBuf;
        int rowY = Integer.MIN_VALUE;

        /** Pixel de una capa empacada: se lee de a una fila entera del Bitmap. */
        int get(int sx, int sy) {
            if (zero) return 0;
            Layer.Packed p = packed;
            if (sy < p.y || sy >= p.y + p.h || sx < p.x || sx >= p.x + p.w) return 0;
            if (sy != rowY) {
                if (rowBuf == null) rowBuf = new int[p.w];
                p.row(sy, rowBuf);
                rowY = sy;
            }
            return rowBuf[sx - p.x];
        }
    }

    private LayerSrc[] layerSources() {
        Layer[] ls = project.layers.toArray(new Layer[0]);
        int n = ls.length;
        int[] ops = new int[n], modes = new int[n];
        boolean[] vs = new boolean[n], clips = new boolean[n];
        for (int k = 0; k < n; k++) {
            ops[k] = ls[k].opacity;
            vs[k] = ls[k].visible;
            modes[k] = ls[k].mode;
            clips[k] = ls[k].clip;
        }
        return buildSources(ls, ops, vs, modes, clips, project.w, project.h);
    }

    private static int over(LayerSrc[] src, int c, int sx, int sy, int w) {
        int i = sy * w + sx;
        int baseA = -1;
        for (LayerSrc s : src) {
            int col = s.dense != null ? s.dense[i] : s.get(sx, sy);
            int ca = col >>> 24;
            if (s.clip && baseA >= 0) ca = ca * baseA / 255;
            else baseA = ca;
            int a = (ca * s.op) / 255;
            if (a > 0) c = blendA(c, s.mode == 0 ? col : Project.mixMode(c, col, s.mode), a);
        }
        return c;
    }

    /**
     * Lista de capas para dibujar: con su modo y recorte. Una capa con recorte
     * sobre una base oculta tampoco se ve. La base oculta igual cuenta como
     * base (con alfa 0) para que sus capas recortadas no se peguen a otra.
     */
    private static LayerSrc[] buildSources(Layer[] ls, int[] ops, boolean[] vs, int[] modes, boolean[] clips,
                                           int w, int h) {
        ArrayList<LayerSrc> out = new ArrayList<LayerSrc>();
        boolean baseSeen = false, baseHidden = false;
        for (int k = 0; k < ls.length; k++) {
            boolean clipped = clips[k] && baseSeen;
            if (!clipped) {
                baseSeen = true;
                baseHidden = !vs[k] || ops[k] <= 0;
            }
            if (clipped && baseHidden) continue;
            Layer l = ls[k];
            LayerSrc s = new LayerSrc();
            s.op = vs[k] ? ops[k] : 0;
            s.mode = modes[k];
            s.clip = clipped;
            int[] d = l.denseOrNull();
            boolean empty = false;
            if (d != null && d.length == w * h) s.dense = d;
            else {
                s.packed = l.packedOrNull();
                if (s.packed == null) {
                    d = l.denseOrNull();
                    if (d == null || d.length != w * h) empty = true;
                    else s.dense = d;
                } else if (s.packed.empty()) empty = true;
            }
            if (empty || s.op <= 0) {
                // base vacia u oculta: igual marca la base para las recortadas
                if (!clipped) {
                    LayerSrc z = new LayerSrc();
                    z.op = 0;
                    z.dense = null;
                    z.packed = null;
                    z.zero = true;
                    out.add(z);
                }
                continue;
            }
            out.add(s);
        }
        return out.toArray(new LayerSrc[0]);
    }

    // ------------------------------------------------------------------
    // Zoom con la resolucion original: al acercarse se dibuja la zona que se
    // ve directo de las capas, pixel por pixel, en vez de la vista reducida.
    // ------------------------------------------------------------------

    /** Maximo de pixeles del detalle (unos 22 MB). */
    private static final int DETAIL_MAX_PX = 5_500_000;
    private Bitmap detail;
    private Rect detailRect;
    private boolean detailValid, detailBuilding, smoothZoom = true;
    private int detailGen;
    private final Paint detailPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Runnable detailRunnable = new Runnable() {
        @Override
        public void run() {
            buildDetail();
        }
    };

    public void setSmoothZoom(boolean on) {
        smoothZoom = on;
        invalidate();
    }

    public boolean isSmoothZoom() {
        return smoothZoom;
    }

    /** Zona de la imagen que conviene tener en alta: lo visible y un margen. */
    private Rect wantedDetail() {
        if (project == null || dispScale <= 1.01f || getWidth() == 0) return null;
        float sc = currentScale();
        if (sc * dispScale < 1.1f) return null;
        if (!view.invert(inverse)) return null;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        Rect vis = new Rect((int) Math.floor(v.left), (int) Math.floor(v.top),
                (int) Math.ceil(v.right), (int) Math.ceil(v.bottom));
        if (!vis.intersect(0, 0, project.w, project.h)) return null;
        if ((long) vis.width() * vis.height() > DETAIL_MAX_PX) return null;
        // margen grande cuando se puede: asi al moverte ya esta listo
        double area = (double) Math.max(1, v.width()) * Math.max(1, v.height());
        float f = (float) Math.min(2.2, Math.sqrt(DETAIL_MAX_PX / area));
        float mx = Math.max(0, v.width() * (f - 1) / 2f), my = Math.max(0, v.height() * (f - 1) / 2f);
        Rect r = new Rect((int) Math.floor(v.left - mx), (int) Math.floor(v.top - my),
                (int) Math.ceil(v.right + mx), (int) Math.ceil(v.bottom + my));
        if (!r.intersect(0, 0, project.w, project.h)) return null;
        return r;
    }

    /** Solo lo que se ve ahora en pantalla (sin margen). */
    private Rect visibleDetail() {
        if (!view.invert(inverse)) return null;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        Rect r = new Rect((int) Math.floor(v.left) - 2, (int) Math.floor(v.top) - 2,
                (int) Math.ceil(v.right) + 2, (int) Math.ceil(v.bottom) + 2);
        if (!r.intersect(0, 0, project.w, project.h)) return null;
        return r;
    }

    private boolean visibleInside(Rect d) {
        if (d == null || !view.invert(inverse)) return false;
        RectF v = new RectF(0, 0, getWidth(), getHeight());
        inverse.mapRect(v);
        RectF img = new RectF(0, 0, project.w, project.h);
        if (!v.intersect(img)) return true;
        return v.left >= d.left - 0.5f && v.top >= d.top - 0.5f && v.right <= d.right + 0.5f && v.bottom <= d.bottom + 0.5f;
    }

    private void scheduleDetail() {
        handler.removeCallbacks(detailRunnable);
        handler.postDelayed(detailRunnable, 30);
    }

    /** Algo cambio en todo el dibujo: el detalle se vuelve a armar. */
    private void invalidateDetail() {
        detailGen++;
        detailValid = false;
        detailStale = false;
    }

    /**
     * Cambio el dibujo pero no el tamano: el detalle nitido viejo se queda
     * en pantalla hasta que llega el nuevo. Asi no se ve un instante borroso.
     */
    private boolean detailStale;

    private void staleDetail() {
        if (detail == null || !detailValid) {
            invalidateDetail();
            return;
        }
        detailGen++;
        detailStale = true;
    }

    private void dropDetail() {
        handler.removeCallbacks(detailRunnable);
        detailGen++;
        detailValid = false;
        if (detail != null && !detail.isRecycled()) detail.recycle();
        detail = null;
        detailRect = null;
    }

    private void buildDetail() {
        if (project == null || busy || drawing) {
            if (project != null) scheduleDetail();
            return;
        }
        if (detailBuilding) return;
        final Rect r = wantedDetail();
        if (r == null) {
            if (detail != null) dropDetail();
            return;
        }
        if (detailValid && !detailStale && detailRect != null && detailRect.contains(r)) return;
        detailBuilding = true;
        final int gen = detailGen;
        final Rect vis0 = visibleDetail();
        final Rect vis = vis0 != null && r.contains(vis0) ? vis0 : null;
        final Layer[] ls = project.layers.toArray(new Layer[0]);
        final int[] ops = new int[ls.length];
        final boolean[] vs = new boolean[ls.length];
        final int[] modes = new int[ls.length];
        final boolean[] clips = new boolean[ls.length];
        for (int k = 0; k < ls.length; k++) {
            ops[k] = ls[k].opacity;
            vs[k] = ls[k].visible;
            modes[k] = ls[k].mode;
            clips[k] = ls[k].clip;
        }
        final byte[] sel = project.selection;
        final int w = project.w;
        final int[] bg = VIEW_BG[viewBg];
        final float cs = 8f * dispScale;
        final Project owner = project;
        // hilo propio: no espera al guardado automatico ni a otras tareas
        DETAIL_BOSS.execute(new Runnable() {
            @Override
            public void run() {
                // 1) primero solo lo que se ve (rapido); 2) despues con margen
                if (vis != null && (vis.width() < r.width() || vis.height() < r.height())) {
                    final Bitmap first = renderDetail(vis, ls, ops, vs, modes, clips, sel, bg, cs, w, owner);
                    post(new Runnable() {
                        @Override
                        public void run() {
                            acceptDetail(first, vis, gen, owner, false);
                        }
                    });
                }
                final Bitmap full = renderDetail(r, ls, ops, vs, modes, clips, sel, bg, cs, w, owner);
                post(new Runnable() {
                    @Override
                    public void run() {
                        acceptDetail(full, r, gen, owner, true);
                    }
                });
            }
        });
    }

    private static final int DETAIL_THREADS = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1));
    private static final java.util.concurrent.ExecutorService DETAIL_BOSS =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private static final java.util.concurrent.ExecutorService DETAIL_WORKERS =
            java.util.concurrent.Executors.newFixedThreadPool(DETAIL_THREADS);

    private void acceptDetail(Bitmap b, Rect r, int gen, Project owner, boolean last) {
        if (last) detailBuilding = false;
        if (b == null) return;
        if (owner != project || gen != detailGen) {
            b.recycle();
            if (last) scheduleDetail();
            return;
        }
        // si ya hay uno mas grande y valido, no se reemplaza con el chico
        if (!last && !detailStale && detail != null && detailValid && detailRect != null && detailRect.contains(r)) {
            b.recycle();
            return;
        }
        if (detail != null && !detail.isRecycled()) detail.recycle();
        detail = b;
        detailRect = r;
        detailValid = true;
        if (last) detailStale = false;
        invalidate();
    }

    /** Arma el detalle repartido en varios hilos, por franjas de filas. */
    private static Bitmap renderDetail(final Rect r, Layer[] ls, int[] ops, boolean[] vs, final int[] modes,
                                       final boolean[] clips, final byte[] sel,
                                       final int[] bg, final float cs, final int w, Project owner) {
        try {
            final Bitmap b = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888);
            final int rows = r.height();
            int parts = Math.min(DETAIL_THREADS, Math.max(1, rows / 64));
            java.util.List<java.util.concurrent.Future<?>> fs = new java.util.ArrayList<java.util.concurrent.Future<?>>();
            for (int k = 0; k < parts; k++) {
                final int y0 = r.top + rows * k / parts, y1 = r.top + rows * (k + 1) / parts;
                final LayerSrc[] src = buildSources(ls, ops, vs, modes, clips, owner.w, owner.h);
                fs.add(DETAIL_WORKERS.submit(new Runnable() {
                    @Override
                    public void run() {
                        int[] row = new int[r.width()];
                        for (int y = y0; y < y1; y++) {
                            for (int x = r.left; x < r.right; x++) {
                                row[x - r.left] = detailPixel(src, sel, bg, cs, x, y, w);
                            }
                            synchronized (b) {
                                b.setPixels(row, 0, row.length, 0, y - r.top, row.length, 1);
                            }
                        }
                    }
                }));
            }
            for (java.util.concurrent.Future<?> f : fs) f.get();
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private static int detailPixel(LayerSrc[] src, byte[] sel, int[] bg, float cs, int x, int y, int w) {
        int c = ((((int) (x / cs)) + ((int) (y / cs))) & 1) == 0 ? bg[0] : bg[1];
        c = over(src, c, x, y, w);
        int a = sel[y * w + x] & 0xFF;
        if (a != 0) c = blendA(c, 0xFF3D7BFF, (a * 140) / 255);
        return c;
    }

    /** Actualiza al momento la parte del detalle que cambio (trazos, relleno chico). */
    private void updateDetail(Rect changed) {
        if (detail == null || detailRect == null || !detailValid || changed == null) return;
        Rect r = new Rect(changed);
        if (!r.intersect(detailRect)) return;
        // Reconstruir una imagen de muchas capas por cada movimiento bloquea
        // el hilo tactil. Para gestos grandes, mostrar la vista normal durante
        // el trazo y reconstruir el detalle nitido al levantar el dedo.
        long pixels = (long) r.width() * r.height();
        if (pixels > (drawing ? 20_000L : 60_000L)) {
            invalidateDetail();
            if (!drawing) scheduleDetail();
            return;
        }
        detailGen++;
        LayerSrc[] src = layerSources();
        int[] bg = VIEW_BG[viewBg];
        float cs = 8f * dispScale;
        int[] row = new int[r.width()];
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                row[x - r.left] = detailPixel(src, project.selection, bg, cs, x, y, project.w);
            }
            detail.setPixels(row, 0, row.length, r.left - detailRect.left, y - detailRect.top, row.length, 1);
        }
    }

    private static int blendA(int dst, int src, int a) {
        if (a >= 255) return src | 0xFF000000;
        int r = (((src >> 16) & 0xFF) * a + ((dst >> 16) & 0xFF) * (255 - a)) / 255;
        int g = (((src >> 8) & 0xFF) * a + ((dst >> 8) & 0xFF) * (255 - a)) / 255;
        int b = ((src & 0xFF) * a + (dst & 0xFF) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Mientras se estampan muchos puntos seguidos, la pantalla se actualiza una sola vez. */
    private int batchDepth;
    private Rect batchRect;

    private void beginBatch() {
        batchDepth++;
    }

    private void endBatch() {
        if (batchDepth > 0) batchDepth--;
        if (batchDepth == 0 && batchRect != null) {
            Rect r = batchRect;
            batchRect = null;
            updateDisplayRegion(r);
        }
    }

    private void updateDisplayRegion(Rect r) {
        if (display == null || r == null) return;
        if (batchDepth > 0) {
            if (batchRect == null) batchRect = new Rect(r);
            else batchRect.union(r);
            return;
        }
        composeRegion((int) (r.left / dispScale) - 1, (int) (r.top / dispScale) - 1,
                (int) Math.ceil(r.right / dispScale) + 1, (int) Math.ceil(r.bottom / dispScale) + 1);
        updateDetail(r);
        invalidate();
    }

    /** Despues de cambiar pixeles de una capa. */
    private void pixelsChanged(Rect r) {
        project.markDirty();
        wire = null;
        updateDisplayRegion(r);
        changed();
    }

    private void buildOverlay() {
        if (overlay != null) overlay.recycle();
        int max = Math.max(project.w, project.h);
        ovScale = max > 1440 ? (int) Math.ceil(max / 1440f) : 1;
        overlay = Bitmap.createBitmap(Math.max(1, project.w / ovScale), Math.max(1, project.h / ovScale),
                Bitmap.Config.ARGB_8888);
        paintOverlay(project.fullRect());
    }

    private void paintOverlay(Rect r) {
        if (overlay == null || project == null) return;
        int ow = overlay.getWidth(), oh = overlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int a = project.selection[sy * project.w + sx] & 0xFF;
                row[i] = a == 0 ? 0 : (((a * 140) / 255) << 24) | 0x3D7BFF;
            }
            overlay.setPixels(row, 0, rw, x0, y, rw, 1);
        }
        updateDetail(r);
    }

    public void refreshOverlay(Rect r) {
        if (project == null) return;
        paintOverlay(r == null ? project.fullRect() : r);
        invalidate();
    }

    public void setViewBg(int v) {
        viewBg = Math.max(0, Math.min(VIEW_BG.length - 1, v));
        refreshDisplayAsync();
    }

    public int getViewBg() {
        return viewBg;
    }

    public void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
    }

    public void fit() {
        if (project == null || getWidth() == 0) return;
        int usable = getHeight() - insetTop - insetBottom;
        if (usable < 80) usable = getHeight();
        float s = Math.min((float) getWidth() / project.w, (float) usable / project.h) * 0.96f;
        view.reset();
        view.postScale(s, s);
        view.postTranslate((getWidth() - project.w * s) / 2f, insetTop + (usable - project.h * s) / 2f);
        fitted = true;
        invalidate();
    }

    public boolean isFitted() {
        return fitted;
    }

    private final float[] viewMatrixValues = new float[9];
    private float currentScale() {
        // Durante el pinch se llama por cada evento; no crear 9 floats por frame.
        view.getValues(viewMatrixValues);
        return (float) Math.sqrt(viewMatrixValues[Matrix.MSCALE_X] * viewMatrixValues[Matrix.MSCALE_X]
                + viewMatrixValues[Matrix.MSKEW_X] * viewMatrixValues[Matrix.MSKEW_X]);
    }

    public void showHud(String text) {
        hud = text;
        hudUntil = System.currentTimeMillis() + 1400;
        invalidate();
        postInvalidateDelayed(1450);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        drawAll(c);
        drawSizePreview(c);
    }

    private void drawAll(Canvas c) {
        c.drawColor(0xFF121214);
        if (project == null || display == null || !fitted) return;
        bmpPaint.setFilterBitmap(smoothZoom || currentScale() * dispScale < 1f);
        detailPaint.setFilterBitmap(smoothZoom || currentScale() < 1f);

        c.save();
        c.concat(view);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, bmpPaint);
        c.restore();

        boolean useDetail = detail != null && !detail.isRecycled() && detailValid && detailRect != null;
        if (useDetail) {
            c.save();
            c.concat(view);
            c.drawBitmap(detail, detailRect.left, detailRect.top, detailPaint);
            c.restore();
        }

        Rect want = wantedDetail();
        if (want == null) {
            if (detail != null) handler.post(new Runnable() {
                @Override
                public void run() {
                    if (wantedDetail() == null) dropDetail();
                }
            });
        } else if (!drawing && (!useDetail || !visibleInside(detailRect))) {
            scheduleDetail();
        }

        if (overlay != null) {
            if (useDetail) {
                c.save();
                Path clip = new Path();
                clip.addRect(new RectF(detailRect), Path.Direction.CW);
                Path sp = new Path();
                clip.transform(view, sp);
                c.clipOutPath(sp);
                drawOv(c, overlay);
                c.restore();
            } else {
                drawOv(c, overlay);
            }
        }
        if (moveGhost != null && moveGhostRect != null && !moveGhost.isRecycled()) {
            c.save();
            c.concat(view);
            c.drawBitmap(moveGhost, moveGhostRect.left + moveDx, moveGhostRect.top + moveDy, ghostMovePaint);
            c.restore();
        }
        if (mode == MODE_TRANSFORM && transformPreparing && !transformActive) drawTransformPreparing(c);
        if (mode == MODE_TRANSFORM && transformActive) drawTransformPreview(c);
        if (redLines != null && !redLines.isRecycled()) {
            c.save();
            c.concat(view);
            c.scale(dispScale, dispScale);
            c.drawBitmap(redLines, 0, 0, previewPaint);
            c.restore();
        }
        if (mode == MODE_MARKER && sepPreview != null && !sepPreview.isRecycled() && sepPreviewRect != null) {
            c.save();
            c.concat(view);
            c.drawBitmap(sepPreview, null, new RectF(sepPreviewRect), previewPaint);
            c.restore();
        }
        if (markersOverlay != null && mode == MODE_MARKER) drawOv(c, markersOverlay);
        if (patchOverlay != null && mode == MODE_PATCH) drawOv(c, patchOverlay);

        if (mode == MODE_LASSO && !lasso.isEmpty()) {
            Path sp = new Path();
            lasso.transform(view, sp);
            c.drawPath(sp, lassoPaint);
        }
        if (mode == MODE_SCISSORS || mode == MODE_MAGNET) drawWire(c);
        if (mode == MODE_LINE && linePts.size() > 1) {
            Path lp = new Path();
            for (int i = 0; i < linePts.size(); i++) {
                point[0] = linePts.get(i)[0];
                point[1] = linePts.get(i)[1];
                view.mapPoints(point);
                if (i == 0) lp.moveTo(point[0], point[1]);
                else lp.lineTo(point[0], point[1]);
            }
            c.drawPath(lp, linePreview);
        }
        if (isShapeTool() && !shapePts.isEmpty()) drawShape(c);
        if ((mode == MODE_CLONE || mode == MODE_HEAL) && cloneSrcSet) {
            point[0] = cloneSrcX;
            point[1] = cloneSrcY;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 22f, markPaint);
            c.drawLine(point[0] - 30, point[1], point[0] + 30, point[1], markPaint);
            c.drawLine(point[0], point[1] - 30, point[0], point[1] + 30, markPaint);
        }

        float rx = ringX + (usesAim() ? aimDx : 0f), ry = ringY + (usesAim() ? aimDy : 0f);
        if (showRing && usesBrush() && !quickPick) c.drawCircle(rx, ry, brushRadius * currentScale(), ringPaint);
        if ((mode == MODE_CLONE || mode == MODE_HEAL) && cloneSrcSet && drawing) drawCloneGhost(c, rx, ry);
        if (usesAim() && showRing && !quickPick) {
            float d = getResources().getDisplayMetrics().density;
            c.drawLine(rx - 10 * d, ry, rx + 10 * d, ry, aimPaint);
            c.drawLine(rx, ry - 10 * d, rx, ry + 10 * d, aimPaint);
            drawLoupe(c, rx, ry);
        }
        if (quickPick) drawPin(c);
        if (hud != null && System.currentTimeMillis() < hudUntil) {
            float pad = 14f * getResources().getDisplayMetrics().density;
            float tw = hudText.measureText(hud);
            float cx = getWidth() / 2f, top = insetTop + pad;
            c.drawRoundRect(new RectF(cx - tw / 2 - pad, top, cx + tw / 2 + pad, top + pad * 2.6f), 12f, 12f, hudBg);
            c.drawText(hud, cx, top + pad * 1.8f, hudText);
        }
    }

    private void drawOv(Canvas c, Bitmap b) {
        c.save();
        c.concat(view);
        c.scale(ovScale, ovScale);
        c.drawBitmap(b, 0, 0, ovPaint);
        c.restore();
    }

    private void drawWire(Canvas c) {
        Path sp = new Path();
        wirePath.transform(view, sp);
        c.drawPath(sp, wirePaint);
        if (livePath != null && livePath.length > 1) {
            Path p = new Path();
            for (int i = 0; i < livePath.length; i += 2) {
                int y = livePath[i] / project.w, x = livePath[i] - y * project.w;
                if (i == 0) p.moveTo(x, y);
                else p.lineTo(x, y);
            }
            Path q = new Path();
            p.transform(view, q);
            c.drawPath(q, wirePaint);
        }
        if (firstAnchor >= 0) {
            point[0] = firstAnchor % project.w;
            point[1] = firstAnchor / project.w;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 16f, wirePaint);
        }
    }

    private void drawLoupe(Canvas c, float sx, float sy) {
        if (display == null) return;
        float d = getResources().getDisplayMetrics().density;
        float r = 62f * d, margin = 12f * d;
        float cx = sx < getWidth() / 2f ? getWidth() - r - margin : r + margin;
        float cy = insetTop + r + margin;
        imagePoint(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float ix = point[0] / dispScale, iy = point[1] / dispScale;
        float zoom = Math.max(2.5f, currentScale() * dispScale * 3f);
        Path clip = new Path();
        clip.addCircle(cx, cy, r, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.drawColor(0xFF202024);
        c.translate(cx, cy);
        c.scale(zoom, zoom);
        c.translate(-ix, -iy);
        c.drawBitmap(display, 0, 0, ovPaint);
        if (overlay != null) {
            c.save();
            c.scale(ovScale / dispScale, ovScale / dispScale);
            c.drawBitmap(overlay, 0, 0, ovPaint);
            c.restore();
        }
        c.restore();
        c.drawCircle(cx, cy, r, loupeEdge);
        c.drawLine(cx - 9 * d, cy, cx + 9 * d, cy, aimPaint);
        c.drawLine(cx, cy - 9 * d, cx, cy + 9 * d, aimPaint);
    }

    private void drawPin(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float r = 34f * d, cx = pickX, cy = pickY - r * 1.8f;
        pinFill.setColor(pickColor);
        pinEdge.setStyle(Paint.Style.FILL);
        Path tip = new Path();
        tip.moveTo(cx - r * 0.42f, cy + r * 0.86f);
        tip.lineTo(cx, cy + r * 1.9f);
        tip.lineTo(cx + r * 0.42f, cy + r * 0.86f);
        tip.close();
        c.drawPath(tip, pinEdge);
        c.drawCircle(cx, cy, r, pinEdge);
        c.drawCircle(cx, cy, r - 4f * d, pinFill);
    }

    private void drawCloneGhost(Canvas c, float sx, float sy) {
        imagePoint(sx - (usesAim() ? aimDx : 0f), sy - (usesAim() ? aimDy : 0f));
        float dxi = point[0], dyi = point[1];
        float ddx = dxi - cloneDestX, ddy = dyi - cloneDestY;
        if (cloneMirror) ddx = -ddx;
        double a = Math.toRadians(cloneAngle);
        float srcX = cloneSrcX + (float) (ddx * Math.cos(a) - ddy * Math.sin(a));
        float srcY = cloneSrcY + (float) (ddx * Math.sin(a) + ddy * Math.cos(a));
        Matrix m = new Matrix();
        m.setTranslate(-srcX, -srcY);
        m.postRotate(-cloneAngle);
        if (cloneMirror) m.postScale(-1f, 1f);
        m.postTranslate(dxi, dyi);
        m.postConcat(view);
        Path clip = new Path();
        clip.addCircle(sx, sy, Math.max(12f, brushRadius * currentScale()), Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        c.concat(m);
        c.scale(dispScale, dispScale);
        c.drawBitmap(display, 0, 0, ghostPaint);
        c.restore();
    }

    // ==================================================================
    // Toque: un dedo trabaja, dos dedos mueven y hacen zoom. Como Ibis.
    // ==================================================================

    private boolean usesBrush() {
        return mode == MODE_BRUSH || mode == MODE_ERASER || mode == MODE_CLONE || mode == MODE_PAINT
                || mode == MODE_SMUDGE || mode == MODE_BLUR || mode == MODE_LIQUIFY
                || (mode == MODE_BGERASE && !bgBucket) || mode == MODE_MARKER || mode == MODE_PATCH
                || mode == MODE_HEAL;
    }

    private boolean isTapTool() {
        return mode == MODE_WAND || mode == MODE_BUCKET || mode == MODE_PICKER || mode == MODE_ZONE
                || mode == MODE_TONE || (mode == MODE_BGERASE && bgBucket);
    }

    private boolean usesAim() {
        return aimOn && mode != MODE_PAN && mode != MODE_MOVE && mode != MODE_TRANSFORM;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (project == null || busy) return true;
        int action = e.getActionMasked();
        int pc = e.getPointerCount();
        if (mode == MODE_TRANSFORM) return onTransformTouch(e);
        // En herramientas normales, pan y zoom se procesan juntos en twoFingers().
        long now = System.currentTimeMillis();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                multi = false;
                midValid = false;
                lastPinchDistance = 0f;
                gestureMax = 1;
                gestureMoved = 0f;
                downTime = now;
                downX = e.getX();
                downY = e.getY();
                lastSX = downX;
                lastSY = downY;
                ringX = downX;
                ringY = downY;
                pickX = downX;
                pickY = downY;
                showRing = usesBrush();
                // Especial necesita soportar presion fija (Contraer/Expandir)
                // sin que el temporizador cambie de herramienta al gotero.
                if (!isShapeTool() && mode != MODE_LIQUIFY) armQuickPick();
                if (isShapeTool()) {
                    shapeDown(downX, downY);
                } else if (mode == MODE_PAN) {
                    panning = true;
                    lastPanX = downX;
                    lastPanY = downY;
                } else if (isTapTool()) {
                    pendingTap = true;
                    tapX = downX;
                    tapY = downY;
                    if (usesAim()) showRing = true;
                } else {
                    // el trazo no empieza todavia: si llega un segundo dedo, no se pinta nada
                    pendingStroke = true;
                    handler.postDelayed(startPending, 90);
                }
                invalidate();
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                handler.removeCallbacks(liquifyHold);
                multi = true;
                gestureMax = Math.max(gestureMax, pc);
                cancelQuickTimer();
                if (quickPick) endQuickPick(false);
                handler.removeCallbacks(startPending);
                pendingStroke = false;
                pendingTap = false;
                shapeCancelTouch();
                if (drawing) {
                    // Abrir dos dedos durante un lazo es navegación, NO confirmar un recorte.
                    if (mode == MODE_LASSO || now - strokeStart < 400) cancelStroke();
                    else endStroke();
                }
                panning = false;
                showRing = false;
                if (pc >= 2) twoFingers(e);
                invalidate();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (multi) {
                    if (pc >= 2) twoFingers(e);
                    return true;
                }
                float mx = e.getX(), my = e.getY();
                gestureMoved += Math.abs(mx - lastSX) + Math.abs(my - lastSY);
                lastSX = mx;
                lastSY = my;
                ringX = mx;
                ringY = my;
                float moved = (float) Math.hypot(mx - downX, my - downY);
                if (quickPick) {
                    updateQuickPick(mx, my);
                    return true;
                }
                if (moved > touchSlop) cancelQuickTimer();
                if (isShapeTool()) {
                    shapeMove(mx, my, moved);
                    return true;
                }
                if (panning) {
                    view.postTranslate(mx - lastPanX, my - lastPanY);
                    lastPanX = mx;
                    lastPanY = my;
                    invalidate();
                    return true;
                }
                if (pendingTap) {
                    if (moved > touchSlop) {
                        if (usesAim()) {
                            tapX = mx;
                            tapY = my;
                        } else {
                            pendingTap = false;
                        }
                    }
                    invalidate();
                    return true;
                }
                if (pendingStroke && moved > touchSlop) beginPending();
                if (drawing) {
                    // el celular junta varios puntos por evento: se usan todos,
                    // asi las curvas rapidas no salen en pedazos rectos
                    beginBatch();
                    try {
                        // Especial y Borrar fondo ya interpolan los puntos entre
                        // eventos. Repetir TODO el historial del hardware hacia
                        // el motor pesado multiplica el trabajo del mismo gesto.
                        boolean processHistory = mode == MODE_LASSO || mode == MODE_PAINT
                                || mode == MODE_ERASER || mode == MODE_BRUSH;
                        if (processHistory && e.getPointerCount() == 1) {
                            int hs = e.getHistorySize();
                            for (int hk = 0; hk < hs; hk++) moveStroke(e.getHistoricalX(0, hk), e.getHistoricalY(0, hk));
                        }
                        moveStroke(mx, my);
                    } finally {
                        endBatch();
                    }
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                // El puntero que se levanta no debe afectar la transformacion.
                midValid = false;
                lastPinchDistance = 0f;
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(liquifyHold);
                cancelQuickTimer();
                handler.removeCallbacks(startPending);
                boolean up = action == MotionEvent.ACTION_UP;
                if (quickPick) {
                    endQuickPick(up);
                } else if (!multi && isShapeTool()) {
                    if (up) shapeUp();
                    else shapeCancelTouch();
                } else if (!multi) {
                    if (pendingTap && up) {
                        runTapTool(tapX, tapY);
                    } else if (pendingStroke && up) {
                        beginPending();
                        if (drawing) endStroke();
                    } else if (drawing) {
                        endStroke();
                    }
                } else if (drawing) {
                    endStroke();
                }
                if (multi && up) checkTapGesture(now);
                pendingStroke = false;
                pendingTap = false;
                panning = false;
                multi = false;
                showRing = false;
                invalidate();
                return true;
        }
        return true;
    }

    private void beginPending() {
        pendingStroke = false;
        handler.removeCallbacks(startPending);
        strokeStart = System.currentTimeMillis();
        startStroke(downX, downY);
        if (drawing && (lastSX != downX || lastSY != downY)) moveStroke(lastSX, lastSY);
    }

    /** Dos dedos: tocar deshace, tres rehace. */
    private void checkTapGesture(long now) {
        if (callback == null) return;
        if (now - downTime > 280 || gestureMoved > 40f) return;
        if (gestureMax == 2) callback.onUndoGesture();
        else if (gestureMax >= 3) callback.onRedoGesture();
    }

    private void twoFingers(MotionEvent e) {
        if (e.getPointerCount() < 2) return;
        float ax = e.getX(0), ay = e.getY(0);
        float bx = e.getX(1), by = e.getY(1);
        float mx = (ax + bx) * .5f, my = (ay + by) * .5f;
        float dist = (float) Math.hypot(bx - ax, by - ay);
        float angle = (float) Math.toDegrees(Math.atan2(by - ay, bx - ax));
        if (!midValid) {
            lastMidX = mx;
            lastMidY = my;
            lastPinchDistance = dist;
            lastAngle = angle;
            midValid = true;
            return;
        }
        float dx = mx - lastMidX, dy = my - lastMidY;
        // Mantener la imagen bajo el centro de los dedos mientras se hace zoom.
        view.postTranslate(dx, dy);
        if (lastPinchDistance > 8f && dist > 8f) {
            float factor = dist / lastPinchDistance;
            float scale = currentScale();
            float target = Math.max(.03f, Math.min(60f, scale * factor));
            if (Float.isFinite(target) && scale > .0001f) {
                float bounded = target / scale;
                if (Math.abs(bounded - 1f) > .0002f) {
                    view.postScale(bounded, bounded, mx, my);
                    gestureMoved += 80f * Math.abs(bounded - 1f);
                }
            }
        }
        // Evitar giros involuntarios por el ruido normal de los dedos.
        float da = angle - lastAngle;
        while (da > 180f) da -= 360f;
        while (da < -180f) da += 360f;
        if (Math.abs(da) > 1.2f) view.postRotate(da, mx, my);
        gestureMoved += Math.abs(dx) + Math.abs(dy) + Math.abs(da);
        lastMidX = mx;
        lastMidY = my;
        lastPinchDistance = dist;
        lastAngle = angle;
        postInvalidateOnAnimation();
    }

    private void armQuickPick() {
        cancelQuickTimer();
        quickArmed = true;
        quickRunnable = new Runnable() {
            @Override
            public void run() {
                if (!quickArmed || project == null || multi) return;
                if (drawing) cancelStroke();
                pendingStroke = false;
                pendingTap = false;
                panning = false;
                quickPick = true;
                updateQuickPick(pickX, pickY);
            }
        };
        handler.postDelayed(quickRunnable, 600);
    }

    private void cancelQuickTimer() {
        quickArmed = false;
        if (quickRunnable != null) handler.removeCallbacks(quickRunnable);
    }

    private void updateQuickPick(float sx, float sy) {
        pickX = sx;
        pickY = sy;
        imagePoint(sx, sy);
        int x = (int) point[0], y = (int) point[1];
        if (x >= 0 && y >= 0 && x < project.w && y < project.h) {
            int c = project.ref()[y * project.w + x];
            pickColor = c | 0xFF000000;
        }
        invalidate();
    }

    private void endQuickPick(boolean apply) {
        quickPick = false;
        if (apply) {
            paintColor = pickColor;
            if (callback != null) callback.onColorPicked(paintColor);
        }
        invalidate();
    }

    /** Pantalla a imagen, sin el desplazamiento del cursor. */
    private void imagePoint(float x, float y) {
        view.invert(inverse);
        point[0] = x;
        point[1] = y;
        inverse.mapPoints(point);
    }

    /** Pantalla a imagen, contando el cursor desplazado si esta activo. */
    private void toImage(float x, float y) {
        if (usesAim() && !quickPick) {
            x += aimDx;
            y += aimDy;
        }
        imagePoint(x, y);
    }

    // ==================================================================
    // Herramientas de un toque
    // ==================================================================

    private void runTapTool(float sx, float sy) {
        toImage(sx, sy);
        int px = (int) point[0], py = (int) point[1];
        if (px < 0 || py < 0 || px >= project.w || py >= project.h) return;
        switch (mode) {
            case MODE_WAND:
                runWand(px, py);
                break;
            case MODE_BUCKET:
                if (paintsSelection()) runWand(px, py);
                else runBucket(px, py);
                break;
            case MODE_PICKER:
                paintColor = project.ref()[py * project.w + px] | 0xFF000000;
                if (callback != null) callback.onColorPicked(paintColor);
                break;
            case MODE_ZONE:
                runZoneFill(px, py);
                break;
            case MODE_TONE:
                runToneFill(px, py);
                break;
            case MODE_BGERASE:
                runBgBucket(px, py);
                break;
        }
    }

    // ==================================================================
    // Trazos
    // ==================================================================

    private void startStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0], iy = point[1];
        int px = (int) ix, py = (int) iy;
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;
        strokeRect = null;
        smoothInit = false;
        lastX = ix;
        lastY = iy;

        switch (mode) {
            case MODE_BRUSH:
                beginSelectionStroke(subtract, inside ? project.ref()[py * project.w + px] : 0);
                stamp(ix, iy);
                return;
            case MODE_PAINT:
            case MODE_ERASER:
                dynOn = false;
                if (paintsSelection()) {
                    beginSelectionStroke(mode == MODE_ERASER, 0);
                } else {
                    if (!beginLayerStroke()) return;
                    strokeErase = mode == MODE_ERASER;
                    painted = 0;
                    dynOn = true;
                }
                beginLineStop();
                strokeArc = 0f;
                speedScale = 1f;
                dynCount = 0;
                lastScreenX = sx;
                lastScreenY = sy;
                lastMoveMs = System.currentTimeMillis();
                if (dynOn) dynStamp(ix, iy, 0f);
                else stamp(ix, iy);
                effR = -1f;
                return;
            case MODE_SMUDGE:
            case MODE_BLUR:
            case MODE_LIQUIFY:
                if (!beginLayerStroke()) return;
                if (mode == MODE_LIQUIFY && !ensureLiquifyField(strokeLayer)) {
                    drawing = false;
                    return;
                }
                painted = 0;
                if (mode == MODE_BLUR || (mode == MODE_LIQUIFY && liquifyType != 0))
                    stampEffect(ix, iy, 0f, 0f);
                if (mode == MODE_LIQUIFY && liquifyType != 0) {
                    handler.removeCallbacks(liquifyHold);
                    handler.postDelayed(liquifyHold, LIQUIFY_HOLD_MS);
                }
                return;
            case MODE_BGERASE:
                if (!beginLayerStroke()) return;
                // si empiezas sobre lo ya borrado, no pasa nada: toma el color
                // del fondo apenas el pincel llegue a algo que queda
                bgRefValid = inside && sampleBgRef(px, py);
                if (bgLimit == 2) ensureGradient(strokeLayer.px());
                stamp(ix, iy);
                return;
            case MODE_MARKER:
                ensureMarkers();
                drawing = true;
                stamp(ix, iy);
                return;
            case MODE_PATCH:
                ensurePatchSource();
                drawing = true;
                stamp(ix, iy);
                return;
            case MODE_CLONE:
            case MODE_HEAL:
                if (needLayer() == null) return;
                if (!cloneSrcSet) {
                    cloneSrcX = ix;
                    cloneSrcY = iy;
                    cloneSrcSet = true;
                    msg("Origen marcado con la cruz roja. Ahora pinta donde quieres copiar");
                    invalidate();
                    return;
                }
                if (!beginLayerStroke()) return;
                cloneDestX = ix;
                cloneDestY = iy;
                stamp(ix, iy);
                return;
            case MODE_LINE:
                linePts.clear();
                linePts.add(new float[]{ix, iy});
                drawing = true;
                invalidate();
                return;
            case MODE_LASSO:
                lasso.reset();
                lasso.moveTo(ix, iy);
                drawing = true;
                invalidate();
                return;
            case MODE_SCISSORS:
                if (!inside) return;
                drawing = true;
                if (!wireStarted) {
                    wireStarted = true;
                    firstAnchor = py * project.w + px;
                    wirePath.reset();
                    wirePath.moveTo(px, py);
                    setAnchorAsync(px, py);
                }
                return;
            case MODE_MAGNET:
                if (!inside) return;
                if (wire == null) wire = new LiveWire(project.ref(), project.w, project.h);
                wirePath.reset();
                wirePath.moveTo(px, py);
                firstAnchor = py * project.w + px;
                wireStarted = true;
                wire.setAnchor(px, py, 120);
                livePath = null;
                drawing = true;
                return;
            case MODE_MOVE:
                startMove(ix, iy);
                return;
        }
    }

    private void beginSelectionStroke(boolean erase, int ref) {
        clearSelectionStrokeBackup();
        strokeOnSelection = true;
        strokeErase = erase;
        refColor = ref;
        drawing = true;
    }

    /** Copia de la capa antes de pintar (para deshacer). Si no alcanza la memoria, avisa. */
    private boolean fillBackup(Layer t) {
        int n = project.w * project.h;
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                if (pxBackup == null || pxBackup.length != n) {
                    pxBackup = null;
                    pxBackup = new int[n];
                }
                System.arraycopy(t.px(), 0, pxBackup, 0, n);
                return true;
            } catch (OutOfMemoryError e) {
                pxBackup = null;
                handler.removeCallbacks(compactRunnable);
                try {
                    project.packInactive();
                } catch (OutOfMemoryError ignored) {
                }
                if (undo != null) undo.trimTo(0.3f);
                System.gc();
            }
        }
        msg("Ya no alcanza la memoria del telefono. Combina o borra alguna capa.");
        return false;
    }

    /**
     * Pintar "plano" (como Saturacion de opacidad de Ibis): repasar no
     * oscurece aunque sueltes y vuelvas a pintar. Viene prendido.
     */
    private boolean flatPaint = true;
    private boolean strokeLock;

    public void setFlatPaint(boolean b) {
        flatPaint = b;
    }

    public boolean isFlatPaint() {
        return flatPaint;
    }

    private int paintOver(int dst, int sa) {
        if (strokeLock) return Project.lockOver(dst, paintColor, sa);
        if (flatPaint) return Project.flatOver(dst, paintColor, sa);
        return Project.over(dst, paintColor, sa);
    }

    private boolean needsStrokeCoverage() {
        // cov solo sirve para herramientas que deben recordar cuanto cubrio cada
        // pixel durante EL MISMO trazo. Goma, Borrar fondo, Difuminar,
        // Borrosidad y Licuar no lo leen: reservar w*h para ellas era memoria
        // desperdiciada (varios MB en 2K/4K).
        // MODE_PAINT lee cov[i] en stampPaint y stampParticles. Si se omite,
        // el primer toque de Brocha provoca NullPointerException y vuelve a Mis obras.
        // MODE_BRUSH solo marca la seleccion; su motor no usa cov.
        return mode == MODE_PAINT || mode == MODE_CLONE || mode == MODE_HEAL || isShapeTool();
    }

    private boolean beginLayerStroke() {
        Layer t = needLayer();
        if (t == null) return false;
        strokeLock = t.alphaLock;
        int n = project.w * project.h;
        clearEffectStrokeBackup();
        effectStrokeBackupLayer = t;
        // El Corrector necesita una imagen completa como referencia para su solver.
        // El resto de pinceles usa respaldo regional por bloques.
        if (mode == MODE_HEAL && !fillBackup(t)) return false;
        if (needsStrokeCoverage()) {
            try {
                if (cov == null || cov.length != n) cov = new byte[n];
                else Arrays.fill(cov, (byte) 0);
            } catch (OutOfMemoryError e) {
                msg("No alcanzo la memoria para iniciar este trazo. Se libero lo temporal; prueba otra vez.");
                cov = null;
                return false;
            }
        } else {
            cov = null;
        }
        strokeLayer = t;
        strokeOnSelection = false;
        selectionActive = project.hasSelection();
        drawing = true;
        return true;
    }

    private void moveStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0], iy = point[1];
        switch (mode) {
            case MODE_LASSO:
                lasso.lineTo(ix, iy);
                invalidate();
                return;
            case MODE_LINE:
                float[] last = linePts.get(linePts.size() - 1);
                if (Math.hypot(ix - last[0], iy - last[1]) > 2f) linePts.add(new float[]{ix, iy});
                invalidate();
                return;
            case MODE_SCISSORS:
                if (wire != null && wire.hasAnchor()) {
                    livePath = wire.pathTo((int) ix, (int) iy);
                    invalidate();
                }
                return;
            case MODE_MAGNET:
                if (wire == null || !wire.hasAnchor()) return;
                livePath = wire.pathTo((int) ix, (int) iy);
                if (Math.hypot(ix - lastX, iy - lastY) > 36f && livePath != null && livePath.length > 1) {
                    appendLive();
                    wire.setAnchor((int) ix, (int) iy, 120);
                    lastX = ix;
                    lastY = iy;
                }
                invalidate();
                return;
            case MODE_MOVE:
                moveDx = Math.round(ix - moveFromX);
                moveDy = Math.round(iy - moveFromY);
                if (moveGhost != null) {
                    // la capa entera se mueve como imagen: fluido, sin recalcular nada
                    invalidate();
                    return;
                }
                long now = System.currentTimeMillis();
                if (now - lastMoveApply > 45) {
                    lastMoveApply = now;
                    applyMove(false);
                }
                return;
        }
        if (mode == MODE_SMUDGE || mode == MODE_BLUR || mode == MODE_LIQUIFY) {
            moveEffectStroke(ix, iy);
            invalidate();
            return;
        }
        if (stabilizer > 0f) {
            if (!smoothInit) {
                smoothX = ix;
                smoothY = iy;
                smoothInit = true;
            }
            smoothX = smoothX * stabilizer + ix * (1f - stabilizer);
            smoothY = smoothY * stabilizer + iy * (1f - stabilizer);
            ix = smoothX;
            iy = smoothY;
        }
        float dx = ix - lastX, dy = iy - lastY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        boolean dyn = dynOn && (mode == MODE_PAINT || mode == MODE_ERASER);
        if (dyn && dynSpeed > 0f) {
            long now = System.currentTimeMillis();
            float dts = Math.max(1f, now - lastMoveMs);
            float v = (float) Math.hypot(sx - lastScreenX, sy - lastScreenY) / dts; // px de pantalla por ms
            float target = 1f - dynSpeed * 0.7f * Math.max(0f, Math.min(1f, (v - 0.3f) / 2.5f));
            speedScale = speedScale * 0.7f + target * 0.3f;
            lastMoveMs = now;
            lastScreenX = sx;
            lastScreenY = sy;
        }
        float stepR = dyn ? brushRadius * dynScale(strokeArc) : brushRadius;
        // Borrar fondo ya visita el disco entero por stamp; 0.48 radios
        // conserva solapamiento y evita repetir casi la misma busqueda 3x.
        float spacing = mode == MODE_BGERASE ? .48f : (dyn ? dynSpacing : .3f);
        float step = Math.max(0.6f, stepR * spacing);
        int n = (int) (dist / step);
        if (mode == MODE_BGERASE) n = Math.min(48, n);
        beginBatch();
        try {
            for (int i = 1; i <= n; i++) {
                float t = i / (float) n;
                if (dyn) dynStamp(lastX + dx * t, lastY + dy * t, strokeArc + dist * t);
                else stamp(lastX + dx * t, lastY + dy * t);
            }
        } finally {
            endBatch();
            effR = -1f;
        }
        if (n > 0 && dyn) strokeArc += dist;
        if (n > 0) {
            lastX = ix;
            lastY = iy;
        }
        invalidate();
    }

    private void stamp(float x, float y) {
        if (!drawing) return;
        switch (mode) {
            case MODE_BRUSH:
                stampSelection(x, y);
                break;
            case MODE_PAINT:
            case MODE_ERASER:
                if (strokeOnSelection) stampSelection(x, y);
                else if (strokeErase) stampErase(x, y);
                else stampPaint(x, y);
                break;
            case MODE_BGERASE:
                stampBgErase(x, y);
                break;
            case MODE_MARKER:
                stampMarker(x, y);
                break;
            case MODE_PATCH:
                stampPatchSource(x, y);
                break;
            case MODE_CLONE:
            case MODE_HEAL:
                stampClone(x, y);
                break;
        }
    }

    private void endStroke() {
        handler.removeCallbacks(liquifyHold);
        if (!drawing) return;
        drawing = false;
        smoothInit = false;
        if (mode == MODE_LIQUIFY && strokeLayer != null && liquifyDirtyTiles.size() > 0) {
            // La calidad completa se aplica una sola vez y por tiles al levantar el dedo.
            renderLiquifyFinalTiles();
            invalidate();
        }
        switch (mode) {
            case MODE_LASSO: {
                Path closed = new Path(lasso);
                closed.close();
                lasso.reset();
                fillPathIntoSelection(closed, "Lazo");
                if (callback != null && project != null && project.hasSelection())
                    callback.onLassoCompleted();
                return;
            }
            case MODE_SCISSORS:
                commitWire();
                return;
            case MODE_MAGNET: {
                appendLive();
                Path closed = new Path(wirePath);
                closed.close();
                scissorsReset();
                fillPathIntoSelection(closed, "Magnetico");
                return;
            }
            case MODE_LINE:
                finishLine();
                return;
            case MODE_MOVE:
                finishMove();
                return;
            case MODE_MARKER:
                schedulePreview();
                return;
            case MODE_PATCH:
                return;
            case MODE_HEAL:
                if (strokeRect != null) finishHeal(strokeRect);
                strokeRect = null;
                clearEffectStrokeBackup();
                return;
        }
        // Borrar fondo con pincel: al soltar no se toca nada mas.
        // Lo que se ve con el dedo abajo es exactamente lo que queda.
        if (dynOn && dynTaperEnd > 0f && !strokeOnSelection && (mode == MODE_PAINT || mode == MODE_ERASER)) {
            drawing = true;
            applyTaperEnd();
            drawing = false;
        }
        dynOn = false;
        effR = -1f;
        stopActive = false;
        if (lineStop) warmLineCache();
        if (strokeRect == null) {
            clearEffectStrokeBackup();
            clearSelectionStrokeBackup();
            return;
        }
        if (strokeOnSelection) {
            recordSelectionStrokeUndo(strokeErase ? "Borrar azul" : "Marcar azul");
            changed();
        } else if (strokeLayer != null) {
            if (mode == MODE_PAINT && painted == 0 && selectionActive) {
                msg("Hay algo seleccionado: solo se pinta dentro de lo azul. Quita la seleccion para pintar libre");
            }
            String undoLabel = mode == MODE_PAINT ? "Pincelada" : mode == MODE_ERASER ? "Goma"
                    : mode == MODE_SMUDGE ? "Difuminar" : mode == MODE_BLUR ? "Borrosidad"
                    : mode == MODE_LIQUIFY ? "Especial" : mode == MODE_BGERASE ? "Borrar fondo" : "Clonar";
            recordEffectStrokeUndo(undoLabel);
            project.markDirty();
            wire = null;
            changed();
        }
        strokeRect = null;
        if (!detailValid && !busy) scheduleDetail();
    }

    /** Deshace el trazo en curso sin tocar el historial (llego un segundo dedo). */
    private void cancelStroke() {
        handler.removeCallbacks(liquifyHold);
        if (!drawing) return;
        drawing = false;
        dynOn = false;
        effR = -1f;
        stopActive = false;
        Rect r = strokeRect;
        strokeRect = null;
        lasso.reset();
        linePts.clear();
        if (mode == MODE_SCISSORS || mode == MODE_MAGNET) {
            livePath = null;
            if (mode == MODE_MAGNET) scissorsReset();
        }
        if (mode == MODE_MOVE && moveBackup != null) {
            Layer t = target();
            if (t != null) System.arraycopy(moveBackup, 0, t.px(), 0, moveBackup.length);
            if (moveSelBackup != null) System.arraycopy(moveSelBackup, 0, project.selection, 0, moveSelBackup.length);
            moveBackup = null;
            project.markDirty();
            refreshDisplay();
            refreshOverlay(null);
            return;
        }
        if (effectStrokeBackupLayer != null && mode != MODE_HEAL) {
            restoreEffectStrokeBackup();
            if (mode == MODE_LIQUIFY) resetLiquifySession();
            if (r != null) updateDisplayRegion(r);
            invalidate();
            return;
        }
        if (r == null) {
            invalidate();
            return;
        }
        int rw = r.width();
        if (strokeOnSelection && selectionStrokeBackupTiles.size() > 0) {
            restoreSelectionStrokeBackup();
            paintOverlay(r);
        } else if (strokeLayer != null && pxBackup != null) {
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(pxBackup, y * project.w + r.left, strokeLayer.px(), y * project.w + r.left, rw);
            }
            project.markDirty();
            updateDisplayRegion(r);
        }
        invalidate();
    }

    private void grow(Rect r) {
        if (r == null) return;
        if (strokeRect == null) strokeRect = new Rect(r);
        else strokeRect.union(r);
    }

    private Rect disk(float cx, float cy) {
        float br = rad();
        int x0 = Math.max(0, (int) Math.floor(cx - br) - 1);
        int y0 = Math.max(0, (int) Math.floor(cy - br) - 1);
        int x1 = Math.min(project.w, (int) Math.ceil(cx + br) + 2);
        int y1 = Math.min(project.h, (int) Math.ceil(cy + br) + 2);
        if (x0 >= x1 || y0 >= y1) return null;
        return new Rect(x0, y0, x1, y1);
    }

    private float falloff(int x, int y, float cx, float cy) {
        float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        float br = rad();
        if (d > br + 0.5f) return 0f;
        float inner = br * hardness;
        float a = d <= inner ? 1f : 1f - (d - inner) / Math.max(1f, br - inner);
        // borde suave de 1 pixel: el pincel duro ya no sale dentado
        float edge = br + 0.5f - d;
        if (edge < 1f) a = Math.min(a < 0f ? 0f : a, Math.max(0f, edge));
        if (a <= 0f) return 0f;
        if (dynGrain > 0f && dynOn) a *= 1f - dynGrain * com.pacco.animecut.core.BrushPreset.noise(x, y);
        return a;
    }

    // ------------------------------------------------------------------
    // Pinceles con vida (como Ibis): punta fina al empezar y al terminar,
    // grosor por velocidad, particulas, grano y acumulacion de aerografo.
    // Solo para Brocha y Goma sobre la capa.
    // ------------------------------------------------------------------

    private float dynTaperStart, dynTaperEnd, dynSpeed, dynGrain, dynSpacing = 0.3f, dynFlow;
    private int dynParticles;
    private boolean dynOn;
    private float effR = -1f;
    private float strokeArc, speedScale = 1f, lastScreenX, lastScreenY;
    private long lastMoveMs;
    private float[] dynPts = new float[0];
    private int dynCount;

    public void setBrushDynamics(float taperStart, float taperEnd, float speedThin, int particles,
                                 float grain, float spacing, float flow) {
        dynTaperStart = taperStart;
        dynTaperEnd = taperEnd;
        dynSpeed = speedThin;
        dynParticles = particles;
        dynGrain = grain;
        dynSpacing = spacing <= 0f ? 0.3f : spacing;
        dynFlow = flow;
    }

    private float rad() {
        return effR > 0f ? effR : brushRadius;
    }

    private float taperLen(float amount) {
        return amount * brushRadius * 6f;
    }

    /** Escala del grosor en ese punto del trazo (sin la punta final). */
    private float dynScale(float arc) {
        return com.pacco.animecut.core.BrushPreset.taper(arc, taperLen(dynTaperStart)) * speedScale;
    }

    private void dynRecord(float x, float y, float scale, float arc) {
        if (dynTaperEnd <= 0f) return;
        if (dynCount * 4 + 4 > dynPts.length) {
            float[] n = new float[Math.max(256, dynPts.length * 2)];
            System.arraycopy(dynPts, 0, n, 0, dynCount * 4);
            dynPts = n;
        }
        int k = dynCount * 4;
        dynPts[k] = x;
        dynPts[k + 1] = y;
        dynPts[k + 2] = scale;
        dynPts[k + 3] = arc;
        dynCount++;
    }

    private void dynStamp(float x, float y, float arc) {
        float sc = dynScale(arc);
        effR = Math.max(0.5f, brushRadius * sc);
        stamp(x, y);
        dynRecord(x, y, sc, arc);
    }

    /**
     * Punta final (como "mas tarde" de Ibis): al soltar se sabe donde termina
     * el trazo, asi que la cola se vuelve a pintar afinandose.
     */
    private void applyTaperEnd() {
        if (dynCount < 2 || strokeRect == null || strokeLayer == null) return;
        float total = dynPts[(dynCount - 1) * 4 + 3];
        float lenE = taperLen(dynTaperEnd);
        if (total <= 1f || lenE <= 0f) return;
        int w = project.w;
        Rect r = new Rect(strokeRect);
        restoreLayerBackupRegion(r);
        for (int y = r.top; y < r.bottom; y++) {
            int off = y * w;
            Arrays.fill(cov, off + r.left, off + r.right, (byte) 0);
        }
        painted = 0;
        beginBatch();
        try {
            for (int i = 0; i < dynCount; i++) {
                int k = i * 4;
                float sc = dynPts[k + 2] * com.pacco.animecut.core.BrushPreset.taper(total - dynPts[k + 3], lenE);
                effR = Math.max(0.5f, brushRadius * sc);
                stamp(dynPts[k], dynPts[k + 1]);
            }
        } finally {
            endBatch();
        }
        effR = -1f;
    }

    /** Pincel sobre lo azul. Con "fino" solo agarra el color donde empezaste. */
    private void stampSelection(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureSelectionStrokeBackup(r)) return;
        int[] ref = smart ? project.ref() : null;
        int limit = tolerance + softness;
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                if (a <= 0f) continue;
                int i = row + x;
                int cap = 255;
                if (smart && !strokeErase) {
                    if (useBarrier && project.barrier != null && project.barrier[i] != 0) continue;
                    int d = ColorDist.dist(ref[i], refColor, colorMode);
                    if (d > limit) continue;
                    if (d > tolerance && softness > 0) cap = 255 - ((d - tolerance) * 255) / softness;
                }
                int cur = project.selection[i] & 0xFF;
                if (strokeErase) {
                    int v = cur - (int) (a * 255f);
                    project.selection[i] = (byte) (v < 0 ? 0 : v);
                } else {
                    int v = (int) (a * cap);
                    if (v > cur) project.selection[i] = (byte) v;
                }
            }
        }
        grow(r);
        paintOverlay(r);
        invalidate();
    }

    /** Brocha: pinta el color encima de la capa. Pinta tambien en lo transparente. */
    private final java.util.Random particleRnd = new java.util.Random();

    // ------------------------------------------------------------------
    // Pincel que no pasa la linea negra: solo pinta la zona donde empezaste.
    // La zona "permitida" crece con cada toque del pincel, pero nunca cruza
    // la linea (se busca la linea en todo el dibujo, en todas las capas).
    // ------------------------------------------------------------------

    private boolean lineStop;
    private byte[] allowMask;
    private Rect allowDirty;
    private boolean stopActive, stopSeeded;
    private byte[] stopLines;
    private int[] stopQueue = new int[0];
    private byte[] lineCache;
    private int lineCacheVer = Integer.MIN_VALUE;
    private Project lineCacheOwner;
    private boolean lineCacheBuilding;

    public void setLineStop(boolean on) {
        lineStop = on;
        if (on) warmLineCache();
    }

    public boolean isLineStop() {
        return lineStop;
    }

    /** Busca la linea en segundo plano, para que el trazo empiece sin espera. */
    private void warmLineCache() {
        if (project == null || lineCacheBuilding) return;
        if (lineCache != null && lineCacheOwner == project && lineCacheVer == project.version) return;
        lineCacheBuilding = true;
        final Project p = project;
        final int ver = p.version;
        final int[] ref = p.ref();
        Task.run(new Runnable() {
            @Override
            public void run() {
                lineCacheTmp = buildStopLines(ref, p.w, p.h);
            }
        }, new Runnable() {
            @Override
            public void run() {
                lineCacheBuilding = false;
                if (lineCacheTmp != null && p == project) {
                    lineCache = lineCacheTmp;
                    lineCacheVer = ver;
                    lineCacheOwner = p;
                }
                lineCacheTmp = null;
            }
        });
    }

    private volatile byte[] lineCacheTmp;

    /**
     * Solo cuenta como linea lo oscuro de verdad. Las sombras grises suaves
     * del dibujo ya no cortan el trazo en pedazos.
     */
    private static byte[] buildStopLines(int[] ref, int w, int h) {
        byte[] m = AutoLines.build(ref, w, h);
        for (int i = 0; i < m.length; i++) {
            if (m[i] == 0) continue;
            int c = ref[i];
            if ((c >>> 24) < 128) {
                m[i] = 0;
                continue;
            }
            int lum = (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
            if (lum >= 110) m[i] = 0;
        }
        return m;
    }

    /** Cuantos pixeles se mete el color debajo de la linea (sin cruzarla). */
    private static final int UNDER_LINE = 2;

    /** La linea a respetar: la marcada a mano si la hay, si no la automatica. */
    private byte[] linesForStop() {
        if (useBarrier && project.barrier != null) return project.barrier;
        if (lineCache == null || lineCacheOwner != project || lineCache.length != project.w * project.h) {
            // la primera vez se busca aqui mismo (una sola vez)
            lineCache = buildStopLines(project.ref(), project.w, project.h);
            lineCacheVer = project.version;
            lineCacheOwner = project;
        } else if (lineCacheVer != project.version) {
            // la de antes sirve para este trazo; la nueva se busca aparte
            warmLineCache();
        }
        return lineCache;
    }

    private void beginLineStop() {
        stopActive = lineStop && mode == MODE_PAINT && !strokeOnSelection;
        stopSeeded = false;
        if (!stopActive) return;
        int n = project.w * project.h;
        try {
            if (allowMask == null || allowMask.length != n) {
                allowMask = new byte[n];
                allowDirty = null;
            }
            stopLines = linesForStop();
        } catch (OutOfMemoryError e) {
            stopActive = false;
            return;
        }
        if (allowDirty != null) {
            for (int y = allowDirty.top; y < allowDirty.bottom; y++) {
                Arrays.fill(allowMask, y * project.w + allowDirty.left, y * project.w + allowDirty.right, (byte) 0);
            }
            allowDirty = null;
        }
    }

    private int[] stopQ2 = new int[0];
    private byte[] stopD = new byte[0];

    private int[] stopQueue2(int n) {
        if (stopQ2.length < n) stopQ2 = new int[n];
        return stopQ2;
    }

    private byte[] stopDepth(int n) {
        if (stopD.length < n) stopD = new byte[n];
        return stopD;
    }

    /** Agranda la zona permitida dentro de este toque, sin cruzar la linea. */
    private void growAllowed(Rect r, float cx, float cy) {
        int w = project.w;
        byte[] lines = stopLines, al = allowMask;
        int rw = r.width(), rh = r.height();
        if (stopQueue.length < rw * rh) stopQueue = new int[rw * rh];
        int[] q = stopQueue;
        int head = 0, tail = 0;
        float lim = rad() + 0.5f;
        float lim2 = lim * lim;
        if (!stopSeeded) {
            // primer toque: empieza en el pixel bajo el dedo (o el mas cercano sin linea)
            int sx = Math.max(r.left, Math.min(r.right - 1, (int) cx));
            int sy = Math.max(r.top, Math.min(r.bottom - 1, (int) cy));
            int best = -1;
            float bd = Float.MAX_VALUE;
            for (int y = r.top; y < r.bottom; y++) {
                for (int x = r.left; x < r.right; x++) {
                    int i = y * w + x;
                    if (lines[i] != 0) continue;
                    float d = (x - sx) * (x - sx) + (y - sy) * (y - sy);
                    if (d < bd) {
                        bd = d;
                        best = i;
                    }
                    if (d == 0) break;
                }
            }
            if (best < 0) return;
            al[best] = 1;
            q[tail++] = best;
            stopSeeded = true;
        } else {
            for (int y = r.top; y < r.bottom; y++) {
                for (int x = r.left; x < r.right; x++) {
                    int i = y * w + x;
                    if (al[i] == 1) q[tail++] = i;
                }
            }
        }
        int zoneEnd;
        while (head < tail) {
            int i = q[head++];
            int y = i / w, x = i - y * w;
            for (int k = 0; k < 4; k++) {
                int nx = k == 0 ? x - 1 : k == 1 ? x + 1 : x;
                int ny = k == 2 ? y - 1 : k == 3 ? y + 1 : y;
                if (nx < r.left || ny < r.top || nx >= r.right || ny >= r.bottom) continue;
                int j = ny * w + nx;
                if (al[j] != 0 || lines[j] != 0) continue;
                float dx = nx + 0.5f - cx, dy = ny + 0.5f - cy;
                if (dx * dx + dy * dy > lim2) continue;
                al[j] = 1;
                if (tail < q.length) q[tail++] = j;
            }
        }
        zoneEnd = tail;
        // debajo de la linea: el color entra hasta UNDER_LINE pixeles en la
        // linea, asi no queda filo blanco entre el color y lo negro
        int[] dq = stopQueue2(rw * rh);
        int dh = 0, dt = 0;
        for (int k = 0; k < zoneEnd; k++) dq[dt++] = q[k] | 0; // profundidad 0
        byte[] depth = stopDepth(rw * rh);
        java.util.Arrays.fill(depth, 0, rw * rh, (byte) 0);
        while (dh < dt) {
            int i = dq[dh++];
            int y = i / w, x = i - y * w;
            int dd = al[i] == 2 ? depth[(y - r.top) * rw + (x - r.left)] : 0;
            if (dd >= UNDER_LINE) continue;
            for (int k = 0; k < 4; k++) {
                int nx = k == 0 ? x - 1 : k == 1 ? x + 1 : x;
                int ny = k == 2 ? y - 1 : k == 3 ? y + 1 : y;
                if (nx < r.left || ny < r.top || nx >= r.right || ny >= r.bottom) continue;
                int j = ny * w + nx;
                if (al[j] != 0 || lines[j] == 0) continue;
                float dx = nx + 0.5f - cx, dy = ny + 0.5f - cy;
                if (dx * dx + dy * dy > lim2) continue;
                al[j] = 2;
                depth[(ny - r.top) * rw + (nx - r.left)] = (byte) (dd + 1);
                if (dt < dq.length) dq[dt++] = j;
            }
        }
        if (allowDirty == null) allowDirty = new Rect(r);
        else allowDirty.union(r);
    }

    private void stampPaint(float cx, float cy) {
        // No se debe acceder a cov si el trazo no pudo reservar su memoria.
        if (cov == null || strokeLayer == null) return;
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureEffectStrokeBackup(r)) return;
        int[] px = strokeLayer.px();
        int alphaColor = paintColor >>> 24;
        boolean stop = stopActive && allowMask != null && stopLines != null;
        if (stop) growAllowed(r, cx, cy);
        if (dynOn && dynParticles > 0) {
            stampParticles(cx, cy, r, px, alphaColor);
            return;
        }
        boolean build = dynOn && dynFlow > 0f;
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                int i = row + x;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                if (stop && allowMask[i] == 0) continue;
                if (a <= 0f) continue;
                int sa = (int) (a * alphaColor);
                int old = cov[i] & 0xFF;
                if (build) {
                    // aerografo: cada pasada suma un poco
                    int add = (int) (sa * dynFlow * (1f - old / 255f)) + 1;
                    sa = Math.min(alphaColor, old + add);
                }
                if (sa <= old) continue;
                cov[i] = (byte) sa;
                // se mezcla contra como estaba antes del trazo: repasar no oscurece de mas
                px[i] = paintOver(strokeOriginalAt(i), sa);
                painted++;
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Aerografo de particulas: puntitos sueltos dentro del circulo. */
    private void stampParticles(float cx, float cy, Rect r, int[] px, int alphaColor) {
        float br = rad();
        int cnt = Math.max(4, (int) (dynParticles * Math.min(4f, br / 30f)));
        float dr = Math.max(0.7f, br * 0.05f);
        particleRnd.setSeed(((long) Float.floatToIntBits(cx) << 32) ^ Float.floatToIntBits(cy));
        int w = project.w, h = project.h;
        for (int k = 0; k < cnt; k++) {
            double ang = particleRnd.nextDouble() * Math.PI * 2, rr = Math.sqrt(particleRnd.nextDouble()) * br;
            float px0 = cx + (float) (Math.cos(ang) * rr), py0 = cy + (float) (Math.sin(ang) * rr);
            int x0 = Math.max(0, (int) (px0 - dr)), x1 = Math.min(w, (int) (px0 + dr) + 2);
            int y0 = Math.max(0, (int) (py0 - dr)), y1 = Math.min(h, (int) (py0 + dr) + 2);
            for (int y = y0; y < y1; y++) {
                for (int x = x0; x < x1; x++) {
                    float dx = x + 0.5f - px0, dy = y + 0.5f - py0;
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d > dr) continue;
                    float a = Math.min(1f, (dr - d) + 0.3f) * brushOpacity;
                    int i = y * w + x;
                    if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                    if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                    if (stopActive && allowMask != null && allowMask[i] == 0) continue;
                    int sa = (int) (a * alphaColor);
                    if (sa <= (cov[i] & 0xFF)) continue;
                    cov[i] = (byte) sa;
                    px[i] = paintOver(strokeOriginalAt(i), sa);
                    painted++;
                }
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Goma: baja la transparencia de la capa. Con seleccion, solo dentro de lo azul. */
    private void stampErase(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureEffectStrokeBackup(r)) return;
        int[] px = strokeLayer.px();
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                int i = row + x;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (a <= 0f) continue;
                int orig = strokeOriginalAt(i) >>> 24;
                int want = (int) (orig * (1f - a));
                int cur = px[i] >>> 24;
                if (want < cur) px[i] = (want << 24) | (px[i] & 0x00FFFFFF);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    // ---- borrar fondo por color ----

    private void stampBgErase(float cx, float cy) {
        Layer t = strokeLayer;
        if (t == null) return;
        int w = project.w, h = project.h;
        int cxi = (int) cx, cyi = (int) cy;
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (!captureEffectStrokeBackup(r)) return;
        if (!bgRefValid) {
            if (cxi < 0 || cyi < 0 || cxi >= w || cyi >= h || !sampleBgRef(cxi, cyi)) return;
            bgRefValid = true;
        }
        if (!bgOnce && cxi >= 0 && cyi >= 0 && cxi < w && cyi < h
                && (strokeOriginalAt(cyi * w + cxi) >>> 24) > 32)
            bgRef = strokeOriginalAt(cyi * w + cxi);
        prepareDil(r);
        int bw = r.width(), bh = r.height();
        if (bgLimit == 1) {
            for (int y = r.top; y < r.bottom; y++) {
                for (int x = r.left; x < r.right; x++) {
                    float f = falloff(x, y, cx, cy);
                    if (f > 0f) applyBg(t, y * w + x, f);
                }
            }
        } else {
            if (cxi < r.left || cyi < r.top || cxi >= r.right || cyi >= r.bottom) return;
            if (bgAmount(cyi * w + cxi) <= 0f) {
                dilRect = null;
                return;
            }
            int need = bw * bh;
            if (bgSeen == null || bgSeen.length < need) bgSeen = new byte[need];
            else Arrays.fill(bgSeen, 0, need, (byte) 0);
            if (bgStack == null || bgStack.length < need) bgStack = new int[need];
            int sp = 0;
            int start = (cyi - r.top) * bw + (cxi - r.left);
            bgStack[sp++] = start;
            bgSeen[start] = 1;
            while (sp > 0) {
                int li = bgStack[--sp];
                int ly = li / bw, lx = li - ly * bw;
                int x = r.left + lx, y = r.top + ly, i = y * w + x;
                float f = falloff(x, y, cx, cy);
                if (f <= 0f) continue;
                applyBg(t, i, f);
                if (bgLimit == 2 && gradient != null && (gradient[i] & 0xFF) > 70) continue;
                if (lx > 0) sp = pushBg(bgStack, sp, bgSeen, li - 1, r.left + lx - 1, y);
                if (lx < bw - 1) sp = pushBg(bgStack, sp, bgSeen, li + 1, r.left + lx + 1, y);
                if (ly > 0) sp = pushBg(bgStack, sp, bgSeen, li - bw, x, y - 1);
                if (ly < bh - 1) sp = pushBg(bgStack, sp, bgSeen, li + bw, x, y + 1);
            }
        }
        dilRect = null;
        grow(r);
        updateDisplayRegion(r);
    }

    private int pushBg(int[] st, int sp, byte[] seen, int li, int x, int y) {
        if (seen[li] != 0) return sp;
        seen[li] = 1;
        if (bgAmount(y * project.w + x) <= 0f) return sp;
        st[sp++] = li;
        return sp;
    }

    /**
     * Busca el color del fondo cerca de donde tocaste, saltando lo que ya
     * esta borrado. Sin esto, al pasar de nuevo por una zona ya borrada la
     * herramienta tomaba lo transparente como referencia y no borraba nada.
     */
    private boolean bgRefValid;

    private boolean sampleBgRef(int cx, int cy) {
        int w = project.w, h = project.h;
        int r = (int) Math.max(2, brushRadius);
        // El bucle anterior examinaba TODO el cuadrado para cada radio (O(r^3)).
        // Recorrer solo el PERIMETRO de cada anillo es O(r^2) y conserva la
        // busqueda desde el punto mas cercano, incluso sobre huecos transparentes.
        for (int rad = 0; rad <= r; rad++) {
            for (int dy = -rad; dy <= rad; dy++) {
                int y = cy + dy;
                if (y < 0 || y >= h) continue;
                if (dy == -rad || dy == rad) {
                    // Parte superior/inferior del anillo; conserva el orden
                    // exacto de busqueda anterior, sin recorrer el interior.
                    for (int dx = -rad; dx <= rad; dx++) {
                        int x = cx + dx;
                        if (x < 0 || x >= w) continue;
                        int c = strokeOriginalAt(y * w + x);
                        if ((c >>> 24) > 32) { bgRef = c; return true; }
                    }
                } else {
                    int xl = cx - rad, xr = cx + rad;
                    if (xl >= 0 && xl < w) {
                        int c = strokeOriginalAt(y * w + xl);
                        if ((c >>> 24) > 32) { bgRef = c; return true; }
                    }
                    if (xr >= 0 && xr < w) {
                        int c = strokeOriginalAt(y * w + xr);
                        if ((c >>> 24) > 32) { bgRef = c; return true; }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Cuanto hay que borrar este pixel. No cuenta la transparencia: lo ya
     * borrado se deja pasar para poder seguir por dentro de la zona.
     */
    private float colorAmount(int i) {
        int c = strokeOriginalAt(i);
        if ((c >>> 24) == 0) return 1f;
        int d = ColorDist.dist(c | 0xFF000000, bgRef | 0xFF000000, colorMode);
        if (d <= bgTolerance) return 1f;
        int band = Math.max(1, bgSoftness);
        if (d >= bgTolerance + band) return 0f;
        return 1f - (d - bgTolerance) / (float) band;
    }

    private void applyBg(Layer t, int i, float f) {
        float amt = bgAmount(i) * f * brushOpacity;
        if (amt <= 0f) return;
        if (protectOn && ColorDist.dist(strokeOriginalAt(i), protectColor, colorMode) <= Math.max(6, tolerance / 2)) return;
        if (selectionActive) amt *= (project.selection[i] & 0xFF) / 255f;
        int orig = strokeOriginalAt(i) >>> 24;
        int want = (int) (orig * (1f - amt));
        int cur = t.px()[i] >>> 24;
        if (want < cur) t.px()[i] = (want << 24) | (t.px()[i] & 0x00FFFFFF);
    }

    // ---- dilatacion propia de Borrar fondo ----

    /** Pixeles de dilatacion de Borrar fondo: + se come el borde, - lo devuelve. */
    private float bgExpansion = 0f;

    public void setBgExpansion(float e) {
        bgExpansion = e;
    }

    public float getBgExpansion() {
        return bgExpansion;
    }

    /**
     * Dilatacion en vivo, dentro del circulo del pincel: lo que ves con el
     * dedo abajo es lo que queda. Con + se come el filo de color pegado al
     * fondo, pero nunca la linea oscura del dibujo. Con - deja ese filo.
     */
    private float[] dilBuf;
    private Rect dilRect;

    private void prepareDil(Rect r) {
        dilRect = null;
        float e = bgExpansion;
        if (e == 0f || r == null) return;
        int mg = (int) Math.ceil(Math.abs(e)) + 2;
        Rect big = new Rect(r);
        big.inset(-mg, -mg);
        clamp(big);
        int lw = big.width(), lh = big.height();
        if (lw <= 0 || lh <= 0) return;
        int n = lw * lh;
        byte[] m;
        try {
            if (dilMask == null || dilMask.length < n) dilMask = new byte[n];
            else Arrays.fill(dilMask, 0, n, (byte) 0);
            m = dilMask;
            if (dilBuf == null || dilBuf.length < n) dilBuf = new float[n];
        } catch (OutOfMemoryError oom) {
            return;
        }
        int w = project.w;
        for (int y = big.top; y < big.bottom; y++) {
            int lo = (y - big.top) * lw - big.left, off = y * w;
            for (int x = big.left; x < big.right; x++) {
                m[lo + x] = (byte) (colorAmount(off + x) >= 1f ? 255 : 0);
            }
        }
        MaskOps.expandSubpixel(m, lw, lh, e, null);
        for (int k = 0; k < n; k++) dilBuf[k] = (m[k] & 0xFF) / 255f;
        dilRect = big;
    }

    private static int luma(int c) {
        return (((c >> 16) & 0xFF) * 299 + ((c >> 8) & 0xFF) * 587 + (c & 0xFF) * 114) / 1000;
    }

    /** Cuanto borrar este pixel, contando la dilatacion si esta prendida. */
    private float bgAmount(int i) {
        float ca = colorAmount(i);
        Rect d = dilRect;
        if (d == null) return ca;
        int w = project.w;
        int y = i / w, x = i - y * w;
        if (!d.contains(x, y)) return ca;
        float v = dilBuf[(y - d.top) * d.width() + (x - d.left)];
        if (bgExpansion > 0f) {
            if (v <= ca) return ca;
            int c = strokeOriginalAt(i);
            if ((c >>> 24) == 0) return 1f;
            // la linea oscura del dibujo no se come
            if (luma(c) < 90 && luma(bgRef) >= 130) return ca;
            return v;
        }
        return Math.min(ca, v);
    }

    /** Quita los puntitos de fondo que quedan sueltos entre lo ya borrado. */
    private void despeckle(Rect r) {
        int w = project.w, h = project.h;
        int[] px = strokeLayer.px();
        int limit = bgTolerance * 2;
        ArrayList<Integer> kill = new ArrayList<Integer>();
        for (int y = Math.max(1, r.top); y < Math.min(h - 1, r.bottom); y++) {
            for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++) {
                int i = y * w + x;
                int a = px[i] >>> 24;
                if (a == 0) continue;
                if (ColorDist.dist(px[i] | 0xFF000000, bgRef | 0xFF000000, colorMode) > limit) continue;
                int empty = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        if ((px[i + dy * w + dx] >>> 24) < 40) empty++;
                    }
                }
                if (empty >= 5) kill.add(i);
            }
        }
        for (int i : kill) px[i] = px[i] & 0x00FFFFFF;
        if (!kill.isEmpty()) updateDisplayRegion(r);
    }

    /** Un toque elimina el fondo conectado. Clasificacion y limpieza fuera de UI. */
    private void runBgBucket(final int sx, final int sy) {
        final Layer t = needLayer();
        if (t == null) return;
        strokeLayer = t;
        if (!sampleBgRef(sx, sy)) return;
        final boolean useSel = project.hasSelection();
        final Project owner = project;
        final Rect[] found = new Rect[1];
        // El buffer de alfa (1 byte/pixel) ocupa cuatro veces MENOS memoria que
        // crear una capa de pixeles adicional. La copia final en UI es muy corta.
        final byte[][] preparedAlpha = new byte[1][];
        setBusy(true);
        try {
            ensureScratch();
        } catch (OutOfMemoryError oom) {
            setBusy(false);
            msg("Borrar fondo necesita mas memoria; cierra otras aplicaciones");
            return;
        }
        Task.run(new Runnable() {
            @Override public void run() {
                try {
                    Arrays.fill(scratch, (byte) 0);
                    Rect r = FloodFill.contiguous(t.px(), owner.w, owner.h, scratch,
                            useBarrier ? owner.barrier : null, sx, sy, bgTolerance, bgSoftness, colorMode);
                    if (r != null && bgExpansion != 0f) {
                        MaskOps.expandSubpixel(scratch, owner.w, owner.h, bgExpansion, r);
                        int m = (int) Math.ceil(Math.abs(bgExpansion)) + 2;
                        r.inset(-m, -m);
                        if (!r.intersect(0, 0, owner.w, owner.h)) r = null;
                    }
                    found[0] = r;
                    if (r == null) return;
                    long area = (long) r.width() * r.height();
                    if (area > 12_000_000L) return; // limite para telefonos con poca RAM
                    preparedAlpha[0] = com.pacco.animecut.core.BackgroundEraseAlpha.prepare(
                            t.px(), owner.w, owner.h, r.left, r.top, r.right, r.bottom,
                            scratch, useSel ? owner.selection : null, bgRef, bgTolerance, colorMode);
                } catch (OutOfMemoryError oom) {
                    preparedAlpha[0] = null; // continuar con el codigo seguro original
                }
            }
        }, new Runnable() {
            @Override public void run() {
                if (owner != project) { setBusy(false); return; }
                Rect r = found[0];
                if (r == null) {
                    setBusy(false);
                    msg("No encontre fondo parecido ahi. Sube la tolerancia");
                    return;
                }
                undo.setLabel("Borrar fondo");
                undo.recordLayer(t, r);
                int[] px = t.px();
                if (preparedAlpha[0] != null) {
                    byte[] alpha = preparedAlpha[0];
                    int rw = r.width();
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * owner.w + r.left;
                        int src = (y - r.top) * rw;
                        for (int x = 0; x < rw; x++) {
                            int i = off + x;
                            px[i] = ((alpha[src + x] & 0xFF) << 24) | (px[i] & 0x00FFFFFF);
                        }
                    }
                    preparedAlpha[0] = null;
                } else {
                    // Reserva fallida: ruta antigua lenta, pero sin perder edicion.
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * owner.w;
                        for (int x = r.left; x < r.right; x++) {
                            int i = off + x, a = scratch[i] & 0xFF;
                            if (a == 0) continue;
                            float f = a / 255f;
                            if (useSel) f *= (owner.selection[i] & 0xFF) / 255f;
                            int col = px[i], orig = col >>> 24;
                            int want = (int) (orig * (1f - f));
                            if (want < orig) px[i] = (want << 24) | (col & 0x00FFFFFF);
                        }
                    }
                    strokeLayer = t;
                    despeckle(r);
                }
                strokeLayer = t;
                pixelsChanged(r);
                setBusy(false);
                showHud("Fondo borrado");
            }
        });
    }

    private void ensureGradient(int[] px) {
        int w = project.w, h = project.h;
        gradient = new byte[w * h];
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                int gx = LineRepair.lum(px[i - w + 1]) + 2 * LineRepair.lum(px[i + 1]) + LineRepair.lum(px[i + w + 1])
                        - LineRepair.lum(px[i - w - 1]) - 2 * LineRepair.lum(px[i - 1]) - LineRepair.lum(px[i + w - 1]);
                int gy = LineRepair.lum(px[i + w - 1]) + 2 * LineRepair.lum(px[i + w]) + LineRepair.lum(px[i + w + 1])
                        - LineRepair.lum(px[i - w - 1]) - 2 * LineRepair.lum(px[i - w]) - LineRepair.lum(px[i - w + 1]);
                int m = (Math.abs(gx) + Math.abs(gy)) >> 2;
                gradient[i] = (byte) (m > 255 ? 255 : m);
            }
        }
    }

    // ---- clonar y corrector ----

    private int cloneSource(int x, int y) {
        float dx = x - cloneDestX, dy = y - cloneDestY;
        if (cloneMirror) dx = -dx;
        if (cloneAngle != 0f) {
            double a = Math.toRadians(cloneAngle);
            float c = (float) Math.cos(a), s = (float) Math.sin(a);
            float rx = dx * c - dy * s, ry = dx * s + dy * c;
            dx = rx;
            dy = ry;
        }
        int sx = Math.round(cloneSrcX + dx), sy = Math.round(cloneSrcY + dy);
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return -1;
        return sy * project.w + sx;
    }

    private void stampClone(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        if (mode != MODE_HEAL) {
            if (!captureEffectStrokeBackup(r)) return;
            captureCloneSourceBackup(r);
        }
        int[] px = strokeLayer.px();
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                float a = falloff(x, y, cx, cy) * brushOpacity;
                if (a <= 0f) continue;
                int src = cloneSource(x, y);
                if (src < 0) continue;
                int i = y * project.w + x;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                int ca = (int) (a * 255f);
                if (ca <= (cov[i] & 0xFF)) continue;
                cov[i] = (byte) ca;
                px[i] = mix(strokeOriginalAt(i), strokeOriginalAt(src), a);
            }
        }
        grow(r);
        updateDisplayRegion(r);
    }

    /** Mezcla dos pixeles con alfa incluido. */
    private static int mix(int a, int b, float t) {
        int it = (int) (t * 256f);
        if (it <= 0) return a;
        if (it >= 256) return b;
        int aa = (((b >>> 24) * it) + ((a >>> 24) * (256 - it))) >> 8;
        int r = ((((b >> 16) & 0xFF) * it) + (((a >> 16) & 0xFF) * (256 - it))) >> 8;
        int g = ((((b >> 8) & 0xFF) * it) + (((a >> 8) & 0xFF) * (256 - it))) >> 8;
        int bl = (((b & 0xFF) * it) + ((a & 0xFF) * (256 - it))) >> 8;
        return (aa << 24) | (r << 16) | (g << 8) | bl;
    }

    private void finishHeal(final Rect r) {
        final Layer t = strokeLayer;
        final int left = r.left, top = r.top, right = r.right, bottom = r.bottom;
        final int rw = right - left, rh = bottom - top;
        final boolean[] region = new boolean[rw * rh];
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                int i = (top + y) * project.w + left + x;
                region[y * rw + x] = t.px()[i] != pxBackup[i];
            }
        }
        undo.setLabel("Corrector");
        undo.recordLayerFromBackup(t, r, pxBackup);
        final int[] orig = pxBackup;
        pxBackup = null;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                Membrane.heal(t.px(), orig, orig, project.w, project.h, region, left, top, right, bottom,
                        new Membrane.SourceMap() {
                            @Override
                            public int map(int x, int y) {
                                return cloneSource(x, y);
                            }
                        });
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                pixelsChanged(r);
            }
        });
    }

    public void resetCloneSource() {
        cloneSrcSet = false;
        invalidate();
        msg("Toca de donde quieres copiar");
    }

    // ---- lazo, tijeras, magnetico ----

    private void fillPathIntoSelection(Path closed, String label) {
        RectF b = new RectF();
        closed.computeBounds(b, true);
        Rect region = new Rect((int) Math.floor(b.left), (int) Math.floor(b.top),
                (int) Math.ceil(b.right) + 1, (int) Math.ceil(b.bottom) + 1);
        clamp(region);
        if (region.isEmpty()) {
            invalidate();
            return;
        }
        int rw = region.width(), rh = region.height();
        Bitmap tmp;
        int[] row;
        try {
            tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
            row = new int[rw];
        } catch (OutOfMemoryError oom) {
            msg("No alcanza memoria para este lazo. Acerca la imagen o extrae una parte menor.");
            return;
        }
        undo.setLabel(label);
        undo.recordSelection(region);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        c.translate(-region.left, -region.top);
        c.drawPath(closed, pt);
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (region.top + y) * project.w + region.left;
            for (int x = 0; x < rw; x++) {
                int a = row[x] >>> 24;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        paintOverlay(region);
        invalidate();
        changed();
    }

    private void setAnchorAsync(final int x, final int y) {
        setBusy(true);
        final int[] ref = project.ref();
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (wire == null) wire = new LiveWire(ref, project.w, project.h);
                wire.setAnchor(x, y, 320);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                invalidate();
            }
        });
    }

    private void appendLive() {
        if (livePath == null || livePath.length < 2) return;
        for (int i = livePath.length - 1; i >= 0; i -= 2) {
            int y = livePath[i] / project.w, x = livePath[i] - y * project.w;
            wirePath.lineTo(x, y);
        }
        livePath = null;
    }

    private void commitWire() {
        if (livePath == null || livePath.length < 2) return;
        int last = livePath[0];
        appendLive();
        int ly = last / project.w, lx = last - ly * project.w;
        if (firstAnchor >= 0) {
            int fy = firstAnchor / project.w, fx = firstAnchor - fy * project.w;
            if (Math.hypot(lx - fx, ly - fy) < 24f) {
                scissorsClose();
                return;
            }
        }
        setAnchorAsync(lx, ly);
        invalidate();
    }

    public void scissorsClose() {
        if (project == null || !wireStarted) {
            msg("Primero traza el contorno con las tijeras");
            return;
        }
        Path closed = new Path(wirePath);
        closed.close();
        scissorsReset();
        fillPathIntoSelection(closed, "Tijeras");
    }

    public void scissorsReset() {
        wirePath.reset();
        livePath = null;
        firstAnchor = -1;
        wireStarted = false;
        invalidate();
    }

    // ---- mover capa o lo seleccionado ----

    private void startMove(float ix, float iy) {
        Layer t = needLayer();
        if (t == null) return;
        try {
            moveBackup = t.px().clone();
        } catch (OutOfMemoryError e) {
            moveBackup = null;
            if (undo != null) undo.trimTo(0.3f);
            System.gc();
            try {
                moveBackup = t.px().clone();
            } catch (OutOfMemoryError e2) {
                msg("Ya no alcanza la memoria para mover. Combina o borra alguna capa.");
                return;
            }
        }
        selectionActive = project.hasSelection();
        moveSelBackup = selectionActive ? project.selection.clone() : null;
        moveFromX = ix;
        moveFromY = iy;
        moveDx = moveDy = 0;
        drawing = true;
        lastMoveApply = 0;
        if (!selectionActive) startGhost(t);
    }

    // Mover fluido: mientras arrastras, la capa se dibuja como una imagen
    // encima (rapido, en la tarjeta de video) y se aplica al soltar.
    private Bitmap moveGhost;
    private Rect moveGhostRect;
    private Layer moveGhostLayer;
    private final Paint ghostMovePaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    private void startGhost(Layer t) {
        try {
            Layer.Packed pk = t.snapshot(project.w, project.h);
            if (pk.empty()) return;
            int[] px = new int[pk.w * pk.h];
            pk.bmp.getPixels(px, 0, pk.w, 0, 0, pk.w, pk.h);
            moveGhost = Bitmap.createBitmap(px, pk.w, pk.h, Bitmap.Config.ARGB_8888);
            moveGhostRect = new Rect(pk.x, pk.y, pk.x + pk.w, pk.y + pk.h);
            moveGhostLayer = t;
            ghostMovePaint.setAlpha(t.opacity);
            t.visible = false;
            refreshDisplay();
        } catch (OutOfMemoryError e) {
            moveGhost = null;
        }
    }

    private void endGhost() {
        if (moveGhostLayer != null) moveGhostLayer.visible = true;
        if (moveGhost != null && !moveGhost.isRecycled()) moveGhost.recycle();
        moveGhost = null;
        moveGhostRect = null;
        moveGhostLayer = null;
    }

    /** Mueve la capa entera, o solo lo seleccionado si hay algo azul. */
    private void applyMove(boolean fin) {
        Layer t = target();
        if (t == null || moveBackup == null) return;
        int w = project.w, h = project.h;
        int[] px = t.px();
        int dx = moveDx, dy = moveDy;
        if (moveSelBackup == null) {
            Arrays.fill(px, 0);
            for (int y = 0; y < h; y++) {
                int ty = y + dy;
                if (ty < 0 || ty >= h) continue;
                int x0 = Math.max(0, -dx), x1 = Math.min(w, w - dx);
                if (x0 >= x1) continue;
                System.arraycopy(moveBackup, y * w + x0, px, ty * w + x0 + dx, x1 - x0);
            }
        } else {
            // lo de afuera queda; lo seleccionado se levanta y se pone en su nuevo lugar
            for (int i = 0; i < px.length; i++) {
                int s = moveSelBackup[i] & 0xFF;
                int c = moveBackup[i];
                int a = ((c >>> 24) * (255 - s)) / 255;
                px[i] = (a << 24) | (c & 0x00FFFFFF);
            }
            Arrays.fill(project.selection, (byte) 0);
            for (int y = 0; y < h; y++) {
                int ty = y + dy;
                if (ty < 0 || ty >= h) continue;
                for (int x = 0; x < w; x++) {
                    int tx = x + dx;
                    if (tx < 0 || tx >= w) continue;
                    int i = y * w + x;
                    int s = moveSelBackup[i] & 0xFF;
                    if (s == 0) continue;
                    int c = moveBackup[i];
                    int a = ((c >>> 24) * s) / 255;
                    int j = ty * w + tx;
                    if (a > 0) px[j] = Project.over(px[j], c, a);
                    project.selection[j] = (byte) s;
                }
            }
            paintOverlay(project.fullRect());
        }
        project.markDirty();
        buildDisplay();
        invalidate();
    }

    private void finishMove() {
        if (moveBackup == null) return;
        boolean hadGhost = moveGhost != null;
        endGhost();
        applyMove(true);
        if (hadGhost) refreshDisplay();
        Layer t = target();
        if ((moveDx != 0 || moveDy != 0) && t != null) {
            undo.setLabel("Mover");
            undo.begin();
            undo.recordLayerFromBackup(t, project.fullRect(), moveBackup);
            if (moveSelBackup != null) undo.recordSelectionFromBackup(project.fullRect(), moveSelBackup);
            undo.end();
            changed();
        }
        moveBackup = null;
        moveSelBackup = null;
    }

    // ==================================================================
    // Varita, balde, gama de colores
    // ==================================================================

    private void runWand(final int sx, final int sy) {
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int[] ref = project.ref();
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = wandGlobal
                        ? FloodFill.global(ref, project.w, project.h, scratch, sx, sy, tolerance, softness, colorMode)
                        : fillWithGaps(ref, sx, sy);
                if (lastFillRect != null && expansion != 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(Math.abs(expansion)) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
                if (lastFillRect != null && toLine) {
                    byte[] line = useBarrier && project.barrier != null ? project.barrier : autoBarrier(ref);
                    growToLine(line, lastFillRect, 6);
                }
                if (lastFillRect != null && fillUnpainted) {
                    MaskOps.fillEnclosed(scratch, project.w, project.h, 6000);
                    lastFillRect = project.fullRect();
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Varita");
                    undo.recordSelection(r);
                    mergeScratch(r);
                    paintOverlay(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    // ------------------------------------------------------------------
    // Ver la linea: por unos segundos se pinta en rojo lo que cuenta como
    // linea, asi sabes si el ajuste sirve para tu dibujo.
    // ------------------------------------------------------------------

    private Bitmap redLines;
    private final Runnable hideRedLines = new Runnable() {
        @Override
        public void run() {
            if (redLines != null && !redLines.isRecycled()) redLines.recycle();
            redLines = null;
            invalidate();
        }
    };

    private void showRedLines(byte[] mask) {
        if (mask == null || display == null || project == null) return;
        int dw = display.getWidth(), dh = display.getHeight();
        Bitmap b = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        int[] row = new int[dw];
        for (int y = 0; y < dh; y++) {
            int sy = Math.min(project.h - 1, (int) (y * dispScale));
            for (int x = 0; x < dw; x++) {
                int sx = Math.min(project.w - 1, (int) (x * dispScale));
                row[x] = mask[sy * project.w + sx] != 0 ? 0xDDFF2020 : 0;
            }
            b.setPixels(row, 0, dw, 0, y, dw, 1);
        }
        handler.removeCallbacks(hideRedLines);
        if (redLines != null && !redLines.isRecycled()) redLines.recycle();
        redLines = b;
        handler.postDelayed(hideRedLines, 4500);
        invalidate();
    }

    /** Muestra en rojo la linea que usa la varita automatica. */
    public void previewAutoLines() {
        if (project == null) return;
        final int[] ref = project.ref();
        final byte[][] out = new byte[1][];
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                out[0] = autoBarrier(ref);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                showHud("En rojo: lo que la varita toma como linea");
                showRedLines(out[0]);
            }
        });
    }

    /** Varita que no se escapa por los cortes de la linea (encendida por defecto). */
    private boolean autoLines = true;
    private byte[] autoBarrier;
    private int autoBarrierVer = Integer.MIN_VALUE;
    private Project autoBarrierOwner;

    public void setAutoLines(boolean on) {
        autoLines = on;
    }

    public boolean isAutoLines() {
        return autoLines;
    }

    private byte[] autoBarrier(int[] ref) {
        Project p = project;
        if (autoBarrier == null || autoBarrierOwner != p || autoBarrierVer != p.version
                || autoBarrier.length != p.w * p.h) {
            int ver = p.version;
            autoBarrier = null;
            autoBarrier = AutoLines.build(ref, p.w, p.h);
            autoBarrierVer = ver;
            autoBarrierOwner = p;
        }
        return autoBarrier;
    }

    /**
     * Relleno con "bola atrapada": la linea se engorda para tapar sus cortes,
     * se rellena, y despues lo relleno vuelve a crecer hasta tocar la linea.
     */
    private Rect fillWithGaps(int[] ref, int sx, int sy) {
        return fillWithGaps(ref, sx, sy, tolerance);
    }

    private Rect fillWithGaps(int[] ref, int sx, int sy, int tolerance) {
        byte[] barrier = useBarrier ? project.barrier : null;
        boolean gaps = gapOn;
        int rad = gapRadius;
        if (barrier == null && autoLines) {
            barrier = autoBarrier(ref);
            gaps = true;
            rad = Math.max(3, gapRadius);
            // si tocaste justo sobre la linea, se usa la varita normal
            if (barrier[sy * project.w + sx] != 0) barrier = null;
        }
        if (!gaps || barrier == null) {
            return FloodFill.contiguous(ref, project.w, project.h, scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        if (gapBarrier == null || gapBarrier.length != barrier.length) gapBarrier = new byte[barrier.length];
        MaskOps.closeGapsBarrier(barrier, project.w, project.h, rad, gapBarrier);
        if (gapBarrier[sy * project.w + sx] != 0) {
            return FloodFill.contiguous(ref, project.w, project.h, scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        Rect r = FloodFill.contiguous(ref, project.w, project.h, scratch, gapBarrier, sx, sy, tolerance, softness, colorMode);
        if (r == null) return null;
        // vuelve a crecer solo hacia pixeles de color parecido al tocado
        int seed = ref[sy * project.w + sx];
        r.inset(-rad - 1, -rad - 1);
        clamp(r);
        growBack(ref, seed, barrier, r, rad);
        return r;
    }

    /** Hasta la linea: quita el borde blanco que queda entre lo elegido y la linea negra. */
    private boolean toLine = true, fillUnpainted = false;

    public void setToLine(boolean b) {
        toLine = b;
    }

    public boolean isToLine() {
        return toLine;
    }

    public void setFillUnpainted(boolean b) {
        fillUnpainted = b;
    }

    public boolean isFillUnpainted() {
        return fillUnpainted;
    }

    /** Hace crecer lo elegido hasta rad pixeles, parando en la linea negra. */
    private void growToLine(byte[] line, Rect r, int rad) {
        int w = project.w, h = project.h;
        r.inset(-rad - 1, -rad - 1);
        clamp(r);
        // solo crece cerca de la linea: asi no se come sombras o colores vecinos
        int rw = r.width(), rh = r.height();
        byte[] near = new byte[rw * rh];
        for (int y = 0; y < rh; y++) System.arraycopy(line, (r.top + y) * w + r.left, near, y * rw, rw);
        MaskOps.dilate(near, rw, rh, rad);
        for (int pass = 0; pass < rad; pass++) {
            for (int y = Math.max(1, r.top); y < Math.min(h - 1, r.bottom); y++) {
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++) {
                    int i = y * w + x;
                    if (scratch[i] != 0 || line[i] != 0) continue;
                    if (near[(y - r.top) * rw + (x - r.left)] == 0) continue;
                    int a;
                    if (((a = scratch[i - 1] & 0xFF) >= 200 && a != 253) || ((a = scratch[i + 1] & 0xFF) >= 200 && a != 253)
                            || ((a = scratch[i - w] & 0xFF) >= 200 && a != 253) || ((a = scratch[i + w] & 0xFF) >= 200 && a != 253)) {
                        scratch[i] = (byte) 253;
                    }
                }
            }
            for (int y = r.top; y < r.bottom; y++)
                for (int x = r.left; x < r.right; x++)
                    if (scratch[y * w + x] == (byte) 253) scratch[y * w + x] = (byte) 255;
        }
    }

    /** Crece lo relleno rad pixeles sin pasar la linea ni colores muy distintos. */
    private void growBack(int[] ref, int seed, byte[] barrier, Rect r, int rad) {
        int w = project.w;
        int lim = Math.max(tolerance * 2, 60);
        for (int pass = 0; pass < rad; pass++) {
            for (int y = Math.max(1, r.top); y < Math.min(project.h - 1, r.bottom); y++) {
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++) {
                    int i = y * w + x;
                    if (scratch[i] != 0 || barrier[i] != 0) continue;
                    int best = 0;
                    int a;
                    if ((a = scratch[i - 1] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i + 1] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i - w] & 0xFF) > best && a != 253) best = a;
                    if ((a = scratch[i + w] & 0xFF) > best && a != 253) best = a;
                    if (best < 200) continue;
                    if (ColorDist.dist(ref[i] | 0xFF000000, seed | 0xFF000000, colorMode) > lim) continue;
                    scratch[i] = (byte) 253;
                }
            }
            for (int y = Math.max(1, r.top); y < Math.min(project.h - 1, r.bottom); y++)
                for (int x = Math.max(1, r.left); x < Math.min(w - 1, r.right); x++)
                    if (scratch[y * w + x] == (byte) 253) scratch[y * w + x] = (byte) 254;
        }
        for (int i = 0; i < scratch.length; i++) if (scratch[i] == (byte) 254) scratch[i] = (byte) 255;
    }

    private void mergeScratch(Rect r) {
        for (int y = r.top; y < r.bottom; y++) {
            int off = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                int a = scratch[off + x] & 0xFF;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
    }

    /** Relleno: pinta la zona tocada con el color, en la capa elegida. */
    // ---- opciones propias del Relleno (ya no usa las de la varita) ----
    private int fillTolerance = 32;
    private float fillExpansion = 2f;
    private boolean fillAllLayers = true, fillToLine = true;

    public void setFillTolerance(int t) {
        fillTolerance = Math.max(0, Math.min(160, t));
    }

    public int getFillTolerance() {
        return fillTolerance;
    }

    public void setFillExpansion(float e) {
        fillExpansion = e;
    }

    public void setFillAllLayers(boolean b) {
        fillAllLayers = b;
    }

    public boolean isFillAllLayers() {
        return fillAllLayers;
    }

    public void setFillToLine(boolean b) {
        fillToLine = b;
    }

    public boolean isFillToLine() {
        return fillToLine;
    }

    /**
     * Relleno: mira todas las capas o solo la elegida, con su propia
     * tolerancia. La dilatacion mete el color debajo del borde suave de la
     * linea, asi no queda el filo blanco entre el relleno y la linea.
     */
    private void runBucket(final int sx, final int sy) {
        final Layer t = needLayer();
        if (t == null) return;
        setBusy(true);
        ensureScratch();
        final boolean useSel = project.hasSelection();
        final boolean all = fillAllLayers;
        final int[] layerPx = all ? null : t.px();
        final int tol = fillTolerance;
        final float exp = fillExpansion;
        final boolean line = fillToLine;
        Task.run(new Runnable() {
            @Override
            public void run() {
                int[] ref = all ? project.ref() : layerPx;
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = all ? fillWithGaps(ref, sx, sy, tol)
                        : FloodFill.contiguous(ref, project.w, project.h, scratch, null, sx, sy, tol, softness, colorMode);
                if (lastFillRect != null && line) {
                    int[] comp = all ? ref : project.ref();
                    byte[] lm = useBarrier && project.barrier != null ? project.barrier : autoBarrier(comp);
                    growToLine(lm, lastFillRect, 6);
                }
                if (lastFillRect != null && exp > 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, exp, lastFillRect);
                    int m = (int) Math.ceil(exp) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Relleno");
                    undo.recordLayer(t, r);
                    int ca = paintColor >>> 24;
                    int[] px = t.px();
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * project.w;
                        for (int x = r.left; x < r.right; x++) {
                            int i = off + x;
                            int a = scratch[i] & 0xFF;
                            if (a == 0) continue;
                            float f = a / 255f * brushOpacity;
                            if (useSel) f *= (project.selection[i] & 0xFF) / 255f;
                            int sa = (int) (f * ca);
                            if (sa > 0) px[i] = t.alphaLock ? Project.lockOver(px[i], paintColor, sa)
                                    : Project.over(px[i], paintColor, sa);
                        }
                    }
                    pixelsChanged(r);
                } else {
                    msg("Ahi no hay nada que rellenar");
                }
                setBusy(false);
            }
        });
    }

    // ==================================================================
    // Curva Bezier y Polilinea, como en Ibis: tocas para poner puntos,
    // arrastras un punto para moverlo y el check lo dibuja en la capa.
    // ==================================================================

    private final java.util.ArrayList<float[]> shapePts = new java.util.ArrayList<float[]>();
    private int shapeSel = -1, shapeDrag = -1;
    private boolean shapeDownOn, shapeFill;
    private float shapeGrabDx, shapeGrabDy;
    private final Paint shapeStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeGuide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeDotEdge = new Paint(Paint.ANTI_ALIAS_FLAG);

    {
        shapeStroke.setStyle(Paint.Style.STROKE);
        shapeStroke.setStrokeCap(Paint.Cap.ROUND);
        shapeStroke.setStrokeJoin(Paint.Join.ROUND);
        shapeFillPaint.setStyle(Paint.Style.FILL);
        shapeGuide.setStyle(Paint.Style.STROKE);
        shapeGuide.setColor(0xCC000000);
        shapeGuide.setPathEffect(new android.graphics.DashPathEffect(new float[]{12f, 10f}, 0f));
        shapeDot.setStyle(Paint.Style.FILL);
        shapeDotEdge.setStyle(Paint.Style.STROKE);
        shapeDotEdge.setColor(0xFFFFFFFF);
    }

    public boolean isShapeTool() {
        return mode == MODE_CURVE || mode == MODE_POLY;
    }

    public int shapeCount() {
        return shapePts.size();
    }

    public void setShapeFill(boolean b) {
        shapeFill = b;
        invalidate();
    }

    public boolean isShapeFill() {
        return shapeFill;
    }

    public void shapeClear() {
        shapePts.clear();
        shapeSel = -1;
        shapeDrag = -1;
        invalidate();
    }

    /** Quita el punto rojo (el elegido). */
    public void shapeDeleteSelected() {
        if (shapePts.isEmpty()) return;
        int k = shapeSel >= 0 && shapeSel < shapePts.size() ? shapeSel : shapePts.size() - 1;
        shapePts.remove(k);
        shapeSel = shapePts.isEmpty() ? -1 : Math.min(k, shapePts.size() - 1);
        invalidate();
    }

    private float dpx(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private int hitShapePoint(float sx, float sy) {
        float best = dpx(26f);
        int hit = -1;
        float[] q = new float[2];
        for (int i = shapePts.size() - 1; i >= 0; i--) {
            q[0] = shapePts.get(i)[0];
            q[1] = shapePts.get(i)[1];
            view.mapPoints(q);
            float d = (float) Math.hypot(q[0] - sx, q[1] - sy);
            if (d < best) {
                best = d;
                hit = i;
            }
        }
        return hit;
    }

    private float[] imgPoint(float sx, float sy) {
        toImage(sx, sy);
        float x = Math.max(0f, Math.min(project.w - 1, point[0]));
        float y = Math.max(0f, Math.min(project.h - 1, point[1]));
        return new float[]{x, y};
    }

    private void shapeDown(float sx, float sy) {
        shapeDownOn = true;
        int k = hitShapePoint(sx, sy);
        shapeDrag = k;
        if (k >= 0) {
            shapeSel = k;
            float[] q = {shapePts.get(k)[0], shapePts.get(k)[1]};
            view.mapPoints(q);
            shapeGrabDx = q[0] - sx;
            shapeGrabDy = q[1] - sy;
        }
        invalidate();
    }

    private void shapeMove(float sx, float sy, float moved) {
        if (!shapeDownOn) return;
        if (shapeDrag < 0) {
            if (moved <= touchSlop) return;
            // arrastrar en vacio: pone un punto nuevo y lo lleva con el dedo
            shapePts.add(imgPoint(downX, downY));
            shapeDrag = shapeSel = shapePts.size() - 1;
            shapeGrabDx = 0f;
            shapeGrabDy = 0f;
        }
        float[] p = imgPoint(sx + shapeGrabDx, sy + shapeGrabDy);
        float[] t = shapePts.get(shapeDrag);
        t[0] = p[0];
        t[1] = p[1];
        invalidate();
    }

    private void shapeUp() {
        if (!shapeDownOn) return;
        shapeDownOn = false;
        if (shapeDrag < 0) {
            shapePts.add(imgPoint(downX, downY));
            shapeSel = shapePts.size() - 1;
            if (shapePts.size() == 1) msg("Toca para poner puntos. Arrastra un punto para moverlo. Check para dibujar");
        }
        shapeDrag = -1;
        invalidate();
    }

    private void shapeCancelTouch() {
        shapeDownOn = false;
        shapeDrag = -1;
    }

    /** La forma como una fila de puntos en la imagen (x0,y0,x1,y1,...). */
    private float[] shapeFlat(boolean closed) {
        int n = shapePts.size();
        java.util.ArrayList<Float> out = new java.util.ArrayList<Float>();
        if (n == 0) return new float[0];
        if (mode == MODE_POLY || n < 3) {
            for (float[] p : shapePts) {
                out.add(p[0]);
                out.add(p[1]);
            }
            if (closed) {
                out.add(shapePts.get(0)[0]);
                out.add(shapePts.get(0)[1]);
            }
        } else {
            // curva que pasa por todos los puntos (Catmull-Rom hecha con Bezier)
            int segs = closed ? n : n - 1;
            out.add(shapePts.get(0)[0]);
            out.add(shapePts.get(0)[1]);
            for (int i = 0; i < segs; i++) {
                float[] p0 = shapePts.get(closed ? (i - 1 + n) % n : Math.max(0, i - 1));
                float[] p1 = shapePts.get(i);
                float[] p2 = shapePts.get((i + 1) % n);
                float[] p3 = shapePts.get(closed ? (i + 2) % n : Math.min(n - 1, i + 2));
                float c1x = p1[0] + (p2[0] - p0[0]) / 6f, c1y = p1[1] + (p2[1] - p0[1]) / 6f;
                float c2x = p2[0] - (p3[0] - p1[0]) / 6f, c2y = p2[1] - (p3[1] - p1[1]) / 6f;
                float len = (float) (Math.hypot(c1x - p1[0], c1y - p1[1]) + Math.hypot(c2x - c1x, c2y - c1y)
                        + Math.hypot(p2[0] - c2x, p2[1] - c2y));
                int steps = Math.max(8, Math.min(400, (int) (len / 2f)));
                for (int k = 1; k <= steps; k++) {
                    float t = k / (float) steps, u = 1f - t;
                    float x = u * u * u * p1[0] + 3 * u * u * t * c1x + 3 * u * t * t * c2x + t * t * t * p2[0];
                    float y = u * u * u * p1[1] + 3 * u * u * t * c1y + 3 * u * t * t * c2y + t * t * t * p2[1];
                    out.add(x);
                    out.add(y);
                }
            }
        }
        float[] a = new float[out.size()];
        for (int i = 0; i < a.length; i++) a[i] = out.get(i);
        return a;
    }

    private void drawShape(Canvas c) {
        int n = shapePts.size();
        boolean closed = shapeFill && n >= 3;
        float sc = currentScale();
        if (n >= 2) {
            float[] f = shapeFlat(closed);
            view.mapPoints(f);
            Path p = new Path();
            p.moveTo(f[0], f[1]);
            for (int i = 2; i + 1 < f.length; i += 2) p.lineTo(f[i], f[i + 1]);
            int col = (paintColor & 0x00FFFFFF) | (Math.round((paintColor >>> 24) * brushOpacity) << 24);
            if (closed) {
                Path fp = new Path(p);
                fp.close();
                shapeFillPaint.setColor(col);
                c.drawPath(fp, shapeFillPaint);
            }
            shapeStroke.setColor(col);
            shapeStroke.setStrokeWidth(Math.max(1f, brushRadius * 2f * sc));
            c.drawPath(p, shapeStroke);
            if (mode == MODE_CURVE && n >= 3) {
                shapeGuide.setStrokeWidth(dpx(1.2f));
                float[] q = new float[n * 2];
                for (int i = 0; i < n; i++) {
                    q[i * 2] = shapePts.get(i)[0];
                    q[i * 2 + 1] = shapePts.get(i)[1];
                }
                view.mapPoints(q);
                Path g = new Path();
                g.moveTo(q[0], q[1]);
                for (int i = 1; i < n; i++) g.lineTo(q[i * 2], q[i * 2 + 1]);
                c.drawPath(g, shapeGuide);
            }
        }
        float r = dpx(9f);
        shapeDotEdge.setStrokeWidth(dpx(2f));
        float[] q = new float[2];
        for (int i = 0; i < n; i++) {
            q[0] = shapePts.get(i)[0];
            q[1] = shapePts.get(i)[1];
            view.mapPoints(q);
            shapeDot.setColor(i == shapeSel ? 0xFFE53935 : 0xFF1E6FE0);
            c.drawCircle(q[0], q[1], r, shapeDot);
            c.drawCircle(q[0], q[1], r, shapeDotEdge);
        }
    }

    /** Check: dibuja la forma en la capa elegida con el color y el grosor de abajo. */
    public void commitShape() {
        if (project == null) return;
        if (shapePts.size() < 2) {
            msg("Pon al menos 2 puntos");
            return;
        }
        boolean closed = shapeFill && shapePts.size() >= 3;
        float[] f = shapeFlat(closed);
        if (!beginLayerStroke()) return;
        strokeErase = false;
        painted = 0;
        strokeRect = null;
        beginBatch();
        try {
            if (closed) fillShape(f);
            float step = Math.max(0.5f, brushRadius * 0.25f);
            stampPaint(f[0], f[1]);
            for (int i = 2; i + 1 < f.length; i += 2) {
                float ax = f[i - 2], ay = f[i - 1], bx = f[i], by = f[i + 1];
                float d = (float) Math.hypot(bx - ax, by - ay);
                int m = Math.max(1, (int) Math.ceil(d / step));
                for (int k = 1; k <= m; k++) {
                    float t = k / (float) m;
                    stampPaint(ax + (bx - ax) * t, ay + (by - ay) * t);
                }
            }
        } finally {
            batchDepth = Math.max(0, batchDepth - 1);
            batchRect = null;
        }
        drawing = false;
        if (strokeRect != null) {
            recordEffectStrokeUndo(mode == MODE_CURVE ? "Curva" : "Polilinea");
            project.markDirty();
            wire = null;
            updateDisplayRegion(strokeRect);
            changed();
        }
        strokeRect = null;
        shapePts.clear();
        shapeSel = -1;
        invalidate();
    }

    /** Llenar: pinta por dentro la forma cerrada. */
    private void fillShape(float[] f) {
        if (f.length < 6) return;
        Path p = new Path();
        p.moveTo(f[0], f[1]);
        for (int i = 2; i + 1 < f.length; i += 2) p.lineTo(f[i], f[i + 1]);
        p.close();
        RectF b = new RectF();
        p.computeBounds(b, true);
        Rect r = new Rect((int) Math.floor(b.left) - 1, (int) Math.floor(b.top) - 1,
                (int) Math.ceil(b.right) + 1, (int) Math.ceil(b.bottom) + 1);
        clamp(r);
        if (r.width() <= 0 || r.height() <= 0) return;
        if (!captureEffectStrokeBackup(r)) return;
        Bitmap m;
        try {
            m = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ALPHA_8);
        } catch (OutOfMemoryError e) {
            msg("La forma es muy grande para rellenar");
            return;
        }
        Canvas cv = new Canvas(m);
        cv.translate(-r.left, -r.top);
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setStyle(Paint.Style.FILL);
        pp.setColor(0xFF000000);
        cv.drawPath(p, pp);
        int rb = m.getRowBytes();
        byte[] a = new byte[rb * r.height()];
        m.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(a));
        m.recycle();
        int[] px = strokeLayer.px();
        int ac = paintColor >>> 24;
        int w = project.w;
        for (int y = 0; y < r.height(); y++) {
            int off = (r.top + y) * w + r.left, lo = y * rb;
            for (int x = 0; x < r.width(); x++) {
                int av = a[lo + x] & 0xFF;
                if (av == 0) continue;
                int i = off + x;
                float fa = av / 255f * brushOpacity;
                if (selectionActive) fa *= (project.selection[i] & 0xFF) / 255f;
                int sa = (int) (fa * ac);
                if (sa <= (cov[i] & 0xFF)) continue;
                cov[i] = (byte) sa;
                px[i] = paintOver(strokeOriginalAt(i), sa);
            }
        }
        grow(r);
    }

    public void beginPreview() {
        if (project == null) return;
        previewBackup = project.selection.clone();
    }

    public void previewColorRange(final int color, final int tol, final boolean replace) {
        if (project == null || previewBackup == null || busy) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.globalColor(project.ref(), project.w, project.h, scratch, color, tol,
                        softness, colorMode);
            }
        }, new Runnable() {
            @Override
            public void run() {
                System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
                if (replace) project.clearSelection();
                if (lastFillRect != null) mergeScratch(lastFillRect);
                refreshOverlay(null);
                setBusy(false);
            }
        });
    }

    public void endPreview(boolean keep) {
        if (project == null || previewBackup == null) return;
        if (keep) {
            undo.setLabel("Gama de colores");
            undo.recordSelectionFromBackup(project.fullRect(), previewBackup);
        } else {
            System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
        }
        previewBackup = null;
        refreshOverlay(null);
        changed();
    }

    // ==================================================================
    // Separar partes con rayones
    // ==================================================================

    private void ensureMarkers() {
        int n = project.w * project.h;
        if (markers == null || markers.length != n) markers = new byte[n];
        if (markersOverlay == null && overlay != null) {
            markersOverlay = Bitmap.createBitmap(overlay.getWidth(), overlay.getHeight(), Bitmap.Config.ARGB_8888);
        }
    }

    private void stampMarker(float cx, float cy) {
        Rect r = disk(cx, cy);
        if (r == null) return;
        float r2 = brushRadius * brushRadius;
        byte v = (byte) (subtract ? 0 : markerLabel);
        for (int y = r.top; y < r.bottom; y++) {
            float dy = y + 0.5f - cy;
            for (int x = r.left; x < r.right; x++) {
                float dx = x + 0.5f - cx;
                if (dx * dx + dy * dy <= r2) markers[y * project.w + x] = v;
            }
        }
        paintLabelOverlay(markersOverlay, markers, r, true);
        invalidate();
    }

    private void paintLabelOverlay(Bitmap ov, byte[] data, Rect r, boolean labels) {
        if (ov == null || data == null) return;
        int ow = ov.getWidth(), oh = ov.getHeight();
        int x0 = Math.max(0, r.left / ovScale), y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1), y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int v = data[sy * project.w + sx] & 0xFF;
                if (labels) row[i] = v == 0 ? 0 : (0xB0000000 | (LABEL_COLORS[v - 1] & 0xFFFFFF));
                else row[i] = v == 0 ? 0 : (((v * 120) / 255) << 24) | 0x34C759;
            }
            ov.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    public void setMarkerLabel(int l) {
        markerLabel = Math.max(1, Math.min(LABEL_NAMES.length, l));
    }

    public int getMarkerLabel() {
        return markerLabel;
    }

    public void setGapClose(int g) {
        gapClose = Math.max(0, g);
    }

    public int getGapClose() {
        return gapClose;
    }

    public void clearMarkers() {
        if (markers != null) Arrays.fill(markers, (byte) 0);
        if (markersOverlay != null) markersOverlay.eraseColor(0);
        dropPreview();
        invalidate();
    }

    // ------------------------------------------------------------------
    // Vista previa en vivo de Separar / Quitar fondo: al soltar el dedo se
    // ve cada parte pintada de su color. Se calcula a la mitad del tamano.
    // ------------------------------------------------------------------

    private Bitmap sepPreview;
    private Rect sepPreviewRect;
    private int previewGen;
    private boolean previewBusy, previewAgain;
    private final Paint previewPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    private void dropPreview() {
        previewGen++;
        if (sepPreview != null && !sepPreview.isRecycled()) sepPreview.recycle();
        sepPreview = null;
        sepPreviewRect = null;
    }

    private boolean hasLabel(boolean bg) {
        if (markers == null) return false;
        for (byte b : markers) {
            int v = b & 0xFF;
            if (v == 0) continue;
            if (bg == (v == BG_LABEL)) return true;
        }
        return false;
    }

    /** Zona de trabajo: alrededor de las rayas, o todo si hay fondo marcado. */
    private Rect markerRegion(boolean whole) {
        int w = project.w, h = project.h;
        if (whole) return new Rect(0, 0, w, h);
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (markers[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        if (maxX < 0) return null;
        // Una raya pequena puede representar una pieza larga (brazo, cabello, pierna).
        // Damos bastante aire para que Watershed encuentre los limites reales en vez
        // de cortar la pieza alrededor de la marca.
        int spanX = Math.max(1, maxX - minX + 1), spanY = Math.max(1, maxY - minY + 1);
        int mx = Math.min(Math.max(128, w / 3), Math.max(Math.max(96, w / 6), spanX * 3));
        int my = Math.min(Math.max(128, h / 3), Math.max(Math.max(96, h / 6), spanY * 3));
        return new Rect(Math.max(0, minX - mx), Math.max(0, minY - my),
                Math.min(w, maxX + 1 + mx), Math.min(h, maxY + 1 + my));
    }

    private void schedulePreview() {
        if (project == null || markers == null) return;
        if (!hasLabel(false) && !hasLabel(true)) {
            dropPreview();
            invalidate();
            return;
        }
        if (previewBusy) {
            previewAgain = true;
            return;
        }
        final Rect cr = markerRegion(hasLabel(true));
        if (cr == null) return;
        final int W = project.w;
        final int cw = cr.width(), ch = cr.height();
        // paso: hasta ~1,5 millones de pixeles para que sea rapido
        int st = 1;
        while ((long) (cw / st) * (ch / st) > 1_500_000L) st++;
        final int step = st;
        final int sw = Math.max(1, cw / step), sh = Math.max(1, ch / step);
        final byte[] seeds = new byte[sw * sh];
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int v = 0;
                for (int dy = 0; dy < step && v == 0; dy++)
                    for (int dx = 0; dx < step; dx++) {
                        int sx = cr.left + x * step + dx, sy = cr.top + y * step + dy;
                        if (sx >= cr.right || sy >= cr.bottom) continue;
                        int m = markers[sy * W + sx] & 0xFF;
                        if (m != 0) {
                            v = m;
                            break;
                        }
                    }
                seeds[y * sw + x] = (byte) v;
            }
        }
        final boolean autoBorderBg = !hasLabel(true);
        if (autoBorderBg) {
            for (int x = 0; x < sw; x++) { seeds[x] = (byte) BG_LABEL; seeds[(sh - 1) * sw + x] = (byte) BG_LABEL; }
            for (int y = 0; y < sh; y++) { seeds[y * sw] = (byte) BG_LABEL; seeds[y * sw + sw - 1] = (byte) BG_LABEL; }
        }
        final int[] refAll = project.ref();
        final int gap = gapClose;
        final int gen = ++previewGen;
        final Bitmap[] out = new Bitmap[1];
        previewBusy = true;
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] lineAll = autoBarrier(refAll);
                int[] small = new int[sw * sh];
                byte[] lc = new byte[sw * sh];
                for (int y = 0; y < sh; y++) {
                    for (int x = 0; x < sw; x++) {
                        int sx = cr.left + x * step, sy = cr.top + y * step;
                        small[y * sw + x] = refAll[sy * W + sx];
                        byte l = 0;
                        for (int dy = 0; dy < step && l == 0; dy++)
                            for (int dx = 0; dx < step; dx++) {
                                int xx = sx + dx, yy = sy + dy;
                                if (xx >= cr.right || yy >= cr.bottom) continue;
                                if (lineAll[yy * W + xx] != 0) {
                                    l = (byte) 255;
                                    break;
                                }
                            }
                        lc[y * sw + x] = l;
                    }
                }
                byte[] lab = Watershed.run(small, sw, sh, seeds, Math.max(1, gap / step), BG_LABEL, lc);
                int[] col = new int[sw * sh];
                for (int i = 0; i < col.length; i++) {
                    int v = lab[i] & 0xFF;
                    if (v == 0) continue;
                    int c = LABEL_COLORS[Math.min(LABEL_COLORS.length, v) - 1];
                    int a = v == BG_LABEL ? 0x70 : 0x66;
                    if (v == BG_LABEL) c = 0xFF202020;
                    col[i] = (a << 24) | (c & 0x00FFFFFF);
                }
                Bitmap b = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
                b.setPixels(col, 0, sw, 0, 0, sw, sh);
                out[0] = b;
            }
        }, new Runnable() {
            @Override
            public void run() {
                previewBusy = false;
                if (out[0] != null) {
                    if (gen == previewGen && mode == MODE_MARKER) {
                        if (sepPreview != null && !sepPreview.isRecycled()) sepPreview.recycle();
                        sepPreview = out[0];
                        sepPreviewRect = cr;
                        invalidate();
                    } else {
                        out[0].recycle();
                    }
                }
                if (previewAgain) {
                    previewAgain = false;
                    schedulePreview();
                }
            }
        });
    }

    /**
     * Quitar fondo con toques, como en ibis: lo marcado con color se queda,
     * lo marcado en gris (fondo) se borra de la capa. Todo lo que no toca
     * ninguna raya de color cuenta como fondo.
     */
    public void removeBackgroundByMarks() {
        final Layer src = needLayer();
        if (src == null) return;
        if (!hasLabel(false)) {
            msg("Toca o raya el personaje con un color, y el fondo en gris");
            return;
        }
        final int W = project.w, H = project.h;
        final byte[] seeds = markers.clone();
        final int[] refAll = project.ref();
        final int gap = gapClose;
        final byte[] keep = new byte[W * H];
        setBusy(true);
        showHud("Quitando fondo...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] lineAll = autoBarrier(refAll);
                byte[] lab = Watershed.run(refAll, W, H, seeds, gap, BG_LABEL, lineAll);
                for (int i = 0; i < keep.length; i++) {
                    int v = lab[i] & 0xFF;
                    if (v != 0 && v != BG_LABEL) keep[i] = (byte) 255;
                }
                MaskOps.feather(keep, W, H, 1);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                undo.setLabel("Quitar fondo");
                undo.recordLayer(src, project.fullRect());
                int[] dp = src.px();
                for (int i = 0; i < dp.length; i++) {
                    int k = keep[i] & 0xFF;
                    if (k == 255) continue;
                    int c = dp[i];
                    int a = ((c >>> 24) * k) / 255;
                    dp[i] = (a << 24) | (c & 0x00FFFFFF);
                }
                clearMarkers();
                project.markDirty();
                refreshDisplay();
                changed();
                showHud("Fondo quitado");
            }
        });
    }

    private byte[] lastLabels;

    /** Cada parte rayada sale en su propia capa, cortada de la capa elegida. */
    public void separateParts() {
        final Layer src = needLayer();
        if (src == null) return;
        boolean any = false;
        if (markers != null) {
            for (byte b : markers) {
                int v = b & 0xFF;
                if (v != 0 && v != BG_LABEL) {
                    any = true;
                    break;
                }
            }
        }
        if (!any) {
            msg("Raya al menos una parte con color, y el fondo en gris");
            return;
        }
        // Region amplia alrededor de las marcas. Si el usuario marco fondo en gris
        // se usa todo el lienzo; si no, el borde del recorte se toma como fondo
        // automatico para que una marca pequena no se convierta en media imagen.
        final boolean hasBg = hasLabel(true);
        final Rect cr = markerRegion(hasBg);
        if (cr == null || cr.isEmpty()) {
            msg("No encontre una zona para separar");
            return;
        }
        int w = project.w, h = project.h;
        setBusy(true);
        showHud("Separando...");
        final int cw = cr.width(), ch = cr.height();
        final byte[] seeds = new byte[cw * ch];
        for (int y = 0; y < ch; y++) System.arraycopy(markers, (cr.top + y) * w + cr.left, seeds, y * cw, cw);
        if (!hasBg) {
            for (int x = 0; x < cw; x++) { seeds[x] = (byte) BG_LABEL; seeds[(ch - 1) * cw + x] = (byte) BG_LABEL; }
            for (int y = 0; y < ch; y++) { seeds[y * cw] = (byte) BG_LABEL; seeds[y * cw + cw - 1] = (byte) BG_LABEL; }
        }
        final int gap = gapClose;
        final ArrayList<Layer> made = new ArrayList<Layer>();
        final byte[] cutMask = new byte[cw * ch];
        final int[] refAll = project.ref();
        final int[] sp = src.px();
        Task.run(new Runnable() {
            @Override
            public void run() {
                int W = project.w;
                int[] crop = new int[cw * ch];
                for (int y = 0; y < ch; y++) System.arraycopy(refAll, (cr.top + y) * W + cr.left, crop, y * cw, cw);
                byte[] lineAll = autoBarrier(refAll);
                byte[] lc = new byte[cw * ch];
                for (int y = 0; y < ch; y++) System.arraycopy(lineAll, (cr.top + y) * W + cr.left, lc, y * cw, cw);
                byte[] out = Watershed.run(crop, cw, ch, seeds, gap, BG_LABEL, lc);
                crop = null;
                boolean[] used = new boolean[256];
                for (byte b : seeds) used[b & 0xFF] = true;
                int n = cw * ch;
                for (int lab = 1; lab < BG_LABEL; lab++) {
                    if (!used[lab]) continue;
                    byte[] m = new byte[n];
                    boolean hit = false;
                    for (int i = 0; i < n; i++) {
                        if ((out[i] & 0xFF) == lab) {
                            m[i] = (byte) 255;
                            hit = true;
                        }
                    }
                    if (!hit) continue;
                    MaskOps.feather(m, cw, ch, 1);
                    int[] px = new int[n];
                    for (int y = 0; y < ch; y++) {
                        for (int x = 0; x < cw; x++) {
                            int i = y * cw + x;
                            int mv = m[i] & 0xFF;
                            if (mv == 0) continue;
                            int c = sp[(cr.top + y) * W + cr.left + x];
                            int a = ((c >>> 24) * mv) / 255;
                            if (a != 0) px[i] = (a << 24) | (c & 0x00FFFFFF);
                            if (mv > (cutMask[i] & 0xFF)) cutMask[i] = (byte) mv;
                        }
                    }
                    String nm = lab - 1 < LABEL_NAMES.length ? LABEL_NAMES[lab - 1] : "parte_" + lab;
                    made.add(Layer.fromCrop(nm, cr.left, cr.top, cw, ch, project.w, project.h, px));
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (made.isEmpty()) {
                    msg("No salio ninguna parte. Raya dentro de cada parte y el fondo en gris");
                    return;
                }
                // las partes se sacan de la capa original, que sigue visible con el resto
                undo.setLabel("Separar");
                undo.begin();
                undo.recordStruct();
                undo.recordLayer(src, cr);
                undo.end();
                int[] dp = src.px();
                int W = project.w;
                for (int y = 0; y < ch; y++) {
                    for (int x = 0; x < cw; x++) {
                        int mv = cutMask[y * cw + x] & 0xFF;
                        if (mv == 0) continue;
                        int i = (cr.top + y) * W + cr.left + x;
                        int c = dp[i];
                        int a = ((c >>> 24) * (255 - mv)) / 255;
                        dp[i] = (a << 24) | (c & 0x00FFFFFF);
                    }
                }
                int at = project.layers.indexOf(src) + 1;
                for (Layer l : made) project.layers.add(at++, l);
                project.active = at - 1;
                if (markers != null) java.util.Arrays.fill(markers, (byte) 0);
                if (markersOverlay != null) markersOverlay.eraseColor(0);
                dropPreview();
                project.markDirty();
                layersChanged();
                showHud(made.size() + (made.size() == 1 ? " parte separada" : " partes separadas")
                        + ". El resto sigue en la capa original");
            }
        });
    }

    // ==================================================================
    // Rehacer lo que queda detras (dentro de la seleccion)
    // ==================================================================

    /** Lo que hay que rehacer es lo azul, un poco agrandado. */
    private byte[] holeMask() {
        if (project == null || !project.hasSelection()) return null;
        byte[] m = new byte[project.w * project.h];
        for (int i = 0; i < m.length; i++) m[i] = (byte) ((project.selection[i] & 0xFF) > 64 ? 255 : 0);
        MaskOps.dilate(m, project.w, project.h, 2);
        return m;
    }

    private boolean needHole() {
        if (project.hasSelection()) return true;
        msg("Primero marca en azul lo que hay que rehacer (con la varita o el pincel)");
        return false;
    }

    /** Tapar hueco rapido: lo azul toma el color de alrededor. */
    public void fillHoleInSelection() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final Rect b = project.selectionBounds();
        final Rect area = new Rect(b);
        area.inset(-27, -27);
        clamp(area);
        undo.setLabel("Tapar hueco");
        undo.recordLayer(t, area);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                HoleFill.fill(t.px(), project.w, project.h, project.selection, 3);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                pixelsChanged(area);
                showHud("Hueco tapado");
            }
        });
    }

    private void runZoneFill(final int x, final int y) {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        undo.setLabel("Zona");
        undo.recordLayer(t, hb);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = ZoneFill.fill(t.px(), project.w, project.h, hole, repairLines, x, y);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect == null) msg("Toca dentro de lo azul");
                else pixelsChanged(lastFillRect);
            }
        });
    }

    private void runToneFill(final int x, final int y) {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        final Rect hb = HoleFill.bounds(hole, project.w, project.h);
        if (hb == null) return;
        undo.setLabel("Trama");
        undo.recordLayer(t, hb);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = ToneFill.fill(t.px(), project.w, project.h, hole, x, y);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect == null) msg("Toca afuera de lo azul, sobre la trama que quieres seguir");
                else {
                    pixelsChanged(lastFillRect);
                    showHud("Trama continuada");
                }
            }
        });
    }

    private void ensureRepairLines() {
        int n = project.w * project.h;
        if (repairLines == null || repairLines.length != n) repairLines = new byte[n];
    }

    private void finishLine() {
        Layer t = needLayer();
        if (t == null || linePts.size() < 2) {
            linePts.clear();
            invalidate();
            return;
        }
        byte[] hole = holeMask();
        float[] a = linePts.get(0), b = linePts.get(linePts.size() - 1);
        float[] a2 = linePts.get(Math.min(linePts.size() - 1, 3)), b2 = linePts.get(Math.max(0, linePts.size() - 4));
        LineRepair.End ea = LineRepair.snap(t.px(), project.w, project.h, hole, a[0], a[1], a2[0] - a[0], a2[1] - a[1], 28);
        LineRepair.End eb = LineRepair.snap(t.px(), project.w, project.h, hole, b[0], b[1], b[0] - b2[0], b[1] - b2[1], 28);
        float[] xy = new float[linePts.size() * 2];
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -1, maxY = -1;
        for (int i = 0; i < linePts.size(); i++) {
            float[] q = linePts.get(i);
            xy[i * 2] = q[0];
            xy[i * 2 + 1] = q[1];
            minX = Math.min(minX, q[0]);
            minY = Math.min(minY, q[1]);
            maxX = Math.max(maxX, q[0]);
            maxY = Math.max(maxY, q[1]);
        }
        Rect guard = new Rect((int) Math.min(minX, Math.min(ea.x, eb.x)) - 40, (int) Math.min(minY, Math.min(ea.y, eb.y)) - 40,
                (int) Math.max(maxX, Math.max(ea.x, eb.x)) + 40, (int) Math.max(maxY, Math.max(ea.y, eb.y)) + 40);
        clamp(guard);
        linePts.clear();
        ensureRepairLines();
        undo.setLabel("Linea");
        undo.recordLayer(t, guard);
        Rect r = LineRepair.drawCurve(t.px(), project.w, project.h, repairLines, ea, eb, xy);
        if (r != null) pixelsChanged(r);
        showHud(ea.snapped && eb.snapped ? "Linea unida" : "Linea dibujada");
    }

    public void autoJoinLines() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        ensureRepairLines();
        final Rect guard = HoleFill.bounds(hole, project.w, project.h);
        if (guard == null) return;
        guard.inset(-12, -12);
        clamp(guard);
        undo.setLabel("Unir lineas");
        undo.recordLayer(t, guard);
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = LineRepair.autoJoin(t.px(), project.w, project.h, hole, repairLines);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    pixelsChanged(lastFillRect);
                    showHud("Lineas unidas");
                } else {
                    showHud("No encontre lineas para unir: trazalas con el dedo");
                }
            }
        });
    }

    private void ensurePatchSource() {
        int n = project.w * project.h;
        if (patchSource == null || patchSource.length != n) patchSource = new byte[n];
        if (patchOverlay == null && overlay != null) {
            patchOverlay = Bitmap.createBitmap(overlay.getWidth(), overlay.getHeight(), Bitmap.Config.ARGB_8888);
        }
    }

    private void stampPatchSource(float cx, float cy) {
        Rect r = MaskOps.stamp(patchSource, project.w, project.h, cx, cy, brushRadius, 1f, subtract, 1f);
        if (r == null) return;
        paintLabelOverlay(patchOverlay, patchSource, r, false);
        invalidate();
    }

    public void clearPatchSource() {
        if (patchSource != null) Arrays.fill(patchSource, (byte) 0);
        if (patchOverlay != null) patchOverlay.eraseColor(0);
        invalidate();
    }

    public void runPatchFill() {
        final Layer t = needLayer();
        if (t == null || !needHole()) return;
        final byte[] hole = holeMask();
        boolean anySrc = false;
        if (patchSource != null) for (byte b : patchSource) if (b != 0) {
            anySrc = true;
            break;
        }
        final byte[] src = anySrc ? patchSource : null;
        Rect guard = HoleFill.bounds(hole, project.w, project.h);
        if (guard == null) return;
        guard.inset(-50, -50);
        if (src != null) {
            Rect sb = HoleFill.bounds(src, project.w, project.h);
            if (sb != null) guard.union(sb);
        }
        clamp(guard);
        undo.setLabel("Copiar zona");
        undo.recordLayer(t, guard);
        setBusy(true);
        showHud("Rellenando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                lastFillRect = PatchFill.fill(t.px(), project.w, project.h, hole, src);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                if (lastFillRect != null) {
                    pixelsChanged(lastFillRect);
                    showHud("Relleno listo");
                } else {
                    msg("Pinta en verde una zona mas grande de donde copiar");
                }
            }
        });
    }



    // ==================================================================
    // Transformar: previsualizacion ligera y aplicacion al confirmar.
    // ==================================================================

    private boolean onTransformTouch(MotionEvent e) {
        if (project == null || busy || transformPreparing) return true;
        int a = e.getActionMasked(), pc = e.getPointerCount();
        if (!transformActive && a == MotionEvent.ACTION_DOWN) {
            if (!startTransformSession()) return true;
        }
        if (!transformActive) return true;

        // Perspectiva, Malla y Puntos: DOS dedos pertenecen siempre a la vista,
        // nunca a la deformacion. Zoom con ScaleGestureDetector + pan por el centro.
        if (transformType != 0 && pc >= 2) {
            transformNode = -1;
            // La seleccion de un anclaje persiste: asi el tacho funciona despues
            // de tocar el punto y luego levantar el dedo.
            scaleDetector.onTouchEvent(e);
            float mx = (e.getX(0) + e.getX(1)) * .5f;
            float my = (e.getY(0) + e.getY(1)) * .5f;
            if (a == MotionEvent.ACTION_POINTER_UP) {
                transformNavMidValid = false;
            } else if (a == MotionEvent.ACTION_POINTER_DOWN || !transformNavMidValid) {
                transformNavMidX = mx; transformNavMidY = my; transformNavMidValid = true;
            } else if (a == MotionEvent.ACTION_MOVE) {
                view.postTranslate(mx - transformNavMidX, my - transformNavMidY);
                transformNavMidX = mx; transformNavMidY = my;
            }
            invalidate();
            return true;
        }
        if (a == MotionEvent.ACTION_POINTER_UP && transformType != 0) {
            scaleDetector.onTouchEvent(e);
            transformNavMidValid = false;
            transformNode = -1;
            invalidate();
            return true;
        }

        if (a == MotionEvent.ACTION_DOWN) {
            transformNavMidValid = false;
            imagePoint(e.getX(), e.getY());
            transformDownX = point[0]; transformDownY = point[1];
            transformStartTx = transformTx; transformStartTy = transformTy;
            transformNode = -1;
            transformAnchorNode = -1;

            if (transformType == 3) {
                int found = findTransformAnchor(transformDownX, transformDownY);
                if (found >= 0) {
                    transformAnchorNode = found;
                    showHud(transformAnchors.get(found)[4] < .5f ? "Punto fijo seleccionado" : "Arrastra el punto naranja");
                } else {
                    addTransformAnchor(transformDownX, transformDownY);
                }
                invalidate();
                return true;
            }

            if (transformType != 0 && transformVerts != null) {
                float lim = 30f / Math.max(.05f, currentScale());
                float best = lim * lim;
                for (int i = 0; i < transformVerts.length / 2; i++) {
                    float dx = transformVerts[i * 2] - transformDownX;
                    float dy = transformVerts[i * 2 + 1] - transformDownY;
                    float dd = dx * dx + dy * dy;
                    if (dd <= best) { best = dd; transformNode = i; }
                }
                transformVertsStart = transformVerts.clone();
            }
            invalidate();
            return true;
        }

        if (a == MotionEvent.ACTION_POINTER_DOWN && transformType == 0 && pc >= 2) {
            screenToImage(e.getX(0), e.getY(0), transformPoint0);
            screenToImage(e.getX(1), e.getY(1), transformPoint1);
            transformGestureDist = Math.max(.001f, (float) Math.hypot(transformPoint1[0] - transformPoint0[0], transformPoint1[1] - transformPoint0[1]));
            transformGestureAngle = (float) Math.toDegrees(Math.atan2(transformPoint1[1] - transformPoint0[1], transformPoint1[0] - transformPoint0[0]));
            transformGestureMidX = (transformPoint0[0] + transformPoint1[0]) * .5f;
            transformGestureMidY = (transformPoint0[1] + transformPoint1[1]) * .5f;
            transformStartScale = transformScale;
            transformStartRotation = transformRotation;
            transformGestureStartTx = transformTx;
            transformGestureStartTy = transformTy;
            return true;
        }

        if (a == MotionEvent.ACTION_MOVE) {
            if (transformType == 0 && pc >= 2) {
                screenToImage(e.getX(0), e.getY(0), transformPoint0);
                screenToImage(e.getX(1), e.getY(1), transformPoint1);
                float dist = Math.max(.001f, (float) Math.hypot(transformPoint1[0] - transformPoint0[0], transformPoint1[1] - transformPoint0[1]));
                float ang = (float) Math.toDegrees(Math.atan2(transformPoint1[1] - transformPoint0[1], transformPoint1[0] - transformPoint0[0]));
                float midX = (transformPoint0[0] + transformPoint1[0]) * .5f, midY = (transformPoint0[1] + transformPoint1[1]) * .5f;
                transformScale = Math.max(.05f, Math.min(12f, transformStartScale * dist / transformGestureDist));
                float da = ang - transformGestureAngle;
                while (da > 180f) da -= 360f;
                while (da < -180f) da += 360f;
                transformRotation = transformStartRotation + da;
                transformTx = transformGestureStartTx + (midX - transformGestureMidX);
                transformTy = transformGestureStartTy + (midY - transformGestureMidY);
                invalidate();
                return true;
            }

            imagePoint(e.getX(), e.getY());
            float x = point[0], y = point[1];
            if (transformType == 0) {
                transformTx = transformStartTx + (x - transformDownX);
                transformTy = transformStartTy + (y - transformDownY);
            } else if (transformType == 3) {
                if (transformAnchorNode >= 0 && transformAnchorNode < transformAnchors.size()) {
                    float[] an = transformAnchors.get(transformAnchorNode);
                    if (an[4] >= .5f) {
                        an[2] = x; an[3] = y;
                        transformRenderDirty = true;
                    }
                }
            } else if (transformVerts != null) {
                if (transformNode >= 0) {
                    float nx = x, ny = y;
                    if (transformType == 2) {
                        int cols = transformMeshX + 1;
                        int gx = transformNode % cols, gy = transformNode / cols;
                        float eps = 1.25f / Math.max(.05f, currentScale());
                        if (gx > 0) nx = Math.max(nx, transformVerts[(transformNode - 1) * 2] + eps);
                        if (gx < transformMeshX) nx = Math.min(nx, transformVerts[(transformNode + 1) * 2] - eps);
                        if (gy > 0) ny = Math.max(ny, transformVerts[(transformNode - cols) * 2 + 1] + eps);
                        if (gy < transformMeshY) ny = Math.min(ny, transformVerts[(transformNode + cols) * 2 + 1] - eps);
                    }
                    transformVerts[transformNode * 2] = nx;
                    transformVerts[transformNode * 2 + 1] = ny;
                    transformRenderDirty = true;
                }
            }
            invalidate();
            return true;
        }

        if (a == MotionEvent.ACTION_POINTER_UP) {
            transformNode = -1;
            transformStartTx = transformTx; transformStartTy = transformTy;
            int up = e.getActionIndex();
            int keep = up == 0 && pc > 1 ? 1 : 0;
            if (keep < pc) {
                screenToImage(e.getX(keep), e.getY(keep), transformPoint0);
                transformDownX = transformPoint0[0]; transformDownY = transformPoint0[1];
            }
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            transformNode = -1;
            if (transformType != 3) transformAnchorNode = -1;
            transformVertsStart = null;
            transformNavMidValid = false;
            invalidate();
            return true;
        }
        return true;
    }

    private void screenToImage(float sx, float sy, float[] out) {
        imagePoint(sx, sy);
        out[0] = point[0];
        out[1] = point[1];
    }

    private int[] copyLayerRect(Layer layer, Rect r) {
        int rw = r.width(), rh = r.height();
        int[] out = new int[rw * rh];
        int[] src = layer.px();
        for (int y = 0; y < rh; y++)
            System.arraycopy(src, (r.top + y) * project.w + r.left, out, y * rw, rw);
        return out;
    }

    private byte[] copySelectionRect(Rect r) {
        int rw = r.width(), rh = r.height();
        byte[] out = new byte[rw * rh];
        for (int y = 0; y < rh; y++)
            System.arraycopy(project.selection, (r.top + y) * project.w + r.left, out, y * rw, rw);
        return out;
    }

    private void restoreLayerRect(Layer layer, Rect r, int[] src) {
        if (layer == null || r == null || src == null || src.length != r.width() * r.height()) return;
        int rw = r.width(), rh = r.height();
        int[] dst = layer.px();
        for (int y = 0; y < rh; y++)
            System.arraycopy(src, y * rw, dst, (r.top + y) * project.w + r.left, rw);
    }

    private void restoreSelectionRect(Rect r, byte[] src) {
        if (r == null || src == null || src.length != r.width() * r.height()) return;
        int rw = r.width(), rh = r.height();
        for (int y = 0; y < rh; y++)
            System.arraycopy(src, y * rw, project.selection, (r.top + y) * project.w + r.left, rw);
    }

    /** Devuelve exactamente el original que se aparto al iniciar Transformar. */
    private void restoreTransformSourceToProject() {
        if (transformLayer == null || transformSrcRect == null) return;
        if (transformBackup != null) {
            restoreLayerRect(transformLayer, transformSrcRect, transformBackup);
        } else if (transformBitmap != null && !transformBitmap.isRecycled()) {
            int[] lp = transformLayer.px();
            // getPixels puede escribir directo en el arreglo grande: no crea otra copia.
            transformBitmap.getPixels(lp, transformSrcRect.top * project.w + transformSrcRect.left,
                    project.w, 0, 0, transformSrcRect.width(), transformSrcRect.height());
        }
        if (transformSelectionBackup != null) restoreSelectionRect(transformSrcRect, transformSelectionBackup);
    }

    /** Libera buffers reutilizables que no hacen falta mientras se transforma. */
    private void releaseTransientMemoryForTransform() {
        pxBackup = null;
        cov = null;
        scratch = null;
        selBackup = null;
        gapBarrier = null;
        gradient = null;
        effectTmp = null;
        resetLiquifySession();
        bgSeen = null;
        bgStack = null;
        dilMask = null;
        dilBuf = null;
        dilRect = null;
        try { project.packInactive(); } catch (OutOfMemoryError ignored) {}
    }

    private boolean startTransformSession() {
        if (transformApplying) return false;
        Layer t = needLayer();
        if (t == null) return false;
        Rect r = project.hasSelection() ? project.selectionBounds() : t.bounds(project.w, project.h);
        if (r == null || r.width() <= 0 || r.height() <= 0) {
            msg(project.hasSelection() ? "La seleccion esta vacia" : "La capa no tiene dibujo para transformar");
            return false;
        }

        releaseTransientMemoryForTransform();
        transformLayer = t;
        transformSrcRect = new Rect(r);
        boolean sel = project.hasSelection();
        try {
            int cw = r.width(), ch = r.height();
            int[] lp = t.px();

            // Solo guardamos el recorte original cuando hay seleccion. Sin seleccion,
            // el propio Bitmap de Transformar ES el respaldo original y evitamos otra
            // copia completa de la imagen.
            transformBackup = sel ? copyLayerRect(t, r) : null;
            transformSelectionBackup = sel ? copySelectionRect(r) : null;

            // Este Bitmap SI se dibuja con Canvas: debe quedar premultiplicado.
            // Usar Layer.newBitmap() aqui lo marcaba como no premultiplicado y en
            // algunos Android Canvas puede lanzar RuntimeException al dibujarlo.
            transformBitmap = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888);
            if (sel) {
                transformMaskBitmap = Bitmap.createBitmap(cw, ch, Bitmap.Config.ALPHA_8);
            } else {
                transformMaskBitmap = null;
            }

            // Construimos primero los Bitmaps. La capa real todavia no se toca: si
            // una asignacion falla, la obra permanece intacta.
            if (!sel) {
                // Copia nativa directa: es mucho mas rapida que recorrer millones
                // de pixeles Java uno por uno y reduce el tiempo bloqueado al tocar.
                transformBitmap.setPixels(lp, r.top * project.w + r.left, project.w,
                        0, 0, cw, ch);
            } else {
                int[] row = new int[cw];
                int[] maskRow = new int[cw];
                for (int y = 0; y < ch; y++) {
                    int src = (r.top + y) * project.w + r.left;
                    int bo = y * cw;
                    for (int x = 0; x < cw; x++) {
                        int c = lp[src + x];
                        int m = transformSelectionBackup[bo + x] & 255;
                        int a = (c >>> 24) * m / 255;
                        row[x] = (c & 0x00FFFFFF) | (a << 24);
                        maskRow[x] = m << 24;
                    }
                    transformBitmap.setPixels(row, 0, cw, 0, y, cw, 1);
                    transformMaskBitmap.setPixels(maskRow, 0, cw, 0, y, cw, 1);
                }
            }

            // Ahora si: apartamos del lienzo SOLO la parte transformada. El respaldo
            // es regional, no project.w*project.h.
            for (int y = 0; y < ch; y++) {
                int dst = (r.top + y) * project.w + r.left;
                int bo = y * cw;
                if (!sel) {
                    Arrays.fill(lp, dst, dst + cw, 0);
                } else {
                    for (int x = 0; x < cw; x++) {
                        int c = transformBackup[bo + x];
                        int m = transformSelectionBackup[bo + x] & 255;
                        int remainA = (c >>> 24) * (255 - m) / 255;
                        lp[dst + x] = (c & 0x00FFFFFF) | (remainA << 24);
                        project.selection[dst + x] = 0;
                    }
                }
            }

            transformTx = transformTy = transformRotation = 0f;
            transformScale = 1f;
            initTransformVerts();
            transformActive = true;
            transformPreparing = false;
            updateDisplayRegion(r);
            if (sel) paintOverlay(r);
            showHud(transformType == 0 ? "Arrastra. Dos dedos: escala y gira" :
                    transformType == 1 ? "Perspectiva: 1 dedo esquinas · 2 dedos mover/zoom" :
                    transformType == 2 ? "Malla: 1 dedo puntos · 2 dedos mover/zoom" :
                    "Puntos: azul fija · naranja mueve · 2 dedos mover/zoom");
            invalidate();
            return true;
        } catch (Throwable e) {
            // Cualquier fallo de Bitmap/Canvas/memoria debe cancelar la sesion, no
            // cerrar el editor ni mandar al usuario de vuelta a la galeria.
            try { restoreTransformSourceToProject(); } catch (Throwable ignored) {}
            transformPreparing = false;
            clearTransformState(true);
            try { project.packInactive(); } catch (Throwable ignored) {}
            if (undo != null) undo.trimTo(0.55f);
            if (e instanceof OutOfMemoryError) System.gc();
            refreshDisplay();
            refreshOverlay(null);
            msg(e instanceof OutOfMemoryError
                    ? "Transformar libero memoria y cancelo la operacion sin perder la imagen. Prueba otra vez."
                    : "Transformar encontro un fallo y se cancelo sin cerrar el editor ni perder la imagen.");
            return false;
        }
    }

    private void initTransformVerts() {
        if (transformSrcRect == null) { transformVerts = null; return; }
        if (transformType == 0 || transformType == 3) { transformVerts = null; transformRenderDirty = true; return; }
        int cols = transformType == 1 ? 1 : transformMeshX;
        int rows = transformType == 1 ? 1 : transformMeshY;
        transformVerts = new float[(cols + 1) * (rows + 1) * 2];
        int k = 0;
        for (int y = 0; y <= rows; y++) {
            float py = transformSrcRect.top + transformSrcRect.height() * (y / (float) rows);
            for (int x = 0; x <= cols; x++) {
                float px = transformSrcRect.left + transformSrcRect.width() * (x / (float) cols);
                transformVerts[k++] = px;
                transformVerts[k++] = py;
            }
        }
        transformRenderDirty = true;
    }

    private void drawTransformPreparing(Canvas c) {
        if (transformSrcRect == null || transformType != 2) return;
        int save = c.save();
        c.concat(view);
        if (transformVerts == null) initTransformVerts();
        if (transformVerts != null) drawMeshGrid(c, transformMeshX, transformMeshY);
        c.restoreToCount(save);
    }

    private float controlDispX(int gx, int gy) {
        gx = Math.max(0, Math.min(transformMeshX, gx)); gy = Math.max(0, Math.min(transformMeshY, gy));
        int i = (gy * (transformMeshX + 1) + gx) * 2;
        float ox = transformSrcRect.left + transformSrcRect.width() * (gx / (float) transformMeshX);
        return transformVerts[i] - ox;
    }

    private float controlDispY(int gx, int gy) {
        gx = Math.max(0, Math.min(transformMeshX, gx)); gy = Math.max(0, Math.min(transformMeshY, gy));
        int i = (gy * (transformMeshX + 1) + gx) * 2 + 1;
        float oy = transformSrcRect.top + transformSrcRect.height() * (gy / (float) transformMeshY);
        return transformVerts[i] - oy;
    }

    private static float catmull(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t, t3 = t2 * t;
        return .5f * ((2f * p1) + (-p0 + p2) * t +
                (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 +
                (-p0 + 3f * p1 - 3f * p2 + p3) * t3);
    }

    private void sampleTransformDisp(float u, float v, float[] out) {
        float x = Math.max(0f, Math.min(transformMeshX, u * transformMeshX));
        float y = Math.max(0f, Math.min(transformMeshY, v * transformMeshY));
        int ix = Math.min(transformMeshX - 1, (int)Math.floor(x));
        int iy = Math.min(transformMeshY - 1, (int)Math.floor(y));
        float fx = x - ix, fy = y - iy;

        float d00x = controlDispX(ix, iy), d10x = controlDispX(ix + 1, iy);
        float d01x = controlDispX(ix, iy + 1), d11x = controlDispX(ix + 1, iy + 1);
        float d00y = controlDispY(ix, iy), d10y = controlDispY(ix + 1, iy);
        float d01y = controlDispY(ix, iy + 1), d11y = controlDispY(ix + 1, iy + 1);
        float bilX = (d00x + (d10x - d00x) * fx) * (1f - fy) + (d01x + (d11x - d01x) * fx) * fy;
        float bilY = (d00y + (d10y - d00y) * fx) * (1f - fy) + (d01y + (d11y - d01y) * fx) * fy;

        float[] rx = transformCatX, ry = transformCatY;
        for (int yy = -1; yy <= 2; yy++) {
            float p0x = controlDispX(ix - 1, iy + yy), p1x = controlDispX(ix, iy + yy);
            float p2x = controlDispX(ix + 1, iy + yy), p3x = controlDispX(ix + 2, iy + yy);
            float p0y = controlDispY(ix - 1, iy + yy), p1y = controlDispY(ix, iy + yy);
            float p2y = controlDispY(ix + 1, iy + yy), p3y = controlDispY(ix + 2, iy + yy);
            rx[yy + 1] = catmull(p0x, p1x, p2x, p3x, fx);
            ry[yy + 1] = catmull(p0y, p1y, p2y, p3y, fx);
        }
        float bicX = catmull(rx[0], rx[1], rx[2], rx[3], fy);
        float bicY = catmull(ry[0], ry[1], ry[2], ry[3], fy);
        float sm = Math.max(0f, Math.min(1f, transformMeshSmoothness));
        float dx = bilX + (bicX - bilX) * sm;
        float dy = bilY + (bicY - bilY) * sm;
        // Catmull-Rom puede sobrepasar. Limitar respecto a los cuatro controles
        // vecinos evita celdas que se disparan y dobleces violentos.
        float minX = Math.min(Math.min(d00x, d10x), Math.min(d01x, d11x));
        float maxX = Math.max(Math.max(d00x, d10x), Math.max(d01x, d11x));
        float minY = Math.min(Math.min(d00y, d10y), Math.min(d01y, d11y));
        float maxY = Math.max(Math.max(d00y, d10y), Math.max(d01y, d11y));
        float pad = Math.max(2f, Math.max(transformSrcRect.width(), transformSrcRect.height()) * .01f * sm);
        out[0] = Math.max(minX - pad, Math.min(maxX + pad, dx));
        out[1] = Math.max(minY - pad, Math.min(maxY + pad, dy));
    }

    private final float[] transformDispSample = new float[2];
    private final float[] transformCatX = new float[4];
    private final float[] transformCatY = new float[4];

    /** Control visible poco denso + malla interna densa y suave. */
    private void ensureTransformRenderVerts() {
        if ((transformType != 2 && transformType != 3) || transformSrcRect == null) return;
        if (transformType == 2 && transformVerts == null) return;
        // Puntos usa ahora el mismo principio que Malla: una cuadrícula moderada
        // dibujada directamente desde el bitmap original. La versión anterior
        // generaba hasta 48x48 nodos y recalculaba pesos en cada movimiento, lo
        // que se sentía tosco y podía verse demasiado filtrado.
        int rx = transformType == 3 ? Math.min(20, Math.max(8, transformMeshX * 2))
                : Math.min(48, Math.max(18, transformMeshX * 6));
        int ry = transformType == 3 ? Math.min(20, Math.max(8, transformMeshY * 2))
                : Math.min(48, Math.max(18, transformMeshY * 6));
        int need = (rx + 1) * (ry + 1) * 2;
        if (!transformRenderDirty && transformRenderVerts != null && transformRenderVerts.length == need &&
                transformRenderMeshX == rx && transformRenderMeshY == ry) return;
        if (transformRenderVerts == null || transformRenderVerts.length != need) transformRenderVerts = new float[need];
        transformRenderMeshX = rx; transformRenderMeshY = ry;
        int k = 0;
        for (int y = 0; y <= ry; y++) {
            float v = y / (float)ry;
            float oy = transformSrcRect.top + transformSrcRect.height() * v;
            for (int x = 0; x <= rx; x++) {
                float u = x / (float)rx;
                float ox = transformSrcRect.left + transformSrcRect.width() * u;
                if (transformType == 3) sampleAnchorDisp(ox, oy, transformDispSample);
                else sampleTransformDisp(u, v, transformDispSample);
                transformRenderVerts[k++] = ox + transformDispSample[0];
                transformRenderVerts[k++] = oy + transformDispSample[1];
            }
        }
        transformRenderDirty = false;
    }

    private void sampleAnchorDisp(float x, float y, float[] out) {
        out[0] = out[1] = 0f;
        if (transformAnchors.isEmpty()) return;
        float numX = 0f, numY = 0f, den = 0f;
        float radius = Math.max(24f, transformAnchorRadius);
        float r2 = radius * radius;
        for (int i = 0; i < transformAnchors.size(); i++) {
            float[] a = transformAnchors.get(i);
            float dx = x - a[0], dy = y - a[1];
            float d2 = dx * dx + dy * dy;
            if (d2 > r2 * 4f) continue;
            float dist = (float)Math.sqrt(Math.max(.0001f, d2));
            float q = Math.max(0f, 1f - dist / (radius * 2f));
            float w = (q * q + .0005f) / (d2 + 36f);
            if (a[4] < .5f) w *= 5.5f; // fijo: fuerte peso con desplazamiento cero
            float ddx = a[4] >= .5f ? (a[2] - a[0]) * transformAnchorStrength : 0f;
            float ddy = a[4] >= .5f ? (a[3] - a[1]) * transformAnchorStrength : 0f;
            numX += ddx * w; numY += ddy * w; den += w;
        }
        if (den > .000001f) { out[0] = numX / den; out[1] = numY / den; }
    }

    private void drawTransformAnchors(Canvas c) {
        if (transformSrcRect == null) return;
        float sc = Math.max(.05f, currentScale());
        float rr = 7f / sc;
        float rrSel = 10f / sc;
        transformAnchorEdgePaint.setStrokeWidth(2f / sc);
        for (int i = 0; i < transformAnchors.size(); i++) {
            float[] a = transformAnchors.get(i);
            Paint fill = a[4] < .5f ? transformAnchorFixedPaint : transformAnchorMovePaint;
            c.drawCircle(a[2], a[3], i == transformAnchorNode ? rrSel : rr, fill);
            c.drawCircle(a[2], a[3], i == transformAnchorNode ? rrSel : rr, transformAnchorEdgePaint);
            if (i == transformAnchorNode && a[4] >= .5f
                    && (Math.abs(a[2]-a[0]) + Math.abs(a[3]-a[1]) > .1f)) {
                c.drawLine(a[0], a[1], a[2], a[3], transformAnchorEdgePaint);
            }
        }
    }

    private int findTransformAnchor(float x, float y) {
        float lim = 28f / Math.max(.05f, currentScale());
        float best = lim * lim; int idx = -1;
        for (int i = 0; i < transformAnchors.size(); i++) {
            float[] a = transformAnchors.get(i);
            float dx = a[2] - x, dy = a[3] - y, d = dx*dx + dy*dy;
            if (d <= best) { best = d; idx = i; }
        }
        return idx;
    }

    private void addTransformAnchor(float x, float y) {
        if (transformSrcRect == null || !transformSrcRect.contains((int)x, (int)y)) {
            showHud("Pon el punto dentro de la imagen"); return;
        }
        transformAnchors.add(new float[]{x, y, x, y, transformAnchorAddMode});
        transformAnchorNode = transformAnchors.size() - 1;
        transformRenderDirty = true;
        showHud(transformAnchorAddMode == 0 ? "Punto fijo azul" : "Punto movil naranja");
    }

    public void setTransformAnchorAddMode(int mode) {
        transformAnchorAddMode = mode <= 0 ? 0 : 1;
        showHud(transformAnchorAddMode == 0 ? "Toca para poner punto fijo" : "Toca para poner punto movil");
        invalidate();
    }
    public int getTransformAnchorAddMode() { return transformAnchorAddMode; }
    public int getTransformAnchorCount() { return transformAnchors.size(); }
    public void deleteSelectedTransformAnchor() {
        if (transformAnchorNode >= 0 && transformAnchorNode < transformAnchors.size()) {
            transformAnchors.remove(transformAnchorNode); transformAnchorNode = -1; transformRenderDirty = true; invalidate();
            showHud("Punto eliminado");
        } else showHud("Toca un punto primero");
    }
    public void clearTransformAnchors() { transformAnchors.clear(); transformAnchorNode = -1; transformRenderDirty = true; invalidate(); showHud("Puntos borrados"); }
    public void setTransformAnchorRadius(float v) { transformAnchorRadius = Math.max(40f, Math.min(900f, v)); transformRenderDirty = true; invalidate(); }
    public float getTransformAnchorRadius() { return transformAnchorRadius; }

    private void drawTransformPreview(Canvas c) {
        if (!transformActive || transformApplying || transformBitmap == null || transformBitmap.isRecycled()) return;
        int save = c.save();
        try {
            c.concat(view);
            if (transformType == 0) {
                drawAffine(c, transformBitmap);
                drawAffineGrid(c);
            } else if (transformType == 1 && transformVerts != null) {
                drawPerspective(c, transformBitmap);
                drawMeshGrid(c, 1, 1);
            } else if (transformType == 2 && transformVerts != null) {
                ensureTransformRenderVerts();
                if (transformRenderVerts != null)
                    c.drawBitmapMesh(transformBitmap, transformRenderMeshX, transformRenderMeshY, transformRenderVerts, 0, null, 0, transformPaint);
                drawMeshGrid(c, transformMeshX, transformMeshY);
            } else if (transformType == 3) {
                ensureTransformRenderVerts();
                if (transformRenderVerts != null)
                    c.drawBitmapMesh(transformBitmap, transformRenderMeshX, transformRenderMeshY, transformRenderVerts, 0, null, 0, transformPaint);
                drawTransformAnchors(c);
            }
        } catch (Throwable err) {
            // Evita que una excepcion grafica de un fabricante cierre MainActivity.
            // La restauracion se hace despues del onDraw para no mutar el lienzo a
            // mitad de una llamada nativa de Canvas.
            final Rect dirty = transformSrcRect == null ? null : new Rect(transformSrcRect);
            post(new Runnable() {
                @Override public void run() {
                    if (!transformActive || transformApplying) return;
                    try { restoreTransformSourceToProject(); } catch (Throwable ignored) {}
                    clearTransformState(true);
                    if (dirty != null) updateDisplayRegion(dirty); else refreshDisplay();
                    refreshOverlay(null);
                    msg("La previsualizacion de Transformar fallo y se cancelo de forma segura.");
                    invalidate();
                }
            });
        } finally {
            c.restoreToCount(save);
        }
    }

    private void drawAffine(Canvas c, Bitmap b) {
        float cx = transformSrcRect.exactCenterX() + transformTx;
        float cy = transformSrcRect.exactCenterY() + transformTy;
        c.save();
        c.translate(cx, cy);
        c.rotate(transformRotation);
        c.scale(transformScale, transformScale);
        c.translate(-b.getWidth() * .5f, -b.getHeight() * .5f);
        c.drawBitmap(b, 0, 0, transformPaint);
        c.restore();
    }

    private void drawPerspective(Canvas c, Bitmap b) {
        if (transformVerts == null || transformVerts.length < 8) return;
        transformPerspectiveSrc[0] = 0f; transformPerspectiveSrc[1] = 0f;
        transformPerspectiveSrc[2] = b.getWidth(); transformPerspectiveSrc[3] = 0f;
        transformPerspectiveSrc[4] = 0f; transformPerspectiveSrc[5] = b.getHeight();
        transformPerspectiveSrc[6] = b.getWidth(); transformPerspectiveSrc[7] = b.getHeight();
        transformMatrix.reset();
        if (transformMatrix.setPolyToPoly(transformPerspectiveSrc, 0, transformVerts, 0, 4))
            c.drawBitmap(b, transformMatrix, transformPaint);
    }

    private void fillAffineCorners(float[] out) {
        float hw = transformBitmap.getWidth() * .5f * transformScale;
        float hh = transformBitmap.getHeight() * .5f * transformScale;
        double a = Math.toRadians(transformRotation);
        float cos = (float) Math.cos(a), sin = (float) Math.sin(a);
        float cx = transformSrcRect.exactCenterX() + transformTx;
        float cy = transformSrcRect.exactCenterY() + transformTy;
        out[0] = cx - hw * cos + hh * sin; out[1] = cy - hw * sin - hh * cos;
        out[2] = cx + hw * cos + hh * sin; out[3] = cy + hw * sin - hh * cos;
        out[4] = cx + hw * cos - hh * sin; out[5] = cy + hw * sin + hh * cos;
        out[6] = cx - hw * cos - hh * sin; out[7] = cy - hw * sin + hh * cos;
    }

    private void drawAffineGrid(Canvas c) {
        fillAffineCorners(transformAffineCorners);
        transformGridPaint.setStrokeWidth(2f / Math.max(.05f, currentScale()));
        c.drawLine(transformAffineCorners[0], transformAffineCorners[1], transformAffineCorners[2], transformAffineCorners[3], transformGridPaint);
        c.drawLine(transformAffineCorners[2], transformAffineCorners[3], transformAffineCorners[4], transformAffineCorners[5], transformGridPaint);
        c.drawLine(transformAffineCorners[4], transformAffineCorners[5], transformAffineCorners[6], transformAffineCorners[7], transformGridPaint);
        c.drawLine(transformAffineCorners[6], transformAffineCorners[7], transformAffineCorners[0], transformAffineCorners[1], transformGridPaint);
    }

    private void drawMeshGrid(Canvas c, int cols, int rows) {
        if (transformVerts == null) return;
        transformGridPaint.setStrokeWidth(2f / Math.max(.05f, currentScale()));
        for (int y = 0; y <= rows; y++) {
            for (int x = 0; x < cols; x++) {
                int i = (y * (cols + 1) + x) * 2;
                c.drawLine(transformVerts[i], transformVerts[i + 1], transformVerts[i + 2], transformVerts[i + 3], transformGridPaint);
            }
        }
        for (int x = 0; x <= cols; x++) {
            for (int y = 0; y < rows; y++) {
                int i = (y * (cols + 1) + x) * 2;
                int j = ((y + 1) * (cols + 1) + x) * 2;
                c.drawLine(transformVerts[i], transformVerts[i + 1], transformVerts[j], transformVerts[j + 1], transformGridPaint);
            }
        }
        Paint node = transformGridPaint;
        node.setStyle(Paint.Style.FILL);
        float rr = 5f / Math.max(.05f, currentScale());
        for (int i = 0; i < transformVerts.length / 2; i++) c.drawCircle(transformVerts[i * 2], transformVerts[i * 2 + 1], rr, node);
        node.setStyle(Paint.Style.STROKE);
    }

    private Rect transformedBounds() {
        if (!transformActive || transformSrcRect == null) return null;
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        if (transformType == 0) {
            fillAffineCorners(transformAffineCorners);
            for (int i = 0; i < 4; i++) {
                float px = transformAffineCorners[i * 2], py = transformAffineCorners[i * 2 + 1];
                minX = Math.min(minX, px); minY = Math.min(minY, py);
                maxX = Math.max(maxX, px); maxY = Math.max(maxY, py);
            }
        } else if (transformType == 3) {
            ensureTransformRenderVerts();
            float[] bv = transformRenderVerts;
            if (bv == null) return new Rect(transformSrcRect);
            for (int i = 0; i < bv.length / 2; i++) {
                minX = Math.min(minX, bv[i * 2]); minY = Math.min(minY, bv[i * 2 + 1]);
                maxX = Math.max(maxX, bv[i * 2]); maxY = Math.max(maxY, bv[i * 2 + 1]);
            }
        } else if (transformVerts != null) {
            float[] bv = transformVerts;
            if (transformType == 2) { ensureTransformRenderVerts(); if (transformRenderVerts != null) bv = transformRenderVerts; }
            for (int i = 0; i < bv.length / 2; i++) {
                minX = Math.min(minX, bv[i * 2]); minY = Math.min(minY, bv[i * 2 + 1]);
                maxX = Math.max(maxX, bv[i * 2]); maxY = Math.max(maxY, bv[i * 2 + 1]);
            }
        }
        int l = Math.max(0, (int) Math.floor(minX) - 2), t = Math.max(0, (int) Math.floor(minY) - 2);
        int r = Math.min(project.w, (int) Math.ceil(maxX) + 2), b = Math.min(project.h, (int) Math.ceil(maxY) + 2);
        if (l >= r || t >= b) return null;
        return new Rect(l, t, r, b);
    }

    /** Rectangulos de a - b, sin solaparse. Ambos deben estar dentro del lienzo. */
    private ArrayList<Rect> rectMinus(Rect a, Rect b) {
        ArrayList<Rect> out = new ArrayList<Rect>();
        if (a == null || a.isEmpty()) return out;
        Rect inter = new Rect();
        if (b == null || !inter.setIntersect(a, b)) {
            out.add(new Rect(a));
            return out;
        }
        if (a.top < inter.top) out.add(new Rect(a.left, a.top, a.right, inter.top));
        if (inter.bottom < a.bottom) out.add(new Rect(a.left, inter.bottom, a.right, a.bottom));
        if (a.left < inter.left) out.add(new Rect(a.left, inter.top, inter.left, inter.bottom));
        if (inter.right < a.right) out.add(new Rect(inter.right, inter.top, a.right, inter.bottom));
        return out;
    }

    /**
     * Prepara el deshacer antes de tocar el destino. Guarda el origen una sola
     * vez y solo las partes del destino que caen fuera del origen. Cuando no
     * hay seleccion reutiliza el propio transformBitmap como respaldo: asi al
     * confirmar una imagen 4K NO nace otro int[] de ~33 MB.
     */
    private TransformApplyResult captureTransformUndo(Rect dst) {
        TransformApplyResult res = new TransformApplyResult();
        Rect src = new Rect(transformSrcRect);
        byte[] sourceSel = transformSelectionBackup;
        if (transformBackup != null) res.undoPieces.add(new TransformUndoPiece(src, transformBackup, sourceSel));
        else res.undoPieces.add(new TransformUndoPiece(src, transformBitmap));

        ArrayList<Rect> extra = rectMinus(dst, src);
        for (Rect r : extra) {
            if (r == null || r.isEmpty()) continue;
            int[] lp = copyLayerRect(transformLayer, r);
            byte[] sp = sourceSel != null ? copySelectionRect(r) : null;
            res.undoPieces.add(new TransformUndoPiece(r, lp, sp));
        }
        return res;
    }

    private void restoreTransformUndo(TransformApplyResult res) {
        if (res == null || transformLayer == null) return;
        for (TransformUndoPiece p : res.undoPieces) {
            if (p.layerBitmap != null && !p.layerBitmap.isRecycled()) {
                int[] lp = transformLayer.px();
                p.layerBitmap.getPixels(lp, p.r.top * project.w + p.r.left, project.w,
                        0, 0, p.r.width(), p.r.height());
            } else {
                restoreLayerRect(transformLayer, p.r, p.layer);
            }
            if (p.selection != null) restoreSelectionRect(p.r, p.selection);
        }
    }

    /** Devuelve true si el historial tomo propiedad de transformBitmap. */
    private boolean commitTransformUndo(TransformApplyResult res, Layer layer) {
        if (res == null || undo == null || layer == null) return false;
        boolean ownsTransformBitmap = false;
        undo.setLabel("Transformar");
        undo.begin();
        for (TransformUndoPiece p : res.undoPieces) {
            if (p.layerBitmap != null) {
                undo.recordLayerBitmapRegionBackup(layer, p.r, p.layerBitmap);
                if (p.layerBitmap == transformBitmap) ownsTransformBitmap = true;
            } else {
                undo.recordLayerRegionBackup(layer, p.r, p.layer);
            }
            if (p.selection != null) undo.recordSelectionRegionBackup(p.r, p.selection);
        }
        undo.end();
        return ownsTransformBitmap;
    }

    /** Dibuja solo la imagen, sin guias. Las coordenadas siguen siendo del lienzo. */
    private void drawTransformContent(Canvas c, Bitmap b) {
        if (transformType == 0) drawAffine(c, b);
        else if (transformType == 1) drawPerspective(c, b);
        else {
            ensureTransformRenderVerts();
            if (transformRenderVerts != null) c.drawBitmapMesh(b, transformRenderMeshX, transformRenderMeshY, transformRenderVerts, 0, null, 0, transformPaint);
        }
    }

    /**
     * Aplica por bloques de 512 px. Antes se creaba un Bitmap del destino entero
     * y otro int[] igual de grande; en 4K eso duplicaba decenas de MB y podia
     * congelar Android. Aqui el buffer temporal nunca pasa de unos pocos MB.
     */
    private void renderTransformTiled(Rect dst) {
        if (dst == null || dst.isEmpty()) return;
        final int TILE = 512;
        Bitmap tile = Bitmap.createBitmap(TILE, TILE, Bitmap.Config.ARGB_8888);
        Canvas tc = new Canvas(tile);
        int[] pix = new int[TILE * TILE];
        int[] lp = transformLayer.px();

        for (int top = dst.top; top < dst.bottom; top += TILE) {
            int th = Math.min(TILE, dst.bottom - top);
            for (int left = dst.left; left < dst.right; left += TILE) {
                int tw = Math.min(TILE, dst.right - left);
                tile.eraseColor(0);
                tc.save();
                tc.clipRect(0, 0, tw, th);
                tc.translate(-left, -top);
                drawTransformContent(tc, transformBitmap);
                tc.restore();
                tile.getPixels(pix, 0, TILE, 0, 0, tw, th);
                for (int y = 0; y < th; y++) {
                    int po = y * TILE;
                    int lo = (top + y) * project.w + left;
                    for (int x = 0; x < tw; x++) {
                        int src = pix[po + x], sa = src >>> 24;
                        if (sa != 0) lp[lo + x] = Project.over(lp[lo + x], src, sa);
                    }
                }
            }
        }

        if (transformMaskBitmap != null && transformSelectionBackup != null) {
            for (int top = dst.top; top < dst.bottom; top += TILE) {
                int th = Math.min(TILE, dst.bottom - top);
                for (int left = dst.left; left < dst.right; left += TILE) {
                    int tw = Math.min(TILE, dst.right - left);
                    tile.eraseColor(0);
                    tc.save();
                    tc.clipRect(0, 0, tw, th);
                    tc.translate(-left, -top);
                    drawTransformContent(tc, transformMaskBitmap);
                    tc.restore();
                    tile.getPixels(pix, 0, TILE, 0, 0, tw, th);
                    for (int y = 0; y < th; y++) {
                        int po = y * TILE;
                        int so = (top + y) * project.w + left;
                        for (int x = 0; x < tw; x++) {
                            int a = pix[po + x] >>> 24;
                            if (a > (project.selection[so + x] & 255)) project.selection[so + x] = (byte) a;
                        }
                    }
                }
            }
        }
        tile.recycle();
    }

    public void applyTransform() {
        if (!transformActive || transformApplying || transformLayer == null || transformBitmap == null) {
            if (mode == MODE_TRANSFORM && !transformApplying) showHud("Elige Mover, Perspectiva, Malla o Puntos para empezar");
            return;
        }
        final Rect dst = transformedBounds();
        final Rect dirty = new Rect(transformSrcRect);
        if (dst != null) dirty.union(dst);
        final Layer layer = transformLayer;
        final TransformApplyResult[] holder = new TransformApplyResult[1];

        transformApplying = true;
        setBusy(true);
        showHud("Aplicando transformacion...");
        invalidate();

        Task.run(new Runnable() {
            @Override public void run() {
                TransformApplyResult res = null;
                try {
                    res = captureTransformUndo(dst);
                    holder[0] = res;
                    renderTransformTiled(dst);
                } catch (Throwable t) {
                    if (res == null) res = new TransformApplyResult();
                    res.error = t;
                    holder[0] = res;
                    // Si ya se habia capturado todo, esto revierte tambien cualquier
                    // bloque del destino que alcanzara a modificarse.
                    if (!res.undoPieces.isEmpty()) restoreTransformUndo(res);
                    else restoreTransformSourceToProject();
                }
            }
        }, new Runnable() {
            @Override public void run() {
                TransformApplyResult res = holder[0];
                setBusy(false);
                transformApplying = false;
                if (res == null || res.error != null) {
                    // En caso de error la obra ya fue restaurada en el hilo de trabajo.
                    updateDisplayRegion(dirty);
                    if (transformSelectionBackup != null) paintOverlay(dirty);
                    clearTransformState(true);
                    msg("Transformar se cancelo sin perder la imagen. Se libero memoria para evitar que la app se cierre.");
                    invalidate();
                    return;
                }

                boolean bitmapMovedToUndo = commitTransformUndo(res, layer);
                // Las copias regionales ahora pertenecen al historial de Deshacer.
                // Si no habia seleccion, el mismo Bitmap origen pasa al historial y
                // no se duplica ni se recicla al cerrar la sesion.
                if (bitmapMovedToUndo) transformBitmap = null;
                transformBackup = null;
                transformSelectionBackup = null;
                project.markDirty();
                updateDisplayRegion(dirty);
                if (res.undoPieces.get(0).selection != null) paintOverlay(dirty);
                clearTransformState(true);
                changed();
                showHud("Transformacion aplicada");
            }
        });
    }

    public void cancelTransform() { cancelTransform(true); }

    private void cancelTransform(boolean message) {
        if (!transformActive || transformApplying) return;
        Rect dirty = transformSrcRect == null ? project.fullRect() : new Rect(transformSrcRect);
        Rect dst = transformedBounds(); if (dst != null) dirty.union(dst);
        boolean hadSelection = transformSelectionBackup != null;
        restoreTransformSourceToProject();
        // Transformar aun no era un cambio confirmado: volver atras no ensucia la obra
        // ni crea una entrada falsa de Deshacer.
        updateDisplayRegion(dirty);
        if (hadSelection) paintOverlay(dirty);
        clearTransformState(true);
        if (message) showHud("Transformacion cancelada");
        invalidate();
    }

    private void clearTransformState(boolean recycle) {
        transformActive = false;
        transformApplying = false;
        transformPreparing = false;
        if (recycle) {
            if (transformBitmap != null && !transformBitmap.isRecycled()) transformBitmap.recycle();
            if (transformMaskBitmap != null && !transformMaskBitmap.isRecycled()) transformMaskBitmap.recycle();
        }
        transformBitmap = null; transformMaskBitmap = null; transformLayer = null;
        transformBackup = null; transformSelectionBackup = null; transformSrcRect = null;
        transformVerts = null; transformVertsStart = null; transformNode = -1;
        transformAnchors.clear(); transformAnchorNode = -1; transformNavMidValid = false;
        transformRenderVerts = null; transformRenderMeshX = transformRenderMeshY = 0; transformRenderDirty = true;
        transformTx = transformTy = transformRotation = 0f; transformScale = 1f;
    }

    public boolean isTransformActive() { return transformActive; }

    public void setTransformType(int type) {
        type = Math.max(0, Math.min(3, type));
        boolean changedType = transformType != type;
        transformType = type;
        if (changedType) {
            transformTx = transformTy = transformRotation = 0f;
            transformScale = 1f;
            transformAnchorNode = -1;
            transformNavMidValid = false;
            if (type == 3) transformAnchors.clear();
        }

        // Al pulsar Mover/Perspectiva/Malla la sesion nace en ese mismo toque.
        // Antes solo cambiaba el icono y habia que tocar otra vez el lienzo para
        // que aparecieran los puntos de la malla.
        if (!transformActive && !transformPreparing && mode == MODE_TRANSFORM) {
            Layer t = needLayer();
            Rect r = t == null ? null : (project.hasSelection() ? project.selectionBounds() : t.bounds(project.w, project.h));
            if (r != null && r.width() > 0 && r.height() > 0) {
                // En Malla dibuja la cuadricula en el mismo frame del toque. La copia
                // pesada del bitmap se hace despues de que Android tenga oportunidad
                // de pintar ese frame, eliminando la sensacion de boton congelado.
                transformSrcRect = new Rect(r);
                initTransformVerts();
                transformPreparing = true;
                invalidate();
                postDelayed(new Runnable() {
                    @Override public void run() {
                        if (mode != MODE_TRANSFORM || !transformPreparing) return;
                        startTransformSession();
                    }
                }, 24);
            }
        } else if (transformActive && changedType) {
            initTransformVerts();
        }
        invalidate();
    }

    public int getTransformType() { return transformType; }

    public void changeTransformGrid(int delta) {
        // Compatibilidad con llamadas antiguas: cambia filas y columnas a la vez.
        transformMeshX = Math.max(2, Math.min(12, transformMeshX + delta));
        transformMeshY = Math.max(2, Math.min(12, transformMeshY + delta));
        if (transformActive && transformType == 2) initTransformVerts();
        showHud("Malla " + transformMeshX + " x " + transformMeshY);
        invalidate();
    }

    public void changeTransformGridCols(int delta) {
        transformMeshX = Math.max(2, Math.min(12, transformMeshX + delta));
        if (transformActive && transformType == 2) initTransformVerts();
        showHud("Columnas " + transformMeshX + "  •  Filas " + transformMeshY);
        invalidate();
    }

    public void changeTransformGridRows(int delta) {
        transformMeshY = Math.max(2, Math.min(12, transformMeshY + delta));
        if (transformActive && transformType == 2) initTransformVerts();
        showHud("Columnas " + transformMeshX + "  •  Filas " + transformMeshY);
        invalidate();
    }

    public int getTransformGrid() { return transformMeshX; }
    public int getTransformGridCols() { return transformMeshX; }
    public int getTransformGridRows() { return transformMeshY; }

    public void setTransformMeshSmoothness(float v) {
        transformMeshSmoothness = Math.max(0f, Math.min(1f, v));
        transformRenderDirty = true;
        showHud("Suavidad malla " + Math.round(transformMeshSmoothness * 100f) + "%");
        invalidate();
    }

    public float getTransformMeshSmoothness() { return transformMeshSmoothness; }

    // ==================================================================
    // Difuminar, borrosidad y licuar. Todo trabaja por regiones pequenas.
    // ==================================================================

    private boolean isLocalEffectMode() {
        return mode == MODE_SMUDGE || mode == MODE_BLUR || mode == MODE_LIQUIFY;
    }

    private void clearEffectStrokeBackup() {
        effectStrokeBackupTiles.clear();
        effectStrokeBackupLayer = null;
        effectStrokeBackupFailed = false;
    }

    /**
     * Guarda el estado anterior SOLO de los bloques que este stamp va a escribir.
     * Asi un pincel grande no necesita copiar toda la capa al empezar el trazo.
     */
    private boolean captureEffectStrokeBackup(Rect area) {
        if (strokeLayer == null || area == null || project == null) return false;
        if (effectStrokeBackupFailed) return false;
        if (effectStrokeBackupLayer != strokeLayer) {
            clearEffectStrokeBackup();
            effectStrokeBackupLayer = strokeLayer;
        }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx0 = Math.max(0, area.left / LIQUIFY_TILE);
        int ty0 = Math.max(0, area.top / LIQUIFY_TILE);
        int tx1 = Math.max(tx0, (Math.max(area.left, area.right - 1)) / LIQUIFY_TILE);
        int ty1 = Math.max(ty0, (Math.max(area.top, area.bottom - 1)) / LIQUIFY_TILE);
        int[] src = strokeLayer.px();
        try {
            for (int ty = ty0; ty <= ty1; ty++) {
                for (int tx = tx0; tx <= tx1; tx++) {
                    int key = ty * cols + tx;
                    if (effectStrokeBackupTiles.get(key) != null) continue;
                    int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
                    int tw = Math.min(LIQUIFY_TILE, project.w - left);
                    int th = Math.min(LIQUIFY_TILE, project.h - top);
                    int[] tile = new int[tw * th];
                    for (int yy = 0; yy < th; yy++)
                        System.arraycopy(src, (top + yy) * project.w + left, tile, yy * tw, tw);
                    effectStrokeBackupTiles.put(key, tile);
                }
            }
            return true;
        } catch (OutOfMemoryError e) {
            effectStrokeBackupFailed = true;
            msg("No alcanzo memoria para continuar este trazo. Suelta el dedo y prueba con un pincel menor");
            return false;
        }
    }

    /** Restaura el trazo local cuando entra un segundo dedo o se cancela. */
    private void restoreEffectStrokeBackup() {
        if (project == null || effectStrokeBackupLayer == null) {
            clearEffectStrokeBackup();
            return;
        }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int[] dst = effectStrokeBackupLayer.px();
        for (int i = 0; i < effectStrokeBackupTiles.size(); i++) {
            int key = effectStrokeBackupTiles.keyAt(i);
            int[] tile = effectStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            for (int yy = 0; yy < th; yy++)
                System.arraycopy(tile, yy * tw, dst, (top + yy) * project.w + left, tw);
        }
        project.markDirty();
        clearEffectStrokeBackup();
    }

    /**
     * Pasa los bloques originales directamente al historial. No se crea otra copia
     * gigante del rectangulo union del trazo, por lo que Deshacer tambien queda ligero.
     */
    private void recordEffectStrokeUndo(String label) {
        if (undo == null || project == null || effectStrokeBackupLayer == null
                || effectStrokeBackupTiles.size() == 0) {
            clearEffectStrokeBackup();
            return;
        }
        Layer layer = effectStrokeBackupLayer;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        undo.setLabel(label);
        undo.begin();
        for (int i = 0; i < effectStrokeBackupTiles.size(); i++) {
            int key = effectStrokeBackupTiles.keyAt(i);
            int[] tile = effectStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            Rect r = new Rect(left, top, left + tw, top + th);
            undo.recordLayerRegionBackup(layer, r, tile);
        }
        undo.end();
        // UndoManager es ahora dueno de los int[]; clear solo suelta nuestras referencias.
        effectStrokeBackupTiles.clear();
        effectStrokeBackupLayer = null;
        effectStrokeBackupFailed = false;
    }

    /** Pixel de la capa tal como estaba al iniciar el trazo, sin una copia completa. */
    private int strokeOriginalAt(int index) {
        if (project == null || strokeLayer == null || index < 0 || index >= project.w * project.h) return 0;
        if (mode == MODE_HEAL && pxBackup != null && pxBackup.length == project.w * project.h) return pxBackup[index];
        int x = index % project.w, y = index / project.w;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx = x / LIQUIFY_TILE, ty = y / LIQUIFY_TILE;
        int[] tile = effectStrokeBackupTiles.get(ty * cols + tx);
        if (tile == null) return strokeLayer.px()[index];
        int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
        int tw = Math.min(LIQUIFY_TILE, project.w - left);
        return tile[(y - top) * tw + (x - left)];
    }

    /** Restaura solo una zona desde los bloques capturados, conservando el respaldo. */
    private void restoreLayerBackupRegion(Rect area) {
        if (project == null || effectStrokeBackupLayer == null || area == null) return;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int[] dst = effectStrokeBackupLayer.px();
        for (int i = 0; i < effectStrokeBackupTiles.size(); i++) {
            int key = effectStrokeBackupTiles.keyAt(i);
            int[] tile = effectStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            Rect tr = new Rect(left, top, left + tw, top + th);
            if (!tr.intersect(area)) continue;
            for (int y = tr.top; y < tr.bottom; y++) {
                int srcOff = (y - top) * tw + (tr.left - left);
                int dstOff = y * project.w + tr.left;
                System.arraycopy(tile, srcOff, dst, dstOff, tr.width());
            }
        }
        project.markDirty();
    }

    /** Captura tambien la zona origen de Clonar antes de que el propio trazo pueda tocarla. */
    private void captureCloneSourceBackup(Rect dest) {
        if (dest == null || project == null || mode == MODE_HEAL) return;
        int[] xs = {dest.left, Math.max(dest.left, dest.right - 1), dest.left, Math.max(dest.left, dest.right - 1)};
        int[] ys = {dest.top, dest.top, Math.max(dest.top, dest.bottom - 1), Math.max(dest.top, dest.bottom - 1)};
        int minX = project.w, minY = project.h, maxX = -1, maxY = -1;
        for (int k = 0; k < 4; k++) {
            int src = cloneSource(xs[k], ys[k]);
            if (src < 0) continue;
            int sy = src / project.w, sx = src - sy * project.w;
            minX = Math.min(minX, sx); minY = Math.min(minY, sy);
            maxX = Math.max(maxX, sx); maxY = Math.max(maxY, sy);
        }
        if (maxX < 0) return;
        Rect r = new Rect(Math.max(0, minX - 3), Math.max(0, minY - 3),
                Math.min(project.w, maxX + 4), Math.min(project.h, maxY + 4));
        captureEffectStrokeBackup(r);
    }

    private void clearSelectionStrokeBackup() {
        selectionStrokeBackupTiles.clear();
        selectionStrokeBackupFailed = false;
    }

    private boolean captureSelectionStrokeBackup(Rect area) {
        if (project == null || area == null || selectionStrokeBackupFailed) return false;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx0 = Math.max(0, area.left / LIQUIFY_TILE);
        int ty0 = Math.max(0, area.top / LIQUIFY_TILE);
        int tx1 = Math.max(tx0, Math.max(area.left, area.right - 1) / LIQUIFY_TILE);
        int ty1 = Math.max(ty0, Math.max(area.top, area.bottom - 1) / LIQUIFY_TILE);
        try {
            for (int ty = ty0; ty <= ty1; ty++) {
                for (int tx = tx0; tx <= tx1; tx++) {
                    int key = ty * cols + tx;
                    if (selectionStrokeBackupTiles.get(key) != null) continue;
                    int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
                    int tw = Math.min(LIQUIFY_TILE, project.w - left);
                    int th = Math.min(LIQUIFY_TILE, project.h - top);
                    byte[] tile = new byte[tw * th];
                    for (int yy = 0; yy < th; yy++)
                        System.arraycopy(project.selection, (top + yy) * project.w + left, tile, yy * tw, tw);
                    selectionStrokeBackupTiles.put(key, tile);
                }
            }
            return true;
        } catch (OutOfMemoryError e) {
            selectionStrokeBackupFailed = true;
            msg("No alcanzo memoria para continuar la seleccion. Prueba un pincel menor");
            return false;
        }
    }

    private void restoreSelectionStrokeBackup() {
        if (project == null) { clearSelectionStrokeBackup(); return; }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        for (int i = 0; i < selectionStrokeBackupTiles.size(); i++) {
            int key = selectionStrokeBackupTiles.keyAt(i);
            byte[] tile = selectionStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            for (int yy = 0; yy < th; yy++)
                System.arraycopy(tile, yy * tw, project.selection, (top + yy) * project.w + left, tw);
        }
        clearSelectionStrokeBackup();
    }

    private void recordSelectionStrokeUndo(String label) {
        if (undo == null || project == null || selectionStrokeBackupTiles.size() == 0) {
            clearSelectionStrokeBackup();
            return;
        }
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        undo.setLabel(label);
        undo.begin();
        for (int i = 0; i < selectionStrokeBackupTiles.size(); i++) {
            int key = selectionStrokeBackupTiles.keyAt(i);
            byte[] tile = selectionStrokeBackupTiles.valueAt(i);
            if (tile == null) continue;
            int tx = key % cols, ty = key / cols;
            int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
            int tw = Math.min(LIQUIFY_TILE, project.w - left);
            int th = Math.min(LIQUIFY_TILE, project.h - top);
            undo.recordSelectionRegionBackup(new Rect(left, top, left + tw, top + th), tile);
        }
        undo.end();
        selectionStrokeBackupTiles.clear();
        selectionStrokeBackupFailed = false;
    }

    private void ensureLiquifyBase(Layer l) {
        if (l == null) return;
        if (liquifyBaseLayer != l) {
            liquifyBaseTiles.clear();
            liquifyBaseLayer = l;
        }
    }

    /** Guarda una sola vez el original de los bloques que va a tocar Especial. */
    private void captureLiquifyBase(Rect area) {
        if (strokeLayer == null || area == null || project == null) return;
        ensureLiquifyBase(strokeLayer);
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx0 = Math.max(0, area.left / LIQUIFY_TILE);
        int ty0 = Math.max(0, area.top / LIQUIFY_TILE);
        int tx1 = Math.max(tx0, (Math.max(area.left, area.right - 1)) / LIQUIFY_TILE);
        int ty1 = Math.max(ty0, (Math.max(area.top, area.bottom - 1)) / LIQUIFY_TILE);
        int[] src = strokeLayer.px();
        try {
            for (int ty = ty0; ty <= ty1; ty++) {
                for (int tx = tx0; tx <= tx1; tx++) {
                    int key = ty * cols + tx;
                    if (liquifyBaseTiles.get(key) != null) continue;
                    int[] tile = new int[LIQUIFY_TILE * LIQUIFY_TILE];
                    int left = tx * LIQUIFY_TILE, top = ty * LIQUIFY_TILE;
                    int tw = Math.min(LIQUIFY_TILE, project.w - left);
                    int th = Math.min(LIQUIFY_TILE, project.h - top);
                    for (int yy = 0; yy < th; yy++)
                        System.arraycopy(src, (top + yy) * project.w + left, tile, yy * LIQUIFY_TILE, tw);
                    liquifyBaseTiles.put(key, tile);
                    // Los nuevos bloques originales deben estar presentes en el sampler.
                    liquifySourceBufferRect.setEmpty();
                }
            }
        } catch (OutOfMemoryError e) {
            // No se cae la app: Restaurar simplemente conserva lo ya capturado.
            msg("Especial libero memoria; continua con una zona mas pequena");
        }
    }

    private int liquifyOriginalAt(int x, int y, int current) {
        if (project == null || x < 0 || y < 0 || x >= project.w || y >= project.h) return current;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx = x / LIQUIFY_TILE, ty = y / LIQUIFY_TILE;
        int[] tile = liquifyBaseTiles.get(ty * cols + tx);
        if (tile == null) return current;
        return tile[(y - ty * LIQUIFY_TILE) * LIQUIFY_TILE + (x - tx * LIQUIFY_TILE)];
    }

    private int liquifySourceAt(int x, int y) {
        if (project == null || x < 0 || y < 0 || x >= project.w || y >= project.h) return 0;
        int current = strokeLayer == null ? 0 : strokeLayer.px()[y * project.w + x];
        return liquifyOriginalAt(x, y, current);
    }

    /** Inicializa solo un campo pequeno; no duplica la imagen completa. */
    private boolean ensureLiquifyField(Layer l) {
        if (l == null || project == null) return false;
        int maxDim = Math.max(project.w, project.h);
        // 18 px en trabajos normales; algo mas espaciado en lienzos enormes para no
        // gastar CPU/memoria. Sigue siendo mucho mas denso que la malla visible.
        // Paso mas fino para ilustraciones y contornos; limite gradual en lienzos grandes.
        // El TopologyGuard previene pliegues independientemente de este paso.
        float step = maxDim > 6400 ? 32f : maxDim > 4000 ? 24f : maxDim > 2200 ? 16f : 12f;
        int cols = (int) Math.ceil((project.w - 1) / step) + 1;
        int rows = (int) Math.ceil((project.h - 1) / step) + 1;
        int need = Math.max(4, cols * rows);
        if (liquifyBaseLayer == l && liquifyFieldReady && liquifyGridCols == cols && liquifyGridRows == rows) return true;
        resetLiquifySession();
        try {
            liquifyGridStep = step;
            liquifyGridCols = cols; liquifyGridRows = rows;
            liquifyDx = new float[need]; liquifyDy = new float[need];
            liquifyDxTmp = new float[need]; liquifyDyTmp = new float[need];
            liquifyBaseLayer = l;
            liquifyFieldReady = true;
            return true;
        } catch (OutOfMemoryError e) {
            resetLiquifySession();
            msg("No alcanzo memoria para Especial. Usa un lienzo o pincel menor.");
            return false;
        }
    }

    private void resetLiquifySession() {
        liquifyBaseTiles.clear();
        liquifyDirtyTiles.clear();
        liquifyPreviewDirty.setEmpty();
        liquifyPreviewDirtyValid = false;
        liquifyLastPreviewMs = 0L;
        liquifyPreviewIntervalMs = LIQUIFY_PREVIEW_MIN_MS;
        liquifyBaseLayer = null;
        liquifyDx = liquifyDy = liquifyDxTmp = liquifyDyTmp = null;
        liquifyGridCols = liquifyGridRows = 0;
        liquifyFieldReady = false;
        liquifyMaxDisplacement = 0f;
        liquifySourceBufferRect.setEmpty();
        liquifySourceBufferW = liquifySourceBufferH = 0;
    }

    private float liquifyFalloff(float d2, float r2) {
        if (d2 >= r2) return 0f;
        float q = 1f - d2 / Math.max(1f, r2);
        q = q * q * (3f - 2f * q);
        // Suavidad alta reparte mas la deformacion hacia el borde sin tocar colores.
        float soft = Math.max(0f, Math.min(1f, effectSoftness));
        return (float) Math.pow(q, 1.65f - soft * .85f);
    }

    private void sampleLiquifyDisplacement(float x, float y, float[] out) {
        sampleLiquifyWithJacobian(x, y, liquifyDifferential);
        out[0] = liquifyDifferential[0];
        out[1] = liquifyDifferential[1];
    }

    // out = [dx, dy, d(dx)/dx, d(dx)/dy, d(dy)/dx, d(dy)/dy].
    // Derivadas exactas del campo bilineal, para invertirlo de forma estable.
    private final float[] liquifyDifferential = new float[6];
    private void sampleLiquifyWithJacobian(float x, float y, float[] out) {
        if (!liquifyFieldReady || liquifyDx == null || project == null) {
            for (int k = 0; k < 6; k++) out[k] = 0f;
            return;
        }
        x = Math.max(0f, Math.min(project.w - 1f, x));
        y = Math.max(0f, Math.min(project.h - 1f, y));
        int x0 = Math.min(liquifyGridCols - 1, (int) (x / liquifyGridStep));
        int y0 = Math.min(liquifyGridRows - 1, (int) (y / liquifyGridStep));
        int x1 = Math.min(liquifyGridCols - 1, x0 + 1);
        int y1 = Math.min(liquifyGridRows - 1, y0 + 1);
        float left = Math.min(project.w - 1f, x0 * liquifyGridStep);
        float top = Math.min(project.h - 1f, y0 * liquifyGridStep);
        float hx = Math.max(1f, Math.min(project.w - 1f, x1 * liquifyGridStep) - left);
        float hy = Math.max(1f, Math.min(project.h - 1f, y1 * liquifyGridStep) - top);
        float fx = x1 == x0 ? 0f : Math.max(0f, Math.min(1f, (x - left) / hx));
        float fy = y1 == y0 ? 0f : Math.max(0f, Math.min(1f, (y - top) / hy));
        int i00 = y0 * liquifyGridCols + x0;
        int i10 = y0 * liquifyGridCols + x1;
        int i01 = y1 * liquifyGridCols + x0;
        int i11 = y1 * liquifyGridCols + x1;
        float d00x = liquifyDx[i00], d10x = liquifyDx[i10];
        float d01x = liquifyDx[i01], d11x = liquifyDx[i11];
        float d00y = liquifyDy[i00], d10y = liquifyDy[i10];
        float d01y = liquifyDy[i01], d11y = liquifyDy[i11];
        float a0x = d00x + (d10x - d00x) * fx, a1x = d01x + (d11x - d01x) * fx;
        float a0y = d00y + (d10y - d00y) * fx, a1y = d01y + (d11y - d01y) * fx;
        out[0] = a0x + (a1x - a0x) * fy;
        out[1] = a0y + (a1y - a0y) * fy;
        out[2] = x0 == x1 ? 0f : ((d10x - d00x) * (1f - fy) + (d11x - d01x) * fy) / hx;
        out[3] = y0 == y1 ? 0f : ((d01x - d00x) * (1f - fx) + (d11x - d10x) * fx) / hy;
        out[4] = x0 == x1 ? 0f : ((d10y - d00y) * (1f - fy) + (d11y - d01y) * fy) / hx;
        out[5] = y0 == y1 ? 0f : ((d01y - d00y) * (1f - fx) + (d11y - d10y) * fx) / hy;
    }

    /** Resuelve (q + desplazamiento(q)) = destino. Sin pliegues, Newton converge rapido. */
    private void invertLiquify(float targetX, float targetY, float[] out) {
        sampleLiquifyWithJacobian(targetX, targetY, liquifyDifferential);
        float qx = targetX - liquifyDifferential[0];
        float qy = targetY - liquifyDifferential[1];
        for (int it = 0; it < 6; it++) {
            sampleLiquifyWithJacobian(qx, qy, liquifyDifferential);
            float ex = qx + liquifyDifferential[0] - targetX;
            float ey = qy + liquifyDifferential[1] - targetY;
            if (ex * ex + ey * ey < .0009f) break;
            float a = 1f + liquifyDifferential[2], b = liquifyDifferential[3];
            float c = liquifyDifferential[4], d = 1f + liquifyDifferential[5];
            float det = a * d - b * c;
            if (!Float.isFinite(det) || det < .08f) break;
            float stepx = (d * ex - b * ey) / det;
            float stepy = (a * ey - c * ex) / det;
            float stepLen = (float)Math.hypot(stepx, stepy);
            float maxStep = Math.max(12f, brushRadius);
            if (stepLen > maxStep) {
                stepx *= maxStep / stepLen;
                stepy *= maxStep / stepLen;
            }
            qx -= stepx;
            qy -= stepy;
            if (!Float.isFinite(qx) || !Float.isFinite(qy)) {
                qx = targetX; qy = targetY; break;
            }
        }
        out[0] = qx;
        out[1] = qy;
    }

    private int sampleLiquifySourceBilinear(float x, float y) {
        // Extender el pixel del borde en vez de mezclar con negro/transparente
        // fuera del lienzo. Evita las franjas grises al licuar junto al contorno.
        if (project == null || project.w <= 0 || project.h <= 0) return 0;
        x = Math.max(0f, Math.min(project.w - 1f, x));
        y = Math.max(0f, Math.min(project.h - 1f, y));
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        int x1 = Math.min(project.w - 1, x0 + 1);
        int y1 = Math.min(project.h - 1, y0 + 1);
        float fx = x - x0, fy = y - y0;
        int c00 = liquifySourceAt(x0, y0), c10 = liquifySourceAt(x1, y0);
        int c01 = liquifySourceAt(x0, y1), c11 = liquifySourceAt(x1, y1);
        return bilerpArgb(c00, c10, c01, c11, fx, fy);
    }

    private static int bilerpArgb(int c00, int c10, int c01, int c11, float fx, float fy) {
        float w00 = (1f - fx) * (1f - fy), w10 = fx * (1f - fy), w01 = (1f - fx) * fy, w11 = fx * fy;
        float a00 = c00 >>> 24, a10 = c10 >>> 24, a01 = c01 >>> 24, a11 = c11 >>> 24;
        float af = a00 * w00 + a10 * w10 + a01 * w01 + a11 * w11;
        int a = Math.max(0, Math.min(255, Math.round(af)));
        if (a <= 0 || af <= .001f) return 0;
        // Interpolacion premultiplicada: evita halos oscuros en bordes transparentes.
        float pr = ((c00 >> 16) & 255) * a00 * w00 + ((c10 >> 16) & 255) * a10 * w10
                + ((c01 >> 16) & 255) * a01 * w01 + ((c11 >> 16) & 255) * a11 * w11;
        float pg = ((c00 >> 8) & 255) * a00 * w00 + ((c10 >> 8) & 255) * a10 * w10
                + ((c01 >> 8) & 255) * a01 * w01 + ((c11 >> 8) & 255) * a11 * w11;
        float pb = (c00 & 255) * a00 * w00 + (c10 & 255) * a10 * w10
                + (c01 & 255) * a01 * w01 + (c11 & 255) * a11 * w11;
        int r = Math.max(0, Math.min(255, Math.round(pr / af)));
        int g = Math.max(0, Math.min(255, Math.round(pg / af)));
        int b = Math.max(0, Math.min(255, Math.round(pb / af)));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private void markLiquifyDirty(Rect r) {
        if (r == null || r.isEmpty() || project == null) return;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        int tx0 = Math.max(0, r.left / LIQUIFY_TILE);
        int ty0 = Math.max(0, r.top / LIQUIFY_TILE);
        int tx1 = Math.max(tx0, (Math.max(r.left, r.right - 1)) / LIQUIFY_TILE);
        int ty1 = Math.max(ty0, (Math.max(r.top, r.bottom - 1)) / LIQUIFY_TILE);
        for (int ty = ty0; ty <= ty1; ty++)
            for (int tx = tx0; tx <= tx1; tx++)
                liquifyDirtyTiles.put(ty * cols + tx, Boolean.TRUE);
        // Conservar TODAS las regiones desde el ultimo render. La vista anterior
        // persiste en la capa y no desaparece mientras se mueve el dedo.
        if (liquifyPreviewDirtyValid) liquifyPreviewDirty.union(r);
        else liquifyPreviewDirty.set(r);
        liquifyPreviewDirtyValid = true;
    }

    private boolean prepareLiquifySourceBuffer(Rect out, int pad) {
        if (project == null || strokeLayer == null || out == null) return false;
        Rect src = new Rect(out);
        src.inset(-Math.max(2, pad), -Math.max(2, pad));
        clamp(src);
        int w = src.width(), h = src.height();
        if (w <= 0 || h <= 0) return false;
        // Si el buffer anterior ya contiene toda la fuente necesaria, se reutiliza.
        // Esto evita volver a copiar miles de pixeles en cada frame de preview.
        if (liquifySourceBuffer != null && liquifySourceBufferW > 0 && liquifySourceBufferH > 0
                && liquifySourceBufferRect.contains(src)) return true;
        int need = w * h;
        try {
            if (liquifySourceBuffer == null || liquifySourceBuffer.length < need)
                liquifySourceBuffer = new int[Math.max(need, need + need / 4)];
        } catch (OutOfMemoryError e) {
            liquifySourceBuffer = null;
            return false;
        }
        for (int y = 0; y < h; y++) {
            int yy = src.top + y;
            int off = y * w;
            for (int x = 0; x < w; x++) {
                int xx = src.left + x;
                int current = strokeLayer.px()[yy * project.w + xx];
                liquifySourceBuffer[off + x] = liquifyOriginalAt(xx, yy, current);
            }
        }
        liquifySourceBufferRect.set(src);
        liquifySourceBufferW = w; liquifySourceBufferH = h;
        return true;
    }

    private int sampleLiquifyBuffered(float x, float y) {
        if (liquifySourceBuffer == null || liquifySourceBufferW <= 0 || liquifySourceBufferH <= 0)
            return sampleLiquifySourceBilinear(x, y);
        float lx = x - liquifySourceBufferRect.left, ly = y - liquifySourceBufferRect.top;
        int x0 = (int)Math.floor(lx), y0 = (int)Math.floor(ly);
        float fx = lx - x0, fy = ly - y0;
        if (x0 < 0 || y0 < 0 || x0 + 1 >= liquifySourceBufferW || y0 + 1 >= liquifySourceBufferH)
            return sampleLiquifySourceBilinear(x, y);
        int i = y0 * liquifySourceBufferW + x0;
        int c00 = liquifySourceBuffer[i], c10 = liquifySourceBuffer[i + 1];
        int c01 = liquifySourceBuffer[i + liquifySourceBufferW], c11 = liquifySourceBuffer[i + liquifySourceBufferW + 1];
        return bilerpArgb(c00, c10, c01, c11, fx, fy);
    }


    private float localLiquifyMax(int gx0, int gy0, int gx1, int gy1) {
        float m = 0f;
        for (int gy = gy0; gy <= gy1; gy++) for (int gx = gx0; gx <= gx1; gx++) {
            int i = gy * liquifyGridCols + gx;
            float d = (float) Math.hypot(liquifyDx[i], liquifyDy[i]);
            if (d > m) m = d;
        }
        return m;
    }

    /**
     * Motor de Licuar no destructivo: modifica un campo, y despues reconstruye el
     * destino desde la fuente estable. No vuelve a usar el resultado anterior como
     * textura de entrada, por lo que no acumula blur ni dientes por cada MotionEvent.
     */
    private Rect effectLiquifyField(float cx, float cy, float dragX, float dragY, int type) {
        if (!ensureLiquifyField(strokeLayer)) return null;
        float r = Math.max(3f, brushRadius);
        float r2 = r * r;
        float str = Math.max(.03f, Math.min(1f, effectStrength));
        int gx0 = Math.max(0, (int) Math.floor((cx - r - liquifyGridStep) / liquifyGridStep));
        int gy0 = Math.max(0, (int) Math.floor((cy - r - liquifyGridStep) / liquifyGridStep));
        int gx1 = Math.min(liquifyGridCols - 1, (int) Math.ceil((cx + r + liquifyGridStep) / liquifyGridStep));
        int gy1 = Math.min(liquifyGridRows - 1, (int) Math.ceil((cy + r + liquifyGridStep) / liquifyGridStep));
        float oldMax = localLiquifyMax(gx0, gy0, gx1, gy1);

        float dragLen = (float) Math.hypot(dragX, dragY);
        float maxStep = Math.max(2f, r * .28f);
        if (dragLen > maxStep && dragLen > .001f) {
            float k = maxStep / dragLen; dragX *= k; dragY *= k; dragLen = maxStep;
        }

        // Antes de cambiar el campo se guarda TODO lo que este stamp podria escribir.
        // Asi un fallo de memoria nunca deja un campo adelantado respecto al bitmap.
        float possibleDelta = type == 0 ? dragLen : (type == 1 || type == 2 ? r * .12f : 0f);
        int prePad = (int) Math.ceil(oldMax + possibleDelta + liquifyGridStep * 2f + 6f);
        Rect preDirty = new Rect((int)Math.floor(cx - r - prePad), (int)Math.floor(cy - r - prePad),
                (int)Math.ceil(cx + r + prePad), (int)Math.ceil(cy + r + prePad));
        clamp(preDirty);
        if (preDirty.isEmpty()) return null;
        Rect sourceNeed = new Rect(preDirty);
        int srcPad = (int)Math.ceil(oldMax + possibleDelta + 6f);
        sourceNeed.inset(-srcPad, -srcPad); clamp(sourceNeed);
        captureLiquifyBase(sourceNeed);
        if (!captureEffectStrokeBackup(preDirty)) return null;

        // Copia LOCAL de los nodos editados + vecinos de Suavizar: permite
        // backtracking sin copiar el lienzo completo en cada MotionEvent.
        int copyX0 = Math.max(0, gx0 - 1), copyX1 = Math.min(liquifyGridCols - 1, gx1 + 1);
        int copyY0 = Math.max(0, gy0 - 1), copyY1 = Math.min(liquifyGridRows - 1, gy1 + 1);
        for (int gy = copyY0; gy <= copyY1; gy++) {
            int start = gy * liquifyGridCols + copyX0;
            System.arraycopy(liquifyDx, start, liquifyDxTmp, start, copyX1 - copyX0 + 1);
            System.arraycopy(liquifyDy, start, liquifyDyTmp, start, copyX1 - copyX0 + 1);
        }

        for (int gy = gy0; gy <= gy1; gy++) {
            float oy = Math.min(project.h - 1, gy * liquifyGridStep);
            for (int gx = gx0; gx <= gx1; gx++) {
                float ox = Math.min(project.w - 1, gx * liquifyGridStep);
                int i = gy * liquifyGridCols + gx;
                float px = ox + liquifyDx[i], py = oy + liquifyDy[i];
                float vx = px - cx, vy = py - cy;
                float d2 = vx * vx + vy * vy;
                float fall = liquifyFalloff(d2, r2);
                if (fall <= .0005f) continue;
                int sx = Math.max(0, Math.min(project.w - 1, Math.round(ox)));
                int sy = Math.max(0, Math.min(project.h - 1, Math.round(oy)));
                float sel = selectionFactor(sy * project.w + sx);
                if (sel <= .001f) continue;
                float wgt = fall * sel;

                if (type == 0) {
                    // Respuesta mas gradual: 32 % no mueve al 56 % de la distancia.
                    float gain = (.12f + .88f * str) * wgt;
                    liquifyDx[i] += dragX * gain;
                    liquifyDy[i] += dragY * gain;
                } else if (type == 1 || type == 2) {
                    float amt = (.018f + .075f * str) * wgt;
                    float sign = type == 1 ? 1f : -1f;
                    liquifyDx[i] += (cx - px) * amt * sign;
                    liquifyDy[i] += (cy - py) * amt * sign;
                } else if (type == 3) {
                    float ax = 0f, ay = 0f, ww = 0f;
                    for (int yy = Math.max(0, gy - 1); yy <= Math.min(liquifyGridRows - 1, gy + 1); yy++) {
                        for (int xx = Math.max(0, gx - 1); xx <= Math.min(liquifyGridCols - 1, gx + 1); xx++) {
                            int j = yy * liquifyGridCols + xx;
                            float kw = (xx == gx && yy == gy) ? 2f : 1f;
                            ax += liquifyDxTmp[j] * kw; ay += liquifyDyTmp[j] * kw; ww += kw;
                        }
                    }
                    float t = Math.min(.65f, (.10f + .42f * str) * wgt);
                    liquifyDx[i] = liquifyDxTmp[i] + (ax / ww - liquifyDxTmp[i]) * t;
                    liquifyDy[i] = liquifyDyTmp[i] + (ay / ww - liquifyDyTmp[i]) * t;
                } else {
                    float t = Math.min(.82f, (.12f + .58f * str) * wgt);
                    liquifyDx[i] *= (1f - t);
                    liquifyDy[i] *= (1f - t);
                }

                float md = Math.max(96f, r * 3.2f);
                float dd = (float) Math.hypot(liquifyDx[i], liquifyDy[i]);
                if (dd > md && dd > .001f) { float k = md / dd; liquifyDx[i] *= k; liquifyDy[i] *= k; }
            }
        }

        // Condicion imprescindible: ninguna celda puede plegarse o colapsar.
        // Aplicamos solo una fraccion del incremento candidato si es necesario.
        float minArea = com.pacco.animecut.core.LiquifyTopologyGuard.minTriangleRatio(
                liquifyDx, liquifyDy, liquifyGridCols, liquifyGridRows,
                liquifyGridStep, project.w, project.h,
                Math.max(0, gx0 - 1), Math.max(0, gy0 - 1),
                Math.min(liquifyGridCols - 2, gx1), Math.min(liquifyGridRows - 2, gy1));
        int halves = 0;
        while (minArea < .12f && halves++ < 12) {
            // Mezclar la propuesta actual con el ultimo estado valido.
            for (int gy = gy0; gy <= gy1; gy++) {
                for (int gx = gx0; gx <= gx1; gx++) {
                    int i = gy * liquifyGridCols + gx;
                    liquifyDx[i] = (liquifyDx[i] + liquifyDxTmp[i]) * .5f;
                    liquifyDy[i] = (liquifyDy[i] + liquifyDyTmp[i]) * .5f;
                }
            }
            minArea = com.pacco.animecut.core.LiquifyTopologyGuard.minTriangleRatio(
                    liquifyDx, liquifyDy, liquifyGridCols, liquifyGridRows,
                    liquifyGridStep, project.w, project.h,
                    Math.max(0, gx0 - 1), Math.max(0, gy0 - 1),
                    Math.min(liquifyGridCols - 2, gx1), Math.min(liquifyGridRows - 2, gy1));
        }
        if (minArea < .12f) {
            for (int gy = gy0; gy <= gy1; gy++) {
                int start = gy * liquifyGridCols + gx0;
                System.arraycopy(liquifyDxTmp, start, liquifyDx, start, gx1 - gx0 + 1);
                System.arraycopy(liquifyDyTmp, start, liquifyDy, start, gx1 - gx0 + 1);
            }
            return null; // Estado anterior intacto: jamas confirmar un pliegue.
        }

        float newMax = localLiquifyMax(gx0, gy0, gx1, gy1);
        liquifyMaxDisplacement = Math.max(liquifyMaxDisplacement, newMax);
        // ROI geométrica: solo rectangulo envolvente de las celdas que han
        // cambiado, ANTES y DESPUES. El radio+maxDesplazamiento era mucho mayor
        // y hacia que la preview recalculara cientos de miles de pixeles de mas.
        float minWX = Float.POSITIVE_INFINITY, minWY = Float.POSITIVE_INFINITY;
        float maxWX = Float.NEGATIVE_INFINITY, maxWY = Float.NEGATIVE_INFINITY;
        for (int gy = copyY0; gy <= copyY1; gy++) {
            float oy = Math.min(project.h - 1f, gy * liquifyGridStep);
            for (int gx = copyX0; gx <= copyX1; gx++) {
                float ox = Math.min(project.w - 1f, gx * liquifyGridStep);
                int i = gy * liquifyGridCols + gx;
                float oldX = ox + liquifyDxTmp[i], newX = ox + liquifyDx[i];
                float oldY = oy + liquifyDyTmp[i], newY = oy + liquifyDy[i];
                minWX = Math.min(minWX, Math.min(oldX, newX));
                minWY = Math.min(minWY, Math.min(oldY, newY));
                maxWX = Math.max(maxWX, Math.max(oldX, newX));
                maxWY = Math.max(maxWY, Math.max(oldY, newY));
            }
        }
        Rect dirty = new Rect((int)Math.floor(minWX) - 3, (int)Math.floor(minWY) - 3,
                (int)Math.ceil(maxWX) + 4, (int)Math.ceil(maxWY) + 4);
        clamp(dirty);
        if (dirty.isEmpty()) return null;
        if (!preDirty.contains(dirty)) {
            captureLiquifyBase(dirty);
            if (!captureEffectStrokeBackup(dirty)) return null;
        }
        markLiquifyDirty(dirty);
        return dirty;
    }

    private final float[] liquifySample = new float[2];

    /** Unico sampler usado durante el trazo y al confirmar. NO hay bloques 4x4. */
    private void renderLiquifyRegion(Rect r) {
        if (r == null || r.isEmpty() || strokeLayer == null || project == null) return;
        int pad = (int)Math.ceil(liquifyMaxDisplacement + 4f);
        boolean buffered = prepareLiquifySourceBuffer(r, pad);
        if (!buffered) {
            // No reutilizar por accidente el buffer de otra region.
            liquifySourceBufferRect.setEmpty();
            liquifySourceBufferW = liquifySourceBufferH = 0;
        }
        int[] dst = strokeLayer.px();
        for (int y = r.top; y < r.bottom; y++) {
            int row = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                // Las zonas sin desplazamiento conservan el original exacto;
                // evita Newton + interpolacion en los margenes del rectangulo.
                sampleLiquifyWithJacobian(x + .5f, y + .5f, liquifyDifferential);
                int warped;
                if (Math.abs(liquifyDifferential[0]) + Math.abs(liquifyDifferential[1]) < .002f) {
                    warped = liquifyOriginalAt(x, y, dst[row + x]);
                } else {
                    invertLiquify(x + .5f, y + .5f, liquifySample);
                    warped = sampleLiquifyBuffered(liquifySample[0] - .5f, liquifySample[1] - .5f);
                }
                int i = row + x;
                if (selectionActive) {
                    float sel = selectionFactor(i);
                    int base = liquifyOriginalAt(x, y, dst[i]);
                    dst[i] = sel <= .001f ? base : sel >= .999f ? warped
                            : com.pacco.animecut.core.AlphaColors.mix(base, warped, sel);
                } else {
                    dst[i] = warped;
                }
            }
        }
    }

    /** El dibujo visible es la capa renderizada por el mismo sampler del resultado.
     * Se conserva la imagen ya procesada fuera de la ROI actual, sin ghosting. */
    private void maybeRenderLiquifyPreview() {
        if (!liquifyPreviewDirtyValid || strokeLayer == null) return;
        long now = android.os.SystemClock.uptimeMillis();
        if (now - liquifyLastPreviewMs < liquifyPreviewIntervalMs) return;
        Rect r = new Rect(liquifyPreviewDirty);
        liquifyPreviewDirty.setEmpty();
        liquifyPreviewDirtyValid = false;
        // No gastar CPU en zonas fuera de pantalla durante el gesto. El commit
        // sigue renderizando TODOS los tiles afectados a resolucion completa.
        Rect visible = visibleDetail();
        if (visible != null && !r.intersect(visible)) return;
        long begin = android.os.SystemClock.uptimeMillis();
        renderLiquifyRegion(r);
        updateDisplayRegion(r);
        // En el móvil rápido cabe otra vista previa antes; en el lento,
        // ceder más tiempo a los eventos táctiles evita atascar el zoom.
        long end = android.os.SystemClock.uptimeMillis();
        long cost = Math.max(1L, end - begin);
        liquifyPreviewIntervalMs = Math.max(LIQUIFY_PREVIEW_MIN_MS,
                Math.min(95L, (long) (cost * 1.2f)));
        liquifyLastPreviewMs = end;
    }

    private void renderLiquifyFinalTiles() {
        if (project == null || strokeLayer == null || liquifyDirtyTiles.size() == 0) return;
        int cols = (project.w + LIQUIFY_TILE - 1) / LIQUIFY_TILE;
        beginBatch();
        try {
            // En vez de copiar una fuente + muestrear 64x64 por cada tile,
            // agrupar tiles adyacentes por filas. Menos buffers y menos dispatch.
            int n = 0;
            while (n < liquifyDirtyTiles.size()) {
                int key = liquifyDirtyTiles.keyAt(n++);
                int tx0 = key % cols, ty = key / cols;
                int tx1 = tx0;
                while (n < liquifyDirtyTiles.size()
                        && liquifyDirtyTiles.keyAt(n) == ty * cols + tx1 + 1) {
                    tx1++;
                    n++;
                }
                Rect r = new Rect(tx0 * LIQUIFY_TILE, ty * LIQUIFY_TILE,
                        Math.min(project.w, (tx1 + 1) * LIQUIFY_TILE),
                        Math.min(project.h, (ty + 1) * LIQUIFY_TILE));
                renderLiquifyRegion(r);
                updateDisplayRegion(r);
            }
        } finally {
            endBatch();
        }
        liquifyDirtyTiles.clear();
        liquifyPreviewDirty.setEmpty();
        liquifyPreviewDirtyValid = false;
    }

    private void moveEffectStroke(float x, float y) {
        float dx = x - lastX, dy = y - lastY;
        float dist = (float) Math.hypot(dx, dy);
        if (dist < 0.08f) return;

        // Espaciado adaptado a cada efecto. Borrosidad no necesita tantos stamps
        // superpuestos; Especial usa algo mas de muestras pero con deformacion mas
        // fuerte. Esto elimina trabajo repetido sin dejar huecos visibles.
        float step;
        if (mode == MODE_LIQUIFY) step = Math.max(2.5f, brushRadius * 0.28f);
        else if (mode == MODE_BLUR) step = Math.max(1.5f, brushRadius * 0.55f);
        else step = Math.max(1f, brushRadius * 0.36f);
        int n = Math.max(1, (int) Math.ceil(dist / step));
        // No truncar a seis puntos: el gesto rapido conserva muestras espaciales.
        // Un limite de seguridad alto protege ante eventos anormalmente grandes.
        n = Math.min(n, mode == MODE_LIQUIFY ? 32 : 48);
        float px = lastX, py = lastY;
        beginBatch();
        try {
            for (int i = 1; i <= n; i++) {
                float t = i / (float) n;
                float nx = lastX + dx * t, ny = lastY + dy * t;
                stampEffect(nx, ny, nx - px, ny - py);
                px = nx; py = ny;
            }
        } finally {
            endBatch();
        }
        lastX = x; lastY = y;
    }

    private void stampEffect(float cx, float cy, float dx, float dy) {
        if (!drawing || strokeLayer == null) return;
        if ((mode == MODE_SMUDGE || (mode == MODE_LIQUIFY && liquifyType == 0))
                && Math.abs(dx) + Math.abs(dy) < 0.02f) return;
        Rect out = disk(cx, cy);
        if (out == null) return;

        if (mode == MODE_LIQUIFY) {
            Rect dirty = effectLiquifyField(cx, cy, dx, dy, liquifyType);
            if (dirty == null) return;
            grow(dirty);
            // Preview y commit comparten exactamente el mismo remapeador.
            maybeRenderLiquifyPreview();
            painted++;
            return;
        }

        // Difuminar/Borrosidad conservan el motor local anterior.
        if (!captureEffectStrokeBackup(out)) return;
        if (mode == MODE_BLUR) effectBlur(cx, cy, out);
        else if (mode == MODE_SMUDGE) effectWarp(cx, cy, dx, dy, out, 0);
        grow(out);
        updateDisplayRegion(out);
        painted++;
    }

    private void effectBlur(float cx, float cy, Rect out) {
        int w = project.w, h = project.h;
        // Un pixel de margen basta para el kernel 3x3. La version anterior copiaba
        // mas zona y despues leia nueve pixeles por cada pixel del pincel.
        Rect srcR = new Rect(Math.max(0, out.left - 1), Math.max(0, out.top - 1),
                Math.min(w, out.right + 1), Math.min(h, out.bottom + 1));
        int rw = srcR.width(), rh = srcR.height();
        int need = rw * rh;
        if (!ensureEffectTmp(need) || !ensureBlurColumns(rw)) return;
        int[] px = strokeLayer.px();
        for (int yy = 0; yy < rh; yy++)
            System.arraycopy(px, (srcR.top + yy) * w + srcR.left, effectTmp, yy * rw, rw);

        float str = Math.max(.05f, Math.min(1f, effectStrength));
        for (int y = out.top; y < out.bottom; y++) {
            int ly = y - srcR.top;
            int sy0 = Math.max(0, ly - 1), sy1 = Math.max(0, Math.min(rh - 1, ly));
            int sy2 = Math.min(rh - 1, ly + 1);
            int o0 = sy0 * rw, o1 = sy1 * rw, o2 = sy2 * rw;

            // Suma vertical de tres filas una sola vez. Luego cada pixel toma tres
            // columnas: 3 lecturas efectivas en vez de 9.
            for (int lx = 0; lx < rw; lx++) {
                int c0 = effectTmp[o0 + lx], c1 = effectTmp[o1 + lx], c2 = effectTmp[o2 + lx];
                blurColA[lx] = (c0 >>> 24) + (c1 >>> 24) + (c2 >>> 24);
                // Mantener RGB premultiplicado por alpha evita halos oscuros
                // cuando las partes se exportan sobre fondo transparente.
                blurColR[lx] = ((c0 >> 16) & 255) * (c0 >>> 24)
                        + ((c1 >> 16) & 255) * (c1 >>> 24)
                        + ((c2 >> 16) & 255) * (c2 >>> 24);
                blurColG[lx] = ((c0 >> 8) & 255) * (c0 >>> 24)
                        + ((c1 >> 8) & 255) * (c1 >>> 24)
                        + ((c2 >> 8) & 255) * (c2 >>> 24);
                blurColB[lx] = (c0 & 255) * (c0 >>> 24)
                        + (c1 & 255) * (c1 >>> 24)
                        + (c2 & 255) * (c2 >>> 24);
            }

            int row = y * w;
            for (int x = out.left; x < out.right; x++) {
                float f = fastBrushFalloff(x, y, cx, cy) * str * selectionFactor(row + x);
                if (f <= .001f) continue;
                int lx = x - srcR.left;
                int x0 = Math.max(0, lx - 1), x1 = Math.max(0, Math.min(rw - 1, lx));
                int x2 = Math.min(rw - 1, lx + 1);
                int as = blurColA[x0] + blurColA[x1] + blurColA[x2];
                int aa = as / 9;
                if (as <= 0) continue;
                int rr = (blurColR[x0] + blurColR[x1] + blurColR[x2]) / as;
                int gg = (blurColG[x0] + blurColG[x1] + blurColG[x2]) / as;
                int bb = (blurColB[x0] + blurColB[x1] + blurColB[x2]) / as;
                int avg = (aa << 24) | (rr << 16) | (gg << 8) | bb;
                px[row + x] = com.pacco.animecut.core.AlphaColors.mix(px[row + x], avg, f);
            }
        }
        project.markDirty();
    }

    /** Falloff del pincel sin sqrt por pixel: conserva centro firme y borde suave. */
    private float fastBrushFalloff(int x, int y, float cx, float cy) {
        float dx = x + .5f - cx, dy = y + .5f - cy;
        float r = Math.max(1f, rad());
        float outer = r + .5f;
        float d2 = dx * dx + dy * dy, o2 = outer * outer;
        if (d2 >= o2) return 0f;
        float inner = Math.max(0f, Math.min(r, r * hardness));
        float i2 = inner * inner;
        if (d2 <= i2) return 1f;
        float u = (o2 - d2) / Math.max(1f, o2 - i2);
        u = Math.max(0f, Math.min(1f, u));
        return u * u * (3f - 2f * u);
    }

    private boolean ensureBlurColumns(int n) {
        try {
            if (blurColA == null || blurColA.length < n) {
                int cap = Math.max(n, n + n / 4);
                blurColA = new int[cap];
                blurColR = new int[cap];
                blurColG = new int[cap];
                blurColB = new int[cap];
            }
            return true;
        } catch (OutOfMemoryError e) {
            blurColA = blurColR = blurColG = blurColB = null;
            msg("No alcanzo memoria para este tamano de Borrosidad");
            return false;
        }
    }

    /** Motor antiguo usado solo por Difuminar. */
    private void effectWarp(float cx, float cy, float dragX, float dragY, Rect out, int type) {
        int w = project.w, h = project.h;
        float r = Math.max(1f, brushRadius), r2 = r * r;
        float base = Math.max(.03f, Math.min(1f, effectStrength));
        boolean special = false;

        // Limita saltos de eventos sin volver el efecto debil. En Arrastrar el
        // desplazamiento sigue el dedo, pero nunca estira una franja enorme de golpe.
        float drag = (float) Math.hypot(dragX, dragY);
        float maxDrag = Math.max(1f, r * (special ? .24f : .14f));
        if (drag > maxDrag && drag > .0001f) {
            float k = maxDrag / drag;
            dragX *= k;
            dragY *= k;
            drag = maxDrag;
        }

        float extra;
        if (type == 0) extra = drag * (special ? 1.05f : .90f) + 4f;
        else if (type == 1 || type == 2) extra = r * (.12f + .18f * base) + 4f;
        else extra = r * .08f + 4f;

        int pad = Math.max(4, (int) Math.ceil(extra));
        Rect srcR = new Rect(Math.max(0, out.left - pad), Math.max(0, out.top - pad),
                Math.min(w, out.right + pad), Math.min(h, out.bottom + pad));
        int rw = srcR.width(), rh = srcR.height(), need = rw * rh;
        if (!ensureEffectTmp(need)) return;
        int[] px = strokeLayer.px();
        for (int yy = 0; yy < rh; yy++)
            System.arraycopy(px, (srcR.top + yy) * w + srcR.left, effectTmp, yy * rw, rw);

        // Suavidad modifica la fuerza geometrica cerca del borde. No mezcla colores:
        // el pixel se mueve, no se difumina.
        float soft = Math.max(0f, Math.min(1f, effectSoftness));
        float innerFrac = .84f - .46f * soft;
        innerFrac = Math.max(.28f, Math.min(.88f, innerFrac));
        float inner2 = r2 * innerFrac * innerFrac;
        float denom = Math.max(1f, r2 - inner2);

        for (int y = out.top; y < out.bottom; y++) {
            int row = y * w;
            for (int x = out.left; x < out.right; x++) {
                float vx = x + .5f - cx, vy = y + .5f - cy;
                float d2 = vx * vx + vy * vy;
                if (d2 >= r2) continue;

                float fall;
                if (d2 <= inner2) fall = 1f;
                else {
                    float q = (r2 - d2) / denom;
                    q = Math.max(0f, Math.min(1f, q));
                    fall = q * q * (3f - 2f * q);
                }
                if (fall <= .001f) continue;

                float sel = selectionFactor(row + x);
                if (sel <= .001f) continue;
                float weight = fall * sel;
                float sx = x + .5f, sy = y + .5f;

                if (type == 0) {
                    if (special) {
                        // Arrastrar tipo Licuar: la geometria sigue el dedo. El falloff
                        // reduce el desplazamiento hacia el borde, no la nitidez.
                        float gain = (.72f + .24f * base) * weight;
                        sx -= dragX * gain;
                        sy -= dragY * gain;
                    } else {
                        float gain = (.35f + .65f * base) * weight;
                        sx -= dragX * gain;
                        sy -= dragY * gain;
                    }
                } else if (type == 1) {
                    // Contraer: trae la textura hacia el centro.
                    float k = 1f + (.045f + .115f * base) * weight;
                    sx = cx + vx * k;
                    sy = cy + vy * k;
                } else if (type == 2) {
                    // Expandir: empuja la textura hacia afuera.
                    float k = Math.max(.76f, 1f - (.045f + .115f * base) * weight);
                    sx = cx + vx * k;
                    sy = cy + vy * k;
                } else {
                    // Remolino local. El angulo cae suavemente hasta cero en el borde.
                    float a = (.045f + .16f * base) * weight;
                    float a2 = a * a;
                    float sn = a * (1f - a2 / 6f);
                    float cs = 1f - a2 * .5f;
                    sx = cx + vx * cs + vy * sn;
                    sy = cy - vx * sn + vy * cs;
                }

                int sample = sampleTmpBilinear(sx - srcR.left, sy - srcR.top, rw, rh);
                float blend = Math.min(1f, weight * (.34f + .46f * base));
                if (blend > .001f) px[row + x] = mixArgb(px[row + x], sample, blend);
            }
        }
        project.markDirty();
    }

    private void effectRestore(float cx, float cy, Rect out) {
        ensureLiquifyBase(strokeLayer);
        if (liquifyBaseLayer != strokeLayer || liquifyBaseTiles.size() == 0) return;
        int w = project.w;
        int[] px = strokeLayer.px();
        float str = Math.max(.03f, Math.min(1f, effectStrength));
        float r = Math.max(1f, brushRadius), r2 = r * r;
        float soft = Math.max(0f, Math.min(1f, effectSoftness));
        float innerFrac = .78f * (1f - soft);
        float inner2 = r2 * innerFrac * innerFrac;
        float denom = Math.max(1f, r2 - inner2);
        for (int y = out.top; y < out.bottom; y++) {
            int row = y * w;
            for (int x = out.left; x < out.right; x++) {
                float dx = x + .5f - cx, dy = y + .5f - cy;
                float d2 = dx * dx + dy * dy;
                if (d2 >= r2) continue;
                float fall;
                if (d2 <= inner2) fall = 1f;
                else {
                    float q = (r2 - d2) / denom;
                    q = Math.max(0f, Math.min(1f, q));
                    fall = q * q * (3f - 2f * q);
                }
                float f = fall * str * selectionFactor(row + x);
                if (f <= .001f) continue;
                int original = liquifyOriginalAt(x, y, px[row + x]);
                px[row + x] = mixArgb(px[row + x], original, Math.min(1f, f));
            }
        }
        project.markDirty();
    }

    private float selectionFactor(int i) {
        if (!selectionActive || project == null || project.selection == null) return 1f;
        return (project.selection[i] & 255) / 255f;
    }

    private boolean ensureEffectTmp(int n) {
        try {
            if (effectTmp == null || effectTmp.length < n) effectTmp = new int[Math.max(n, n + n / 4)];
            return true;
        } catch (OutOfMemoryError e) {
            effectTmp = null;
            msg("No alcanzo la memoria para este pincel");
            return false;
        }
    }

    private int sampleTmpNearest(float x, float y, int w, int h) {
        if (w <= 0 || h <= 0) return 0;
        int ix = Math.max(0, Math.min(w - 1, Math.round(x)));
        int iy = Math.max(0, Math.min(h - 1, Math.round(y)));
        return effectTmp[iy * w + ix];
    }

    private int sampleTmpBilinear(float x, float y, int w, int h) {
        if (w <= 0 || h <= 0) return 0;
        x = Math.max(0f, Math.min(w - 1.001f, x));
        y = Math.max(0f, Math.min(h - 1.001f, y));
        int x0 = (int) x, y0 = (int) y;
        int x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
        float fx = x - x0, fy = y - y0;
        int a = mixArgb(effectTmp[y0 * w + x0], effectTmp[y0 * w + x1], fx);
        int b = mixArgb(effectTmp[y1 * w + x0], effectTmp[y1 * w + x1], fx);
        return mixArgb(a, b, fy);
    }

    private static int mixArgb(int a, int b, float t) {
        if (t <= 0f) return a;
        if (t >= 1f) return b;
        float u = 1f - t;
        int aa = (int) (((a >>> 24) * u) + ((b >>> 24) * t) + .5f);
        int rr = (int) ((((a >> 16) & 255) * u) + (((b >> 16) & 255) * t) + .5f);
        int gg = (int) ((((a >> 8) & 255) * u) + (((b >> 8) & 255) * t) + .5f);
        int bb = (int) (((a & 255) * u) + ((b & 255) * t) + .5f);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }

    // ==================================================================
    // Capas
    // ==================================================================

    public void layersChanged() {
        project.markDirty();
        if (undo != null) undo.rebalance();
        wire = null;
        refreshDisplay();
        changed();
    }

    public void setActive(int i) {
        if (project == null) return;
        if (i >= project.layers.size()) return;
        if (i < Project.SEL) return;
        if (i >= 0) lastNormalLayer = project.layers.get(i);
        if (project.active == i) return;
        project.active = i;
        // antes se empacaba aqui mismo y el toque se trababa; ahora va despues,
        // y si falta memoria al pintar, ensureMemory empaca en ese momento
        changed();
    }

    public void addEmptyLayer() {
        undo.setLabel("Capa nueva");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        project.layers.add(Math.min(at, project.layers.size()),
                new Layer(uniqueName("capa"), project.w, project.h));
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
    }

    /** Crea una capa de pintura en modo Superponer y la deja activa. */
    public void addOverlayPaintLayer() {
        if (project == null) return;
        undo.setLabel("Capa Superposición");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        Layer l = new Layer(uniqueName("Superposición"), project.w, project.h);
        l.mode = Layer.MODE_OVERLAY;
        project.layers.add(Math.min(at, project.layers.size()), l);
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
        mode = MODE_PAINT;
        showHud("Capa Superposición lista para pintar");
    }

    /** Una imagen de afuera como capa nueva, centrada y ajustada al lienzo. */
    public void addImageLayer(Bitmap img) {
        // va directo a la memoria grande del telefono, sin pasar por la de Java
        float s = Math.min((float) project.w / img.getWidth(), (float) project.h / img.getHeight());
        int tw = Math.max(1, Math.round(img.getWidth() * s)), th = Math.max(1, Math.round(img.getHeight() * s));
        Layer nl;
        try {
            Bitmap sc = Bitmap.createScaledBitmap(img, tw, th, true);
            Bitmap crop = Layer.newBitmap(tw, th);
            int[] row = new int[tw];
            for (int y = 0; y < th; y++) {
                sc.getPixels(row, 0, tw, 0, y, tw, 1);
                crop.setPixels(row, 0, tw, 0, y, tw, 1);
            }
            if (sc != img) sc.recycle();
            int ox = (project.w - tw) / 2, oy = (project.h - th) / 2;
            nl = Layer.fromBitmap(uniqueName("imagen"), ox, oy, crop, project.w, project.h);
        } catch (OutOfMemoryError e) {
            msg("La imagen es muy grande para agregarla");
            return;
        }
        undo.setLabel("Agregar imagen");
        undo.recordStruct();
        int at = Math.max(0, project.active + 1);
        project.layers.add(Math.min(at, project.layers.size()), nl);
        project.active = Math.min(at, project.layers.size() - 1);
        layersChanged();
    }

    // ---- propiedades de la capa elegida (como Ibis) ----

    public void setLayerMode(Layer l, int mode) {
        if (l == null) return;
        l.mode = mode;
        layersChangedAsync();
    }

    public void setLayerClip(Layer l, boolean on) {
        if (l == null) return;
        if (on && project.layers.indexOf(l) <= 0) {
            msg("La capa de mas abajo no puede tener recorte: no hay base");
            return;
        }
        l.clip = on;
        layersChangedAsync();
    }

    public void setLayerAlphaLock(Layer l, boolean on) {
        if (l == null) return;
        l.alphaLock = on;
        changed();
    }

    /**
     * Preparar para colorear (flujo de Ibis): de la imagen elegida saca la
     * linea negra a una capa transparente en Multiplicar, arriba de todo, y
     * pone debajo una capa vacia "color" para pintar sin tapar la linea.
     */
    public void prepareForColoring(final int white, final int black) {
        final Layer src = needLayer();
        if (src == null) return;
        final int w = project.w, h = project.h;
        final int[] copy;
        try {
            copy = new int[w * h];
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria. Borra o combina alguna capa.");
            return;
        }
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                src.copyTo(copy, w, h);
                int span = Math.max(1, white - black);
                for (int i = 0; i < copy.length; i++) {
                    int c = copy[i];
                    int a0 = c >>> 24;
                    if (a0 == 0) {
                        copy[i] = 0;
                        continue;
                    }
                    int lum = (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
                    // blanco -> transparente, negro -> linea llena
                    int a = (white - lum) * 255 / span;
                    if (a < 0) a = 0;
                    if (a > 255) a = 255;
                    a = a * a0 / 255;
                    copy[i] = a == 0 ? 0 : (a << 24);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                undo.setLabel("Preparar para colorear");
                undo.recordStruct();
                Layer line = new Layer(uniqueName("linea"), copy);
                line.mode = Layer.MODE_MULTIPLY;
                Layer color = new Layer(uniqueName("color"), w, h);
                project.layers.add(line);
                int at = project.layers.size() - 1;
                project.layers.add(at, color);
                project.active = project.layers.indexOf(color);
                layersChanged();
                msg("Listo: pinta en la capa \"color\". La linea queda arriba y no se tapa");
            }
        });
    }

    public void duplicateActive() {
        Layer a = target();
        if (a == null) {
            msg("Toca una capa para duplicarla");
            return;
        }
        Layer copy;
        try {
            copy = a.copy(uniqueName(a.name), project.w, project.h);
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para duplicar. Combina o borra alguna capa.");
            return;
        }
        undo.setLabel("Duplicar");
        undo.recordStruct();
        project.layers.add(project.active + 1, copy);
        project.active++;
        layersChanged();
    }

    /** Lo seleccionado de la capa elegida pasa a una capa nueva. Con cortar, se quita de la original. */
    public void layerFromSelection(boolean cut) {
        layerFromSelection(cut, 0, null);
    }

    /**
     * Crea una parte lista para animar. overlap conserva unos pixeles extra
     * alrededor de la seleccion para que al rotar brazos/cabeza en Alight Motion
     * no aparezcan huecos en las uniones. Al cortar, se elimina solo el nucleo
     * seleccionado y el solapamiento queda compartido entre ambas capas.
     */
    public void layerFromSelection(boolean cut, int overlap, String preferredName) {
        Layer a = target();
        if (a == null && project != null && !project.layers.isEmpty()) {
            if (lastNormalLayer != null && project.layers.contains(lastNormalLayer)) a = lastNormalLayer;
            else a = project.layers.get(Math.max(0, project.layers.size() - 1));
        }
        if (a == null) {
            msg("Toca en Capas la capa de donde quieres sacar la parte");
            return;
        }
        final int sourceIndex = project.layers.indexOf(a);
        if (sourceIndex < 0) {
            msg("No se encontro la capa origen");
            return;
        }
        if (!project.hasSelection()) {
            msg("Primero marca en azul la parte");
            return;
        }
        Rect core = selectionBoundsAny();
        if (core == null || core.isEmpty()) {
            msg("Primero marca en azul la parte");
            return;
        }
        overlap = Math.max(0, Math.min(24, overlap));
        Rect sb = new Rect(core);
        int pad = overlap + 2;
        sb.inset(-pad, -pad);
        clamp(sb);
        int w = project.w;
        int cw = sb.width(), ch = sb.height();
        if (!ensureMemory((long) cw * ch * 6L)) return;
        int[] crop;
        byte[] localSel;
        int[] apx;
        try {
            crop = new int[cw * ch];
            localSel = new byte[cw * ch];
            apx = a.px();
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para crear la capa. Combina o borra alguna capa.");
            return;
        }
        for (int y = 0; y < ch; y++)
            System.arraycopy(project.selection, (sb.top + y) * w + sb.left, localSel, y * cw, cw);
        if (overlap > 0) {
            MaskOps.dilate(localSel, cw, ch, overlap);
            if (overlap >= 3) MaskOps.feather(localSel, cw, ch, 1);
        }
        for (int y = 0; y < ch; y++) {
            int so = (sb.top + y) * w + sb.left, lo = y * cw;
            for (int x = 0; x < cw; x++) {
                int s = localSel[lo + x] & 0xFF;
                if (s == 0) continue;
                int c = apx[so + x];
                int al = ((c >>> 24) * s) / 255;
                if (al > 0) crop[lo + x] = (al << 24) | (c & 0x00FFFFFF);
            }
        }
        undo.setLabel(cut ? "Cortar parte" : "Crear parte");
        undo.begin();
        undo.recordStruct();
        if (cut) {
            undo.recordLayer(a, core);
            for (int y = core.top; y < core.bottom; y++) {
                int off = y * w;
                for (int x = core.left; x < core.right; x++) {
                    int i = off + x;
                    int sv = project.selection[i] & 0xFF;
                    if (sv == 0) continue;
                    int c = apx[i];
                    int al = ((c >>> 24) * (255 - sv)) / 255;
                    apx[i] = (al << 24) | (c & 0x00FFFFFF);
                }
            }
        }
        undo.end();
        String base = preferredName == null ? "parte" : preferredName.trim();
        if (base.length() == 0) base = "parte";
        int insertAt = Math.min(project.layers.size(), sourceIndex + 1);
        project.layers.add(insertAt,
                Layer.fromCrop(uniqueName(base), sb.left, sb.top, cw, ch, project.w, project.h, crop));
        project.active = insertAt;
        lastNormalLayer = project.layers.get(insertAt);
        layersChanged();
        showHud((cut ? "Parte cortada" : "Parte creada")
                + (overlap > 0 ? " con " + overlap + " px de solapamiento" : ""));
    }

    /** Rectangulo de todo lo azul, incluido lo muy suave del borde. */
    private Rect selectionBoundsAny() {
        byte[] m = project.selection;
        int w = project.w, h = project.h;
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (m[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** Combina la capa elegida con la de abajo, como en Ibis. */
    public void mergeDown() {
        Layer a = target();
        int i = project.active;
        if (a == null || i <= 0) {
            msg("No hay capa abajo para combinar");
            return;
        }
        Layer below = project.layers.get(i - 1);
        Rect ab = a.bounds(project.w, project.h);
        if (!ensureMemory((long) project.w * project.h * 4)) return;
        try {
            below.px();
        } catch (OutOfMemoryError e) {
            msg("No alcanzo la memoria para combinar. Borra alguna capa.");
            return;
        }
        undo.setLabel("Combinar");
        undo.begin();
        undo.recordStruct();
        if (ab != null) undo.recordLayer(below, ab);
        undo.end();
        if (ab != null) {
            int[] bp = below.px(), ap = a.px();
            int w = project.w;
            for (int y = ab.top; y < ab.bottom; y++) {
                for (int x = ab.left; x < ab.right; x++) {
                    int k = y * w + x;
                    int c = ap[k];
                    int ca = c >>> 24;
                    if (a.clip) ca = ca * (bp[k] >>> 24) / 255;
                    int sa = (ca * a.opacity) / 255;
                    if (sa > 0) bp[k] = Project.over(bp[k], a.mode == 0 ? c : Project.mixMode(bp[k], c, a.mode), sa);
                }
            }
        }
        project.layers.remove(i);
        a.pack(project.w, project.h);
        project.active = i - 1;
        layersChanged();
    }

    public void deleteActive() {
        if (target() == null) return;
        if (project.layers.size() <= 1) {
            msg("Tiene que quedar al menos una capa");
            return;
        }
        undo.setLabel("Eliminar capa");
        undo.recordStruct();
        Layer gone = project.layers.remove(project.active);
        gone.pack(project.w, project.h);
        project.active = Math.min(project.active, project.layers.size() - 1);
        layersChanged();
    }

    public void moveActive(int delta) {
        int i = project.active, t = i + delta;
        if (i < 0 || t < 0 || t >= project.layers.size()) return;
        undo.setLabel("Ordenar capas");
        undo.recordStruct();
        Layer a = project.layers.get(i);
        project.layers.set(i, project.layers.get(t));
        project.layers.set(t, a);
        project.active = t;
        layersChanged();
    }

    public void clearActive() {
        Layer t = needLayer();
        if (t == null) return;
        undo.setLabel("Limpiar capa");
        undo.recordLayer(t, project.fullRect());
        if (project.hasSelection()) {
            for (int i = 0; i < t.px().length; i++) {
                int s = project.selection[i] & 0xFF;
                int al = ((t.px()[i] >>> 24) * (255 - s)) / 255;
                t.px()[i] = (al << 24) | (t.px()[i] & 0x00FFFFFF);
            }
        } else {
            Arrays.fill(t.px(), 0);
        }
        layersChanged();
    }

    /** Borrar area: quita de la capa lo que esta en azul. */
    public void eraseSelectionFromLayer() {
        if (!project.hasSelection()) {
            msg("No hay nada en azul");
            return;
        }
        clearActive();
    }

    /** Dejar solo esto: en la capa queda solo lo azul. */
    public void keepSelectionInLayer() {
        Layer t = needLayer();
        if (t == null || !needHole()) return;
        undo.setLabel("Dejar solo esto");
        undo.recordLayer(t, project.fullRect());
        for (int i = 0; i < t.px().length; i++) {
            int s = project.selection[i] & 0xFF;
            int al = ((t.px()[i] >>> 24) * s) / 255;
            t.px()[i] = (al << 24) | (t.px()[i] & 0x00FFFFFF);
        }
        layersChanged();
    }

    private String uniqueName(String base) {
        int n = 1;
        while (true) {
            String cand = base + "_" + n;
            boolean clash = false;
            for (Layer l : project.layers) if (l.name.equals(cand)) {
                clash = true;
                break;
            }
            if (!clash) return cand;
            n++;
        }
    }

    // ==================================================================
    // Seleccion: acciones del menu
    // ==================================================================

    public void clearTemporarySelectionAfterCopy() {
        if (project == null || !project.hasSelection()) return;
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void clearSelection() {
        if (project == null) return;
        undo.setLabel("Quitar seleccion");
        undo.recordSelection(project.fullRect());
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void invertSelection() {
        if (project == null) return;
        undo.setLabel("Invertir");
        undo.recordSelection(project.fullRect());
        MaskOps.invert(project.selection);
        refreshOverlay(null);
        changed();
    }

    /** kind: 0 expandir, 1 contraer, 2 suavizar, 3 endurecer, 4 cerrar puntos, 5 zonas encerradas */
    public void edgeOp(final int kind, final int radius) {
        if (project == null) return;
        if (!project.hasSelection()) {
            msg("Primero marca algo en azul (con la varita o el lazo). Esto trabaja sobre lo azul.");
            return;
        }
        final long before = selectionSum();
        setBusy(true);
        undo.setLabel("Borde");
        undo.recordSelection(project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                byte[] s = project.selection;
                switch (kind) {
                    case 0:
                        MaskOps.dilate(s, project.w, project.h, radius);
                        break;
                    case 1:
                        MaskOps.erode(s, project.w, project.h, radius);
                        break;
                    case 2:
                        MaskOps.feather(s, project.w, project.h, radius);
                        break;
                    case 4:
                        MaskOps.closeHoles(s, project.w, project.h, radius);
                        break;
                    case 5:
                        MaskOps.fillEnclosed(s, project.w, project.h, radius <= 0 ? 0 : radius * 400);
                        break;
                    default:
                        MaskOps.threshold(s, 128);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
                if (kind == 4 || kind == 5) {
                    long diff = selectionSum() - before;
                    showHud(diff > 0 ? "Listo: se rellenaron los huequitos dentro de lo azul"
                            : "No habia huequitos que cerrar dentro de lo azul");
                }
            }
        });
    }

    private long selectionSum() {
        long t = 0;
        for (byte b : project.selection) t += b & 0xFF;
        return t;
    }

    public void expandSelection(final float px) {
        if (project == null) return;
        if (!project.hasSelection()) {
            msg("Primero marca algo en azul (con la varita o el lazo)");
            return;
        }
        setBusy(true);
        undo.setLabel("Ampliar");
        undo.recordSelection(project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                MaskOps.expandSubpixel(project.selection, project.w, project.h, px, null);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void refineEdge(final int radius, final float eps) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Refinar borde");
        undo.recordSelection(project.fullRect());
        final Rect area = project.selectionBounds();
        Task.run(new Runnable() {
            @Override
            public void run() {
                GuidedFilter.refine(project.selection, project.ref(), project.w, project.h, radius, eps, area);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void buildBarrier(final int threshold, final int closeGap) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                project.barrier = LineArt.build(project.ref(), project.w, project.h, threshold, closeGap);
                gapBarrier = null;
            }
        }, new Runnable() {
            @Override
            public void run() {
                useBarrier = true;
                setBusy(false);
                showHud("En rojo: lo que la varita toma como linea");
                showRedLines(project.barrier);
                changed();
            }
        });
    }

    /** kind: 0 mediana, 1 posterizar, 2 niveles, 3 extraer line art. Sobre la capa elegida. */
    public void applyFilter(final int kind, final int a, final int b, final int c) {
        final Layer t = needLayer();
        if (t == null) return;
        setBusy(true);
        undo.setLabel("Filtro");
        undo.recordLayer(t, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        Filters.median3(t.px(), project.w, project.h);
                        break;
                    case 1:
                        Filters.posterize(t.px(), a);
                        break;
                    case 2:
                        Filters.levels(t.px(), a, b, c / 100f);
                        break;
                    default:
                        Filters.extractLineArt(t.px(), project.w, project.h, a, b, c);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                layersChanged();
            }
        });
    }

    public void transform(final int kind) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (kind == 0) project.rotate90(true);
                else if (kind == 1) project.rotate90(false);
                else project.flip(kind == 2);
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.clear();
                scratch = selBackup = gapBarrier = gradient = markers = patchSource = repairLines = null;
                pxBackup = null;
                clearEffectStrokeBackup();
                clearSelectionStrokeBackup();
                if (markersOverlay != null) markersOverlay.recycle();
                if (patchOverlay != null) patchOverlay.recycle();
                markersOverlay = patchOverlay = null;
                wire = null;
                scissorsReset();
                buildDisplay();
                buildOverlay();
                fit();
                setBusy(false);
                showHud("Listo. El historial se reinicia al girar");
                changed();
            }
        });
    }

    // ==================================================================
    // Deshacer
    // ==================================================================

    public void doUndo() {
        if (isShapeTool() && !shapePts.isEmpty()) {
            shapePts.remove(shapePts.size() - 1);
            shapeSel = shapePts.size() - 1;
            invalidate();
            return;
        }
        if (undo == null) return;
        Rect r = undo.undo();
        afterRestore(r, "Deshacer");
    }

    public void doRedo() {
        if (undo == null) return;
        Rect r = undo.redo();
        afterRestore(r, "Rehacer");
    }

    private void afterRestore(Rect r, String word) {
        if (r == null) {
            showHud(word.equals("Deshacer") ? "Nada que deshacer" : "Nada que rehacer");
            return;
        }
        wire = null;
        // Si Deshacer/Rehacer cambia la capa, el campo de Licuar anterior ya no
        // corresponde a esos pixeles. Se reinicia sin tocar el resultado restaurado.
        if (mode == MODE_LIQUIFY) resetLiquifySession();
        if (undo.lastWasStruct()) refreshDisplay();
        else updateDisplayRegion(r);
        paintOverlay(r);
        invalidate();
        String l = undo.lastLabel();
        showHud(l == null || l.isEmpty() ? word : word + ": " + l);
        changed();
    }

    // ==================================================================
    // Utilidades
    // ==================================================================

    private void ensureScratch() {
        int n = project.w * project.h;
        if (scratch == null || scratch.length != n) scratch = new byte[n];
    }

    private void clamp(Rect r) {
        if (r.left < 0) r.left = 0;
        if (r.top < 0) r.top = 0;
        if (r.right > project.w) r.right = project.w;
        if (r.bottom > project.h) r.bottom = project.h;
    }

    private void setBusy(boolean b) {
        busy = b;
        if (callback != null) callback.onBusy(b);
    }

    private void changed() {
        scheduleCompact();
        if (callback != null) callback.onChanged();
    }

    // ------------------------------------------------------------------
    // Memoria: las capas que no se usan se empacan (solo su recorte).
    // ------------------------------------------------------------------

    private final Runnable compactRunnable = new Runnable() {
        @Override
        public void run() {
            if (project == null) return;
            if (busy || drawing || compactHold) {
                handler.postDelayed(this, 400);
                return;
            }
            try {
                project.packInactive();
            } catch (OutOfMemoryError e) {
                // se intenta la proxima vez
            }
        }
    };

    private void scheduleCompact() {
        handler.removeCallbacks(compactRunnable);
        handler.postDelayed(compactRunnable, 1200);
    }

    /** Mientras arrastras una capa no se empaca nada, para que no se trabe. */
    private boolean compactHold;

    public void setCompactHold(boolean hold) {
        compactHold = hold;
        if (!hold) scheduleCompact();
    }

    /** Empaca ya todo lo que no se usa y avisa si igual no alcanza la memoria. */
    private boolean ensureMemory(long bytes) {
        if (project != null && !busy) {
            try {
                project.packInactive();
            } catch (OutOfMemoryError ignored) {
            }
        }
        // solo cuenta lo que va a la memoria de Java; las capas guardadas usan la del telefono
        if (freeMemory() > bytes + (8L << 20)) return true;
        if (undo != null) undo.trimTo(0.5f);
        pxBackup = null;
        System.gc();
        // no se bloquea: lo que falte lo atrapan los try/catch de cada accion
        return true;
    }

    private static long freeMemory() {
        Runtime rt = Runtime.getRuntime();
        return rt.maxMemory() - (rt.totalMemory() - rt.freeMemory());
    }

    /** Memoria que gasta la obra ahora, para mostrar en Capas. */
    public String memoryInfo() {
        if (project == null) return "";
        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        return (used >> 20) + " de " + (rt.maxMemory() >> 20) + " MB";
    }

    private void msg(String s) {
        if (callback != null) callback.onMessage(s);
    }

    // ---- ajustes ----

    public void setMode(int m) {
        if (transformApplying && m != MODE_TRANSFORM) return;
        handler.removeCallbacks(liquifyHold);
        if ((mode == MODE_SCISSORS || mode == MODE_MAGNET) && m != mode) scissorsReset();
        if (mode == MODE_TRANSFORM && m != MODE_TRANSFORM && transformActive) cancelTransform(false);
        if (mode == MODE_LIQUIFY && m != MODE_LIQUIFY) resetLiquifySession();
        if (m == MODE_LIQUIFY && mode != MODE_LIQUIFY) resetLiquifySession();
        mode = m;
        invalidate();
    }

    public int getMode() {
        return mode;
    }

    public void setTolerance(int t) {
        tolerance = t;
    }

    public int getTolerance() {
        return tolerance;
    }

    public void setSoftness(int s) {
        softness = Math.max(0, s);
    }

    public int getSoftness() {
        return softness;
    }

    public void setColorMode(int m) {
        colorMode = m;
    }

    public int getColorMode() {
        return colorMode;
    }

    public void setExpansion(float e) {
        expansion = e;
    }

    public float getExpansion() {
        return expansion;
    }

    public void setGap(boolean on, int r) {
        gapOn = on;
        gapRadius = Math.max(1, r);
        gapBarrier = null;
    }

    public boolean isGapOn() {
        return gapOn;
    }

    public int getGapRadius() {
        return gapRadius;
    }

    public void setBrushSize(float px) {
        brushRadius = Math.max(0.5f, px / 2f);
    }

    private float sizePreview;
    private long sizePreviewUntil;
    private final Paint sizePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Al mover la barra de tamano se ve el circulo del pincel en el centro, como en ibis. */
    public void showSizePreview(float size) {
        sizePreview = size;
        sizePreviewUntil = System.currentTimeMillis() + 900;
        invalidate();
        postDelayed(new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        }, 950);
    }

    private void drawSizePreview(Canvas c) {
        if (System.currentTimeMillis() > sizePreviewUntil) return;
        float r = Math.max(2f, sizePreview * currentScale() / 2f);
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        sizePaint.setStyle(Paint.Style.FILL);
        sizePaint.setColor(0x55000000);
        c.drawCircle(cx, cy, r, sizePaint);
        sizePaint.setStyle(Paint.Style.STROKE);
        sizePaint.setStrokeWidth(3f);
        sizePaint.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, r, sizePaint);
        sizePaint.setStrokeWidth(1.5f);
        sizePaint.setColor(0xFF000000);
        c.drawCircle(cx, cy, r + 2f, sizePaint);
        sizePaint.setStyle(Paint.Style.FILL);
        sizePaint.setColor(0xFFFFFFFF);
        sizePaint.setTextSize(34f);
        sizePaint.setTextAlign(Paint.Align.CENTER);
        c.drawText(String.valueOf((int) sizePreview), cx, cy + 12f, sizePaint);
    }

    public float getHardness() {
        return hardness;
    }

    public float getBrushSize() {
        return brushRadius * 2f;
    }

    public void setHardness(float h) {
        hardness = Math.max(0.05f, Math.min(1f, h));
    }

    public void setBrushOpacity(float v) {
        brushOpacity = Math.max(0.02f, Math.min(1f, v));
    }

    public void setColor(int c) {
        paintColor = c;
    }

    public int getColor() {
        return paintColor;
    }

    public void setEffectStrength(float v) {
        effectStrength = Math.max(0.05f, Math.min(1f, v));
    }

    public float getEffectStrength() { return effectStrength; }

    public void setEffectSoftness(float v) {
        effectSoftness = Math.max(0f, Math.min(1f, v));
        showHud("Suavidad " + Math.round(effectSoftness * 100f) + "%");
    }

    public float getEffectSoftness() { return effectSoftness; }

    public void setLiquifyType(int type) {
        if (drawing && mode == MODE_LIQUIFY) endStroke();
        liquifyType = Math.max(0, Math.min(4, type));
        showHud(liquifyType == 0 ? "Licuar: Arrastrar" : liquifyType == 1 ? "Licuar: Contraer"
                : liquifyType == 2 ? "Licuar: Expandir" : liquifyType == 3 ? "Licuar: Suavizar"
                : "Licuar: Restaurar");
        invalidate();
    }

    public int getLiquifyType() { return liquifyType; }

    public float getBrushOpacity() { return brushOpacity; }

    public void setWandGlobal(boolean g) {
        wandGlobal = g;
    }

    public boolean isWandGlobal() {
        return wandGlobal;
    }

    public void setUseBarrier(boolean b) {
        useBarrier = b;
    }

    public boolean isUseBarrier() {
        return useBarrier;
    }

    public void setSubtract(boolean s) {
        subtract = s;
    }

    public boolean isSubtract() {
        return subtract;
    }

    public void setSmart(boolean s) {
        smart = s;
    }

    public boolean isSmart() {
        return smart;
    }

    public void setStabilizer(float v) {
        stabilizer = Math.max(0f, Math.min(0.92f, v));
    }

    public void setAim(boolean on) {
        aimOn = on;
        invalidate();
    }

    public boolean isAim() {
        return aimOn;
    }

    public void setBgOnce(boolean b) {
        bgOnce = b;
    }

    public boolean isBgOnce() {
        return bgOnce;
    }

    public void setBgBucket(boolean b) {
        bgBucket = b;
    }

    public boolean isBgBucket() {
        return bgBucket;
    }

    public void setBgTolerance(int t) {
        bgTolerance = Math.max(0, Math.min(160, t));
    }

    public int getBgTolerance() {
        return bgTolerance;
    }

    public void setBgSoftness(int s) {
        bgSoftness = Math.max(0, Math.min(160, s));
    }

    public int getBgSoftness() {
        return bgSoftness;
    }

    public void setBgLimit(int l) {
        bgLimit = Math.max(0, Math.min(2, l));
    }

    public int getBgLimit() {
        return bgLimit;
    }

    public void setProtect(boolean on) {
        protectOn = on;
        protectColor = paintColor;
    }

    public boolean isProtect() {
        return protectOn;
    }

    public void setCloneMirror(boolean m) {
        cloneMirror = m;
    }

    public boolean isCloneMirror() {
        return cloneMirror;
    }

    public void setCloneAngle(float a) {
        cloneAngle = a;
    }

    public float getCloneAngle() {
        return cloneAngle;
    }

    /** Libera temporales de la vista al cerrar el editor. No recicla las capas
     * del proyecto porque un autoguardado que ya empezo puede seguir leyendolas. */
    public void releaseUiResources() {
        callback = null;
        cancelQuickTimer();
        handler.removeCallbacksAndMessages(null);
        if (undo != null) undo.clear();
        clearEffectStrokeBackup();
        clearSelectionStrokeBackup();
        resetLiquifySession();
        effectTmp = null;
        blurColA = blurColR = blurColG = blurColB = null;
        endGhost();
        dropPreview();
        dropDetail();
        if (redLines != null && !redLines.isRecycled()) redLines.recycle();
        redLines = null;
        if (markersOverlay != null && !markersOverlay.isRecycled()) markersOverlay.recycle();
        if (patchOverlay != null && !patchOverlay.isRecycled()) patchOverlay.recycle();
        markersOverlay = patchOverlay = null;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (project != null && ow == 0) fit();
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelQuickTimer();
        handler.removeCallbacks(startPending);
        super.onDetachedFromWindow();
    }
}
