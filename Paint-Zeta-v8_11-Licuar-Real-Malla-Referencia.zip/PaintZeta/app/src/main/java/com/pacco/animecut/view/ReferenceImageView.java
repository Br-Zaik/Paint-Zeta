package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Visor ligero de referencia: pan/zoom independiente del lienzo y toque rapido
 * para tomar un color. No pertenece al Project, por lo que nunca se exporta.
 */
public class ReferenceImageView extends View {
    public interface Listener { void onColor(int color); }

    private Bitmap bitmap;
    private Listener listener;
    private final Matrix matrix = new Matrix();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private float lastX, lastY, downX, downY;
    private float oldDist, oldMidX, oldMidY;
    private boolean multi, moved, fitted;

    public ReferenceImageView(Context c) { super(c); init(); }
    public ReferenceImageView(Context c, AttributeSet a) { super(c, a); init(); }
    private void init() { setBackgroundColor(0xFF151518); }

    public void setBitmap(Bitmap b) { bitmap = b; fitted = false; invalidate(); }
    public void setListener(Listener l) { listener = l; }

    private void fit() {
        if (bitmap == null || getWidth() <= 0 || getHeight() <= 0) return;
        float s = Math.min((float)getWidth() / bitmap.getWidth(), (float)getHeight() / bitmap.getHeight());
        matrix.reset();
        matrix.postScale(s, s);
        matrix.postTranslate((getWidth() - bitmap.getWidth() * s) * .5f,
                (getHeight() - bitmap.getHeight() * s) * .5f);
        fitted = true;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { fitted = false; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (bitmap == null || bitmap.isRecycled()) return;
        if (!fitted) fit();
        c.drawBitmap(bitmap, matrix, paint);
    }

    private static float dist(MotionEvent e) {
        if (e.getPointerCount() < 2) return 0f;
        return (float)Math.hypot(e.getX(1) - e.getX(0), e.getY(1) - e.getY(0));
    }

    private void pick(float sx, float sy) {
        if (bitmap == null || listener == null) return;
        Matrix inv = new Matrix();
        if (!matrix.invert(inv)) return;
        float[] p = {sx, sy}; inv.mapPoints(p);
        int x = Math.round(p[0]), y = Math.round(p[1]);
        if (x < 0 || y < 0 || x >= bitmap.getWidth() || y >= bitmap.getHeight()) return;
        listener.onColor(bitmap.getPixel(x, y) | 0xFF000000);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            multi = false; moved = false;
            downX = lastX = e.getX(); downY = lastY = e.getY();
            return true;
        }
        if (a == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() >= 2) {
            multi = true; moved = true;
            oldDist = Math.max(1f, dist(e));
            oldMidX = (e.getX(0) + e.getX(1)) * .5f;
            oldMidY = (e.getY(0) + e.getY(1)) * .5f;
            return true;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            if (e.getPointerCount() >= 2) {
                float nd = Math.max(1f, dist(e));
                float mx = (e.getX(0) + e.getX(1)) * .5f;
                float my = (e.getY(0) + e.getY(1)) * .5f;
                float scale = Math.max(.6f, Math.min(1.7f, nd / oldDist));
                matrix.postTranslate(mx - oldMidX, my - oldMidY);
                matrix.postScale(scale, scale, mx, my);
                oldDist = nd; oldMidX = mx; oldMidY = my;
                invalidate();
            } else if (!multi) {
                float x = e.getX(), y = e.getY();
                if (Math.hypot(x - downX, y - downY) > 8f) moved = true;
                matrix.postTranslate(x - lastX, y - lastY);
                lastX = x; lastY = y;
                invalidate();
            }
            return true;
        }
        if (a == MotionEvent.ACTION_POINTER_UP) { multi = true; return true; }
        if (a == MotionEvent.ACTION_UP) {
            if (!multi && !moved) pick(e.getX(), e.getY());
            multi = false;
            return true;
        }
        if (a == MotionEvent.ACTION_CANCEL) { multi = false; return true; }
        return true;
    }
}
