package com.pacco.animecut.core;

/**
 * v8.54: PINCEL RAPIDO de Borrar fondo. Java puro (lo usan la app y las pruebas).
 *
 * Por que existe: el pincel protegido de v8.32-v8.53 (BgStroke + BgEngine) hacia en CADA toque del
 * dedo un analisis completo (distancia exacta, nucleo, crecimiento, banda) sobre una ventana de
 * cientos de px alrededor del circulo, y al empezar cada trazo medía el grosor de linea y la region
 * de fondo de TODA la imagen. En el telefono eso son decenas de ms por toque: el borrado iba
 * detras del dedo.
 *
 * Este pincel solo mira el circulo del dedo mas unos pocos px:
 *  1) FONDO: color parecido al color tomado al empezar (con la tolerancia). La tinta oscura y el
 *     color protegido nunca son fondo. Lo ya borrado cuenta con su color de antes (la copia).
 *  2) NUCLEO: fondo a mas de "gap" px de cualquier cosa que no sea fondo (distancia chamfer 3-4).
 *     Un corte de la linea mas angosto que unos 2*gap px no tiene nucleo: el borrado no lo cruza.
 *  3) ALCANCE: el borrado solo avanza por el nucleo desde lo aceptado en este trazo, desde lo ya
 *     borrado que era fondo, y al empezar desde el dedo. Si el dedo pasa encima del personaje, alli
 *     no hay nada unido y no se borra.
 *  4) BANDA: desde el nucleo alcanzado se llega hasta "gap" px mas por el fondo, para llegar
 *     pegado a la linea sin cruzar el corte.
 *  5) BORDE: el pixel de la linea pegado a lo borrado se desmezcla entre el color de la linea y el
 *     del fondo: conserva su parte de tinta, sin el tinte del fondo (sin halo blanco).
 * Todo sale de la copia de antes, asi repasar no come mas de la cuenta.
 */
public final class BgBrushFast {

    // ---- ajustes del trazo ----
    public int tol = 46;
    public int mode = ColorDist.HUE;
    /** Radio de cierre de cortes (px). */
    public int gap = 3;
    /** true = el color del fondo sigue cambios suaves mientras pasas el dedo. */
    public boolean follow = true;
    public boolean protect;
    public int protectColor, protectTol = 23;
    /** Matriz 4x5 de B/N (GrayView.matrix) para decidir que es fondo; null = color. */
    public float[] gray;

    private int[] cur, snap;
    private byte[] sel;
    private int W, H;
    /** 1 = nucleo de fondo aceptado en este trazo (semilla del toque siguiente). */
    private byte[] acc;
    private int ax0, ay0, ax1, ay1;
    private boolean started, any;
    /** Color de fondo para decidir (en B/N si gray != null) y el real (para el borde). */
    public int ref, refStart, refReal;

    /** Zona cambiada en el ultimo toque. */
    public int rx0, ry0, rx1, ry1;
    public int erased, edged;
    public long lastNs, maxNs, totNs;
    public int dabs;

    // ---- memoria de trabajo (solo la ventana) ----
    private int[] wc;      // color de analisis
    private int[] dist;    // distancia chamfer (x3)
    private byte[] st;     // estado
    private int[] qu;
    private static final int BG = 1, CORE = 2, REACH = 4, SEEN = 8;
    private int fx0, fy0, fw, fh;

    public boolean isStarted() { return started; }

    /** Empieza el trazo en (sx, sy). false si alli no hay color de fondo para tomar. */
    public boolean begin(int[] cur, int[] snap, int w, int h, byte[] sel, int sx, int sy, int searchR) {
        this.cur = cur;
        this.snap = snap != null && snap.length == cur.length ? snap : null;
        this.sel = sel;
        W = w;
        H = h;
        if (acc == null || acc.length != w * h) acc = new byte[w * h];
        else clearAcc();
        ax0 = ay0 = Integer.MAX_VALUE;
        ax1 = ay1 = Integer.MIN_VALUE;
        any = false;
        started = false;
        dabs = 0;
        totNs = maxNs = 0;
        sx = Math.max(0, Math.min(w - 1, sx));
        sy = Math.max(0, Math.min(h - 1, sy));
        int real = pickRef(sx, sy, Math.max(2, searchR));
        if (real == 0) return false;
        refReal = real | 0xFF000000;
        ref = ana(refReal);
        refStart = ref;
        started = true;
        return true;
    }

    /** Termina el trazo (limpia lo aceptado, solo la caja usada). */
    public void end() {
        clearAcc();
        started = false;
        any = false;
    }

    /** Suelta la memoria grande (al salir de Borrar fondo). */
    public void release() {
        acc = null;
        wc = null;
        dist = null;
        st = null;
        qu = null;
        started = false;
    }

    private void clearAcc() {
        if (acc != null && ax1 > ax0 && ay1 > ay0) {
            for (int y = ay0; y < ay1; y++) java.util.Arrays.fill(acc, y * W + ax0, y * W + ax1, (byte) 0);
        }
        ax0 = ay0 = Integer.MAX_VALUE;
        ax1 = ay1 = Integer.MIN_VALUE;
    }

    /** Color de antes del pixel (si esta mas borrado que en la copia, el de la copia). */
    private int orig(int i) {
        int c = cur[i];
        if (snap != null) {
            int s = snap[i];
            if ((c >>> 24) < (s >>> 24)) return s;
        }
        return c;
    }

    /** Color de analisis (B/N si hay matriz). */
    private int ana(int c) {
        float[] m = gray;
        if (m == null) return c;
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        int nr = clamp(Math.round(m[0] * r + m[1] * g + m[2] * b + m[4]));
        int ng = clamp(Math.round(m[5] * r + m[6] * g + m[7] * b + m[9]));
        int nb = clamp(Math.round(m[10] * r + m[11] * g + m[12] * b + m[14]));
        return (c & 0xFF000000) | (nr << 16) | (ng << 8) | nb;
    }

    private static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    static int lum(int c) {
        return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
    }

    static boolean inkAbs(int c) {
        int l = lum(c);
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        int sat = Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
        return l < 45 || (l < 70 && sat < 60);
    }

    /** Distancia de color del fondo (igual que el Balde: en modo tono, el tono pesa solo si hay color). */
    int bgDist(int c, int r) {
        if (mode != ColorDist.HUE) return ColorDist.dist(c | 0xFF000000, r | 0xFF000000, mode);
        int ar = (c >> 16) & 255, ag = (c >> 8) & 255, ab = c & 255;
        int br = (r >> 16) & 255, bg = (r >> 8) & 255, bb = r & 255;
        int m = Math.max(Math.abs(ar - br), Math.max(Math.abs(ag - bg), Math.abs(ab - bb)));
        int h1 = Math.abs((ar - ag) - (br - bg)), h2 = Math.abs((ab - ag) - (bb - bg)), h3 = Math.abs((ar - ab) - (br - bb));
        int sa = Math.max(ar, Math.max(ag, ab)) - Math.min(ar, Math.min(ag, ab));
        int sb = Math.max(br, Math.max(bg, bb)) - Math.min(br, Math.min(bg, bb));
        int sat = Math.max(sa, sb);
        int wq = Math.max(4, Math.min(12, (sat - 6) * 4 / 6));
        int hh = wq * Math.max(h1, Math.max(h2, h3)) / 4;
        return Math.min(255, Math.max(m, hh));
    }

    /**
     * Color de fondo al empezar: el del dedo si no es tinta; si no, el mas cercano que no sea
     * tinta. Si el dedo esta sobre una zona negra ANCHA (7x7 casi todo tinta), ese negro.
     */
    private int pickRef(int x, int y, int r) {
        int c = orig(y * W + x);
        if ((c >>> 24) > 32 && !inkAbs(c)) return c;
        if ((c >>> 24) > 32) {
            int ink = 0, n = 0;
            for (int dy = -3; dy <= 3; dy++)
                for (int dx = -3; dx <= 3; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
                    n++;
                    int q = orig(yy * W + xx);
                    if ((q >>> 24) > 32 && inkAbs(q)) ink++;
                }
            if (n > 0 && ink * 100 >= n * 85) return c;
        }
        for (int pass = 0; pass < 2; pass++)
            for (int rad = 1; rad <= r; rad++)
                for (int dy = -rad; dy <= rad; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= H) continue;
                    int step = (dy == -rad || dy == rad) ? 1 : 2 * rad;
                    for (int dx = -rad; dx <= rad; dx += step) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= W) continue;
                        int q = orig(yy * W + xx);
                        if ((q >>> 24) <= 32) continue;
                        if (pass == 0 && inkAbs(q)) continue;
                        return q;
                    }
                }
        return 0;
    }

    private boolean ensure(int n) {
        if (wc == null || wc.length < n) {
            int cap = Math.max(n, 128 * 128);
            wc = new int[cap];
            dist = new int[cap];
            st = new byte[cap];
            qu = new int[cap];
            return true;
        }
        return false;
    }

    /**
     * Un tramo del pincel: capsula del punto a al punto b con radio rad. Borra en px (la capa).
     * Devuelve true si cambio algo (zona en rx0..ry1).
     */
    public boolean dab(int[] px, float ax, float ay, float bx, float by, float rad) {
        long t0 = System.nanoTime();
        erased = edged = 0;
        rx0 = ry0 = rx1 = ry1 = 0;
        if (!started) return false;
        int g = Math.max(1, gap);
        // ventana interior (donde se decide) y completa (+g para medir bien la distancia)
        int E = g + 2;
        int ix0 = Math.max(0, (int) Math.floor(Math.min(ax, bx) - rad) - E);
        int iy0 = Math.max(0, (int) Math.floor(Math.min(ay, by) - rad) - E);
        int ix1 = Math.min(W, (int) Math.ceil(Math.max(ax, bx) + rad) + 1 + E);
        int iy1 = Math.min(H, (int) Math.ceil(Math.max(ay, by) + rad) + 1 + E);
        if (ix1 <= ix0 || iy1 <= iy0) { finish(t0); return false; }
        fx0 = Math.max(0, ix0 - g - 1);
        fy0 = Math.max(0, iy0 - g - 1);
        int fx1 = Math.min(W, ix1 + g + 1), fy1 = Math.min(H, iy1 + g + 1);
        fw = fx1 - fx0;
        fh = fy1 - fy0;
        int n = fw * fh;
        ensure(n);
        boolean refInk = inkAbs(ref);
        int walls = 0;
        // 1) fondo / muro
        for (int y = fy0; y < fy1; y++) {
            int o = (y - fy0) * fw - fx0, row = y * W;
            for (int x = fx0; x < fx1; x++) {
                int i = row + x, k = o + x;
                int c = orig(i);
                boolean bg;
                if ((c >>> 24) <= 32) {
                    bg = true;                     // transparente desde antes: no es muro
                    wc[k] = 0;
                } else {
                    int a = ana(c);
                    wc[k] = a;
                    bg = bgDist(a, ref) <= tol && (refInk || !inkAbs(a));
                    if (bg && protect && ColorDist.dist(c | 0xFF000000, protectColor | 0xFF000000, mode) <= protectTol) bg = false;
                }
                st[k] = (byte) (bg ? BG : 0);
                dist[k] = bg ? Integer.MAX_VALUE / 4 : 0;
                if (!bg) walls++;
            }
        }
        if (walls == 0) {
            // zona abierta (todo fondo, lejos de la linea): todo es nucleo, sin medir distancias
            for (int k = 0; k < n; k++) st[k] |= CORE;
        } else {
        // 2) distancia chamfer 3-4 al muro (fuera del lienzo no hay muro: tira de papel del borde)
        for (int y = 0; y < fh; y++) {
            int o = y * fw;
            for (int x = 0; x < fw; x++) {
                int k = o + x;
                int d = dist[k];
                if (d == 0) continue;
                if (x > 0) d = Math.min(d, dist[k - 1] + 3);
                if (y > 0) {
                    d = Math.min(d, dist[k - fw] + 3);
                    if (x > 0) d = Math.min(d, dist[k - fw - 1] + 4);
                    if (x < fw - 1) d = Math.min(d, dist[k - fw + 1] + 4);
                }
                dist[k] = d;
            }
        }
        int thr = 3 * g;
        for (int y = fh - 1; y >= 0; y--) {
            int o = y * fw;
            for (int x = fw - 1; x >= 0; x--) {
                int k = o + x;
                int d = dist[k];
                if (d == 0) continue;
                if (x < fw - 1) d = Math.min(d, dist[k + 1] + 3);
                if (y < fh - 1) {
                    d = Math.min(d, dist[k + fw] + 3);
                    if (x < fw - 1) d = Math.min(d, dist[k + fw + 1] + 4);
                    if (x > 0) d = Math.min(d, dist[k + fw - 1] + 4);
                }
                dist[k] = d;
                if (d > thr) st[k] |= CORE;
            }
        }
        }
        // 3) semillas en la ventana interior: lo aceptado, lo ya borrado que era fondo, el dedo
        int qh = 0, qt = 0;
        for (int y = iy0; y < iy1; y++) {
            int o = (y - fy0) * fw - fx0, row = y * W;
            for (int x = ix0; x < ix1; x++) {
                int k = o + x;
                if ((st[k] & CORE) == 0) continue;
                int i = row + x;
                if (acc[i] != 0 || (cur[i] >>> 24) < 32) {
                    st[k] |= REACH | SEEN;
                    qu[qt++] = k;
                }
            }
        }
        if (!any && qt == 0) {
            int s = firstSeed(bx, by, g + 2, ix0, iy0, ix1, iy1);
            if (s >= 0) {
                st[s] |= REACH | SEEN;
                qu[qt++] = s;
            }
        }
        if (qt == 0) { finish(t0); return false; }
        any = true;
        // 4) relleno por el nucleo (dentro de la ventana interior)
        int lx0 = ix0 - fx0, ly0 = iy0 - fy0, lx1 = ix1 - fx0, ly1 = iy1 - fy0;
        while (qh < qt) {
            int k = qu[qh++];
            int y = k / fw, x = k - y * fw;
            if (x > lx0) qt = core(k - 1, qt);
            if (x < lx1 - 1) qt = core(k + 1, qt);
            if (y > ly0) qt = core(k - fw, qt);
            if (y < ly1 - 1) qt = core(k + fw, qt);
        }
        int coreN = qt;
        // lo alcanzado del nucleo queda aceptado para el toque siguiente
        for (int q = 0; q < coreN; q++) {
            int k = qu[q];
            int y = k / fw + fy0, x = k % fw + fx0;
            acc[y * W + x] = 1;
        }
        ax0 = Math.min(ax0, ix0); ay0 = Math.min(ay0, iy0);
        ax1 = Math.max(ax1, ix1); ay1 = Math.max(ay1, iy1);
        // 5) banda: hasta g px mas por el fondo (llegar pegado a la linea sin cruzar el corte)
        qh = 0;
        int levelEnd = qt;
        for (int depth = 0; depth < g && qh < qt; depth++) {
            levelEnd = qt;
            while (qh < levelEnd) {
                int k = qu[qh++];
                int y = k / fw, x = k - y * fw;
                if (x > lx0) qt = band(k - 1, qt);
                if (x < lx1 - 1) qt = band(k + 1, qt);
                if (y > ly0) qt = band(k - fw, qt);
                if (y < ly1 - 1) qt = band(k + fw, qt);
            }
        }
        // 6) borrar lo alcanzado dentro de la capsula; desmezclar el borde de la linea
        float sx = bx - ax, sy = by - ay, sl2 = sx * sx + sy * sy;
        float rr = (rad + 0.5f) * (rad + 0.5f);
        int cx0 = Math.max(0, (int) Math.floor(Math.min(ax, bx) - rad - 1)), cy0 = Math.max(0, (int) Math.floor(Math.min(ay, by) - rad - 1));
        int cx1 = Math.min(W, (int) Math.ceil(Math.max(ax, bx) + rad + 2)), cy1 = Math.min(H, (int) Math.ceil(Math.max(ay, by) + rad + 2));
        int mx0 = Integer.MAX_VALUE, my0 = Integer.MAX_VALUE, mx1 = Integer.MIN_VALUE, my1 = Integer.MIN_VALUE;
        for (int y = cy0; y < cy1; y++) {
            int o = (y - fy0) * fw - fx0, row = y * W;
            float py = y + 0.5f - ay;
            for (int x = cx0; x < cx1; x++) {
                float pxx = x + 0.5f - ax;
                float t = sl2 > 1e-6f ? Math.max(0f, Math.min(1f, (pxx * sx + py * sy) / sl2)) : 0f;
                float dx = pxx - sx * t, dy = py - sy * t;
                if (dx * dx + dy * dy > rr) continue;
                int k = o + x, i = row + x;
                int s = st[k];
                int c = px[i];
                int ca = c >>> 24;
                if (ca == 0) continue;
                if ((s & REACH) != 0) {
                    int want = 0;
                    if (sel != null) {
                        int sa = sel[i] & 0xFF;
                        if (sa == 0) continue;
                        want = (orig(i) >>> 24) * (255 - sa) / 255;
                    }
                    if (want < ca) {
                        px[i] = (want << 24) | (c & 0x00FFFFFF);
                        erased++;
                        if (x < mx0) mx0 = x; if (x > mx1) mx1 = x;
                        if (y < my0) my0 = y; if (y > my1) my1 = y;
                    }
                } else if ((s & BG) == 0 && touchesReach(k, x - fx0, y - fy0)) {
                    if (edge(px, i, x, y)) {
                        edged++;
                        if (x < mx0) mx0 = x; if (x > mx1) mx1 = x;
                        if (y < my0) my0 = y; if (y > my1) my1 = y;
                    }
                }
            }
        }
        // 7) el color sigue al fondo de a poco (solo en una zona pareja ya aceptada)
        if (follow) followColor((int) bx, (int) by);
        if (mx1 >= mx0) {
            rx0 = mx0; ry0 = my0; rx1 = mx1 + 1; ry1 = my1 + 1;
        }
        finish(t0);
        return mx1 >= mx0;
    }

    private void finish(long t0) {
        lastNs = System.nanoTime() - t0;
        totNs += lastNs;
        if (lastNs > maxNs) maxNs = lastNs;
        dabs++;
    }

    private int core(int k, int qt) {
        int s = st[k];
        if ((s & SEEN) != 0 || (s & CORE) == 0) return qt;
        st[k] = (byte) (s | SEEN | REACH);
        qu[qt++] = k;
        return qt;
    }

    private int band(int k, int qt) {
        int s = st[k];
        if ((s & SEEN) != 0 || (s & BG) == 0) return qt;
        st[k] = (byte) (s | SEEN | REACH);
        qu[qt++] = k;
        return qt;
    }

    private boolean touchesReach(int k, int lx, int ly) {
        if (lx > 0 && (st[k - 1] & REACH) != 0) return true;
        if (lx < fw - 1 && (st[k + 1] & REACH) != 0) return true;
        if (ly > 0 && (st[k - fw] & REACH) != 0) return true;
        return ly < fh - 1 && (st[k + fw] & REACH) != 0;
    }

    /** Primer toque: el nucleo bajo el dedo o, si el dedo esta junto a la linea, el mas cercano. */
    private int firstSeed(float bx, float by, int r, int ix0, int iy0, int ix1, int iy1) {
        int cx = (int) bx, cy = (int) by;
        int best = -1;
        long bd = Long.MAX_VALUE;
        for (int y = Math.max(iy0, cy - r); y <= Math.min(iy1 - 1, cy + r); y++)
            for (int x = Math.max(ix0, cx - r); x <= Math.min(ix1 - 1, cx + r); x++) {
                int k = (y - fy0) * fw + (x - fx0);
                if ((st[k] & CORE) == 0) continue;
                long d = (long) (x - cx) * (x - cx) + (long) (y - cy) * (y - cy);
                if (d < bd && d <= (long) r * r) { bd = d; best = k; }
            }
        return best;
    }

    /**
     * Pixel de la linea pegado a lo borrado: alfa = cuanto tiene de la linea (desmezcla entre el
     * color mas distinto del fondo cerca y el fondo); el color pierde el tinte del fondo. Si el
     * color no se explica con esos dos (otro color del personaje), no se toca.
     */
    private boolean edge(int[] px, int i, int x, int y) {
        int o = orig(i);
        int oa = o >>> 24;
        if (oa <= 32) return false;
        int B = refReal;
        int br = (B >> 16) & 255, bg = (B >> 8) & 255, bb = B & 255;
        int best = 0, bestD = -1;
        for (int dy = -2; dy <= 2; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= H) continue;
            for (int dx = -2; dx <= 2; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= W) continue;
                int q = orig(yy * W + xx);
                if ((q >>> 24) <= 200) continue;
                int dr = ((q >> 16) & 255) - br, dg = ((q >> 8) & 255) - bg, db = (q & 255) - bb;
                int d = dr * dr + dg * dg + db * db;
                if (d > bestD) { bestD = d; best = q; }
            }
        }
        if (bestD < 900) return false;                      // la linea se parece demasiado al fondo
        float lr = ((best >> 16) & 255) - br, lg = ((best >> 8) & 255) - bg, lb = (best & 255) - bb;
        float pr = ((o >> 16) & 255) - br, pg = ((o >> 8) & 255) - bg, pb = (o & 255) - bb;
        float l2 = lr * lr + lg * lg + lb * lb;
        float t = (pr * lr + pg * lg + pb * lb) / l2;
        if (t >= 0.94f) return false;                      // es linea entera
        if (t < 0f) t = 0f;
        float er = pr - t * lr, eg = pg - t * lg, eb = pb - t * lb;
        if (er * er + eg * eg + eb * eb > 45f * 45f) return false;   // otro color: se conserva
        int c = px[i];
        int ca = c >>> 24;
        int na = Math.round(oa * t);
        if (sel != null) {
            int sa = sel[i] & 0xFF;
            if (sa == 0) return false;
            na = Math.round(oa - (oa - na) * sa / 255f);
        }
        if (na >= ca) return false;
        int rgb;
        if (t < 0.05f) rgb = c & 0x00FFFFFF;
        else {
            int r = clamp(Math.round(br + pr / t)), gg = clamp(Math.round(bg + pg / t)), b = clamp(Math.round(bb + pb / t));
            rgb = (r << 16) | (gg << 8) | b;
        }
        px[i] = (na << 24) | rgb;
        return true;
    }

    private void followColor(int x, int y) {
        if (x < 0 || y < 0 || x >= W || y >= H || acc[y * W + x] == 0) return;
        int c = orig(y * W + x);
        if ((c >>> 24) <= 32) return;
        int a = ana(c | 0xFF000000);
        if (inkAbs(a) && !inkAbs(ref)) return;
        if (bgDist(a, ref) > Math.max(12, tol / 2)) return;
        if (bgDist(a, refStart) > tol + 24) return;
        int lim = Math.max(16, tol * 2 / 3);
        for (int dy = -1; dy <= 1; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= H) return;
            for (int dx = -1; dx <= 1; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= W) return;
                int q = orig(yy * W + xx);
                if ((q >>> 24) < 32) continue;
                if (ColorDist.dist(q | 0xFF000000, c | 0xFF000000, ColorDist.RGB) > lim) return;
            }
        }
        ref = a | 0xFF000000;
        refReal = c | 0xFF000000;
    }
}
