# Paint Zeta v8.54: pincel de Borrar fondo rápido y Relleno normal otra vez (sobre la v8.53)

Solo se tocaron dos cosas: el Pincel de Borrar fondo y el Relleno. Lo demás quedó igual.

## 1. Pincel de Borrar fondo

### Comparación de las versiones

- **8.28 y 8.30**: el pincel solo miraba un pedazo chico alrededor del dedo, por eso iba rápido. Pero cruzaba la línea negra cuando tenía cortes y se comía partes del personaje.
- **8.33 hasta 8.53**: se cambió a un "motor" muy cuidadoso que ya no cruzaba la línea. El problema es que es pesado:
  - en cada toque del dedo analizaba un cuadro grande alrededor del pincel, varias veces más grande que el pincel;
  - al empezar cada trazo, revisaba la imagen entera (el grosor de las líneas y todo el fondo);
  - todo eso iba en el mismo momento en que mueves el dedo, así que el borrado iba atrasado.
- La 8.53 intentó aliviarlo con trucos alrededor, pero el corazón del pincel seguía siendo igual de pesado. Por eso se sentía igual de lento.

### Qué se hizo

Un pincel nuevo que junta lo bueno de las dos épocas:

- Mira solo el círculo del pincel y unos pocos píxeles más, como la 8.28 y la 8.30.
- No cruza la línea: si la línea tiene un corte chico, el borrado no pasa por ahí. El tamaño de corte que frena depende del grosor de las líneas de tu dibujo.
- Si el dedo pasa por encima del personaje, ahí no borra. Sigue borrando cuando vuelves al fondo que ya estabas borrando.
- El borde de la línea queda limpio: conserva su parte de tinta, sin halo blanco.
- Al poner el dedo ya no se revisa la imagen entera.

### Medido en la PC

Con un dibujo de 1728 × 2604 y un trazo de 700 px:

- Pincel de 28 px: la 8.53 tardaba unos 80 ms y hasta 6–9 ms por toque. El nuevo tarda unos 10 ms y menos de 0,5 ms por toque. Además la 8.53 gastaba unos 300 ms extra al empezar cada trazo; el nuevo, casi nada.
- Pincel de 60 px: unos 75 ms antes, unos 13 ms ahora.
- Pincel muy grande (200 px): unos 125 ms antes, unos 40 ms ahora.
- En la prueba del círculo cerrado con un corte de 3 a 8 px, ni la 8.53 ni el nuevo se metieron adentro.
- Con cortes más grandes (unos 12 px) el nuevo sí pasa. Para esos casos sube "Cerrar huecos" en los ajustes avanzados, o borra esa parte con el Borrador.

Un teléfono es más lento que la PC, así que los números reales serán más altos, pero la diferencia entre la 8.53 y el nuevo se mantiene.

### Lo que no cambió

- Balde de Borrar fondo (el toque), Borrador, Restaurar, Escoba, B/N y Recortar con IA: iguales.
- Los rincones muy angostos entre mechones puede que no se borren del todo con el pincel. Para eso: el Borrador o la Escoba.

## 2. Relleno (balde)

### Qué pasaba

- El balde normal es el mismo de la 8.33: nadie lo cambió por dentro.
- Lo que cambió es que desde la 8.43, al usar **1 Colorear**, la obra quedaba en "modo manga" para siempre. Desde ese momento, el **Relleno** de la caja de herramientas se volvía el balde de colorear por zonas (con sombra, "Suave 100 %" y las tres muestras de color). Eso es lo que viste en las capturas.

### Qué se hizo

- **Relleno** (Pintar y retocar) es siempre el balde normal: pinta un color parejo en la zona, con su tolerancia, dilatación, "hasta la línea" y destino, como antes.
- El balde para colorear manga es una opción aparte:
  - **1 Colorear** lo abre, igual que antes;
  - en **Manga +** hay una opción nueva: "Balde de colorear manga (por líneas)".
- Si cambias de un balde al otro, una vista previa pendiente se cancela. Así no se mezclan.

## Qué falta probar en tu teléfono

- Que el pincel de Borrar fondo vaya pegado al dedo.
- Que el Relleno sea el balde normal aunque antes hayas usado 1 Colorear.
- Que 1 Colorear y Manga + sigan abriendo el balde de colorear.

Todo esto se probó en la PC y se revisó el código. No se pudo armar el APK aquí, así que lo compila GitHub Actions como siempre.
