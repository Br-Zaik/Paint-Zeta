"""Pruebas estaticas del codigo fuente. No reemplazan ejecutar APK en Android."""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VIEW = (ROOT / 'app/src/main/java/com/pacco/animecut/view/CanvasView.java').read_text()
MAIN = (ROOT / 'app/src/main/java/com/pacco/animecut/MainActivity.java').read_text()


class SourceRegressions(unittest.TestCase):
    def test_paint_allocates_coverage_before_use(self):
        # Fallo reproducible de la version 8.14: stampPaint leia cov[i],
        # pero beginLayerStroke dejaba cov en null para MODE_PAINT.
        section = VIEW[VIEW.index('private boolean needsStrokeCoverage()'):VIEW.index('private boolean beginLayerStroke()')]
        self.assertIn('return mode == MODE_PAINT ||', section)
        paint_section = VIEW[VIEW.index('private void stampPaint(float cx, float cy)'):VIEW.index('private void stampParticles(')]
        self.assertIn('if (cov == null || strokeLayer == null) return;', paint_section)
        self.assertIn('int old = cov[i] & 0xFF;', VIEW)

    def test_liquify_modes_are_reachable(self):
        self.assertIn('String[] names = {"Arrastrar", "Contraer", "Expandir", "Suavizar", "Restaurar"}', MAIN)
        self.assertIn('canvas.setLiquifyType(which);', MAIN)
        self.assertIn('"Grosor\\n" + sizeText + "px"', MAIN)
        self.assertIn('"Fuerza " + v + "%"', MAIN)

    def test_color_and_liquify_strength_not_mixed(self):
        self.assertIn('if (canvas.getMode() != CanvasView.MODE_LIQUIFY) bottomOp.setProgress(op);', MAIN)
        self.assertIn('canvas.setEffectStrength(v / 100f);', MAIN)
        self.assertIn('canvas.setBrushOpacity(v / 100f);', MAIN)

    def test_liquify_edge_and_final_sampling(self):
        self.assertIn('private void invertLiquify(', VIEW)
        self.assertIn('private void sampleLiquifyWithJacobian(', VIEW)
        self.assertIn('Math.min(project.w - 1f, x)', VIEW)
        self.assertIn('Math.min(project.h - 1f, y)', VIEW)
        # No usar la rasterizacion de malla sin antialias como preview.
        self.assertNotIn('drawBitmapMesh(liquifyMesh', VIEW)
        self.assertNotIn('buildLiquifyMeshPreview(', VIEW)
        # Vista previa y final deben invocar EL MISMO sampler de pixel.
        self.assertEqual(VIEW.count('renderLiquifyRegion(r);'), 2)

    def test_liquify_guard_is_applied_before_dirty_commit(self):
        method = VIEW[VIEW.index('private Rect effectLiquifyField('):VIEW.index('private final float[] liquifySample')]
        self.assertIn('LiquifyTopologyGuard.minTriangleRatio(', method)
        self.assertIn('if (minArea < .12f)', method)
        self.assertLess(method.index('if (minArea < .12f)'), method.index('markLiquifyDirty(dirty)'))

    def test_liquify_input_and_preview_are_not_coarsened(self):
        self.assertIn('getHistoricalX(0, hk)', VIEW)
        self.assertIn('!isShapeTool() && mode != MODE_LIQUIFY', VIEW)
        self.assertIn('mode == MODE_LIQUIFY ? 512 : 64', VIEW)
        self.assertNotIn('liquifyMeshPreviewVisible', VIEW)
        self.assertIn('if (liquifyPreviewDirtyValid) liquifyPreviewDirty.union(r);', VIEW)

    def test_all_resource_xml_parses(self):
        for file in ROOT.glob('app/src/main/res/**/*.xml'):
            with self.subTest(file=file.name):
                ET.parse(file)

    def test_version(self):
        gradle = (ROOT / 'app/build.gradle').read_text()
        self.assertIn('versionCode 53', gradle)
        self.assertIn('versionName "8.16"', gradle)


if __name__ == '__main__':
    unittest.main()
