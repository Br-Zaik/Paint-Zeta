package com.pacco.animecut;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.Exporter;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.ProjectIO;
import com.pacco.animecut.core.ProjectStore;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.Thumbs;
import com.pacco.animecut.view.CanvasView;
import com.pacco.animecut.view.ColorPickerView;
import com.pacco.animecut.view.SelDemoView;
import com.pacco.animecut.view.ReferenceImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Pantalla principal. Funciona como Ibis: capas de verdad, capa de seleccion,
 * herramientas en un panel chico abajo a la izquierda.
 */
public class MainActivity extends AppCompatActivity implements CanvasView.Callback {

    public static final String EXTRA_PROJECT = "obra";

    private static final int[] PALETTE = {
            0xFF000000, 0xFF444444, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF, 0xFF7A4A2B,
            0xFFE05A5A, 0xFFFF7A45, 0xFFFFB03A, 0xFFFFE05C, 0xFFB5E05A, 0xFF4FC66B,
            0xFF3DD6C0, 0xFF4DA3FF, 0xFF3D6BFF, 0xFF7B5CFF, 0xFFB558FF, 0xFFFF6FC3,
            0xFFFFE0C4, 0xFFF5C9A6, 0xFFD9A377, 0xFF9C6B4A, 0xFF2B2B3A, 0xFF1B3358
    };

    private CanvasView canvas;
    private TextView sliderLabel;
    private SeekBar slider;

    private ActivityResultLauncher<String> openImage;
    private ActivityResultLauncher<String> addImage;
    private ActivityResultLauncher<String> createZip;
    private ActivityResultLauncher<String> createPng;
    private ActivityResultLauncher<Uri> pickFolder;
    private ActivityResultLauncher<String> createProject;
    private ActivityResultLauncher<String[]> openProject;
    private ActivityResultLauncher<String[]> pickColorRef;

    private interface ColorPickTarget {
        void onColor(int color);
    }

    private String projectId;
    private String lastError;
    private int lastExportCount;
    private int outW, outH;
    private int edgeClean = 2;
    private boolean saving = false;
    private boolean destroyed = false;
    private boolean showAdvanced = false;
    private Layer pendingLayerExport;
    private ProjectIO.Loaded loaded;
    private int[] tintNext;
    private Runnable hideDemo;
    private Bitmap colorRefBitmap;
    private ColorPickTarget pendingColorRefTarget;
    private PopupWindow colorRefWindow;
    private ReferenceImageView colorRefView;
    private int colorRefX = 18, colorRefY = 90;
    private int colorRefW = 330, colorRefH = 390;
    private final android.os.Handler previewHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        android.content.SharedPreferences refPrefs = getSharedPreferences("pz", MODE_PRIVATE);
        colorRefX = refPrefs.getInt("ref_x", 18);
        colorRefY = refPrefs.getInt("ref_y", 90);
        colorRefW = refPrefs.getInt("ref_w", 330);
        colorRefH = refPrefs.getInt("ref_h", 390);
        canvas = findViewById(R.id.canvas);
        sliderLabel = findViewById(R.id.sliderLabel);
        slider = findViewById(R.id.slider);
        canvas.setCallback(this);

        openImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) loadImage(uri);
                        else if (canvas.getProject() == null) finish();
                    }
                });
        addImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) addImageLayer(uri);
                    }
                });
        createZip = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/zip"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportZip(uri);
                    }
                });
        pickFolder = registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportFolder(uri);
                    }
                });
        createPng = registerForActivityResult(new ActivityResultContracts.CreateDocument("image/png"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) doExportLayer(uri);
                    }
                });
        createProject = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) saveProjectTo(uri);
                    }
                });
        openProject = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) openProjectFrom(uri);
                    }
                });

        pickColorRef = registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri == null) {
                            pendingColorRefTarget = null;
                            return;
                        }
                        Bitmap bmp = decodeReference(uri);
                        if (bmp == null) return;
                        if (colorRefBitmap != null && colorRefBitmap != bmp && !colorRefBitmap.isRecycled()) {
                            colorRefBitmap.recycle();
                        }
                        colorRefBitmap = bmp;
                        toast("Referencia de color cargada");
                        if (pendingColorRefTarget != null) {
                            showReferenceColorPanel(pendingColorRefTarget);
                            pendingColorRefTarget = null;
                        }
                    }
                });

        click(R.id.btnUndo, new Runnable() {
            public void run() {
                canvas.doUndo();
                updateUi();
            }
        });
        click(R.id.btnRedo, new Runnable() {
            public void run() {
                canvas.doRedo();
                updateUi();
            }
        });
        click(R.id.btnSelMenu, new Runnable() {
            public void run() {
                selectionMenu();
            }
        });
        click(R.id.btnMenu, new Runnable() {
            public void run() {
                mainMenu();
            }
        });
        click(R.id.btnTools, new Runnable() {
            public void run() {
                toolGrid();
            }
        });
        click(R.id.btnSize, new Runnable() {
            public void run() {
                brushPresets();
            }
        });
        click(R.id.btnColor, new Runnable() {
            public void run() {
                colorDialog();
            }
        });
        click(R.id.btnLayers, new Runnable() {
            public void run() {
                toggleLayersPanel();
            }
        });
        click(R.id.btnLayersClose, new Runnable() {
            public void run() {
                closeLayers();
            }
        });
        click(R.id.btnExport, new Runnable() {
            public void run() {
                exportDialog();
            }
        });
        click(R.id.btnAddMode, new Runnable() {
            public void run() {
                canvas.setSubtract(false);
                updateUi();
            }
        });
        click(R.id.btnSubMode, new Runnable() {
            public void run() {
                canvas.setSubtract(true);
                updateUi();
            }
        });
        click(R.id.btnSmart, new Runnable() {
            public void run() {
                canvas.setSmart(!canvas.isSmart());
                canvas.showHud(canvas.isSmart() ? "Fino: SI (se queda en el color que tocas)" : "Fino: NO");
                updateUi();
            }
        });
        click(R.id.btnLineart, new Runnable() {
            public void run() {
                lineArtDialog();
            }
        });
        click(R.id.btnSizeMinus, new Runnable() {
            public void run() {
                slider.setProgress(Math.max(0, slider.getProgress() - 1));
            }
        });
        click(R.id.btnSizePlus, new Runnable() {
            public void run() {
                slider.setProgress(Math.min(slider.getMax(), slider.getProgress() + 1));
            }
        });
        final SeekBar op = findViewById(R.id.opacity);
        click(R.id.btnOpMinus, new Runnable() {
            public void run() {
                op.setProgress(Math.max(2, op.getProgress() - 5));
            }
        });
        click(R.id.btnOpPlus, new Runnable() {
            public void run() {
                op.setProgress(Math.min(100, op.getProgress() + 5));
            }
        });
        op.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                v = Math.max(2, v);
                canvas.setBrushOpacity(v / 100f);
                ((TextView) findViewById(R.id.opacityLabel)).setText(String.valueOf(v));
            }
        });
        slider.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                applySlider(v);
            }
        });
        installTooltips();

        canvas.setBrushSize(20f);
        canvas.setSmoothZoom(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("smooth_zoom", true));
        bgExpOn = getSharedPreferences("pz", MODE_PRIVATE).getBoolean("bg_exp_on", false);
        bgExpAmt = getSharedPreferences("pz", MODE_PRIVATE).getInt("bg_exp_amt", 2);
        canvas.setBgExpansion(bgExpOn ? bgExpAmt : 0f);
        {
            android.content.SharedPreferences bsp = getSharedPreferences("pz", MODE_PRIVATE);
            canvas.setBgTolerance(bsp.getInt("bg_tol", 46));
            canvas.setBgSoftness(bsp.getInt("bg_soft", 42));
            canvas.setBgOnce(bsp.getBoolean("bg_once", true));
            canvas.setBgLimit(bsp.getInt("bg_limit", 0));
        }
        loadFillPrefs();
        {
            android.content.SharedPreferences bsp = getSharedPreferences("pz", MODE_PRIVATE);
            int bi = bsp.getInt("brush_preset3", 0);
            applyBrushPreset(bi, false);
            if (!bsp.contains("brush_preset3")) {
                // primera vez con esta version: empieza con el Pincel de color
                com.pacco.animecut.core.BrushPreset bp = com.pacco.animecut.core.BrushPreset.PRESETS[0];
                canvas.setBrushSize(bp.size);
                canvas.setHardness(bp.hardness);
                bsp.edit().putInt("brush_preset3", 0).apply();
            }
        }
        canvas.setFlatPaint(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("flat_paint", true));
        canvas.setLineStop(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("line_stop", false));
        canvas.setAutoLines(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("auto_lines", true));
        canvas.setToLine(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("to_line", true));
        canvas.setFillUnpainted(getSharedPreferences("pz", MODE_PRIVATE).getBoolean("fill_unpainted", false));
        // boton de ajustes de la varita, junto a los de la barra de seleccion
        ImageButton gear = new ImageButton(this);
        gear.setImageResource(R.drawable.ic_menu);
        gear.setBackgroundResource(R.drawable.bg_tool);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER);
        gear.setPadding(dp(9), dp(9), dp(9), dp(9));
        gear.setContentDescription("Ajustes de la varita");
        gear.setId(View.generateViewId());
        wandGear = gear;
        ((ViewGroup) findViewById(R.id.btnLineart).getParent()).addView(gear,
                new LinearLayout.LayoutParams(dp(44), dp(40)));
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wandDialog();
            }
        });
        Task.setErrorListener(new Task.ErrorListener() {
            @Override
            public void onError(Throwable t) {
                if (destroyed) return;
                if (t instanceof OutOfMemoryError) {
                    toast("No alcanzo la memoria para eso. Combina o borra alguna capa y prueba otra vez.");
                }
            }
        });
        syncSlider();
        updateUi();
        measureBars();

        saveHandler.postDelayed(savePeriodic, 30000);
        projectId = getIntent().getStringExtra(EXTRA_PROJECT);
        if (projectId != null) {
            // la obra aparece de una vez ya ajustada, sin salto de zoom
            canvas.setAlpha(0f);
            recoverFrom(ProjectStore.fileFor(this, projectId));
        }
        else openImage.launch("image/*");
    }

    @Override
    protected void onPause() {
        super.onPause();
        autosave(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (dirty) autosave(false);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        saveHandler.removeCallbacksAndMessages(null);
        previewHandler.removeCallbacksAndMessages(null);
        opHandler.removeCallbacksAndMessages(null);
        Task.setErrorListener(null);
        try { thumbPool.shutdownNow(); } catch (Throwable ignored) {}
        for (Bitmap b : new ArrayList<Bitmap>(thumbCache.values()))
            if (b != null && !b.isRecycled()) b.recycle();
        thumbCache.clear();
        if (colorRefWindow != null) {
            try { colorRefWindow.dismiss(); } catch (Throwable ignored) {}
            colorRefWindow = null; colorRefView = null;
        }
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) {
            colorRefBitmap.recycle();
            colorRefBitmap = null;
        }
        rowHolders.clear();
        if (canvas != null) {
            canvas.setCallback(null);
            canvas.releaseUiResources();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // Guardado automatico: poco despues de cada cambio y cada 30 segundos.
    // Asi, si la app se cierra de golpe, se pierde muy poco.
    // ------------------------------------------------------------------

    private boolean dirty = false, saveAgain = false;
    private final android.os.Handler saveHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable saveSoon = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            if (dirty) autosave(false);
        }
    };
    private final Runnable savePeriodic = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            if (dirty) autosave(false);
            if (!destroyed) saveHandler.postDelayed(this, 30000);
        }
    };

    private void markDirty() {
        dirty = true;
        saveHandler.removeCallbacks(saveSoon);
        saveHandler.postDelayed(saveSoon, 4000);
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    private void installTooltips() {
        int[] ids = {R.id.btnUndo, R.id.btnRedo, R.id.btnSelMenu, R.id.btnMenu, R.id.btnTools, R.id.btnSize,
                R.id.btnColor, R.id.btnLayers, R.id.btnExport, R.id.btnAddMode, R.id.btnSubMode, R.id.btnSmart,
                R.id.btnLineart};
        String[] names = {"Deshacer (o toca con dos dedos)", "Rehacer (o toca con tres dedos)",
                "Seleccion: acciones con lo azul", "Mas opciones", "Herramientas", "Tipo de pincel",
                "Color", "Capas", "Exportar", "Agregar a lo azul", "Quitar de lo azul",
                "Fino: se queda en el color que tocas", "Line art: la linea hace de pared"};
        for (int i = 0; i < ids.length; i++) {
            final String n = names[i];
            findViewById(ids[i]).setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    toast(n);
                    return true;
                }
            });
        }
    }

    // ==================================================================
    // Abrir, agregar imagen, guardar
    // ==================================================================

    /**
     * Ya no hay un limite artificial de 4096 px. El tamano de apertura se decide
     * con la memoria real disponible del dispositivo para no cerrar Android.
     */
    private long safeOpenPixels() {
        long heap = Runtime.getRuntime().maxMemory();
        // Abrir una obra necesita temporalmente Bitmap + int[] de la capa + buffers.
        // Aproximar 14 bytes/pixel deja margen para la interfaz y el deshacer.
        return Math.max(8_000_000L, heap / 14L);
    }

    private Bitmap decode(Uri uri) {
        try {
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            InputStream is0 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is0, null, b);
            if (is0 != null) is0.close();
            int ow = b.outWidth, oh = b.outHeight;
            if (ow <= 0 || oh <= 0) {
                toast("No se pudo leer el tamano de la imagen");
                return null;
            }

            long safePixels = safeOpenPixels();
            int sample = 1;
            while ((long) Math.max(1, ow / sample) * Math.max(1, oh / sample) > safePixels * 2L) {
                sample *= 2;
            }

            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            if (bmp == null) {
                toast("No se pudo abrir la imagen");
                return null;
            }

            long got = (long) bmp.getWidth() * bmp.getHeight();
            if (got > safePixels) {
                float f = (float) Math.sqrt(safePixels / (double) got);
                int tw = Math.max(1, Math.round(bmp.getWidth() * f));
                int th = Math.max(1, Math.round(bmp.getHeight() * f));
                Bitmap sc = Bitmap.createScaledBitmap(bmp, tw, th, true);
                if (sc != bmp) bmp.recycle();
                bmp = sc;
            }
            if (bmp.getWidth() != ow || bmp.getHeight() != oh) {
                toast("La imagen " + ow + "x" + oh + " se ajusto a " + bmp.getWidth() + "x"
                        + bmp.getHeight() + " segun la memoria disponible del telefono");
            }
            return bmp;
        } catch (OutOfMemoryError e) {
            toast("Android se quedo sin memoria al abrir esa imagen");
        } catch (Exception e) {
            toast("No se pudo abrir: " + e.getMessage());
        }
        return null;
    }

    private void loadImage(Uri uri) {
        Bitmap bmp = decode(uri);
        if (bmp == null) return;
        projectId = null;
        canvas.setProject(new Project(bmp));
        bmp.recycle();
        afterProjectLoaded();
        markDirty();
        toast("Imagen abierta en la capa \"imagen\"");
        guideIfFirstTime();
    }

    private void addImageLayer(Uri uri) {
        if (!needProject()) return;
        Bitmap bmp = decode(uri);
        if (bmp == null) return;
        canvas.addImageLayer(bmp);
        bmp.recycle();
        updateUi();
    }

    private void afterProjectLoaded() {
        closeTools();
        closeLayers();
        canvas.setMode(CanvasView.MODE_WAND);
        canvas.setSubtract(false);
        syncSlider();
        updateUi();
    }

    private void applyLoaded() {
        if (lastError != null) {
            canvas.setAlpha(1f);
            toast("No se pudo abrir: " + lastError);
            return;
        }
        if (loaded == null || loaded.project == null) {
            canvas.setAlpha(1f);
            return;
        }
        canvas.setProject(loaded.project);
        canvas.setColor(loaded.color);
        loaded = null;
        afterProjectLoaded();
        revealCanvas();
    }

    private boolean barsMeasured, pendingReveal;

    /** Muestra el lienzo con un fundido corto, cuando ya esta en su lugar. */
    private void revealCanvas() {
        if (!barsMeasured) {
            pendingReveal = true;
            return;
        }
        pendingReveal = false;
        canvas.post(new Runnable() {
            @Override
            public void run() {
                if (!canvas.isFitted()) canvas.fit();
                canvas.animate().alpha(1f).setDuration(140).start();
            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.pz_stay, R.anim.pz_fade_out);
    }

    /** Guarda sola en la galeria al salir y al hacer cambios de capas. */
    private void autosave(final boolean notify) {
        if (canvas != null && canvas.isTransformActive()) {
            saveAgain = true;
            return;
        }
        final Project p = canvas.getProject();
        if (p == null) return;
        if (saving) {
            saveAgain = true;
            return;
        }
        saving = true;
        dirty = false;
        if (projectId == null) projectId = ProjectStore.newId();
        final String id = projectId;
        final int color = canvas.getColor();
        final File dest = ProjectStore.fileFor(this, id);
        final File tmp = new File(dest.getAbsolutePath() + ".tmp");
        if (notify) toast("Guardando...");
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileOutputStream fo = new FileOutputStream(tmp);
                    ProjectIO.save(fo, p, color);
                    fo.close();
                    if (dest.exists() && !dest.delete()) throw new java.io.IOException("No se pudo reemplazar");
                    if (!tmp.renameTo(dest)) throw new java.io.IOException("No se pudo renombrar");
                    Bitmap th = p.previewBitmap(320);
                    ProjectStore.saveThumb(MainActivity.this, id, th);
                    th.recycle();
                    lastError = null;
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                saving = false;
                if (lastError != null) dirty = true;
                if (notify) toast(lastError != null ? "Error al guardar: " + lastError : "Guardado en la galeria");
                if (saveAgain) {
                    saveAgain = false;
                    if (dirty) autosave(false);
                }
            }
        });
    }

    // ==================================================================
    // Herramientas
    // ==================================================================

    private static final String[] GROUPS = {"SACAR", "PINTAR Y BORRAR", "REHACER LO DE ATRAS", "MOVER"};
    // {grupo, modo, sub, avanzada}   sub: 1 agrega a lo azul, 2 quita de lo azul
    private static final int[][] TOOLS = {
            {0, CanvasView.MODE_WAND, 0, 0}, {0, CanvasView.MODE_BGERASE, 0, 0},
            {0, CanvasView.MODE_BRUSH, 1, 0}, {0, CanvasView.MODE_BRUSH, 2, 0},
            {0, CanvasView.MODE_MARKER, 0, 0}, {0, CanvasView.MODE_LASSO, 0, 0},
            {0, CanvasView.MODE_SCISSORS, 0, 1}, {0, CanvasView.MODE_MAGNET, 0, 1},
            {1, CanvasView.MODE_PAINT, 0, 0}, {1, CanvasView.MODE_ERASER, 0, 0},
            {1, CanvasView.MODE_BUCKET, 0, 0}, {1, CanvasView.MODE_SMUDGE, 0, 0},
            {1, CanvasView.MODE_BLUR, 0, 0}, {1, CanvasView.MODE_LIQUIFY, 0, 0},
            {1, CanvasView.MODE_CURVE, 0, 0}, {1, CanvasView.MODE_POLY, 0, 0},
            {2, CanvasView.MODE_ZONE, 0, 0}, {2, CanvasView.MODE_CLONE, 0, 0},
            {2, CanvasView.MODE_LINE, 0, 1}, {2, CanvasView.MODE_PATCH, 0, 1},
            {2, CanvasView.MODE_HEAL, 0, 1}, {2, CanvasView.MODE_TONE, 0, 1},
            {3, CanvasView.MODE_PAN, 0, 0}, {3, CanvasView.MODE_MOVE, 0, 0},
            {3, CanvasView.MODE_TRANSFORM, 0, 0}
    };

    private String[] toolInfo(int mode, int sub) {
        switch (mode) {
            case CanvasView.MODE_BGERASE: return new String[]{"Borrar fondo",
                    "Borra el fondo de la capa sin tocar al personaje.",
                    "Con el balde encendido, un toque borra todo el fondo pegado de ese color. "
                            + "Apagalo para borrar con el pincel pasando por el borde.",
                    "Si se come el dibujo o deja restos, ajusta la tolerancia (la gota). "
                            + "El cuadrito con + prende la dilatacion; los tres puntos de al lado la ajustan."};
            case CanvasView.MODE_WAND: return new String[]{"Varita",
                    "Marca en azul una zona del mismo color.",
                    "Toca una zona. Abajo, el + agrega y el - quita.",
                    "Despues: en el cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_BRUSH: return sub == 2 ? new String[]{"Borrar azul",
                    "Quita parte de lo marcado en azul. No borra el dibujo.",
                    "Pinta sobre lo azul que sobra.", "Sirve para corregir lo que marco la Varita."}
                    : new String[]{"Marcar azul", "Marca a mano lo que quieres sacar.",
                    "Pinta encima. Lo azul es lo que vas a copiar o borrar.",
                    "Despues: cuadro punteado de arriba, Copiar a capa."};
            case CanvasView.MODE_ERASER: return new String[]{"Goma",
                    "Borra el dibujo de la capa elegida, como la goma de Ibis.",
                    "Elige la capa en Capas y borra. Si hay algo azul, solo borra dentro.",
                    "Si en Capas esta elegida la capa de seleccion, borra lo azul."};
            case CanvasView.MODE_MARKER: return new String[]{"Separar y quitar fondo",
                    "Separa partes o quita el fondo con toques o rayas, sin cuidado.",
                    "Toca o raya cada parte con un color y el fondo en gris (boton Fondo). Al soltar ves el resultado en vivo.",
                    "Check: cada parte sale en su capa. Boton borrador: se borra el fondo y queda el personaje."};
            case CanvasView.MODE_SCISSORS: return new String[]{"Tijeras", "Marca siguiendo el contorno.",
                    "Arrastra cerca de la linea y se pega sola. Vuelve al punto verde para cerrar.",
                    "Queda azul."};
            case CanvasView.MODE_MAGNET: return new String[]{"Magnetico", "Como las tijeras, de un solo trazo.",
                    "Arrastra por el contorno sin soltar. Al soltar se cierra.", "Queda azul."};
            case CanvasView.MODE_LASSO: return new String[]{"Lazo", "Marca rodeando con el dedo.",
                    "Dibuja alrededor de la zona.", "Queda azul."};
            case CanvasView.MODE_BUCKET: return new String[]{"Relleno",
                    "Pinta de un color toda una zona de golpe.",
                    "Toca la zona. Abajo: tolerancia (gota), dilatacion (cuadrito +, y sus tres puntos), "
                            + "mirar todas las capas o solo esta, y hasta la linea.",
                    "La dilatacion mete el color debajo del borde de la linea: no queda filo blanco."};
            case CanvasView.MODE_PAINT: return new String[]{"Brocha",
                    "Pinta con el color de abajo, con el pincel que elijas.",
                    "Pasa el dedo. Abajo: el borde con flechas prende \"No pasar la linea\": "
                            + "pinta solo la zona donde empiezas, sin cruzar la linea negra.",
                    "Si hay algo azul, solo pinta dentro. Repasar no oscurece: con poca opacidad queda parejo."};
            case CanvasView.MODE_CURVE: return new String[]{"Curva",
                    "Dibuja una linea curva suave por los puntos que pones.",
                    "Toca para poner puntos. Arrastra un punto para moverlo. Deshacer quita el ultimo.",
                    "Check: se dibuja con el color y el grosor de abajo. Llenar: pinta por dentro."};
            case CanvasView.MODE_POLY: return new String[]{"Polilinea",
                    "Lineas rectas de punto a punto: cuadros, bordes, vinetas.",
                    "Toca para poner puntos. Arrastra un punto para moverlo. Deshacer quita el ultimo.",
                    "Check: se dibuja con el color y el grosor de abajo. Llenar: pinta por dentro."};
            case CanvasView.MODE_PICKER: return new String[]{"Gotero", "Toma un color de la imagen.",
                    "Toca un color. Tambien manteniendo pulsado con cualquier herramienta.", "Despues: Brocha o Relleno."};
            case CanvasView.MODE_ZONE: return new String[]{"Zona",
                    "Rellena lo azul con el color plano que tiene alrededor.",
                    "Marca en azul lo que hay que rehacer (donde estaba el ojo). Toca dentro de lo azul.",
                    "Hazlo en la capa de atras, la que quedo con el hueco."};
            case CanvasView.MODE_CLONE: return new String[]{"Clonar", "Copia un trozo de la capa a otro lugar.",
                    "Toca de donde copiar (cruz roja). Despues pinta. Tiene espejo y giro abajo.",
                    "Para tapar huecos copiando algo parecido."};
            case CanvasView.MODE_LINE: return new String[]{"Linea",
                    "Continua una linea cortada dentro de lo azul.",
                    "Traza por donde seguia la linea. Se engancha a la linea real.", "Despues: Zona."};
            case CanvasView.MODE_PATCH: return new String[]{"Copiar zona",
                    "Rellena lo azul copiando sombras o brillos de otro lado.",
                    "Pinta en verde de donde copiar y toca el check.", "Para cuando Zona queda muy plano."};
            case CanvasView.MODE_HEAL: return new String[]{"Corrector",
                    "Copia de un lado a otro y funde el color para que no se note.",
                    "Toca de donde copiar. Despues pinta donde quieres.", "Para disimular cortes."};
            case CanvasView.MODE_TONE: return new String[]{"Trama",
                    "Continua la trama de puntos del manga dentro de lo azul.",
                    "Toca la trama que esta al lado de lo azul.", "Solo para manga."};
            case CanvasView.MODE_SMUDGE: return new String[]{"Difuminar",
                    "Arrastra y mezcla los pixeles siguiendo el dedo.",
                    "Pasa el pincel sobre pelo, sombras o bordes. Abajo puedes ajustar la fuerza.",
                    "Trabaja solo en la zona del pincel para mantener fluidez."};
            case CanvasView.MODE_BLUR: return new String[]{"Borrosidad",
                    "Desenfoca solo donde pintas.",
                    "Pasa varias veces para aumentar el desenfoque. Ajusta tamano y fuerza.",
                    "No desenfoca toda la capa."};
            case CanvasView.MODE_LIQUIFY: return new String[]{"Especial",
                    "Licua la imagen con cinco modos.",
                    "Arrastrar, Contraer, Expandir, Suavizar y Restaurar. Elige el modo abajo.",
                    "Restaurar vuelve hacia el estado que tenia la capa al entrar a Especial."};
            case CanvasView.MODE_TRANSFORM: return new String[]{"Transformar",
                    "Mueve, escala, gira, cambia perspectiva o deforma con malla.",
                    "Mover: arrastra; dos dedos escalan y giran. Perspectiva/Malla: arrastra sus puntos.",
                    "Usa check para aplicar o X para cancelar."};
            case CanvasView.MODE_MOVE: return new String[]{"Mover",
                    "Mueve la capa entera, o solo lo azul si hay algo marcado.",
                    "Arrastra.", ""};
            default: return new String[]{"Mano", "Mueve y acerca la imagen sin pintar.",
                    "Arrastra con un dedo. Con dos dedos haces zoom en cualquier herramienta.", ""};
        }
    }

    private void toolGrid() {
        final View panel = findViewById(R.id.toolPanel);
        final View scrim = findViewById(R.id.toolScrim);
        if (panel.getVisibility() == View.VISIBLE) {
            closeTools();
            return;
        }
        closeLayers();
        LinearLayout box = findViewById(R.id.toolPanelContent);
        box.removeAllViews();
        TextView tip = new TextView(this);
        tip.setText("Manten pulsada una herramienta para ver que hace");
        tip.setTextColor(0xFF9FC6FF);
        tip.setTextSize(10f);
        tip.setPadding(dp(4), dp(2), dp(4), dp(2));
        box.addView(tip);
        int cols = 4, lastGroup = -1, inRow = 0;
        LinearLayout row = null;
        for (int[] tdef : TOOLS) {
            final int group = tdef[0], mode = tdef[1], sub = tdef[2];
            if (group != lastGroup) {
                if (row != null) fillRow(row, inRow, cols);
                TextView h = new TextView(this);
                h.setText(GROUPS[group]);
                h.setTextColor(0xFF8A8A92);
                h.setTextSize(10f);
                h.setPadding(dp(4), dp(8), 0, dp(2));
                box.addView(h);
                row = null;
                inRow = 0;
                lastGroup = group;
            }
            if (row == null || inRow == cols) {
                if (row != null) fillRow(row, inRow, cols);
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row);
                inRow = 0;
            }
            boolean active = canvas.getMode() == mode && (sub == 0 || (sub == 2) == canvas.isSubtract());
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(2), dp(6), dp(2), dp(5));
            cell.setBackgroundResource(active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(1), dp(1), dp(1), dp(1));
            cell.setLayoutParams(clp);
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
            img.setImageResource(sub == 2 ? R.drawable.ic_remove : toolIcon(mode));
            cell.addView(img);
            TextView t = new TextView(this);
            t.setText(toolInfo(mode, sub)[0]);
            t.setTextColor(0xFFE0E0E0);
            t.setTextSize(9.5f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setMaxLines(1);
            t.setPadding(0, dp(3), 0, 0);
            cell.addView(t);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closeTools();
                    if (sub == 1) canvas.setSubtract(false);
                    if (sub == 2) canvas.setSubtract(true);
                    selectTool(mode);
                    cardFirstTime(mode, sub);
                }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showToolCard(mode, sub);
                    return true;
                }
            });
            row.addView(cell);
            inRow++;
        }
        if (row != null) fillRow(row, inRow, cols);

        View bottom = findViewById(R.id.bottomPanel);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) panel.getLayoutParams();
        lp.bottomMargin = bottom.getHeight() + dp(4);
        panel.setLayoutParams(lp);
        final int limit = canvas.getHeight() - bottom.getHeight() - findViewById(R.id.topBar).getHeight() - dp(16);
        scrim.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        panel.post(new Runnable() {
            @Override
            public void run() {
                if (limit > 0 && panel.getHeight() > limit) {
                    FrameLayout.LayoutParams l2 = (FrameLayout.LayoutParams) panel.getLayoutParams();
                    l2.height = limit;
                    panel.setLayoutParams(l2);
                }
            }
        });
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeTools();
            }
        });
    }

    private void selectTool(int mode) {
        canvas.setMode(mode);
        if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) canvas.resetCloneSource();
        syncSlider();
        updateUi();
    }

    /** Opciones propias de cada herramienta, solo iconos. */
    private void buildOptBar(int mode) {
        LinearLayout bar = findViewById(R.id.optBar);
        bar.removeAllViews();
        bar.setVisibility(View.VISIBLE);
        if (mode == CanvasView.MODE_BGERASE) {
            ImageButton bk = iconButton(canvas.isBgBucket() ? R.drawable.ic_bucket : R.drawable.ic_bgerase,
                    canvas.isBgBucket() ? "Un toque borra todo el fondo pegado" : "Pincel: borra por donde pasas",
                    new Runnable() {
                        public void run() {
                            canvas.setBgBucket(!canvas.isBgBucket());
                            canvas.showHud(canvas.isBgBucket() ? "Un toque borra todo el fondo"
                                    : "Pincel: borra por donde pasas");
                            updateUi();
                        }
                    });
            bk.setBackgroundResource(canvas.isBgBucket() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(bk);
            bar.addView(iconButton(canvas.isBgOnce() ? R.drawable.ic_once : R.drawable.ic_cont,
                    canvas.isBgOnce() ? "Toma el color una vez" : "Toma el color todo el rato", new Runnable() {
                        public void run() {
                            canvas.setBgOnce(!canvas.isBgOnce());
                            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("bg_once", canvas.isBgOnce()).apply();
                            canvas.showHud(canvas.isBgOnce() ? "Color: una vez al tocar" : "Color: sigue al pincel");
                            updateUi();
                        }
                    }));
            int lim = canvas.getBgLimit();
            final String[] names = {"Contiguo: solo lo pegado", "Disperso: tambien entre mechones",
                    "Bordes: respeta el contorno"};
            bar.addView(iconButton(lim == 0 ? R.drawable.ic_lim_cont : lim == 1 ? R.drawable.ic_lim_disp
                    : R.drawable.ic_lim_edge, names[lim], new Runnable() {
                public void run() {
                    canvas.setBgLimit((canvas.getBgLimit() + 1) % 3);
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_limit", canvas.getBgLimit()).apply();
                    canvas.showHud(names[canvas.getBgLimit()]);
                    updateUi();
                }
            }));
            ImageButton lock = iconButton(R.drawable.ic_lock, "Proteger el color de pintar", new Runnable() {
                public void run() {
                    canvas.setProtect(!canvas.isProtect());
                    canvas.showHud(canvas.isProtect() ? "Protegido el color cargado" : "Sin proteccion");
                    updateUi();
                }
            });
            lock.setBackgroundResource(canvas.isProtect() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(lock);
            bar.addView(iconButton(R.drawable.ic_range, "Tolerancia del fondo", new Runnable() {
                public void run() {
                    bgToleranceDialog();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_blur, "Suavidad del borde", new Runnable() {
                public void run() {
                    bgSoftnessDialog();
                }
            }));
            final ImageButton dil = iconButton(R.drawable.ic_grow, "Borde: quitar halo o recuperar filo", new Runnable() {
                public void run() {
                    bgExpOn = !bgExpOn;
                    applyBgExp();
                    canvas.showHud(bgExpOn ? "Dilatacion prendida: " + signed(bgExpAmt) + " px" : "Dilatacion apagada");
                    updateUi();
                }
            });
            dil.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    expansionDialog(false);
                    return true;
                }
            });
            dil.setBackgroundResource(bgExpOn ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(dil);
            bar.addView(dotsButton("Ajustar borde", new Runnable() {
                public void run() {
                    expansionDialog(false);
                }
            }));
        } else if (mode == CanvasView.MODE_BUCKET) {
            bar.addView(iconButton(R.drawable.ic_range, "Cuanto se parece el color", new Runnable() {
                public void run() {
                    fillToleranceDialog();
                }
            }));
            ImageButton fd = iconButton(R.drawable.ic_grow, "Dilatacion del relleno", new Runnable() {
                public void run() {
                    fillExpOn = !fillExpOn;
                    applyFillPrefs();
                    canvas.showHud(fillExpOn ? "Dilatacion prendida: " + signed(fillExpAmt) + " px" : "Dilatacion apagada");
                    updateUi();
                }
            });
            fd.setBackgroundResource(fillExpOn ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fd);
            bar.addView(dotsButton("Ajustar la dilatacion", new Runnable() {
                public void run() {
                    expansionDialog(true);
                }
            }));
            final boolean all = canvas.isFillAllLayers();
            ImageButton src = iconButton(all ? R.drawable.ic_layers : R.drawable.ic_image,
                    all ? "Mira todas las capas" : "Mira solo la capa elegida", new Runnable() {
                        public void run() {
                            canvas.setFillAllLayers(!canvas.isFillAllLayers());
                            applyFillPrefs();
                            canvas.showHud(canvas.isFillAllLayers()
                                    ? "Mira todas las capas: rellena debajo de la linea"
                                    : "Mira solo la capa elegida");
                            updateUi();
                        }
                    });
            src.setBackgroundResource(all ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(src);
            ImageButton ln = iconButton(R.drawable.ic_edge, "Hasta la linea", new Runnable() {
                public void run() {
                    canvas.setFillToLine(!canvas.isFillToLine());
                    applyFillPrefs();
                    canvas.showHud(canvas.isFillToLine() ? "Hasta la linea: SI" : "Hasta la linea: NO");
                    updateUi();
                }
            });
            ln.setBackgroundResource(canvas.isFillToLine() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(ln);
        } else if (mode == CanvasView.MODE_CURVE || mode == CanvasView.MODE_POLY) {
            final boolean curve = mode == CanvasView.MODE_CURVE;
            bar.addView(iconButton(curve ? R.drawable.ic_poly : R.drawable.ic_curve,
                    curve ? "Pasar a lineas rectas" : "Pasar a curva", new Runnable() {
                        public void run() {
                            canvas.setMode(curve ? CanvasView.MODE_POLY : CanvasView.MODE_CURVE);
                            canvas.showHud(curve ? "Polilinea: lineas rectas" : "Curva");
                            updateUi();
                        }
                    }));
            ImageButton fl = iconButton(R.drawable.ic_bucket, "Llenar por dentro", new Runnable() {
                public void run() {
                    canvas.setShapeFill(!canvas.isShapeFill());
                    canvas.showHud(canvas.isShapeFill() ? "Llenar: SI (necesita 3 puntos)" : "Llenar: NO");
                    updateUi();
                }
            });
            fl.setBackgroundResource(canvas.isShapeFill() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fl);
            bar.addView(iconButton(R.drawable.ic_remove, "Quitar el punto rojo", new Runnable() {
                public void run() {
                    canvas.shapeDeleteSelected();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todos los puntos", new Runnable() {
                public void run() {
                    canvas.shapeClear();
                }
            }));
            ImageButton ok = iconButton(R.drawable.ic_check, "Dibujar en la capa", new Runnable() {
                public void run() {
                    canvas.commitShape();
                    updateUi();
                }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
        } else if (mode == CanvasView.MODE_MARKER) {
            int lab = canvas.getMarkerLabel();
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(dp(4), 0, dp(4), 0);
            sw.setLayoutParams(lp);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(CanvasView.LABEL_COLORS[lab - 1]);
            g.setStroke(dp(2), 0xFFFFFFFF);
            sw.setBackground(g);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    labelPicker();
                }
            });
            bar.addView(sw);
            final int bgLab = CanvasView.LABEL_NAMES.length;
            final boolean onBg = lab == bgLab;
            ImageButton fondo = iconButton(R.drawable.ic_sub, onBg ? "Volver a marcar partes" : "Marcar fondo (gris)",
                    new Runnable() {
                        public void run() {
                            if (canvas.getMarkerLabel() == bgLab) {
                                canvas.setMarkerLabel(lastPartLabel);
                            } else {
                                lastPartLabel = canvas.getMarkerLabel();
                                canvas.setMarkerLabel(bgLab);
                            }
                            if (canvas.isSubtract()) canvas.setSubtract(false);
                            updateUi();
                        }
                    });
            fondo.setBackgroundResource(onBg ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(fondo);
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar rayones", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todos los rayones", new Runnable() {
                public void run() {
                    canvas.clearMarkers();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_bgerase, "Quitar fondo: queda lo marcado con color", new Runnable() {
                public void run() {
                    canvas.removeBackgroundByMarks();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Separar las partes", new Runnable() {
                public void run() {
                    canvas.separateParts();
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else if (mode == CanvasView.MODE_LINE) {
            bar.addView(iconButton(R.drawable.ic_join, "Unir solas las lineas cortadas", new Runnable() {
                public void run() {
                    canvas.autoJoinLines();
                }
            }));
        } else if (mode == CanvasView.MODE_ZONE || mode == CanvasView.MODE_TONE) {
            bar.addView(iconButton(R.drawable.ic_patch, "Tapar todo lo azul de una vez", new Runnable() {
                public void run() {
                    canvas.fillHoleInSelection();
                }
            }));
        } else if (mode == CanvasView.MODE_PATCH) {
            ImageButton sub = iconButton(R.drawable.ic_remove, "Borrar lo verde", new Runnable() {
                public void run() {
                    canvas.setSubtract(!canvas.isSubtract());
                    updateUi();
                }
            });
            sub.setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_tool);
            bar.addView(sub);
            bar.addView(iconButton(R.drawable.ic_trash, "Borrar todo lo verde", new Runnable() {
                public void run() {
                    canvas.clearPatchSource();
                }
            }));
            ImageButton go = iconButton(R.drawable.ic_check, "Rellenar lo azul", new Runnable() {
                public void run() {
                    canvas.runPatchFill();
                }
            });
            go.setBackgroundResource(R.drawable.bg_save);
            bar.addView(go);
        } else if (mode == CanvasView.MODE_SMUDGE || mode == CanvasView.MODE_BLUR) {
            bar.addView(iconButton(R.drawable.ic_range, "Fuerza del efecto", new Runnable() {
                public void run() { effectStrengthDialog(); }
            }));
        } else if (mode == CanvasView.MODE_LIQUIFY) {
            final int lt = canvas.getLiquifyType();
            int[] icons = {R.drawable.ic_liq_drag, R.drawable.ic_liq_pinch, R.drawable.ic_liq_expand, R.drawable.ic_liq_smooth, R.drawable.ic_liq_restore};
            String[] names = {"Arrastrar", "Contraer", "Expandir", "Suavizar", "Restaurar"};
            for (int i = 0; i < 5; i++) {
                final int which = i;
                ImageButton b = iconButton(icons[i], names[i], new Runnable() {
                    public void run() {
                        canvas.setLiquifyType(which);
                        updateUi();
                        if (getSharedPreferences("pz", MODE_PRIVATE).getBoolean("demo_on", true))
                            showDemo(CanvasView.MODE_LIQUIFY, 0);
                    }
                });
                b.setBackgroundResource(lt == i ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(b);
            }
            bar.addView(iconButton(R.drawable.ic_range, "Fuerza de deformacion", new Runnable() {
                public void run() { effectStrengthDialog(); }
            }));
            bar.addView(iconButton(R.drawable.ic_blur, "Borde de deformacion", new Runnable() {
                public void run() { effectSoftnessDialog(); }
            }));
        } else if (mode == CanvasView.MODE_TRANSFORM) {
            int tt = canvas.getTransformType();
            ImageButton free = compactIconButton(R.drawable.ic_move, "Mover, escalar y girar", new Runnable() {
                public void run() { canvas.setTransformType(0); canvas.showHud("Mover / escalar / girar"); updateUi(); }
            });
            free.setBackgroundResource(tt == 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(free);
            ImageButton persp = compactIconButton(R.drawable.ic_curve, "Perspectiva: 4 esquinas", new Runnable() {
                public void run() { canvas.setTransformType(1); canvas.showHud("Perspectiva: 1 dedo esquinas · 2 dedos mover/zoom"); updateUi(); }
            });
            persp.setBackgroundResource(tt == 1 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(persp);
            ImageButton mesh = compactIconButton(R.drawable.ic_transform, "Malla deformable", new Runnable() {
                public void run() { canvas.setTransformType(2); canvas.showHud("Malla: 1 dedo puntos · 2 dedos mover/zoom"); updateUi(); }
            });
            mesh.setBackgroundResource(tt == 2 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(mesh);
            ImageButton anchors = compactIconButton(R.drawable.ic_anchor_points, "Puntos y anclajes", new Runnable() {
                public void run() { canvas.setTransformType(3); canvas.showHud("Puntos: azul fija · naranja mueve · 2 dedos mover/zoom"); updateUi(); }
            });
            anchors.setBackgroundResource(tt == 3 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(anchors);

            if (tt == 2) {
                bar.addView(compactIconButton(R.drawable.ic_sub, "Malla menos densa", new Runnable() {
                    public void run() { canvas.changeTransformGrid(-1); updateUi(); }
                }));
                TextView gridInfo = new TextView(this);
                gridInfo.setText(canvas.getTransformGridCols() + "x" + canvas.getTransformGridRows());
                gridInfo.setTextColor(0xFFE6E6E6);
                gridInfo.setTextSize(11f);
                gridInfo.setGravity(android.view.Gravity.CENTER);
                gridInfo.setPadding(dp(2), 0, dp(2), 0);
                bar.addView(gridInfo, new LinearLayout.LayoutParams(dp(42), dp(36)));
                bar.addView(compactIconButton(R.drawable.ic_add, "Malla mas densa", new Runnable() {
                    public void run() { canvas.changeTransformGrid(1); updateUi(); }
                }));
                bar.addView(compactIconButton(R.drawable.ic_blur, "Suavidad de la malla", new Runnable() {
                    public void run() { transformMeshSmoothnessDialog(); }
                }));
            } else if (tt == 3) {
                final int am = canvas.getTransformAnchorAddMode();
                ImageButton fixed = compactIconButton(R.drawable.ic_anchor_fixed, "Agregar punto fijo azul", new Runnable() {
                    public void run() { canvas.setTransformAnchorAddMode(0); updateUi(); }
                });
                fixed.setBackgroundResource(am == 0 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(fixed);
                ImageButton movable = compactIconButton(R.drawable.ic_anchor_move, "Agregar punto movil naranja", new Runnable() {
                    public void run() { canvas.setTransformAnchorAddMode(1); updateUi(); }
                });
                movable.setBackgroundResource(am == 1 ? R.drawable.bg_tool_on : R.drawable.bg_tool);
                bar.addView(movable);
                bar.addView(compactIconButton(R.drawable.ic_trash, "Eliminar punto seleccionado", new Runnable() {
                    public void run() { canvas.deleteSelectedTransformAnchor(); }
                }));
                bar.addView(compactIconButton(R.drawable.ic_menu, "Mas opciones de puntos", new Runnable() {
                    public void run() { transformAnchorOptionsDialog(); }
                }));
            }

            ImageButton cancel = compactIconButton(R.drawable.ic_close, "Cancelar transformacion", new Runnable() {
                public void run() { canvas.cancelTransform(); updateUi(); }
            });
            bar.addView(cancel);
            ImageButton ok = compactIconButton(R.drawable.ic_check, "Aplicar transformacion", new Runnable() {
                public void run() { canvas.applyTransform(); updateUi(); }
            });
            ok.setBackgroundResource(R.drawable.bg_save);
            bar.addView(ok);
        } else if (mode == CanvasView.MODE_PAINT) {
            ImageButton ls = iconButton(R.drawable.ic_edge, "No pasar la linea negra", new Runnable() {
                public void run() {
                    boolean on = !canvas.isLineStop();
                    canvas.setLineStop(on);
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("line_stop", on).apply();
                    canvas.showHud(on ? "No pasa la linea: pinta solo la zona donde empiezas"
                            : "Pincel libre: pasa por encima de la linea");
                    updateUi();
                }
            });
            ls.setBackgroundResource(canvas.isLineStop() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(ls);
            bar.addView(iconButton(toolIcon(CanvasView.MODE_PAINT), "Pinceles", new Runnable() {
                public void run() {
                    brushPresets();
                }
            }));
            bar.addView(iconButton(R.drawable.ic_layers, "Crear capa Superposicion", new Runnable() {
                public void run() {
                    canvas.addOverlayPaintLayer();
                    updateUi();
                }
            }));
        } else if (mode == CanvasView.MODE_CLONE || mode == CanvasView.MODE_HEAL) {
            bar.addView(iconButton(R.drawable.ic_aim, "Elegir otro origen", new Runnable() {
                public void run() {
                    canvas.resetCloneSource();
                }
            }));
            ImageButton mir = iconButton(R.drawable.ic_mirror, "Espejo", new Runnable() {
                public void run() {
                    canvas.setCloneMirror(!canvas.isCloneMirror());
                    canvas.showHud(canvas.isCloneMirror() ? "Espejo: SI" : "Espejo: NO");
                    updateUi();
                }
            });
            mir.setBackgroundResource(canvas.isCloneMirror() ? R.drawable.bg_tool_on : R.drawable.bg_tool);
            bar.addView(mir);
            bar.addView(iconButton(R.drawable.ic_rotate, "Girar el origen", new Runnable() {
                public void run() {
                    cloneAngleDialog();
                }
            }));
        } else {
            bar.setVisibility(View.GONE);
        }
    }

    private void effectStrengthDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF);
        value.setTextSize(18f);
        value.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(95);
        int cur = Math.max(5, Math.round(canvas.getEffectStrength() * 100f));
        bar.setProgress(cur - 5);
        value.setText("Fuerza " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                int x = v + 5;
                canvas.setEffectStrength(x / 100f);
                value.setText("Fuerza " + x + "%");
            }
        });
        root.addView(value);
        root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Fuerza").setView(root).setPositiveButton("Listo", null).show();
    }

    private void effectSoftnessDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF);
        value.setTextSize(18f);
        value.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getEffectSoftness() * 100f)));
        bar.setProgress(cur);
        value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setEffectSoftness(v / 100f);
                value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value);
        root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Suavidad de Especial").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void transformMeshSmoothnessDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(18f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(100);
        int cur = Math.max(0, Math.min(100, Math.round(canvas.getTransformMeshSmoothness() * 100f)));
        bar.setProgress(cur); value.setText("Suavidad " + cur + "%");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                canvas.setTransformMeshSmoothness(v / 100f); value.setText("Suavidad " + v + "%");
            }
        });
        root.addView(value); root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Suavidad de malla").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    private void transformAnchorOptionsDialog() {
        final String[] items = {"Radio de influencia", "Borrar todos los puntos"};
        new AlertDialog.Builder(this)
                .setTitle("Puntos y anclajes")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == 0) transformAnchorRadiusDialog();
                        else if (which == 1) {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setMessage("¿Borrar todos los puntos?")
                                    .setNegativeButton("Cancelar", null)
                                    .setPositiveButton("Borrar", new android.content.DialogInterface.OnClickListener() {
                                        @Override public void onClick(android.content.DialogInterface d, int w) {
                                            canvas.clearTransformAnchors();
                                        }
                                    }).show();
                        }
                    }
                }).show();
    }

    private void transformAnchorRadiusDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        final TextView value = new TextView(this);
        value.setTextColor(0xFFFFFFFF); value.setTextSize(18f); value.setGravity(Gravity.CENTER);
        final SeekBar bar = new SeekBar(this); bar.setMax(860);
        int cur = Math.max(40, Math.min(900, Math.round(canvas.getTransformAnchorRadius())));
        bar.setProgress(cur - 40); value.setText("Radio " + cur + " px");
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                int px = v + 40;
                canvas.setTransformAnchorRadius(px);
                value.setText("Radio " + px + " px");
            }
        });
        root.addView(value); root.addView(bar);
        new AlertDialog.Builder(this).setTitle("Influencia de los puntos").setView(root)
                .setPositiveButton("Listo", null).show();
    }

    /**
     * Dilatacion propia de Borrar fondo. Se prende y apaga con un toque;
     * manteniendo presionado se ajusta de 1 en 1. Funciona en vivo mientras
     * pasas el pincel: al soltar no se come nada mas.
     */
    private boolean bgExpOn;
    private int bgExpAmt = 2;
    private static final int EXP_MIN = -3, EXP_MAX = 10;

    private void applyBgExp() {
        canvas.setBgExpansion(bgExpOn ? bgExpAmt : 0f);
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putBoolean("bg_exp_on", bgExpOn).putInt("bg_exp_amt", bgExpAmt).apply();
    }

    // ---- Relleno: opciones guardadas ----
    private boolean fillExpOn = true;
    private int fillExpAmt = 2;

    private void applyFillPrefs() {
        canvas.setFillExpansion(fillExpOn ? fillExpAmt : 0f);
        getSharedPreferences("pz", MODE_PRIVATE).edit()
                .putBoolean("fill_exp_on", fillExpOn).putInt("fill_exp_amt", fillExpAmt)
                .putInt("fill_tol", canvas.getFillTolerance())
                .putBoolean("fill_all", canvas.isFillAllLayers())
                .putBoolean("fill_line", canvas.isFillToLine()).apply();
    }

    private void loadFillPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        fillExpOn = sp.getBoolean("fill_exp_on", true);
        fillExpAmt = sp.getInt("fill_exp_amt", 2);
        canvas.setFillTolerance(sp.getInt("fill_tol", 32));
        canvas.setFillAllLayers(sp.getBoolean("fill_all", true));
        canvas.setFillToLine(sp.getBoolean("fill_line", true));
        canvas.setFillExpansion(fillExpOn ? fillExpAmt : 0f);
    }

    private static String signed(int v) {
        return (v > 0 ? "+" : "") + v;
    }

    /** Boton de tres puntos para abrir las opciones de al lado. */
    private ImageButton dotsButton(String name, Runnable r) {
        ImageButton b = iconButton(R.drawable.ic_menu, name, r);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(26), dp(38)));
        b.setPadding(dp(2), dp(9), dp(2), dp(9));
        b.setBackground(null);
        return b;
    }

    private void fillToleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getFillTolerance());
        final TextView t = new TextView(this);
        t.setText("Tolerancia " + canvas.getFillTolerance());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta rellena colores mas distintos. Si se sale de la zona, bajala.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Tolerancia " + v);
                canvas.setFillTolerance(v);
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                applyFillPrefs();
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Dilatacion de 1 en 1, para Borrar fondo (fill=false) o Relleno (fill=true). */
    private void expansionDialog(final boolean fill) {
        final int min = fill ? 0 : EXP_MIN;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.setBackgroundColor(0xFF232329);
        final TextView t = new TextView(this);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        final SeekBar bar = new SeekBar(this);
        bar.setMax(EXP_MAX - min);
        final int cur = fill ? fillExpAmt : bgExpAmt;
        bar.setProgress(cur - min);
        t.setText(expText(cur));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageButton minus = iconButton(R.drawable.ic_sub, "Menos 1", new Runnable() {
            public void run() {
                bar.setProgress(Math.max(0, bar.getProgress() - 1));
                setExp(fill, bar.getProgress() + min, t);
            }
        });
        ImageButton plus = iconButton(R.drawable.ic_add, "Mas 1", new Runnable() {
            public void run() {
                bar.setProgress(Math.min(EXP_MAX - min, bar.getProgress() + 1));
                setExp(fill, bar.getProgress() + min, t);
            }
        });
        row.addView(minus);
        row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(plus);
        TextView hint = new TextView(this);
        hint.setText(fill
                ? "Cuantos pixeles se mete el color debajo del borde de la linea. Asi no queda filo blanco."
                : "Mas alto: se come el borde de color pegado al fondo, sin tocar la linea negra. "
                + "Negativo: deja un poco de borde. Se ve en vivo mientras pasas el dedo.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        hint.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        root.addView(row);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (u) setExp(fill, v + min, t);
            }
        });
        new AlertDialog.Builder(this).setView(root)
                .setNeutralButton("Restablecer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        setExp(fill, 2, null);
                    }
                })
                .setPositiveButton("Listo", null)
                .setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface d) {
                        updateUi();
                    }
                })
                .show();
    }

    private void setExp(boolean fill, int amount, TextView label) {
        if (fill) {
            fillExpAmt = Math.max(0, Math.min(EXP_MAX, amount));
            fillExpOn = true;
            applyFillPrefs();
            if (label != null) label.setText(expText(fillExpAmt));
        } else {
            setBgExp(amount, label);
        }
    }

    /** Al ajustar el valor, la dilatacion queda prendida. */
    private void setBgExp(int amount, TextView label) {
        bgExpAmt = Math.max(EXP_MIN, Math.min(EXP_MAX, amount));
        bgExpOn = true;
        applyBgExp();
        if (label != null) label.setText(expText(bgExpAmt));
    }

    private static String expText(int e) {
        return "Dilatacion " + (e > 0 ? "+" : "") + e + " px";
    }

    /** Tolerancia propia de Borrar fondo: no toca la de la varita. */
    private void bgToleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getBgTolerance());
        final TextView t = new TextView(this);
        t.setText("Tolerancia " + canvas.getBgTolerance());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta borra mas de golpe. Si se come el dibujo, bajala.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Tolerancia " + v);
                canvas.setBgTolerance(v);
                if (u) getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_tol", v).apply();
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Suavidad independiente: crea una transicion de alfa en el borde en vez de un corte duro. */
    private void bgSoftnessDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getBgSoftness());
        final TextView t = new TextView(this);
        t.setText("Suavidad " + canvas.getBgSoftness());
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(16f);
        t.setGravity(android.view.Gravity.CENTER);
        TextView hint = new TextView(this);
        hint.setText("Mas alta suaviza el borde y ayuda a quitar halos. Si queda demasiado transparente, bajala.");
        hint.setTextColor(0xFFAAAAAA);
        hint.setTextSize(12f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        root.addView(hint);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText("Suavidad " + v);
                canvas.setBgSoftness(v);
                if (u) getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("bg_soft", v).apply();
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    private void cloneAngleDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(360);
        bar.setProgress(Math.round(canvas.getCloneAngle()) + 180);
        final TextView t = new TextView(this);
        t.setText(Math.round(canvas.getCloneAngle()) + "°");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int a = v - 180;
                for (int snap : new int[]{-180, -90, 0, 90, 180}) if (Math.abs(a - snap) <= 4) a = snap;
                t.setText(a + "°");
                canvas.setCloneAngle(a);
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    // ==================================================================
    // Menu de seleccion (cuadro punteado de arriba)
    // ==================================================================

    private void selectionMenu() {
        if (!needProject()) return;
        int[] icons = {R.drawable.ic_layer_add, R.drawable.ic_sel_delete, R.drawable.ic_clone,
                R.drawable.ic_sel_keep, R.drawable.ic_sel_invert, R.drawable.ic_close};
        String[] names = {"Copiar a capa", "Cortar a capa", "Duplicar capa", "Dejar solo esto",
                "Invertir", "Quitar azul"};
        Runnable[] actions = {
                new Runnable() { public void run() { partFromSelectionDialog(false); } },
                new Runnable() { public void run() { partFromSelectionDialog(true); } },
                new Runnable() { public void run() { canvas.duplicateActive(); updateUi(); } },
                new Runnable() { public void run() { canvas.keepSelectionInLayer(); } },
                new Runnable() { public void run() { canvas.invertSelection(); } },
                new Runnable() { public void run() { canvas.clearSelection(); } }
        };
        demoNext = new int[]{SelDemoView.COPY, SelDemoView.CUT, SelDemoView.DUP, SelDemoView.KEEP,
                SelDemoView.INVERT, SelDemoView.CLEAR};
        showIconGrid(null, icons, names, actions, 3, -1);
        demoNext = null;
    }

    /** Crear una parte con nombre y solapamiento listos para Alight Motion. */
    private void partFromSelectionDialog(final boolean cut) {
        Project p = canvas.getProject();
        if (p == null || !p.hasSelection()) {
            toast("Primero marca en azul la parte");
            return;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(8), dp(16), dp(4));

        TextView hint = new TextView(this);
        hint.setText("El solapamiento deja unos pixeles escondidos para que al mover la parte no aparezcan huecos.");
        hint.setTextColor(0xFFCCCCCC);
        hint.setTextSize(12.5f);
        root.addView(hint);

        final String[] names = {"parte", "cabeza", "cabello_frontal", "cabello_trasero",
                "brazo_I", "brazo_D", "mano_I", "mano_D", "torso", "pierna_I", "pierna_D"};
        final android.widget.Spinner spin = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> ad = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, names);
        spin.setAdapter(ad);
        root.addView(spin);

        final TextView ovText = new TextView(this);
        final SeekBar ov = new SeekBar(this);
        ov.setMax(12);
        ov.setProgress(6);
        ovText.setText("Solapamiento para animar: 6 px");
        ov.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar b, int v, boolean u) {
                ovText.setText("Solapamiento para animar: " + v + " px");
            }
        });
        root.addView(ovText);
        root.addView(ov);

        new AlertDialog.Builder(this)
                .setTitle(cut ? "Cortar parte para animar" : "Crear parte para animar")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        canvas.layerFromSelection(cut, ov.getProgress(), names[spin.getSelectedItemPosition()]);
                        updateUi();
                        if (layersOpen()) buildLayersPanel();
                    }
                }).show();
    }

    private int[] demoNext;
    private int lastPartLabel = 1;
    private ImageButton wandGear;

    private static final String[][] SEL_INFO = {
            {"Copiar a capa", "Copia lo azul a una capa nueva. La imagen queda igual."},
            {"Cortar a capa", "Saca lo azul a una capa nueva y lo borra de la capa original."},
            {"Duplicar capa", "Hace una copia de la capa entera."},
            {"Dejar solo esto", "Borra todo lo que no esta en azul, en la capa elegida."},
            {"Invertir", "Lo azul pasa a no azul y al reves. Elige el fondo con la varita e invierte para quedarte con el personaje."},
            {"Quitar azul", "Borra la seleccion. Los dibujos no se tocan."},
            {"Ampliar", "Agranda lo azul unos pixeles hacia afuera."},
            {"Refinar borde", "Ajusta el borde azul al dibujo real. Para pelo y bordes finos."},
            {"Cerrar puntos", "Rellena los huequitos que quedaron sin azul dentro de la seleccion."},
            {"Gama color", "Selecciona todos los pixeles de un color parecido en toda la imagen."},
            {"Tapar hueco", "Rellena lo azul con el color de al lado y une la linea negra. Usalo en el cuerpo despues de sacar un brazo."},
            {"Cerrar tijeras", "Cierra el contorno que marcaste con las tijeras y lo vuelve azul."},
            {"Varita que no se escapa", "La varita respeta la linea negra aunque tenga cortes chicos. Se prende y apaga en el menu de tres puntos."},
            {"Separar partes", "Raya cada parte con un color (pelo, cuerpo, brazo) y el fondo en gris. Toca el check y cada parte sale en su capa, cortada sobre la linea negra."}
    };

    /** Ficha con la animacion de antes y despues. */
    private void showSelCard(int scene) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(SEL_INFO[scene][0]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        SelDemoView art = new SelDemoView(this, scene);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(200), dp(200));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        root.addView(cardLine("", SEL_INFO[scene][1]));
        new AlertDialog.Builder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    // ==================================================================
    // Panel de capas, como Ibis
    // ==================================================================

    private void toggleLayersPanel() {
        if (!needProject()) return;
        View panel = findViewById(R.id.layersPanel);
        if (panel.getVisibility() == View.VISIBLE) {
            closeLayers();
        } else {
            closeTools();
            panel.setVisibility(View.VISIBLE);
            hideForLayers(true);
            buildLayersPanel();
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            if (!sp.getBoolean("hint_layer_drag", false)) {
                sp.edit().putBoolean("hint_layer_drag", true).apply();
                toast("Arrastra las rayitas de la derecha para subir o bajar una capa. Toca la capa elegida para cambiarle el nombre.");
            }
        }
    }

    private void closeLayers() {
        if (layerDrag != null) layerDrag.cancel();
        findViewById(R.id.layersPanel).setVisibility(View.GONE);
        canvas.setCompactHold(false);
        hideForLayers(false);
        updateUi();
    }

    private void hideForLayers(boolean hide) {
        int v = hide ? View.GONE : View.VISIBLE;
        findViewById(R.id.sizeRow).setVisibility(v);
        findViewById(R.id.opacityRow).setVisibility(v);
        if (hide) {
            findViewById(R.id.selBar).setVisibility(View.GONE);
            findViewById(R.id.optBar).setVisibility(View.GONE);
        }
    }

    private boolean layersOpen() {
        return findViewById(R.id.layersPanel).getVisibility() == View.VISIBLE;
    }

    // ------------------------------------------------------------------
    // Filas de capas: se crean una vez y despues solo se actualizan.
    // Antes se borraba y rehacia todo el panel en cada toque (y las
    // miniaturas tambien), por eso se trababa.
    // ------------------------------------------------------------------

    private static final class RowHolder {
        Layer layer;
        LinearLayout row;
        ImageView thumb;
        TextView text;
        ImageButton eye;
    }

    private final java.util.IdentityHashMap<Layer, RowHolder> rowHolders = new java.util.IdentityHashMap<Layer, RowHolder>();
    private final java.util.IdentityHashMap<Layer, Bitmap> thumbCache = new java.util.IdentityHashMap<Layer, Bitmap>();
    private final java.util.concurrent.ExecutorService thumbPool = java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean thumbsBusy, thumbsAgain, layerActionsBuilt, opacityRowReady, panelRefreshing;
    private LayerDrag layerDrag;
    private LinearLayout selectionPanelRow;
    private TextView selectionPanelText;

    private void buildLayersPanel() {
        final Project p = canvas.getProject();
        if (p == null || panelRefreshing) return;
        if (layerDrag != null && layerDrag.active) return;
        panelRefreshing = true;
        try {
            buildViewBg();
            setupOpacityRow();
            updateOpacityRow();

            LinearLayout list = findViewById(R.id.layersList);
            java.util.IdentityHashMap<Layer, Boolean> alive = new java.util.IdentityHashMap<Layer, Boolean>();
            for (Layer l : p.layers) alive.put(l, Boolean.TRUE);
            for (Layer l : new ArrayList<Layer>(rowHolders.keySet()))
                if (!alive.containsKey(l)) rowHolders.remove(l);
            for (Layer l : new ArrayList<Layer>(thumbCache.keySet())) {
                if (!alive.containsKey(l)) {
                    Bitmap old = thumbCache.remove(l);
                    if (old != null && !old.isRecycled()) old.recycle();
                }
            }

            ensureSelectionPanelRow();
            int n = p.layers.size();
            boolean same = list.getChildCount() == n + 1 && list.getChildAt(0) == selectionPanelRow;
            for (int pos = 0; pos < n; pos++) {
                Layer l = p.layers.get(n - 1 - pos);
                RowHolder h = rowHolders.get(l);
                if (h == null) {
                    h = makeRow(l);
                    rowHolders.put(l, h);
                    same = false;
                } else if (same && list.getChildAt(pos + 1) != h.row) {
                    same = false;
                }
            }
            if (!same) {
                list.removeAllViews();
                list.addView(selectionPanelRow);
                for (int pos = 0; pos < n; pos++) {
                    RowHolder h = rowHolders.get(p.layers.get(n - 1 - pos));
                    h.row.setTranslationY(0f);
                    list.addView(h.row);
                }
            }
            bindSelectionPanelRow(p);
            for (int i = 0; i < n; i++) bindRow(rowHolders.get(p.layers.get(i)), i == p.active);
            if (!layerActionsBuilt) {
                buildLayerActions();
                layerActionsBuilt = true;
            }
        } finally {
            panelRefreshing = false;
        }
        requestThumbs();
    }

    private void ensureSelectionPanelRow() {
        if (selectionPanelRow != null) return;
        selectionPanelRow = rowBase(false);
        ImageView icon = thumb(null);
        icon.setImageResource(R.drawable.ic_select);
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));
        selectionPanelText = rowText("Seleccion", "Lo azul", true);
        ImageButton clear = iconButton(R.drawable.ic_close, "Quitar seleccion", new Runnable() {
            @Override public void run() {
                canvas.clearSelection();
                buildLayersPanel();
            }
        });
        clear.setBackground(null);
        selectionPanelRow.addView(icon);
        selectionPanelRow.addView(selectionPanelText);
        selectionPanelRow.addView(clear);
        selectionPanelRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Project p = canvas.getProject();
                if (p == null) return;
                canvas.setActive(Project.SEL);
                buildLayersPanel();
            }
        });
    }

    private void bindSelectionPanelRow(Project p) {
        if (selectionPanelRow == null || p == null) return;
        boolean on = p.active == Project.SEL;
        selectionPanelRow.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        selectionPanelText.setText("Seleccion\n" + (p.hasSelection() ? "Azul activo - toca para editar" : "Vacia - pinta o usa Varita"));
        selectionPanelText.setTextColor(p.hasSelection() ? 0xFFFFFFFF : 0xFF9A9A9A);
    }

    private void bindRow(RowHolder h, boolean on) {
        Layer l = h.layer;
        h.row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        h.row.setPadding(dp(6), dp(6), dp(2), dp(6));
        StringBuilder sub = new StringBuilder();
        sub.append(l.opacity * 100 / 255).append('%');
        if (l.mode != Layer.MODE_NORMAL) sub.append("  ").append(Layer.MODE_NAMES[l.mode]);
        if (l.alphaLock) sub.append("  alfa bloq.");
        h.text.setText((l.clip ? "\u21B3 " : "") + l.name + "\n" + sub);
        // la capa con recorte va corrida a la derecha, como en Ibis
        ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) h.row.getLayoutParams();
        int want = l.clip ? dp(18) : 0;
        if (mlp != null && mlp.leftMargin != want) {
            mlp.leftMargin = want;
            h.row.setLayoutParams(mlp);
        }
        h.text.setTextColor(l.visible ? 0xFFFFFFFF : 0xFF7A7A7A);
        h.eye.setImageResource(l.visible ? R.drawable.ic_eye : R.drawable.ic_eye_off);
        h.eye.setContentDescription(l.visible ? "Ocultar" : "Mostrar");
        Bitmap tb = thumbCache.get(l);
        if (tb != null && h.thumb.getTag() != tb) {
            h.thumb.setImageBitmap(tb);
            h.thumb.setTag(tb);
        }
    }

    private RowHolder makeRow(final Layer l) {
        final RowHolder h = new RowHolder();
        h.layer = l;
        h.row = rowBase(false);
        h.thumb = thumb(null);
        h.thumb.setBackgroundColor(0xFF3A3A40);
        h.text = rowText(l.name, "", true);
        h.eye = iconButton(R.drawable.ic_eye, "Ocultar o mostrar", new Runnable() {
            public void run() {
                l.visible = !l.visible;
                bindRow(h, canvas.getProject().activeLayer() == l);
                canvas.layersChangedAsync();
            }
        });
        h.eye.setBackground(null);
        ImageView handle = new ImageView(this);
        handle.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(48)));
        handle.setPadding(dp(8), dp(12), dp(8), dp(12));
        handle.setScaleType(ImageView.ScaleType.FIT_CENTER);
        handle.setImageResource(R.drawable.ic_drag);
        handle.setContentDescription("Arrastra para subir o bajar la capa");
        h.row.addView(h.thumb);
        h.row.addView(h.text);
        h.row.addView(h.eye);
        h.row.addView(handle);
        h.row.setOnTouchListener(new RowTouch(h, false));
        handle.setOnTouchListener(new RowTouch(h, true));
        return h;
    }

    /** Toque corto: elige la capa (o abre sus opciones si ya era la elegida). Mantener: arrastrar. */
    private void onRowTap(RowHolder h) {
        Project p = canvas.getProject();
        if (p == null) return;
        int idx = p.layers.indexOf(h.layer);
        if (idx < 0) return;
        if (idx == p.active) layerOptions(h.layer);
        else canvas.setActive(idx); // avisa por onChanged y el panel se actualiza solo
    }

    private final class RowTouch implements View.OnTouchListener {
        final RowHolder h;
        final boolean handle;
        float downX, downY, lastY;
        boolean pressed, dragging;
        final Runnable longPress;

        RowTouch(final RowHolder h, boolean handle) {
            this.h = h;
            this.handle = handle;
            longPress = new Runnable() {
                @Override
                public void run() {
                    if (pressed && !dragging) {
                        dragging = true;
                        h.row.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        startDrag(h, lastY);
                    }
                }
            };
        }

        @Override
        public boolean onTouch(View v, android.view.MotionEvent e) {
            int slop = android.view.ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = lastY = e.getRawY();
                    pressed = true;
                    dragging = false;
                    if (handle) {
                        dragging = true;
                        startDrag(h, lastY);
                    } else {
                        h.row.postDelayed(longPress, android.view.ViewConfiguration.getLongPressTimeout());
                    }
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    lastY = e.getRawY();
                    if (dragging) {
                        if (layerDrag != null) layerDrag.move(lastY);
                    } else if (Math.abs(e.getRawX() - downX) > slop || Math.abs(lastY - downY) > slop) {
                        pressed = false;
                        h.row.removeCallbacks(longPress);
                    }
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                    h.row.removeCallbacks(longPress);
                    if (dragging) {
                        if (layerDrag != null) layerDrag.finish();
                    } else if (pressed && !handle) {
                        onRowTap(h);
                    }
                    pressed = dragging = false;
                    return true;
                case android.view.MotionEvent.ACTION_CANCEL:
                    h.row.removeCallbacks(longPress);
                    if (dragging && layerDrag != null) layerDrag.finish();
                    pressed = dragging = false;
                    return true;
            }
            return false;
        }
    }

    private void startDrag(RowHolder h, float rawY) {
        if (layerDrag != null && layerDrag.active) return;
        layerDrag = new LayerDrag(h, rawY);
    }

    /** Arrastrar una capa como en Ibis: las demas se corren para hacerle espacio. */
    private final class LayerDrag {
        final RowHolder h;
        final LinearLayout list;
        final ScrollView scroll;
        final float startY;
        final int startScroll, from, n;
        final float pitch;
        int to;
        boolean active = true;

        LayerDrag(RowHolder h, float rawY) {
            this.h = h;
            list = findViewById(R.id.layersList);
            scroll = findViewById(R.id.layersScroll);
            startY = rawY;
            startScroll = scroll.getScrollY();
            from = to = list.indexOfChild(h.row);
            n = list.getChildCount();
            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) h.row.getLayoutParams();
            pitch = h.row.getHeight() + lp.topMargin + lp.bottomMargin;
            scroll.requestDisallowInterceptTouchEvent(true);
            canvas.setCompactHold(true);
            h.row.setElevation(dp(10));
            h.row.animate().scaleX(1.03f).scaleY(1.03f).alpha(0.94f).setDuration(90).start();
            if (from < 0 || pitch <= 0) active = false;
        }

        void move(float rawY) {
            if (!active) return;
            int[] loc = new int[2];
            scroll.getLocationOnScreen(loc);
            float yIn = rawY - loc[1];
            int edge = dp(40);
            if (yIn < edge) scroll.scrollBy(0, -dp(12));
            else if (yIn > scroll.getHeight() - edge) scroll.scrollBy(0, dp(12));
            float dy = (rawY - startY) + (scroll.getScrollY() - startScroll);
            // La fila 0 es la capa Seleccion y no forma parte del orden de capas.
            // Nunca dejamos que una capa normal se arrastre por encima de ella.
            int firstLayerRow = selectionPanelRow != null && list.getChildAt(0) == selectionPanelRow ? 1 : 0;
            float min = (firstLayerRow - from) * pitch, max = (n - 1 - from) * pitch;
            if (dy < min) dy = min;
            if (dy > max) dy = max;
            h.row.setTranslationY(dy);
            int t = Math.round(from + dy / pitch);
            t = Math.max(firstLayerRow, Math.min(n - 1, t));
            if (t == to) return;
            to = t;
            for (int k = 0; k < n; k++) {
                if (k == from) continue;
                View c = list.getChildAt(k);
                float want = 0f;
                if (from < to && k > from && k <= to) want = -pitch;
                else if (from > to && k >= to && k < from) want = pitch;
                if (c.getTranslationY() != want) c.animate().translationY(want).setDuration(110).start();
            }
        }

        void finish() {
            if (!active) return;
            active = false;
            float dy = h.row.getTranslationY();
            for (int k = 0; k < list.getChildCount(); k++) {
                View c = list.getChildAt(k);
                c.animate().cancel();
                if (c != h.row) c.setTranslationY(0f);
            }
            if (to != from && from >= 0) {
                list.removeView(h.row);
                list.addView(h.row, to);
                h.row.setTranslationY(dy - (to - from) * pitch);
                int fromIdx = n - 1 - from, toIdx = n - 1 - to;
                canvas.moveLayer(fromIdx, toIdx);
            }
            h.row.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(1f).setDuration(120)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            h.row.setElevation(0f);
                        }
                    }).start();
            canvas.setCompactHold(false);
            buildLayersPanel();
        }

        void cancel() {
            if (!active) return;
            to = from;
            finish();
        }
    }

    /** Miniaturas en segundo plano: se ve la anterior hasta que llega la nueva. */
    private void requestThumbs() {
        if (!layersOpen()) return;
        if (thumbsBusy) {
            thumbsAgain = true;
            return;
        }
        final Project p = canvas.getProject();
        if (p == null) return;
        thumbsBusy = true;
        thumbsAgain = false;
        final List<Layer> ls = new ArrayList<Layer>(p.layers);
        final Bitmap[] out = new Bitmap[ls.size()];
        thumbPool.execute(new Runnable() {
            @Override
            public void run() {
                for (int k = 0; k < ls.size(); k++) {
                    try {
                        out[k] = Thumbs.forLayer(p, ls.get(k), 96);
                    } catch (Throwable ignored) {
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (destroyed) {
                            for (Bitmap b : out) if (b != null && !b.isRecycled()) b.recycle();
                            return;
                        }
                        thumbsBusy = false;
                        if (canvas.getProject() == p) {
                            for (int k = 0; k < ls.size(); k++) {
                                if (out[k] == null) continue;
                                thumbCache.put(ls.get(k), out[k]);
                                RowHolder h = rowHolders.get(ls.get(k));
                                if (h != null) {
                                    h.thumb.setImageBitmap(out[k]);
                                    h.thumb.setTag(out[k]);
                                }
                            }
                        }
                        if (thumbsAgain) requestThumbs();
                    }
                });
            }
        });
    }

    /** Opacidad arriba, fija, como en Ibis: se ve al momento y sin trabarse. */
    private void setupOpacityRow() {
        if (opacityRowReady) return;
        opacityRowReady = true;
        SeekBar ob = findViewById(R.id.layersOpBar);
        ob.setMax(100);
        ob.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (!u) return;
                Project p = canvas.getProject();
                Layer l = p == null ? null : p.activeLayer();
                if (l == null) return;
                l.opacity = Math.round(v * 255 / 100f);
                ((TextView) findViewById(R.id.layersOpText)).setText("Opacidad " + v + "%");
                RowHolder h = rowHolders.get(l);
                if (h != null) bindRow(h, true);
                canvas.refreshDisplayAsync();
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                canvas.layersChangedAsync();
            }
        });
    }

    private void updateOpacityRow() {
        Project p = canvas.getProject();
        Layer l = p == null ? null : p.activeLayer();
        SeekBar ob = findViewById(R.id.layersOpBar);
        TextView ot = findViewById(R.id.layersOpText);
        ob.setEnabled(l != null);
        int v = l == null ? 100 : l.opacity * 100 / 255;
        if (ob.getProgress() != v) ob.setProgress(v);
        ot.setText("Opacidad " + v + "%");
    }

    /** Fondo para mirar: cuadros claros, cuadros oscuros, blanco, negro, verde. */
    private void buildViewBg() {
        LinearLayout row = findViewById(R.id.viewBgRow);
        if (row.getChildCount() != CanvasView.VIEW_BG.length) {
            row.removeAllViews();
            for (int k = 0; k < CanvasView.VIEW_BG.length; k++) {
                final int idx = k;
                View sw = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
                lp.setMargins(dp(3), 0, dp(3), 0);
                sw.setLayoutParams(lp);
                sw.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        canvas.setViewBg(idx);
                        buildViewBg();
                    }
                });
                row.addView(sw);
            }
        }
        for (int k = 0; k < CanvasView.VIEW_BG.length; k++) {
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(6));
            int[] c = CanvasView.VIEW_BG[k];
            if (c[0] != c[1]) g.setColors(new int[]{c[0], c[1]});
            else g.setColor(c[0]);
            boolean on = canvas.getViewBg() == k;
            g.setStroke(dp(on ? 3 : 1), on ? 0xFF2F6BD8 : 0xFF777777);
            row.getChildAt(k).setBackground(g);
        }
    }

    /** Botones de abajo del panel: solo lo que hace falta, sin repetir. */
    private void buildLayerActions() {
        LinearLayout bar = findViewById(R.id.layersActions);
        bar.removeAllViews();
        addAction(bar, R.drawable.ic_add, "Nueva", new Runnable() {
            public void run() {
                canvas.addEmptyLayer();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_dup, "Duplicar", new Runnable() {
            public void run() {
                canvas.duplicateActive();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_ref_color, "Imagen color", new Runnable() {
            public void run() {
                // Primera vez abre Archivos/Galeria. Si ya existe una referencia, la
                // abre para tomar mas colores y desde ahi se puede cambiar la imagen.
                requestColorReference(new ColorPickTarget() {
                    @Override public void onColor(int color) {
                        canvas.setColor(color | 0xFF000000);
                        canvas.showHud(String.format(Locale.US, "Color #%06X", color & 0xFFFFFF));
                        updateUi();
                    }
                });
            }
        });
        addAction(bar, R.drawable.ic_layer_add, "De lo azul", new Runnable() {
            public void run() {
                partFromSelectionDialog(false);
            }
        });
        addAction(bar, R.drawable.ic_merge, "Combinar", new Runnable() {
            public void run() {
                canvas.mergeDown();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_sel_delete, "Limpiar", new Runnable() {
            public void run() {
                canvas.clearActive();
                afterLayerOp();
            }
        });
        addAction(bar, R.drawable.ic_trash, "Eliminar", new Runnable() {
            public void run() {
                canvas.deleteActive();
                afterLayerOp();
            }
        });
    }

    private void addAction(LinearLayout bar, int icon, String name, final Runnable r) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(android.view.Gravity.CENTER);
        cell.setPadding(dp(2), dp(6), dp(2), dp(6));
        cell.setBackgroundResource(R.drawable.bg_cell);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        clp.setMargins(dp(2), 0, dp(2), 0);
        cell.setLayoutParams(clp);
        ImageView img = new ImageView(this);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(24), dp(24));
        ilp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        img.setLayoutParams(ilp);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageResource(icon);
        cell.addView(img);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextColor(0xFFDDDDDD);
        t.setTextSize(10f);
        t.setSingleLine(true);
        t.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, dp(3), 0, 0);
        cell.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        bar.addView(cell);
    }

    private void afterLayerOp() {
        if (layersOpen()) buildLayersPanel();
        updateUi();
    }

    private void layerOptions(final Layer l) {
        final String[] items = {
                "Modo de mezcla: " + Layer.MODE_NAMES[l.mode],
                l.clip ? "Recorte (solo dentro de la capa de abajo): SI" : "Recorte (solo dentro de la capa de abajo): NO",
                l.alphaLock ? "Bloquear alfa (pintar solo sobre lo dibujado): SI" : "Bloquear alfa (pintar solo sobre lo dibujado): NO",
                "Cambiar nombre",
                "Exportar solo esta capa"};
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                modeDialog(l);
                                break;
                            case 1:
                                canvas.setLayerClip(l, !l.clip);
                                canvas.showHud(l.clip ? "Recorte: la capa solo se ve dentro de la de abajo" : "Recorte apagado");
                                buildLayersPanel();
                                break;
                            case 2:
                                canvas.setLayerAlphaLock(l, !l.alphaLock);
                                canvas.showHud(l.alphaLock ? "Alfa bloqueado: solo se pinta sobre lo que ya hay" : "Alfa libre");
                                buildLayersPanel();
                                break;
                            case 3:
                                renameDialog(l);
                                break;
                            default:
                                pendingLayerExport = l;
                                createPng.launch(l.name + ".png");
                                break;
                        }
                    }
                })
                .show();
    }

    /** Modos de mezcla mas usados para anime, con para que sirve cada uno. */
    private void modeDialog(final Layer l) {
        final String[] items = {
                "Normal",
                "Multiplicar: sombras y la linea (el blanco se vuelve invisible)",
                "Pantalla: luces suaves",
                "Anadir (brillo): brillos fuertes y ojos",
                "Superponer: ambiente y color sobre gris"};
        new AlertDialog.Builder(this)
                .setTitle("Modo de mezcla")
                .setSingleChoiceItems(items, l.mode, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        d.dismiss();
                        canvas.setLayerMode(l, i);
                        canvas.showHud("Modo: " + Layer.MODE_NAMES[i]);
                        buildLayersPanel();
                    }
                })
                .show();
    }

    // ==================================================================
    // Menu de tres puntos
    // ==================================================================

    private void mainMenu() {
        final List<String> items = new ArrayList<String>();
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        items.add("Guia rapida: como se usa");
        items.add("Que hace cada herramienta");
        items.add("Encuadrar la imagen");
        items.add(canvas.isAim() ? "Cursor separado con lupa: SI" : "Cursor separado con lupa: NO");
        items.add(sp.getBoolean("demo_on", true) ? "Animacion al elegir herramienta: SI"
                : "Animacion al elegir herramienta: NO");
        items.add(canvas.isSmoothZoom() ? "Zoom suave (como la galeria): SI" : "Zoom suave (como la galeria): NO");
        items.add(canvas.isAutoLines() ? "Varita no se escapa por la linea: SI" : "Varita no se escapa por la linea: NO");
        items.add("Ver en rojo la linea que usa la varita");
        items.add("Abrir otra imagen");
        items.add("Agregar una imagen como capa");
        items.add(colorRefBitmap != null ? "Referencia de color: CAMBIAR" : "Importar referencia de color");
        if (colorRefBitmap != null) items.add("Quitar referencia de color");
        items.add("Ajustes de la varita");
        items.add(canvas.isWandGlobal() ? "Varita en toda la imagen: SI" : "Varita en toda la imagen: NO");
        items.add("Preparar para colorear (linea arriba, color debajo)");
        items.add(canvas.isFlatPaint() ? "Repasar no oscurece (pintado plano): SI" : "Repasar no oscurece (pintado plano): NO");
        items.add("Filtros de la capa");
        items.add("Girar la imagen");
        items.add("Estabilizador del trazo");
        items.add("Dureza del pincel");
        items.add("Guardar ahora");
        items.add("Guardar copia en un archivo");
        new AlertDialog.Builder(this)
                .setTitle("Paint Zeta")
                .setItems(items.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        runMenu(items.get(i));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void runMenu(String item) {
        if (item.startsWith("Guia")) {
            guideDialog();
        } else if (item.startsWith("Que hace")) {
            toolCardsList();
        } else if (item.startsWith("Encuadrar")) {
            if (needProject()) canvas.fit();
        } else if (item.startsWith("Cursor")) {
            canvas.setAim(!canvas.isAim());
            canvas.showHud(canvas.isAim() ? "Cursor separado del dedo, con lupa" : "Cursor normal");
        } else if (item.startsWith("Ver en rojo")) {
            canvas.previewAutoLines();
        } else if (item.startsWith("Varita no se escapa")) {
            boolean on = !canvas.isAutoLines();
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("auto_lines", on).apply();
            canvas.setAutoLines(on);
            canvas.showHud(on ? "La varita respeta la linea negra aunque tenga cortes" : "Varita normal");
            if (on) canvas.previewAutoLines();
        } else if (item.startsWith("Zoom suave")) {
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean on = !canvas.isSmoothZoom();
            sp.edit().putBoolean("smooth_zoom", on).apply();
            canvas.setSmoothZoom(on);
            canvas.showHud(on ? "Zoom suave" : "Zoom con pixeles marcados, para bordes exactos");
        } else if (item.startsWith("Animacion")) {
            android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
            boolean on = !sp.getBoolean("demo_on", true);
            sp.edit().putBoolean("demo_on", on).apply();
            toast(on ? "Animacion al elegir herramienta: SI" : "Animaciones apagadas");
        } else if (item.startsWith("Abrir otra")) {
            autosave(false);
            openImage.launch("image/*");
        } else if (item.startsWith("Agregar una imagen")) {
            addImage.launch("image/*");
        } else if (item.startsWith("Importar referencia") || item.startsWith("Referencia de color")) {
            pendingColorRefTarget = null;
            pickColorRef.launch(new String[]{"image/*"});
        } else if (item.startsWith("Quitar referencia")) {
            clearColorReference(true);
        } else if (item.startsWith("Ajustes de la varita")) {
            wandDialog();
        } else if (item.startsWith("Varita en toda")) {
            canvas.setWandGlobal(!canvas.isWandGlobal());
            toast(canvas.isWandGlobal() ? "La varita busca ese color en toda la imagen" : "La varita agarra solo lo pegado");
        } else if (item.startsWith("Preparar para colorear")) {
            prepareColoringDialog();
        } else if (item.startsWith("Repasar no oscurece")) {
            boolean on = !canvas.isFlatPaint();
            canvas.setFlatPaint(on);
            getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("flat_paint", on).apply();
            canvas.showHud(on ? "Repasar no oscurece: el color queda parejo" : "Cada pasada oscurece un poco mas");
        } else if (item.startsWith("Filtros")) {
            filtersDialog();
        } else if (item.startsWith("Girar")) {
            rotateDialog();
        } else if (item.startsWith("Estabilizador")) {
            stabilizerDialog();
        } else if (item.startsWith("Dureza")) {
            hardnessDialog();
        } else if (item.startsWith("Guardar ahora")) {
            if (needProject()) autosave(true);
        } else if (item.startsWith("Guardar copia")) {
            projectDialog();
        }
    }

    /** Lista de todas las herramientas; al tocar una, sale su ficha animada. */
    private void toolCardsList() {
        final List<int[]> defs = new ArrayList<int[]>();
        List<String> names = new ArrayList<String>();
        for (int[] t : TOOLS) {
            defs.add(t);
            names.add(toolInfo(t[1], t[2])[0]);
        }
        new AlertDialog.Builder(this)
                .setTitle("Toca una para ver que hace")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        showToolCard(defs.get(i)[1], defs.get(i)[2]);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    // ==================================================================
    // Exportar
    // ==================================================================

    private void exportDialog() {
        if (!needProject()) return;
        final Project p = canvas.getProject();
        final int[][] sizes = {{p.w, p.h}, {Math.max(1, p.w / 2), Math.max(1, p.h / 2)},
                longSide(p, 1920), longSide(p, 1280)};
        final String[] items = {"Original  " + sizes[0][0] + "x" + sizes[0][1],
                "Mitad  " + sizes[1][0] + "x" + sizes[1][1],
                "Lado largo 1920  " + sizes[2][0] + "x" + sizes[2][1],
                "Lado largo 1280  " + sizes[3][0] + "x" + sizes[3][1]};
        new AlertDialog.Builder(this)
                .setTitle("Exportar las capas visibles")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        outW = sizes[i][0];
                        outH = sizes[i][1];
                        edgeDialogExport();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void edgeDialogExport() {
        final String[] items = {"Limpiar borde y quitar el fondo pegado (recomendado)", "Solo limpiar borde",
                "No tocar el borde"};
        final int[] vals = {2, 1, 0};
        new AlertDialog.Builder(this)
                .setTitle("Borde de las capas")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        edgeClean = vals[i];
                        formatDialog();
                    }
                })
                .show();
    }

    private void formatDialog() {
        final String[] items = {"Elegir capas y guardar en Pictures/PaintZeta (automatico)",
                "PNG sueltos en una carpeta que elijo", "Todo junto en un ZIP"};
        new AlertDialog.Builder(this)
                .setTitle("Como guardar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 0) {
                            chooseLayersToSave();
                        } else if (i == 1) {
                            toast("Elige o crea la carpeta donde van los PNG");
                            pickFolder.launch(null);
                        } else {
                            createZip.launch("capas_anime.zip");
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Marca las capas que quieres; salen todas juntas como PNG transparente. */
    private void chooseLayersToSave() {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int n = p.layers.size();
        final String[] names = new String[n];
        final boolean[] on = new boolean[n];
        for (int k = 0; k < n; k++) {
            Layer l = p.layers.get(n - 1 - k);
            names[k] = l.name;
            on[k] = l.visible;
        }
        new AlertDialog.Builder(this)
                .setTitle("Capas a guardar")
                .setMultiChoiceItems(names, on, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i, boolean c) {
                        on[i] = c;
                    }
                })
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        ArrayList<Layer> pick = new ArrayList<Layer>();
                        for (int k = n - 1; k >= 0; k--) if (on[k]) pick.add(p.layers.get(n - 1 - k));
                        if (pick.isEmpty()) {
                            toast("No marcaste ninguna capa");
                            return;
                        }
                        doExportAuto(pick);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Guarda en Pictures/PaintZeta/<fecha>/ sin preguntar carpeta (Android 10 o mas). */
    private void doExportAuto(final List<Layer> layers) {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            toast("En este Android elige la carpeta una vez");
            pickFolder.launch(null);
            return;
        }
        final Project p = canvas.getProject();
        final String folder = "Pictures/PaintZeta/" + new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US)
                .format(new java.util.Date());
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.ContentResolver cr = getContentResolver();
                    int idx = 1;
                    for (Layer l : layers) {
                        String name = String.format(Locale.US, "%02d_%s.png", idx++, safeName(l.name));
                        android.content.ContentValues cv = new android.content.ContentValues();
                        cv.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, name);
                        cv.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png");
                        cv.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, folder);
                        Uri uri = cr.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        if (uri == null) throw new java.io.IOException("No se pudo crear " + name);
                        Exporter.exportLayer(cr, p, l, uri, outW, outH, edgeClean);
                        lastExportCount++;
                    }
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al guardar: " + lastError
                        : lastExportCount + " PNG transparentes guardados en " + folder);
            }
        });
    }

    /** Cada capa visible sale como PNG suelto en la carpeta: 01_pelo.png, 02_brazo.png... */
    private void doExportFolder(final Uri tree) {
        final Project p = canvas.getProject();
        if (p == null) return;
        onBusy(true);
        lastError = null;
        lastExportCount = 0;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.ContentResolver cr = getContentResolver();
                    Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,
                            android.provider.DocumentsContract.getTreeDocumentId(tree));
                    int idx = 1;
                    for (Layer l : new ArrayList<Layer>(p.layers)) {
                        if (!l.visible) continue;
                        String name = String.format(java.util.Locale.US, "%02d_%s", idx++, safeName(l.name));
                        Uri doc = android.provider.DocumentsContract.createDocument(cr, parent, "image/png", name);
                        if (doc == null) throw new java.io.IOException("No se pudo crear " + name);
                        Exporter.exportLayer(cr, p, l, doc, outW, outH, edgeClean);
                        lastExportCount++;
                    }
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al exportar: " + lastError
                        : lastExportCount + " PNG de " + outW + "x" + outH + " guardados en la carpeta");
            }
        });
    }

    private static String safeName(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(Character.isLetterOrDigit(c) || c == '_' || c == '-' ? c : '_');
        return sb.length() == 0 ? "capa" : sb.toString();
    }

    private void doExportZip(final Uri uri) {
        final Project p = canvas.getProject();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    lastExportCount = Exporter.exportZip(getContentResolver(), p, uri, outW, outH, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error al exportar: " + lastError
                        : lastExportCount + " PNG de " + outW + "x" + outH + " guardados en el ZIP");
            }
        });
    }

    private void doExportLayer(final Uri uri) {
        final Project p = canvas.getProject();
        final Layer l = pendingLayerExport;
        pendingLayerExport = null;
        if (l == null) return;
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    Exporter.exportLayer(getContentResolver(), p, l, uri, edgeClean);
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                toast(lastError != null ? "Error: " + lastError : "PNG guardado");
            }
        });
    }

    // ==================================================================
    // Interfaz
    // ==================================================================

    private void updateUi() {
        Project p = canvas.getProject();
        ((TextView) findViewById(R.id.layerCount)).setText(String.valueOf(p == null ? 0 : p.layers.size()));
        ((TextView) findViewById(R.id.btnSize)).setText(String.format(Locale.US,
                canvas.getBrushSize() < 10 ? "%.1f" : "%.0f", canvas.getBrushSize()));
        android.graphics.drawable.GradientDrawable sw = new android.graphics.drawable.GradientDrawable();
        sw.setCornerRadius(dp(4));
        sw.setColor(canvas.getColor());
        sw.setStroke(dp(2), 0xFFFFFFFF);
        findViewById(R.id.btnColor).setBackground(sw);
        ((ImageButton) findViewById(R.id.btnTools)).setImageResource(
                canvas.getMode() == CanvasView.MODE_BRUSH && canvas.isSubtract() ? R.drawable.ic_remove
                        : toolIcon(canvas.getMode()));

        if (layersOpen()) {
            hideForLayers(true);
            buildLayersPanel();
            return;
        }
        int m = canvas.getMode();
        boolean selTool = m == CanvasView.MODE_WAND || m == CanvasView.MODE_LASSO
                || m == CanvasView.MODE_SCISSORS || m == CanvasView.MODE_MAGNET || m == CanvasView.MODE_BRUSH;
        findViewById(R.id.selBar).setVisibility(selTool ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnAddMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg : R.drawable.bg_seg_on);
        findViewById(R.id.btnSubMode).setBackgroundResource(canvas.isSubtract() ? R.drawable.bg_seg_off : R.drawable.bg_seg);
        toggle(R.id.btnSmart, canvas.isSmart());
        toggle(R.id.btnLineart, canvas.isUseBarrier() && p != null && p.barrier != null);
        if (wandGear != null) wandGear.setVisibility(m == CanvasView.MODE_WAND ? View.VISIBLE : View.GONE);
        buildOptBar(m);
    }

    // ==================================================================
    // Avisos del lienzo
    // ==================================================================

    @Override
    public void onBusy(boolean busy) {
        int[] ids = {R.id.btnExport, R.id.btnTools, R.id.btnUndo, R.id.btnRedo,
                R.id.btnLayers, R.id.btnMenu, R.id.btnSelMenu};
        for (int id : ids) {
            View v = findViewById(id);
            if (v != null) v.setEnabled(!busy);
        }
    }

    @Override
    public void onChanged() {
        markDirty();
        updateUi();
    }

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    @Override
    public void onColorPicked(int color) {
        updateUi();
        canvas.showHud(String.format(Locale.US, "Color #%06X", color & 0xFFFFFF));
    }

    @Override
    public void onUndoGesture() {
        canvas.doUndo();
        updateUi();
    }

    @Override
    public void onRedoGesture() {
        canvas.doRedo();
        updateUi();
    }


    // ==================================================================
    // Dialogos
    // ==================================================================

    /** Ajustes de la varita, al estilo de los de Ibis. */
    /** Panel chico de la varita, como en ibis: se aplica al momento. */
    private void wandDialog() {
        if (!needProject()) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);

        final TextView tExp = smallText("Dilatacion " + String.format(Locale.US, "%.1f", canvas.getExpansion()));
        final SeekBar sExp = new SeekBar(this);
        sExp.setMax(80); // -3.0 .. +5.0
        sExp.setProgress(Math.round((canvas.getExpansion() + 3f) * 10f));
        sExp.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                float e = v / 10f - 3f;
                tExp.setText("Dilatacion " + String.format(Locale.US, "%.1f", e));
                canvas.setExpansion(e);
            }
        });
        root.addView(tExp);
        root.addView(sExp);

        final android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        root.addView(smallSwitch("Hasta la linea", canvas.isToLine(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setToLine(on);
                sp.edit().putBoolean("to_line", on).apply();
            }
        }));
        root.addView(smallSwitch("Reconocimiento de huecos", canvas.isAutoLines(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setAutoLines(on);
                sp.edit().putBoolean("auto_lines", on).apply();
            }
        }));
        root.addView(smallSwitch("Zonas sin pintar", canvas.isFillUnpainted(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setFillUnpainted(on);
                sp.edit().putBoolean("fill_unpainted", on).apply();
            }
        }));
        root.addView(smallSwitch("Llenado continuo", !canvas.isWandGlobal(), new SwitchDo() {
            public void set(boolean on) {
                canvas.setWandGlobal(!on);
            }
        }));

        final AlertDialog dlg = new AlertDialog.Builder(this).setView(root)
                .setPositiveButton("Listo", null)
                .setNeutralButton("Restablecer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(28);
                        canvas.setSoftness(24);
                        canvas.setExpansion(1.5f);
                        canvas.setAutoLines(true);
                        canvas.setWandGlobal(false);
                        canvas.setToLine(true);
                        canvas.setFillUnpainted(false);
                        canvas.setColorMode(ColorDist.RGB);
                        sp.edit().putBoolean("auto_lines", true).putBoolean("to_line", true)
                                .putBoolean("fill_unpainted", false).apply();
                        syncSlider();
                        toast("Restablecido");
                    }
                })
                .create();
        dlg.show();
        // cuadro chico, no toda la pantalla
        if (dlg.getWindow() != null) {
            dlg.getWindow().setLayout(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private interface SwitchDo {
        void set(boolean on);
    }

    private TextView smallText(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFFE0E0E0);
        v.setTextSize(13f);
        v.setPadding(0, dp(4), 0, 0);
        return v;
    }

    private android.widget.Switch smallSwitch(String text, boolean on, final SwitchDo d) {
        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setText(text);
        sw.setTextSize(13f);
        sw.setTextColor(0xFFE0E0E0);
        sw.setChecked(on);
        sw.setPadding(0, dp(2), 0, dp(2));
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean c) {
                d.set(c);
            }
        });
        return sw;
    }

    private String expLabel(float v) {
        return String.format(Locale.US, "Expansion del borde: %.1f px", v);
    }

    /** Gama de colores, con vista previa mientras mueves el margen. */
    private void colorRangeDialog() {
        if (!needProject()) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView info = new TextView(this);
        info.setText("Se usa el color cargado. Mueve el margen y mira el lienzo: la seleccion se actualiza sola.");
        root.addView(info);

        final View sw = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        lp.topMargin = dp(8);
        sw.setLayoutParams(lp);
        sw.setBackgroundColor(canvas.getColor());
        root.addView(sw);

        final TextView tTol = new TextView(this);
        final SeekBar sTol = new SeekBar(this);
        sTol.setMax(160);
        sTol.setProgress(canvas.getTolerance());
        tTol.setText("Margen: " + canvas.getTolerance());
        root.addView(tTol);
        root.addView(sTol);

        final CheckBox replace = new CheckBox(this);
        replace.setText("Reemplazar la seleccion actual");
        replace.setChecked(true);
        root.addView(replace);

        canvas.beginPreview();
        final Runnable[] pending = new Runnable[1];
        sTol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, final int v, boolean u) {
                tTol.setText("Margen: " + v);
                if (pending[0] != null) previewHandler.removeCallbacks(pending[0]);
                pending[0] = new Runnable() {
                    @Override
                    public void run() {
                        canvas.previewColorRange(canvas.getColor(), v, replace.isChecked());
                    }
                };
                previewHandler.postDelayed(pending[0], 180);
            }
        });
        canvas.previewColorRange(canvas.getColor(), sTol.getProgress(), replace.isChecked());

        new AlertDialog.Builder(this)
                .setTitle("Gama de colores")
                .setView(scroll)
                .setCancelable(false)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.setTolerance(sTol.getProgress());
                        canvas.endPreview(true);
                        syncSlider();
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.endPreview(false);
                    }
                })
                .show();
    }

    private void refineDialog() {
        if (!needProject()) return;
        final String[] items = {"Suave (pelo fino)", "Medio", "Fuerte"};
        final int[] rad = {6, 12, 20};
        final float[] eps = {0.0004f, 0.0016f, 0.006f};
        new AlertDialog.Builder(this)
                .setTitle("Refinar borde")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.refineEdge(rad[i], eps[i]);
                    }
                })
                .show();
    }

    private void unpaintedDialog() {
        if (!needProject()) return;
        final String[] items = {"Solo huecos chicos", "Huecos medianos", "Huecos grandes", "Todos los huecos"};
        final int[] vals = {2, 8, 30, 0};
        new AlertDialog.Builder(this)
                .setTitle("Rellenar zonas sin pintar")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(5, vals[i]);
                    }
                })
                .show();
    }

    /** Saca la linea del manga a su capa y deja una capa de color debajo. */
    private void prepareColoringDialog() {
        if (!needProject()) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(4));
        final TextView info = new TextView(this);
        info.setText("Usa la capa elegida (la imagen del manga). Crea arriba una capa \"linea\" solo con lo negro, "
                + "en Multiplicar, y debajo una capa \"color\" vacia para pintar.");
        info.setTextColor(0xFFCCCCCC);
        info.setTextSize(13f);
        root.addView(info);
        final TextView tw = new TextView(this);
        tw.setTextColor(0xFFFFFFFF);
        tw.setPadding(0, dp(10), 0, 0);
        final SeekBar sw = new SeekBar(this);
        sw.setMax(255);
        sw.setProgress(220);
        tw.setText("Blanco (lo que se vuelve transparente): 220");
        final TextView tb = new TextView(this);
        tb.setTextColor(0xFFFFFFFF);
        final SeekBar sbk = new SeekBar(this);
        sbk.setMax(255);
        sbk.setProgress(60);
        tb.setText("Negro (lo que queda como linea llena): 60");
        sw.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tw.setText("Blanco (lo que se vuelve transparente): " + v);
            }
        });
        sbk.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tb.setText("Negro (lo que queda como linea llena): " + v);
            }
        });
        root.addView(tw);
        root.addView(sw);
        root.addView(tb);
        root.addView(sbk);
        new AlertDialog.Builder(this)
                .setTitle("Preparar para colorear")
                .setView(root)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Preparar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        int wv = sw.getProgress(), bv = Math.min(sbk.getProgress(), wv - 1);
                        canvas.prepareForColoring(wv, Math.max(0, bv));
                    }
                })
                .show();
    }

    private void filtersDialog() {
        if (!needProject()) return;
        final String[] items = {
                "Quitar ruido de JPEG (mediana)",
                "Aplanar tonos (posterizar)",
                "Niveles: mas contraste",
                "Extraer line art"
        };
        new AlertDialog.Builder(this)
                .setTitle("Filtros de limpieza")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        switch (i) {
                            case 0:
                                canvas.applyFilter(0, 0, 0, 0);
                                break;
                            case 1:
                                posterizeDialog();
                                break;
                            case 2:
                                canvas.applyFilter(2, 25, 230, 100);
                                break;
                            default:
                                lineArtFilterDialog();
                                break;
                        }
                    }
                })
                .show();
    }

    private void posterizeDialog() {
        final String[] items = {"4 tonos", "6 tonos", "10 tonos", "16 tonos"};
        final int[] vals = {4, 6, 10, 16};
        new AlertDialog.Builder(this)
                .setTitle("Aplanar tonos")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.applyFilter(1, vals[i], 0, 0);
                    }
                })
                .show();
    }

    /** Extraer line art con sus tres controles, como el filtro de Ibis. */
    private void lineArtFilterDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        final TextView tw = new TextView(this);
        final SeekBar sw = new SeekBar(this);
        sw.setMax(255);
        sw.setProgress(210);
        tw.setText("Blanco: 210");
        sw.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tw.setText("Blanco: " + v);
            }
        });
        root.addView(tw);
        root.addView(sw);

        final TextView tb = new TextView(this);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(255);
        sb.setProgress(40);
        tb.setText("Negro: 40");
        sb.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tb.setText("Negro: " + v);
            }
        });
        root.addView(tb);
        root.addView(sb);

        final TextView tm = new TextView(this);
        final SeekBar sm = new SeekBar(this);
        sm.setMax(100);
        sm.setProgress(50);
        tm.setText("Medio: 50");
        sm.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tm.setText("Medio: " + Math.max(1, v));
            }
        });
        root.addView(tm);
        root.addView(sm);

        new AlertDialog.Builder(this)
                .setTitle("Extraer line art")
                .setView(scroll)
                .setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.applyFilter(3, sw.getProgress(), sb.getProgress(),
                                Math.max(1, sm.getProgress()));
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void stabilizerDialog() {
        final String[] items = {"Apagado", "Suave", "Medio", "Fuerte"};
        final float[] vals = {0f, 0.5f, 0.72f, 0.88f};
        new AlertDialog.Builder(this)
                .setTitle("Estabilizador del trazo")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setStabilizer(vals[i]);
                        toast("Estabilizador: " + items[i]);
                    }
                })
                .show();
    }

    private void expandDialog() {
        if (!needProject()) return;
        final String[] items = {"+0.5 px", "+1.0 px", "+1.5 px", "+2.0 px", "-0.5 px", "-1.0 px"};
        final float[] vals = {0.5f, 1f, 1.5f, 2f, -0.5f, -1f};
        new AlertDialog.Builder(this)
                .setTitle("Expandir o contraer con decimales")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.expandSelection(vals[i]);
                    }
                })
                .show();
    }

    /** Quita los puntitos que deja la trama del manga dentro de la seleccion. */
    private void closeHolesDialog() {
        if (!needProject()) return;
        final String[] items = {"Puntos chicos (1 px)", "Medianos (2 px)", "Grandes (3 px)", "Muy grandes (5 px)"};
        final int[] vals = {1, 2, 3, 5};
        new AlertDialog.Builder(this)
                .setTitle("Cerrar huecos de la trama")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.edgeOp(4, vals[i]);
                    }
                })
                .show();
    }

    private void hardnessDialog() {
        final String[] items = {"Muy suave 20%", "Suave 40%", "Media 70%", "Dura 100%"};
        final float[] vals = {0.2f, 0.4f, 0.7f, 1f};
        new AlertDialog.Builder(this)
                .setTitle("Dureza del pincel")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.setHardness(vals[i]);
                        toast("Dureza " + items[i]);
                    }
                })
                .show();
    }

    private void rotateDialog() {
        if (!needProject()) return;
        final String[] items = {"Girar a la derecha", "Girar a la izquierda",
                "Voltear horizontal", "Voltear vertical"};
        new AlertDialog.Builder(this)
                .setTitle("Girar imagen")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        canvas.transform(i);
                    }
                })
                .show();
    }

    private void lineArtDialog() {
        if (!needProject()) return;
        if (canvas.isUseBarrier() && canvas.getProject().barrier != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Line art")
                    .setMessage("La barrera esta activa. La varita y el balde se detienen en las lineas.")
                    .setPositiveButton("Desactivar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            canvas.setUseBarrier(false);
                            updateUi();
                        }
                    })
                    .setNegativeButton("Recalcular", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            thresholdDialog();
                        }
                    })
                    .show();
            return;
        }
        thresholdDialog();
    }

    private void thresholdDialog() {
        final String[] items = {"Lineas muy oscuras (60)", "Oscuras (90)", "Normal (120)", "Tenues (160)"};
        final int[] vals = {60, 90, 120, 160};
        new AlertDialog.Builder(this)
                .setTitle("Que tan oscura es la linea")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, final int i) {
                        final String[] gaps = {"Sin cerrar huecos", "Cerrar 1 px", "Cerrar 2 px", "Cerrar 3 px"};
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cerrar huecos de la linea")
                                .setItems(gaps, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface d2, int g) {
                                        canvas.buildBarrier(vals[i], g);
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    private Bitmap decodeReference(Uri uri) {
        try {
            BitmapFactory.Options b = new BitmapFactory.Options();
            b.inJustDecodeBounds = true;
            InputStream is0 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is0, null, b);
            if (is0 != null) is0.close();
            int ow = b.outWidth, oh = b.outHeight;
            if (ow <= 0 || oh <= 0) return null;
            int sample = 1;
            int maxSide = Math.max(ow, oh);
            while (maxSide / sample > 2800) sample *= 2;
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o.inMutable = false;
            o.inSampleSize = Math.max(1, sample);
            Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
            if (is != null) is.close();
            return bmp;
        } catch (Throwable t) {
            toast("No se pudo abrir la referencia");
            return null;
        }
    }

    private void clearColorReference(boolean showToast) {
        pendingColorRefTarget = null;
        if (colorRefWindow != null) { try { colorRefWindow.dismiss(); } catch (Throwable ignored) {} }
        colorRefWindow = null; colorRefView = null;
        if (colorRefBitmap != null && !colorRefBitmap.isRecycled()) colorRefBitmap.recycle();
        colorRefBitmap = null;
        if (showToast) toast("Referencia de color quitada");
    }

    private void requestColorReference(ColorPickTarget target) {
        if (colorRefBitmap == null || colorRefBitmap.isRecycled()) {
            pendingColorRefTarget = target;
            pickColorRef.launch(new String[]{"image/*"});
        } else {
            showReferenceColorPanel(target);
        }
    }

    private int[] extractReferencePalette(Bitmap bmp, int count) {
        if (bmp == null) return new int[0];
        java.util.LinkedHashMap<Integer, Integer> hist = new java.util.LinkedHashMap<Integer, Integer>();
        int w = bmp.getWidth(), h = bmp.getHeight();
        int sx = Math.max(1, w / 80), sy = Math.max(1, h / 80);
        for (int y = 0; y < h; y += sy) {
            for (int x = 0; x < w; x += sx) {
                int c = bmp.getPixel(x, y);
                if (((c >>> 24) & 0xFF) < 20) continue;
                int r = (Color.red(c) >> 4) & 0xF;
                int g = (Color.green(c) >> 4) & 0xF;
                int b = (Color.blue(c) >> 4) & 0xF;
                int key = (r << 8) | (g << 4) | b;
                Integer old = hist.get(key);
                hist.put(key, old == null ? 1 : old + 1);
            }
        }
        java.util.List<java.util.Map.Entry<Integer, Integer>> list = new java.util.ArrayList<java.util.Map.Entry<Integer, Integer>>(hist.entrySet());
        java.util.Collections.sort(list, new java.util.Comparator<java.util.Map.Entry<Integer, Integer>>() {
            @Override
            public int compare(java.util.Map.Entry<Integer, Integer> a, java.util.Map.Entry<Integer, Integer> b) {
                return b.getValue() - a.getValue();
            }
        });
        java.util.ArrayList<Integer> out = new java.util.ArrayList<Integer>();
        for (java.util.Map.Entry<Integer, Integer> e : list) {
            int key = e.getKey();
            int r = ((key >> 8) & 0xF) * 17;
            int g = ((key >> 4) & 0xF) * 17;
            int bl = (key & 0xF) * 17;
            int c = Color.rgb(r, g, bl);
            boolean close = false;
            for (int i = 0; i < out.size(); i++) {
                int oc = out.get(i);
                int dr = Color.red(oc) - r, dg = Color.green(oc) - g, db = Color.blue(oc) - bl;
                if (dr * dr + dg * dg + db * db < 28 * 28) {
                    close = true;
                    break;
                }
            }
            if (!close) out.add(c);
            if (out.size() >= count) break;
        }
        int[] arr = new int[out.size()];
        for (int i = 0; i < out.size(); i++) arr[i] = out.get(i);
        return arr;
    }

    private Integer colorFromImageTouch(ImageView iv, Bitmap bmp, MotionEvent e) {
        if (bmp == null || iv.getDrawable() == null) return null;
        float[] values = new float[9];
        Matrix m = iv.getImageMatrix();
        m.getValues(values);
        float scaleX = values[Matrix.MSCALE_X];
        float scaleY = values[Matrix.MSCALE_Y];
        float transX = values[Matrix.MTRANS_X];
        float transY = values[Matrix.MTRANS_Y];
        if (scaleX == 0f || scaleY == 0f) return null;
        float bx = (e.getX() - transX) / scaleX;
        float by = (e.getY() - transY) / scaleY;
        if (bx < 0 || by < 0 || bx >= bmp.getWidth() || by >= bmp.getHeight()) return null;
        return bmp.getPixel(Math.max(0, Math.min(bmp.getWidth() - 1, Math.round(bx))),
                Math.max(0, Math.min(bmp.getHeight() - 1, Math.round(by))));
    }

    private void showReferenceColorPanel(final ColorPickTarget target) {
        if (colorRefBitmap == null || colorRefBitmap.isRecycled()) return;
        if (colorRefWindow != null && colorRefWindow.isShowing()) {
            if (colorRefView != null) {
                colorRefView.setBitmap(colorRefBitmap);
                colorRefView.setListener(new ReferenceImageView.Listener() {
                    @Override public void onColor(int color) {
                        target.onColor(color);
                        toast(String.format(Locale.US, "Color tomado #%06X", color & 0xFFFFFF));
                    }
                });
            }
            return;
        }

        final FrameLayout shell = new FrameLayout(this);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(4), dp(4), dp(4), dp(4));
        root.setBackgroundResource(R.drawable.bg_ref_panel);
        shell.addView(root, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Referencia");
        title.setTextColor(0xFFF4F4F6);
        title.setTextSize(14f);
        title.setPadding(dp(8), 0, dp(4), 0);
        head.addView(title, new LinearLayout.LayoutParams(0, dp(34), 1f));

        ImageButton change = refIconButton(R.drawable.ic_image, "Cambiar imagen");
        ImageButton remove = refIconButton(R.drawable.ic_trash, "Quitar referencia");
        ImageButton close = refIconButton(R.drawable.ic_close, "Cerrar referencia");
        head.addView(change); head.addView(remove); head.addView(close);
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));

        colorRefView = new ReferenceImageView(this);
        colorRefView.setBitmap(colorRefBitmap);
        colorRefView.setListener(new ReferenceImageView.Listener() {
            @Override public void onColor(int color) {
                target.onColor(color);
                toast(String.format(Locale.US, "Color tomado #%06X", color & 0xFFFFFF));
            }
        });
        root.addView(colorRefView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Tirador pequeno: solo aparece en la esquina y no tapa la imagen.
        final ImageView resize = new ImageView(this);
        resize.setImageResource(R.drawable.ic_resize_ref);
        resize.setPadding(dp(4), dp(4), dp(4), dp(4));
        resize.setBackgroundResource(R.drawable.bg_ref_handle);
        FrameLayout.LayoutParams rh = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.RIGHT | Gravity.BOTTOM);
        rh.setMargins(0, 0, dp(4), dp(4));
        shell.addView(resize, rh);

        float density = getResources().getDisplayMetrics().density;
        int swDp = Math.round(getResources().getDisplayMetrics().widthPixels / density);
        int shDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        colorRefW = Math.max(180, Math.min(colorRefW, Math.max(180, swDp - 8)));
        colorRefH = Math.max(190, Math.min(colorRefH, Math.max(190, shDp - 8)));
        colorRefWindow = new PopupWindow(shell, dp(colorRefW), dp(colorRefH), false);
        colorRefWindow.setOutsideTouchable(false);
        colorRefWindow.setClippingEnabled(true);
        colorRefWindow.setElevation(dp(8));
        colorRefWindow.showAtLocation(findViewById(android.R.id.content), Gravity.TOP | Gravity.START, colorRefX, colorRefY);

        final float[] drag = new float[4];
        head.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (colorRefWindow == null) return false;
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    drag[0] = e.getRawX(); drag[1] = e.getRawY(); drag[2] = colorRefX; drag[3] = colorRefY; return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    int sw = getResources().getDisplayMetrics().widthPixels;
                    int sh = getResources().getDisplayMetrics().heightPixels;
                    colorRefX = Math.max(0, Math.min(sw - dp(70), Math.round(drag[2] + e.getRawX() - drag[0])));
                    colorRefY = Math.max(0, Math.min(sh - dp(70), Math.round(drag[3] + e.getRawY() - drag[1])));
                    colorRefWindow.update(colorRefX, colorRefY, -1, -1); return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("ref_x", colorRefX).putInt("ref_y", colorRefY).apply();
                    return true;
                }
                return false;
            }
        });

        final float[] size = new float[4];
        resize.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (colorRefWindow == null) return false;
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    size[0] = e.getRawX(); size[1] = e.getRawY(); size[2] = colorRefW; size[3] = colorRefH; return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    float d = getResources().getDisplayMetrics().density;
                    int sw = Math.round(getResources().getDisplayMetrics().widthPixels / d);
                    int sh = Math.round(getResources().getDisplayMetrics().heightPixels / d);
                    int dx = Math.round((e.getRawX() - size[0]) / d);
                    int dy = Math.round((e.getRawY() - size[1]) / d);
                    colorRefW = Math.max(180, Math.min(sw - Math.round(colorRefX / d) - 6, Math.round(size[2]) + dx));
                    colorRefH = Math.max(190, Math.min(sh - Math.round(colorRefY / d) - 6, Math.round(size[3]) + dy));
                    colorRefWindow.update(colorRefX, colorRefY, dp(colorRefW), dp(colorRefH));
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("ref_w", colorRefW).putInt("ref_h", colorRefH).apply();
                    return true;
                }
                return false;
            }
        });

        change.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pendingColorRefTarget = target; pickColorRef.launch(new String[]{"image/*"}); }
        });
        remove.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { clearColorReference(true); }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (colorRefWindow != null) colorRefWindow.dismiss(); colorRefWindow = null; colorRefView = null; }
        });
    }

    private ImageButton refIconButton(int icon, String desc) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(icon);
        b.setColorFilter(0xFFF1F1F3);
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setContentDescription(desc);
        b.setPadding(dp(7), dp(7), dp(7), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
        lp.setMargins(dp(1), 0, dp(1), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView smallTextButton(String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(0xFFFFFFFF); v.setTextSize(12f); v.setGravity(Gravity.CENTER);
        v.setPadding(dp(7), 0, dp(7), 0);
        v.setBackgroundResource(R.drawable.bg_tool);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.setMargins(dp(2), 0, dp(2), 0); v.setLayoutParams(lp);
        return v;
    }

    private void colorDialog() {
        final int previous = canvas.getColor() | 0xFF000000;
        final int[] chosen = {previous};
        final boolean[] syncing = {false};

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        scroll.addView(root);

        // Color anterior y actual, como referencia visual rapida.
        LinearLayout previews = new LinearLayout(this);
        previews.setOrientation(LinearLayout.HORIZONTAL);
        final TextView oldPreview = new TextView(this);
        final TextView newPreview = new TextView(this);
        oldPreview.setText("Anterior"); newPreview.setText("Actual");
        oldPreview.setGravity(android.view.Gravity.CENTER); newPreview.setGravity(android.view.Gravity.CENTER);
        oldPreview.setTextColor(contrastText(previous)); newPreview.setTextColor(contrastText(previous));
        oldPreview.setBackgroundColor(previous); newPreview.setBackgroundColor(previous);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        pp.setMargins(dp(2), 0, dp(2), dp(8));
        previews.addView(oldPreview, pp); previews.addView(newPreview, pp);
        root.addView(previews);

        final ColorPickerView picker = new ColorPickerView(this);
        picker.setColor(previous);
        root.addView(picker, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));

        // HEX con boton de aplicar.
        LinearLayout hexRow = new LinearLayout(this);
        hexRow.setOrientation(LinearLayout.HORIZONTAL);
        hexRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        final EditText hex = new EditText(this);
        hex.setSingleLine(true);
        hex.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        hex.setText(String.format(Locale.US, "#%06X", previous & 0xFFFFFF));
        TextView hexGo = new TextView(this);
        hexGo.setText(">"); hexGo.setTextSize(28f); hexGo.setGravity(android.view.Gravity.CENTER);
        hexGo.setTextColor(0xFFFFFFFF); hexGo.setBackgroundResource(R.drawable.bg_tool);
        hexRow.addView(hex, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(54), dp(44)); gp.setMargins(dp(8), 0, 0, 0);
        hexRow.addView(hexGo, gp);
        root.addView(hexRow);

        final SeekBar sr = new SeekBar(this), sg = new SeekBar(this), sb = new SeekBar(this), sa = new SeekBar(this);
        sr.setMax(255); sg.setMax(255); sb.setMax(255); sa.setMax(100);
        final TextView vr = new TextView(this), vg = new TextView(this), vb = new TextView(this), va = new TextView(this);
        addColorChannel(root, "R", sr, vr);
        addColorChannel(root, "G", sg, vg);
        addColorChannel(root, "B", sb, vb);
        addColorChannel(root, "Opacidad", sa, va);

        // Paleta rapida se conserva, pero mas compacta que antes.
        LinearLayout paletteRow = new LinearLayout(this);
        paletteRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 8; i++) {
            final int c = PALETTE[i * 3 % PALETTE.length];
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(32), 1f);
            lp.setMargins(dp(2), dp(5), dp(2), 0);
            sw.setLayoutParams(lp); sw.setBackgroundColor(c);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    chosen[0] = c | 0xFF000000;
                    syncing[0] = true;
                    picker.setColor(chosen[0]);
                    sr.setProgress(Color.red(chosen[0])); sg.setProgress(Color.green(chosen[0])); sb.setProgress(Color.blue(chosen[0]));
                    hex.setText(String.format(Locale.US, "#%06X", chosen[0] & 0xFFFFFF));
                    newPreview.setBackgroundColor(chosen[0]); newPreview.setTextColor(contrastText(chosen[0]));
                    vr.setText(String.valueOf(Color.red(chosen[0]))); vg.setText(String.valueOf(Color.green(chosen[0]))); vb.setText(String.valueOf(Color.blue(chosen[0])));
                    syncing[0] = false;
                }
            });
            paletteRow.addView(sw);
        }
        root.addView(paletteRow);

        final LinearLayout refBox = new LinearLayout(this);
        refBox.setOrientation(LinearLayout.VERTICAL);
        refBox.setPadding(0, dp(10), 0, 0);
        TextView refTitle = new TextView(this);
        refTitle.setText("Referencia de color");
        refTitle.setTextColor(0xFF9FC6FF);
        refTitle.setTextSize(13f);
        refBox.addView(refTitle);
        TextView refHelp = new TextView(this);
        refHelp.setText(colorRefBitmap == null ? "Importa una imagen a color del personaje. Luego toca sus ojos, ropa o piel para sacar el color." : "Ya hay una referencia guardada. Puedes tomar color, cambiarla o quitarla.");
        refHelp.setTextColor(0xFFD8D8D8);
        refHelp.setTextSize(12f);
        refBox.addView(refHelp);
        LinearLayout refActions = new LinearLayout(this);
        refActions.setOrientation(LinearLayout.HORIZONTAL);
        TextView refBtn = smallAction("Tomar/Importar");
        TextView changeBtn = smallAction("Cambiar");
        TextView clearBtn = smallAction("Quitar");
        refActions.addView(refBtn, new LinearLayout.LayoutParams(0, dp(40), 1f));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(40), 1f); ap.setMargins(dp(6), 0, 0, 0);
        refActions.addView(changeBtn, ap);
        LinearLayout.LayoutParams ap2 = new LinearLayout.LayoutParams(0, dp(40), 1f); ap2.setMargins(dp(6), 0, 0, 0);
        refActions.addView(clearBtn, ap2);
        refBox.addView(refActions);
        root.addView(refBox);

        final Runnable syncRgbUi = new Runnable() {
            @Override public void run() {
                syncing[0] = true;
                sr.setProgress(Color.red(chosen[0])); sg.setProgress(Color.green(chosen[0])); sb.setProgress(Color.blue(chosen[0]));
                vr.setText(String.valueOf(Color.red(chosen[0]))); vg.setText(String.valueOf(Color.green(chosen[0]))); vb.setText(String.valueOf(Color.blue(chosen[0])));
                hex.setText(String.format(Locale.US, "#%06X", chosen[0] & 0xFFFFFF));
                newPreview.setBackgroundColor(chosen[0]); newPreview.setTextColor(contrastText(chosen[0]));
                syncing[0] = false;
            }
        };

        picker.setListener(new ColorPickerView.Listener() {
            @Override public void onColorChanged(int color) {
                if (syncing[0]) return;
                chosen[0] = color | 0xFF000000;
                syncRgbUi.run();
            }
        });

        SeekBar.OnSeekBarChangeListener rgb = new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (syncing[0]) return;
                chosen[0] = Color.rgb(sr.getProgress(), sg.getProgress(), sb.getProgress());
                picker.setColor(chosen[0]);
                syncRgbUi.run();
            }
        };
        sr.setOnSeekBarChangeListener(rgb); sg.setOnSeekBarChangeListener(rgb); sb.setOnSeekBarChangeListener(rgb);
        sa.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                int v = Math.max(1, value);
                va.setText(v + "%");
            }
        });

        oldPreview.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                chosen[0] = previous; picker.setColor(previous); syncRgbUi.run();
            }
        });
        final ColorPickTarget refTarget = new ColorPickTarget() {
            @Override public void onColor(int color) {
                chosen[0] = color | 0xFF000000;
                picker.setColor(chosen[0]);
                syncRgbUi.run();
            }
        };
        refBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                requestColorReference(refTarget);
            }
        });
        changeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pendingColorRefTarget = refTarget;
                pickColorRef.launch(new String[]{"image/*"});
            }
        });
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                clearColorReference(true);
                toast("La referencia se puede volver a importar cuando quieras");
            }
        });
        hexGo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Integer parsed = parseHexColor(hex.getText().toString());
                if (parsed == null) { toast("HEX invalido. Usa por ejemplo #FF3030"); return; }
                chosen[0] = parsed | 0xFF000000; picker.setColor(chosen[0]); syncRgbUi.run();
            }
        });

        sr.setProgress(Color.red(previous)); sg.setProgress(Color.green(previous)); sb.setProgress(Color.blue(previous));
        int opa = Math.max(1, Math.round(canvas.getBrushOpacity() * 100f));
        sa.setProgress(opa); va.setText(opa + "%"); syncRgbUi.run();

        new AlertDialog.Builder(this)
                .setTitle("Color")
                .setView(scroll)
                .setPositiveButton("Usar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Integer parsed = parseHexColor(hex.getText().toString());
                        if (parsed != null) chosen[0] = parsed | 0xFF000000;
                        canvas.setColor(chosen[0]);
                        int op = Math.max(1, sa.getProgress());
                        canvas.setBrushOpacity(op / 100f);
                        SeekBar bottomOp = findViewById(R.id.opacity);
                        bottomOp.setProgress(op);
                        updateUi();
                    }
                })
                .setNeutralButton("Gotero", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        canvas.setMode(CanvasView.MODE_PICKER);
                        toast("Toca la imagen para tomar ese color");
                        updateUi();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private TextView smallAction(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setTextColor(0xFFFFFFFF);
        tv.setBackgroundResource(R.drawable.bg_tool);
        tv.setTextSize(12f);
        return tv;
    }

    private void addColorChannel(LinearLayout root, String name, final SeekBar bar, final TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this);
        label.setText(name); label.setTextColor(0xFFE8E8E8); label.setTextSize(13f); label.setGravity(android.view.Gravity.CENTER);
        row.addView(label, new LinearLayout.LayoutParams(dp(name.equals("Opacidad") ? 72 : 26), dp(42)));
        ImageButton minus = iconButton(R.drawable.ic_sub, "Menos", new Runnable() {
            @Override public void run() { bar.setProgress(Math.max(0, bar.getProgress() - (bar.getMax() == 100 ? 5 : 1))); }
        });
        minus.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        row.addView(minus);
        row.addView(bar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        value.setTextColor(0xFFFFFFFF); value.setGravity(android.view.Gravity.CENTER); value.setMinWidth(dp(42));
        row.addView(value, new LinearLayout.LayoutParams(dp(48), dp(42)));
        ImageButton plus = iconButton(R.drawable.ic_add, "Mas", new Runnable() {
            @Override public void run() { bar.setProgress(Math.min(bar.getMax(), bar.getProgress() + (bar.getMax() == 100 ? 5 : 1))); }
        });
        plus.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        row.addView(plus);
        root.addView(row);
    }

    private Integer parseHexColor(String text) {
        if (text == null) return null;
        String s = text.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6) return null;
        try { return 0xFF000000 | (int) Long.parseLong(s, 16); }
        catch (Throwable t) { return null; }
    }

    private int contrastText(int c) {
        int y = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
        return y > 150 ? 0xFF000000 : 0xFFFFFFFF;
    }

    private void addLabeled(LinearLayout root, String name, SeekBar bar, int value,
                            SeekBar.OnSeekBarChangeListener l) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(l);
        root.addView(bar);
    }

    private void renameDialog(final Layer l) {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        in.setText(l.name);
        new AlertDialog.Builder(this)
                .setTitle("Nombre de la capa")
                .setView(in)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = in.getText().toString().trim();
                        if (!s.isEmpty()) l.name = s;
                        updateUi();
                        buildLayersPanel();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private final android.os.Handler opHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean opPending;

    /** Mientras mueves la barra de opacidad, la imagen se actualiza seguido pero sin trabarse. */
    private void scheduleOpacityRefresh() {
        if (opPending) return;
        opPending = true;
        opHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                opPending = false;
                canvas.refreshDisplayAsync();
            }
        }, 60);
    }

    /** Pinceles como la lista basica de Ibis: cada uno con su propio trazo. */
    private void brushPresets() {
        final com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        int current = getSharedPreferences("pz", MODE_PRIVATE).getInt("brush_preset3", 0);
        if (current < 0 || current >= list.length) current = 0;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText("Pinceles");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(17f);
        title.setPadding(dp(6), dp(2), 0, dp(4));
        root.addView(title);
        final android.widget.CheckBox flat = new android.widget.CheckBox(this);
        flat.setText("Repasar no oscurece (color parejo con poca opacidad)");
        flat.setTextColor(0xFFDDDDDD);
        flat.setTextSize(12.5f);
        flat.setChecked(canvas.isFlatPaint());
        flat.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                canvas.setFlatPaint(on);
                getSharedPreferences("pz", MODE_PRIVATE).edit().putBoolean("flat_paint", on).apply();
            }
        });
        root.addView(flat);
        final AlertDialog[] dlg = new AlertDialog[1];
        for (int i = 0; i < list.length; i++) {
            final com.pacco.animecut.core.BrushPreset bp = list[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            if (i == current) {
                android.graphics.drawable.GradientDrawable sel = new android.graphics.drawable.GradientDrawable();
                sel.setColor(0xFF1E2A44);
                sel.setStroke(dp(2), 0xFF3D7BFF);
                sel.setCornerRadius(dp(8));
                row.setBackground(sel);
            } else {
                row.setBackgroundResource(R.drawable.bg_cell);
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, 0, 0, dp(4));
            row.setLayoutParams(rlp);
            row.setPadding(dp(10), dp(6), dp(10), dp(6));
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(android.view.Gravity.CENTER_VERTICAL);
            TextView t = new TextView(this);
            t.setText(bp.name + (i == current ? "  (en uso)" : ""));
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12.5f);
            top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView sz = new TextView(this);
            sz.setText(String.format(Locale.US, bp.size < 10 ? "%.1f" : "%.0f", bp.size));
            sz.setTextColor(0xFFAAAAAA);
            sz.setTextSize(12f);
            top.addView(sz);
            row.addView(top);
            final ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
            img.setScaleType(ImageView.ScaleType.FIT_XY);
            row.addView(img);
            // las muestras se dibujan aparte para que la lista abra al instante
            final int pw = dp(260), ph = dp(34);
            thumbPool.execute(new Runnable() {
                @Override
                public void run() {
                    final Bitmap b = bp.preview(pw, ph);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            img.setImageBitmap(b);
                        }
                    });
                }
            });
            final int idx = i;
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dlg[0].dismiss();
                    applyBrushPreset(idx, true);
                    canvas.showHud(bp.name);
                }
            });
            root.addView(row);
        }
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        dlg[0] = new AlertDialog.Builder(this).setView(sc).create();
        dlg[0].show();
    }

    /** Aplica un pincel. Con all=false solo su forma de trazo (al abrir la app). */
    private void applyBrushPreset(int idx, boolean all) {
        com.pacco.animecut.core.BrushPreset[] list = com.pacco.animecut.core.BrushPreset.PRESETS;
        if (idx < 0 || idx >= list.length) return;
        com.pacco.animecut.core.BrushPreset bp = list[idx];
        canvas.setBrushDynamics(bp.taperStart, bp.taperEnd, bp.speedThin, bp.particles, bp.grain, bp.spacing, bp.flow);
        if (!all) return;
        getSharedPreferences("pz", MODE_PRIVATE).edit().putInt("brush_preset3", idx).apply();
        canvas.setBrushSize(bp.size);
        canvas.setHardness(bp.hardness);
        ((SeekBar) findViewById(R.id.opacity)).setProgress(bp.opacity);
        syncSlider();
        updateUi();
    }

    private void toleranceDialog() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(160);
        bar.setProgress(canvas.getTolerance());
        final TextView t = new TextView(this);
        t.setText(String.valueOf(canvas.getTolerance()));
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(18f);
        t.setGravity(android.view.Gravity.CENTER);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(t);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                t.setText(String.valueOf(v));
                canvas.setTolerance(v);
            }
        });
        new AlertDialog.Builder(this).setView(root).setPositiveButton("OK", null).show();
    }

    /** Elegir que parte se esta rayando: un color por parte, el gris es el fondo. */
    private void labelPicker() {
        int n = CanvasView.LABEL_NAMES.length;
        int[] icons = new int[n];
        String[] names = new String[n];
        Runnable[] actions = new Runnable[n];
        for (int i = 0; i < n; i++) {
            icons[i] = R.drawable.ic_color;
            names[i] = i == n - 1 ? "fondo" : "parte " + (i + 1);
            final int lab = i + 1;
            actions[i] = new Runnable() {
                public void run() {
                    canvas.setMarkerLabel(lab);
                    canvas.setSubtract(false);
                    canvas.showHud(lab == CanvasView.LABEL_NAMES.length ? "Rayando el fondo" : "Rayando parte " + lab);
                    updateUi();
                }
            };
        }
        showIconGridTinted(icons, names, actions, 3, canvas.getMarkerLabel() - 1, CanvasView.LABEL_COLORS);
    }

    private void showIconGridTinted(int[] icons, String[] names, Runnable[] actions, int cols,
                                    int active, int[] tints) {
        tintNext = tints;
        showIconGrid(null, icons, names, actions, cols, active);
        tintNext = null;
    }

    /** Cuadricula de iconos con su nombre corto debajo. */
    private void showIconGrid(String title, int[] icons, String[] names, final Runnable[] actions,
                              int cols, int active) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(0xFF232329);
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                root.addView(row);
            }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(android.view.Gravity.CENTER);
            cell.setPadding(dp(4), dp(10), dp(4), dp(10));
            cell.setBackgroundResource(i == active ? R.drawable.bg_tool_on : R.drawable.bg_cell);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            clp.setMargins(dp(3), dp(3), dp(3), dp(3));
            cell.setLayoutParams(clp);

            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
            img.setImageResource(icons[i]);
            if (tintNext != null && i < tintNext.length) img.setColorFilter(tintNext[i]);
            cell.addView(img);

            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextColor(0xFFE8E8E8);
            t.setTextSize(12f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, dp(4), 0, 0);
            cell.addView(t);

            final int idx = i;
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (dlg[0] != null) dlg[0].dismiss();
                    actions[idx].run();
                }
            });
            if (demoNext != null && i < demoNext.length) {
                final int scene = demoNext[i];
                cell.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showSelCard(scene);
                        return true;
                    }
                });
            }
            row.addView(cell);
        }
        // rellenar la ultima fila para que no se estiren las celdas
        int rest = icons.length % cols;
        if (rest != 0 && row != null) {
            for (int k = rest; k < cols; k++) {
                View v = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
                v.setLayoutParams(lp);
                row.addView(v);
            }
        }
        if (demoNext != null) {
            TextView hint = new TextView(this);
            hint.setText("Manten presionado un boton para ver que hace");
            hint.setTextColor(0xFF9FC6FF);
            hint.setTextSize(12f);
            hint.setGravity(android.view.Gravity.CENTER);
            hint.setPadding(0, dp(8), 0, dp(2));
            root.addView(hint);
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setView(root);
        if (title != null) b.setTitle(title);
        dlg[0] = b.create();
        dlg[0].show();
    }

    /** Ficha de la herramienta: dibujo de antes y despues y tres lineas cortas. */
    private void showToolCard(int mode, int sub) {
        String[] info = toolInfo(mode, sub);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(info[0]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        View art = demoFor(mode, sub);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        root.addView(cardLine("Para que:", info[1]));
        root.addView(cardLine("Como:", info[2]));
        if (!info[3].isEmpty()) root.addView(cardLine("", info[3]));
        new AlertDialog.Builder(this).setView(root).setPositiveButton("Entendido", null).show();
    }

    private TextView cardLine(String head, String text) {
        TextView t = new TextView(this);
        t.setText(head.isEmpty() ? text : head + " " + text);
        t.setTextColor(head.isEmpty() ? 0xFF9FC6FF : 0xFFE0E0E0);
        t.setTextSize(13f);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    /**
     * La primera vez que eliges una herramienta sale su ficha completa. Las
     * siguientes veces, un cuadrito con la animacion unos segundos.
     */
    private void cardFirstTime(int mode, int sub) {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        String key = "card_" + mode + "_" + sub;
        if (!sp.getBoolean(key, false)) {
            sp.edit().putBoolean(key, true).apply();
            showToolCard(mode, sub);
            return;
        }
        if (sp.getBoolean("demo_on", true)) showDemo(mode, sub);
    }

    /** Animacion de la herramienta. Separar y la varita usan la de antes y despues. */
    private View demoFor(int mode, int sub) {
        if (mode == CanvasView.MODE_MARKER) return new SelDemoView(this, SelDemoView.SEPARATE);
        if (mode == CanvasView.MODE_WAND && canvas.isAutoLines()) return new SelDemoView(this, SelDemoView.WAND_LINES);
        int variant = mode == CanvasView.MODE_LIQUIFY ? canvas.getLiquifyType() : 0;
        return new com.pacco.animecut.view.ToolDemoView(this, mode, sub == 2, variant);
    }

    /** Cuadrito arriba a la izquierda con la herramienta trabajando. Se va solo. */
    private void showDemo(int mode, int sub) {
        final View box = findViewById(R.id.demoBox);
        FrameLayout holder = findViewById(R.id.demoHolder);
        holder.removeAllViews();
        holder.addView(demoFor(mode, sub),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        String demoTitle = toolInfo(mode, sub)[0];
        if (mode == CanvasView.MODE_LIQUIFY) {
            int lt = canvas.getLiquifyType();
            demoTitle = "Especial · " + (lt == 0 ? "Arrastrar" : lt == 1 ? "Contraer"
                    : lt == 2 ? "Expandir" : lt == 3 ? "Suavizar" : "Restaurar");
        }
        ((TextView) findViewById(R.id.demoName)).setText(demoTitle);
        box.setVisibility(View.VISIBLE);
        box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                box.setVisibility(View.GONE);
            }
        });
        if (hideDemo != null) box.removeCallbacks(hideDemo);
        hideDemo = new Runnable() {
            @Override
            public void run() {
                box.setVisibility(View.GONE);
                ((FrameLayout) findViewById(R.id.demoHolder)).removeAllViews();
            }
        };
        box.postDelayed(hideDemo, 4500);
    }

    private void tutorialPage(final int page) {
        final int[] modes = {CanvasView.MODE_BGERASE, CanvasView.MODE_MARKER, CanvasView.MODE_ZONE,
                CanvasView.MODE_PAN};
        final String[] titles = {"1. Saca el personaje", "2. Separa las partes",
                "3. Rellena lo de atras", "4. Exporta"};
        final String[] texts = {
                "Tu imagen queda en la capa \"imagen\". Con Borrar fondo pasas el pincel por el borde y "
                        + "solo se borra el fondo. En Capas puedes mirar sobre negro o verde para ver si quedo limpio.",
                "Separar: raya cada parte con un color (pelo, cara, ojos) y el fondo en gris, y toca el check "
                        + "verde. Cada parte sale en su capa. Tambien: Varita y en el cuadro punteado, Copiar a capa.",
                "Donde sacaste un ojo o un brazo, en la capa de atras queda el dibujo viejo. Marca esa zona en azul, "
                        + "toca esa capa en Capas y usa Zona tocando dentro de lo azul: queda con el color de alrededor.",
                "La flecha de abajo guarda un PNG por cada capa visible, todas del mismo tamano, "
                        + "listas para Alight Motion."
        };        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(4));
        root.setBackgroundColor(0xFF232329);
        TextView title = new TextView(this);
        title.setText(titles[page]);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(18f);
        root.addView(title);
        com.pacco.animecut.view.ToolDemoView art =
                new com.pacco.animecut.view.ToolDemoView(this, modes[page], false);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(170), dp(170));
        alp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        alp.topMargin = dp(8);
        alp.bottomMargin = dp(8);
        art.setLayoutParams(alp);
        root.addView(art);
        TextView t = new TextView(this);
        t.setText(texts[page]);
        t.setTextColor(0xFFE0E0E0);
        t.setTextSize(14f);
        root.addView(t);
        TextView foot = new TextView(this);
        foot.setText((page + 1) + " de 4    Manten pulsada cualquier herramienta para ver su ficha");
        foot.setTextColor(0xFF8A8A92);
        foot.setTextSize(11f);
        foot.setPadding(0, dp(10), 0, 0);
        root.addView(foot);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setView(root);
        if (page < 3) {
            b.setPositiveButton("Siguiente", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    tutorialPage(page + 1);
                }
            });
            b.setNegativeButton("Saltar", null);
        } else {
            b.setPositiveButton("Empezar", null);
        }
        b.show();
    }

    /** Tutorial: cuatro fichas con dibujo, una detras de otra. */
    private void guideDialog() {
        tutorialPage(0);
    }

    private void guideIfFirstTime() {
        android.content.SharedPreferences sp = getSharedPreferences("pz", MODE_PRIVATE);
        if (sp.getBoolean("guia3", false)) return;
        sp.edit().putBoolean("guia3", true).apply();
        guideDialog();
    }

    private void projectDialog() {
        final boolean has = canvas.getProject() != null;
        final String[] items = {
                "Guardar proyecto en un archivo",
                "Abrir un proyecto guardado",
                "Guardar ahora en la app"
        };
        new AlertDialog.Builder(this)
                .setTitle("Proyecto")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        if (i == 1) {
                            openProject.launch(new String[]{"*/*"});
                            return;
                        }
                        if (!has) {
                            toast("Abre una imagen primero");
                            return;
                        }
                        if (i == 0) createProject.launch("proyecto.acut");
                        else autosave(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void saveProjectTo(final Uri uri) {
        final Project p = canvas.getProject();
        if (p == null) return;
        final int color = canvas.getColor();
        onBusy(true);
        lastError = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    ProjectIO.save(os, p, color);
                    if (os != null) os.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                if (lastError != null) toast("Error al guardar: " + lastError);
                else toast("Proyecto guardado con sus " + p.layers.size() + " capas");
            }
        });
    }

    private void openProjectFrom(final Uri uri) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = getContentResolver().openInputStream(uri);
                    loaded = ProjectIO.load(is);
                    if (is != null) is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    private void recoverFrom(final File f) {
        onBusy(true);
        lastError = null;
        loaded = null;
        Task.run(new Runnable() {
            @Override
            public void run() {
                try {
                    FileInputStream is = new FileInputStream(f);
                    loaded = ProjectIO.load(is);
                    is.close();
                } catch (Throwable t) {
                    lastError = String.valueOf(t.getMessage());
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                onBusy(false);
                applyLoaded();
            }
        });
    }

    /** Mantiene la proporcion para que todas las capas sigan cuadrando entre si. */
    private int[] longSide(Project p, int target) {
        int max = Math.max(p.w, p.h);
        if (max <= target) return new int[]{p.w, p.h};
        float f = target / (float) max;
        return new int[]{Math.max(1, Math.round(p.w * f)), Math.max(1, Math.round(p.h * f))};
    }

    private int toolIcon(int mode) {
        switch (mode) {
            case CanvasView.MODE_LASSO: return R.drawable.ic_lasso;
            case CanvasView.MODE_SCISSORS: return R.drawable.ic_scissors;
            case CanvasView.MODE_BRUSH: return R.drawable.ic_brush;
            case CanvasView.MODE_ERASER: return R.drawable.ic_eraser;
            case CanvasView.MODE_PAINT: return R.drawable.ic_paint;
            case CanvasView.MODE_BUCKET: return R.drawable.ic_bucket;
            case CanvasView.MODE_PICKER: return R.drawable.ic_picker;
            case CanvasView.MODE_CLONE: return R.drawable.ic_clone;
            case CanvasView.MODE_MOVE: return R.drawable.ic_move;
            case CanvasView.MODE_PAN: return R.drawable.ic_hand;
            case CanvasView.MODE_BGERASE: return R.drawable.ic_bgerase;
            case CanvasView.MODE_MARKER: return R.drawable.ic_marker;
            case CanvasView.MODE_MAGNET: return R.drawable.ic_magnet;
            case CanvasView.MODE_LINE: return R.drawable.ic_line_cont;
            case CanvasView.MODE_CURVE: return R.drawable.ic_curve;
            case CanvasView.MODE_POLY: return R.drawable.ic_poly;
            case CanvasView.MODE_ZONE: return R.drawable.ic_zone;
            case CanvasView.MODE_PATCH: return R.drawable.ic_patch_fill;
            case CanvasView.MODE_HEAL: return R.drawable.ic_heal;
            case CanvasView.MODE_TONE: return R.drawable.ic_tone;
            case CanvasView.MODE_SMUDGE: return R.drawable.ic_smudge;
            case CanvasView.MODE_BLUR: return R.drawable.ic_blur;
            case CanvasView.MODE_LIQUIFY: return R.drawable.ic_liquify;
            case CanvasView.MODE_TRANSFORM: return R.drawable.ic_transform;
            default: return R.drawable.ic_wand;
        }
    }

    private void fillRow(LinearLayout row, int used, int cols) {
        for (int k = used; k < cols; k++) {
            View v = new View(this);
            v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
            row.addView(v);
        }
    }

    private void closeTools() {
        findViewById(R.id.toolPanel).setVisibility(View.GONE);
        findViewById(R.id.toolScrim).setVisibility(View.GONE);
        FrameLayout.LayoutParams l = (FrameLayout.LayoutParams) findViewById(R.id.toolPanel).getLayoutParams();
        l.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        findViewById(R.id.toolPanel).setLayoutParams(l);
    }

    private ImageButton iconButton(int icon, final String name, final Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        b.setBackgroundResource(R.drawable.bg_tool);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setImageResource(icon);
        b.setContentDescription(name);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                toast(name);
                return true;
            }
        });
        return b;
    }

    /** Boton compacto para Transformar: evita que X/✓ queden fuera de pantalla. */
    private ImageButton compactIconButton(int icon, final String name, final Runnable action) {
        ImageButton b = iconButton(icon, name, action);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(31), dp(36)));
        b.setPadding(dp(6), dp(7), dp(6), dp(7));
        return b;
    }

    private ImageView thumb(Bitmap b) {
        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setImageBitmap(b);
        return img;
    }

    private TextView rowText(String name, String sub, boolean bright) {
        TextView t = new TextView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(10);
        t.setLayoutParams(lp);
        t.setText(name + "\n" + sub);
        t.setTextColor(bright ? 0xFFFFFFFF : 0xFF7A7A7A);
        t.setTextSize(13f);
        return t;
    }

    private LinearLayout rowBase(boolean on) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(on ? R.drawable.bg_row_on : R.drawable.bg_row);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);
        return row;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void click(int id, final Runnable r) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
    }

    private boolean needProject() {
        if (canvas.getProject() == null) {
            toast("Abre una imagen primero");
            return false;
        }
        return true;
    }

    /** Marca en azul lo que esta activado, para que se vea sin leer nada. */
    private void toggle(int id, boolean on) {
        findViewById(id).setBackgroundResource(on ? R.drawable.bg_tool_on : R.drawable.bg_tool);
    }

    private boolean sliderIsTolerance() {
        int m = canvas.getMode();
        return m == CanvasView.MODE_WAND || m == CanvasView.MODE_BUCKET;
    }

    private void applySlider(int v) {
        if (sliderIsTolerance()) {
            canvas.setTolerance(v);
            sliderLabel.setText(String.valueOf(v));
        } else {
            float t = v / 120f;
            float size = 1f + t * t * 299f;
            canvas.setBrushSize(size);
            canvas.showSizePreview(size);
            sliderLabel.setText(String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
            ((TextView) findViewById(R.id.btnSize)).setText(
                    String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void syncSlider() {
        if (sliderIsTolerance()) {
            slider.setProgress(canvas.getTolerance());
            sliderLabel.setText(String.valueOf(canvas.getTolerance()));
        } else {
            float t = (float) Math.sqrt(Math.max(0f, (canvas.getBrushSize() - 1f) / 299f));
            slider.setProgress(Math.round(t * 120f));
            float size = canvas.getBrushSize();
            sliderLabel.setText(String.format(Locale.US, size < 10 ? "%.1f" : "%.0f", size));
        }
    }

    private void measureBars() {
        final View top = findViewById(R.id.topBar);
        final View bottom = findViewById(R.id.bottomPanel);
        top.post(new Runnable() {
            @Override
            public void run() {
                canvas.setInsets(top.getHeight() + dp(12), bottom.getHeight());
                if (canvas.getProject() != null) canvas.fit();
                barsMeasured = true;
                if (pendingReveal) revealCanvas();
            }
        });
    }

    /** Para no repetir los tres metodos del SeekBar en cada dialogo. */
    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }
}
