# Resultados de las pruebas internas de la v8.58 (filtros, modos y capas)

Nota: en la 8.58, "Mejorar imagen" y "Recortar con IA" volvieron a ser idénticos a la 8.56. Las pruebas de la parte D se hicieron en la 8.57 y quedan solo como referencia; esos cambios NO están en la 8.58.

## Dónde se probó

- **Equipo**:
  - PC en la nube: procesador Intel Xeon de 2,10 GHz con 2 núcleos y 7 GB de RAM.
  - Linux con OpenJDK 21.
  - Las pruebas de IA usaron ONNX Runtime 1.29 para PC, en el procesador. La app usa ONNX Runtime 1.20 para Android.
- **NO se probó en ningún teléfono ni emulador.** Un teléfono de gama baja puede ser de 3 a 6 veces más lento que esta PC. Los tiempos de abajo son de la PC, no del teléfono.
- **Compilación**:
  - El proyecto completo compila sin errores con javac y las clases reales de Android 14 (android.jar de la plataforma 34).
  - Para androidx y ONNX Runtime, que no se pudieron descargar aquí, se usaron reemplazos mínimos que solo sirven para compilar.
  - El APK lo arma tu GitHub Actions; aquí no se pudo armar.
- **Imágenes usadas**:
  - Tus imágenes del proyecto: manga B/N, manga gris y anime a color.
  - Un recorte con transparencia hecho a partir de ellas.
  - Casos sintéticos con resultado conocido: líneas sobre papel amarillo con JPEG malo, y líneas con el fondo borrado con balde.

## Pruebas

### A) Vista previa

- **T01 Abrir y cerrar 20 veces: PASA (PC).**
  - Memoria usada tras limpiar: 34 MB en la vuelta 1 y 33 MB en la vuelta 20. No crece.
- **T02 Barra rápida de mínimo a máximo, 101 cambios: PASA (PC).**
  - Se usó la misma regla de "generación" que la pantalla.
  - Se mostró el último pedido, nunca uno viejo después de uno nuevo, y la imagen final es idéntica al último valor.
- **T03 Cancelar a mitad: PASA (PC).**
  - Cancelado a los 40 ms (respondió en 45 a 58 ms) y la capa quedó sin ningún cambio.
- **T04 Aplicar, Deshacer y Rehacer 10 veces con el historial real de la app: PASA (PC).**
  - Los pixeles quedaron exactos en cada paso.
- **T05 Vista previa vs resultado real: medido (PC).**
  - Se comparó el resultado a tamaño real, reducido al tamaño de la vista previa, con la vista previa.
  - Diferencia media de 0 a 6 sobre 255 en todos los filtros.
  - Lo más distinto:
    - **Ruido** (2,5 a 6,3): en la vista previa el grano se ve más grueso porque cada pixel chico representa varios reales.
    - **Pictorizar líneas** (1,7 a 3,1): las líneas finas en la copia chica salen un poco distintas.
- **T06 El filtro no crea capas: PASA en PC (calcular no agrega capas).**
  - La opción "capa nueva" está en la app; compila, pero no se probó en el teléfono.

### B) Filtros

- **T07 Extraer líneas: PASA (PC, con resultado conocido).**
  - **Manga limpio**: tinta conservada 100 % y papel 100 % transparente.
  - **JPEG sucio con papel amarillo y mancha**:
    - con la corrección de papel nueva: tinta conservada 99,2 % y papel 100 % transparente;
    - sin la corrección, como antes: quedaba un velo en el papel (alfa medio 0,042) y el doble de manchas.
  - **Pestañas finas y trama de puntos**: se conservan, porque "Limpiar puntos" viene en 0.
- **T08 a T10 Pictorizar: revisado mirando las imágenes (PC).**
  - Las líneas siguen ojos, pelo y contornos, en color y en manga.
  - Pictorizar color aplana sin borrar los bordes.
  - La versión combinada no oscurece el fondo.
  - En un manga con mucho negro, el pelo negro queda como un contorno (no se rellena).
- **T11 Inflar con el sol movido 40 veces: PASA (PC).**
  - Primera vez 37 ms; luego mediana de 4 ms y máximo de 37 ms. El volumen se calcula una sola vez.
- **T12 Sombra y Resplandor en capa transparente: PASA (PC).**
  - Ningún pixel perdió transparencia.
  - El resplandor no toca la transparencia salvo que marques "Brillar fuera del dibujo".
- **T13 Valores 0, normal y máximo: PASA (PC).**
  - En 0 la imagen queda idéntica.
  - Ruido, vintage, nitidez, inflar, pictorizar color, posterizar y niveles no cambian la transparencia.
  - El ruido sale idéntico cada vez.

### C) Modos de mezcla

- **T14 Los 28 modos: PASA (PC).**
  - Se probaron 4000 colores con la capa al 0, 25, 50, 75 y 100 %, y con lo de abajo a 0, 35 y 100 %.
  - Ningún error y ningún resultado fuera de regla.
  - Diferencia máxima con las fórmulas W3C: 1 sobre 255.
- **T15 Opacidades: PASA (PC).**
  - Al 0 % no cambia nada. Cancelar vuelve al modo y a la opacidad guardados (revisado en el código).
- **T16 Pantalla vs exportar/miniatura: PASA (PC).**
  - Se comparó la cuenta de la pantalla con la del exportado en los 28 modos, con alfa al azar: diferencia 0.
- **T17 Sobreexponer brillo y Añadir brillo: medido. Son una aproximación propia.**
  - Con un pincel suave sobre fondo oscuro dan más brillo que Sobreexponer color y Añadir en lo semitransparente. Al 100 % dan lo mismo.
  - No se asegura que sean idénticos a Clip Studio.
- **T18 Obras viejas: PASA por diseño.**
  - Los números de los modos 0 a 23 no cambiaron; solo se agregaron del 24 al 27. Los nombres cambiaron solo en pantalla.

### D) IA y bordes (hecho en la 8.57, NO incluido en la 8.58)

- **T19 B/N con el fondo borrado y línea negra, al 100 % y al 400 %: PASA (PC).**
  - Antes salían escalones del lado transparente; ahora la línea queda lisa y nítida.
  - Imágenes 01, 02, 03 y 06.
- **T20 Color con escalones: PASA (PC).**
  - El borde queda liso y sin halo. Imagen 04.
- **T21 Alfa semitransparente: PASA (PC).**
  - El borde suave se conserva sin agregar bordes grises ni blancos. Imagen 05.
  - Una primera versión lo endurecía; se corrigió.
- **T22 Uniones a 2x y 4x: PASA (PC).**
  - El salto en las uniones de pedazos (1,17 y 1,22) está dentro de lo normal de la imagen: en columnas cualquiera va de 0,98 a 1,27.
  - No se ven costuras, ni antes ni ahora.
  - Tiempo en PC: unos 5 s para una imagen de 736 x 736 a x2 o x4.
  - Los pedazos con borde pasan dos veces por la IA, así que tardan entre 1,5 y 2 veces más.
- **T23 Cancelar Mejorar: PASA (PC).**
  - Devuelve nada y la obra no cambia.
  - Cerrar la pantalla a mitad: no se probó (necesita el teléfono).
- **T24 Poca memoria simulada: PASA (PC).**
  - Si el pedazo falla, se reintenta a la mitad y, si igual falla, cancela limpio.
  - La memoria libre real del teléfono no se probó.
- **T25 Modelo reducido de Recortar con IA: NO EJECUTADO.**
  - La herramienta para convertir el modelo no se pudo instalar en este equipo (bloqueo de red), así que no se generó ni se incluye.
  - Medido el modelo actual en PC: 322 MB cargado en modo ahorro y pico de 874 MB al recortar. En modo completo: 525 MB y pico de 1153 MB.
  - Queda pendiente.
- **T26 Recortar con IA ve el sujeto completo: sin cambios.**
  - El modelo pide siempre la imagen entera a 1024; no se partió en pedazos.

### E) Pantalla y funcionamiento normal

- **T27 Panel de capas con 1, 5, 20 o más capas: NO EJECUTADO** (necesita el teléfono). Compila.
- **T28 Pregunta "¿Extraer líneas?": PASA (PC).**
  - Pregunta con manga B/N y manga gris.
  - No pregunta con imagen a color ni con un recorte transparente.
- **T29 Zoom y rotación con dos dedos: NO EJECUTADO** (necesita el teléfono). Ese código no se tocó.
- **T30 Regresión de Pintar, Balde, Borrar fondo, Separar, Marioneta y Lazo: NO EJECUTADO en el teléfono.**
  - Esas herramientas no se tocaron, salvo la cuenta de los modos de mezcla en la pantalla, que dio idéntico (T16). Compila.
- **T31 Comparación con Clip Studio: solo por comportamiento**, mirando tus 20 capturas.
  - No se copió código, imágenes ni marca.
- **T32 Abrir obras viejas, guardar, exportar y volver tras una interrupción: NO EJECUTADO** (necesita el teléfono). El formato de guardado no cambió.

## Tiempos de la vista previa en la PC

Medido en milisegundos: la primera vez al elegir el filtro, y luego la mediana mientras mueves la barra. Copia de 720 x 720 de un manga de 1108 x 1108.

- **Muy rápidos (menos de 25 ms)**:
  - Extraer líneas 18
  - Pictorizar líneas 23
  - Nitidez 13
  - Ruido 10
  - Sombra 9
  - Aberración 19
  - Posterizar 2
  - Niveles 2
- **Rápidos (25 a 80 ms)**:
  - Pictorizar color 51
  - Color y líneas 78
  - Gaussiano 56
  - Movimiento 64
  - Radial 71
  - Resplandor 39
  - Inflar 33
  - Vintage 28
  - Quitar ruido 66
- **El más pesado**: Desenfoque de lente, 158.

En el teléfono, mientras arrastras, se usa una copia más chica (400 o 320 de lado), que es unas 3 veces más liviana. El objetivo de 50 ms en el teléfono es una meta, no algo medido.

## Archivos de comparación (carpeta aparte, no van en el ZIP)

- **Filtros**: 07 manga, 08 color, 09 recorte transparente.
- 10 Extraer líneas en JPEG sucio, sin y con la corrección de papel.
- 11 Los 28 modos de mezcla.
- 12 Sombra paralela en una capa transparente.

## Prueba extra de la 8.58: suavizar el borde de Recortar con IA (descartada)

Se probó un paso nuevo al final del recorte con IA, con el modelo real y tus imágenes (manga, manga gris y dos a color):
- **Qué hacía**: quitaba el halo claro pegado a la línea y devolvía su antialias.
- **Medido**: en vez de mejorar, aumentó los pixeles claros pegados al corte y los saltos bruscos de opaco a transparente. Por ejemplo, en el manga los saltos pasaron de 48 a 271, y en una imagen a color de 106 a 301.
- **Decisión**: no se incluyó. El recorte con IA queda como en la 8.56.
- **Para seguir**: hace falta una captura tuya de un recorte con IA donde el borde salió feo, para atacar ese caso concreto.
