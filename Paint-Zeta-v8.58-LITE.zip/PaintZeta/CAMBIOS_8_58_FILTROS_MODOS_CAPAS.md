# Paint Zeta v8.58: filtros con vista previa, 28 modos y capas compactas

Es la 8.57 con una corrección: **la IA queda exactamente como en la 8.56**.
- **"Mejorar imagen"** vuelve a ser idéntico a la 8.56, sin el cambio de bordes, de pedazos ni de temperatura. Tú no habías pedido cambiarlo.
- **"Recortar con IA"** también queda idéntico a la 8.56. Probé suavizar el borde final del recorte con IA, pero en las mediciones con tus imágenes salía peor (dejaba más saltos bruscos), así que no se incluyó.

Hecha sobre la 8.56, sin quitar nada de lo anterior.

## Qué ya existía y se reutilizó

- **24 de los 28 modos de mezcla** (mismas fórmulas; solo se agregaron los 4 que faltaban).
- **Filtros de limpieza**: Quitar ruido JPEG, Posterizar y Niveles. Ahora están dentro de la pantalla nueva de Filtros, no en un menú aparte.
- **"Líneas" de Capas**: crea la capa de líneas más la capa de color debajo. Sigue igual, pero ahora usa el mismo motor que "Extraer líneas", que corrige el papel amarillo.
- **"Mejorar imagen" y "Recortar con IA"**: sin cambios, idénticos a la 8.56.

## Qué se añadió

- **Pantalla de Filtros** (menú de la capa > Filtros), al estilo de Clip Studio:
  - La obra arriba y abajo una fila de filtros con miniaturas.
  - Solo las barras del filtro elegido; las avanzadas van en "Más ajustes".
  - Botones Aceptar y Cancelar arriba, y "Antes" (mantener pulsado) para ver la obra sin el filtro.
  - La vista previa se calcula en una copia chica, en segundo plano. Mientras arrastras usa una copia más chica todavía, y al soltar se calcula bien.
  - Aceptar calcula a tamaño real, con barra de avance y Cancelar. Se puede Deshacer.
  - "Aplicar en capa nueva" es opcional y viene apagado.
  - Si hay selección, el filtro solo cambia lo seleccionado.
- **Filtros**:
  - Extraer líneas
  - Pictorizar líneas
  - Pictorizar color
  - Pictorizar color y líneas
  - Desenfoques: gaussiano, de movimiento, radial y de lente
  - Nitidez
  - Ruido
  - Resplandor
  - Sombra paralela
  - Inflar (el sol se mueve con el dedo)
  - Película vintage
  - Aberración cromática
  - Quitar ruido JPEG, Posterizar y Niveles (los de antes)
- **Rueda de modos de mezcla**:
  - Al deslizar, el modo del centro se ve al momento en el lienzo.
  - Arriba va la barra de opacidad con cuadritos.
  - Aceptar guarda el cambio (se puede Deshacer); Cancelar vuelve a como estaba.
  - Hay 28 modos con los nombres de Clip Studio. Los nuevos son Color más oscuro, Color más claro, Sobreexponer brillo y Añadir brillo.
  - Sobreexponer brillo y Añadir brillo son una aproximación propia, porque Clip Studio no publica su fórmula.
- **¿Extraer las líneas?**:
  - Al abrir una imagen que parece manga en blanco y negro, pregunta una sola vez.
  - No pregunta con fotos, imágenes a color ni recortes con transparencia.
  - Tiene la opción "No volver a preguntar".

## Qué se corrigió

- **Panel de capas**:
  - La lista ocupa cerca de 1/8 de la pantalla; antes eran 270 dp y, con los botones, casi la mitad.
  - El botón "▲ Más" la agranda a 1/3 y "▼ Menos" la vuelve a achicar. Se recuerda lo que elegiste.
  - Con muchas capas, la lista se mueve por dentro y siempre deja a la vista la capa elegida.
  - Se mantuvieron la transparencia y todas las operaciones.

## Archivos principales

- **Nuevos**:
  - core/Fx.java (motor único de filtros)
  - core/FxSession.java (copias chicas y vista previa)
  - FxScreen.java (pantalla de Filtros)
- **Cambiados**:
  - core/Layer.java y core/Project.java: 4 modos nuevos y una sola función de mezcla para la pantalla, las miniaturas y el exportado.
  - core/Compositor.java, core/Atmos.java y view/CanvasView.java: usan esa función.
  - core/LineArt.java: "Líneas" usa el motor nuevo.
  - MainActivity.java:
    - rueda de modos
    - Filtros
    - panel de capas
    - pregunta al abrir
  - res/layout/activity_main.xml: alto del panel.

## Cómo probarlo en tu teléfono

1. **Filtros**:
   - Abre una imagen y entra a menú de la capa > Filtros.
   - Toca varios filtros y mueve las barras rápido. La imagen debe seguir sin trabarse y quedarse con lo último que pusiste.
   - Aceptar, luego Deshacer y Rehacer.
2. **Capa nueva**: marca "Aplicar en capa nueva" y acepta. Debe aparecer una capa encima y la original quedar igual. Sin marcar, no se crea ninguna capa.
3. **Inflar y Sombra**: arrastra el dedo sobre la imagen y mira que el sol o la sombra sigan al dedo.
4. **Extraer líneas**: pruébalo en un manga escaneado amarillento y en un JPEG.
5. **Modos**:
   - En Capas toca el modo de una capa.
   - Desliza la rueda: el lienzo debe cambiar al momento.
   - Mueve la opacidad. Cancelar debe volver a como estaba.
   - Exporta un PNG y compáralo con lo que ves.
6. **Capas**: con 1, 5 y 20 capas, prueba "▲ Más" y "▼ Menos", arrastrar capas para ordenar, duplicar, eliminar, ocultar y opacidad.
7. **¿Extraer las líneas?**: abre un manga (debe preguntar) y una foto a color (no debe preguntar). Prueba "No volver a preguntar".
8. **Resto de la app**: Borrar fondo, Recortar con IA, Colorear manga, Marioneta, Lazo, zoom con dos dedos y exportar, para confirmar que siguen igual.
