package com.pacco.animecut;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.pacco.animecut.core.Fx;
import com.pacco.animecut.core.FxSession;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.view.CanvasView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v8.57 pantalla "Filtros" (como la de Clip Studio en el telefono): la obra arriba, la fila de
 * filtros con miniaturas abajo, solo las barras del filtro elegido, Aceptar / Cancelar.
 *
 *  - La vista previa se calcula en una copia chica, en otro hilo. Si mueves la barra rapido,
 *    los calculos viejos se descartan (contador de generacion): nunca aparece un resultado viejo
 *    despues de uno nuevo. Mientras arrastras usa una copia aun mas chica; al soltar, la normal.
 *  - Aceptar calcula a tamano real con barra de avance y Cancelar. Se puede Deshacer.
 *  - "Aplicar en capa nueva" es OPCIONAL (apagado = cambia la capa elegida).
 *  - Tocar o arrastrar en la imagen mueve el sol / la sombra / el centro (si el filtro lo usa).
 *  - Mantener "Antes" muestra la obra sin el filtro.
 */
final class FxScreen {
    private final Activity act;
    private final CanvasView canvas;
    private final Layer target;
    private final Project project;
    private final float dens;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private Dialog dlg;
    private FxSession session;
    private volatile int gen;
    private volatile boolean closed;
    private int cur;
    private Fx.P params;
    private final Fx.P[] saved = new Fx.P[Fx.COUNT];

    private ImageView preview;
    private PointMark mark;
    private TextView title, help, info;
    private LinearLayout controls;
    private final LinearLayout[] cells = new LinearLayout[Fx.COUNT];
    private final ImageView[] thumbs = new ImageView[Fx.COUNT];
    private CheckBox newLayerBox;
    private boolean showAdvanced;
    private final Bitmap[][] bufs = new Bitmap[2][3];
    private final int[] bufIdx = new int[2];
    private long lastMs;

    private FxScreen(Activity a, CanvasView c, Layer t, int startId) {
        act = a;
        canvas = c;
        target = t;
        project = c.getProject();
        dens = a.getResources().getDisplayMetrics().density;
        prefs = a.getSharedPreferences("pz", Activity.MODE_PRIVATE);
        cur = startId;
    }

    private int dp(float v) { return Math.round(v * dens); }

    /** Abre la pantalla de filtros sobre la capa elegida. startId &lt; 0 = el ultimo usado. */
    static void open(Activity a, CanvasView c, int startId) {
        if (c.getProject() == null) return;
        Layer t = c.fxTarget();
        if (t == null) return;
        if (startId < 0) startId = a.getSharedPreferences("pz", Activity.MODE_PRIVATE).getInt("fx_last", Fx.EXTRACT);
        if (startId < 0 || startId >= Fx.COUNT) startId = Fx.EXTRACT;
        new FxScreen(a, c, t, startId).show();
    }

    // ------------------------------------------------------------------ armar la pantalla

    private void show() {
        params = Fx.defaults(cur);
        canvas.setCompactHold(true);
        dlg = new Dialog(act, android.R.style.Theme_Black_NoTitleBar);
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1B1B20);

        // barra de arriba: Cancelar · nombre · Aceptar
        LinearLayout top = new LinearLayout(act);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(6), dp(8), dp(6));
        TextView cancel = pill("Cancelar", 0xFF3A3A42);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { close(); }
        });
        title = new TextView(act);
        title.setTextColor(Color.WHITE);
        title.setTextSize(16f);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        TextView ok = pill("Aceptar", 0xFF2F6BD8);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { applyFull(); }
        });
        top.addView(cancel);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(ok);
        root.addView(top);

        // la obra
        FrameLayout frame = new FrameLayout(act);
        frame.setBackgroundColor(0xFF111114);
        preview = new ImageView(act);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(preview, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mark = new PointMark();
        frame.addView(mark, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        info = new TextView(act);
        info.setTextColor(0xCCFFFFFF);
        info.setTextSize(11f);
        info.setBackgroundColor(0x88000000);
        info.setPadding(dp(6), dp(2), dp(6), dp(2));
        info.setText("Preparando la vista previa...");
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ilp.gravity = Gravity.TOP | Gravity.START;
        ilp.setMargins(dp(6), dp(6), 0, 0);
        frame.addView(info, ilp);
        final TextView before = pill("Antes", 0xAA000000);
        before.setTextSize(12f);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.TOP | Gravity.END;
        blp.setMargins(0, dp(6), dp(6), 0);
        frame.addView(before, blp);
        before.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) showOriginal();
                else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) request(false);
                return true;
            }
        });
        preview.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) { return touchPoint(e); }
        });
        root.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ayuda corta + controles
        LinearLayout panel = new LinearLayout(act);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(6), dp(12), dp(2));
        help = new TextView(act);
        help.setTextColor(0xFFB8B8C0);
        help.setTextSize(12f);
        panel.addView(help);
        controls = new LinearLayout(act);
        controls.setOrientation(LinearLayout.VERTICAL);
        panel.addView(controls);
        newLayerBox = new CheckBox(act);
        newLayerBox.setText("Aplicar en capa nueva (la original no cambia)");
        newLayerBox.setTextColor(0xFFDDDDDD);
        newLayerBox.setTextSize(13f);
        newLayerBox.setChecked(prefs.getBoolean("fx_new_layer", false));
        newLayerBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                prefs.edit().putBoolean("fx_new_layer", v).apply();
            }
        });
        panel.addView(newLayerBox);
        root.addView(panel);

        // fila de filtros con miniaturas
        HorizontalScrollView hs = new HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setBackgroundColor(0xFF141418);
        LinearLayout strip = new LinearLayout(act);
        strip.setPadding(dp(4), dp(6), dp(4), dp(6));
        for (final int id : Fx.ORDER) {
            LinearLayout cell = new LinearLayout(act);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(3), dp(3), dp(3), dp(3));
            ImageView th = new ImageView(act);
            th.setScaleType(ImageView.ScaleType.CENTER_CROP);
            th.setBackgroundColor(0xFF2A2A30);
            cell.addView(th, new LinearLayout.LayoutParams(dp(58), dp(58)));
            TextView tv = new TextView(act);
            tv.setText(Fx.SHORT[id]);
            tv.setTextColor(0xFFDDDDDD);
            tv.setTextSize(10f);
            tv.setGravity(Gravity.CENTER);
            tv.setMaxLines(2);
            cell.addView(tv, new LinearLayout.LayoutParams(dp(66), ViewGroup.LayoutParams.WRAP_CONTENT));
            cell.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(id); }
            });
            cells[id] = cell;
            thumbs[id] = th;
            strip.addView(cell);
        }
        hs.addView(strip);
        root.addView(hs);

        dlg.setContentView(root);
        dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) { release(); }
        });
        Window win = dlg.getWindow();
        if (win != null) win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dlg.show();
        bindFilter();

        // copias chicas fuera de la pantalla; luego la primera vista previa y las miniaturas
        final int idx = project.layers.indexOf(target);
        long avail = availMem();
        final int mainSide = avail < 600_000_000L ? 540 : 720;
        final int dragSide = avail < 600_000_000L ? 320 : 400;
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    FxSession s = new FxSession(project.layers, idx, project.w, project.h,
                            project.selection, mainSide, dragSide);
                    s.build(new Fx.Job() {
                        @Override public boolean cancelled() { return closed; }
                        @Override public void progress(int pct) { }
                    });
                    session = s;
                } catch (Fx.Cancelled c) {
                    return;
                } catch (OutOfMemoryError e) {
                    ui.post(new Runnable() {
                        @Override public void run() { toast("No alcanzo la memoria para la vista previa"); close(); }
                    });
                    return;
                }
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (closed) return;
                        request(false);
                        makeThumbs();
                        if (session.hasSelection()) toast("Hay una seleccion: el filtro solo cambia lo seleccionado");
                    }
                });
            }
        });
    }

    private TextView pill(String text, int color) {
        TextView t = new TextView(act);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(18));
        t.setBackground(g);
        return t;
    }

    private long availMem() {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) act.getSystemService(Activity.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.availMem;
        } catch (Throwable t) {
            return 1_000_000_000L;
        }
    }

    // ------------------------------------------------------------------ elegir filtro y barras

    private void select(int id) {
        if (id == cur) return;
        saved[cur] = params;
        cur = id;
        params = saved[id] != null ? saved[id] : Fx.defaults(id);
        prefs.edit().putInt("fx_last", id).apply();
        bindFilter();
        request(false);
    }

    private void bindFilter() {
        title.setText(Fx.NAMES[cur]);
        Fx.Spec sp = Fx.spec(cur);
        help.setText(Fx.HELP[cur] + (sp.point != null ? " " + sp.point + "." : ""));
        for (int id = 0; id < Fx.COUNT; id++) {
            if (cells[id] == null) continue;
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(8));
            g.setColor(id == cur ? 0xFF2F6BD8 : 0x00000000);
            cells[id].setBackground(g);
        }
        controls.removeAllViews();
        boolean anyAdv = false;
        for (int i = 0; i < sp.sliders.length; i++) {
            Fx.Slider s = sp.sliders[i];
            if (s.advanced) { anyAdv = true; if (!showAdvanced) continue; }
            controls.addView(sliderRow(i, s));
        }
        if (anyAdv) {
            final TextView more = new TextView(act);
            more.setText(showAdvanced ? "Menos ajustes ▴" : "Más ajustes ▾");
            more.setTextColor(0xFF8FB4FF);
            more.setTextSize(13f);
            more.setPadding(0, dp(4), 0, dp(4));
            more.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showAdvanced = !showAdvanced; bindFilter(); }
            });
            controls.addView(more);
        }
        if (sp.toggle != null) {
            CheckBox cb = new CheckBox(act);
            cb.setText(sp.toggle);
            cb.setTextColor(0xFFDDDDDD);
            cb.setTextSize(13f);
            cb.setChecked(params.opt);
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean v) { params.opt = v; request(false); }
            });
            controls.addView(cb);
        }
        mark.invalidate();
    }

    private View sliderRow(final int i, final Fx.Slider s) {
        LinearLayout row = new LinearLayout(act);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView lab = new TextView(act);
        lab.setText(s.label);
        lab.setTextColor(0xFFEEEEEE);
        lab.setTextSize(13f);
        lab.setMinWidth(dp(92));
        final TextView val = new TextView(act);
        val.setTextColor(Color.WHITE);
        val.setTextSize(13f);
        val.setGravity(Gravity.END);
        val.setMinWidth(dp(52));
        val.setText(params.v[i] + s.unit);
        SeekBar sb = new SeekBar(act);
        sb.setMax(s.max - s.min);
        sb.setProgress(params.v[i] - s.min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int v, boolean user) {
                if (!user) return;
                params.v[i] = v + s.min;
                val.setText(params.v[i] + s.unit);
                request(true);
            }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { request(false); }
        });
        row.addView(lab);
        row.addView(sb, new LinearLayout.LayoutParams(0, dp(36), 1f));
        row.addView(val);
        return row;
    }

    // ------------------------------------------------------------------ vista previa

    /**
     * Pide una vista previa. Cada pedido sube la generacion; el calculo en curso ve que quedo
     * viejo y se corta, y los que estaban en cola se saltan. Solo se muestra el ultimo.
     */
    private void request(final boolean drag) {
        final FxSession s = session;
        if (s == null || closed) return;
        final int g = ++gen;
        final int id = cur;
        final Fx.P p = params.copy();
        worker.execute(new Runnable() {
            @Override public void run() {
                if (g != gen || closed) return;
                long t0 = SystemClock.uptimeMillis();
                int[] px;
                try {
                    px = s.render(id, p, drag, new Fx.Job() {
                        @Override public boolean cancelled() { return g != gen || closed; }
                        @Override public void progress(int pct) { }
                    });
                } catch (Fx.Cancelled c) {
                    return;
                } catch (OutOfMemoryError e) {
                    return;
                }
                if (g != gen || closed) return;
                final int level = drag ? 1 : 0;
                final Bitmap bm = nextBuffer(level, s.width(drag), s.height(drag));
                if (bm == null) return;
                bm.setPixels(px, 0, s.width(drag), 0, 0, s.width(drag), s.height(drag));
                final long ms = SystemClock.uptimeMillis() - t0;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (closed || g != gen) return;
                        preview.setImageBitmap(bm);
                        lastMs = ms;
                        info.setText((drag ? "Vista rápida" : "Vista previa reducida") + " · " + ms + " ms · al aceptar se calcula a tamaño real");
                        mark.invalidate();
                    }
                });
            }
        });
    }

    /** Tres bitmaps por nivel en rueda: nunca se escribe en el que se esta mostrando. */
    private Bitmap nextBuffer(int level, int w, int h) {
        try {
            int k = bufIdx[level] = (bufIdx[level] + 1) % 3;
            Bitmap b = bufs[level][k];
            if (b == null || b.getWidth() != w || b.getHeight() != h) {
                b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                bufs[level][k] = b;
            }
            return b;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    private void showOriginal() {
        final FxSession s = session;
        if (s == null) return;
        final int g = ++gen;
        worker.execute(new Runnable() {
            @Override public void run() {
                if (g != gen || closed) return;
                int[] px = s.original(false);
                final Bitmap bm = nextBuffer(0, s.width(false), s.height(false));
                if (bm == null) return;
                bm.setPixels(px, 0, s.width(false), 0, 0, s.width(false), s.height(false));
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (closed || g != gen) return;
                        preview.setImageBitmap(bm);
                        info.setText("Antes (sin el filtro)");
                    }
                });
            }
        });
    }

    private void makeThumbs() {
        final FxSession s = session;
        for (final int id : Fx.ORDER) {
            worker.execute(new Runnable() {
                @Override public void run() {
                    if (closed) return;
                    try {
                        int[] dims = new int[2];
                        int[] px = s.thumb(id, Math.max(48, dp(58)), dims);
                        final Bitmap b = Bitmap.createBitmap(px, dims[0], dims[1], Bitmap.Config.ARGB_8888);
                        ui.post(new Runnable() {
                            @Override public void run() { if (!closed) thumbs[id].setImageBitmap(b); }
                        });
                    } catch (Throwable ignored) { }
                }
            });
        }
    }

    /** Tocar / arrastrar en la imagen: mueve el sol, la sombra o el centro. */
    private boolean touchPoint(MotionEvent e) {
        Fx.Spec sp = Fx.spec(cur);
        if (sp.point == null || preview.getDrawable() == null) return false;
        float[] pt = {e.getX(), e.getY()};
        Matrix inv = new Matrix();
        if (!preview.getImageMatrix().invert(inv)) return false;
        inv.mapPoints(pt);
        int bw = preview.getDrawable().getIntrinsicWidth(), bh = preview.getDrawable().getIntrinsicHeight();
        if (bw <= 0 || bh <= 0) return false;
        params.px = Math.max(0f, Math.min(1f, pt[0] / bw));
        params.py = Math.max(0f, Math.min(1f, pt[1] / bh));
        mark.invalidate();
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) request(false);
        else request(true);
        return true;
    }

    /** Circulo en el punto elegido (sol, centro o hacia donde cae la sombra). */
    private final class PointMark extends View {
        private final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);

        PointMark() {
            super(act);
            setWillNotDraw(false);
        }

        @Override protected void onDraw(Canvas c) {
            Fx.Spec sp = Fx.spec(cur);
            if (sp.point == null || preview.getDrawable() == null) return;
            int bw = preview.getDrawable().getIntrinsicWidth(), bh = preview.getDrawable().getIntrinsicHeight();
            float[] pt = {params.px * bw, params.py * bh};
            preview.getImageMatrix().mapPoints(pt);
            pen.setStyle(Paint.Style.STROKE);
            pen.setStrokeWidth(dp(3));
            pen.setColor(0xFF000000);
            c.drawCircle(pt[0], pt[1], dp(13), pen);
            pen.setStrokeWidth(dp(1.6f));
            pen.setColor(cur == Fx.INFLATE ? 0xFFFFD54F : 0xFFFFFFFF);
            c.drawCircle(pt[0], pt[1], dp(13), pen);
            if (cur == Fx.INFLATE) {
                pen.setStyle(Paint.Style.FILL);
                c.drawCircle(pt[0], pt[1], dp(5), pen);
            }
        }
    }

    // ------------------------------------------------------------------ aplicar a tamano real

    private void applyFull() {
        if (session == null) { toast("Espera la vista previa"); return; }
        final int id = cur;
        final Fx.P p = params.copy();
        final boolean asNew = newLayerBox.isChecked();
        final long n = (long) project.w * project.h;
        if (!canvas.fxMemory(n * 4L * 7L)) toast("Poca memoria: puede tardar o no alcanzar");
        gen++;   // corta la vista previa en curso
        final boolean[] cancel = new boolean[1];
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(4));
        final TextView msg = new TextView(act);
        msg.setTextColor(Color.WHITE);
        msg.setText(Fx.NAMES[id] + " a tamaño real (" + project.w + "x" + project.h + ")...");
        final ProgressBar bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        box.addView(msg);
        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        final AlertDialog prog = new AlertDialog.Builder(act).setView(box).setCancelable(false)
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { cancel[0] = true; }
                }).show();
        final long t0 = SystemClock.uptimeMillis();
        final FxSession s = session;
        new Thread(new Runnable() {
            @Override public void run() {
                int[] res = null;
                String err = null;
                try {
                    res = s.full(id, p, new Fx.Job() {
                        @Override public boolean cancelled() { return cancel[0]; }
                        @Override public void progress(final int pct) {
                            ui.post(new Runnable() { @Override public void run() { bar.setProgress(pct); } });
                        }
                    });
                } catch (Fx.Cancelled c) {
                    err = "Cancelado: no cambió nada";
                } catch (OutOfMemoryError e) {
                    err = "No alcanzó la memoria del teléfono: no cambió nada";
                } catch (Throwable t) {
                    err = "No se pudo aplicar: " + t.getMessage();
                }
                final int[] r = res;
                final String e2 = err;
                final long ms = SystemClock.uptimeMillis() - t0;
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { prog.dismiss(); } catch (Throwable ignored) { }
                        if (e2 != null) { toast(e2); return; }
                        canvas.fxCommit(target, r, asNew, Fx.NAMES[id]);
                        toast(Fx.NAMES[id] + " listo en " + Math.max(1, ms / 100) / 10f + " s");
                        close();
                    }
                });
            }
        }, "pz-filtro").start();
    }

    // ------------------------------------------------------------------ cerrar

    private void close() {
        if (dlg != null && dlg.isShowing()) {
            try { dlg.dismiss(); } catch (Throwable ignored) { }
        } else {
            release();
        }
    }

    private void release() {
        if (closed) return;
        closed = true;
        gen++;
        worker.shutdownNow();
        canvas.setCompactHold(false);
        final FxSession s = session;
        session = null;
        if (s != null) s.release();
        preview.setImageDrawable(null);
        for (Bitmap[] lvl : bufs)
            for (int k = 0; k < lvl.length; k++) lvl[k] = null;   // los suelta el recolector (pueden seguir en uso un instante)
    }

    private void toast(String s) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show();
    }
}
