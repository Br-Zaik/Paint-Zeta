package com.pacco.animecut.core;

import android.graphics.Bitmap;

import java.util.Random;

/**
 * Pinceles como la lista basica de Ibis. Cada uno cambia de verdad el trazo:
 * punta fina al empezar y al terminar, grosor segun la velocidad, particulas,
 * grano de lapiz, espaciado y acumulacion (aerografo).
 */
public final class BrushPreset {

    public final String name;
    public final float size;       // grosor en px
    public final float hardness;   // 0.05 suave .. 1 duro
    public final int opacity;      // 0..100
    public final float taperStart; // largo de la punta al empezar (0 = sin punta)
    public final float taperEnd;   // largo de la punta al terminar (se ajusta al soltar)
    public final float speedThin;  // 0..1: mas rapido = mas fino
    public final int particles;    // 0 = solido; >0 = puntitos por toque
    public final float grain;      // 0..1 textura granulada
    public final float spacing;    // separacion entre toques (fraccion del radio)
    public final float flow;       // 0 = uniforme; >0 = se acumula como aerografo

    public BrushPreset(String name, float size, float hardness, int opacity, float taperStart, float taperEnd,
                       float speedThin, int particles, float grain, float spacing, float flow) {
        this.name = name;
        this.size = size;
        this.hardness = hardness;
        this.opacity = opacity;
        this.taperStart = taperStart;
        this.taperEnd = taperEnd;
        this.speedThin = speedThin;
        this.particles = particles;
        this.grain = grain;
        this.spacing = spacing;
        this.flow = flow;
    }

    //                                   nombre                     px   dureza op  ini  fin  vel  part grano esp  flujo
    public static final BrushPreset[] PRESETS = {
            new BrushPreset("Pluma (Suave)",               26f, 0.45f, 100, 1.0f, 1.0f, 0.30f, 0, 0f, 0.25f, 0f),
            new BrushPreset("Pluma (Fuerte)",              30f, 1.00f, 100, 1.0f, 1.0f, 0.30f, 0, 0f, 0.20f, 0f),
            new BrushPreset("Pluma (Difuminado)",           3f, 0.60f, 100, 1.0f, 1.0f, 0.20f, 0, 0.55f, 0.25f, 0f),
            new BrushPreset("Rotulador (Suave)",            3f, 0.60f, 100, 0f, 0f, 0f, 0, 0f, 0.25f, 0f),
            new BrushPreset("Rotulador (Fuerte)",           8f, 1.00f, 100, 0f, 0f, 0f, 0, 0f, 0.20f, 0f),
            new BrushPreset("Lapiz (Difuminado)",          60f, 0.10f, 100, 0f, 0f, 0f, 0, 0f, 0.25f, 0f),
            new BrushPreset("Lapiz digital",                8f, 0.95f, 100, 0.3f, 0.3f, 0f, 0, 0f, 0.20f, 0f),
            new BrushPreset("Lapiz (Grano)",                6f, 0.80f, 90, 0.2f, 0.2f, 0f, 0, 0.60f, 0.20f, 0f),
            new BrushPreset("Aerografo (Normal)",          80f, 0.05f, 60, 0f, 0f, 0f, 0, 0f, 0.20f, 0.12f),
            new BrushPreset("Aerografo (Triangulo)",        9f, 0.05f, 100, 0f, 0f, 0f, 0, 0f, 0.20f, 0f),
            new BrushPreset("Aerografo (Trapezoide 20%)",   7f, 0.20f, 100, 0f, 0f, 0f, 0, 0f, 0.20f, 0f),
            new BrushPreset("Aerografo (Trapezoide 40%)",  60f, 0.40f, 70, 0f, 0f, 0f, 0, 0f, 0.20f, 0.10f),
            new BrushPreset("Aerografo (Trapezoide 60%)",   8f, 0.60f, 100, 0f, 0f, 0f, 0, 0f, 0.20f, 0f),
            new BrushPreset("Aerografo (Particulas)",     120f, 1.00f, 100, 0f, 0f, 0f, 60, 0f, 0.35f, 0f),
            new BrushPreset("Pluma de genio",             3.5f, 1.00f, 100, 1.5f, 1.5f, 0.50f, 0, 0f, 0.20f, 0f),
            new BrushPreset("Boligrafo de tinta",           3f, 1.00f, 100, 0.5f, 0f, 0.15f, 0, 0.15f, 0.20f, 0f),
            new BrushPreset("Plumilla maru (Suave)",        3f, 0.60f, 100, 1.0f, 1.0f, 0.30f, 0, 0f, 0.25f, 0f),
            new BrushPreset("Plumilla maru (Dura)",         3f, 1.00f, 100, 1.0f, 1.0f, 0.30f, 0, 0f, 0.20f, 0f),
    };

    /** Grano de lapiz: 0..1, fijo para cada pixel (no parpadea al repasar). */
    public static float noise(int x, int y) {
        int h = x * 374761393 + y * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535f;
    }

    /** Escala del grosor por la punta: 0.15 al borde, 1 despues del largo dado. */
    public static float taper(float dist, float len) {
        if (len <= 0f || dist >= len) return 1f;
        float t = Math.max(0f, dist / len);
        t = t * t * (3f - 2f * t);
        return 0.15f + 0.85f * t;
    }

    /**
     * Muestra del trazo para la lista: usa las mismas reglas que el lienzo
     * (punta, particulas, grano, acumulacion), en blanco sobre transparente.
     */
    public Bitmap preview(int w, int h) {
        w = Math.max(1, w);
        h = Math.max(1, h);
        int[] px = new int[w * h];
        float[] cov = new float[w * h];
        // el grosor de la muestra se ajusta al alto, pero guarda las proporciones
        float r = Math.max(1.2f, Math.min(h * 0.36f, 2.2f + size * 0.14f));
        if (particles > 0) r = h * 0.42f;
        float hard = Math.max(0.05f, hardness);
        float op = opacity / 100f;
        int n = 400;
        float[] xs = new float[n], ys = new float[n], sp = new float[n];
        float total = 0f;
        for (int i = 0; i < n; i++) {
            float t = i / (float) (n - 1);
            float x = r + 2 + t * (w - 2 * r - 4);
            float y = h / 2f + (float) Math.sin(t * Math.PI * 2) * (h / 2f - r - 2) * 0.55f;
            xs[i] = x;
            ys[i] = y;
            if (i > 0) total += (float) Math.hypot(x - xs[i - 1], y - ys[i - 1]);
            sp[i] = total;
        }
        float step = Math.max(0.5f, r * spacing);
        float lenS = taperStart * r * 6f, lenE = taperEnd * r * 6f;
        Random rnd = new Random(7);
        float next = 0f;
        for (int i = 0; i < n; i++) {
            if (sp[i] < next) continue;
            next = sp[i] + step;
            float sc = taper(sp[i], lenS) * taper(total - sp[i], lenE);
            // la velocidad: en la muestra se simula un trazo que acelera en el medio
            if (speedThin > 0f) sc *= 1f - speedThin * 0.5f * (float) Math.sin(sp[i] / total * Math.PI);
            float rr = r * sc;
            if (particles > 0) {
                int cnt = Math.max(4, particles / 4);
                float dr = Math.max(0.6f, rr * 0.05f);
                for (int k = 0; k < cnt; k++) {
                    double ang = rnd.nextDouble() * Math.PI * 2, rad = Math.sqrt(rnd.nextDouble()) * rr;
                    dab(px, cov, w, h, xs[i] + (float) (Math.cos(ang) * rad), ys[i] + (float) (Math.sin(ang) * rad),
                            dr, 1f, op, 0f);
                }
            } else {
                dab(px, cov, w, h, xs[i], ys[i], rr, hard, op, flow);
            }
        }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        for (int i = 0; i < px.length; i++) {
            float a = cov[i];
            if (a <= 0f) continue;
            if (grain > 0f) a *= 1f - grain * noise(i % w, i / w);
            px[i] = (Math.min(255, Math.round(a * 255f)) << 24) | 0xFFFFFF;
        }
        b.setPixels(px, 0, w, 0, 0, w, h);
        return b;
    }

    private static void dab(int[] px, float[] cov, int w, int h, float cx, float cy, float r,
                            float hard, float op, float flow) {
        int x0 = Math.max(0, (int) (cx - r) - 1), x1 = Math.min(w, (int) (cx + r) + 2);
        int y0 = Math.max(0, (int) (cy - r) - 1), y1 = Math.min(h, (int) (cy + r) + 2);
        float inner = r * hard;
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > r) continue;
                float a = d <= inner ? 1f : 1f - (d - inner) / Math.max(0.5f, r - inner);
                a *= op;
                int i = y * w + x;
                if (flow > 0f) cov[i] = Math.min(1f, cov[i] + a * flow * (1f - cov[i]));
                else if (a > cov[i]) cov[i] = a;
            }
        }
    }
}
