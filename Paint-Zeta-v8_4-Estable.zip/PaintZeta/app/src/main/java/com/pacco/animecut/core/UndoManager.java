package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Deshacer y rehacer. Guarda solo la zona que cambio de la seleccion o de
 * una capa, y para cambios de capas (agregar, borrar, ordenar) guarda la
 * lista. Varias cosas hechas juntas se deshacen de una sola vez.
 */
public class UndoManager {

    public static final int SELECTION = 0;
    public static final int LAYER = 1;
    public static final int STRUCT = 2;

    /** Cuanto puede guardar el deshacer: una parte de la memoria del telefono. */
    private static final long BUDGET = Math.max(24L << 20, Math.min(64L << 20, Runtime.getRuntime().maxMemory() / 10));

    private static class Snap {
        int type;
        Rect r;
        Layer layer;
        byte[] bytes;
        int[] ints;
        /** Respaldo de capa ya existente. UndoManager toma propiedad y lo recicla. */
        Bitmap bitmap;
        List<Layer> list;
        int active;

        long size() {
            if (bytes != null) return bytes.length;
            if (ints != null) return ints.length * 4L;
            if (bitmap != null && !bitmap.isRecycled()) return bitmap.getAllocationByteCount();
            return 64;
        }
    }

    private static class Entry {
        String label = "";
        final List<Snap> snaps = new ArrayList<Snap>();

        long size() {
            long s = 0;
            for (Snap x : snaps) s += x.size();
            return s;
        }
    }

    private final Project p;
    private final ArrayDeque<Entry> undo = new ArrayDeque<Entry>();
    private final ArrayDeque<Entry> redo = new ArrayDeque<Entry>();
    private long used = 0;
    private String label = "";
    private Entry group;
    private String lastLabel = "";
    private boolean lastStruct = false;

    public UndoManager(Project p) {
        this.p = p;
    }

    public void setLabel(String l) {
        label = l == null ? "" : l;
    }

    public String lastLabel() {
        return lastLabel;
    }

    /** true si lo ultimo que se deshizo cambio la lista de capas. */
    public boolean lastWasStruct() {
        return lastStruct;
    }

    /** Todo lo que se registre hasta end() se deshace junto. */
    public void begin() {
        group = new Entry();
        group.label = label;
    }

    public void end() {
        Entry g = group;
        group = null;
        if (g != null && !g.snaps.isEmpty()) push(g);
    }

    public void recordSelection(Rect r) {
        add(capture(SELECTION, r, null));
    }

    public void recordLayer(Layer l, Rect r) {
        add(capture(LAYER, r, l));
    }

    public void recordStruct() {
        Snap s = new Snap();
        s.type = STRUCT;
        s.list = new ArrayList<Layer>(p.layers);
        s.active = p.active;
        add(s);
    }

    public void recordSelectionFromBackup(Rect in, byte[] backup) {
        Rect r = clamp(in);
        if (r == null || backup == null) return;
        Snap s = new Snap();
        s.type = SELECTION;
        s.r = r;
        s.bytes = copyBytes(backup, r);
        add(s);
    }

    public void recordLayerFromBackup(Layer l, Rect in, int[] backup) {
        Rect r = clamp(in);
        if (r == null || backup == null || l == null) return;
        Snap s = new Snap();
        s.type = LAYER;
        s.layer = l;
        s.r = r;
        s.ints = copyInts(backup, r);
        add(s);
    }

    /**
     * Igual que recordLayerFromBackup, pero el arreglo ya contiene SOLO el
     * rectangulo r (fila por fila). Se toma tal cual, sin volver a copiarlo.
     * Esto evita duplicar decenas de MB al confirmar Transformar.
     */
    public void recordLayerRegionBackup(Layer l, Rect in, int[] regionBackup) {
        Rect r = clamp(in);
        if (r == null || l == null || regionBackup == null) return;
        if (r.left != in.left || r.top != in.top || r.right != in.right || r.bottom != in.bottom) return;
        if (regionBackup.length != r.width() * r.height()) return;
        Snap s = new Snap();
        s.type = LAYER;
        s.layer = l;
        s.r = r;
        s.ints = regionBackup;
        add(s);
    }

    /**
     * Respaldo regional ya guardado en Bitmap. Se usa en Transformar para que
     * el Bitmap que ya existe pase directo al historial en vez de convertirlo
     * en otro int[] igual de grande. UndoManager toma propiedad del Bitmap.
     */
    public void recordLayerBitmapRegionBackup(Layer l, Rect in, Bitmap regionBackup) {
        Rect r = clamp(in);
        if (r == null || l == null || regionBackup == null || regionBackup.isRecycled()) return;
        if (r.left != in.left || r.top != in.top || r.right != in.right || r.bottom != in.bottom) return;
        if (regionBackup.getWidth() != r.width() || regionBackup.getHeight() != r.height()) return;
        Snap s = new Snap();
        s.type = LAYER;
        s.layer = l;
        s.r = r;
        s.bitmap = regionBackup;
        add(s);
    }

    /** Version compacta para la seleccion: el arreglo ya es exactamente r. */
    public void recordSelectionRegionBackup(Rect in, byte[] regionBackup) {
        Rect r = clamp(in);
        if (r == null || regionBackup == null) return;
        if (r.left != in.left || r.top != in.top || r.right != in.right || r.bottom != in.bottom) return;
        if (regionBackup.length != r.width() * r.height()) return;
        Snap s = new Snap();
        s.type = SELECTION;
        s.r = r;
        s.bytes = regionBackup;
        add(s);
    }

    private void add(Snap s) {
        if (s == null) return;
        if (group != null) {
            group.snaps.add(s);
            return;
        }
        Entry e = new Entry();
        e.label = label;
        e.snaps.add(s);
        push(e);
    }

    private void push(Entry e) {
        undo.push(e);
        used += e.size();
        for (Entry x : redo) {
            used -= x.size();
            releaseEntry(x);
        }
        redo.clear();
        while (used > BUDGET && undo.size() > 1) {
            Entry old = undo.removeLast();
            used -= old.size();
            releaseEntry(old);
        }
    }

    private static void releaseEntry(Entry e) {
        if (e == null) return;
        for (Snap s : e.snaps) {
            if (s.bitmap != null && !s.bitmap.isRecycled()) s.bitmap.recycle();
            s.bitmap = null;
        }
    }

    public boolean canUndo() {
        return !undo.isEmpty();
    }

    public boolean canRedo() {
        return !redo.isEmpty();
    }

    /** Devuelve la zona a repintar (null = todo). */
    public Rect undo() {
        return swap(undo, redo);
    }

    public Rect redo() {
        return swap(redo, undo);
    }

    private Rect swap(ArrayDeque<Entry> from, ArrayDeque<Entry> to) {
        if (from.isEmpty()) return null;
        Entry e = from.pop();
        used -= e.size();
        Entry back = new Entry();
        back.label = e.label;
        Rect dirty = null;
        boolean full = false;
        lastStruct = false;
        for (int k = e.snaps.size() - 1; k >= 0; k--) {
            Snap s = e.snaps.get(k);
            Snap now;
            if (s.type == STRUCT) {
                now = new Snap();
                now.type = STRUCT;
                now.list = new ArrayList<Layer>(p.layers);
                now.active = p.active;
                lastStruct = true;
                full = true;
            } else {
                now = capture(s.type, s.r, s.layer);
            }
            restore(s);
            // El respaldo bitmap de la entrada consumida ya no se necesitara:
            // el estado opuesto acaba de capturarse en 'now'.
            if (s.bitmap != null && !s.bitmap.isRecycled()) s.bitmap.recycle();
            s.bitmap = null;
            if (now != null) back.snaps.add(0, now);
            if (s.r != null) {
                if (dirty == null) dirty = new Rect(s.r);
                else dirty.union(s.r);
            }
        }
        to.push(back);
        used += back.size();
        lastLabel = e.label;
        p.markDirty();
        return full ? p.fullRect() : (dirty == null ? p.fullRect() : dirty);
    }

    /** Suelta lo mas viejo hasta quedar en esa parte del limite (para liberar memoria). */
    public void trimTo(float part) {
        for (Entry x : redo) {
            used -= x.size();
            releaseEntry(x);
        }
        redo.clear();
        long lim = (long) (BUDGET * part);
        while (used > lim && !undo.isEmpty()) {
            Entry old = undo.removeLast();
            used -= old.size();
            releaseEntry(old);
        }
        if (used < 0) used = 0;
    }

    public void clear() {
        for (Entry x : undo) releaseEntry(x);
        for (Entry x : redo) releaseEntry(x);
        undo.clear();
        redo.clear();
        used = 0;
    }

    private Snap capture(int type, Rect in, Layer l) {
        Rect r = clamp(in);
        if (r == null) return null;
        Snap s = new Snap();
        s.type = type;
        s.r = r;
        s.layer = l;
        if (type == SELECTION) s.bytes = copyBytes(p.selection, r);
        else s.ints = copyLayer(l, r);
        return s;
    }

    private void restore(Snap s) {
        if (s.type == STRUCT) {
            p.layers.clear();
            p.layers.addAll(s.list);
            p.active = s.active < p.layers.size() ? s.active : p.layers.size() - 1;
            return;
        }
        int rw = s.r.width(), rh = s.r.height();
        if (s.type == LAYER && s.bitmap != null && !s.bitmap.isRecycled()) {
            int[] lp = s.layer.px();
            if (lp.length == p.w * p.h) {
                s.bitmap.getPixels(lp, s.r.top * p.w + s.r.left, p.w,
                        0, 0, rw, rh);
            }
            return;
        }
        for (int y = 0; y < rh; y++) {
            int dst = (s.r.top + y) * p.w + s.r.left;
            if (s.type == SELECTION) System.arraycopy(s.bytes, y * rw, p.selection, dst, rw);
            else if (s.bitmap == null) {
                int[] lp = s.layer.px();
                if (lp.length == p.w * p.h) System.arraycopy(s.ints, y * rw, lp, dst, rw);
            }
        }
    }

    private byte[] copyBytes(byte[] src, Rect r) {
        int rw = r.width(), rh = r.height();
        byte[] out = new byte[rw * rh];
        for (int y = 0; y < rh; y++) System.arraycopy(src, (r.top + y) * p.w + r.left, out, y * rw, rw);
        return out;
    }

    private int[] copyInts(int[] src, Rect r) {
        int rw = r.width(), rh = r.height();
        int[] out = new int[rw * rh];
        for (int y = 0; y < rh; y++) System.arraycopy(src, (r.top + y) * p.w + r.left, out, y * rw, rw);
        return out;
    }

    /** Copia la zona de una capa sin desempacarla. */
    private int[] copyLayer(Layer l, Rect r) {
        int[] d = l.denseOrNull();
        if (d != null && d.length == p.w * p.h) return copyInts(d, r);
        int rw = r.width(), rh = r.height();
        int[] out = new int[rw * rh];
        l.read(r.left, r.top, rw, rh, out, p.w, p.h);
        return out;
    }

    private Rect clamp(Rect in) {
        if (in == null) return null;
        int l = Math.max(0, in.left), t = Math.max(0, in.top);
        int rr = Math.min(p.w, in.right), b = Math.min(p.h, in.bottom);
        if (l >= rr || t >= b) return null;
        return new Rect(l, t, rr, b);
    }
}
