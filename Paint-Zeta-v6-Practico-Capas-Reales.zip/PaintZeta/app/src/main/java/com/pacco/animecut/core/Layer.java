package com.pacco.animecut.core;

/**
 * Una capa = una mascara de opacidad del mismo tamano que la imagen original.
 * 1 byte por pixel (0 = transparente, 255 = opaco). Ocupa 4 veces menos
 * memoria que guardar un bitmap ARGB completo por capa.
 */
public class Layer {

    public String name;
    public boolean visible = true;
    /** Mostrar esta capa extraida sin color, sin alterar la imagen de origen. */
    public boolean grayscale = false;
    /** 0 a 255. Se aplica al exportar. */
    public int opacity = 255;
    public byte[] mask;
    /** ARGB independiente, null para proyectos antiguos basados en máscaras. */
    public int[] rasterPixels;
    public boolean alphaLock = false;

    public boolean isRaster() { return rasterPixels != null; }

    /** Conserva máscaras para miniatura/compatibilidad/exportación. */
    public void syncMask() {
        if (rasterPixels == null) return;
        if (mask == null || mask.length != rasterPixels.length) mask = new byte[rasterPixels.length];
        for (int i = 0; i < rasterPixels.length; i++) mask[i] = (byte) (rasterPixels[i] >>> 24);
    }


    public Layer(String name, byte[] mask) {
        this.name = name;
        this.mask = mask;
    }
}
