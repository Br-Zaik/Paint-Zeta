package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Guarda y abre el proyecto entero en un archivo: la imagen, la seleccion,
 * el line art y todas las capas con sus nombres.
 *
 * Por dentro es un ZIP. Las mascaras son casi todo ceros y doscientos
 * cincuenta y cinco, asi que se comprimen muchisimo y el archivo queda chico.
 */
public final class ProjectIO {

    private static final String META = "meta.txt";
    private static final String BASE = "base.png";
    private static final String SEL = "seleccion.bin";
    private static final String BAR = "lineart.bin";

    public static class Loaded {
        public Project project;
        public int color;
    }

    private ProjectIO() {
    }

    public static void save(OutputStream out, Project p, int color) throws IOException {
        ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(out));
        try {
            StringBuilder meta = new StringBuilder();
            meta.append("v3\n");
            meta.append(p.w).append(' ').append(p.h).append('\n');
            meta.append(color).append('\n');
            meta.append(p.layers.size()).append('\n');
            for (Layer l : p.layers) {
                meta.append(l.visible ? 1 : 0).append('|')
                        .append(l.opacity).append('|')
                        .append(l.grayscale ? 1 : 0).append('|')
                        .append(l.alphaLock ? 1 : 0).append('|')
                        .append(l.name.replace('|', '_').replace('\n', ' ')).append('\n');
            }
            z.putNextEntry(new ZipEntry(META));
            z.write(meta.toString().getBytes("UTF-8"));
            z.closeEntry();

            z.putNextEntry(new ZipEntry(BASE));
            p.base.compress(Bitmap.CompressFormat.PNG, 100, z);
            z.closeEntry();

            z.putNextEntry(new ZipEntry(SEL));
            z.write(p.selection);
            z.closeEntry();

            if (p.barrier != null) {
                z.putNextEntry(new ZipEntry(BAR));
                z.write(p.barrier);
                z.closeEntry();
            }

            for (int i = 0; i < p.layers.size(); i++) {
                Layer l = p.layers.get(i);
                if (l.rasterPixels != null) l.syncMask();
                z.putNextEntry(new ZipEntry(String.format(Locale.US, "capa_%03d.bin", i)));
                z.write(l.mask);
                z.closeEntry();
                if (l.rasterPixels != null) {
                    Bitmap raster = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
                    try {
                        raster.setPixels(l.rasterPixels, 0, p.w, 0, 0, p.w, p.h);
                        z.putNextEntry(new ZipEntry(String.format(Locale.US, "capa_%03d.png", i)));
                        if (!raster.compress(Bitmap.CompressFormat.PNG, 100, z))
                            throw new IOException("No se pudo guardar la capa raster");
                        z.closeEntry();
                    } finally {
                        raster.recycle();
                    }
                }
            }
            z.finish();
        } finally {
            try {
                z.close();
            } catch (IOException ignored) {
            }
        }
    }

    public static Loaded load(InputStream in) throws IOException {
        ZipInputStream z = new ZipInputStream(new BufferedInputStream(in));
        Map<String, byte[]> blobs = new HashMap<String, byte[]>();
        try {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                blobs.put(e.getName(), readAll(z));
                z.closeEntry();
            }
        } finally {
            try {
                z.close();
            } catch (IOException ignored) {
            }
        }

        byte[] metaBytes = blobs.get(META);
        byte[] baseBytes = blobs.get(BASE);
        if (metaBytes == null || baseBytes == null) {
            throw new IOException("El archivo no es un proyecto de AnimeCut");
        }

        String[] lines = new String(metaBytes, "UTF-8").split("\n");
        if (lines.length < 4) throw new IOException("Proyecto incompleto");
        int color = parse(lines[2], 0xFFE05A5A);
        int layerCount = parse(lines[3], 0);

        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inMutable = true;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap base = BitmapFactory.decodeByteArray(baseBytes, 0, baseBytes.length, o);
        if (base == null) throw new IOException("No se pudo leer la imagen del proyecto");

        Project p = new Project(base);
        int expected = p.w * p.h;

        byte[] sel = blobs.get(SEL);
        if (sel != null && sel.length == expected) {
            System.arraycopy(sel, 0, p.selection, 0, expected);
        }
        byte[] bar = blobs.get(BAR);
        if (bar != null && bar.length == expected) p.barrier = bar;

        List<String> names = new ArrayList<String>();
        List<Boolean> vis = new ArrayList<Boolean>();
        List<Integer> ops = new ArrayList<Integer>();
        List<Boolean> grays = new ArrayList<Boolean>();
        List<Boolean> locked = new ArrayList<Boolean>();
        for (int i = 0; i < layerCount && (4 + i) < lines.length; i++) {
            String line = lines[4 + i];
            String[] parts = line.split("\\|", 5);
            if (parts.length >= 5) {
                vis.add("1".equals(parts[0]));
                ops.add(parse(parts[1], 255));
                grays.add("1".equals(parts[2]));
                locked.add("1".equals(parts[3]));
                names.add(parts[4]);
            } else if (parts.length >= 4) {
                vis.add("1".equals(parts[0]));
                ops.add(parse(parts[1], 255));
                grays.add("1".equals(parts[2]));
                locked.add(false);
                names.add(parts[3]);
            } else if (parts.length >= 3) {
                vis.add("1".equals(parts[0]));
                ops.add(parse(parts[1], 255));
                grays.add(false);
                locked.add(false);
                names.add(parts[2]);
            } else if (parts.length == 2) {
                vis.add("1".equals(parts[0]));
                ops.add(255);
                grays.add(false);
                locked.add(false);
                names.add(parts[1]);
            } else {
                vis.add(Boolean.TRUE);
                ops.add(255);
                grays.add(false);
                locked.add(false);
                names.add(line);
            }
        }
        for (int i = 0; i < names.size(); i++) {
            byte[] mask = blobs.get(String.format(Locale.US, "capa_%03d.bin", i));
            if (mask == null || mask.length != expected) continue;
            Layer l = new Layer(names.get(i), mask);
            l.visible = vis.get(i);
            l.opacity = ops.get(i);
            l.grayscale = grays.get(i);
            l.alphaLock = locked.get(i);
            byte[] rasterBytes = blobs.get(String.format(Locale.US, "capa_%03d.png", i));
            if (rasterBytes != null) {
                Bitmap raster = BitmapFactory.decodeByteArray(rasterBytes, 0, rasterBytes.length);
                if (raster == null || raster.getWidth() != p.w || raster.getHeight() != p.h)
                    throw new IOException("PNG de capa dañada o tamaño incorrecto: " + i);
                l.rasterPixels = new int[expected];
                raster.getPixels(l.rasterPixels, 0, p.w, 0, 0, p.w, p.h);
                raster.recycle();
                l.syncMask();
            }
            p.layers.add(l);
        }

        Loaded r = new Loaded();
        r.project = p;
        r.color = color;
        return r;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 16);
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    private static int parse(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }
}
