package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.pacco.animecut.core.CloneStamp;
import com.pacco.animecut.core.ColorDist;
import com.pacco.animecut.core.FloodFill;
import com.pacco.animecut.core.Filters;
import com.pacco.animecut.core.GuidedFilter;
import com.pacco.animecut.core.LineArt;
import com.pacco.animecut.core.LiveWire;
import com.pacco.animecut.core.MaskOps;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.Task;
import com.pacco.animecut.core.UndoManager;

import java.util.Arrays;

/**
 * El lienzo. Dibuja una copia reducida de la imagen para ir fluido, pero
 * todas las operaciones caen sobre los pixeles a resolucion real.
 */
public class CanvasView extends View {

    public static final int MODE_PAN = 0;
    public static final int MODE_WAND = 1;
    public static final int MODE_BRUSH = 2;
    public static final int MODE_ERASER = 3;
    public static final int MODE_LASSO = 4;
    public static final int MODE_CLONE = 5;
    public static final int MODE_PAINT = 6;
    public static final int MODE_BUCKET = 7;
    public static final int MODE_PICKER = 8;
    public static final int MODE_SCISSORS = 9;
    public static final int MODE_MOVE = 10;
    public static final int MODE_ERASE_PIXELS = 11;

    public interface Callback {
        void onBusy(boolean busy);

        void onChanged();

        void onMessage(String msg);

        void onColorPicked(int color);

        void onUndoGesture();

        void onRedoGesture();
    }

    private Project project;
    private UndoManager undo;
    private Callback callback;

    private Bitmap display;
    private float dispScale = 1f;
    private Bitmap overlay;
    private int ovScale = 1;

    private final Matrix view = new Matrix();
    private final Matrix inverse = new Matrix();
    private final float[] point = new float[2];
    private ScaleGestureDetector scaleDetector;

    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ovPaint = new Paint();
    private final Paint lassoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hudText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pinEdge = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int mode = MODE_PAINT;
    private float brushRadius = 40f;
    private float hardness = 0.7f;
    private float toolOpacity = 1f;
    private int paintColor = Color.parseColor("#FFE05A5A");

    // Ajustes de la varita y del balde
    private int tolerance = 28;
    private int softness = 24;
    private int colorMode = ColorDist.RGB;
    private float expansion = 1.5f;
    private boolean gapOn = false;
    private int gapRadius = 4;
    private boolean wandGlobal = false;
    private boolean useBarrier = false;

    private boolean subtract = false;
    private boolean smart = false;
    private boolean busy = false;
    private int insetTop = 0;
    private int insetBottom = 0;

    private byte[] scratch;
    private byte[] selBackup;
    private int[] pxBackup;
    private byte[] gapBarrier;

    // portapapeles de seleccion
    private int[] clipPixels;
    private byte[] clipMask;
    private Rect clipRect;

    private boolean drawing = false;
    private boolean panning = false;
    private boolean midValid = false;
    private float lastX, lastY, lastMidX, lastMidY, lastAngle;
    private float ringX, ringY;
    private boolean showRing = false;
    private Rect strokeRect;

    private final Path lasso = new Path();
    private final Path lassoScreen = new Path();

    private boolean cloneSrcSet = false;
    private float cloneSrcX, cloneSrcY;
    private int cloneOffX, cloneOffY;

    private int refColor;
    private boolean selectionActive;
    private int painted;
    private Rect lastFillRect;

    // el toque de varita, balde y gotero se resuelve al levantar el dedo,
    // para que el gesto de dos dedos no dispare una seleccion sin querer
    private boolean pendingTap = false;
    private float tapX, tapY;

    // gestos de dos y tres dedos
    private long gestureStart;
    private int gestureMaxPointers;
    private float gestureMoved;

    // cuentagotas rapido
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean quickPick = false;
    private boolean quickArmed = false;
    private float pickX, pickY;
    private int pickColor;
    private Runnable quickRunnable;

    // tijeras inteligentes
    private LiveWire wire;
    private final Path wirePath = new Path();
    private final Path wireScreen = new Path();
    private int[] livePath;
    private int firstAnchor = -1;
    private boolean wireStarted = false;
    private final Paint wirePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // mover la seleccion
    private byte[] moveBackup;
    private float moveFromX, moveFromY;
    private int moveDx, moveDy;

    private Layer activeLayer;
    private int[] moveRasterBackup;
    private boolean movingLayer;
    private Layer isolatedLayer;
    private Bitmap isolationDisplay;
    private Bitmap checkerDisplay;
    private Bitmap layersDisplay;
    private boolean showBase = true;
    private float stabilizer = 0f;
    private float smoothX, smoothY;
    private boolean smoothInit = false;

    // vista previa de gama de colores
    private byte[] previewBackup;

    // aviso flotante
    private String hud;
    private long hudUntil;

    public CanvasView(Context c) {
        super(c);
        init(c);
    }

    public CanvasView(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    private void init(Context c) {
        ovPaint.setFilterBitmap(false);
        lassoPaint.setStyle(Paint.Style.STROKE);
        lassoPaint.setColor(Color.parseColor("#FF3D7BFF"));
        lassoPaint.setStrokeWidth(3f);
        markPaint.setStyle(Paint.Style.STROKE);
        markPaint.setColor(Color.parseColor("#FFFF5252"));
        markPaint.setStrokeWidth(3f);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(Color.parseColor("#CCFFFFFF"));
        ringPaint.setStrokeWidth(2f);
        wirePaint.setStyle(Paint.Style.STROKE);
        wirePaint.setColor(Color.parseColor("#FF32D74B"));
        wirePaint.setStrokeWidth(3f);
        hudBg.setColor(Color.parseColor("#CC000000"));
        hudText.setColor(Color.WHITE);
        hudText.setTextSize(getResources().getDisplayMetrics().density * 14f);
        hudText.setTextAlign(Paint.Align.CENTER);
        pinEdge.setColor(Color.parseColor("#FFF0F0F0"));
        pinFill.setStyle(Paint.Style.FILL);

        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float f = d.getScaleFactor();
                float cur = currentScale();
                if (cur * f < 0.03f || cur * f > 60f) return true;
                view.postScale(f, f, d.getFocusX(), d.getFocusY());
                showHud(Math.round(currentScale() * dispScale * 100f) + "%");
                return true;
            }
        });
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    public void setProject(Project p) {
        this.project = p;
        isolatedLayer = null;
        activeLayer = null;
        moveRasterBackup = null;
        showBase = true;
        if (isolationDisplay != null) { isolationDisplay.recycle(); isolationDisplay = null; }
        if (layersDisplay != null) { layersDisplay.recycle(); layersDisplay = null; }
        if (checkerDisplay != null) { checkerDisplay.recycle(); checkerDisplay = null; }
        this.undo = p == null ? null : new UndoManager(p);
        this.scratch = null;
        this.selBackup = null;
        this.pxBackup = null;
        this.gapBarrier = null;
        this.cloneSrcSet = false;
        lasso.reset();
        if (p != null) {
            buildDisplay();
            buildOverlay();
            post(new Runnable() {
                @Override
                public void run() {
                    fit();
                }
            });
        }
        invalidate();
    }

    public Project getProject() {
        return project;
    }

    public Layer getActiveLayer() { return activeLayer; }

    public void setActiveLayer(Layer layer) {
        if (layer != null && (project == null || !project.layers.contains(layer))) return;
        activeLayer = layer;
        isolateLayer(null);
        showHud(layer == null ? "Editando fondo" : "Editando: " + layer.name);
        invalidate();
    }

    public void setMode(int m) {
        if (mode == MODE_SCISSORS && m != MODE_SCISSORS) scissorsReset();
        mode = m;
        invalidate();
    }

    public boolean isScissorsActive() {
        return wireStarted;
    }

    public int getMode() {
        return mode;
    }

    // ---- ajustes de la varita ----

    public void setTolerance(int t) {
        tolerance = t;
    }

    public int getTolerance() {
        return tolerance;
    }

    public void setSoftness(int s) {
        softness = Math.max(0, s);
    }

    public int getSoftness() {
        return softness;
    }

    public void setColorMode(int m) {
        colorMode = m;
    }

    public int getColorMode() {
        return colorMode;
    }

    public void setExpansion(float px) {
        expansion = px;
    }

    public float getExpansion() {
        return expansion;
    }

    public void setGap(boolean on, int radius) {
        gapOn = on;
        gapRadius = Math.max(1, radius);
        gapBarrier = null;
    }

    public boolean isGapOn() {
        return gapOn;
    }

    public int getGapRadius() {
        return gapRadius;
    }

    public void setBrushSize(float px) {
        brushRadius = Math.max(0.5f, px / 2f);
    }

    public float getBrushSize() {
        return brushRadius * 2f;
    }

    public void setHardness(float h) {
        hardness = Math.max(0.05f, Math.min(1f, h));
    }

    public void setToolOpacity(float opacity) {
        toolOpacity = Math.max(0.01f, Math.min(1f, opacity));
    }

    public float getToolOpacity() {
        return toolOpacity;
    }

    public void setColor(int c) {
        paintColor = c;
    }

    public int getColor() {
        return paintColor;
    }

    public void setWandGlobal(boolean g) {
        wandGlobal = g;
    }

    public boolean isWandGlobal() {
        return wandGlobal;
    }

    public void setUseBarrier(boolean b) {
        useBarrier = b;
    }

    public boolean isUseBarrier() {
        return useBarrier;
    }

    public void setSubtract(boolean s) {
        subtract = s;
    }

    public boolean isSubtract() {
        return subtract;
    }

    public void setSmart(boolean s) {
        smart = s;
    }

    public boolean isSmart() {
        return smart;
    }

    public boolean hasClipboard() {
        return clipPixels != null;
    }

    public void resetCloneSource() {
        cloneSrcSet = false;
        invalidate();
        msg("Toca el punto de donde quieres copiar");
    }

    // ------------------------------------------------------------------
    // Render
    // ------------------------------------------------------------------

    private void buildDisplay() {
        Bitmap old = display;
        int max = Math.max(project.w, project.h);
        float s = max > 2048 ? max / 2048f : 1f;
        int dw = Math.max(1, Math.round(project.w / s));
        int dh = Math.max(1, Math.round(project.h / s));
        Bitmap scaled = Bitmap.createScaledBitmap(project.base, dw, dh, true);
        if (scaled == project.base) scaled = project.base.copy(Bitmap.Config.ARGB_8888, true);
        display = scaled;
        dispScale = (float) project.w / dw;
        if (old != null && old != project.base && !old.isRecycled()) old.recycle();
        if (checkerDisplay != null && !checkerDisplay.isRecycled()) checkerDisplay.recycle();
        checkerDisplay = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        int[] checks = new int[dw];
        for (int y = 0; y < dh; y++) {
            for (int x = 0; x < dw; x++) {
                checks[x] = (((x / 12) + (y / 12)) & 1) == 0 ? 0xFFB8B8B8 : 0xFFE6E6E6;
            }
            checkerDisplay.setPixels(checks, 0, dw, 0, y, dw, 1);
        }
        refreshLayersPreview();
    }

    public boolean isBaseVisible() { return showBase; }

    public void setBaseVisible(boolean show) {
        showBase = show;
        refreshLayersPreview();
        invalidate();
    }

    /** Composicion visual de capas extraidas; base en blanco transparente si se oculta el fondo. */
    public void refreshLayersPreview() {
        if (layersDisplay != null && !layersDisplay.isRecycled()) layersDisplay.recycle();
        layersDisplay = null;
        if (project == null || display == null || project.layers.isEmpty()) {
            invalidate(); return;
        }
        int w = display.getWidth(), h = display.getHeight();
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            int sy = Math.min(project.h - 1, (int)(y * dispScale));
            for (int x = 0; x < w; x++) {
                int sx = Math.min(project.w - 1, (int)(x * dispScale));
                int i = sy * project.w + sx;
                int source = project.pixels[i];
                int out = 0;
                for (Layer l : project.layers) {
                    if (!l.visible) continue;
                    int col = l.rasterPixels == null ? source : l.rasterPixels[i];
                    int a = (l.rasterPixels == null ? (l.mask[i] & 255) : (col >>> 24)) * l.opacity / 255;
                    if (a <= 0) continue;
                    // Las capas v1 eran solo mascaras extraidas; no tapar toda la foto duplicandola.
                    if (l.rasterPixels == null && showBase) continue;
                    if (l.grayscale) {
                        int g = (((col >> 16) & 255) * 77 + ((col >> 8) & 255) * 150 + (col & 255) * 29 + 128) >> 8;
                        col = (col & 0xFF000000) | (g << 16) | (g << 8) | g;
                    }
                    int da = (out >>> 24);
                    int oa = a + da * (255 - a) / 255;
                    if (oa == 0) continue;
                    int r = (((col >> 16) & 255) * a * 255 + ((out >> 16) & 255) * da * (255 - a)) / (oa * 255);
                    int g = (((col >> 8) & 255) * a * 255 + ((out >> 8) & 255) * da * (255 - a)) / (oa * 255);
                    int bl = ((col & 255) * a * 255 + (out & 255) * da * (255 - a)) / (oa * 255);
                    out = (oa << 24) | (Math.min(255,r) << 16) | (Math.min(255,g) << 8) | Math.min(255,bl);
                }
                row[x] = out;
            }
            b.setPixels(row, 0, w, 0, y, w, 1);
        }
        layersDisplay = b;
        invalidate();
    }

    private void updateLayerDisplayRegion(Rect r) {
        if (project == null || layersDisplay == null) {
            refreshLayersPreview(); return;
        }
        int dw = layersDisplay.getWidth(), dh = layersDisplay.getHeight();
        int x0 = Math.max(0, (int) (r.left / dispScale));
        int y0 = Math.max(0, (int) (r.top / dispScale));
        int x1 = Math.min(dw, (int) Math.ceil(r.right / dispScale) + 1);
        int y1 = Math.min(dh, (int) Math.ceil(r.bottom / dispScale) + 1);
        int[] row = new int[Math.max(1, x1 - x0)];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, (int) (y * dispScale));
            for (int x = x0; x < x1; x++) {
                int sx = Math.min(project.w - 1, (int) (x * dispScale));
                int i = sy * project.w + sx;
                int out = 0;
                for (Layer l : project.layers) {
                    if (!l.visible || (l.rasterPixels == null && showBase)) continue;
                    int col = l.rasterPixels != null ? l.rasterPixels[i] : project.pixels[i];
                    int a = (l.rasterPixels == null ? (l.mask[i] & 255) : (col >>> 24)) * l.opacity / 255;
                    if (a <= 0) continue;
                    if (l.grayscale) {
                        int g = (((col >> 16) & 255) * 77 + ((col >> 8) & 255) * 150 + (col & 255) * 29 + 128) >> 8;
                        col = (col & 0xFF000000) | (g << 16) | (g << 8) | g;
                    }
                    int da = out >>> 24;
                    int oa = a + da * (255 - a) / 255;
                    if (oa == 0) continue;
                    int rr = (((col >> 16) & 255) * a * 255 + ((out >> 16) & 255) * da * (255-a)) / (oa*255);
                    int gg = (((col >> 8) & 255) * a * 255 + ((out >> 8) & 255) * da * (255-a)) / (oa*255);
                    int bb = ((col & 255) * a * 255 + (out & 255) * da * (255-a)) / (oa*255);
                    out = (oa<<24)|(Math.min(255,rr)<<16)|(Math.min(255,gg)<<8)|Math.min(255,bb);
                }
                row[x-x0] = out;
            }
            layersDisplay.setPixels(row, 0, row.length, x0, y, row.length, 1);
        }
        invalidate();
    }

    /** Previsualiza una capa real de extraccion sobre transparencia; tocar "Todas" devuelve la imagen. */
    public void isolateLayer(Layer layer) {
        if (isolationDisplay != null && !isolationDisplay.isRecycled()) isolationDisplay.recycle();
        isolationDisplay = null;
        isolatedLayer = layer;
        if (layer != null && project != null) {
            final int w = display.getWidth(), h = display.getHeight();
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            int[] row = new int[w];
            for (int y = 0; y < h; y++) {
                int sy = Math.min(project.h - 1, (int) (y * dispScale));
                for (int x = 0; x < w; x++) {
                    int sx = Math.min(project.w - 1, (int) (x * dispScale));
                    int i = sy * project.w + sx;
                    int c = layer.rasterPixels == null ? project.pixels[i] : layer.rasterPixels[i];
                    int alpha = (layer.rasterPixels == null ? (layer.mask[i] & 255) : (c >>> 24)) * layer.opacity / 255;
                    if (layer.grayscale) {
                        int g = (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 150 + (c & 255) * 29 + 128) >> 8;
                        c = (c & 0xFF000000) | (g << 16) | (g << 8) | g;
                    }
                    row[x] = (alpha << 24) | (c & 0xFFFFFF);
                }
                b.setPixels(row, 0, w, 0, y, w, 1);
            }
            isolationDisplay = b;
        }
        invalidate();
    }

    public Layer getIsolatedLayer() { return isolatedLayer; }

    public void refreshDisplay() {
        if (project == null) return;
        buildDisplay();
        if (isolatedLayer != null) isolateLayer(isolatedLayer);
        invalidate();
    }

    private void buildOverlay() {
        if (overlay != null) overlay.recycle();
        int max = Math.max(project.w, project.h);
        ovScale = max > 1440 ? (int) Math.ceil(max / 1440f) : 1;
        int ow = Math.max(1, project.w / ovScale);
        int oh = Math.max(1, project.h / ovScale);
        overlay = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
        paintOverlay(new Rect(0, 0, project.w, project.h));
    }

    private void paintOverlay(Rect r) {
        if (overlay == null || project == null) return;
        int ow = overlay.getWidth();
        int oh = overlay.getHeight();
        int x0 = Math.max(0, r.left / ovScale);
        int y0 = Math.max(0, r.top / ovScale);
        int x1 = Math.min(ow, r.right / ovScale + 1);
        int y1 = Math.min(oh, r.bottom / ovScale + 1);
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, y * ovScale);
            int base = sy * project.w;
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (x0 + i) * ovScale);
                int a = project.selection[base + sx] & 0xFF;
                row[i] = a == 0 ? 0 : (((a * 150) / 255) << 24) | 0x0080FF;
            }
            overlay.setPixels(row, 0, rw, x0, y, rw, 1);
        }
    }

    public void refreshOverlay(Rect r) {
        if (project == null) return;
        if (r == null) r = new Rect(0, 0, project.w, project.h);
        paintOverlay(r);
        invalidate();
    }

    public void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
    }

    public void fit() {
        if (project == null || getWidth() == 0) return;
        int usable = getHeight() - insetTop - insetBottom;
        if (usable < 80) usable = getHeight();
        float sx = (float) getWidth() / project.w;
        float sy = (float) usable / project.h;
        float s = Math.min(sx, sy) * 0.96f;
        view.reset();
        view.postScale(s, s);
        view.postTranslate((getWidth() - project.w * s) / 2f,
                insetTop + (usable - project.h * s) / 2f);
        invalidate();
    }

    private float currentScale() {
        float[] v = new float[9];
        view.getValues(v);
        float a = v[Matrix.MSCALE_X];
        float b = v[Matrix.MSKEW_X];
        return (float) Math.sqrt(a * a + b * b);
    }

    public void showHud(String text) {
        hud = text;
        hudUntil = System.currentTimeMillis() + 900;
        invalidate();
        postInvalidateDelayed(950);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(Color.parseColor("#FF121212"));
        if (project == null || display == null) return;

        float shown = currentScale() * dispScale;
        bmpPaint.setFilterBitmap(shown < 1f);

        c.save();
        c.concat(view);
        c.scale(dispScale, dispScale);
        if (checkerDisplay != null) c.drawBitmap(checkerDisplay, 0, 0, bmpPaint);
        if (isolatedLayer != null) {
            if (isolationDisplay != null) c.drawBitmap(isolationDisplay, 0, 0, bmpPaint);
        } else {
            if (showBase) c.drawBitmap(display, 0, 0, bmpPaint);
            if (layersDisplay != null) c.drawBitmap(layersDisplay, 0, 0, bmpPaint);
        }
        c.restore();

        if (overlay != null && isolatedLayer == null) {
            c.save();
            c.concat(view);
            c.scale(ovScale, ovScale);
            c.drawBitmap(overlay, 0, 0, ovPaint);
            c.restore();
        }

        if (mode == MODE_LASSO && !lasso.isEmpty()) {
            lassoScreen.reset();
            lasso.transform(view, lassoScreen);
            c.drawPath(lassoScreen, lassoPaint);
        }

        if (mode == MODE_SCISSORS) {
            wireScreen.reset();
            wirePath.transform(view, wireScreen);
            c.drawPath(wireScreen, wirePaint);
            if (livePath != null && livePath.length > 1) {
                Path p = new Path();
                for (int i = 0; i < livePath.length; i += 2) {
                    int idx = livePath[i];
                    int y = idx / project.w;
                    int x = idx - y * project.w;
                    if (i == 0) p.moveTo(x, y);
                    else p.lineTo(x, y);
                }
                Path sp = new Path();
                p.transform(view, sp);
                c.drawPath(sp, wirePaint);
            }
            if (firstAnchor >= 0) {
                int y = firstAnchor / project.w;
                int x = firstAnchor - y * project.w;
                point[0] = x;
                point[1] = y;
                view.mapPoints(point);
                c.drawCircle(point[0], point[1], 16f, wirePaint);
            }
        }

        if (mode == MODE_CLONE && cloneSrcSet) {
            point[0] = cloneSrcX;
            point[1] = cloneSrcY;
            view.mapPoints(point);
            c.drawCircle(point[0], point[1], 22f, markPaint);
            c.drawLine(point[0] - 30, point[1], point[0] + 30, point[1], markPaint);
            c.drawLine(point[0], point[1] - 30, point[0], point[1] + 30, markPaint);
        }

        if (showRing && usesBrush() && !quickPick) {
            c.drawCircle(ringX, ringY, brushRadius * currentScale(), ringPaint);
        }

        if (quickPick) drawPin(c);

        if (hud != null && System.currentTimeMillis() < hudUntil) {
            float pad = 14f * getResources().getDisplayMetrics().density;
            float tw = hudText.measureText(hud);
            float cx = getWidth() / 2f;
            float top = insetTop + pad;
            c.drawRoundRect(new RectF(cx - tw / 2 - pad, top, cx + tw / 2 + pad, top + pad * 2.6f),
                    12f, 12f, hudBg);
            c.drawText(hud, cx, top + pad * 1.8f, hudText);
        }
    }

    /** Burbuja del cuentagotas, desplazada para no tapar el punto. */
    private void drawPin(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float r = 34f * d;
        float cx = pickX;
        float cy = pickY - r * 1.8f;
        pinFill.setColor(pickColor);
        pinEdge.setStyle(Paint.Style.STROKE);
        pinEdge.setStrokeWidth(4f * d);
        c.drawCircle(cx, cy, r, pinFill);
        c.drawCircle(cx, cy, r, pinEdge);
        Path tip = new Path();
        tip.moveTo(cx - r * 0.42f, cy + r * 0.86f);
        tip.lineTo(cx, cy + r * 1.9f);
        tip.lineTo(cx + r * 0.42f, cy + r * 0.86f);
        tip.close();
        pinEdge.setStyle(Paint.Style.FILL);
        c.drawPath(tip, pinEdge);
        pinFill.setColor(pickColor);
        c.drawCircle(cx, cy, r - 3f * d, pinFill);
    }

    private boolean usesBrush() {
        return mode == MODE_BRUSH || mode == MODE_ERASER || mode == MODE_CLONE || mode == MODE_PAINT || mode == MODE_ERASE_PIXELS;
    }

    // ------------------------------------------------------------------
    // Toque
    // ------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (project == null || busy) return true;
        int action = e.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            gestureStart = System.currentTimeMillis();
            gestureMaxPointers = 1;
            gestureMoved = 0f;
        }
        if (action == MotionEvent.ACTION_POINTER_DOWN) {
            gestureMaxPointers = Math.max(gestureMaxPointers, e.getPointerCount());
        }

        if (e.getPointerCount() >= 2) {
            pendingTap = false;
            cancelQuickTimer();
            if (quickPick) endQuickPick(false);
            if (drawing) cancelStroke();
            panning = false;
            showRing = false;
            scaleDetector.onTouchEvent(e);
            handleTwoFingers(e);
            if (action == MotionEvent.ACTION_POINTER_UP) checkTapGesture(e);
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                midValid = false;
                ringX = e.getX();
                ringY = e.getY();
                pickX = e.getX();
                pickY = e.getY();
                showRing = usesBrush();
                armQuickPick();
                if (isTapTool()) {
                    pendingTap = true;
                    tapX = e.getX();
                    tapY = e.getY();
                    return true;
                }
                if (mode == MODE_PAN) {
                    panning = true;
                    lastX = e.getX();
                    lastY = e.getY();
                } else {
                    startStroke(e.getX(), e.getY());
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                gestureMoved += Math.abs(e.getX() - ringX) + Math.abs(e.getY() - ringY);
                ringX = e.getX();
                ringY = e.getY();
                if (quickPick) {
                    updateQuickPick(e.getX(), e.getY());
                    return true;
                }
                if (gestureMoved > 24f) {
                    cancelQuickTimer();
                    pendingTap = false;
                }
                if (panning) {
                    view.postTranslate(e.getX() - lastX, e.getY() - lastY);
                    lastX = e.getX();
                    lastY = e.getY();
                    invalidate();
                } else if (drawing) {
                    moveStroke(e.getX(), e.getY());
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cancelQuickTimer();
                if (quickPick) {
                    endQuickPick(action == MotionEvent.ACTION_UP);
                } else if (pendingTap && action == MotionEvent.ACTION_UP) {
                    pendingTap = false;
                    runTapTool(tapX, tapY);
                } else if (drawing) {
                    endStroke();
                }
                pendingTap = false;
                checkTapGesture(e);
                panning = false;
                midValid = false;
                showRing = false;
                invalidate();
                return true;
        }
        return true;
    }

    private boolean isTapTool() {
        return mode == MODE_WAND || mode == MODE_BUCKET || mode == MODE_PICKER;
    }

    private void runTapTool(float sx, float sy) {
        toImage(sx, sy);
        int px = (int) point[0];
        int py = (int) point[1];
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;
        if (!inside) return;
        if (mode == MODE_WAND) {
            runWand(px, py);
        } else if (mode == MODE_BUCKET) {
            runBucket(px, py);
        } else {
            paintColor = project.pixels[py * project.w + px] | 0xFF000000;
            if (callback != null) callback.onColorPicked(paintColor);
        }
    }

    /** Dos dedos = deshacer, tres dedos = rehacer, como en Ibis. */
    private void checkTapGesture(MotionEvent e) {
        if (callback == null) return;
        long dur = System.currentTimeMillis() - gestureStart;
        if (dur > 260 || gestureMoved > 30f) return;
        if (gestureMaxPointers == 2) {
            gestureMaxPointers = 0;
            callback.onUndoGesture();
        } else if (gestureMaxPointers >= 3) {
            gestureMaxPointers = 0;
            callback.onRedoGesture();
        }
    }

    private void handleTwoFingers(MotionEvent e) {
        float mx = (e.getX(0) + e.getX(1)) / 2f;
        float my = (e.getY(0) + e.getY(1)) / 2f;
        float angle = (float) Math.toDegrees(Math.atan2(
                e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)));
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_POINTER_DOWN || !midValid) {
            lastMidX = mx;
            lastMidY = my;
            lastAngle = angle;
            midValid = true;
        } else if (a == MotionEvent.ACTION_MOVE) {
            view.postTranslate(mx - lastMidX, my - lastMidY);
            float da = angle - lastAngle;
            while (da > 180f) da -= 360f;
            while (da < -180f) da += 360f;
            if (Math.abs(da) > 0.4f) view.postRotate(da, mx, my);
            lastMidX = mx;
            lastMidY = my;
            lastAngle = angle;
            gestureMoved += 10f;
            invalidate();
        }
        if (a == MotionEvent.ACTION_POINTER_UP) midValid = false;
    }

    // ---- cuentagotas rapido ----

    private void armQuickPick() {
        cancelQuickTimer();
        quickArmed = true;
        quickRunnable = new Runnable() {
            @Override
            public void run() {
                if (!quickArmed || project == null) return;
                if (drawing) cancelStroke();
                panning = false;
                quickPick = true;
                updateQuickPick(pickX, pickY);
            }
        };
        handler.postDelayed(quickRunnable, 550);
    }

    private void cancelQuickTimer() {
        quickArmed = false;
        if (quickRunnable != null) handler.removeCallbacks(quickRunnable);
    }

    private void updateQuickPick(float sx, float sy) {
        pickX = sx;
        pickY = sy;
        toImage(sx, sy);
        int x = (int) point[0];
        int y = (int) point[1];
        if (x >= 0 && y >= 0 && x < project.w && y < project.h) {
            pickColor = project.pixels[y * project.w + x] | 0xFF000000;
        }
        invalidate();
    }

    private void endQuickPick(boolean apply) {
        quickPick = false;
        if (apply) {
            paintColor = pickColor;
            if (callback != null) callback.onColorPicked(paintColor);
        }
        invalidate();
    }

    private void toImage(float x, float y) {
        view.invert(inverse);
        point[0] = x;
        point[1] = y;
        inverse.mapPoints(point);
    }

    // ------------------------------------------------------------------
    // Trazos
    // ------------------------------------------------------------------

    private void startStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0];
        float iy = point[1];
        int px = (int) ix;
        int py = (int) iy;
        boolean inside = px >= 0 && py >= 0 && px < project.w && py < project.h;

        switch (mode) {
            case MODE_WAND:
                cancelQuickTimer();
                runWand(px, py);
                return;

            case MODE_PICKER:
                cancelQuickTimer();
                if (inside) {
                    paintColor = project.pixels[py * project.w + px] | 0xFF000000;
                    if (callback != null) callback.onColorPicked(paintColor);
                }
                return;

            case MODE_BUCKET:
                cancelQuickTimer();
                runBucket(px, py);
                return;

            case MODE_BRUSH:
            case MODE_ERASER:
                ensureSelBackup();
                System.arraycopy(project.selection, 0, selBackup, 0, selBackup.length);
                refColor = inside ? project.pixels[py * project.w + px] : 0;
                strokeRect = null;
                drawing = true;
                stampBrush(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_PAINT:
            case MODE_ERASE_PIXELS:
                ensurePxBackup();
                int[] pixelsToEdit = activeLayer != null && activeLayer.rasterPixels != null
                        ? activeLayer.rasterPixels : project.pixels;
                System.arraycopy(pixelsToEdit, 0, pxBackup, 0, pxBackup.length);
                selectionActive = project.hasSelection();
                painted = 0;
                strokeRect = null;
                drawing = true;
                stampPaint(ix, iy);
                lastX = ix;
                lastY = iy;
                return;

            case MODE_SCISSORS:
                cancelQuickTimer();
                if (!inside) return;
                drawing = true;
                if (!wireStarted) {
                    wireStarted = true;
                    firstAnchor = py * project.w + px;
                    wirePath.reset();
                    wirePath.moveTo(px, py);
                    setAnchorAsync(px, py);
                    msg("Arrastra siguiendo el contorno y suelta para fijar");
                }
                return;

            case MODE_MOVE:
                cancelQuickTimer();
                movingLayer = !project.hasSelection() && activeLayer != null && activeLayer.rasterPixels != null;
                if (movingLayer) {
                    try { moveRasterBackup = activeLayer.rasterPixels.clone(); }
                    catch (OutOfMemoryError oom) { msg("No hay memoria para mover esta capa"); movingLayer = false; return; }
                } else {
                    ensureSelBackup();
                    System.arraycopy(project.selection, 0, selBackup, 0, selBackup.length);
                    moveBackup = selBackup;
                }
                moveFromX = ix;
                moveFromY = iy;
                moveDx = 0;
                moveDy = 0;
                drawing = true;
                return;

            case MODE_LASSO:
                lasso.reset();
                lasso.moveTo(ix, iy);
                drawing = true;
                lastX = ix;
                lastY = iy;
                invalidate();
                return;

            case MODE_CLONE:
                if (!cloneSrcSet) {
                    cancelQuickTimer();
                    cloneSrcX = ix;
                    cloneSrcY = iy;
                    cloneSrcSet = true;
                    msg("Origen fijado. Ahora arrastra donde quieres copiarlo");
                    invalidate();
                    return;
                }
                ensurePxBackup();
                System.arraycopy(project.pixels, 0, pxBackup, 0, pxBackup.length);
                cloneOffX = (int) (ix - cloneSrcX);
                cloneOffY = (int) (iy - cloneSrcY);
                strokeRect = null;
                drawing = true;
                stampClone(ix, iy);
                lastX = ix;
                lastY = iy;
                return;
        }
    }

    private void moveStroke(float sx, float sy) {
        toImage(sx, sy);
        float ix = point[0];
        float iy = point[1];

        if (mode == MODE_LASSO) {
            lasso.lineTo(ix, iy);
            invalidate();
            return;
        }

        if (mode == MODE_SCISSORS) {
            if (wire != null && wire.hasAnchor()) {
                livePath = wire.pathTo((int) ix, (int) iy);
                invalidate();
            }
            return;
        }

        if (mode == MODE_MOVE) {
            moveDx = (int) (ix - moveFromX);
            moveDy = (int) (iy - moveFromY);
            if (movingLayer) showHud("Mover capa: " + moveDx + ", " + moveDy + " px");
            else shiftSelection(moveDx, moveDy);
            return;
        }

        if (stabilizer > 0f) {
            if (!smoothInit) {
                smoothX = ix;
                smoothY = iy;
                smoothInit = true;
            }
            smoothX = smoothX * stabilizer + ix * (1f - stabilizer);
            smoothY = smoothY * stabilizer + iy * (1f - stabilizer);
            ix = smoothX;
            iy = smoothY;
        }

        float dx = ix - lastX;
        float dy = iy - lastY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float step = Math.max(0.6f, brushRadius * 0.3f);
        int n = (int) (dist / step);
        for (int i = 1; i <= n; i++) {
            float t = i / (float) n;
            float bx = lastX + dx * t;
            float by = lastY + dy * t;
            if (mode == MODE_CLONE) stampClone(bx, by);
            else if (mode == MODE_PAINT || mode == MODE_ERASE_PIXELS) stampPaint(bx, by);
            else stampBrush(bx, by);
        }
        if (n > 0) {
            lastX = ix;
            lastY = iy;
        }
        invalidate();
    }

    private void endStroke() {
        drawing = false;
        smoothInit = false;
        if (mode == MODE_LASSO) {
            applyLasso();
            return;
        }
        if (mode == MODE_SCISSORS) {
            commitWire();
            return;
        }
        if (mode == MODE_MOVE) {
            if (moveDx != 0 || moveDy != 0) {
                if (movingLayer && moveRasterBackup != null && activeLayer != null) {
                    undo.setLabel("Mover capa");
                    int[] shifted = new int[moveRasterBackup.length];
                    int w = project.w, h = project.h;
                    for (int sy = Math.max(0, -moveDy); sy < Math.min(h, h - moveDy); sy++) {
                        int srcX = Math.max(0, -moveDx), dstX = Math.max(0, moveDx);
                        int len = w - Math.abs(moveDx);
                        if (len > 0) System.arraycopy(moveRasterBackup, sy*w+srcX,
                                shifted, (sy+moveDy)*w+dstX, len);
                    }
                    undo.recordLayerFromBackup(activeLayer, project.fullRect(), moveRasterBackup);
                    activeLayer.rasterPixels = shifted;
                    activeLayer.syncMask();
                    refreshLayersPreview();
                    changed();
                } else if (!movingLayer) {
                    undo.setLabel("Mover seleccion");
                    undo.recordFromBackup(UndoManager.SELECTION, project.fullRect(), moveBackup, null);
                    changed();
                }
            }
            moveBackup = null;
            moveRasterBackup = null;
            movingLayer = false;
            return;
        }
        if (mode == MODE_PAINT && painted == 0 && selectionActive) {
            msg("Hay una seleccion activa: solo se pinta dentro de lo azul. Usa Limpiar para pintar libre.");
        }
        if (strokeRect != null) {
            undo.setLabel(mode == MODE_PAINT ? "Pincelada"
                    : mode == MODE_ERASE_PIXELS ? "Borrar imagen"
                    : mode == MODE_CLONE ? "Clonar"
                    : mode == MODE_ERASER ? "Borrador" : "Pincel");
            if (mode == MODE_CLONE || mode == MODE_PAINT || mode == MODE_ERASE_PIXELS) {
                if (activeLayer != null && activeLayer.rasterPixels != null && mode != MODE_CLONE)
                    undo.recordLayerFromBackup(activeLayer, strokeRect, pxBackup);
                else undo.recordFromBackup(UndoManager.PIXELS, strokeRect, null, pxBackup);
            } else {
                undo.recordFromBackup(UndoManager.SELECTION, strokeRect, selBackup, null);
            }
            changed();
        }
        strokeRect = null;
    }

    /** Deshace el trazo en curso sin tocar el historial. */
    private void cancelStroke() {
        if (!drawing) return;
        drawing = false;
        if (strokeRect == null) {
            lasso.reset();
            moveRasterBackup = null;
            movingLayer = false;
            return;
        }
        Rect r = strokeRect;
        strokeRect = null;
        if (mode == MODE_CLONE || mode == MODE_PAINT || mode == MODE_ERASE_PIXELS) {
            int[] target = activeLayer != null && activeLayer.rasterPixels != null && mode != MODE_CLONE
                    ? activeLayer.rasterPixels : project.pixels;
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(pxBackup, y * project.w + r.left,
                        target, y * project.w + r.left, r.width());
            }
            if (target == project.pixels) { project.pushPixels(r); updateDisplayRegion(r); }
            else { activeLayer.syncMask(); updateLayerDisplayRegion(r); }
        } else if (mode == MODE_BRUSH || mode == MODE_ERASER) {
            for (int y = r.top; y < r.bottom; y++) {
                System.arraycopy(selBackup, y * project.w + r.left,
                        project.selection, y * project.w + r.left, r.width());
            }
            paintOverlay(r);
        }
        lasso.reset();
        invalidate();
    }

    private void stampBrush(float cx, float cy) {
        Rect r = smart ? smartSelectStamp(cx, cy)
                : MaskOps.stamp(project.selection, project.w, project.h, cx, cy,
                brushRadius, hardness, mode == MODE_ERASER, toolOpacity);
        if (r == null) return;
        grow(r);
        paintOverlay(r);
        invalidate();
    }

    private Rect smartSelectStamp(float cx, float cy) {
        int w = project.w;
        int h = project.h;
        int x0 = (int) Math.floor(cx - brushRadius) - 1;
        int y0 = (int) Math.floor(cy - brushRadius) - 1;
        int x1 = (int) Math.ceil(cx + brushRadius) + 1;
        int y1 = (int) Math.ceil(cy + brushRadius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return null;

        boolean erase = mode == MODE_ERASER;
        float inner = brushRadius * hardness;
        float band = Math.max(1f, brushRadius - inner);
        int limit = tolerance + softness;

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > brushRadius) continue;
                int i = row + x;
                int cap = 255;
                if (!erase) {
                    if (project.barrier != null && useBarrier && project.barrier[i] != 0) continue;
                    int cd = ColorDist.dist(project.pixels[i], refColor, colorMode);
                    if (cd > limit) continue;
                    if (cd > tolerance && softness > 0) {
                        cap = 255 - ((cd - tolerance) * 255) / softness;
                    }
                }
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                if (a <= 0f) continue;
                int cur = project.selection[i] & 0xFF;
                int add = (int) (a * cap * toolOpacity);
                if (erase) {
                    int v = cur - (int) (a * 255f * toolOpacity);
                    project.selection[i] = (byte) (v < 0 ? 0 : v);
                } else if (add > cur) {
                    project.selection[i] = (byte) add;
                }
            }
        }
        return new Rect(x0, y0, x1, y1);
    }

    private void stampPaint(float cx, float cy) {
        int w = project.w;
        int h = project.h;
        int x0 = (int) Math.floor(cx - brushRadius) - 1;
        int y0 = (int) Math.floor(cy - brushRadius) - 1;
        int x1 = (int) Math.ceil(cx + brushRadius) + 1;
        int y1 = (int) Math.ceil(cy + brushRadius) + 1;
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > w) x1 = w;
        if (y1 > h) y1 = h;
        if (x0 >= x1 || y0 >= y1) return;

        float inner = brushRadius * hardness;
        float band = Math.max(1f, brushRadius - inner);
        final int[] target = activeLayer != null && activeLayer.rasterPixels != null
                ? activeLayer.rasterPixels : project.pixels;

        for (int y = y0; y < y1; y++) {
            int row = y * w;
            float dy = y + 0.5f - cy;
            for (int x = x0; x < x1; x++) {
                float dx = x + 0.5f - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > brushRadius) continue;
                int i = row + x;
                if (smart && project.barrier != null && project.barrier[i] != 0) continue;
                float a = d <= inner ? 1f : 1f - (d - inner) / band;
                a *= toolOpacity;
                if (selectionActive) a *= (project.selection[i] & 0xFF) / 255f;
                if (a <= 0f) continue;
                painted++;
                if (activeLayer != null && activeLayer.rasterPixels != null && activeLayer.alphaLock
                        && (target[i] >>> 24) == 0) continue;
                if (mode == MODE_ERASE_PIXELS) {
                    int original = target[i];
                    int newAlpha = Math.max(0, Math.round(((original >>> 24) & 255) * (1f - a)));
                    target[i] = (newAlpha << 24) | (original & 0xFFFFFF);
                } else {
                    target[i] = blend(target[i], paintColor, a);
                }
            }
        }
        Rect r = new Rect(x0, y0, x1, y1);
        grow(r);
        if (activeLayer != null && activeLayer.rasterPixels != null) {
            for (int y = y0; y < y1; y++) {
                for (int x = x0; x < x1; x++) {
                    int i = y * w + x;
                    activeLayer.mask[i] = (byte) (target[i] >>> 24);
                }
            }
            updateLayerDisplayRegion(r);
        } else {
            project.pushPixels(r);
            updateDisplayRegion(r);
            if (!showBase) refreshLayersPreview();
        }
    }

    private void stampClone(float cx, float cy) {
        Rect r = CloneStamp.stamp(project.pixels, pxBackup, project.w, project.h, cx, cy,
                brushRadius, hardness, cloneOffX, cloneOffY);
        if (r == null) return;
        grow(r);
        project.pushPixels(r);
        updateDisplayRegion(r);
        if (!showBase) refreshLayersPreview();
    }

    /** Composicion sobre RGBA: pintar vuelve a cubrir las partes borradas. */
    private static int blend(int dst, int src, float a) {
        int srcA = Math.min(255, Math.max(0, Math.round(a * ((src >>> 24) & 255))));
        int dstA = (dst >>> 24) & 255;
        int outA = srcA + dstA * (255 - srcA) / 255;
        if (outA <= 0) return 0;
        int r = (((src >> 16) & 255) * srcA * 255 + ((dst >> 16) & 255) * dstA * (255 - srcA)) / (outA * 255);
        int g = (((src >> 8) & 255) * srcA * 255 + ((dst >> 8) & 255) * dstA * (255 - srcA)) / (outA * 255);
        int b = ((src & 255) * srcA * 255 + (dst & 255) * dstA * (255 - srcA)) / (outA * 255);
        return (outA << 24) | (Math.min(255,r) << 16) | (Math.min(255,g) << 8) | Math.min(255,b);
    }

    private void updateDisplayRegion(Rect r) {
        if (display == null) return;
        int dw = display.getWidth();
        int dh = display.getHeight();
        int x0 = Math.max(0, (int) (r.left / dispScale));
        int y0 = Math.max(0, (int) (r.top / dispScale));
        int x1 = Math.min(dw, (int) Math.ceil(r.right / dispScale));
        int y1 = Math.min(dh, (int) Math.ceil(r.bottom / dispScale));
        if (x0 >= x1 || y0 >= y1) return;
        int rw = x1 - x0;
        int[] row = new int[rw];
        for (int y = y0; y < y1; y++) {
            int sy = Math.min(project.h - 1, (int) (y * dispScale));
            int base = sy * project.w;
            for (int i = 0; i < rw; i++) {
                int sx = Math.min(project.w - 1, (int) ((x0 + i) * dispScale));
                row[i] = project.pixels[base + sx];
            }
            display.setPixels(row, 0, rw, x0, y, rw, 1);
        }
        invalidate();
    }

    private void grow(Rect r) {
        if (strokeRect == null) strokeRect = new Rect(r);
        else strokeRect.union(r);
    }

    private void applyLasso() {
        Path closed = new Path(lasso);
        closed.close();
        RectF b = new RectF();
        closed.computeBounds(b, true);
        int l = Math.max(0, (int) Math.floor(b.left));
        int t = Math.max(0, (int) Math.floor(b.top));
        int rr = Math.min(project.w, (int) Math.ceil(b.right) + 1);
        int bb = Math.min(project.h, (int) Math.ceil(b.bottom) + 1);
        lasso.reset();
        if (l >= rr || t >= bb) {
            invalidate();
            return;
        }
        Rect region = new Rect(l, t, rr, bb);
        undo.record(UndoManager.SELECTION, region);

        int rw = region.width();
        int rh = region.height();
        Bitmap tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        pt.setStyle(Paint.Style.FILL);
        c.translate(-l, -t);
        c.drawPath(closed, pt);

        int[] row = new int[rw];
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (t + y) * project.w + l;
            for (int x = 0; x < rw; x++) {
                int a = (row[x] >>> 24);
                if (a == 0) continue;
                if (subtract) {
                    int cur = project.selection[off + x] & 0xFF;
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > (project.selection[off + x] & 0xFF)) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        paintOverlay(region);
        invalidate();
        changed();
    }

    // ------------------------------------------------------------------
    // Varita y balde
    // ------------------------------------------------------------------

    private void runWand(final int sx, final int sy) {
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                if (wandGlobal) {
                    lastFillRect = FloodFill.global(project.pixels, project.w, project.h,
                            scratch, sx, sy, tolerance, softness, colorMode);
                } else {
                    lastFillRect = fillWithGaps(sx, sy);
                }
                if (lastFillRect != null && expansion != 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(Math.abs(expansion)) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Varita");
                    undo.record(UndoManager.SELECTION, r);
                    mergeScratch(r);
                    paintOverlay(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    /**
     * Relleno con reconocimiento de huecos. Engorda la linea para tapar los
     * cortes, rellena dentro, y devuelve el relleno a su sitio. Asi no se
     * escapa por una linea abierta.
     */
    private Rect fillWithGaps(int sx, int sy) {
        byte[] barrier = useBarrier ? project.barrier : null;
        if (!gapOn || barrier == null) {
            return FloodFill.contiguous(project.pixels, project.w, project.h,
                    scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        if (gapBarrier == null || gapBarrier.length != barrier.length) {
            gapBarrier = new byte[barrier.length];
        }
        MaskOps.closeGapsBarrier(barrier, project.w, project.h, gapRadius, gapBarrier);
        if (gapBarrier[sy * project.w + sx] != 0) {
            // el punto quedo bajo la linea engordada: se rellena sin cierre
            return FloodFill.contiguous(project.pixels, project.w, project.h,
                    scratch, barrier, sx, sy, tolerance, softness, colorMode);
        }
        Rect r = FloodFill.contiguous(project.pixels, project.w, project.h,
                scratch, gapBarrier, sx, sy, tolerance, softness, colorMode);
        if (r == null) return null;
        MaskOps.dilate(scratch, project.w, project.h, gapRadius);
        for (int i = 0; i < scratch.length; i++) {
            if (barrier[i] != 0) scratch[i] = 0;
        }
        r.inset(-gapRadius - 1, -gapRadius - 1);
        clamp(r);
        return r;
    }

    private void mergeScratch(Rect r) {
        for (int y = r.top; y < r.bottom; y++) {
            int off = y * project.w;
            for (int x = r.left; x < r.right; x++) {
                int a = scratch[off + x] & 0xFF;
                if (a == 0) continue;
                int cur = project.selection[off + x] & 0xFF;
                if (subtract) {
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > cur) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
    }

    private void clamp(Rect r) {
        if (r.left < 0) r.left = 0;
        if (r.top < 0) r.top = 0;
        if (r.right > project.w) r.right = project.w;
        if (r.bottom > project.h) r.bottom = project.h;
    }

    private void runBucket(final int sx, final int sy) {
        if (sx < 0 || sy < 0 || sx >= project.w || sy >= project.h) return;
        setBusy(true);
        ensureScratch();
        final boolean useSel = project.hasSelection();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = fillWithGaps(sx, sy);
                if (lastFillRect != null && expansion > 0f) {
                    MaskOps.expandSubpixel(scratch, project.w, project.h, expansion, lastFillRect);
                    int m = (int) Math.ceil(expansion) + 2;
                    lastFillRect.inset(-m, -m);
                    clamp(lastFillRect);
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                Rect r = lastFillRect;
                if (r != null) {
                    undo.setLabel("Balde");
                    undo.record(UndoManager.PIXELS, r);
                    for (int y = r.top; y < r.bottom; y++) {
                        int off = y * project.w;
                        for (int x = r.left; x < r.right; x++) {
                            int i = off + x;
                            int a = scratch[i] & 0xFF;
                            if (a == 0) continue;
                            float f = a / 255f;
                            if (useSel) f *= (project.selection[i] & 0xFF) / 255f;
                            if (f <= 0f) continue;
                            project.pixels[i] = blend(project.pixels[i], paintColor, f);
                        }
                    }
                    project.pushPixels(r);
                    updateDisplayRegion(r);
                    changed();
                }
                setBusy(false);
                invalidate();
            }
        });
    }

    // ------------------------------------------------------------------
    // Gama de colores, copiar y pegar
    // ------------------------------------------------------------------

    /** Selecciona ese color en toda la imagen. Lo usa Gama de colores. */
    public void selectColorRange(final int color, final int tol, final int soft,
                                 final boolean replace) {
        if (project == null) return;
        setBusy(true);
        ensureScratch();
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.globalColor(project.pixels, project.w, project.h,
                        scratch, color, tol, soft, colorMode);
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.record(UndoManager.SELECTION, project.fullRect());
                if (replace) project.clearSelection();
                if (lastFillRect != null) mergeScratch(lastFillRect);
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void copySelection(boolean cut) {
        if (project == null) return;
        Rect r = project.selectionBounds();
        if (r == null) { msg("No hay nada seleccionado"); return; }
        int rw = r.width(), rh = r.height();
        clipPixels = new int[rw * rh];
        clipMask = new byte[rw * rh];
        clipRect = new Rect(r);
        final int[] source = activeLayer != null && activeLayer.rasterPixels != null
                ? activeLayer.rasterPixels : project.pixels;
        for (int y = 0; y < rh; y++) {
            int src = (r.top + y) * project.w + r.left;
            System.arraycopy(source, src, clipPixels, y * rw, rw);
            System.arraycopy(project.selection, src, clipMask, y * rw, rw);
        }
        if (cut) {
            if (source != project.pixels) {
                undo.setLabel("Cortar capa");
                undo.recordLayerFromBackup(activeLayer, r, source);
            } else undo.record(UndoManager.PIXELS, r);
            for (int y = 0; y < rh; y++) {
                int off = (r.top + y) * project.w + r.left;
                for (int x = 0; x < rw; x++) {
                    int a = clipMask[y * rw + x] & 255;
                    if (a == 0) continue;
                    if (source != project.pixels) {
                        int c = source[off + x];
                        int alpha = (c >>> 24) * (255 - a) / 255;
                        source[off+x] = (alpha << 24) | (c & 0xFFFFFF);
                    } else source[off + x] = blend(source[off + x], 0xFFFFFFFF, a / 255f);
                }
            }
            if (source == project.pixels) { project.pushPixels(r); updateDisplayRegion(r); }
            else { activeLayer.syncMask(); updateLayerDisplayRegion(r); }
            changed();
        }
        msg(cut ? "Cortado" : "Copiado");
    }

    /** Pega en la capa seleccionada si es raster o en el fondo en caso contrario. */
    public void paste(int offX, int offY) {
        if (project == null || clipPixels == null) { msg("No hay nada copiado"); return; }
        int rw = clipRect.width(), rh = clipRect.height();
        Rect dst = new Rect(clipRect.left + offX, clipRect.top + offY,
                clipRect.left + offX + rw, clipRect.top + offY + rh);
        Rect safe = new Rect(dst);
        clamp(safe);
        if (safe.isEmpty()) return;
        final int[] target = activeLayer != null && activeLayer.rasterPixels != null
                ? activeLayer.rasterPixels : project.pixels;
        if (target != project.pixels) {
            undo.setLabel("Pegar en capa");
            undo.recordLayerFromBackup(activeLayer, safe, target);
        } else undo.record(UndoManager.PIXELS, safe);
        for (int y = 0; y < rh; y++) {
            int ty = dst.top + y;
            if (ty < 0 || ty >= project.h) continue;
            for (int x = 0; x < rw; x++) {
                int tx = dst.left + x;
                if (tx < 0 || tx >= project.w) continue;
                int a = clipMask[y * rw + x] & 255;
                if (a == 0) continue;
                int i = ty * project.w + tx;
                target[i] = blend(target[i], clipPixels[y * rw + x], a / 255f);
            }
        }
        if (target == project.pixels) { project.pushPixels(safe); updateDisplayRegion(safe); }
        else { activeLayer.syncMask(); updateLayerDisplayRegion(safe); }
        changed();
        msg("Pegado");
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    private void ensureScratch() {
        if (scratch == null || scratch.length != project.w * project.h)
            scratch = new byte[project.w * project.h];
    }

    private void ensureSelBackup() {
        if (selBackup == null || selBackup.length != project.w * project.h)
            selBackup = new byte[project.w * project.h];
    }

    private void ensurePxBackup() {
        if (pxBackup == null || pxBackup.length != project.w * project.h)
            pxBackup = new int[project.w * project.h];
    }

    private void setBusy(boolean b) {
        busy = b;
        if (callback != null) callback.onBusy(b);
    }

    private void changed() {
        if (callback != null) callback.onChanged();
    }

    private void msg(String s) {
        if (callback != null) callback.onMessage(s);
    }

    public void clearUndoHistory() {
        if (undo != null) undo.clear();
    }

    public void doUndo() {
        if (undo == null) return;
        Rect r = undo.undo();
        if (r != null) {
            applyRestored(r);
            String l = undo.lastLabel();
            showHud(l == null || l.isEmpty() ? "Deshacer" : "Deshacer: " + l);
        } else {
            showHud("Nada que deshacer");
        }
    }

    public void doRedo() {
        if (undo == null) return;
        Rect r = undo.redo();
        if (r != null) {
            applyRestored(r);
            String l = undo.lastLabel();
            showHud(l == null || l.isEmpty() ? "Rehacer" : "Rehacer: " + l);
        } else {
            showHud("Nada que rehacer");
        }
    }

    private void applyRestored(Rect r) {
        if (undo.lastRestoredType() == UndoManager.PIXELS) updateDisplayRegion(r);
        else if (undo.lastRestoredType() == UndoManager.LAYER) updateLayerDisplayRegion(r);
        else paintOverlay(r);
        invalidate();
        changed();
    }

    public void clearSelection() {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        project.clearSelection();
        refreshOverlay(null);
        changed();
    }

    public void invertSelection() {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        MaskOps.invert(project.selection);
        refreshOverlay(null);
        changed();
    }

    public void loadSelection(byte[] mask) {
        if (project == null) return;
        undo.record(UndoManager.SELECTION, project.fullRect());
        MaskOps.copyInto(project.selection, mask);
        refreshOverlay(null);
        changed();
    }

    /** kind: 0 expandir, 1 contraer, 2 suavizar, 3 endurecer, 4 cerrar huecos */
    public void edgeOp(final int kind, final int radius) {
        if (project == null) return;
        setBusy(true);
        undo.record(UndoManager.SELECTION, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        MaskOps.dilate(project.selection, project.w, project.h, radius);
                        break;
                    case 1:
                        MaskOps.erode(project.selection, project.w, project.h, radius);
                        break;
                    case 2:
                        MaskOps.feather(project.selection, project.w, project.h, radius);
                        break;
                    case 4:
                        MaskOps.closeHoles(project.selection, project.w, project.h, radius);
                        break;
                    case 5:
                        MaskOps.fillEnclosed(project.selection, project.w, project.h,
                                radius <= 0 ? 0 : radius * 400);
                        break;
                    default:
                        MaskOps.threshold(project.selection, 128);
                        break;
                }
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    /** Expansion con decimales aplicada a mano sobre la seleccion. */
    public void expandSelection(final float px) {
        if (project == null) return;
        setBusy(true);
        undo.record(UndoManager.SELECTION, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                MaskOps.expandSubpixel(project.selection, project.w, project.h, px, null);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    public void buildBarrier(final int threshold, final int closeGap) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                project.barrier = LineArt.build(project.pixels, project.w, project.h,
                        threshold, closeGap);
                gapBarrier = null;
                wire = null;
            }
        }, new Runnable() {
            @Override
            public void run() {
                useBarrier = true;
                setBusy(false);
                msg("Line art listo: la varita y el balde ya no se escapan por las lineas");
                changed();
            }
        });
    }

    public void transform(final int kind) {
        if (project == null) return;
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        project.rotate90(true);
                        break;
                    case 1:
                        project.rotate90(false);
                        break;
                    case 2:
                        project.flip(true);
                        break;
                    default:
                        project.flip(false);
                        break;
                }
                gapBarrier = null;
                wire = null;
            }
        }, new Runnable() {
            @Override
            public void run() {
                undo.clear();
                scissorsReset();
                buildDisplay();
                buildOverlay();
                fit();
                setBusy(false);
                msg("Listo. El historial de deshacer se reinicia al girar");
                changed();
            }
        });
    }

    // ------------------------------------------------------------------
    // Tijeras inteligentes
    // ------------------------------------------------------------------

    private void setAnchorAsync(final int x, final int y) {
        setBusy(true);
        Task.run(new Runnable() {
            @Override
            public void run() {
                if (wire == null) wire = new LiveWire(project.pixels, project.w, project.h);
                wire.setAnchor(x, y, 320);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setBusy(false);
                invalidate();
            }
        });
    }

    /** Fija el tramo que se estaba viendo y arranca el siguiente. */
    private void commitWire() {
        if (livePath == null || livePath.length < 2) return;
        // el camino viene del dedo hacia el ancla, se recorre al reves
        for (int i = livePath.length - 1; i >= 0; i -= 2) {
            int idx = livePath[i];
            int y = idx / project.w;
            int x = idx - y * project.w;
            wirePath.lineTo(x, y);
        }
        int last = livePath[0];
        int ly = last / project.w;
        int lx = last - ly * project.w;
        livePath = null;

        if (firstAnchor >= 0) {
            int fy = firstAnchor / project.w;
            int fx = firstAnchor - fy * project.w;
            float d = (float) Math.hypot(lx - fx, ly - fy);
            if (d < 24f) {
                scissorsClose();
                return;
            }
        }
        setAnchorAsync(lx, ly);
        invalidate();
    }

    /** Cierra la figura y la convierte en seleccion. */
    public void scissorsClose() {
        if (project == null || !wireStarted) {
            msg("Primero traza el contorno con las tijeras");
            return;
        }
        Path closed = new Path(wirePath);
        closed.close();
        scissorsReset();
        fillPathIntoSelection(closed, "Tijeras");
    }

    public void scissorsReset() {
        wirePath.reset();
        livePath = null;
        firstAnchor = -1;
        wireStarted = false;
        invalidate();
    }

    /** Rellena una figura cerrada dentro de la seleccion. */
    private void fillPathIntoSelection(Path closed, String label) {
        RectF b = new RectF();
        closed.computeBounds(b, true);
        int l = Math.max(0, (int) Math.floor(b.left));
        int t = Math.max(0, (int) Math.floor(b.top));
        int rr = Math.min(project.w, (int) Math.ceil(b.right) + 1);
        int bb = Math.min(project.h, (int) Math.ceil(b.bottom) + 1);
        if (l >= rr || t >= bb) {
            invalidate();
            return;
        }
        Rect region = new Rect(l, t, rr, bb);
        undo.setLabel(label);
        undo.record(UndoManager.SELECTION, region);

        int rw = region.width();
        int rh = region.height();
        Bitmap tmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(tmp);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(Color.WHITE);
        pt.setStyle(Paint.Style.FILL);
        c.translate(-l, -t);
        c.drawPath(closed, pt);

        int[] row = new int[rw];
        for (int y = 0; y < rh; y++) {
            tmp.getPixels(row, 0, rw, 0, y, rw, 1);
            int off = (t + y) * project.w + l;
            for (int x = 0; x < rw; x++) {
                int a = (row[x] >>> 24);
                if (a == 0) continue;
                if (subtract) {
                    int cur = project.selection[off + x] & 0xFF;
                    int v = cur - a;
                    project.selection[off + x] = (byte) (v < 0 ? 0 : v);
                } else if (a > (project.selection[off + x] & 0xFF)) {
                    project.selection[off + x] = (byte) a;
                }
            }
        }
        tmp.recycle();
        paintOverlay(region);
        invalidate();
        changed();
    }

    // ------------------------------------------------------------------
    // Mover la seleccion
    // ------------------------------------------------------------------

    private void shiftSelection(int dx, int dy) {
        if (moveBackup == null) return;
        int w = project.w, h = project.h;
        java.util.Arrays.fill(project.selection, (byte) 0);
        for (int y = 0; y < h; y++) {
            int ty = y + dy;
            if (ty < 0 || ty >= h) continue;
            int src = y * w;
            int dst = ty * w;
            for (int x = 0; x < w; x++) {
                int tx = x + dx;
                if (tx < 0 || tx >= w) continue;
                project.selection[dst + tx] = moveBackup[src + x];
            }
        }
        refreshOverlay(null);
    }

    // ------------------------------------------------------------------
    // Estabilizador, vista previa, refinado y filtros
    // ------------------------------------------------------------------

    public void setStabilizer(float v) {
        stabilizer = Math.max(0f, Math.min(0.92f, v));
    }

    public float getStabilizer() {
        return stabilizer;
    }

    /** Guarda la seleccion para poder ir probando margenes en vivo. */
    public void beginPreview() {
        if (project == null) return;
        if (previewBackup == null || previewBackup.length != project.selection.length) {
            previewBackup = new byte[project.selection.length];
        }
        System.arraycopy(project.selection, 0, previewBackup, 0, previewBackup.length);
    }

    public void previewColorRange(final int color, final int tol, final boolean replace) {
        if (project == null || previewBackup == null || busy) return;
        setBusy(true);
        ensureScratch();
        final int soft = softness;
        Task.run(new Runnable() {
            @Override
            public void run() {
                Arrays.fill(scratch, (byte) 0);
                lastFillRect = FloodFill.globalColor(project.pixels, project.w, project.h,
                        scratch, color, tol, soft, colorMode);
            }
        }, new Runnable() {
            @Override
            public void run() {
                System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
                if (replace) project.clearSelection();
                if (lastFillRect != null) mergeScratch(lastFillRect);
                refreshOverlay(null);
                setBusy(false);
            }
        });
    }

    /** Se queda con lo que se ve, o lo devuelve a como estaba. */
    public void endPreview(boolean keep) {
        if (project == null || previewBackup == null) return;
        if (keep) {
            byte[] shown = new byte[project.selection.length];
            System.arraycopy(project.selection, 0, shown, 0, shown.length);
            System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
            undo.setLabel("Gama de colores");
            undo.record(UndoManager.SELECTION, project.fullRect());
            System.arraycopy(shown, 0, project.selection, 0, shown.length);
        } else {
            System.arraycopy(previewBackup, 0, project.selection, 0, previewBackup.length);
        }
        previewBackup = null;
        refreshOverlay(null);
        changed();
    }

    /** Refina el borde siguiendo el dibujo. Para pelo y bordes finos. */
    public void refineEdge(final int radius, final float eps) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Refinar borde");
        undo.record(UndoManager.SELECTION, project.fullRect());
        final Rect area = project.selectionBounds();
        Task.run(new Runnable() {
            @Override
            public void run() {
                GuidedFilter.refine(project.selection, project.pixels,
                        project.w, project.h, radius, eps, area);
            }
        }, new Runnable() {
            @Override
            public void run() {
                refreshOverlay(null);
                setBusy(false);
                changed();
            }
        });
    }

    /** kind: 0 mediana, 1 posterizar, 2 niveles, 3 extraer line art */
    public void applyFilter(final int kind, final int a, final int b, final int c) {
        if (project == null) return;
        setBusy(true);
        undo.setLabel("Filtro");
        undo.record(UndoManager.PIXELS, project.fullRect());
        Task.run(new Runnable() {
            @Override
            public void run() {
                switch (kind) {
                    case 0:
                        Filters.median3(project.pixels, project.w, project.h);
                        break;
                    case 1:
                        Filters.posterize(project.pixels, a);
                        break;
                    case 2:
                        Filters.levels(project.pixels, a, b, c / 100f);
                        break;
                    default:
                        Filters.extractLineArt(project.pixels, project.w, project.h, a, b, c);
                        break;
                }
                project.pushPixels(null);
            }
        }, new Runnable() {
            @Override
            public void run() {
                wire = null;
                refreshDisplay();
                setBusy(false);
                changed();
            }
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (project != null && ow == 0) fit();
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelQuickTimer();
        super.onDetachedFromWindow();
    }
}
