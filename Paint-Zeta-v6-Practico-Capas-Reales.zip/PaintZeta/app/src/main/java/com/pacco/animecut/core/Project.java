package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Documento de trabajo. La imagen NUNCA se reescala: se guarda a su
 * resolucion original y todas las mascaras tienen exactamente ese tamano,
 * para que las capas exportadas entren alineadas en Alight Motion.
 */
public class Project {

    public Bitmap base;
    public int w;
    public int h;

    /** Copia de los pixeles de la imagen. La usan la varita, el balde y el pincel. */
    public int[] pixels;

    /** Seleccion activa (0..255 por pixel). */
    public byte[] selection;

    /** Line art usado como barrera del relleno. null = no calculado. */
    public byte[] barrier;

    public final List<Layer> layers = new ArrayList<>();

    public Project(Bitmap base) {
        this.base = base;
        this.w = base.getWidth();
        this.h = base.getHeight();
        this.pixels = new int[w * h];
        base.getPixels(pixels, 0, w, 0, 0, w, h);
        this.selection = new byte[w * h];
    }

    public boolean hasSelection() {
        for (int i = 0; i < selection.length; i++) {
            if (selection[i] != 0) return true;
        }
        return false;
    }

    public void clearSelection() {
        Arrays.fill(selection, (byte) 0);
    }

    public Rect fullRect() {
        return new Rect(0, 0, w, h);
    }

    /** Devuelve el rectangulo que ocupa la seleccion, o null si esta vacia. */
    public Rect selectionBounds() {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                if (selection[row + x] != 0) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0) return null;
        return new Rect(minX, minY, maxX + 1, maxY + 1);
    }

    /** Vuelca al bitmap los pixeles modificados (pintar, balde, clonar). */
    public void pushPixels(Rect r) {
        if (r == null) r = fullRect();
        int left = Math.max(0, r.left);
        int top = Math.max(0, r.top);
        int right = Math.min(w, r.right);
        int bottom = Math.min(h, r.bottom);
        int rw = right - left;
        if (rw <= 0) return;
        int[] buf = new int[rw];
        for (int y = top; y < bottom; y++) {
            System.arraycopy(pixels, y * w + left, buf, 0, rw);
            base.setPixels(buf, 0, rw, left, y, rw, 1);
        }
    }

    public String nextLayerName() {
        return "capa_" + (layers.size() + 1);
    }

    // ------------------------------------------------------------------
    // Girar y voltear. Se transforma TODO a la vez: imagen, seleccion,
    // line art y cada capa, para que nada se desalinee.
    // ------------------------------------------------------------------

    public void rotate90(boolean clockwise) {
        int nw = h;
        int nh = w;
        pixels = rotInts(pixels, w, h, clockwise);
        selection = rotBytes(selection, w, h, clockwise);
        if (barrier != null) barrier = rotBytes(barrier, w, h, clockwise);
        for (Layer l : layers) {
            l.mask = rotBytes(l.mask, w, h, clockwise);
            if (l.rasterPixels != null) l.rasterPixels = rotInts(l.rasterPixels, w, h, clockwise);
        }
        w = nw;
        h = nh;
        rebuildBase();
    }

    public void flip(boolean horizontal) {
        pixels = flipInts(pixels, w, h, horizontal);
        selection = flipBytes(selection, w, h, horizontal);
        if (barrier != null) barrier = flipBytes(barrier, w, h, horizontal);
        for (Layer l : layers) {
            l.mask = flipBytes(l.mask, w, h, horizontal);
            if (l.rasterPixels != null) l.rasterPixels = flipInts(l.rasterPixels, w, h, horizontal);
        }
        rebuildBase();
    }

    private void rebuildBase() {
        Bitmap old = base;
        base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        base.setPixels(pixels, 0, w, 0, 0, w, h);
        if (old != null && !old.isRecycled()) old.recycle();
    }

    private static int[] rotInts(int[] s, int w, int h, boolean cw) {
        int[] d = new int[s.length];
        int nw = h;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int nx, ny;
                if (cw) {
                    nx = h - 1 - y;
                    ny = x;
                } else {
                    nx = y;
                    ny = w - 1 - x;
                }
                d[ny * nw + nx] = s[row + x];
            }
        }
        return d;
    }

    private static byte[] rotBytes(byte[] s, int w, int h, boolean cw) {
        byte[] d = new byte[s.length];
        int nw = h;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int nx, ny;
                if (cw) {
                    nx = h - 1 - y;
                    ny = x;
                } else {
                    nx = y;
                    ny = w - 1 - x;
                }
                d[ny * nw + nx] = s[row + x];
            }
        }
        return d;
    }

    private static int[] flipInts(int[] s, int w, int h, boolean horizontal) {
        int[] d = new int[s.length];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            int drow = horizontal ? row : (h - 1 - y) * w;
            for (int x = 0; x < w; x++) {
                int dx = horizontal ? (w - 1 - x) : x;
                d[drow + dx] = s[row + x];
            }
        }
        return d;
    }

    private static byte[] flipBytes(byte[] s, int w, int h, boolean horizontal) {
        byte[] d = new byte[s.length];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            int drow = horizontal ? row : (h - 1 - y) * w;
            for (int x = 0; x < w; x++) {
                int dx = horizontal ? (w - 1 - x) : x;
                d[drow + dx] = s[row + x];
            }
        }
        return d;
    }
}
