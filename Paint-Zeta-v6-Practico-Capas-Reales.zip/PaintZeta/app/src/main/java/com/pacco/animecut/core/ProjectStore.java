package com.pacco.animecut.core;

import android.content.Context;
import android.graphics.Bitmap;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Carpeta de obras. Cada trabajo es un archivo .acut con su miniatura al
 * lado, para que la galeria cargue rapido sin abrir el proyecto entero.
 */
public final class ProjectStore {

    public static class Entry {
        public String id;
        public File file;
        public File thumb;
        public long modified;
        public int layers;
    }

    private ProjectStore() {
    }

    public static File dir(Context c) {
        File d = new File(c.getFilesDir(), "obras");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static String newId() {
        return "obra_" + System.currentTimeMillis();
    }

    public static File fileFor(Context c, String id) {
        return new File(dir(c), id + ".acut");
    }

    public static File thumbFor(Context c, String id) {
        return new File(dir(c), id + ".png");
    }

    public static List<Entry> list(Context c) {
        List<Entry> out = new ArrayList<Entry>();
        File[] files = dir(c).listFiles();
        if (files == null) return out;
        for (File f : files) {
            String n = f.getName();
            if (!n.endsWith(".acut") || f.length() == 0) continue;
            Entry e = new Entry();
            e.id = n.substring(0, n.length() - 5);
            e.file = f;
            e.thumb = thumbFor(c, e.id);
            e.modified = f.lastModified();
            out.add(e);
        }
        Collections.sort(out, new Comparator<Entry>() {
            @Override
            public int compare(Entry a, Entry b) {
                return Long.compare(b.modified, a.modified);
            }
        });
        return out;
    }

    /** Miniatura de 320 px de lado largo. */
    public static void saveThumb(Context c, String id, Bitmap base) {
        try {
            int max = Math.max(base.getWidth(), base.getHeight());
            float s = max > 320 ? 320f / max : 1f;
            int tw = Math.max(1, Math.round(base.getWidth() * s));
            int th = Math.max(1, Math.round(base.getHeight() * s));
            Bitmap t = Bitmap.createScaledBitmap(base, tw, th, true);
            FileOutputStream fo = new FileOutputStream(thumbFor(c, id));
            t.compress(Bitmap.CompressFormat.PNG, 90, fo);
            fo.close();
            if (t != base) t.recycle();
        } catch (Throwable ignored) {
        }
    }

    /** Miniatura real del dibujo, incluyendo capas raster visibles. */
    public static void saveThumb(Context c, String id, Project p) {
        try {
            int max = Math.max(p.w, p.h);
            float scale = max > 320 ? 320f / max : 1f;
            int tw = Math.max(1, Math.round(p.w * scale));
            int th = Math.max(1, Math.round(p.h * scale));
            Bitmap preview = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            int[] row = new int[tw];
            for (int y = 0; y < th; y++) {
                int sy = Math.min(p.h - 1, y * p.h / th);
                for (int x = 0; x < tw; x++) {
                    int sx = Math.min(p.w - 1, x * p.w / tw);
                    int i = sy * p.w + sx;
                    int out = p.pixels[i];
                    for (Layer l : p.layers) {
                        if (!l.visible || l.rasterPixels == null) continue;
                        int src = l.rasterPixels[i];
                        int a = (src >>> 24) * l.opacity / 255;
                        if (a <= 0) continue;
                        if (l.grayscale) {
                            int gray = (((src>>16)&255)*77 + ((src>>8)&255)*150 + (src&255)*29 + 128)>>8;
                            src = (src&0xFF000000) | (gray<<16) | (gray<<8) | gray;
                        }
                        int da = out >>> 24;
                        int oa = a + da * (255-a)/255;
                        if (oa <= 0) { out = 0; continue; }
                        int r = (((src>>16)&255)*a*255 + ((out>>16)&255)*da*(255-a))/(oa*255);
                        int g = (((src>>8)&255)*a*255 + ((out>>8)&255)*da*(255-a))/(oa*255);
                        int b = ((src&255)*a*255 + (out&255)*da*(255-a))/(oa*255);
                        out = (oa<<24)|(Math.min(255,r)<<16)|(Math.min(255,g)<<8)|Math.min(255,b);
                    }
                    row[x] = out;
                }
                preview.setPixels(row, 0, tw, 0, y, tw, 1);
            }
            try (FileOutputStream fo = new FileOutputStream(thumbFor(c, id))) {
                preview.compress(Bitmap.CompressFormat.PNG, 90, fo);
            }
            preview.recycle();
        } catch (Throwable ignored) {
            // Error de miniatura nunca invalida el proyecto guardado.
        }
    }

    public static File nameFile(Context c, String id) {
        return new File(dir(c), id + ".txt");
    }

    public static String name(Context c, String id) {
        File f = nameFile(c, id);
        if (!f.exists()) return null;
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int n = in.read(buf);
            in.close();
            if (n <= 0) return null;
            return new String(buf, 0, n, "UTF-8").trim();
        } catch (Throwable t) {
            return null;
        }
    }

    public static void setName(Context c, String id, String name) {
        try {
            FileOutputStream o = new FileOutputStream(nameFile(c, id));
            o.write(name.getBytes("UTF-8"));
            o.close();
        } catch (Throwable ignored) {
        }
    }

    public static void delete(Context c, String id) {
        File n = nameFile(c, id);
        if (n.exists()) n.delete();
        File f = fileFor(c, id);
        if (f.exists()) f.delete();
        File t = thumbFor(c, id);
        if (t.exists()) t.delete();
    }
}
