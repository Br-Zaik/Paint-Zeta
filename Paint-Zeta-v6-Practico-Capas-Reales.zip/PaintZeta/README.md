# Paint Zeta v6 — edición práctica y capas reales

Proyecto Android en Java + AndroidX AppCompat para dibujar, seleccionar partes, editarlas por capas y exportar a Alight Motion. El ZIP contiene **código fuente, no una APK**.

## Uso

1. Abre una imagen o entra a Menú → Crear lienzo blanco para dibujar desde cero.
2. La barra inferior separa claramente Pincel de color, Color, Varita, Pincel de selección, Borrador de imagen, Lazo, Tijeras, Mover y Mano. Mantener pulsado un botón explica su función; hay una leyenda para la herramienta activa.
3. Tamaño y opacidad tienen barras independientes visibles. Más herramientas oculta las opciones técnicas (borrador de selección azul, balde, cuentagotas, clonar, etc.).
4. Toca Capas → + SIN selección para crear una capa de dibujo transparente; CON selección para extraer la zona a una nueva capa ARGB independiente. Toca el nombre para seleccionar una capa y dibuja o borra. Mantén pulsado Fondo visible para volver a editar el fondo.
5. En el panel de capas: miniaturas, visibilidad, opacidad individual, orden, duplicación, renombrar, B/N, bloqueo alfa (α), combinar con la capa inferior, eliminar con confirmación, aislar sobre tablero de transparencia. Oculta fondo para visualizar solo las capas.
6. Con Mover: si hay una selección azul se desplaza esa selección; si no hay selección azul y existe una capa ARGB activa, se mueve su contenido. Con zoom de dos dedos se mueve y amplía el lienzo sin alterar el dibujo.
7. Exportar crea ZIP con PNG independientes transparentes, todos del mismo tamaño y alineados para Alight Motion. Si el fondo está visible también exporta `99_fondo_restante.png`; si lo ocultas, exporta solo las piezas. Menú → Guardar dibujo como PNG guarda la imagen base; cada capa puede exportarse suelta desde las opciones clásicas de capas.

## Persistencia y compatibilidad

- Nuevo formato de proyecto `.acut` v3 guarda PNGs de las capas ARGB, máscaras y propiedades (opacidad, visibilidad, blanco/negro, bloqueo alfa). Puede abrir proyectos v1 y v2. Las capas antiguas solo de máscara siguen siendo legibles y exportables; para dibujar en una capa antigua, crea una nueva raster desde su selección.
- Se conserva applicationId `com.pacco.animecut`, iconos HD cuadrados/circulares/adaptables, Java 17, Gradle 8.7 y alineación Kotlin 1.8.22.
- Se añade deshacer/rehacer para trazos y movimientos raster. Combinar capas reinicia historial de deshacer para evitar referencias rotas a las capas fusionadas.

## Límites que no se deben confundir con Ibis Paint

No es una réplica de todas las herramientas de Ibis Paint: aún faltan modos de fusión (Multiplicar, Pantalla, etc.), deformación libre y controles avanzados de transformación por capa. Las herramientas automáticas basadas en color (varita, balde, line-art y gotero) todavía muestrean principalmente la imagen base; las herramientas manuales de dibujo y borrado operan sobre la capa ARGB activa. Las capas raster grandes requieren RAM; se comprueba memoria disponible antes de crear otra.

**Prueba de compilación pendiente:** se han validado sintaxis Java (sin SDK Android), XML, referencias de IDs, YAML y estructura del ZIP; no se pudo compilar ni ejecutar la APK en este entorno. Confirma el resultado de GitHub Actions antes de instalar.
