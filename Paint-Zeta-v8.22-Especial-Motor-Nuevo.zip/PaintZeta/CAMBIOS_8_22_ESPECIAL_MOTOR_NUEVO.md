# Paint Zeta v8.22 — Especial: motor nuevo

## Alcance

Solo se reconstruyó la herramienta **Especial** (Arrastrar, Contraer, Expandir, Suavizar y Restaurar, con Grosor y Fuerza). **No se tocaron** Malla, los puntos de anclaje, Curva, Polilínea, Lazo, Brocha, Goma, las capas, el coloreado ni la exportación. `MainActivity.java` no cambió: la interfaz de Especial (botones, iconos y deslizadores) es la misma de la v8.21.

## Errores encontrados en v8.21 (comprobados en el código y con pruebas)

1. **ARRASTRAR sumaba vectores en vez de componer movimientos.** El nodo hacía `campo -= arrastre·peso` sin mirar dónde estaba antes ese contenido. Si la zona ya estaba deformada, el contenido anterior no seguía al dedo y la línea se torcía. Medido frente a una referencia exacta, el error era de 1,67 px de media y 18,3 px como máximo. Con el motor nuevo baja a 0,33 px de media y 3,4 px como máximo.
2. **Rejilla gruesa (12–32 px) con interpolación bilineal.** La pendiente del campo cambiaba de golpe en cada celda y producía quiebres y escalones en las líneas finas.
3. **El antipliegue descartaba estampas.** Si la protección fallaba 13 veces, la estampa se tiraba entera y el dedo se movía sin efecto («no responde»).
4. **Límites duros:** máximo de 0,23·radio por estampa, tope de desplazamiento por nodo y 32 estampas por evento. Con un gesto rápido se recortaba movimiento.
5. **Regularización laplaciana tras cada estampa:** movía el campo en direcciones que el dedo no pidió y cambiaba según cuántos eventos llegaban, lo que hacía que la imagen «bailara».
6. **Historial táctil ignorado en Especial:** solo se usaba el último punto de cada evento.
7. **Contraer, Expandir, Suavizar y Restaurar con el dedo quieto actuaban cada 165 ms**, a tirones.
8. **Estampas, copias del original y composición de la región en el hilo de la interfaz.** La confirmación al levantar el dedo también era síncrona, de ahí el lag y los congelamientos.
9. **La vista previa se recortaba a 550.000 px alrededor del dedo** y se calculaba por otra ruta que el resultado final, lo que podía dar un resultado distinto al soltar.
10. **El detalle nítido con zoom se desactivaba con más de 48.000 px cambiados**, y la imagen se veía borrosa durante el gesto.
11. **Un segundo dedo (cancelar) reiniciaba toda la sesión de Especial.** Se perdía la posibilidad de Restaurar los trazos anteriores.
12. **Sin antialiasing al contraer:** las tramas y las líneas paralelas comprimidas formaban bandas.

## Algoritmos implementados

- **Campo inverso compuesto** (`core/LiquifyField.java`): cada píxel destino p lee el original en S(p) = p + U(p). Cada estampa es una transformación local T y se compone: U'(p) = U(T(p)) + (T(p) − p). Vale para Arrastrar, Contraer y Expandir.
- **Rejilla fina** de 4 px (6 u 8 px en lienzos de más de 4200 o 6400 px), evaluada con **B-spline cúbica** (continuidad C2, sin oscilaciones). Los coeficientes se transportan con una mezcla de 70 % Catmull-Rom y 30 % B-spline, elegida midiendo exactitud y robustez.
- **Paso limitado por construcción** (`core/LiquifyStroke.java`): cada sub-estampa cumple det(dT) ≥ 1 − 0,45, calculado con la pendiente real del perfil del pincel (`core/LiquifyFalloff.java`).
- **Estampas a distancias iguales a lo largo del recorrido**, y no una por evento. Así, 60 Hz, 240 Hz o lotes irregulares de Android dan prácticamente el mismo resultado.
- **Modos de tiempo:** Contraer, Expandir, Suavizar y Restaurar avanzan con el tiempo que el dedo está apoyado, en cada fotograma.
- **Saturación suave:** si la estampa fuese a llevar el mapa a un estiramiento extremo (det < 0,15) o a una compresión extrema (det > 16), se atenúa la estampa entera de manera uniforme, sin crear quiebres.
- **Verificador del mapa real:** después de cada sub-estampa se calcula det(dS) de la B-spline en 9 puntos por celda. Ningún punto puede bajar de min(0,05, valor previo). Si alguno bajaría, solo se reduce el incremento de los nodos que lo afectan.
- **Suavizar** promedia el **campo** con una caja proporcional al pincel y no emborrona la imagen. **Restaurar** lleva el campo a cero exacto y devuelve el píxel original bit a bit.
- **Rasterizador único** (`core/LiquifyRaster.java`) para la vista previa y el resultado final:
  - Donde no hay deformación, devuelve el píxel original exacto.
  - Interpola en bilineal con alfa premultiplicado, sin halo oscuro en las transparencias.
  - Con compresión mayor de 1,3×, promedia hasta 3×3 muestras sobre la huella del píxel (antialiasing).
  - En los bordes del lienzo repite el píxel del borde.
- **Fuente original por bloques** (`core/LiquifySource.java`): nunca se lee un píxel ya deformado, así que no hay borrosidad acumulada.

## Arquitectura de hilos

- **Interfaz:** recibe cada punto del dedo, incluido el historial y la hora de cada punto, y lo envía al motor. Una vez por fotograma (con Choreographer) copia a la capa los bloques de 64×64 ya terminados y guarda antes el bloque original para Deshacer. No calcula ni el campo ni los píxeles.
- **Motor** (`core/LiquifySession.java`, hilo propio con prioridad de dibujo):
  - Aplica **todas** las sub-estampas en orden: nunca descarta movimiento, solo fotogramas intermedios.
  - Renderiza primero los bloques visibles más cercanos al pincel y cede el paso cuando llegan movimientos nuevos.
- **Al levantar el dedo:** el motor aplica el tramo final y lo pendiente, y después avisa. La interfaz no se congela. Deshacer, Rehacer, cambiar de herramienta, empezar otro trazo o leer el proyecto (guardar o exportar) esperan primero a que ese último trazo quede confirmado.
- **Segundo dedo antes de 400 ms:** se cancela el trazo, el campo vuelve exactamente al estado anterior y la capa se restaura. Un bloque de un trazo cancelado o antiguo nunca se copia, porque cada bloque lleva el número de su trazo.
- **Marcas para Perfetto/System Trace:** `Especial:campo`, `Especial:render`, `Especial:render-final` y `Especial:copiar-bloques`.

## Archivos

Archivos modificados:
- `app/src/main/java/com/pacco/animecut/view/CanvasView.java`. Solo cambió el bloque de Especial y sus puntos de entrada (toque, inicio, movimiento, fin y cancelación del trazo, deshacer y rehacer, cambio de herramienta, `getProject`).
- `app/build.gradle`: versión 8.22 (versionCode 60).
- `tests/run_jvm_tests.sh`.
- `tests/test_regressions.py`: se actualizaron las pruebas de Especial.

Archivos nuevos:
- `core/LiquifyField.java`
- `core/LiquifyFalloff.java`
- `core/LiquifyStroke.java`
- `core/LiquifySource.java`
- `core/LiquifyRaster.java`
- `core/LiquifySession.java`
- `tests/LiquifyEngineTest.java`
- `tests/CanvasEspecialSimTest.java`
- `tests/androidsim/`: una simulación mínima de Android, solo para pruebas.
- `tests/legacy/`: el motor anterior, solo para compararlo en las pruebas.
- `docs/comparacion_especial_v8_21_vs_v8_22.png`
- `docs/RESULTADOS_PRUEBAS_8_22.txt`

Archivos eliminados:
- `core/InverseLiquifyEngine.java`
- `core/LiquifyFrameRenderer.java`
- `core/LiquifyTopologyGuard.java`
- Sus tres pruebas antiguas.

## Pruebas ejecutadas (resultados completos en `docs/RESULTADOS_PRUEBAS_8_22.txt`)

Ejecutar: `sh tests/run_jvm_tests.sh` (o `sh tests/run_jvm_tests.sh full` para medir también el rendimiento).

- **Motor (JVM):**
  - Un campo nulo deja la imagen igual bit a bit.
  - Arrastrar sigue al dedo según la Fuerza.
  - La composición frente a la referencia densa es 5 veces más exacta que en v8.21.
  - El mismo recorrido a 60 Hz, a 240 Hz o en lotes irregulares da una diferencia de 0,49 px como máximo.
  - Hay 8 escenarios (arrastre lento, rápido, círculos, zigzag, contraer, expandir, suavizar y restaurar parcial), con líneas de 1, 2 y 3 px sobre blanco y sobre transparente. En todos: sin pliegues, sin cortes, sin duplicados y sin halo.
  - Restaurar devuelve el original bit a bit.
  - Suavizar actúa sobre el campo.
  - Antialiasing: una trama de 1 px comprimida 3,9× queda en gris (desviación 10) y no forma bandas.
  - Cancelar deja el campo exacto.
  - La selección no cambia ni un píxel fuera de lo seleccionado.
  - Con el hilo real, la vista previa es igual al resultado final bit a bit.
  - Cancelar y seguir no deja restos.
- **Estrés extremo:** 260 trazos aleatorios (8727 sub-estampas, los 5 modos, radios de 12 a 152, fuerza del 5 al 100 %). En los puntos de control, el determinante nunca baja de 0,05. Entre los puntos de control quedaron micro-pliegues (det mínimo −0,053, en 3 de 13 revisiones) tras torsiones extremas acumuladas. **No se puede afirmar ausencia absoluta de pliegues en casos extremos.**
- **Integración** (CanvasView REAL + Android simulado):
  - Vista previa en vivo y confirmación asíncrona, iguales al campo.
  - Deshacer y Rehacer exactos, también justo al soltar.
  - Dos dedos al empezar: sin trazo falso y sin tocar el historial.
  - Dos dedos tras 400 ms: confirma el trazo y luego solo navega.
  - Contraer con el dedo quieto avanza en cada fotograma.
  - Restaurar devuelve el original exacto.
  - Al cambiar de herramienta y volver, la sesión empieza limpia.
- **Pruebas estáticas:** 21 correctas.
- **Compilación:** `CanvasView` y todo `core` compilan con javac contra firmas de Android simuladas. **No se pudo compilar el APK**, porque este entorno no tiene Android SDK ni acceso a Google Maven.

## Rendimiento medido (CPU del servidor de pruebas, no de un teléfono)

Lienzo de 2048×2048, en ms por fotograma:

- Pincel de radio 35: campo 0,26 ms y render 2,4 ms.
- Pincel de radio 115: campo 1,2 ms y render 10 ms.
- Pincel de radio 250: campo 4,6 ms y render 14 ms.

Hilo de interfaz por fotograma, en la integración: 0,17 ms de media y 0,9 ms como máximo.

Memoria del campo con 4096×4096: 8 MB.

Un teléfono económico puede ser de 3 a 8 veces más lento. El dedo y la interfaz no esperan al motor, pero con pinceles grandes la vista previa puede bajar de 60 FPS.

## Pendiente (no hecho, a propósito)

- **OpenGL ES 3.0 no se implementó.** Primero hay que medir esta versión en un teléfono real con Perfetto. Si el render de pinceles grandes no llega a la fluidez deseada, el siguiente paso es un fragment shader con este mismo `LiquifyRaster` como ruta de respaldo y de verificación. No se añadió una ruta GPU sin poder probarla.
- **Composición en la interfaz.** El recompuesto de la vista de capas (`composeRegion` / `updateDetail`) sigue en el hilo de la interfaz, porque es compartido por todas las herramientas. Para Especial se subió el límite de detalle nítido a 260.000 px por fotograma.
- **Restaurar y Suavizar** sobre zonas muy retorcidas avanzan más despacio donde aparecería un pliegue.
- **Selección.** Con selección, el borde entre la zona seleccionada y la no seleccionada queda nítido en el trazo con selección. Si después se vuelve a deformar esa zona sin selección, ese borde se suaviza unos píxeles.
- **Calibración.** Las velocidades de Fuerza en cada modo son propias, porque ibis Paint no publica las suyas. Hay que compararlas lado a lado en el teléfono.
