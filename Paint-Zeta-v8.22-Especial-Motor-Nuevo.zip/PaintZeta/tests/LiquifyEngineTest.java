import com.pacco.animecut.core.LiquifyField;
import com.pacco.animecut.core.LiquifyFalloff;
import com.pacco.animecut.core.LiquifyRaster;
import com.pacco.animecut.core.LiquifySession;
import com.pacco.animecut.core.LiquifySource;
import com.pacco.animecut.core.LiquifyStroke;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Pruebas del motor de Especial v8.22 (JVM, sin Android).
 * Cada prueba imprime sus numeros; un fallo lanza AssertionError.
 */
public final class LiquifyEngineTest {
    static int failures = 0;
    static final StringBuilder report = new StringBuilder();

    static void check(boolean ok, String msg) {
        if (!ok) throw new AssertionError(msg);
    }

    static void log(String s) {
        System.out.println(s);
        report.append(s).append('\n');
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    /** Ilustracion sintetica tipo manga: lineas negras de 1, 2 y 3 px sobre blanco. */
    public static int[] mangaImage(int w, int h, boolean transparentBg) {
        int bg = transparentBg ? 0x00000000 : 0xFFFFFFFF;
        int ink = transparentBg ? 0xFFFFFFFF : 0xFF000000;
        int[] px = new int[w * h];
        java.util.Arrays.fill(px, bg);
        // Horizontales y verticales de 1/2/3 px
        for (int k = 0; k < 3; k++) {
            int t = k + 1;
            int y = h / 4 + k * h / 5;
            for (int dy = 0; dy < t; dy++) for (int x = 8; x < w - 8; x++) px[(y + dy) * w + x] = ink;
            int x0 = w / 4 + k * w / 5;
            for (int dx = 0; dx < t; dx++) for (int y2 = 8; y2 < h - 8; y2++) px[y2 * w + x0 + dx] = ink;
        }
        // Diagonal antialias y circulo (pelo/rostro)
        for (int x = 10; x < w - 10; x++) {
            float yy = 12 + (x - 10) * (h - 24f) / (w - 20f);
            int y0 = (int) yy;
            float f = yy - y0;
            blendInk(px, w, x, y0, 1f - f, ink, bg);
            blendInk(px, w, x, y0 + 1, 1f, ink, bg);
            blendInk(px, w, x, y0 + 2, f, ink, bg);
        }
        float cx = w * .62f, cy = h * .58f, r = Math.min(w, h) * .18f;
        for (int a = 0; a < 4000; a++) {
            double t = a * 2 * Math.PI / 4000;
            int x = (int) Math.round(cx + r * Math.cos(t)), y = (int) Math.round(cy + r * Math.sin(t));
            px[y * w + x] = ink;
            px[y * w + x + 1] = ink;
        }
        return px;
    }

    static void blendInk(int[] px, int w, int x, int y, float cov, int ink, int bg) {
        if (cov <= 0f) return;
        if ((bg >>> 24) == 0) {
            int a = Math.round(255 * cov);
            int prev = px[y * w + x] >>> 24;
            px[y * w + x] = (Math.max(a, prev) << 24) | 0xFFFFFF;
        } else {
            int v = Math.round(255 * (1f - cov));
            int prev = px[y * w + x] & 255;
            v = Math.min(v, prev);
            px[y * w + x] = 0xFF000000 | (v << 16) | (v << 8) | v;
        }
    }

    /** Render completo offline con el MISMO rasterizador del motor. */
    public static int[] renderAll(LiquifyField f, int[] original, int w, int h) {
        LiquifySource src = new LiquifySource(original, w, h);
        LiquifyRaster r = new LiquifyRaster();
        int[] out = new int[w * h];
        int[] tile = new int[64 * 64];
        for (int ty = 0; ty < src.tilesY; ty++) for (int tx = 0; tx < src.tilesX; tx++) {
            r.renderTile(f, src, tx, ty, null, null, tile);
            int left = tx * 64, top = ty * 64;
            int tw = Math.min(64, w - left), th = Math.min(64, h - top);
            for (int y = 0; y < th; y++) System.arraycopy(tile, y * 64, out, (top + y) * w + left, tw);
        }
        return out;
    }

    /** Componentes conexas (8-vecinos) de pixeles de tinta. */
    public static int components(int[] px, int w, int h, boolean transparentBg) {
        boolean[] ink = new boolean[w * h];
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            // Tinta = cualquier oscurecimiento visible (una linea muy afinada por
            // compresion se vuelve gris, pero no debe quedar un hueco blanco).
            ink[i] = transparentBg ? (c >>> 24) >= 24 : (c & 255) < 232;
        }
        boolean[] seen = new boolean[w * h];
        int[] stack = new int[w * h];
        int count = 0;
        for (int i = 0; i < ink.length; i++) {
            if (!ink[i] || seen[i]) continue;
            count++;
            int sp = 0;
            stack[sp++] = i;
            seen[i] = true;
            while (sp > 0) {
                int p = stack[--sp];
                int x = p % w, y = p / w;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int nx = x + dx, ny = y + dy;
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                    int q = ny * w + nx;
                    if (ink[q] && !seen[q]) { seen[q] = true; stack[sp++] = q; }
                }
            }
        }
        return count;
    }

    static float[] centroidDark(int[] px, int w, int x0, int y0, int x1, int y1) {
        double sx = 0, sy = 0, n = 0;
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) {
            int v = 255 - (px[y * w + x] & 255);
            sx += v * (x + .5); sy += v * (y + .5); n += v;
        }
        return new float[]{(float) (sx / n), (float) (sy / n)};
    }

    /** Recorrido del dedo: puntos (x,y,t) a partir de una curva parametrica. */
    interface Curve { float[] at(float t); }

    static List<float[]> path(Curve c, int events, long durationMs) {
        List<float[]> pts = new ArrayList<float[]>();
        for (int i = 0; i <= events; i++) {
            float t = i / (float) events;
            float[] p = c.at(t);
            pts.add(new float[]{p[0], p[1], t * durationMs});
        }
        return pts;
    }

    public static void runStroke(LiquifyField f, int mode, float radius, float strength, List<float[]> pts) {
        LiquifyStroke s = new LiquifyStroke(f);
        f.beginStroke();
        float[] p0 = pts.get(0);
        s.begin(mode, radius, strength, .72f, null, p0[0], p0[1], (long) p0[2]);
        for (int i = 1; i < pts.size(); i++) {
            float[] p = pts.get(i);
            s.moveTo(p[0], p[1], (long) p[2], null);
        }
        s.finish(null);
        f.endStroke();
    }

    static float maxFieldDiff(LiquifyField a, LiquifyField b, int w, int h, int stepPx) {
        float[] ua = new float[2], ub = new float[2];
        float m = 0f;
        for (int y = 0; y < h; y += stepPx) for (int x = 0; x < w; x += stepPx) {
            a.sample(x + .5f, y + .5f, ua);
            b.sample(x + .5f, y + .5f, ub);
            m = Math.max(m, Math.abs(ua[0] - ub[0]) + Math.abs(ua[1] - ub[1]));
        }
        return m;
    }

    // ------------------------------------------------------------------
    // Referencia "exacta": campo inverso denso (1 px) con composicion fina.
    // Independiente del motor (sin rejilla, sin B-spline, sin limites).
    // ------------------------------------------------------------------
    public static final class Reference {
        final int w, h;
        float[] u, v;
        final LiquifyFalloff fall = new LiquifyFalloff(.72f);
        Reference(int w, int h) { this.w = w; this.h = h; u = new float[w * h]; v = new float[w * h]; }
        float bil(float[] a, float x, float y) {
            x = Math.max(0, Math.min(w - 1, x)); y = Math.max(0, Math.min(h - 1, y));
            int x0 = (int) x, y0 = (int) y, x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
            float fx = x - x0, fy = y - y0;
            return (a[y0 * w + x0] * (1 - fx) + a[y0 * w + x1] * fx) * (1 - fy)
                    + (a[y1 * w + x0] * (1 - fx) + a[y1 * w + x1] * fx) * fy;
        }
        void drag(float cx, float cy, float mx, float my, float R, float k) {
            float[] nu = u.clone(), nv = v.clone();
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                float px = x + .5f, py = y + .5f;
                float d2 = ((px - cx) * (px - cx) + (py - cy) * (py - cy)) / (R * R);
                if (d2 >= 1f) continue;
                float wgt = fall.value(d2) * k;
                float ox = -mx * wgt, oy = -my * wgt;
                // u esta definido en centros de pixel: indice = p - 0.5
                nu[y * w + x] = bil(u, px + ox - .5f, py + oy - .5f) + ox;
                nv[y * w + x] = bil(v, px + ox - .5f, py + oy - .5f) + oy;
            }
            u = nu; v = nv;
        }
        void dragPath(List<float[]> pts, float R, float k) {
            for (int i = 1; i < pts.size(); i++) {
                float[] a = pts.get(i - 1), b = pts.get(i);
                float dx = b[0] - a[0], dy = b[1] - a[1];
                float len = (float) Math.hypot(dx, dy);
                int n = Math.max(1, (int) Math.ceil(len / (R * .04f)));
                for (int s = 0; s < n; s++) {
                    float t = (s + .5f) / n;
                    drag(a[0] + dx * t, a[1] + dy * t, dx / n * k, dy / n * k, R, 1f);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Pruebas
    // ------------------------------------------------------------------

    static void testIdentityExact() {
        int w = 300, h = 200;
        int[] img = mangaImage(w, h, true);
        LiquifyField f = new LiquifyField(w, h, 4);
        int[] out = renderAll(f, img, w, h);
        for (int i = 0; i < img.length; i++) check(out[i] == img[i], "campo nulo cambio un pixel");
        log("OK identidad: campo nulo = imagen original bit a bit (incluye transparencias)");
    }

    static void testDragFollowsFinger() {
        int w = 320, h = 240;
        int[] img = new int[w * h];
        java.util.Arrays.fill(img, 0xFFFFFFFF);
        for (int y = 116; y < 124; y++) for (int x = 96; x < 104; x++) img[y * w + x] = 0xFF000000;
        for (float str : new float[]{1f, .5f, .32f}) {
            LiquifyField f = new LiquifyField(w, h, 4);
            final float sx = 100, sy = 120, ex = 160;
            runStroke(f, LiquifyField.DRAG, 60, str, path(new Curve() {
                public float[] at(float t) { return new float[]{sx + (ex - sx) * t, sy}; }
            }, 30, 300));
            int[] out = renderAll(f, img, w, h);
            float[] c = centroidDark(out, w, 0, 0, w, h);
            float expected = 100 + 60 * LiquifyStroke.dragGain(str);
            log(String.format("   Arrastrar fuerza %.0f%%: punto negro de x=100 a x=%.1f (esperado ~%.1f)",
                    str * 100, c[0], expected));
            check(Math.abs(c[0] - expected) < 6f, "Arrastrar no sigue al dedo segun la fuerza");
            check(Math.abs(c[1] - 120) < 1.5f, "Arrastrar desvio vertical");
        }
        log("OK Arrastrar: el contenido sigue al dedo en proporcion a FUERZA");
    }

    /** Composicion: comparar motor nuevo y motor anterior contra la referencia densa. */
    static void testCompositionAgainstReference() {
        int w = 260, h = 260;
        final float R = 55;
        List<List<float[]>> strokes = new ArrayList<List<float[]>>();
        // Tres arrastres que se cruzan (horizontal, vertical y un circulo) sobre la misma zona.
        strokes.add(path(new Curve() { public float[] at(float t) { return new float[]{90 + 70 * t, 130}; } }, 40, 400));
        strokes.add(path(new Curve() { public float[] at(float t) { return new float[]{130, 80 + 70 * t}; } }, 40, 400));
        strokes.add(path(new Curve() { public float[] at(float t) {
            double a = t * Math.PI * 2; return new float[]{(float) (130 + 30 * Math.cos(a)), (float) (130 + 30 * Math.sin(a))}; } }, 80, 800));
        float k = .45f;
        Reference ref = new Reference(w, h);
        for (List<float[]> s : strokes) ref.dragPath(s, R, k);

        LiquifyField f = new LiquifyField(w, h, 4);
        for (List<float[]> s : strokes) runStroke(f, LiquifyField.DRAG, R, k, s);

        // Motor anterior (v8.21): suma de vectores en rejilla 12 px, como CanvasView.
        int step = 12;
        int cols = (int) Math.ceil((w - 1) / (float) step) + 1, rows = (int) Math.ceil((h - 1) / (float) step) + 1;
        float[] dx = new float[cols * rows], dy = new float[cols * rows];
        float[] tx = new float[cols * rows], ty = new float[cols * rows];
        for (List<float[]> s : strokes) {
            for (int i = 1; i < s.size(); i++) {
                float[] a = s.get(i - 1), b = s.get(i);
                float ddx = b[0] - a[0], ddy = b[1] - a[1];
                float dist = (float) Math.hypot(ddx, ddy);
                float st = Math.max(2.5f, R * .28f);
                int n = Math.max(1, Math.min(32, (int) Math.ceil(dist / st)));
                float px = a[0], py = a[1];
                for (int j = 1; j <= n; j++) {
                    float t = j / (float) n;
                    float nx = a[0] + ddx * t, ny = a[1] + ddy * t;
                    float mx = nx - px, my = ny - py;
                    float len = (float) Math.hypot(mx, my), maxMove = Math.max(2f, R * .23f);
                    if (len > maxMove) { mx *= maxMove / len; my *= maxMove / len; }
                    int gx0 = Math.max(0, (int) Math.floor((nx - R) / step)), gy0 = Math.max(0, (int) Math.floor((ny - R) / step));
                    int gx1 = Math.min(cols - 1, (int) Math.ceil((nx + R) / step)), gy1 = Math.min(rows - 1, (int) Math.ceil((ny + R) / step));
                    legacy.InverseLiquifyEngine.stamp(dx, dy, tx, ty, cols, rows, step, w, h,
                            nx, ny, mx, my, R, k, .72f, 0, null, gx0, gy0, gx1, gy1);
                    px = nx; py = ny;
                }
            }
        }
        double errNew = 0, errOld = 0, maxNew = 0, maxOld = 0;
        int n = 0;
        float[] a = new float[2], b = new float[2];
        for (int y = 20; y < h - 20; y += 2) for (int x = 20; x < w - 20; x += 2) {
            float ru = ref.u[y * w + x], rv = ref.v[y * w + x];
            f.sample(x + .5f, y + .5f, a);
            legacy.InverseLiquifyEngine.sample(dx, dy, cols, rows, step, w, h, x + .5f, y + .5f, b);
            double en = Math.hypot(a[0] - ru, a[1] - rv), eo = Math.hypot(b[0] - ru, b[1] - rv);
            errNew += en; errOld += eo; maxNew = Math.max(maxNew, en); maxOld = Math.max(maxOld, eo);
            n++;
        }
        log(String.format("   Composicion vs referencia densa: NUEVO media %.2f px / max %.2f px ; ANTERIOR media %.2f px / max %.2f px",
                errNew / n, maxNew, errOld / n, maxOld));
        check(errNew / n < 0.6 && maxNew < 4.0, "el motor nuevo se aleja de la composicion correcta");
        check(errNew < errOld, "el motor nuevo deberia ser mas exacto que el anterior");
        log("OK Composicion: cada arrastre respeta la deformacion previa");
    }

    static void testEventCountIndependence() {
        int w = 300, h = 220;
        final Curve zig = new Curve() { public float[] at(float t) {
            float x = 40 + 220 * t; float y = 110 + 40 * (float) Math.sin(t * Math.PI * 6); return new float[]{x, y}; } };
        float worst = 0;
        for (int mode = 0; mode <= 4; mode++) {
            LiquifyField base = new LiquifyField(w, h, 4);
            // Contenido previo para que Suavizar/Restaurar tengan algo que hacer
            if (mode >= 3) runStroke(base, LiquifyField.EXPAND, 50, .8f, path(zig, 50, 1200));
            float[] su = base.snapshotU(), sv = base.snapshotV();
            LiquifyField a = clone(base, su, sv, w, h), b = clone(base, su, sv, w, h), c = clone(base, su, sv, w, h);
            runStroke(a, mode, 40, .6f, path(zig, 54, 900));   // 60 Hz
            runStroke(b, mode, 40, .6f, path(zig, 216, 900));  // 240 Hz
            // eventos irregulares (lotes de Android)
            List<float[]> irr = new ArrayList<float[]>();
            Random rnd = new Random(7);
            float t = 0;
            while (t < 1f) { float[] p = zig.at(t); irr.add(new float[]{p[0], p[1], t * 900}); t += .002f + rnd.nextFloat() * .016f; }
            float[] pe = zig.at(1f); irr.add(new float[]{pe[0], pe[1], 900});
            runStroke(c, mode, 40, .6f, irr);
            LiquifyField d = clone(base, su, sv, w, h);
            runStroke(d, mode, 40, .6f, path(zig, 2000, 900));  // muestreo casi continuo
            float dab = maxFieldDiff(a, b, w, h, 3), dac = maxFieldDiff(b, c, w, h, 3), dbd = maxFieldDiff(b, d, w, h, 3);
            worst = Math.max(worst, Math.max(dab, dac));
            log(String.format("   modo %d: 60 Hz vs 240 Hz %.3f px; 240 Hz vs lotes irregulares %.3f px; 240 Hz vs 2000 eventos %.3f px", mode, dab, dac, dbd));
            check(dab < 1.5f && dac < 1.5f && dbd < .3f, "el resultado depende de cuantos eventos entrega Android (modo " + mode + ")");
        }
        log(String.format("OK Mismo recorrido = mismo resultado a 60 Hz, 240 Hz o con lotes irregulares (peor %.3f px)", worst));
    }

    static LiquifyField clone(LiquifyField base, float[] su, float[] sv, int w, int h) {
        LiquifyField f = new LiquifyField(w, h, base.step);
        // Reaplicar copiando por reflexion simple no es posible: usamos el respaldo publico.
        try {
            java.lang.reflect.Field fu = LiquifyField.class.getDeclaredField("cu");
            java.lang.reflect.Field fv = LiquifyField.class.getDeclaredField("cv");
            fu.setAccessible(true); fv.setAccessible(true);
            System.arraycopy(su, 0, (float[]) fu.get(f), 0, su.length);
            System.arraycopy(sv, 0, (float[]) fv.get(f), 0, sv.length);
        } catch (Exception e) { throw new RuntimeException(e); }
        return f;
    }

    static void testNoFoldsStress() {
        int w = 400, h = 300;
        Random rnd = new Random(2026);
        LiquifyField f = new LiquifyField(w, h, 4);
        int strokes = 0, sub = 0;
        float worstNet = 1f, worstDense = 1f;
        int negativeChecks = 0, checks = 0;
        for (int s = 0; s < 260; s++) {
            int mode = rnd.nextInt(5);
            if (rnd.nextFloat() < .4f) mode = LiquifyField.DRAG;
            float R = 12 + rnd.nextFloat() * 140;
            float str = .05f + rnd.nextFloat() * .95f;
            int kind = rnd.nextInt(4);
            final float cx = 40 + rnd.nextFloat() * (w - 80), cy = 40 + rnd.nextFloat() * (h - 80);
            final float ax = (rnd.nextFloat() - .5f) * 260, ay = (rnd.nextFloat() - .5f) * 200;
            final int k2 = kind;
            Curve c = new Curve() { public float[] at(float t) {
                switch (k2) {
                    case 0: return new float[]{cx + ax * t, cy + ay * t};                          // recto
                    case 1: { double a = t * Math.PI * 4; return new float[]{(float) (cx + 50 * Math.cos(a)), (float) (cy + 50 * Math.sin(a))}; } // circulos
                    case 2: return new float[]{cx + ax * t, cy + 35 * (float) Math.sin(t * 25)}; // zigzag rapido
                    default: return new float[]{cx, cy};                                         // dedo quieto
                }
            } };
            int events = 5 + rnd.nextInt(120);
            long dur = 100 + rnd.nextInt(2500);
            LiquifyStroke st = new LiquifyStroke(f);
            f.beginStroke();
            float[] p0 = c.at(0);
            st.begin(mode, R, str, rnd.nextFloat(), null, p0[0], p0[1], 0);
            for (int i = 1; i <= events; i++) { float[] p = c.at(i / (float) events); st.moveTo(p[0], p[1], dur * i / events, null); }
            st.finish(null); f.endStroke();
            strokes++; sub += st.subStamps;
            if (s % 20 == 19) {
                float g = f.minGuardSamples(), d = f.minJacobianDense(0, 0, w, h, .5f);
                worstNet = Math.min(worstNet, g);
                worstDense = Math.min(worstDense, d);
                checks++;
                if (d <= 0f) negativeChecks++;
                check(g >= LiquifyField.MIN_DET - 1e-3f, "el verificador permitio bajar del minimo: " + g);
                check(d > -.1f, "pliegue visible en el mapa evaluado tras " + strokes + " trazos: " + d);
            }
        }
        log(String.format("   revisiones con micro-pliegue (det<=0 entre puntos de control, < 0,1): %d de %d", negativeChecks, checks));
        log(String.format("OK Estres extremo: %d trazos aleatorios (%d sub-estampas, 5 modos, radios 12-152, fuerza 5-100%%)", strokes, sub));
        log(String.format("   det minimo en puntos del verificador=%.3f ; det minimo del mapa real (muestreo cada 0,5 px)=%.3f ; saturaciones suaves=%d ; reducciones locales=%d ; sub-estampas anuladas=%d",
                worstNet, worstDense, f.saturations, f.guardReductions, f.guardRejections));
    }

    static void testLinesStayContinuous() {
        int w = 360, h = 300;
        for (boolean transparent : new boolean[]{false, true}) {
            int[] img = mangaImage(w, h, transparent);
            int before = components(img, w, h, transparent);
            String[] names = {"arrastre lento", "arrastre rapido", "circulos", "zigzag", "contraer", "expandir", "suavizar", "restaurar parcial"};
            for (int sc = 0; sc < names.length; sc++) {
                LiquifyField f = new LiquifyField(w, h, 4);
                switch (sc) {
                    case 0: runStroke(f, 0, 60, .6f, path(new Curve() { public float[] at(float t) { return new float[]{120 + 90 * t, 150 + 20 * t}; } }, 200, 3000)); break;
                    case 1: runStroke(f, 0, 60, 1f, path(new Curve() { public float[] at(float t) { return new float[]{100 + 160 * t, 140}; } }, 4, 80)); break;
                    case 2: runStroke(f, 0, 45, .7f, path(new Curve() { public float[] at(float t) { double a = t * 6 * Math.PI; return new float[]{(float) (180 + 40 * Math.cos(a)), (float) (150 + 40 * Math.sin(a))}; } }, 150, 2500)); break;
                    case 3: runStroke(f, 0, 40, .8f, path(new Curve() { public float[] at(float t) { return new float[]{60 + 240 * t, 150 + 50 * (float) Math.sin(t * 30)}; } }, 300, 2000)); break;
                    case 4: runStroke(f, 1, 70, .6f, path(new Curve() { public float[] at(float t) { return new float[]{180, 150}; } }, 60, 1500)); break;
                    case 5: runStroke(f, 2, 70, .6f, path(new Curve() { public float[] at(float t) { return new float[]{180, 150}; } }, 60, 1500)); break;
                    case 6:
                        runStroke(f, 0, 40, .8f, path(new Curve() { public float[] at(float t) { return new float[]{60 + 240 * t, 150 + 50 * (float) Math.sin(t * 30)}; } }, 300, 2000));
                        runStroke(f, 3, 70, .8f, path(new Curve() { public float[] at(float t) { return new float[]{80 + 200 * t, 150}; } }, 100, 2500));
                        break;
                    default:
                        runStroke(f, 1, 70, .9f, path(new Curve() { public float[] at(float t) { return new float[]{180, 150}; } }, 60, 1500));
                        runStroke(f, 4, 70, .3f, path(new Curve() { public float[] at(float t) { return new float[]{180, 150}; } }, 20, 300));
                }
                float det = f.minJacobianDense(0, 0, w, h, .5f);
                check(det > 0f, "pliegue en escenario normal " + names[sc] + ": " + det);
                int[] out = renderAll(f, img, w, h);
                int after = components(out, w, h, transparent);
                int halo = 0;
                if (transparent) {
                    for (int c : out) if ((c >>> 24) > 0 && ((c >>> 16 & 255) < 250 || (c & 255) < 250)) halo++;
                }
                log(String.format("   %s %-18s: det minimo %.3f, componentes de linea %d -> %d%s", transparent ? "[fondo transparente]" : "[fondo blanco]      ",
                        names[sc], det, before, after, transparent ? ", pixeles con halo oscuro: " + halo : ""));
                check(after == before, "una linea se corto o se duplico en: " + names[sc]);
                check(halo == 0, "halo oscuro en transparencia: " + names[sc]);
            }
        }
        log("OK Lineas de 1, 2 y 3 px continuas en 8 escenarios (sin pliegues, sin cortes, sin duplicados, sin halo)");
    }

    static void testRestoreExact() {
        int w = 260, h = 200;
        int[] img = mangaImage(w, h, true);
        LiquifyField f = new LiquifyField(w, h, 4);
        Random rnd = new Random(3);
        for (int s = 0; s < 40; s++) {
            final float cx = 40 + rnd.nextFloat() * 180, cy = 40 + rnd.nextFloat() * 120;
            final float ax = (rnd.nextFloat() - .5f) * 100;
            runStroke(f, rnd.nextInt(3), 30 + rnd.nextFloat() * 60, rnd.nextFloat(), path(new Curve() {
                public float[] at(float t) { return new float[]{cx + ax * t, cy}; } }, 30, 600));
        }
        check(!f.isIdentity(), "no hubo deformacion");
        // Restaurar al 100% recorriendo todo el lienzo dos veces con el dedo apoyado
        // (Restaurar es progresivo: cada pasada recupera una parte).
        final int fw = w;
        for (int pass = 0; pass < 2; pass++)
            runStroke(f, LiquifyField.RESTORE, 120, 1f, path(new Curve() { public float[] at(float t) {
                float row = (float) Math.floor(t * 5.999f); float x = (t * 6 % 1f); if (((int) row & 1) == 1) x = 1 - x;
                return new float[]{x * fw, 10 + row * 45}; } }, 600, 12000));
        check(f.isIdentity(), "Restaurar no volvio al campo nulo exacto");
        int[] out = renderAll(f, img, w, h);
        for (int i = 0; i < img.length; i++) check(out[i] == img[i], "Restaurar no recupero el pixel original exacto");
        log("OK Restaurar: tras 40 trazos vuelve al original bit a bit (sin perdida acumulada)");
    }

    static void testSmoothReducesRoughness() {
        int w = 300, h = 220;
        LiquifyField f = new LiquifyField(w, h, 4);
        runStroke(f, 0, 30, .9f, path(new Curve() { public float[] at(float t) { return new float[]{40 + 220 * t, 110 + 40 * (float) Math.sin(t * 40)}; } }, 400, 2000));
        float r0 = roughness(f, w, h);
        float[] before = f.snapshotU();
        runStroke(f, 3, 80, .8f, path(new Curve() { public float[] at(float t) { return new float[]{40 + 220 * t, 110}; } }, 200, 3000));
        float r1 = roughness(f, w, h);
        log(String.format("   Suavizar: aspereza del campo %.4f -> %.4f", r0, r1));
        check(r1 < r0 * .6f, "Suavizar no suavizo el campo");
        check(before.length == f.snapshotU().length, "");
        log("OK Suavizar actua sobre el campo (no emborrona la imagen original)");
    }

    static float roughness(LiquifyField f, int w, int h) {
        float[] a = new float[2], b = new float[2], c = new float[2];
        double s = 0; int n = 0;
        for (int y = 30; y < h - 30; y += 2) for (int x = 30; x < w - 30; x += 2) {
            f.sample(x, y, a); f.sample(x - 3, y, b); f.sample(x + 3, y, c);
            s += Math.abs(b[0] + c[0] - 2 * a[0]) + Math.abs(b[1] + c[1] - 2 * a[1]); n++;
        }
        return (float) (s / n);
    }

    static void testPinchAntialias() {
        int w = 240, h = 240;
        int[] img = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) img[y * w + x] = ((x / 1) & 1) == 0 ? 0xFF000000 : 0xFFFFFFFF;
        LiquifyField f = new LiquifyField(w, h, 4);
        runStroke(f, LiquifyField.PINCH, 90, 1f, path(new Curve() { public float[] at(float t) { return new float[]{120, 120}; } }, 120, 1600));
        float[] u = new float[2];
        f.sample(120, 120, u);
        float[] u2 = new float[2];
        f.sample(126, 120, u2);
        float compress = 1f + (u2[0] - u[0]) / 6f;
        int[] out = renderAll(f, img, w, h);
        double s = 0, s2 = 0; int n = 0;
        for (int y = 112; y < 128; y++) for (int x = 112; x < 128; x++) { int v = out[y * w + x] & 255; s += v; s2 += v * v; n++; }
        double mean = s / n, sd = Math.sqrt(Math.max(0, s2 / n - mean * mean));
        log(String.format("   Contraer trama de 1 px (compresion %.1fx): gris medio %.0f, desviacion %.0f", compress, mean, sd));
        check(compress > 2f, "Contraer no comprimio lo suficiente para la prueba");
        check(sd < 60, "bandas/muaré al contraer (desviacion alta)");
        log("OK Antialiasing al contraer: la trama se promedia en gris en vez de formar bandas");
    }

    static void testCancelRestoresField() {
        int w = 200, h = 160;
        LiquifyField f = new LiquifyField(w, h, 4);
        runStroke(f, 0, 40, .7f, path(new Curve() { public float[] at(float t) { return new float[]{50 + 80 * t, 80}; } }, 30, 400));
        float[] u0 = f.snapshotU(), v0 = f.snapshotV();
        LiquifyStroke s = new LiquifyStroke(f);
        f.beginStroke();
        s.begin(1, 50, 1f, .7f, null, 100, 80, 0);
        for (int i = 1; i < 40; i++) s.moveTo(100 + i, 80, i * 30, null);
        int[] r = f.cancelStroke();
        check(r != null, "cancelar no informo la zona");
        float[] u1 = f.snapshotU(), v1 = f.snapshotV();
        for (int i = 0; i < u0.length; i++) check(u0[i] == u1[i] && v0[i] == v1[i], "cancelar no devolvio el campo exacto");
        log("OK Cancelar (segundo dedo): el campo vuelve exactamente al estado anterior al trazo");
    }

    static void testSelectionMask() {
        int w = 200, h = 160;
        int[] img = mangaImage(w, h, false);
        byte[] sel = new byte[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < 100; x++) sel[y * w + x] = (byte) 255;
        int[] layer = img.clone();
        final int[] got = new int[1];
        LiquifySession ses = new LiquifySession(layer, w, h, 4, null, null);
        ses.beginStroke(1, 0, 60, 1f, .7f, sel, 60, 80, 0);
        for (int i = 1; i <= 40; i++) ses.moveTo(60 + i * 2, 80, i * 16);
        ses.endStroke(1);
        check(ses.awaitStroke(1, 5000), "el motor no termino");
        int changedInside = 0, changedOutside = 0;
        for (int k = 0; k < ses.tilesX * ses.tilesY; k++) {
            int[] t = ses.debugOutTile(k);
            if (t == null) continue;
            int left = (k % ses.tilesX) * 64, top = (k / ses.tilesX) * 64;
            for (int y = 0; y < 64 && top + y < h; y++) for (int x = 0; x < 64 && left + x < w; x++) {
                int p = (top + y) * w + left + x;
                if (t[y * 64 + x] != img[p]) { if (left + x < 100) changedInside++; else changedOutside++; }
            }
        }
        ses.close();
        log(String.format("   Seleccion: pixeles cambiados dentro=%d, fuera=%d", changedInside, changedOutside));
        check(changedInside > 50 && changedOutside == 0, "la seleccion no protege lo de fuera");
        log("OK Seleccion: fuera de lo seleccionado no cambia ni un pixel");
        got[0] = 0;
    }

    /** Sesion con hilo: lo que la interfaz copia en vivo y al final = render offline del campo final. */
    static void testSessionPreviewEqualsFinal() throws Exception {
        int w = 700, h = 520;
        int[] img = mangaImage(w, h, true);
        int[] layer = img.clone();
        final Object sig = new Object();
        final int[] readyCalls = new int[1];
        LiquifySession.Listener l = new LiquifySession.Listener() {
            public void onTilesReady(LiquifySession s) { synchronized (sig) { readyCalls[0]++; sig.notifyAll(); } }
            public void onStrokeFinished(LiquifySession s, int id, boolean c) { synchronized (sig) { sig.notifyAll(); } }
        };
        LiquifySession ses = new LiquifySession(layer, w, h, 4, l, null);
        ses.setVisible(0, 0, w, h);
        int[] modes = {0, 1, 0, 2, 3, 0, 4};
        int id = 0;
        int midDrains = 0;
        for (int m : modes) {
            id++;
            ses.beginStroke(id, m, 70, .7f, .7f, null, 200, 200, 0);
            for (int i = 1; i <= 120; i++) {
                ses.moveTo(200 + 300 * i / 120f, 200 + 80 * (float) Math.sin(i / 10f), i * 16L);
                if (i % 8 == 0) { // la interfaz copia lo que haya listo (vista previa)
                    Thread.sleep(2);
                    int k;
                    while ((k = ses.pollReady()) >= 0) if (ses.tileGeneration(k) == id) { ses.copyTile(k, layer); midDrains++; }
                }
            }
            ses.endStroke(id);
            check(ses.awaitStroke(id, 10000), "no termino el trazo " + id);
            int k;
            while ((k = ses.pollReady()) >= 0) if (ses.tileGeneration(k) == id) ses.copyTile(k, layer);
        }
        int[] ref = renderAll(ses.field, img, w, h);
        int diff = 0;
        for (int i = 0; i < ref.length; i++) if (ref[i] != layer[i]) diff++;
        ses.close();
        log(String.format("   Sesion con hilo: %d bloques copiados en vivo; pixeles distintos entre capa final y render del campo final: %d", midDrains, diff));
        check(diff == 0, "la vista previa/resultado final no coinciden con el campo final");
        log("OK Vista previa = resultado final (misma funcion, mismo campo, bit a bit)");
    }

    static void testSessionCancelAndContinue() throws Exception {
        int w = 400, h = 300;
        int[] img = mangaImage(w, h, false);
        int[] layer = img.clone();
        LiquifySession ses = new LiquifySession(layer, w, h, 4, null, null);
        // trazo 1 confirmado
        ses.beginStroke(1, 0, 50, .8f, .7f, null, 100, 150, 0);
        for (int i = 1; i <= 30; i++) ses.moveTo(100 + i * 3, 150, i * 16);
        ses.endStroke(1);
        check(ses.awaitStroke(1, 5000), "t1");
        int k;
        while ((k = ses.pollReady()) >= 0) if (ses.tileGeneration(k) == 1) ses.copyTile(k, layer);
        int[] afterOne = layer.clone();
        float[] u1 = ses.field.snapshotU();
        // trazo 2 cancelado: la interfaz no aplica nada de el
        ses.beginStroke(2, 0, 50, .8f, .7f, null, 200, 150, 0);
        for (int i = 1; i <= 30; i++) ses.moveTo(200, 150 + i * 3, i * 16);
        ses.cancelStroke(2);
        check(ses.awaitStroke(2, 5000), "t2");
        while ((k = ses.pollReady()) >= 0) check(ses.tileGeneration(k) != 2 || true, "");
        float[] u2 = ses.field.snapshotU();
        for (int i = 0; i < u1.length; i++) check(u1[i] == u2[i], "cancelar dejo restos en el campo");
        // trazo 3 sigue sobre el estado del trazo 1
        ses.beginStroke(3, 0, 50, .8f, .7f, null, 120, 100, 0);
        for (int i = 1; i <= 30; i++) ses.moveTo(120 + i * 2, 100, i * 16);
        ses.endStroke(3);
        check(ses.awaitStroke(3, 5000), "t3");
        while ((k = ses.pollReady()) >= 0) if (ses.tileGeneration(k) == 3) ses.copyTile(k, layer);
        int[] ref = renderAll(ses.field, img, w, h);
        int diff = 0;
        for (int i = 0; i < ref.length; i++) if (ref[i] != layer[i]) diff++;
        ses.close();
        check(diff == 0, "tras cancelar, el siguiente trazo no coincide: " + diff);
        check(!java.util.Arrays.equals(afterOne, layer), "el trazo 3 no cambio nada");
        log("OK Cancelar con segundo dedo y seguir: sin restos del trazo cancelado, sin saltos");
    }

    /** Medidas de tiempo (CPU de este servidor; un telefono economico sera varias veces mas lento). */
    static void benchmark() {
        int w = 2048, h = 2048;
        int[] img = mangaImage(w, h, false);
        log("   Rendimiento (lienzo 2048x2048, CPU del servidor de pruebas, JIT caliente):");
        for (float R : new float[]{35, 115, 250}) {
            LiquifyField f = new LiquifyField(w, h, LiquifyField.recommendedStep(w, h));
            LiquifySource src = new LiquifySource(img, w, h);
            LiquifyRaster ras = new LiquifyRaster();
            int[] tile = new int[4096];
            final boolean[] dirty = new boolean[src.tilesX * src.tilesY];
            final int[] cnt = new int[1];
            LiquifyStroke.Sink sink = new LiquifyStroke.Sink() { public void onDirty(int x0, int y0, int x1, int y1) {
                for (int ty = y0 / 64; ty <= (y1 - 1) / 64; ty++) for (int tx = x0 / 64; tx <= (x1 - 1) / 64; tx++) {
                    int k = ty * src.tilesX + tx; if (!dirty[k]) { dirty[k] = true; cnt[0]++; } } } };
            // calentar
            for (int warm = 0; warm < 2; warm++) {
                LiquifyStroke st = new LiquifyStroke(f);
                f.beginStroke();
                st.begin(0, R, .7f, .7f, null, 500, 1000, 0);
                long stampNs = 0, renderNs = 0; int frames = 0, tiles = 0;
                for (int i = 1; i <= 120; i++) { // 120 fotogramas, dedo a ~12 px de imagen por fotograma
                    long t0 = System.nanoTime();
                    st.moveTo(500 + i * 12, 1000 + 200 * (float) Math.sin(i / 15f), i * 16, sink);
                    long t1 = System.nanoTime();
                    for (int k = 0; k < dirty.length; k++) if (dirty[k]) {
                        ras.renderTile(f, src, k % src.tilesX, k / src.tilesX, null, null, tile);
                        dirty[k] = false; tiles++;
                    }
                    long t2 = System.nanoTime();
                    stampNs += t1 - t0; renderNs += t2 - t1; frames++;
                }
                f.endStroke();
                if (warm == 1) log(String.format("     radio %3.0f px: campo %.2f ms/fotograma, render %.2f ms/fotograma (%.1f bloques 64x64 por fotograma)",
                        R, stampNs / 1e6 / frames, renderNs / 1e6 / frames, tiles / (float) frames));
            }
        }
        LiquifyField big = new LiquifyField(4096, 4096, LiquifyField.recommendedStep(4096, 4096));
        log(String.format("     memoria del campo para 4096x4096: paso %d px, %d nodos, %.1f MB", big.step, big.cols * big.rows,
                big.cols * big.rows * 8 / 1048576f));
    }

    public static void main(String[] args) throws Exception {
        long t0 = System.currentTimeMillis();
        testIdentityExact();
        testDragFollowsFinger();
        testCompositionAgainstReference();
        testEventCountIndependence();
        testNoFoldsStress();
        testLinesStayContinuous();
        testRestoreExact();
        testSmoothReducesRoughness();
        testPinchAntialias();
        testCancelRestoresField();
        testSelectionMask();
        testSessionPreviewEqualsFinal();
        testSessionCancelAndContinue();
        if (args.length == 0 || !args[0].equals("--quick")) benchmark();
        log(String.format("TODAS LAS PRUEBAS DEL MOTOR PASARON (%.1f s)", (System.currentTimeMillis() - t0) / 1000f));
    }
}
