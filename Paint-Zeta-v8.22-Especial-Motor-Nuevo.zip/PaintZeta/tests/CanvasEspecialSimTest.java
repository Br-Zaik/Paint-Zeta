import android.graphics.Matrix;
import android.os.Sim;
import android.os.SystemClock;
import android.view.Choreographer;
import android.view.MotionEvent;
import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.LiquifyField;
import com.pacco.animecut.core.LiquifySession;
import com.pacco.animecut.core.Project;
import com.pacco.animecut.view.CanvasView;
import java.lang.reflect.Field;
import java.util.Arrays;

/**
 * Prueba de INTEGRACION de Especial con el CanvasView REAL de Paint Zeta,
 * ejecutado en una JVM con una simulacion minima de Android (tests/androidsim).
 * Recorre el mismo codigo que en el telefono: onTouchEvent -> motor en otro hilo
 * -> copia de bloques por fotograma -> confirmacion -> Deshacer/Rehacer.
 * NO es Android real: no mide la pantalla, la GPU ni el panel tactil.
 */
public final class CanvasEspecialSimTest {
    static void check(boolean ok, String m) { if (!ok) throw new AssertionError(m); }
    static void log(String s) { System.out.println(s); }

    static CanvasView cv;
    static Project project;
    static int W = 640, H = 480;

    static Object get(String name) throws Exception {
        Field f = CanvasView.class.getDeclaredField(name);
        f.setAccessible(true);
        return f.get(cv);
    }

    static int[] layer() { return project.layers.get(0).px(); }

    static float[] screen(float ix, float iy) throws Exception {
        Matrix m = (Matrix) get("view");
        float[] p = {ix, iy};
        m.mapPoints(p);
        return p;
    }

    static void touch(int action, float[]... pts) {
        float[] xs = new float[pts.length], ys = new float[pts.length];
        for (int i = 0; i < pts.length; i++) { xs[i] = pts[i][0]; ys[i] = pts[i][1]; }
        cv.onTouchEvent(new MotionEvent(action, xs, ys, null, null, null, SystemClock.uptimeMillis()));
    }

    /** Arrastre de un dedo a lo largo de puntos de IMAGEN; 2 puntos de historial por evento (120 Hz en lotes de 60 Hz). */
    static void stroke(float[][] imgPts, long durationMs, boolean lift) throws Exception {
        float[] s0 = screen(imgPts[0][0], imgPts[0][1]);
        touch(MotionEvent.ACTION_DOWN, s0);
        int frames = Math.max(2, (int) (durationMs / 16));
        int idx = 0;
        for (int f = 1; f <= frames; f++) {
            Sim.pump(16);
            float t1 = f / (float) frames, t0 = (f - .5f) / frames;
            float[] a = at(imgPts, t0), b = at(imgPts, t1);
            float[] sa = screen(a[0], a[1]), sb = screen(b[0], b[1]);
            long now = SystemClock.uptimeMillis();
            cv.onTouchEvent(new MotionEvent(MotionEvent.ACTION_MOVE, new float[]{sb[0]}, new float[]{sb[1]},
                    new float[]{sa[0]}, new float[]{sa[1]}, new long[]{now - 8}, now));
            idx++;
        }
        if (lift) {
            float[] e = screen(imgPts[imgPts.length - 1][0], imgPts[imgPts.length - 1][1]);
            touch(MotionEvent.ACTION_UP, e);
        }
    }

    static float[] at(float[][] pts, float t) {
        float x = t * (pts.length - 1);
        int i = Math.min(pts.length - 2, (int) x);
        float f = x - i;
        return new float[]{pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f};
    }

    static void settle() { Sim.pump(250); }

    static int diff(int[] a, int[] b) { int n = 0; for (int i = 0; i < a.length; i++) if (a[i] != b[i]) n++; return n; }

    static int[] expectedFromSession() throws Exception {
        LiquifySession s = (LiquifySession) get("liquifySession");
        check(s != null, "sin sesion");
        // Original de ESTA sesion: bloques capturados por el motor + resto de la capa.
        int[] src = layer().clone();
        for (int k = 0; k < s.tilesX * s.tilesY; k++) {
            if (!s.source.isCaptured(k)) continue;
            int[] t = s.source.tile(k);
            int left = (k % s.tilesX) * 64, top = (k / s.tilesX) * 64;
            for (int y = 0; y < 64 && top + y < H; y++)
                System.arraycopy(t, y * 64, src, (top + y) * W + left, Math.min(64, W - left));
        }
        return LiquifyEngineTest.renderAll(s.field, src, W, H);
    }

    static int[] original;

    public static void main(String[] args) throws Exception {
        Sim.main = Thread.currentThread();
        original = LiquifyEngineTest.mangaImage(W, H, false);
        project = new Project(W, H);
        project.layers.add(new Layer("imagen", original.clone()));
        project.active = 0;
        cv = new CanvasView(new android.content.Context() { });
        cv.setProject(project);
        Sim.pump(50);
        cv.setMode(CanvasView.MODE_LIQUIFY);
        cv.setBrushSize(140);
        cv.setEffectStrength(.7f);
        cv.setLiquifyType(0);
        Sim.pump(20);

        // 1) Arrastre real: vista previa en vivo, confirmacion sin bloquear, igual al render del campo
        Choreographer.FRAME_NANOS.clear();
        stroke(new float[][]{{200, 240}, {330, 260}, {420, 200}}, 700, false);
        int liveChanged = diff(layer(), original);
        check(liveChanged > 1000, "la vista previa no mostro la deformacion durante el gesto: " + liveChanged);
        touch(MotionEvent.ACTION_UP, screen(420, 200));
        int pending = (Integer) get("liquifyPendingCommit");
        settle();
        int[] afterOne = layer().clone();
        int d1 = diff(afterOne, expectedFromSession());
        log("   1 dedo: pixeles deformados durante el gesto=" + liveChanged + ", confirmacion asincrona pendiente al soltar=" + (pending != 0)
                + ", diferencia capa vs campo final=" + d1);
        check(d1 == 0, "la capa confirmada no coincide con el campo final");
        long max = 0, sum = 0;
        for (long n : Choreographer.FRAME_NANOS) { max = Math.max(max, n); sum += n; }
        log(String.format("   trabajo del hilo de interfaz por fotograma (copiar bloques + componer): medio %.2f ms, maximo %.2f ms (%d fotogramas)",
                sum / 1e6 / Math.max(1, Choreographer.FRAME_NANOS.size()), max / 1e6, Choreographer.FRAME_NANOS.size()));
        log("OK Arrastrar con el CanvasView real: vista previa en vivo y resultado final identicos");

        // 2) Deshacer / Rehacer
        cv.doUndo();
        check(diff(layer(), original) == 0, "Deshacer no devolvio el original exacto");
        cv.doRedo();
        check(diff(layer(), afterOne) == 0, "Rehacer no devolvio el trazo exacto");
        log("OK Deshacer/Rehacer de Especial exactos");

        // 3) Confirmacion pendiente + Deshacer inmediato (sin esperar fotogramas)
        stroke(new float[][]{{300, 120}, {300, 300}}, 300, true);
        cv.doUndo(); // debe esperar al motor y deshacer EXACTAMENTE ese trazo
        check(diff(layer(), afterOne) == 0, "Deshacer inmediato tras soltar no fue exacto");
        settle();
        check(diff(layer(), afterOne) == 0, "un bloque tardio sobrescribio el Deshacer");
        log("OK Deshacer justo al soltar el dedo: espera al motor y no quedan bloques tardios");

        // 4) Segundo dedo al empezar (< 400 ms): sin trazo falso, sin historial
        int[] before = layer().clone();
        float[] a = screen(250, 250), b = screen(250, 330);
        touch(MotionEvent.ACTION_DOWN, a);
        Sim.pump(16);
        long now = SystemClock.uptimeMillis();
        float[] a2 = screen(270, 250);
        cv.onTouchEvent(new MotionEvent(MotionEvent.ACTION_MOVE, new float[]{a2[0]}, new float[]{a2[1]}, null, null, null, now));
        Sim.pump(60);
        float[] a3 = screen(300, 250);
        cv.onTouchEvent(new MotionEvent(MotionEvent.ACTION_MOVE, new float[]{a3[0]}, new float[]{a3[1]}, null, null, null, SystemClock.uptimeMillis()));
        Sim.pump(40);
        touch(MotionEvent.ACTION_POINTER_DOWN, a3, b);
        for (int i = 0; i < 10; i++) { // pan + zoom con dos dedos
            Sim.pump(16);
            touch(MotionEvent.ACTION_MOVE, new float[]{a3[0] + i * 6, a3[1] + i * 3}, new float[]{b[0] + i * 9, b[1] + i * 7});
        }
        touch(MotionEvent.ACTION_POINTER_UP, new float[]{a3[0] + 60, a3[1] + 30}, new float[]{b[0] + 90, b[1] + 70});
        Sim.pump(16);
        touch(MotionEvent.ACTION_MOVE, new float[]{a3[0] + 80, a3[1] + 40});   // el dedo que queda NO pinta
        touch(MotionEvent.ACTION_UP, new float[]{a3[0] + 80, a3[1] + 40});
        settle();
        check(diff(layer(), before) == 0, "el segundo dedo dejo una deformacion falsa: " + diff(layer(), before));
        cv.doUndo(); // el ultimo cambio del historial sigue siendo el Rehacer anterior
        check(diff(layer(), original) == 0, "el gesto de dos dedos altero el historial");
        cv.doRedo();
        log("OK Dos dedos: cancelar al empezar, mover/ampliar y levantar sin saltos ni trazos falsos");

        // 4b) Segundo dedo DESPUES de 400 ms: el trazo se confirma y luego solo se navega
        stroke(new float[][]{{150, 150}, {230, 170}}, 520, false);
        float[] f1 = screen(230, 170), f2 = screen(230, 260);
        touch(MotionEvent.ACTION_POINTER_DOWN, f1, f2);
        Sim.pump(30);
        int[] committed = null;
        for (int i = 0; i < 12; i++) {
            Sim.pump(16);
            touch(MotionEvent.ACTION_MOVE, new float[]{f1[0] - i * 8, f1[1] + i * 4}, new float[]{f2[0] - i * 5, f2[1] + i * 9});
            if (i == 2) { settle(); committed = layer().clone(); }
        }
        touch(MotionEvent.ACTION_POINTER_UP, f1, f2);
        touch(MotionEvent.ACTION_UP, f1);
        settle();
        check(committed != null && diff(layer(), committed) == 0, "navegar con dos dedos cambio la imagen");
        check(diff(layer(), expectedFromSession()) == 0, "el trazo confirmado por el segundo dedo no coincide con el campo");
        cv.doUndo();
        cv.doRedo();
        check(diff(layer(), committed) == 0, "Deshacer/Rehacer del trazo confirmado por el segundo dedo");
        log("OK Segundo dedo tras 400 ms: confirma el trazo y luego solo mueve/amplia (sin deformar)");

        // 5) Contraer con el dedo quieto (avanza con el tiempo, no con eventos)
        cv.setLiquifyType(1);
        int[] beforePinch = layer().clone();
        float[] c = screen(330, 330);
        touch(MotionEvent.ACTION_DOWN, c);
        Sim.pump(900);
        touch(MotionEvent.ACTION_UP, c);
        settle();
        int pinchChanged = diff(layer(), beforePinch);
        int dp = diff(layer(), expectedFromSession());
        log("   Contraer con el dedo quieto 0,9 s: pixeles cambiados=" + pinchChanged + ", diferencia con el campo=" + dp);
        check(pinchChanged > 500 && dp == 0, "Contraer con presion fija no actuo o no coincide");
        log("OK Contraer con el dedo quieto avanza fotograma a fotograma");

        // 6) Restaurar todo: vuelve al original de la sesion
        cv.setLiquifyType(4);
        cv.setEffectStrength(1f);
        cv.setBrushSize(400);
        for (int pass = 0; pass < 3; pass++) {
            stroke(new float[][]{{0, 60}, {640, 60}, {640, 180}, {0, 180}, {0, 300}, {640, 300}, {640, 420}, {0, 420}}, 3000, true);
            settle();
        }
        // La sesion empezo en el paso 5 (tras Rehacer): su original es beforePinch.
        int left = diff(layer(), beforePinch);
        LiquifySession rs = (LiquifySession) get("liquifySession");
        if (left != 0) {
            int minx = W, miny = H, maxx = 0, maxy = 0; int[] L = layer();
            for (int i = 0; i < L.length; i++) if (L[i] != beforePinch[i]) { minx = Math.min(minx, i % W); maxx = Math.max(maxx, i % W); miny = Math.min(miny, i / W); maxy = Math.max(maxy, i / W); }
            log("   (diagnostico) campo nulo=" + rs.field.isIdentity() + " zona distinta " + minx + "," + miny + " - " + maxx + "," + maxy
                + " max|U|=" + rs.field.maxAbs(0, 0, rs.field.cols, rs.field.rows) + " diff con campo=" + diff(layer(), expectedFromSession()));
        }
        log("   Restaurar al 100% con 3 pasadas: pixeles distintos del original de la sesion=" + left);
        check(left == 0, "Restaurar no recupero el original exacto");
        log("OK Restaurar devuelve el dibujo original exacto");

        // 7) Cambiar de herramienta y volver: la sesion se cierra y se reabre limpia
        cv.setMode(CanvasView.MODE_PAINT);
        check(get("liquifySession") == null, "la sesion no se cerro al cambiar de herramienta");
        cv.setMode(CanvasView.MODE_LIQUIFY);
        cv.setLiquifyType(2);
        cv.setBrushSize(120);
        cv.setEffectStrength(.6f);
        int[] beforeExp = layer().clone();
        stroke(new float[][]{{320, 240}, {322, 241}}, 600, true);
        settle();
        check(diff(layer(), beforeExp) > 0, "Expandir no actuo tras reabrir");
        check(diff(layer(), expectedFromSession()) == 0, "Expandir: capa distinta del campo");
        log("OK Cambiar de herramienta y volver: sesion nueva, Expandir correcto");

        LiquifySession s = (LiquifySession) get("liquifySession");
        check(!s.isFailed(), "el motor marco error");
        cv.setMode(CanvasView.MODE_PAINT);
        log("TODAS LAS PRUEBAS DE INTEGRACION (CanvasView real + Android simulado) PASARON");
        System.exit(0);
    }
}
