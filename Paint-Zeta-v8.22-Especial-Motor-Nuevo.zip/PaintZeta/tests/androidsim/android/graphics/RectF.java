package android.graphics;
public class RectF {
  public float left, top, right, bottom;
  public RectF(){} public RectF(float l,float t,float r,float b){left=l;top=t;right=r;bottom=b;} public RectF(Rect r){this(r.left,r.top,r.right,r.bottom);} public RectF(RectF r){this(r.left,r.top,r.right,r.bottom);}
  public void set(float l,float t,float r,float b){left=l;top=t;right=r;bottom=b;} public void set(Rect r){set(r.left,r.top,r.right,r.bottom);} public void set(RectF r){set(r.left,r.top,r.right,r.bottom);}
  public boolean intersect(RectF r){return intersect(r.left,r.top,r.right,r.bottom);}
  public boolean intersect(float l,float t,float r,float b){ if(left<r&&l<right&&top<b&&t<bottom){ if(left<l)left=l; if(top<t)top=t; if(right>r)right=r; if(bottom>b)bottom=b; return true;} return false; }
  public float width(){return right-left;} public float height(){return bottom-top;} public float centerX(){return (left+right)*.5f;} public float centerY(){return (top+bottom)*.5f;}
  public boolean isEmpty(){return left>=right||top>=bottom;}
  public void union(RectF r){union(r.left,r.top,r.right,r.bottom);} public void union(float x,float y){ if(x<left)left=x; else if(x>right)right=x; if(y<top)top=y; else if(y>bottom)bottom=y; }
  public void union(float l,float t,float r,float b){ if(l>=r||t>=b)return; if(left<right&&top<bottom){left=Math.min(left,l);top=Math.min(top,t);right=Math.max(right,r);bottom=Math.max(bottom,b);} else {left=l;top=t;right=r;bottom=b;} }
  public void inset(float dx,float dy){left+=dx;top+=dy;right-=dx;bottom-=dy;} public void offset(float dx,float dy){left+=dx;right+=dx;top+=dy;bottom+=dy;} public boolean contains(float x,float y){return left<right&&top<bottom&&x>=left&&x<right&&y>=top&&y<bottom;}
  public void round(Rect r){r.set(Math.round(left),Math.round(top),Math.round(right),Math.round(bottom));} public void roundOut(Rect r){r.set((int)Math.floor(left),(int)Math.floor(top),(int)Math.ceil(right),(int)Math.ceil(bottom));} public void setEmpty(){left=top=right=bottom=0;} public void sort(){ if(left>right){float t=left;left=right;right=t;} if(top>bottom){float t=top;top=bottom;bottom=t;} }
}
