package android.graphics;
public class Canvas {
  public Canvas(){} public Canvas(Bitmap b){}
  public int save(){return 0;} public void restore(){} public void restoreToCount(int c){} public int saveLayer(RectF r, Paint p){return 0;} public int saveLayer(float l,float t,float r,float b, Paint p){return 0;} public int saveLayerAlpha(RectF r,int a){return 0;}
  public void translate(float x,float y){} public void scale(float x,float y){} public void scale(float x,float y,float px,float py){} public void rotate(float d){} public void rotate(float d,float px,float py){} public void concat(Matrix m){} public void setMatrix(Matrix m){}
  public boolean clipRect(Rect r){return true;} public boolean clipRect(RectF r){return true;} public boolean clipRect(float l,float t,float r,float b){return true;} public boolean clipRect(int l,int t,int r,int b){return true;} public boolean clipPath(Path p){return true;} public boolean clipOutPath(Path p){return true;} public boolean clipOutRect(RectF r){return true;}
  public void drawBitmap(Bitmap b,float x,float y,Paint p){} public void drawBitmap(Bitmap b,Rect s,Rect d,Paint p){} public void drawBitmap(Bitmap b,Rect s,RectF d,Paint p){} public void drawBitmap(Bitmap b,Matrix m,Paint p){}
  public void drawBitmapMesh(Bitmap b,int mw,int mh,float[] v,int vo,int[] c,int co,Paint p){}
  public void drawRect(RectF r,Paint p){} public void drawRect(Rect r,Paint p){} public void drawRect(float l,float t,float r,float b,Paint p){}
  public void drawRoundRect(RectF r,float rx,float ry,Paint p){} public void drawRoundRect(float l,float t,float r,float b,float rx,float ry,Paint p){}
  public void drawCircle(float x,float y,float r,Paint p){} public void drawLine(float a,float b,float c,float d,Paint p){} public void drawLines(float[] p,Paint pa){} public void drawLines(float[] p,int o,int c,Paint pa){} public void drawPath(Path p,Paint pa){}
  public void drawPoint(float x,float y,Paint p){} public void drawPoints(float[] p,Paint pa){} public void drawColor(int c){} public void drawColor(int c, PorterDuff.Mode m){} public void drawARGB(int a,int r,int g,int b){} public void drawRGB(int r,int g,int b){}
  public void drawText(String t,float x,float y,Paint p){} public void drawOval(RectF r,Paint p){} public void drawOval(float l,float t,float r,float b,Paint p){} public void drawArc(RectF r,float s,float sw,boolean u,Paint p){} public void drawArc(float l,float t,float r,float b,float s,float sw,boolean u,Paint p){} public void drawPaint(Paint p){}
  public int getWidth(){return 0;} public int getHeight(){return 0;} public void getMatrix(Matrix m){} public Matrix getMatrix(){return null;} public void setBitmap(Bitmap b){}
}
