package android.graphics;
public class BitmapFactory {
  public static class Options { public boolean inJustDecodeBounds, inMutable, inPremultiplied; public int outWidth, outHeight, inSampleSize; public Bitmap.Config inPreferredConfig; }
  public static Bitmap decodeStream(java.io.InputStream s){return null;} public static Bitmap decodeStream(java.io.InputStream s, Rect r, Options o){return null;}
  public static Bitmap decodeFile(String f){return null;} public static Bitmap decodeFile(String f, Options o){return null;}
  public static Bitmap decodeByteArray(byte[] b,int o,int l){return null;} public static Bitmap decodeByteArray(byte[] b,int o,int l, Options op){return null;}
}
