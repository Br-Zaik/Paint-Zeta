package android.graphics;
public class Color {
  public static final int BLACK=0xFF000000, WHITE=-1, TRANSPARENT=0, RED=0xFFFF0000, GREEN=0xFF00FF00, BLUE=0xFF0000FF, GRAY=0xFF888888, DKGRAY=0xFF444444, LTGRAY=0xFFCCCCCC, YELLOW=0xFFFFFF00, CYAN=0xFF00FFFF, MAGENTA=0xFFFF00FF;
  public static int argb(int a,int r,int g,int b){return 0;} public static int rgb(int r,int g,int b){return 0;} public static int alpha(int c){return 0;} public static int red(int c){return 0;} public static int green(int c){return 0;} public static int blue(int c){return 0;}
  public static void colorToHSV(int c,float[] h){} public static int HSVToColor(float[] h){return 0;} public static int HSVToColor(int a,float[] h){return 0;} public static void RGBToHSV(int r,int g,int b,float[] h){} public static int parseColor(String s){return 0;}
}
