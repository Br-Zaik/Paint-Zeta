package android.graphics;
/** Matriz afin funcional (x' = a x + b y + tx ; y' = c x + d y + ty). */
public class Matrix {
  public static final int MSCALE_X=0,MSKEW_X=1,MTRANS_X=2,MSKEW_Y=3,MSCALE_Y=4,MTRANS_Y=5,MPERSP_0=6,MPERSP_1=7,MPERSP_2=8;
  double a=1,b=0,tx=0,c=0,d=1,ty=0;
  public Matrix(){} public Matrix(Matrix m){set(m);}
  public void set(Matrix m){ if(m==null){reset();return;} a=m.a;b=m.b;tx=m.tx;c=m.c;d=m.d;ty=m.ty; } public void reset(){a=1;b=0;tx=0;c=0;d=1;ty=0;}
  public boolean isIdentity(){return a==1&&b==0&&tx==0&&c==0&&d==1&&ty==0;}
  private void post(double A,double B,double TX,double C,double D,double TY){ double na=A*a+B*c, nb=A*b+B*d, ntx=A*tx+B*ty+TX, nc=C*a+D*c, nd=C*b+D*d, nty=C*tx+D*ty+TY; a=na;b=nb;tx=ntx;c=nc;d=nd;ty=nty; }
  private void pre(double A,double B,double TX,double C,double D,double TY){ double na=a*A+b*C, nb=a*B+b*D, ntx=a*TX+b*TY+tx, nc=c*A+d*C, nd=c*B+d*D, nty=c*TX+d*TY+ty; a=na;b=nb;tx=ntx;c=nc;d=nd;ty=nty; }
  public boolean invert(Matrix m){ double det=a*d-b*c; if(Math.abs(det)<1e-12) return false; double ia=d/det, ib=-b/det, ic=-c/det, id=a/det; double itx=-(ia*tx+ib*ty), ity=-(ic*tx+id*ty); m.a=ia;m.b=ib;m.c=ic;m.d=id;m.tx=itx;m.ty=ity; return true; }
  public void setTranslate(float x,float y){reset();tx=x;ty=y;} public void setScale(float x,float y){reset();a=x;d=y;} public void setScale(float x,float y,float px,float py){reset();postScale(x,y,px,py);} public void setRotate(float deg){reset();postRotate(deg);} public void setRotate(float deg,float px,float py){reset();postRotate(deg,px,py);}
  public boolean postTranslate(float x,float y){post(1,0,x,0,1,y);return true;} public boolean postScale(float x,float y){post(x,0,0,0,y,0);return true;} public boolean postScale(float x,float y,float px,float py){post(x,0,px-x*px,0,y,py-y*py);return true;}
  public boolean postRotate(float deg){double r=Math.toRadians(deg),cs=Math.cos(r),sn=Math.sin(r);post(cs,-sn,0,sn,cs,0);return true;} public boolean postRotate(float deg,float px,float py){postTranslate(-px,-py);postRotate(deg);postTranslate(px,py);return true;}
  public boolean postConcat(Matrix m){post(m.a,m.b,m.tx,m.c,m.d,m.ty);return true;}
  public boolean preTranslate(float x,float y){pre(1,0,x,0,1,y);return true;} public boolean preScale(float x,float y){pre(x,0,0,0,y,0);return true;} public boolean preScale(float x,float y,float px,float py){pre(x,0,px-x*px,0,y,py-y*py);return true;}
  public boolean preRotate(float deg){double r=Math.toRadians(deg),cs=Math.cos(r),sn=Math.sin(r);pre(cs,-sn,0,sn,cs,0);return true;} public boolean preRotate(float deg,float px,float py){Matrix t=new Matrix();t.setRotate(deg,px,py);return preConcat(t);} public boolean preConcat(Matrix m){pre(m.a,m.b,m.tx,m.c,m.d,m.ty);return true;}
  public void setConcat(Matrix x, Matrix y){Matrix r=new Matrix(x);r.preConcat(y);set(r);}
  public void mapPoints(float[] p){mapPoints(p,0,p,0,p.length/2);} public void mapPoints(float[] dst,float[] src){mapPoints(dst,0,src,0,src.length/2);}
  public void mapPoints(float[] dst,int di,float[] src,int si,int n){ for(int i=0;i<n;i++){ double x=src[si+2*i], y=src[si+2*i+1]; dst[di+2*i]=(float)(a*x+b*y+tx); dst[di+2*i+1]=(float)(c*x+d*y+ty);} }
  public void mapVectors(float[] v){ for(int i=0;i+1<v.length;i+=2){double x=v[i],y=v[i+1]; v[i]=(float)(a*x+b*y); v[i+1]=(float)(c*x+d*y);} }
  public boolean mapRect(RectF r){return mapRect(r,r);} public boolean mapRect(RectF dst,RectF s){ float[] p={s.left,s.top,s.right,s.top,s.left,s.bottom,s.right,s.bottom}; mapPoints(p); float l=Math.min(Math.min(p[0],p[2]),Math.min(p[4],p[6])), r=Math.max(Math.max(p[0],p[2]),Math.max(p[4],p[6])), t=Math.min(Math.min(p[1],p[3]),Math.min(p[5],p[7])), bo=Math.max(Math.max(p[1],p[3]),Math.max(p[5],p[7])); dst.set(l,t,r,bo); return b==0&&c==0; }
  public float mapRadius(float r){return (float)(r*Math.sqrt(Math.abs(a*d-b*c)));}
  public void getValues(float[] v){v[0]=(float)a;v[1]=(float)b;v[2]=(float)tx;v[3]=(float)c;v[4]=(float)d;v[5]=(float)ty;v[6]=0;v[7]=0;v[8]=1;} public void setValues(float[] v){a=v[0];b=v[1];tx=v[2];c=v[3];d=v[4];ty=v[5];}
  public boolean setPolyToPoly(float[] s,int si,float[] d,int di,int n){reset();return true;} public boolean setRectToRect(RectF s,RectF d,ScaleToFit f){ reset(); float sx=d.width()/s.width(), sy=d.height()/s.height(); a=sx; this.d=sy; tx=d.left-s.left*sx; ty=d.top-s.top*sy; return true; }
  public enum ScaleToFit {FILL,START,CENTER,END}
}
