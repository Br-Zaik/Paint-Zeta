package android.graphics; public class ColorMatrix { public ColorMatrix(){} public ColorMatrix(float[] a){} public void set(float[] a){} public void setSaturation(float s){} }
