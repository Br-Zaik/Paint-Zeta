package android.graphics; public class PorterDuffColorFilter extends ColorFilter { public PorterDuffColorFilter(int c, PorterDuff.Mode m){} }
