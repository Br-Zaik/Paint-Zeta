package android.graphics;
public class Path {
  public enum Direction {CW, CCW} public enum FillType {WINDING, EVEN_ODD, INVERSE_WINDING, INVERSE_EVEN_ODD}
  public Path(){} public Path(Path p){}
  public void reset(){} public void rewind(){} public void moveTo(float x,float y){} public void lineTo(float x,float y){} public void quadTo(float a,float b,float c,float d){} public void cubicTo(float a,float b,float c,float d,float e,float f){} public void close(){}
  public void addCircle(float x,float y,float r,Direction d){} public void addRect(RectF r,Direction d){} public void addRect(float l,float t,float r,float b,Direction d){} public void addPath(Path p){} public void addPath(Path p,Matrix m){} public void addOval(RectF r,Direction d){} public void addRoundRect(RectF r,float rx,float ry,Direction d){}
  public void transform(Matrix m){} public void transform(Matrix m,Path d){} public void computeBounds(RectF r,boolean e){} public boolean isEmpty(){return true;} public void setFillType(FillType f){} public FillType getFillType(){return null;} public void offset(float dx,float dy){} public void set(Path p){} public void rLineTo(float x,float y){} public void arcTo(RectF r,float s,float sw){} public void arcTo(RectF r,float s,float sw,boolean f){}
}
