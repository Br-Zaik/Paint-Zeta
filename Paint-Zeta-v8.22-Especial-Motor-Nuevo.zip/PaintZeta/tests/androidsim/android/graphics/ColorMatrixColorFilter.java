package android.graphics; public class ColorMatrixColorFilter extends ColorFilter { public ColorMatrixColorFilter(ColorMatrix m){} public ColorMatrixColorFilter(float[] a){} }
