package android.graphics;
public class Paint {
  public static final int ANTI_ALIAS_FLAG=1, FILTER_BITMAP_FLAG=2, DITHER_FLAG=4;
  public enum Style {FILL, STROKE, FILL_AND_STROKE} public enum Cap {BUTT, ROUND, SQUARE} public enum Join {MITER, ROUND, BEVEL} public enum Align {LEFT, CENTER, RIGHT}
  public Paint(){} public Paint(int f){} public Paint(Paint p){}
  public void setColor(int c){} public int getColor(){return 0;} public void setAlpha(int a){} public int getAlpha(){return 0;} public void setStyle(Style s){} public void setStrokeWidth(float w){} public float getStrokeWidth(){return 0;}
  public void setStrokeCap(Cap c){} public void setStrokeJoin(Join j){} public void setAntiAlias(boolean a){} public void setFilterBitmap(boolean f){} public void setDither(boolean d){}
  public Xfermode setXfermode(Xfermode x){return x;} public PathEffect setPathEffect(PathEffect p){return p;} public Shader setShader(Shader s){return s;} public ColorFilter setColorFilter(ColorFilter c){return c;}
  public void setTextSize(float s){} public float getTextSize(){return 0;} public void setTextAlign(Align a){} public float measureText(String s){return 0;} public Typeface setTypeface(Typeface t){return t;} public void setFakeBoldText(boolean b){}
  public void setShadowLayer(float r,float dx,float dy,int c){} public void clearShadowLayer(){} public void setARGB(int a,int r,int g,int b){} public void set(Paint p){} public void reset(){} public void setFlags(int f){}
  public float ascent(){return 0;} public float descent(){return 0;} public void getTextBounds(String s,int a,int b,Rect r){}
}
