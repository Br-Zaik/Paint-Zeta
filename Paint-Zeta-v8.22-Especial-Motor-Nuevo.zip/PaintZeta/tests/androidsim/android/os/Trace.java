package android.os; public final class Trace { public static void beginSection(String s){} public static void endSection(){} }
