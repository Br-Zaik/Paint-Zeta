package android.os;
/** Bucle principal simulado: el hilo de la prueba hace de hilo de interfaz. */
public final class Sim {
  public static Thread main;
  private static final java.util.PriorityQueue<long[]> order = new java.util.PriorityQueue<long[]>((x,y)->x[0]!=y[0]?Long.compare(x[0],y[0]):Long.compare(x[1],y[1]));
  private static final java.util.Map<Long,Runnable> jobs = new java.util.HashMap<Long,Runnable>();
  private static long seq;
  public static synchronized void post(Runnable r,long delay){ long id=seq++; jobs.put(id,r); order.add(new long[]{SystemClock.uptimeMillis()+delay,id}); Sim.class.notifyAll(); }
  public static synchronized void remove(Runnable r){ jobs.values().removeIf(x->x==r); }
  public static synchronized void clear(){ jobs.clear(); order.clear(); }
  /** Ejecuta lo que toque hasta ahora (una pasada). */
  public static int runDue(){ int ran=0; while(true){ Runnable r=null; synchronized(Sim.class){ long[] t=order.peek(); if(t==null||t[0]>SystemClock.uptimeMillis()) break; order.poll(); r=jobs.remove(t[1]); } if(r!=null){ r.run(); ran++; } } return ran; }
  /** Avanza el tiempo real ms milisegundos ejecutando tareas y fotogramas (60 Hz). */
  public static void pump(long ms){ long end=SystemClock.uptimeMillis()+ms; while(true){ runDue(); android.view.Choreographer.getInstance().runFrame(); runDue(); long now=SystemClock.uptimeMillis(); if(now>=end) break; try{ Thread.sleep(Math.min(16, end-now)); }catch(InterruptedException e){ return; } } }
}
