package android.util;
/** SparseArray funcional (claves ordenadas), solo pruebas JVM. */
public class SparseArray<E> {
  private int[] keys = new int[8]; private Object[] vals = new Object[8]; private int n;
  public SparseArray(){} public SparseArray(int c){}
  private int find(int k){ return java.util.Arrays.binarySearch(keys,0,n,k); }
  @SuppressWarnings("unchecked") public E get(int k){int i=find(k);return i>=0?(E)vals[i]:null;} @SuppressWarnings("unchecked") public E get(int k,E d){int i=find(k);return i>=0?(E)vals[i]:d;}
  public void put(int k,E v){int i=find(k); if(i>=0){vals[i]=v;return;} i=~i; if(n==keys.length){keys=java.util.Arrays.copyOf(keys,n*2);vals=java.util.Arrays.copyOf(vals,n*2);} System.arraycopy(keys,i,keys,i+1,n-i);System.arraycopy(vals,i,vals,i+1,n-i);keys[i]=k;vals[i]=v;n++;}
  public void remove(int k){int i=find(k); if(i>=0) removeAt(i);} public void delete(int k){remove(k);} public void removeAt(int i){System.arraycopy(keys,i+1,keys,i,n-i-1);System.arraycopy(vals,i+1,vals,i,n-i-1);n--;vals[n]=null;}
  public int size(){return n;} public int keyAt(int i){return keys[i];} @SuppressWarnings("unchecked") public E valueAt(int i){return (E)vals[i];} public void clear(){java.util.Arrays.fill(vals,0,n,null);n=0;} public int indexOfKey(int k){int i=find(k);return i>=0?i:-1;} public void setValueAt(int i,E v){vals[i]=v;} public void append(int k,E v){put(k,v);}
}
