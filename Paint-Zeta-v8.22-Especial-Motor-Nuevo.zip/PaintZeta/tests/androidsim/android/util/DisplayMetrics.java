package android.util; public class DisplayMetrics { public float density, scaledDensity; public int widthPixels, heightPixels, densityDpi; }
