package android.content;
public abstract class Context { public ContentResolver getContentResolver(){return null;} public android.content.res.Resources getResources(){return null;} public Object getSystemService(String s){return null;} public java.io.File getFilesDir(){return null;} public java.io.File getCacheDir(){return null;} public Context getApplicationContext(){return this;} }
