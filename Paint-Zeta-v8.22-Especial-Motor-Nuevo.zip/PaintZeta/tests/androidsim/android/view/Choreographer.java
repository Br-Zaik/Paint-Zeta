package android.view;
public final class Choreographer { public interface FrameCallback { void doFrame(long frameTimeNanos); }
  private static final Choreographer I = new Choreographer(); private final java.util.ArrayList<FrameCallback> cbs = new java.util.ArrayList<FrameCallback>();
  public static Choreographer getInstance(){return I;} public synchronized void postFrameCallback(FrameCallback c){cbs.add(c);} public synchronized void removeFrameCallback(FrameCallback c){cbs.remove(c);}
  /** Solo simulacion: ejecuta los callbacks pendientes como un fotograma. */
  public static final java.util.ArrayList<Long> FRAME_NANOS = new java.util.ArrayList<Long>();
  public void runFrame(){ java.util.ArrayList<FrameCallback> l; synchronized(this){ l=new java.util.ArrayList<FrameCallback>(cbs); cbs.clear(); } if(l.isEmpty()) return; long t=System.nanoTime(); for(FrameCallback c:l) c.doFrame(t); FRAME_NANOS.add(System.nanoTime()-t); } }
