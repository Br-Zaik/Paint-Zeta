import com.pacco.animecut.core.AlphaColors;

public final class AlphaColorsTest {
    private static void eq(String msg, int expected, int got) {
        if (got != expected) throw new AssertionError(msg + ": expected=" + Integer.toHexString(expected)
                + " received=" + Integer.toHexString(got));
    }

    public static void main(String[] args) {
        // Píxel blanco opaco contra transparente negro: no debe volverse gris.
        eq("semi translucent white", 0x80FFFFFF, AlphaColors.mix(0xFFFFFFFF, 0x00000000, .5f));
        eq("opaque red unchanged", 0xFFFF0000, AlphaColors.mix(0xFFFF0000, 0x00000000, 0f));
        eq("transparent", 0x00000000, AlphaColors.mix(0x00000000, 0x00000000, .5f));
        eq("middle colors", 0xFF808080, AlphaColors.mix(0xFF000000, 0xFFFFFFFF, .5f));
        eq("half alpha green", 0x8000FF00, AlphaColors.mix(0x00000000, 0xFF00FF00, .5f));
        System.out.println("AlphaColors: 5 pruebas correctas");
    }
}
