import java.util.Random;
import com.pacco.animecut.core.BackgroundEraseAlpha;
import com.pacco.animecut.core.ColorDist;

/** Regresion JVM: misma transparencia que el borrador antiguo (con despeckle). */
public final class BackgroundEraseAlphaTest {
    private static void check(boolean b, String s) { if (!b) throw new AssertionError(s); }
    private static int[] oldApply(int[] orig, int w, int h, byte[] mask, byte[] sel,
                                  int left, int top, int right, int bottom, int ref, int tol, int mode) {
        int[] px = orig.clone();
        for (int y = top; y < bottom; y++) for (int x = left; x < right; x++) {
            int i = y * w + x, a = mask[i] & 255;
            if (a == 0) continue;
            float f = a / 255f;
            if (sel != null) f *= (sel[i] & 255) / 255f;
            int current = px[i] >>> 24;
            int wanted = (int)(current * (1f - f));
            if (wanted < current) px[i] = (wanted << 24) | (px[i] & 0x00FFFFFF);
        }
        int[] kill = new int[(right - left) * (bottom - top)];
        int nk = 0;
        for (int y = Math.max(1, top); y < Math.min(h - 1, bottom); y++) {
            for (int x = Math.max(1, left); x < Math.min(w - 1, right); x++) {
                int i = y * w + x;
                if ((px[i] >>> 24) == 0) continue;
                if (ColorDist.dist(px[i] | 0xFF000000, ref | 0xFF000000, mode) > tol * 2) continue;
                int empty = 0;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    if ((px[i + dy * w + dx] >>> 24) < 40) empty++;
                }
                if (empty >= 5) kill[nk++] = i;
            }
        }
        for (int k = 0; k < nk; k++) px[kill[k]] &= 0x00FFFFFF;
        return px;
    }
    private static void randomized() {
        Random rnd = new Random(20261011L);
        for (int run = 0; run < 400; run++) {
            int w = 3 + rnd.nextInt(50), h = 3 + rnd.nextInt(45);
            int[] px = new int[w*h];
            byte[] mask = new byte[px.length], sel = (run % 4 == 0) ? null : new byte[px.length];
            for (int i = 0; i < px.length; i++) {
                px[i] = rnd.nextInt();
                mask[i] = (byte)(run % 3 == 0 ? rnd.nextInt(256) : (rnd.nextBoolean() ? 255 : 0));
                if (sel != null) sel[i] = (byte)rnd.nextInt(256);
            }
            int left = rnd.nextInt(w-1), right = left + 1 + rnd.nextInt(w - left);
            int top = rnd.nextInt(h-1), bottom = top + 1 + rnd.nextInt(h - top);
            int ref = rnd.nextInt(), tol = rnd.nextInt(151), mode = run % 3;
            int[] expected = oldApply(px,w,h,mask,sel,left,top,right,bottom,ref,tol,mode);
            byte[] actual = BackgroundEraseAlpha.prepare(px,w,h,left,top,right,bottom,mask,sel,ref,tol,mode);
            for (int y = top; y < bottom; y++) for (int x = left; x < right; x++) {
                int i = y*w+x, j = (y-top)*(right-left)+(x-left);
                if ((expected[i] >>> 24) != (actual[j] & 255)) {
                    throw new AssertionError("mismatch case="+run+" at="+x+","+y);
                }
            }
        }
        System.out.println("BackgroundEraseAlpha: 400 casos aleatorios, equivalencia OK");
    }
    public static void main(String[] args) { randomized(); }
}
