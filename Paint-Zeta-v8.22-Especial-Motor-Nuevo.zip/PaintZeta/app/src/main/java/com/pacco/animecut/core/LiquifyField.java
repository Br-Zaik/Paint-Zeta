package com.pacco.animecut.core;

/**
 * Campo de deformacion de Especial (v8.22). No depende de Android.
 *
 * MODELO
 * - Mapa INVERSO: el pixel destino p lee el color original en S(p) = p + U(p).
 *   p usa coordenadas continuas de imagen (el centro del pixel x es x + 0.5).
 * - U se guarda como coeficientes en una rejilla fina (paso 4-8 px) y se evalua
 *   con B-spline cubica uniforme: continuidad C2, sin oscilaciones (cada valor
 *   es una media convexa de coeficientes) y sin quiebres entre celdas.
 * - Cada estampa es una transformacion local T y se COMPONE con lo existente:
 *   U_nuevo(p) = U(T(p)) + (T(p) - p). Asi lo ya deformado viaja con el dedo en
 *   lugar de sumarse vectorialmente.
 * - El tamano de cada sub-estampa se limita (ver LiquifyStroke) para que
 *   det(dT) >= 1 - KAPPA > 0: componer mapas sin pliegue no crea pliegues.
 *   Ademas se verifica la red de coeficientes tras cada estampa y, si la
 *   discretizacion acercara una celda al pliegue, se reduce SOLO el incremento.
 * - Restaurar lleva los coeficientes a cero exacto: vuelve el pixel original.
 */
public final class LiquifyField {
    public static final int DRAG = 0, PINCH = 1, EXPAND = 2, SMOOTH = 3, RESTORE = 4;

    /** Margen del limite de paso: det(dT) >= 1 - KAPPA por sub-estampa. */
    public static final float KAPPA = 0.45f;
    /** Determinante minimo aceptado en la red (limita ampliacion a ~4x lineal). */
    public static final float MIN_DET = 0.05f;

    /** Bloques de coeficientes para el respaldo por trazo (cancelar con 2 dedos). */
    private static final int CT = 16;

    public final int width, height, step, cols, rows;
    final float[] cu, cv;

    private final int ctCols, ctRows;
    private final float[][] backupU, backupV;
    private final int[] backupList;
    private int backupCount;
    private boolean strokeOpen;
    private int strokeMinI = Integer.MAX_VALUE, strokeMinJ = Integer.MAX_VALUE;
    private int strokeMaxI = Integer.MIN_VALUE, strokeMaxJ = Integer.MIN_VALUE;

    // Escrituras de la estampa actual (region de nodos) y buffers reutilizables.
    private float[] nu = new float[0], nv = new float[0];
    private float[] ou = new float[0], ov = new float[0];
    private float[] tu = new float[0], tv = new float[0];
    private float[] hu = new float[0], hv = new float[0];
    private final float[] w4a = new float[4], w4b = new float[4];
    private final float[] q2 = new float[2];

    /** Ultima region modificada en pixeles: x0, y0, x1, y1 (exclusivo). */
    public final int[] lastDirty = new int[4];
    /** Cuantas veces el verificador tuvo que reducir un incremento. */
    public int guardReductions;
    /** Sub-estampas atenuadas por la saturacion suave. */
    public int saturations;
    /** Incrementos que el verificador anulo por completo (deberia quedar en 0). */
    public int guardRejections;

    public LiquifyField(int width, int height, int step) {
        if (width < 2 || height < 2 || step < 1) throw new IllegalArgumentException();
        this.width = width;
        this.height = height;
        this.step = step;
        this.cols = (width + step - 1) / step + 2;
        this.rows = (height + step - 1) / step + 2;
        this.cu = new float[cols * rows];
        this.cv = new float[cols * rows];
        this.ctCols = (cols + CT - 1) / CT;
        this.ctRows = (rows + CT - 1) / CT;
        this.backupU = new float[ctCols * ctRows][];
        this.backupV = new float[ctCols * ctRows][];
        this.backupList = new int[ctCols * ctRows];
    }

    /** Paso recomendado: rejilla fina sin exceder ~1,1 millones de nodos. */
    public static int recommendedStep(int w, int h) {
        int max = Math.max(w, h);
        if (max <= 4200) return 4;
        if (max <= 6400) return 6;
        return 8;
    }

    // ------------------------------------------------------------------
    // Pesos de interpolacion
    // ------------------------------------------------------------------

    /** B-spline cubica uniforme (aproximante, C2, pesos >= 0). */
    static void bspline(float f, float[] w) {
        float f2 = f * f, f3 = f2 * f, g = 1f - f;
        w[0] = g * g * g * (1f / 6f);
        w[1] = (3f * f3 - 6f * f2 + 4f) * (1f / 6f);
        w[2] = (-3f * f3 + 3f * f2 + 3f * f + 1f) * (1f / 6f);
        w[3] = f3 * (1f / 6f);
    }

    /** Catmull-Rom: solo para transportar coeficientes (poca difusion numerica). */
    static void catmull(float f, float[] w) {
        float f2 = f * f, f3 = f2 * f;
        w[0] = .5f * (-f3 + 2f * f2 - f);
        w[1] = .5f * (3f * f3 - 5f * f2 + 2f);
        w[2] = .5f * (-3f * f3 + 4f * f2 + f);
        w[3] = .5f * (f3 - f2);
    }

    private int ci(int i) { return i < 0 ? 0 : (i >= cols ? cols - 1 : i); }
    private int cj(int j) { return j < 0 ? 0 : (j >= rows ? rows - 1 : j); }

    /** U(p) evaluado con B-spline. out[0]=Ux, out[1]=Uy (pixeles). */
    public void sample(float px, float py, float[] out) {
        float gx = px / step, gy = py / step;
        int i0 = (int) Math.floor(gx), j0 = (int) Math.floor(gy);
        bspline(gx - i0, w4a);
        bspline(gy - j0, w4b);
        float ux = 0f, uy = 0f;
        for (int b = 0; b < 4; b++) {
            int row = cj(j0 - 1 + b) * cols;
            float wy = w4b[b];
            for (int a = 0; a < 4; a++) {
                int k = row + ci(i0 - 1 + a);
                float ww = wy * w4a[a];
                ux += ww * cu[k];
                uy += ww * cv[k];
            }
        }
        out[0] = ux;
        out[1] = uy;
    }

    /**
     * Mezcla de interpolantes para transportar coeficientes: 70 % Catmull-Rom
     * (exacta, poca difusion) + 30 % B-spline (amortigua el ruido de alta
     * frecuencia que, tras cientos de estampas, acercaria el mapa al pliegue).
     * Medido en pruebas: mejor exactitud (0,3 px de error medio frente a una
     * referencia densa) Y mucha mas robustez que cualquiera de los dos solos.
     */
    static final float ADVECT_BSPLINE = .3f;

    static void advectWeights(float f, float[] w) {
        float f2 = f * f, f3 = f2 * f, g = 1f - f;
        float a = 1f - ADVECT_BSPLINE, b = ADVECT_BSPLINE * (1f / 6f);
        w[0] = a * .5f * (-f3 + 2f * f2 - f) + b * g * g * g;
        w[1] = a * .5f * (3f * f3 - 5f * f2 + 2f) + b * (3f * f3 - 6f * f2 + 4f);
        w[2] = a * .5f * (-3f * f3 + 4f * f2 + f) + b * (-3f * f3 + 3f * f2 + 3f * f + 1f);
        w[3] = a * .5f * (f3 - f2) + b * f3;
    }

    /** Coeficientes interpolados (transporte) en coordenadas de nodo. */
    private void coefAt(float gx, float gy, float[] out) {
        int i0 = (int) Math.floor(gx), j0 = (int) Math.floor(gy);
        advectWeights(gx - i0, w4a);
        advectWeights(gy - j0, w4b);
        float ux = 0f, uy = 0f;
        for (int b = 0; b < 4; b++) {
            int row = cj(j0 - 1 + b) * cols;
            float wy = w4b[b];
            for (int a = 0; a < 4; a++) {
                int k = row + ci(i0 - 1 + a);
                float ww = wy * w4a[a];
                ux += ww * cu[k];
                uy += ww * cv[k];
            }
        }
        out[0] = ux;
        out[1] = uy;
    }

    /** true si todos los coeficientes del rango de nodos (inclusive) son cero. */
    public boolean isZero(int i0, int j0, int i1, int j1) {
        i0 = ci(i0); i1 = ci(i1); j0 = cj(j0); j1 = cj(j1);
        for (int j = j0; j <= j1; j++) {
            int row = j * cols;
            for (int i = i0; i <= i1; i++) {
                if (cu[row + i] != 0f || cv[row + i] != 0f) return false;
            }
        }
        return true;
    }

    public boolean isIdentity() {
        for (int k = 0; k < cu.length; k++) if (cu[k] != 0f || cv[k] != 0f) return false;
        return true;
    }

    /** Valor maximo |U| en un rango de nodos (cota del desplazamiento evaluado). */
    public float maxAbs(int i0, int j0, int i1, int j1) {
        i0 = ci(i0); i1 = ci(i1); j0 = cj(j0); j1 = cj(j1);
        float m = 0f;
        for (int j = j0; j <= j1; j++) {
            int row = j * cols;
            for (int i = i0; i <= i1; i++) {
                float a = Math.abs(cu[row + i]) + Math.abs(cv[row + i]);
                if (a > m) m = a;
            }
        }
        return m;
    }

    // ------------------------------------------------------------------
    // Respaldo por trazo
    // ------------------------------------------------------------------

    public void beginStroke() {
        endStroke();
        strokeOpen = true;
        strokeMinI = strokeMinJ = Integer.MAX_VALUE;
        strokeMaxI = strokeMaxJ = Integer.MIN_VALUE;
    }

    /** Confirma: suelta los respaldos de coeficientes. */
    public void endStroke() {
        for (int n = 0; n < backupCount; n++) {
            int t = backupList[n];
            backupU[t] = null;
            backupV[t] = null;
        }
        backupCount = 0;
        strokeOpen = false;
    }

    /**
     * Devuelve el campo exactamente al estado del inicio del trazo.
     * @return region de pixeles afectada (x0,y0,x1,y1) o null si no hubo cambios.
     */
    public int[] cancelStroke() {
        if (!strokeOpen) return null;
        int[] dirty = null;
        if (backupCount > 0) {
            for (int n = 0; n < backupCount; n++) {
                int t = backupList[n];
                int ti = t % ctCols, tj = t / ctCols;
                int i0 = ti * CT, j0 = tj * CT;
                int iw = Math.min(CT, cols - i0), jh = Math.min(CT, rows - j0);
                float[] bu = backupU[t], bv = backupV[t];
                for (int y = 0; y < jh; y++) {
                    System.arraycopy(bu, y * CT, cu, (j0 + y) * cols + i0, iw);
                    System.arraycopy(bv, y * CT, cv, (j0 + y) * cols + i0, iw);
                }
            }
            dirty = pixelRect(strokeMinI, strokeMinJ, strokeMaxI, strokeMaxJ, new int[4]);
        }
        endStroke();
        return dirty;
    }

    private void backupNodes(int i0, int j0, int i1, int j1) {
        if (!strokeOpen) return;
        if (i0 < strokeMinI) strokeMinI = i0;
        if (j0 < strokeMinJ) strokeMinJ = j0;
        if (i1 > strokeMaxI) strokeMaxI = i1;
        if (j1 > strokeMaxJ) strokeMaxJ = j1;
        for (int tj = j0 / CT; tj <= j1 / CT; tj++) {
            for (int ti = i0 / CT; ti <= i1 / CT; ti++) {
                int t = tj * ctCols + ti;
                if (backupU[t] != null) continue;
                float[] bu = new float[CT * CT], bv = new float[CT * CT];
                int bi = ti * CT, bj = tj * CT;
                int iw = Math.min(CT, cols - bi), jh = Math.min(CT, rows - bj);
                for (int y = 0; y < jh; y++) {
                    System.arraycopy(cu, (bj + y) * cols + bi, bu, y * CT, iw);
                    System.arraycopy(cv, (bj + y) * cols + bi, bv, y * CT, iw);
                }
                backupU[t] = bu;
                backupV[t] = bv;
                backupList[backupCount++] = t;
            }
        }
    }

    /** Pixeles cuya U depende de los nodos [i0..i1]x[j0..j1] (soporte B-spline 4 nodos). */
    public int[] pixelRect(int i0, int j0, int i1, int j1, int[] out) {
        int x0 = (int) Math.floor((i0 - 2) * (float) step - .5f);
        int y0 = (int) Math.floor((j0 - 2) * (float) step - .5f);
        int x1 = (int) Math.ceil((i1 + 2) * (float) step - .5f) + 1;
        int y1 = (int) Math.ceil((j1 + 2) * (float) step - .5f) + 1;
        out[0] = Math.max(0, x0);
        out[1] = Math.max(0, y0);
        out[2] = Math.min(width, x1);
        out[3] = Math.min(height, y1);
        return out;
    }

    // ------------------------------------------------------------------
    // Estampas
    // ------------------------------------------------------------------

    private void ensureScratch(int n) {
        if (nu.length >= n) return;
        int m = Math.max(n, nu.length + nu.length / 2);
        nu = new float[m]; nv = new float[m];
        ou = new float[m]; ov = new float[m];
        tu = new float[m]; tv = new float[m];
    }

    /**
     * Aplica UNA sub-estampa ya acotada por LiquifyStroke.
     *
     * @param cx,cy  centro del pincel (coordenadas continuas de imagen)
     * @param mx,my  DRAG: desplazamiento del contenido en el centro (px)
     * @param amount PINCH/EXPAND: escala radial (sigma &gt; 0); SMOOTH/RESTORE: mezcla 0..1
     * @param radius radio efectivo
     * @param selection mascara 0..255 (null = todo el lienzo)
     * @return true si el campo cambio; lastDirty contiene los pixeles afectados
     */
    public boolean apply(int mode, float cx, float cy, float mx, float my, float amount,
            float radius, LiquifyFalloff falloff, byte[] selection) {
        if (!(radius > 0f) || !Float.isFinite(cx) || !Float.isFinite(cy)) return false;
        if (mode == DRAG && mx == 0f && my == 0f) return false;
        if (mode != DRAG && !(amount > 0f)) return false;
        float invS = 1f / step;
        int i0 = Math.max(0, (int) Math.ceil((cx - radius) * invS));
        int j0 = Math.max(0, (int) Math.ceil((cy - radius) * invS));
        int i1 = Math.min(cols - 1, (int) Math.floor((cx + radius) * invS));
        int j1 = Math.min(rows - 1, (int) Math.floor((cy + radius) * invS));
        if (i1 < i0 || j1 < j0) return false;
        int rw = i1 - i0 + 1, rh = j1 - j0 + 1, n = rw * rh;
        ensureScratch(n);
        float invR2 = 1f / (radius * radius);
        final float[] q = q2;

        // Media local para Suavizar: caja separable de radio proporcional al pincel.
        int box = 0;
        if (mode == SMOOTH) {
            box = Math.max(1, Math.round(radius * .3f * invS));
            boxBlur(i0, j0, i1, j1, box);
        }

        // Saturacion global y SUAVE: si en algun nodo la estampa llevaria el mapa
        // a un estiramiento (det < SAT_LOW) o compresion (det > SAT_HIGH) extremos,
        // toda la estampa se escala por igual (sin crear quiebres en el campo).
        if (mode <= EXPAND) {
            float scale = 1f;
            for (int j = j0; j <= j1; j++) {
                float py = j * (float) step, dy = py - cy;
                for (int i = i0; i <= i1; i++) {
                    float px = i * (float) step, dx = px - cx;
                    float d2 = (dx * dx + dy * dy) * invR2;
                    if (d2 >= 1f) continue;
                    float w = falloff.value(d2);
                    if (selection != null) {
                        int sx = Math.min(width - 1, Math.max(0, (int) px));
                        int sy = Math.min(height - 1, Math.max(0, (int) py));
                        w *= (selection[sy * width + sx] & 255) * (1f / 255f);
                    }
                    if (w <= 0f) continue;
                    float sc = saturation(mode, i, j, dx, dy, d2, w, mx * scale, my * scale, amount * scale, radius, falloff);
                    if (sc < 1f) scale *= Math.max(0f, sc);
                    if (scale <= 0f) break;
                }
                if (scale <= 0f) break;
            }
            if (scale < 1f) {
                saturations++;
                if (scale <= .001f) return false;
                mx *= scale; my *= scale; amount *= scale;
            }
        }

        boolean any = false;
        for (int j = j0; j <= j1; j++) {
            float py = j * (float) step;
            float dy = py - cy;
            for (int i = i0; i <= i1; i++) {
                int r = (j - j0) * rw + (i - i0);
                int k = j * cols + i;
                float oldU = cu[k], oldV = cv[k];
                ou[r] = oldU; ov[r] = oldV;
                float px = i * (float) step;
                float dx = px - cx;
                float d2 = (dx * dx + dy * dy) * invR2;
                float w = d2 >= 1f ? 0f : falloff.value(d2);
                if (w > 0f && selection != null) {
                    int sx = Math.min(width - 1, Math.max(0, (int) px));
                    int sy = Math.min(height - 1, Math.max(0, (int) py));
                    w *= (selection[sy * width + sx] & 255) * (1f / 255f);
                }
                if (w <= 0f) { nu[r] = oldU; nv[r] = oldV; continue; }
                float newU, newV;
                switch (mode) {
                    case DRAG: {
                        // T(p) = p - m w(p);  U' = U(T p) + (T p - p)
                        float ox = -mx * w, oy = -my * w;
                        coefAt((px + ox) * invS, (py + oy) * invS, q);
                        newU = q[0] + ox;
                        newV = q[1] + oy;
                        break;
                    }
                    case PINCH:
                    case EXPAND: {
                        // Contraer lee mas lejos del centro (T expande), Expandir mas cerca.
                        float s = (mode == PINCH ? amount : -amount) * w;
                        float ox = dx * s, oy = dy * s;
                        coefAt((px + ox) * invS, (py + oy) * invS, q);
                        newU = q[0] + ox;
                        newV = q[1] + oy;
                        break;
                    }
                    case SMOOTH: {
                        float t = Math.min(1f, amount * w);
                        newU = oldU + (tu[r] - oldU) * t;
                        newV = oldV + (tv[r] - oldV) * t;
                        break;
                    }
                    case RESTORE: {
                        float t = Math.min(1f, amount * w);
                        newU = oldU * (1f - t);
                        newV = oldV * (1f - t);
                        // Llegar al original exacto sin colas infinitesimales
                        // (0,02 px es invisible; asi el pixel vuelve bit a bit).
                        if (Math.abs(newU) < .02f) newU = 0f;
                        if (Math.abs(newV) < .02f) newV = 0f;
                        break;
                    }
                    default:
                        return false;
                }
                if (!Float.isFinite(newU) || !Float.isFinite(newV)) { newU = oldU; newV = oldV; }
                nu[r] = newU; nv[r] = newV;
                if (newU != oldU || newV != oldV) any = true;
            }
        }
        if (!any) return false;

        backupNodes(i0, j0, i1, j1);
        if (!guard(i0, j0, i1, j1, rw, rh)) {
            guardRejections++;
            return false;
        }
        pixelRect(i0, j0, i1, j1, lastDirty);
        return true;
    }

    private float[] detBefore = new float[0], detAfter = new float[0], lam = new float[0];
    private float[] rowA = new float[0];

    /**
     * Escribe la region y verifica el mapa REAL (B-spline evaluada) en 4 puntos por
     * celda (esquina, medios de arista y centro). Ningun punto puede bajar de
     * min(MIN_DET, su valor previo). Si alguno lo haria, se reduce SOLO el
     * incremento de los nodos que lo influyen: el resto del pincel sigue
     * respondiendo y la zona extrema simplemente deja de estirarse mas.
     * @return false si no se pudo aplicar nada sin violar la condicion.
     */
    private boolean guard(int i0, int j0, int i1, int j1, int rw, int rh) {
        int si0 = Math.max(0, i0 - 2), sj0 = Math.max(0, j0 - 2);
        int si1 = Math.min(cols - 2, i1 + 1), sj1 = Math.min(rows - 2, j1 + 1);
        if (si1 < si0 || sj1 < sj0) { write(i0, j0, rw, rh, 1f); return true; }
        int per = perCell();
        int ns = (si1 - si0 + 1) * (sj1 - sj0 + 1) * per;
        if (detAfter.length < ns) { detAfter = new float[ns + ns / 2]; detBefore = new float[detAfter.length]; }
        write(i0, j0, rw, rh, 1f);
        if (evalDets(si0, sj0, si1, sj1, detAfter) >= MIN_DET) return true;
        // Hay puntos bajo el umbral: valores previos para la condicion relativa.
        write(i0, j0, rw, rh, 0f);
        evalDets(si0, sj0, si1, sj1, detBefore);
        for (int k = 0; k < ns; k++) detBefore[k] = Math.min(MIN_DET, detBefore[k]) - 1e-5f;
        guardReductions++;
        if (lam.length < rw * rh) lam = new float[rw * rh + rw * rh / 2];
        java.util.Arrays.fill(lam, 0, rw * rh, 1f);
        int sw = si1 - si0 + 1;
        for (int iter = 0; iter < 16; iter++) {
            for (int y = 0; y < rh; y++) {
                int k = (j0 + y) * cols + i0, r = y * rw;
                for (int x = 0; x < rw; x++, k++, r++) {
                    float l = lam[r];
                    cu[k] = ou[r] + (nu[r] - ou[r]) * l;
                    cv[k] = ov[r] + (nv[r] - ov[r]) * l;
                }
            }
            evalDets(si0, sj0, si1, sj1, detAfter);
            boolean bad = false;
            float f = iter < 11 ? .5f : 0f;
            for (int k = 0; k < ns; k++) {
                if (detAfter[k] >= detBefore[k]) continue;
                bad = true;
                int cell = k / per, ci = si0 + cell % sw, cj = sj0 + cell / sw;
                for (int dj = -1; dj <= 2; dj++) for (int di = -1; di <= 2; di++) {
                    int ni = ci + di - i0, nj = cj + dj - j0;
                    if (ni >= 0 && nj >= 0 && ni < rw && nj < rh) lam[nj * rw + ni] *= f;
                }
            }
            if (!bad) return true;
        }
        write(i0, j0, rw, rh, 0f);
        return false;
    }

    /** Puntos de control por eje dentro de cada celda (F x F por celda). */
    public static final int GUARD_F = 3;
    private static float[] gW, gD; private static int gF;

    private static synchronized void guardWeights() {
        if (gF == GUARD_F && gW != null) return;
        int F = GUARD_F;
        float[] w = new float[F * 4], d = new float[F * 4];
        for (int q = 0; q < F; q++) {
            float f = q / (float) F, f2 = f * f, g = 1f - f;
            w[q * 4] = g * g * g / 6f;
            w[q * 4 + 1] = (3f * f2 * f - 6f * f2 + 4f) / 6f;
            w[q * 4 + 2] = (-3f * f2 * f + 3f * f2 + 3f * f + 1f) / 6f;
            w[q * 4 + 3] = f2 * f / 6f;
            d[q * 4] = -.5f * g * g;
            d[q * 4 + 1] = 1.5f * f2 - 2f * f;
            d[q * 4 + 2] = -1.5f * f2 + f + .5f;
            d[q * 4 + 3] = .5f * f2;
        }
        gW = w; gD = d; gF = F;
    }

    /** Numero de puntos de control por celda. */
    private static int perCell() { guardWeights(); return gF * gF; }

    /**
     * det(dS) de la B-spline en F x F puntos por celda del rango (incluido).
     * Separable: convoluciones horizontales por fila y combinacion vertical.
     * Devuelve el minimo; out recibe un valor por punto.
     */
    private float evalDets(int si0, int sj0, int si1, int sj1, float[] out) {
        guardWeights();
        final int F = gF;
        final float[] W = gW, D = gD;
        int sw = si1 - si0 + 1, sh = sj1 - sj0 + 1;
        int r0 = sj0 - 1, nr = sh + 3;
        int plane = nr * sw;
        int need = plane * 4 * F;
        if (rowA.length < need) rowA = new float[need + need / 2];
        float invS = 1f / step;
        // Planos por fraccion q en x: [Au, Du, Av, Dv]
        for (int r = 0; r < nr; r++) {
            int row = cj(r0 + r) * cols;
            for (int x = 0; x < sw; x++) {
                int i = si0 + x;
                float um = cu[row + ci(i - 1)], u0 = cu[row + ci(i)], u1 = cu[row + ci(i + 1)], u2 = cu[row + ci(i + 2)];
                float vm = cv[row + ci(i - 1)], v0 = cv[row + ci(i)], v1 = cv[row + ci(i + 1)], v2 = cv[row + ci(i + 2)];
                int o = r * sw + x;
                for (int q = 0; q < F; q++) {
                    int b = q * 4, p = q * 4 * plane;
                    rowA[p + o] = W[b] * um + W[b + 1] * u0 + W[b + 2] * u1 + W[b + 3] * u2;
                    rowA[p + plane + o] = (D[b] * um + D[b + 1] * u0 + D[b + 2] * u1 + D[b + 3] * u2) * invS;
                    rowA[p + 2 * plane + o] = W[b] * vm + W[b + 1] * v0 + W[b + 2] * v1 + W[b + 3] * v2;
                    rowA[p + 3 * plane + o] = (D[b] * vm + D[b + 1] * v0 + D[b + 2] * v1 + D[b + 3] * v2) * invS;
                }
            }
        }
        float min = Float.POSITIVE_INFINITY;
        int per = F * F;
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int o0 = y * sw + x, o1 = o0 + sw, o2 = o1 + sw, o3 = o2 + sw;
                int cell = (y * sw + x) * per;
                for (int qy = 0; qy < F; qy++) {
                    int by = qy * 4;
                    float wy0 = W[by], wy1 = W[by + 1], wy2 = W[by + 2], wy3 = W[by + 3];
                    float dy0 = D[by] * invS, dy1 = D[by + 1] * invS, dy2 = D[by + 2] * invS, dy3 = D[by + 3] * invS;
                    for (int qx = 0; qx < F; qx++) {
                        int p = qx * 4 * plane;
                        int pAu = p, pDu = p + plane, pAv = p + 2 * plane, pDv = p + 3 * plane;
                        float uxx = wy0 * rowA[pDu + o0] + wy1 * rowA[pDu + o1] + wy2 * rowA[pDu + o2] + wy3 * rowA[pDu + o3];
                        float vxx = wy0 * rowA[pDv + o0] + wy1 * rowA[pDv + o1] + wy2 * rowA[pDv + o2] + wy3 * rowA[pDv + o3];
                        float uyy = dy0 * rowA[pAu + o0] + dy1 * rowA[pAu + o1] + dy2 * rowA[pAu + o2] + dy3 * rowA[pAu + o3];
                        float vyy = dy0 * rowA[pAv + o0] + dy1 * rowA[pAv + o1] + dy2 * rowA[pAv + o2] + dy3 * rowA[pAv + o3];
                        float det = (1f + uxx) * (1f + vyy) - uyy * vxx;
                        if (!(det == det)) det = Float.NEGATIVE_INFINITY;
                        out[cell + qy * F + qx] = det;
                        if (det < min) min = det;
                    }
                }
            }
        }
        return min;
    }

    /** det minimo (normalizado) en las 4 esquinas de la celda (i,j) de la red deformada. */
    private float cellDet(int i, int j) {
        float s = step, inv = 1f / (s * s);
        int k00 = j * cols + i, k10 = k00 + 1, k01 = k00 + cols, k11 = k01 + 1;
        float ax = cu[k00], ay = cv[k00];
        float bx = s + cu[k10], by = cv[k10];
        float cx = cu[k01], cy = s + cv[k01];
        float ex = s + cu[k11], ey = s + cv[k11];
        float t1 = ((bx - ax) * (cy - ay) - (by - ay) * (cx - ax)) * inv;
        float t2 = ((bx - ax) * (ey - by) - (by - ay) * (ex - bx)) * inv;
        float t3 = ((ex - cx) * (cy - ay) - (ey - cy) * (cx - ax)) * inv;
        float t4 = ((ex - cx) * (ey - by) - (ey - cy) * (ex - bx)) * inv;
        float m = Math.min(Math.min(t1, t2), Math.min(t3, t4));
        return m == m ? m : Float.NEGATIVE_INFINITY;
    }

    /** Zona de saturacion: el estiramiento/compresion local deja de crecer con suavidad. */
    public static final float SAT_LOW = .15f, SAT_HIGH = 16f;

    /**
     * Factor 0..1 que suaviza la estampa en un nodo cuando el mapa ya esta muy
     * estirado (det pequeno) o muy comprimido (det grande) y la estampa lo
     * empujaria aun mas. Fuera de esos extremos devuelve 1 (sin efecto).
     * delta = det(dT) de la estampa en el nodo; D = det(dS) actual en el nodo.
     */
    private float saturation(int mode, int i, int j, float dx, float dy, float d2, float w,
            float mx, float my, float amount, float radius, LiquifyFalloff falloff) {
        float delta;
        float rho = (float) Math.sqrt(d2);
        float fp = falloff.slope(d2); // df/drho
        float wr = w / Math.max(1e-6f, falloff.value(d2)); // escala aplicada (seleccion)
        if (mode == DRAG) {
            if (rho < 1e-6f) return 1f;
            // grad w = wr * f'(rho) * (p - c) / (|p - c| R)
            float gx = wr * fp * dx / (rho * radius * radius);
            float gy = wr * fp * dy / (rho * radius * radius);
            delta = 1f - (mx * gx + my * gy);
        } else {
            float sg = (mode == PINCH ? amount : -amount) * wr;
            float f = w / Math.max(1e-6f, wr);
            float g = 1f + sg * f;
            delta = g * (1f + sg * (f + rho * fp));
        }
        if (delta > .999f && delta < 1.001f) return 1f;
        // det del mapa actual en el punto de donde se TRANSPORTA el contenido, T(p):
        // det_nuevo(p) = det_actual(T p) * det(dT)(p).
        float px = i * (float) step, py = j * (float) step, tx, ty;
        if (mode == DRAG) { tx = px - mx * w; ty = py - my * w; }
        else { float sg = (mode == PINCH ? amount : -amount) * w; tx = px + dx * sg; ty = py + dy * sg; }
        float D = detAtPoint(tx, ty);
        if (delta < 1f) {
            if (D <= SAT_LOW) return 0f;
            float lim = (D - SAT_LOW) / (D * (1f - delta));
            return lim >= 1f ? 1f : lim;
        } else {
            if (D >= SAT_HIGH) return 0f;
            float lim = (SAT_HIGH / D - 1f) / (delta - 1f);
            return lim >= 1f ? 1f : lim;
        }
    }

    private final float[] dwa = new float[4], dwb = new float[4], vwa = new float[4], vwb = new float[4];

    /** det(dS) de la B-spline en un punto cualquiera (valor y derivada analiticos). */
    float detAtPoint(float px, float py) {
        float gx = px / step, gy = py / step;
        int i0 = (int) Math.floor(gx), j0 = (int) Math.floor(gy);
        float fx = gx - i0, fy = gy - j0;
        bspline(fx, vwa); bspline(fy, vwb);
        bsplineDeriv(fx, dwa); bsplineDeriv(fy, dwb);
        float ux = 0, uy = 0, vx = 0, vy = 0;
        for (int b = 0; b < 4; b++) {
            int row = cj(j0 - 1 + b) * cols;
            for (int a = 0; a < 4; a++) {
                int k = row + ci(i0 - 1 + a);
                float cxw = dwa[a] * vwb[b], cyw = vwa[a] * dwb[b];
                ux += cxw * cu[k]; vx += cxw * cv[k];
                uy += cyw * cu[k]; vy += cyw * cv[k];
            }
        }
        float inv = 1f / step;
        ux *= inv; vx *= inv; uy *= inv; vy *= inv;
        return (1f + ux) * (1f + vy) - uy * vx;
    }

    static void bsplineDeriv(float f, float[] d) {
        float g = 1f - f, f2 = f * f;
        d[0] = -.5f * g * g;
        d[1] = 1.5f * f2 - 2f * f;
        d[2] = -1.5f * f2 + f + .5f;
        d[3] = .5f * f2;
    }

    /** det(dS) de la B-spline exactamente en el nodo (i, j). */
    public float nodeDet(int i, int j) {
        // Pesos en f=0: valor (1,4,1)/6 ; derivada (-1,0,1)/2 / step
        int rm = cj(j - 1) * cols, r0 = cj(j) * cols, rp = cj(j + 1) * cols;
        int im = ci(i - 1), i0 = ci(i), ip = ci(i + 1);
        float inv = .5f / step;
        float uxRm = (cu[rm + ip] - cu[rm + im]), uxR0 = (cu[r0 + ip] - cu[r0 + im]), uxRp = (cu[rp + ip] - cu[rp + im]);
        float vxRm = (cv[rm + ip] - cv[rm + im]), vxR0 = (cv[r0 + ip] - cv[r0 + im]), vxRp = (cv[rp + ip] - cv[rp + im]);
        float ux = (uxRm + 4f * uxR0 + uxRp) / 6f * inv;
        float vx = (vxRm + 4f * vxR0 + vxRp) / 6f * inv;
        float uyCm = cu[rp + im] - cu[rm + im], uyC0 = cu[rp + i0] - cu[rm + i0], uyCp = cu[rp + ip] - cu[rm + ip];
        float vyCm = cv[rp + im] - cv[rm + im], vyC0 = cv[rp + i0] - cv[rm + i0], vyCp = cv[rp + ip] - cv[rm + ip];
        float uy = (uyCm + 4f * uyC0 + uyCp) / 6f * inv;
        float vy = (vyCm + 4f * vyC0 + vyCp) / 6f * inv;
        return (1f + ux) * (1f + vy) - uy * vx;
    }

    /** cu = old + lambda * (new - old) en la region. */
    private void write(int i0, int j0, int rw, int rh, float lambda) {
        for (int y = 0; y < rh; y++) {
            int k = (j0 + y) * cols + i0, r = y * rw;
            for (int x = 0; x < rw; x++, k++, r++) {
                if (lambda == 1f) { cu[k] = nu[r]; cv[k] = nv[r]; }
                else if (lambda == 0f) { cu[k] = ou[r]; cv[k] = ov[r]; }
                else {
                    cu[k] = ou[r] + (nu[r] - ou[r]) * lambda;
                    cv[k] = ov[r] + (nv[r] - ov[r]) * lambda;
                }
            }
        }
    }

    /** Media de caja separable de los coeficientes de la region (resultado en tu/tv). */
    private void boxBlur(int i0, int j0, int i1, int j1, int box) {
        int rw = i1 - i0 + 1, rh = j1 - j0 + 1;
        int eh = rh + 2 * box, need = rw * eh;
        if (hu.length < need) { hu = new float[need + need / 2]; hv = new float[hu.length]; }
        float inv = 1f / (2 * box + 1);
        for (int y = 0; y < eh; y++) {
            int row = cj(j0 - box + y) * cols;
            // Suma corrida horizontal: O(rw) por fila, independiente del radio.
            float su = 0f, sv = 0f;
            for (int d = -box; d <= box; d++) { int k = row + ci(i0 + d); su += cu[k]; sv += cv[k]; }
            for (int x = 0; x < rw; x++) {
                hu[y * rw + x] = su * inv;
                hv[y * rw + x] = sv * inv;
                int kin = row + ci(i0 + x + box + 1), kout = row + ci(i0 + x - box);
                su += cu[kin] - cu[kout];
                sv += cv[kin] - cv[kout];
            }
        }
        for (int x = 0; x < rw; x++) {
            float su = 0f, sv = 0f;
            for (int d = 0; d <= 2 * box; d++) { su += hu[d * rw + x]; sv += hv[d * rw + x]; }
            for (int y = 0; y < rh; y++) {
                tu[y * rw + x] = su * inv;
                tv[y * rw + x] = sv * inv;
                if (y + 1 < rh) {
                    su += hu[(y + 2 * box + 1) * rw + x] - hu[y * rw + x];
                    sv += hv[(y + 2 * box + 1) * rw + x] - hv[y * rw + x];
                }
            }
        }
    }

    /**
     * Determinante minimo (normalizado) de la red de nodos deformada S = P + c en
     * las cuatro esquinas de cada celda [i, i+1] x [j, j+1] del rango.
     * &gt; 0 en todas las esquinas = ninguna celda volteada.
     */
    public float minCellDet(int i0, int j0, int i1, int j1) {
        i0 = Math.max(0, i0); j0 = Math.max(0, j0);
        i1 = Math.min(cols - 2, i1); j1 = Math.min(rows - 2, j1);
        float min = Float.POSITIVE_INFINITY;
        for (int j = j0; j <= j1; j++)
            for (int i = i0; i <= i1; i++) min = Math.min(min, cellDet(i, j));
        return min == Float.POSITIVE_INFINITY ? 1f : min;
    }

    /**
     * Verificacion densa del mapa REAL evaluado (B-spline): determinante minimo
     * de dS por diferencias centrales en una rejilla de muestreo de paso h px.
     */
    public float minJacobianDense(int x0, int y0, int x1, int y1, float h) {
        float[] a = new float[2], b = new float[2], c = new float[2], d = new float[2];
        float min = Float.POSITIVE_INFINITY;
        for (float y = y0 + .5f; y < y1; y += h) {
            for (float x = x0 + .5f; x < x1; x += h) {
                sample(x + .5f, y, a); sample(x - .5f, y, b);
                sample(x, y + .5f, c); sample(x, y - .5f, d);
                float sxx = 1f + a[0] - b[0], syx = a[1] - b[1];
                float sxy = c[0] - d[0], syy = 1f + c[1] - d[1];
                float det = sxx * syy - sxy * syx;
                if (det < min) min = det;
            }
        }
        return min == Float.POSITIVE_INFINITY ? 1f : min;
    }

    /** det minimo en los puntos de control del verificador, en todo el campo. */
    public float minGuardSamples() {
        int n = (cols - 1) * (rows - 1) * perCell();
        float[] buf = new float[n];
        return evalDets(0, 0, cols - 2, rows - 2, buf);
    }

    /** det(dS) por diferencias finitas de la B-spline en el punto p (pruebas). */
    public float detAt(float x, float y) {
        float[] a = new float[2], b = new float[2], c = new float[2], d = new float[2];
        float h = .05f;
        sample(x + h, y, a); sample(x - h, y, b); sample(x, y + h, c); sample(x, y - h, d);
        float sxx = 1f + (a[0] - b[0]) / (2 * h), syx = (a[1] - b[1]) / (2 * h);
        float sxy = (c[0] - d[0]) / (2 * h), syy = 1f + (c[1] - d[1]) / (2 * h);
        return sxx * syy - sxy * syx;
    }

    /** Copia exacta (pruebas y comparaciones). */
    public float[] snapshotU() { return cu.clone(); }
    public float[] snapshotV() { return cv.clone(); }
}
