package com.pacco.animecut.core;

/**
 * Perfil del pincel de Especial: f(rho), rho = distancia / radio.
 * f(0) = 1, f(1) = 0, con pendiente nula en el centro Y en el borde, por lo que
 * el perimetro del pincel no deja escalones en el campo.
 *
 * Ademas calcula numericamente las cotas que usa LiquifyStroke para que cada
 * sub-estampa no pueda plegar la imagen:
 *  - maxSlope   = max |f'(rho)|           (Arrastrar)
 *  - radialMin  = min (f + rho f')        (Contraer)
 *  - radialMax  = max (f + rho f') = 1    (Expandir)
 */
public final class LiquifyFalloff {
    private static final int N = 1024;
    private final float[] table = new float[N + 2];
    public final float softness;
    public final float maxSlope, radialMin, radialMax;

    public LiquifyFalloff(float softness) {
        this.softness = Math.max(0f, Math.min(1f, softness));
        float gamma = 1.65f - .85f * this.softness;
        for (int k = 0; k <= N + 1; k++) {
            float d2 = Math.min(1f, k / (float) N);
            table[k] = shape(d2, gamma);
        }
        // Cotas con muestreo fino de rho (derivada por diferencias centrales).
        float slope = 0f, rmin = Float.POSITIVE_INFINITY, rmax = Float.NEGATIVE_INFINITY;
        int samples = 4000;
        float h = 1f / samples;
        for (int k = 0; k <= samples; k++) {
            float rho = k * h;
            float a = shape(Math.max(0f, rho - h * .5f), gamma, true);
            float b = shape(Math.min(1f, rho + h * .5f), gamma, true);
            float d = (b - a) / h;
            float f = shape(rho, gamma, true);
            slope = Math.max(slope, Math.abs(d));
            float rad = f + rho * d;
            rmin = Math.min(rmin, rad);
            rmax = Math.max(rmax, rad);
        }
        // Pequeno margen por la interpolacion lineal de la tabla.
        maxSlope = slope * 1.02f;
        radialMin = rmin * 1.02f;
        radialMax = Math.max(1f, rmax * 1.02f);
    }

    private static float shape(float rho, float gamma, boolean byRho) {
        return shape(rho * rho, gamma);
    }

    private static float shape(float d2, float gamma) {
        if (d2 >= 1f) return 0f;
        float q = 1f - d2;
        q = q * q * (3f - 2f * q);
        return (float) Math.pow(q, gamma);
    }

    /** df/drho a partir de rho^2 (diferencia de la tabla). */
    public float slope(float d2) {
        if (d2 >= 1f || d2 <= 0f) return 0f;
        float rho = (float) Math.sqrt(d2);
        float h = .004f;
        float a = rho - h, b = rho + h;
        if (a < 0f) a = 0f;
        if (b > 1f) b = 1f;
        return (value(b * b) - value(a * a)) / (b - a);
    }

    /** f a partir de rho^2 en [0,1). */
    public float value(float d2) {
        if (d2 >= 1f) return 0f;
        if (d2 <= 0f) return 1f;
        float x = d2 * N;
        int k = (int) x;
        float t = x - k;
        return table[k] + (table[k + 1] - table[k]) * t;
    }
}
