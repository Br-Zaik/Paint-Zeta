package com.pacco.animecut.core;

/** Utilidades de color ARGB sin premultiplicar usadas en bordes transparentes. */
public final class AlphaColors {
    private AlphaColors() {}

    /**
     * Interpolación en espacio alfa premultiplicado, para no oscurecer líneas
     * blancas al mezclarlas con píxeles transparentes RGB=0.
     * No modifica el alpha original ni aplica color de fondo.
     */
    public static int mix(int a, int b, float factor) {
        if (factor <= 0f) return a;
        if (factor >= 1f) return b;
        final float left = (1f - factor) * (a >>> 24);
        final float right = factor * (b >>> 24);
        final float weight = left + right;
        if (weight <= 0.0001f) return 0;
        final int alpha = clamp(Math.round(weight));
        final int r = clamp(Math.round((((a >>> 16) & 255) * left + ((b >>> 16) & 255) * right) / weight));
        final int g = clamp(Math.round((((a >>> 8) & 255) * left + ((b >>> 8) & 255) * right) / weight));
        final int blue = clamp(Math.round(((a & 255) * left + (b & 255) * right) / weight));
        return (alpha << 24) | (r << 16) | (g << 8) | blue;
    }

    private static int clamp(int value) {
        return value < 0 ? 0 : Math.min(255, value);
    }
}
