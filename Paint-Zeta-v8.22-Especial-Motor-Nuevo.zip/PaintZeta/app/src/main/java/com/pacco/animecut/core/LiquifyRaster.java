package com.pacco.animecut.core;

/**
 * Rasterizador UNICO de Especial: lo usan la vista previa y el resultado final,
 * por eso al levantar el dedo no puede aparecer un salto.
 *
 * Para cada pixel destino p: S(p) = p + U(p) (B-spline del campo) y se toma el
 * color ORIGINAL en S(p):
 * - zona sin deformar: pixel original exacto (bit a bit);
 * - zona estirada o casi 1:1: bilineal en alfa premultiplicado;
 * - zona contraida: varias muestras repartidas sobre la huella del pixel en la
 *   fuente (hasta 3x3, anisotropo), para no producir bandas ni muaré.
 * Fuera del lienzo se repite el pixel del borde (no entra negro ni transparente).
 *
 * Una instancia por hilo: reutiliza sus buffers (sin asignaciones por pixel).
 */
public final class LiquifyRaster {
    public static final int TILE = LiquifySource.TILE;
    private static final int E = TILE + 2;
    /** (1,3 px)^2: limite de huella a partir del cual se promedian varias muestras. */
    private static final float SS2 = 1.3f * 1.3f;

    private final float[] su = new float[E * E], sv = new float[E * E];
    private final int[] ix0 = new int[E];
    private final float[] wx = new float[E * 4];
    private final float[] colU = new float[E + 8], colV = new float[E + 8];
    private final float[] wy = new float[4];

    /** Muestras extra usadas (diagnostico). */
    public long supersampledPixels;

    /**
     * Renderiza el bloque (tx,ty) en out (stride 64).
     * @param selection mascara de seleccion del trazo o null
     * @param prev      contenido del bloque antes del trazo (solo con seleccion)
     */
    public void renderTile(LiquifyField field, LiquifySource src, int tx, int ty,
            byte[] selection, int[] prev, int[] out) {
        final int w = src.width, h = src.height;
        final int x0 = tx * TILE, y0 = ty * TILE;
        final int tw = Math.min(TILE, w - x0), th = Math.min(TILE, h - y0);
        final int key = ty * src.tilesX + tx;
        final int[] baseTile = src.tile(key);
        final int step = field.step;
        final float invS = 1f / step;

        // Seleccion: bloque totalmente fuera -> queda como estaba antes del trazo.
        int selMode = 1; // 0 nada, 1 todo, 2 mezcla
        if (selection != null) {
            boolean any = false, all = true;
            for (int y = 0; y < th && (all || !any); y++) {
                int row = (y0 + y) * w + x0;
                for (int x = 0; x < tw; x++) {
                    int m = selection[row + x] & 255;
                    if (m != 0) any = true;
                    if (m != 255) all = false;
                }
            }
            selMode = !any ? 0 : all ? 1 : 2;
            if (selMode == 0) {
                int[] keep = prev != null ? prev : baseTile;
                for (int y = 0; y < th; y++) System.arraycopy(keep, y * TILE, out, y * TILE, tw);
                return;
            }
        }

        // Campo nulo en todo el soporte del bloque -> original exacto.
        int ni0 = (int) Math.floor((x0 - 1 + .5f) * invS) - 2;
        int ni1 = (int) Math.floor((x0 + tw + .5f) * invS) + 3;
        int nj0 = (int) Math.floor((y0 - 1 + .5f) * invS) - 2;
        int nj1 = (int) Math.floor((y0 + th + .5f) * invS) + 3;
        if (field.isZero(ni0, nj0, ni1, nj1)) {
            if (selMode == 1) {
                for (int y = 0; y < th; y++) System.arraycopy(baseTile, y * TILE, out, y * TILE, tw);
            } else {
                for (int y = 0; y < th; y++) {
                    int row = (y0 + y) * w + x0;
                    for (int x = 0; x < tw; x++) {
                        int m = selection[row + x] & 255;
                        int o = y * TILE + x;
                        out[o] = mixSel(prev != null ? prev[o] : baseTile[o], baseTile[o], m);
                    }
                }
            }
            return;
        }

        // 1) S(p) para el bloque con un pixel de margen (derivadas centrales).
        final int cw = tw + 2, chh = th + 2;
        int icMin = Integer.MAX_VALUE, icMax = Integer.MIN_VALUE;
        for (int c = 0; c < cw; c++) {
            float gx = (x0 - 1 + c + .5f) * invS;
            int i0 = (int) Math.floor(gx);
            ix0[c] = i0;
            float f = gx - i0, f2 = f * f, f3 = f2 * f, g = 1f - f;
            int b = c * 4;
            wx[b] = g * g * g * (1f / 6f);
            wx[b + 1] = (3f * f3 - 6f * f2 + 4f) * (1f / 6f);
            wx[b + 2] = (-3f * f3 + 3f * f2 + 3f * f + 1f) * (1f / 6f);
            wx[b + 3] = f3 * (1f / 6f);
            if (i0 - 1 < icMin) icMin = i0 - 1;
            if (i0 + 2 > icMax) icMax = i0 + 2;
        }
        final int ncol = icMax - icMin + 1;
        final int cols = field.cols, rows = field.rows;
        final float[] cu = field.cu, cv = field.cv;
        for (int r = 0; r < chh; r++) {
            int py = y0 - 1 + r;
            float gy = (py + .5f) * invS;
            int j0 = (int) Math.floor(gy);
            LiquifyField.bspline(gy - j0, wy);
            int r0 = clamp(j0 - 1, rows) * cols, r1 = clamp(j0, rows) * cols;
            int r2 = clamp(j0 + 1, rows) * cols, r3 = clamp(j0 + 2, rows) * cols;
            float a0 = wy[0], a1 = wy[1], a2 = wy[2], a3 = wy[3];
            for (int c = 0; c < ncol; c++) {
                int ic = clamp(icMin + c, cols);
                colU[c] = a0 * cu[r0 + ic] + a1 * cu[r1 + ic] + a2 * cu[r2 + ic] + a3 * cu[r3 + ic];
                colV[c] = a0 * cv[r0 + ic] + a1 * cv[r1 + ic] + a2 * cv[r2 + ic] + a3 * cv[r3 + ic];
            }
            int o = r * cw;
            for (int c = 0; c < cw; c++) {
                int base = ix0[c] - 1 - icMin, b = c * 4;
                float u = wx[b] * colU[base] + wx[b + 1] * colU[base + 1]
                        + wx[b + 2] * colU[base + 2] + wx[b + 3] * colU[base + 3];
                float v = wx[b] * colV[base] + wx[b + 1] * colV[base + 1]
                        + wx[b + 2] * colV[base + 2] + wx[b + 3] * colV[base + 3];
                su[o + c] = (x0 - 1 + c) + u;
                sv[o + c] = py + v;
            }
        }

        // 2) Muestreo del original.
        for (int y = 0; y < th; y++) {
            int py = y0 + y;
            int selRow = py * w + x0;
            for (int x = 0; x < tw; x++) {
                int px = x0 + x;
                int idx = (y + 1) * cw + (x + 1);
                float sx = su[idx], sy = sv[idx];
                int o = y * TILE + x;
                int warped;
                if (sx == px && sy == py) {
                    warped = baseTile[o];
                } else {
                    float jxx = (su[idx + 1] - su[idx - 1]) * .5f, jxy = (sv[idx + 1] - sv[idx - 1]) * .5f;
                    float jyx = (su[idx + cw] - su[idx - cw]) * .5f, jyy = (sv[idx + cw] - sv[idx - cw]) * .5f;
                    float qx = jxx * jxx + jxy * jxy, qy = jyx * jyx + jyy * jyy;
                    // Huella del pixel en la fuente &lt;= 1,3 px por eje: una bilineal basta
                    // (sin aliasing visible). Mas compresion: filtro de huella.
                    if (qx <= SS2 && qy <= SS2) {
                        warped = bilinear(src, sx, sy);
                    } else {
                        float fpx = (float) Math.sqrt(qx), fpy = (float) Math.sqrt(qy);
                        warped = footprint(src, sx, sy, jxx, jxy, fpx, fpx - 1f, jyx, jyy, fpy, fpy - 1f);
                        supersampledPixels++;
                    }
                }
                if (selMode == 1) out[o] = warped;
                else {
                    int m = selection[selRow + x] & 255;
                    out[o] = mixSel(prev != null ? prev[o] : baseTile[o], warped, m);
                }
            }
        }
    }

    private static int mixSel(int before, int after, int m) {
        return m == 0 ? before : m == 255 ? after : AlphaColors.mix(before, after, m / 255f);
    }

    private static int clamp(int i, int n) {
        return i < 0 ? 0 : (i >= n ? n - 1 : i);
    }

    /** Bilineal ARGB (alfa premultiplicado), coordenadas de indice de pixel. */
    static int bilinear(LiquifySource src, float x, float y) {
        int w = src.width, h = src.height;
        if (x < 0f) x = 0f; else if (x > w - 1) x = w - 1;
        if (y < 0f) y = 0f; else if (y > h - 1) y = h - 1;
        int x0 = (int) x, y0 = (int) y;
        float fx = x - x0, fy = y - y0;
        int lx = x0 & LiquifySource.MASK, ly = y0 & LiquifySource.MASK;
        if (lx < TILE - 1 && ly < TILE - 1) {
            // Las cuatro muestras estan en el mismo bloque (caso habitual).
            int[] t = src.tileAt(x0, y0);
            int o = (ly << LiquifySource.SHIFT) | lx;
            int a = t[o];
            if (fx == 0f && fy == 0f) return a;
            return blend(a, t[o + 1], t[o + TILE], t[o + TILE + 1], fx, fy);
        }
        int a = src.fetch(x0, y0);
        if (fx == 0f && fy == 0f) return a;
        int x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
        return blend(a, src.fetch(x1, y0), src.fetch(x0, y1), src.fetch(x1, y1), fx, fy);
    }

    /** Promedio de nX x nY bilineales repartidos en la huella del pixel en la fuente. */
    private int footprint(LiquifySource src, float sx, float sy,
            float jxx, float jxy, float fpx, float wX,
            float jyx, float jyy, float fpy, float wY) {
        int nX = wX <= .3f ? 1 : Math.min(3, 1 + (int) Math.ceil(wX));
        int nY = wY <= .3f ? 1 : Math.min(3, 1 + (int) Math.ceil(wY));
        // Huella mas ancha que 4 muestras: se ensancha el reparto (filtro de caja).
        float ux = fpx > 1e-6f ? jxx / fpx : 1f, uy = fpx > 1e-6f ? jxy / fpx : 0f;
        float vx = fpy > 1e-6f ? jyx / fpy : 0f, vy = fpy > 1e-6f ? jyy / fpy : 1f;
        float sa = 0f, sr = 0f, sg = 0f, sb = 0f;
        int w = src.width, h = src.height;
        for (int j = 0; j < nY; j++) {
            float oy = nY == 1 ? 0f : (j / (float) (nY - 1) - .5f) * wY;
            for (int i = 0; i < nX; i++) {
                float ox = nX == 1 ? 0f : (i / (float) (nX - 1) - .5f) * wX;
                float x = sx + ux * ox + vx * oy;
                float y = sy + uy * ox + vy * oy;
                if (x < 0f) x = 0f; else if (x > w - 1) x = w - 1;
                if (y < 0f) y = 0f; else if (y > h - 1) y = h - 1;
                int x0 = (int) x, y0 = (int) y;
                float fx = x - x0, fy = y - y0;
                int c00, c10, c01, c11;
                int lx = x0 & LiquifySource.MASK, ly = y0 & LiquifySource.MASK;
                if (lx < TILE - 1 && ly < TILE - 1) {
                    int[] t = src.tileAt(x0, y0);
                    int o = (ly << LiquifySource.SHIFT) | lx;
                    c00 = t[o]; c10 = t[o + 1]; c01 = t[o + TILE]; c11 = t[o + TILE + 1];
                } else {
                    int x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
                    c00 = src.fetch(x0, y0); c10 = src.fetch(x1, y0);
                    c01 = src.fetch(x0, y1); c11 = src.fetch(x1, y1);
                }
                float w00 = (1f - fx) * (1f - fy), w10 = fx * (1f - fy), w01 = (1f - fx) * fy, w11 = fx * fy;
                float a00 = (c00 >>> 24) * w00, a10 = (c10 >>> 24) * w10, a01 = (c01 >>> 24) * w01, a11 = (c11 >>> 24) * w11;
                sa += a00 + a10 + a01 + a11;
                sr += ((c00 >>> 16) & 255) * a00 + ((c10 >>> 16) & 255) * a10 + ((c01 >>> 16) & 255) * a01 + ((c11 >>> 16) & 255) * a11;
                sg += ((c00 >>> 8) & 255) * a00 + ((c10 >>> 8) & 255) * a10 + ((c01 >>> 8) & 255) * a01 + ((c11 >>> 8) & 255) * a11;
                sb += (c00 & 255) * a00 + (c10 & 255) * a10 + (c01 & 255) * a01 + (c11 & 255) * a11;
            }
        }
        float n = nX * nY;
        int ia = (int) (sa / n + .5f);
        if (ia <= 0 || sa < 1e-4f) return 0;
        if (ia > 255) ia = 255;
        float inv = 1f / sa;
        int r = Math.min(255, (int) (sr * inv + .5f));
        int g = Math.min(255, (int) (sg * inv + .5f));
        int b = Math.min(255, (int) (sb * inv + .5f));
        return (ia << 24) | (r << 16) | (g << 8) | b;
    }

    /** Interpolacion ARGB en alfa premultiplicado (sin halo negro en transparencias). */
    public static int blend(int a, int b, int c, int d, float fx, float fy) {
        float w0 = (1f - fx) * (1f - fy), w1 = fx * (1f - fy);
        float w2 = (1f - fx) * fy, w3 = fx * fy;
        int aa = a >>> 24, ab = b >>> 24, ac = c >>> 24, ad = d >>> 24;
        if ((aa & ab & ac & ad) == 255) {
            // Valores &gt;= 0: (int)(v + .5) equivale a Math.round y es mas rapido.
            int rr = (int) (((a >>> 16) & 255) * w0 + ((b >>> 16) & 255) * w1
                    + ((c >>> 16) & 255) * w2 + ((d >>> 16) & 255) * w3 + .5f);
            int gg = (int) (((a >>> 8) & 255) * w0 + ((b >>> 8) & 255) * w1
                    + ((c >>> 8) & 255) * w2 + ((d >>> 8) & 255) * w3 + .5f);
            int bb = (int) ((a & 255) * w0 + (b & 255) * w1 + (c & 255) * w2 + (d & 255) * w3 + .5f);
            return 0xff000000 | (Math.min(255, rr) << 16) | (Math.min(255, gg) << 8) | Math.min(255, bb);
        }
        float alpha = aa * w0 + ab * w1 + ac * w2 + ad * w3;
        int ia = Math.min(255, Math.max(0, Math.round(alpha)));
        if (ia == 0 || alpha < .0001f) return 0;
        float r = (((a >>> 16) & 255) * aa * w0 + ((b >>> 16) & 255) * ab * w1
                + ((c >>> 16) & 255) * ac * w2 + ((d >>> 16) & 255) * ad * w3) / alpha;
        float g = (((a >>> 8) & 255) * aa * w0 + ((b >>> 8) & 255) * ab * w1
                + ((c >>> 8) & 255) * ac * w2 + ((d >>> 8) & 255) * ad * w3) / alpha;
        float bl = ((a & 255) * aa * w0 + (b & 255) * ab * w1
                + (c & 255) * ac * w2 + (d & 255) * ad * w3) / alpha;
        return (ia << 24) | (Math.min(255, Math.round(r)) << 16)
                | (Math.min(255, Math.round(g)) << 8) | Math.min(255, Math.round(bl));
    }
}
