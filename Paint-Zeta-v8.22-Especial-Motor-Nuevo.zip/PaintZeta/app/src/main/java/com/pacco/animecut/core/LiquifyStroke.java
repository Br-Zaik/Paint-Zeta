package com.pacco.animecut.core;

/**
 * Convierte el recorrido del dedo (x, y, tiempo) en sub-estampas para LiquifyField.
 *
 * - Arrastrar depende SOLO del camino recorrido: el mismo trazo da el mismo
 *   campo aunque Android entregue 10 o 200 eventos (se reparte por longitud).
 * - Contraer, Expandir, Suavizar y Restaurar dependen del TIEMPO que el dedo
 *   esta apoyado (tambien con el dedo quieto) y se reparten a lo largo del
 *   camino recorrido en ese tiempo.
 * - Ninguna sub-estampa supera la cota que garantiza det(dT) &gt;= 1 - KAPPA.
 *   Un movimiento grande se divide en mas sub-estampas; nunca se recorta ni se
 *   descarta la parte "sobrante" del movimiento.
 */
public final class LiquifyStroke {
    public interface Sink {
        void onDirty(int x0, int y0, int x1, int y1);
    }

    /** Espaciado maximo entre centros, en radios. */
    public static final float SPACING = .15f;
    /** Cuanto de tiempo para modos de presion fija (s). */
    public static final float TIME_QUANTUM = 1f / 60f;
    /** Paso de tiempo maximo que se acepta entre dos eventos (evita saltos tras un tiron). */
    public static final float MAX_DT = .10f;

    private final LiquifyField field;
    private int mode;
    private float radius, strength;
    private LiquifyFalloff falloff;
    private byte[] selection;
    private float lastX, lastY;
    private long lastT;
    // Recorrido: ultimo punto donde se coloco una estampa y distancia acumulada.
    private float anchorX, anchorY, carry, spacing;
    // Modos de tiempo: cantidad acumulada aun no aplicada.
    private float pending, perStamp, quantum;
    private boolean active;
    /** Sub-estampas aplicadas en este trazo (diagnostico/pruebas). */
    public int subStamps;

    public LiquifyStroke(LiquifyField field) {
        this.field = field;
    }

    public boolean isActive() { return active; }
    public float lastX() { return lastX; }
    public float lastY() { return lastY; }

    /** Radio efectivo: al menos 2,5 nodos para que el campo represente el perfil. */
    public static float effectiveRadius(float radius, int step) {
        return Math.max(radius, 2.5f * step);
    }

    /** Ganancia de Arrastrar: fraccion del movimiento del dedo que sigue el centro. */
    public static float dragGain(float strength) {
        return Math.max(.05f, Math.min(1f, strength));
    }

    /** Velocidad por segundo de cada modo temporal segun FUERZA (0..1). */
    public static float rate(int mode, float strength) {
        float s = Math.max(0f, Math.min(1f, strength));
        switch (mode) {
            case LiquifyField.PINCH:
            case LiquifyField.EXPAND: return .10f + 1.20f * s;
            case LiquifyField.SMOOTH: return 1.0f + 5.0f * s;
            case LiquifyField.RESTORE: return 1.5f + 8.0f * s;
            default: return 0f;
        }
    }

    public void begin(int mode, float radius, float strength, float softness,
            byte[] selection, float x, float y, long timeMs) {
        this.mode = mode;
        this.radius = effectiveRadius(Math.max(1f, radius), field.step);
        this.strength = Math.max(0f, Math.min(1f, strength));
        if (falloff == null || Math.abs(falloff.softness - softness) > 1e-4f)
            falloff = new LiquifyFalloff(softness);
        this.selection = selection;
        lastX = x; lastY = y; lastT = timeMs;
        anchorX = x; anchorY = y;
        carry = 0f;
        pending = 0f;
        subStamps = 0;
        active = true;
        float r = this.radius;
        if (mode == LiquifyField.DRAG) {
            float k = dragGain(this.strength);
            float byFold = LiquifyField.KAPPA * r / (k * falloff.maxSlope);
            spacing = Math.min(SPACING * r, byFold);
        } else {
            spacing = SPACING * r;
        }
        if (mode == LiquifyField.PINCH) {
            perStamp = falloff.radialMin < 0f ? LiquifyField.KAPPA / -falloff.radialMin : 1f;
            perStamp = Math.min(perStamp, .35f);
        } else if (mode == LiquifyField.EXPAND) {
            perStamp = Math.min(.35f, LiquifyField.KAPPA / falloff.radialMax);
        } else {
            perStamp = .15f; // Suavizar/Restaurar: cambios pequenos y frecuentes
        }
        quantum = rate(mode, this.strength) * TIME_QUANTUM;
    }

    /** Levantar el dedo: aplica el tramo final pendiente (nada se pierde). */
    public void finish(Sink sink) {
        if (!active) return;
        if (mode == LiquifyField.DRAG) {
            float dx = lastX - anchorX, dy = lastY - anchorY;
            if (dx * dx + dy * dy > 1e-8f) {
                float k = dragGain(strength);
                stamp((anchorX + lastX) * .5f, (anchorY + lastY) * .5f, dx * k, dy * k, 0f, sink);
                anchorX = lastX; anchorY = lastY;
            }
        } else if (pending > 0f) {
            emitAmount(lastX, lastY, sink);
        }
        carry = 0f;
        active = false;
    }

    public void end() { active = false; }

    /** Dedo quieto: solo avanza el tiempo. */
    public void tick(long timeMs, Sink sink) {
        moveTo(lastX, lastY, timeMs, sink);
    }

    /**
     * Las sub-estampas se colocan a distancias IGUALES a lo largo del recorrido
     * (no una por evento). Asi 60 Hz, 120 Hz, 240 Hz o lotes irregulares de
     * Android producen practicamente la misma secuencia de estampas.
     */
    public void moveTo(float x, float y, long timeMs, Sink sink) {
        if (!active || !Float.isFinite(x) || !Float.isFinite(y)) return;
        float dt = Math.max(0f, Math.min(MAX_DT, (timeMs - lastT) / 1000f));
        if (timeMs > lastT) lastT = timeMs;
        boolean drag = mode == LiquifyField.DRAG;
        if (!drag) pending += rate(mode, strength) * dt;
        float sx = lastX, sy = lastY;
        float dx = x - sx, dy = y - sy;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        float pos = 0f;
        while (len > 1e-6f && carry + (len - pos) >= spacing) {
            pos += spacing - carry;
            carry = 0f;
            float t = pos / len;
            float px = sx + dx * t, py = sy + dy * t;
            if (drag) {
                float k = dragGain(strength);
                stamp((anchorX + px) * .5f, (anchorY + py) * .5f,
                        (px - anchorX) * k, (py - anchorY) * k, 0f, sink);
            } else if (pending > 0f) {
                emitAmount(px, py, sink);
            }
            anchorX = px; anchorY = py;
        }
        if (len > 1e-6f) carry += len - pos;
        lastX = x; lastY = y;
        // Dedo quieto o lento en modos de tiempo: aplicar por cuantos de tiempo.
        if (!drag && pending >= quantum) emitAmount(x, y, sink);
    }

    private void emitAmount(float x, float y, Sink sink) {
        float total = pending;
        pending = 0f;
        int n = Math.max(1, (int) Math.ceil(total / perStamp));
        float a = total / n;
        for (int i = 0; i < n; i++) stamp(x, y, 0f, 0f, a, sink);
    }

    private void stamp(float cx, float cy, float mx, float my, float amount, Sink sink) {
        if (field.apply(mode, cx, cy, mx, my, amount, radius, falloff, selection)) {
            subStamps++;
            int[] d = field.lastDirty;
            if (sink != null) sink.onDirty(d[0], d[1], d[2], d[3]);
        }
    }
}
