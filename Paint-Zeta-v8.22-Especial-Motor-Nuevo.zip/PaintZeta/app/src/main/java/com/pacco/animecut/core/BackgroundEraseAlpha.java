package com.pacco.animecut.core;

/**
 * Prepara la transparencia del borrador mágico sin mutar la capa.
 * No usa clases Android: comprobable con javac en pruebas de JVM.
 */
public final class BackgroundEraseAlpha {
    private BackgroundEraseAlpha() {}

    /** Devuelve (right-left)*(bottom-top) bytes de alfa ya descontaminada.
     * El llamante conserva los RGB originales y confirma el resultado en UI.
     */
    public static byte[] prepare(int[] px, int w, int h, int left, int top,
                                 int right, int bottom, byte[] mask, byte[] selection,
                                 int bgRef, int tolerance, int colorMode) {
        if (px == null || mask == null || left < 0 || top < 0 || right > w || bottom > h
                || left >= right || top >= bottom) throw new IllegalArgumentException("ROI");
        int rw = right - left, rh = bottom - top;
        byte[] alpha = new byte[rw * rh];
        for (int y = top; y < bottom; y++) {
            int src = y * w + left, dst = (y - top) * rw;
            for (int x = 0; x < rw; x++) {
                int i = src + x;
                int a = mask[i] & 255;
                int orig = px[i] >>> 24;
                float f = a / 255f;
                if (selection != null) f *= (selection[i] & 255) / 255f;
                alpha[dst + x] = (byte) (a == 0 ? orig : (int) (orig * (1f - f)));
            }
        }
        // Eliminar motas sin dependencia del orden de visita: igual que el
        // despeckle anterior, todos los vecinos usan alfa ANTES de esta fase.
        byte[] remove = null;
        int limit = tolerance * 2;
        for (int y = Math.max(1, top); y < Math.min(h - 1, bottom); y++) {
            int row = (y - top) * rw;
            for (int x = Math.max(1, left); x < Math.min(w - 1, right); x++) {
                int j = row + x - left;
                if ((alpha[j] & 255) == 0) continue;
                int i = y * w + x;
                if (ColorDist.dist(px[i] | 0xFF000000, bgRef | 0xFF000000, colorMode) > limit) continue;
                int empty = 0;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int xx = x + dx, yy = y + dy;
                    int na = xx >= left && xx < right && yy >= top && yy < bottom
                            ? alpha[(yy - top) * rw + xx - left] & 255
                            : px[yy * w + xx] >>> 24;
                    if (na < 40) empty++;
                }
                if (empty >= 5) {
                    if (remove == null) remove = new byte[alpha.length];
                    remove[j] = 1;
                }
            }
        }
        if (remove != null) {
            for (int i = 0; i < alpha.length; i++) if (remove[i] != 0) alpha[i] = 0;
        }
        return alpha;
    }
}
