# Paint Zeta v8.19.1 — Recuperar Curva y Polilínea

## Cambio puntual solicitado

- **Curva** y **Polilínea** vuelven a aparecer en **PINTAR Y RETOCAR**, junto con Brocha, Goma, Relleno, Difuminar, Borrosidad y Especial.
- Estas dos herramientas **dibujan sobre la capa** y **no requieren una selección azul**. Se retiraron por error en v8.17 al simplificar el menú.
- Se conservan sus motores existentes, iconos originales (`ic_curve`, `ic_poly`), y controles existentes: creación/edición de puntos, alternar Curva/Polilínea, rellenar, borrar puntos y confirmar trazo.
- No se ha restaurado Varita, Marcar azul, Borrar azul, Tijeras o Magnético.
- No se ha modificado el motor de Especial, zoom, capas ni el borrado de fondo en esta revisión.
- Código: `app/src/main/java/com/pacco/animecut/MainActivity.java` (definición `TOOLS`).
- Versión `8.19.1` / código `57` para instalar una compilación nueva sobre la anterior si conserva la firma.

## Verificación

Se comprobó la presencia de las dos herramientas en la lista de menú y la existencia de sus implementaciones e iconos. **Sin APK compilado ni pruebas en teléfono Android**: hay que verificar la interacción real cuando se compile.
