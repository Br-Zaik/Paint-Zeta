# Paint Zeta v8.20 — Especial: remapeo inverso y estabilidad de navegación

## Problema de origen

Las capturas de v8.19 muestran contornos quebrados, estiramientos incorrectos y lentitud en **Especial**. El código anterior almacenaba desplazamientos *hacia delante* y, para reconstruir **cada píxel** modificado, invertía numéricamente el mapa mediante hasta seis iteraciones de Newton y varias evaluaciones del jacobiano. Esto añadía carga de CPU y podía introducir saltos en regiones de fuerte deformación. Una prueba matemática estática no equivale a comprobar el resultado en Android.

## Implementado en código (v8.20)

1. **Nuevo motor de Especial separado de Malla:** `core/InverseLiquifyEngine.java`. El campo indica directamente de qué coordenada original debe leerse cada píxel destino. No utiliza Newton ni rasterización de triángulos para Especial. Se conservan cinco modos: Arrastrar, Contraer, Expandir, Suavizar y Restaurar.
2. **Deformación controlada:** fuerza proporcional en Arrastrar, influencia gradual, campos temporales para Suavizar, modo Restaurar y protección por orientación/área de celda (`LiquifyTopologyGuard`); las estampas que plegarían la imagen retroceden parcialmente o se rechazan.
3. **Vista previa y resultado final:** ambos llaman a `renderLiquifyRegion`, usando interpolación bilineal y mezcla premultiplicada para transparencias; cada región se reconstruye desde la fuente original guardada por bloques, sin volver a deformar acumulativamente la imagen que ya se ve.
4. **Menos cálculos por píxel:** consulta bilineal de desplazamiento + bilineal de color, sin bucle de Newton por píxel. El trabajo continúa en CPU, por lo que no se garantiza una tasa de 60 FPS en móviles económicos.
5. **Gesto de dos dedos:** desplazar/ampliar ya no provoca rotación involuntaria del lienzo por pequeñas variaciones del ángulo de los dedos. La rotación intencional sigue disponible dentro de Transformar. Los micro-movimientos con Mano se acumulan para evitar saltos y no perder movimiento lento.
6. **Borrar fondo:** Tolerancia conserva la gota; Suavizar bordes recibe un icono distinto (`ic_feather_edge`). Se retira un botón duplicado que abría el mismo diálogo de borde, conservando el ajuste al mantener pulsado Dilatación. Se mantienen las optimizaciones del Borrador mágico incorporadas en v8.19, pero no se afirma que hayan desaparecido todos los tirones.
7. **Herramientas conservadas:** el código de **Malla, Perspectiva y Anclajes** no cambió (se verificó el bloque de fuente contra el ZIP de v8.19.1). **Curva, Polilínea, Lazo y Capas** continúan disponibles.

## Verificación realizada en este entorno

Ejecutar desde la carpeta raíz:

```sh
sh tests/run_jvm_tests.sh
```

- Pruebas Java del motor nuevo: signo de Arrastrar, cinco modos, máscara de selección, posición subpíxel, protección geométrica de los movimientos, trayectorias en zigzag, círculos y movimientos aleatorios (1300 estampas de estrés).
- Pruebas anteriores: fondo/borrador mágico (400 casos matemáticos), alfa y protección geométrica anterior.
- 20 pruebas de regresión de código; lectura de recursos XML y preservación de herramientas.
- **No se ha compilado un APK ni probado esta versión en un teléfono Android en este entorno.** En particular, **no se ha medido latencia P95, FPS, RAM, ANR ni comparado fotograma a fotograma con ibis Paint en el mismo teléfono**. No debe presentarse como calidad idéntica a ibis Paint ni lista para Google Play.

## Pruebas MANUALES obligatorias antes de considerar que esta versión está bien

1. En teléfono gama baja (p. ej., Android 11), abrir imágenes con pelo y bordes negros 720p/1080p/2K; cinco modos Especial con 32 % y 100 % de fuerza; tamaños 35, 115 y 250 px. Revisar si los trazos siguen al dedo o saltan.
2. Inspeccionar el contorno antes de tocar, durante el gesto, después de levantar el dedo y después de guardar/reabrir: deben coincidir vista previa y resultado final, sin píxeles doblados, líneas replicadas o halos negros.
3. Repetir después de hacer zoom 50 %, 100 %, 400 % y 800 %; mover con dos dedos durante Especial y durante Borrar fondo. No debe cambiar la imagen al soltar ni girar sin intención.
4. Probar Borrar fondo en modo toque y pincel, tolerancia y suavizado; validar transparente PNG, Undo/Redo y exportación para Alight Motion.
5. Probar que **Malla/Anclajes**, **Curva/Polilínea**, Lazo y el sistema de capas funcionan igual que antes. En caso de fallo, recopilar video + logcat.
6. Medir Perfetto/Android Studio Profiler: FPS, tiempo de entrada, consumo de memoria y operaciones de Especial en UI, no inferir fluidez únicamente de tests Java.

## Decisión técnica para futuras mejoras

Si un móvil real continúa mostrando mucho lag con pinceles muy grandes, la siguiente etapa será separar la rasterización de la UI, mantener una vista previa acelerada por GPU compatible con el resultado del remapeo y usar una cola de tareas por generaciones para no mostrar píxeles viejos. Esa arquitectura NO está implementada en v8.20; no debe anunciarse como si existiera.
