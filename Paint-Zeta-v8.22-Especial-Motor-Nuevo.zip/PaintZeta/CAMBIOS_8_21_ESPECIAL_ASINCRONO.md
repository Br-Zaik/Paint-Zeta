# Paint Zeta v8.21 — Especial: vista previa asincrona y fuente estable

## Alcance

Solo se ha intervenido en **Especial** y sus pruebas; la herramienta **Malla**, puntos de anclaje, Curva, Polilinea, Lazo, colores y borrado **no se han modificado**. Se parte del codigo v8.20 entregado por el usuario.

## Problema comprobable en v8.20

En `CanvasView.maybeRenderLiquifyPreview` la rasterizacion `renderLiquifyRegion` se ejecutaba sincronicamente en el hilo UI durante el movimiento, con tiempo de respuesta dependiente del numero de pixeles por estampa. `renderLiquifyRegion` y `prepareLiquifySourceBuffer` realizaban muchas busquedas por pixel en `SparseArray` de bloques originales. Una actualizacion grande de detalle podia degradar a vista reducida mientras el dedo seguia sobre el lienzo. Esto **puede contribuir** a retrasos, falta de respuesta aparente y borrosidad; la magnitud real debe medirse en el telefono.

## Cambios implementados en codigo

1. **Preview asincrono de Especial**: un unico executor de rasterizacion recibe snapshots de imagen original, campo inverso y mascara. La UI solo toma snapshots y compone la region al terminar el worker. No se escribe ninguna capa ni Bitmap desde el worker.
2. **Coalescencia/backpressure**: maximo un trabajo de preview por editor en curso; mientras tanto los eventos tactiles acumulan las zonas sucias. Al terminar el worker se procesa el ultimo estado, sin encolar una rasterizacion por cada movimiento.
3. **Proteccion contra previews caducadas**: contador de epoca comprobado antes y despues del trabajo; cambios de proyecto, cancelaciones y confirmaciones invalidan previews que no se deben aplicar despues del commit, sobre otro trazo o sobre otra capa.
4. **Muestreo compartido**: `LiquifyFrameRenderer.blend` es la interpolacion bilineal ARGB con alfa premultiplicado que usan tanto preview como el render final; zonas fuera de la deformacion conservan los pixeles originales exactos. Se evitan oscurecimientos por mezclar RGB de pixels transparentes.
5. **Lectura original por tiles**: `copyLiquifyOriginal` primero copia filas con `System.arraycopy` y luego superpone originales solo en los tiles necesarios. Reduce la cantidad de busquedas `SparseArray` de una por pixel a una por tile. El remapeo final usa acceso O(1) al buffer original cuando esta disponible.
6. **Arrastrar con regularizacion elastica**: suavizado local y ligero del campo entre nodos adyacentes, antes del control antipliegue, para reducir escalones y quiebres en contornos; no aplica desenfoque sobre la imagen y se ha probado matematicamente, aunque la mejora visual aun requiere un telefono real.
7. **Fuente local acotada**: la vista previa captura solo el desplazamiento maximo de los nodos cercanos a su ROI y acota el numero de pixeles de cada frame; el commit final sigue a resolucion original y no se recorta.
8. **Detalle visual**: al trabajar en Especial, el limite para actualizacion del detalle nitido se ajusto de 20.000 a 48.000 pixeles antes de recurrir a la vista reducida. No significa que desaparezca toda la borrosidad a zoom alto.

## Limitaciones conocidas y comprobacion requerida

- Todavia se calculan las estampas del campo, guardados originales y composicion de la region en UI. Por tanto, se redujo parte del trabajo pero **no hay garantia de 60 FPS ni ausencia total de temblor**.
- El commit final de Especial es sincronico (para conservar integracion con historial y guardado); puede tardar al soltar el dedo en imagenes grandes. No se modificaron estos subsistemas.
- Las regiones extremadamente grandes (>550.000 px visibles) se acotan en preview para proteger la memoria. El resultado definitivo se renderiza completo al soltar el dedo.
- No se ha compilado APK ni medido FPS, latencia, memoria ni comparado visualmente de forma controlada con ibis Paint en hardware Android real. **No se debe afirmar que el resultado sea identico a ibis Paint**.

## Tests automaticos realizados

Ejecutar desde la raiz del proyecto:

```bash
sh tests/run_jvm_tests.sh
```

Incluye prueba JVM nueva `LiquifyFrameRendererTest` con 50 estampas sinteticas de manga, alpha parcial y transparente, comparacion de ROI vs render completo, comprobacion determinista (sin acumulacion), mascara vacia/completa y bordes negro-blanco. Se mantienen pruebas anteriores (campo inverso, topologia y fondo), y 21 comprobaciones estaticas. Los tests JVM no sustituyen la compilacion Android ni pruebas en dispositivo.

## QA recomendado en el telefono

1. Abrir manga/manhwa con cabello de lineas finas y zoom 100%, 200%, 400%. Comparar clip de ibis Paint en identica zona, tamanos de 35/83/115px y fuerza 32/59/100%.
2. Arrastrar rapido durante 10 segundos en zigzag y circulos: comprobar latencia percibida, contornos, ausencia de saltos atras de los frames y cambios al levantar dedo.
3. Probar Contraer, Expandir, Suavizar y Restaurar con presion fija y movimiento; verificar que el campo no quede congelado despues de muchas estampas.
4. Usar dos dedos durante Especial, deshacer, rehacer, guardar/reabrir, transparencia, mascara y multiples capas. Debe ser imposible que un preview viejo reescriba el commit o el cambio de capa.
5. Usar Android Studio Profiler/Perfetto con un telefono economico: registrar FPS/P95, tiempo UI de copia original, tiempo worker por frame, RAM y tiempo del commit final.
