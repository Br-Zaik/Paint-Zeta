# Lista de pruebas manuales (Android)

- [ ] Abrir una ilustración nueva y comprobar que empieza en Brocha, sin selección azul.
- [ ] Menú de herramientas: solo EXTRAER PERSONAJES, PINTAR Y RETOCAR, MOVER Y ANIMAR.
- [ ] Dibujar un lazo sobre un personaje y soltar: diálogo "Crear parte para animar".
- [ ] Elegir 'brazo_I', solapamiento 6 y crear: nueva capa; se conserva dibujo en la original.
- [ ] Capa resultante PNG con transparencia alrededor del brazo.
- [ ] Lazo sobre un área fuera del dibujo: no debe crear contenido inesperado.
- [ ] Deshacer/recrear parte, cerrar y abrir proyecto, verificar capas.
- [ ] Zoom con dos dedos en Lazo: la selección no debe confirmarse accidentalmente.
- [ ] Zoom, mover y girar con dos dedos en Brocha, Goma, Relleno, Borrar fondo, Especial, Mano, Mover, Transformar.
- [ ] Zoom continuo 25% → 400% → 25%, sin saltos grandes o giros involuntarios.
- [ ] Especial Arrastrar: 64 px, 32%; luego 115 px, 32%; no generar picos ni huecos visibles.
- [ ] Especial Contraer / Expandir / Suavizar / Restaurar; comparar vista previa con resultado final.
- [ ] Repetir sobre imagen con transparencia, sobre línea fina y cerca de bordes del lienzo.
- [ ] Medir input lag y velocidad de render (ms) en móvil de gama baja.
- [ ] Exportación por capas de un personaje a PNG para Alight Motion.
