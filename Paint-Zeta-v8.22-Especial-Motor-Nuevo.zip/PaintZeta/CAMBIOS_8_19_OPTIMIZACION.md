# Paint Zeta v8.19 — rendimiento y estabilidad (código fuente)

## Síntomas e investigación

Los videos/capturas de v8.18 muestran una interfaz simplificada, **pero una captura estática no demuestra la causa ni la cantidad de lag**. Analizando el código encontramos varios trabajos que se hacían en el hilo UI durante los gestos: muestreo de Especial, recomposición de detalle de zoom (hasta 1,2 millones de píxeles), historial táctil repetido en herramientas caras y la aplicación en UI de un borrado de fondo conectado grande.

## Implementado

1. **Borrar fondo / borrador mágico por toque** (`CanvasView.runBgBucket`): clasificar píxeles, preparar el alfa resultante y eliminar motas pequeñas fuera del hilo principal. En UI se registra el deshacer y se aplican alfas precalculados. Usa un buffer de **1 byte por píxel** y la ruta anterior como fallback si falla la asignación. Verificar en dispositivo con lienzos enormes y poca RAM.
2. **Borrar fondo con pincel**: reducir la frecuencia espacial de las estampas que recalculan el área; buscar el siguiente color visible recorriendo los **anillos**, no todo el cuadrado para cada radio. El nuevo orden preserva el orden de búsqueda antiguo. Transparencia, límite y selección no fueron eliminados.
3. **Especial**: espaciar las estampas costosas durante gestos, limitar trabajo por evento, omitir Newton y el remuestreo para los píxeles que no se movieron, y agrupar en franjas horizontales los bloques afectados al confirmar. Se conserva el guardián geométrico, el muestreo bilineal premultiplicado y **el mismo motor** en preview/final.
4. **Zoom/edición con capas**: la recomposición síncrona de detalle se limita a 20.000 píxeles por actualización mientras se dibuja y a 60.000 píxeles para acciones aisladas; se reconstruye el resto asíncronamente. Reutiliza la matriz del cálculo de escala durante el zoom con dos dedos.
5. **Eventos táctiles**: Lazo/Brocha/Goma mantienen histórico; Especial, Difuminar y Borrar fondo evitan repetir las muestras históricas porque ya interpolan las posiciones entre eventos (deben comprobarse trazos rápidos sobre hardware).

## Qué no significa esta versión

- **No podemos garantizar 60 FPS, ausencia completa de lag, ni una calidad idéntica a ibis Paint.** No hay APK compilado ni dispositivo Android de prueba aquí.
- Esto **no es** una reescritura nativa/GPU del motor. Especial aún remapea píxeles en Java y en el hilo de la interfaz; el commit final puede tardar en lienzos grandes.
- El sistema de deshacer conserva el coste del registro de zonas grandes y las imágenes con muchas capas siguen siendo costosas.

## Pruebas necesarias antes de publicar

1. En un teléfono de gama baja y uno medio, probar archivos 720p/1080p/2K/4K con 1, 5 y 15 capas, activando la superposición de GPU y Perfetto/Android Studio Profiler.
2. En Especial: Arrastrar/Contraer/Expandir/Suavizar/Restaurar con 32 % / 64 px y 100 % / 115 px; realizar líneas finas y movimientos circulares/zigzag. Comprobar el resultado después de soltar y después de exportar. No deben aparecer triángulos plegados ni halos.
3. En Borrar fondo: fondo blanco y gris, bordes con antialias, regiones muy grandes, pincel y toque, expansión positiva/negativa, selección y deshacer/rehacer. Verificar que el color más cercano y las motas coincidan con v8.18.
4. En zoom: usar dos dedos en **cada** herramienta, interrumpir un trazo, mover sobre lienzo grande y repetir; comprobar que no aparezca detalle de imagen antiguo sobre la edición.
5. Grabaciones de pantalla a 60 FPS, logcat y tiempos P50/P95 de las estampas para detectar cuellos de botella reales; no suponer fluidez a partir de tests de sintaxis.

**Nota:** Las pruebas incluidas comprueban invariantes de código/geométricas, no tiempos ni interacción en un Android real. Los ZIP previos no se modificaron.

## Comprobación JVM de equivalencia

`tests/BackgroundEraseAlphaTest.java` compara la rutina nueva de alfa y limpieza contra la anterior con **400 casos aleatorios** de selección, tolerancia, modo de comparación y regiones; no equivale a ensayos de fluidez.
