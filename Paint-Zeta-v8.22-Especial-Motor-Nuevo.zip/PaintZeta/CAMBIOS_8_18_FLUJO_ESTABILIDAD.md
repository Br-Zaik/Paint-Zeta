# Paint Zeta 8.18 — Usabilidad para animación y correcciones puntuales

**Base:** código fuente de v8.17. Proyecto completo de Android Studio (no APK).

## Implementado

1. **Entrada coherente:** un proyecto abierto empieza con **Mano**, no con la «Varita» retirada de la lista de herramientas en v8.17. Zoom y movimiento quedan disponibles sin empezar a pintar o seleccionar accidentalmente.
2. **Flujo «Preparar personaje (pasos rápidos)»:** desde los tres puntos abre un menú corto para Borrar fondo, Lazo, Pintar, Especial, Exportar y ver Capas. Reutiliza las herramientas reales existentes, sin crear una segunda lógica inconsistente.
3. **Lazo con dos acciones claras:** una vez rodeada la pieza permite **Copiar** a otra capa sin tocar el original, o **Cortar** creando la pieza y dejando su zona quitada de la fuente. Mantiene nombre y solapamiento elegidos. La selección temporal se limpia al crear la capa con éxito.
4. **Exportación rápida para animación:** botón Exportar ofrece primero ZIP con todos los PNG transparentes visibles al tamaño original del lienzo, colocados en coordenadas idénticas para importar alineados en Alight Motion. Conserva la opción de exportación avanzada anterior y agrega un `LEEME_Partes.txt` al ZIP.
5. **Guardado con copia recuperable:** primero se genera `.acut.tmp`; el proyecto anterior queda como `.acut.bak` antes de confirmar el archivo nuevo. Si un archivo de proyecto no se puede leer, el editor prueba el respaldo. La galería lista respaldos si falta el `.acut` y al eliminar un proyecto borra también `.bak`/`.tmp`.
6. **Especial mantenido pulsado:** Contraer, Expandir, Suavizar y Restaurar vuelven a actuar a intervalos aproximados de 165 ms mientras se mantiene el dedo, cancelándose al soltar, al iniciar gesto multitáctil o al cambiar de herramienta. Arrastrar no se repite sin movimiento. El motor de campo y protección geométrica anterior se conservan.
7. **Transparencias en Borrosidad y Licuar:** el desenfoque 3×3 calcula colores ponderados por alfa; la mezcla con selección parcial usa una interpolación de alfa premultiplicado (`AlphaColors`). Se evitan oscurecimientos matemáticos al mezclar trazos de color claro con píxeles de alfa 0.
8. **Seguridad de remapeo:** si el buffer de fuente de Especial no está disponible, se descarta el buffer anterior para que no se reutilice por error; se utiliza el sampler de respaldo original.
9. **Versión:** `versionCode 55`, `versionName 8.18`.

## Validación ejecutada en este entorno

- Compilador Java 21: parseo sintáctico de 36 archivos Java, sin errores de sintaxis.
- XML: 118 archivos interpretados correctamente.
- `python tests/test_regressions.py`: 14 pruebas estáticas.
- `javac` + `java tests/AlphaColorsTest.java`: 5 pruebas de interpolación RGBA en una clase sin dependencias Android.
- `javac` + `java tests/LiquifyTopologyTest.java`: simulaciones matemáticas de zigzag y movimiento circular sin inversión de triángulos en esas trayectorias.
- Integridad del ZIP comprobada.

## LIMITACIONES — antes de llamar «terminado» a Especial o publicar en Play Store

- **No se compiló un APK:** este entorno no tiene Android SDK ni Gradle instalado. El parseo de Java verifica sintaxis, **NO** firmas de métodos Android, ni enlazado, ni funcionamiento de la interfaz.
- **No se ha medido ni confirmado el rendimiento en un móvil** (FPS, latencia y consumo). La deformación de Especial sigue recalculándose en el hilo principal: todavía podría dar tirones con lienzos grandes, según hardware.
- No se implementó de cero una herramienta automática inteligente para reconstruir partes ocultas, IA ni cambio global de color; existen funciones básicas de reparación/coloreado anteriores, pero no un motor de inpainting de nueva generación.
- Se conservan los motores antiguos invisibles del menú para compatibilidad con archivos antiguos; no son parte del flujo simplificado.
- La app **todavía no está lista para Google Play**: hace falta actualizar y probar `compileSdk`/`targetSdk` a los requisitos vigentes, compilar AAB firmado, completar ficha, políticas, privacidad y pruebas cerradas donde correspondan.

## Pruebas físicas mínimas recomendadas

1. Abrir una imagen de manga con líneas finas y probar Especial a 64 y 115 px con 32 % de fuerza; Arrastrar en zigzag/círculos, Contraer y Expandir con el dedo quieto, Suavizar y Restaurar. Comparar antes/después con video ibis Paint.
2. Durante un trazo, poner un segundo dedo, hacer zoom y arrastrar; repetir en todas las herramientas visibles. Comprobar que no quedan artefactos ni golpes de zoom.
3. Usar Lazo alrededor de cabello y brazo: **Copiar** no cambia original, **Cortar** lo separa; verificar nombre, transparencia, solapamiento y Deshacer/Rehacer.
4. Desenfocar una línea blanca o gris sobre transparencia; exportar sobre fondo oscuro/claro y buscar halos.
5. Forzar cierre de la app en mitad de varios cambios, reabrir desde galería y comprobar que hay proyecto reciente o respaldo utilizable.
6. Exportar ZIP, extraer PNG y verificar dimensiones exactas y alfa, importando las capas alineadas en Alight Motion.
7. Probar 1080p y 4K en dispositivo de pocos recursos; medir tiempos (Performance Profiler y logcat) y corregir bloqueos antes de distribuir.
