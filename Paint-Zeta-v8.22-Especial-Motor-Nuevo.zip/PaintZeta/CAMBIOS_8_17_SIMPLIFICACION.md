# Paint Zeta 8.17 — Menú simple, Lazo y navegación

## Objetivo
App ligera para recortar personajes de anime, manga y manhwa en capas; colorear y exportar para animación externa (Alight Motion). Se priorizó no romper proyectos existentes.

## Cambios aplicados al código fuente

### Herramientas disponibles en el menú
**EXTRAER PERSONAJES:** Separar y quitar fondo, Borrar fondo, Lazo.
**PINTAR Y RETOCAR:** Brocha, Goma, Relleno, Difuminar, Borrosidad, Especial.
**MOVER Y ANIMAR:** Mano, Mover, Transformar.

Se retiraron del **menú visible**: Varita, Marcar azul, Borrar azul, Tijeras, Magnético, Zona, Clonar, Línea, Copiar zona, Corrector, Trama, Curva y Polilínea. El motor de sus modos no se borró: la eliminación física sin probar compatibilidad de archivos podría dañar funciones existentes. También se eliminaron las opciones de Varita del menú de configuración, se oculta la barra de sumar/quitar selección y la fila de selección vacía en el panel de capas.

### Lazo
* Recoge los puntos históricos del dedo durante movimientos rápidos, para reducir segmentos rectos largos.
* Al levantar el dedo, abre el diálogo de crear parte: nombre y píxeles de solapamiento (por defecto 6 px).
* Al confirmar, utiliza la función `layerFromSelection(false, ...)` preexistente para copiar la parte de **la capa activa** a una **nueva capa** sin borrar la original.
* Una vez creada, limpia la selección temporal para no dejar manchas azules ni restringir brocha/Especial involuntariamente.
* Si llega un segundo dedo a mitad del contorno, se cancela el Lazo y se prioriza navegar, en lugar de recortar accidentalmente.
* Cuando falta memoria para la máscara se muestra un mensaje en lugar de cerrar abruptamente.

### Dos dedos
* Se unificó pan + pinch + giro en `twoFingers()`, antes repartidos entre `ScaleGestureDetector` y otro controlador para las herramientas normales.
* Se limita la escala a los valores ya admitidos y se evita procesar como gesto útil el dedo que acaba de levantarse.
* El control de Transformar conserva su propio tratamiento especializado de multitáctil.

### Especial
* Vista previa con intervalo **adaptativo** desde ~38 ms según duración real del procesado, en lugar de bloquear siempre al menos 70 ms entre previas. El motor de deformación y el TopologyGuard de v8.16 permanecen.
* Esto mejora la **oportunidad** de respuesta cuando el teléfono tiene capacidad, pero no garantiza 30/60 FPS: los remapeos de píxeles siguen ocurriendo en el hilo principal y el commit al levantar el dedo sigue siendo síncrono.

## Validación completada
- Parse de sintaxis de 35 archivos Java, 0 errores.
- Parse XML de 118 archivos, sin errores.
- 10 pruebas estáticas de regresión, todas superadas.
- Simulación matemática de la malla en zigzag y circular: pasa; no sustituye prueba visual Android.
- Archivo ZIP empaquetado y comprobado.

## Pendiente — OBLIGATORIO antes de declarar corregida la app
1. Compilar el APK con Android Studio, Android SDK 34 y Gradle.
2. Probar el Lazo con imágenes de 1080p/4K, capas transparentes y varios niveles de zoom.
3. Verificar que Copiar produce exactamente la región deseada y que deshacer/rehacer no altera otras capas.
4. Probar dos dedos, pinch, pan, giro y cambio de dedos en **cada** herramienta visible; revisar en particular pinch durante Especial.
5. Medir tiempo por frame de Especial en un dispositivo físico; comparar el mismo gesto sobre una línea de manga a 64/115 px y 32 % de fuerza.
6. Probar cinco modos de Especial por separado, transparencias y bordes; documentar capturas antes/después.
7. Verificar exportación PNG con transparencia para Alight Motion y reabrir los proyectos guardados.

**Esta versión NO está validada en un dispositivo real ni se asegura que los artefactos visuales de Especial estén resueltos.**
