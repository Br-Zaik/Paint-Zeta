# Paint Zeta v8.16 — Corrección estructural de Especial

Esta versión modifica **solo el motor y la interfaz de la herramienta Especial**; mantiene las herramientas ajenas a Especial y las correcciones de Brocha/color de v8.15.

## Fallos abordados

1. **Protección contra pliegues de malla:** se agregó `core/LiquifyTopologyGuard.java`. Tras cada estampado de Arrastrar, Contraer, Expandir, Suavizar y Restaurar se comprueban las áreas firmadas en las cuatro esquinas de cada celda adyacente. Si alguna casi colapsa o invierte orientación (área normalizada menor a 0,12), se reduce el incremento mediante backtracking. Si no puede mantenerse válido, se descarta el incremento y se conserva la deformación anterior.
2. **Mismo render para vista previa y resultado final:** se retiró la vista previa `drawBitmapMesh` de Especial. Tanto durante el gesto como al finalizar se utiliza `renderLiquifyRegion` con la misma inversión y el mismo muestreo bilineal, sobre una fuente estable. Las regiones anteriores permanecen pintadas hasta el commit, sin una malla superpuesta desfasada.
3. **Inversión geométrica más estable:** se sustituyeron las 3 iteraciones de punto fijo por hasta 6 iteraciones de Newton con derivadas analíticas del campo bilineal, límite de paso y comprobación del determinante. La operación se aplica por píxel también durante el gesto, no en bloques grandes.
4. **Densidad de campo:** paso de 12/16/24/32 px según dimensiones del lienzo, en lugar de 16/28/38 px. Esto ayuda con detalles finos; el guard evita que la malla más densa pueda invertirse.
5. **Área de cálculo precisa:** la región a remapear se obtiene de las posiciones originales y deformadas de las celdas cambiadas. Se evita recomputar una caja excesivamente grande por cada movimiento.
6. **Rastreo del gesto:** densidad de muestras mayor, sin tope rígido de 6 en Especial. Se mantiene el procesamiento del historial del `MotionEvent` que ya existía.
7. **Interacción:** el gotero por pulsación larga ya no interrumpe la presión fija de Contraer/Expandir; los seis controles de Especial se distribuyen con zonas táctiles mayores, sin el título que comprimía los iconos.

## Qué comprobamos en este entorno

- Compilación y ejecución JDK del **guard geométrico independiente**: identidad, inversión forzada, borde parcial, secuencia de 220 stamps en zigzag a 115 px / 32 % y secuencia de 220 stamps circular a 115 px / 32 %. **No detectó celdas invertidas en las trayectorias ensayadas**.
- **8 pruebas de regresión** sobre fuente/recursos: correctas.
- **35 archivos Java** analizados por el parser Java: sintaxis válida.
- **117 XML** de recursos leídos correctamente mediante las pruebas.

**Estas pruebas no equivalen a comprobar Android:** no hay Gradle/Android SDK ni emulador/dispositivo Android en el entorno de esta revisión. No se ha compilado el APK ni se han medido FPS, artefactos de píxeles, undo/redo y persistencia en dispositivo. La calidad visual debe verificarse con el mismo dibujo y recorrido de los videos originales.

## Pruebas manuales obligatorias antes de publicar

1. Abrir el mismo dibujo de manga del video, usar Especial → Arrastrar con **Grosor 115 px, Fuerza 32 %**, trazos en zigzag y circulares. Confirmar ausencia de picos, bandas y pliegues.
2. Repetir los cinco modos a 100 %, 250 % y 400 % de zoom, con líneas de 1–4 px, en bordes y esquinas y en áreas transparentes.
3. Comprobar que la forma visible **antes** de levantar el dedo coincide con la forma final (sin saltos o rectángulos de preview), y que es fluida en dispositivos modestos.
4. Realizar 20 trazos, deshacer, rehacer, guardar y reabrir el trabajo.
5. Comprobar selección parcial, cambiar de herramienta y volver a Especial; probar pulsación fija de Contraer/Expandir.
6. Prueba de regresión del selector de color y Brocha: cambiar color, usar, pintar 10 veces; revisar logcat ante cualquier cierre.

## Ejecución de pruebas de código

Desde la carpeta `PaintZeta`:

```bash
python -m unittest discover -s tests -v
javac -d /tmp/pz-tests app/src/main/java/com/pacco/animecut/core/LiquifyTopologyGuard.java tests/LiquifyTopologyTest.java
java -cp /tmp/pz-tests LiquifyTopologyTest
```

Para compilar APK desde Android Studio: abrir `PaintZeta` como proyecto Android Gradle, sincronizar dependencias y ejecutar `assembleDebug` con SDK Android 34 y Java 17. El flujo `.github/workflows/build.yml` incluido permite una compilación remota del ZIP usando GitHub Actions.
