# PHONK ZETA v0.6.1 — corrección prueba schema

Diagnóstico del run 35545356133 (GitHub Actions):
- La compilación Kotlin y empaquetado Android avanzaron; Gradle concluyó con error por `:app:testDebugUnitTest`.
- Prueba `multiplePianoLanesRemainIndependentAfterSave`, `ProjectAndWaveTest.kt:89`, esperaba `schema = 4`.
- El proyecto v0.6.0 guarda intencionalmente `schema = 5` para conservar clips de audio y ciclo.
- Se actualizó **únicamente la expectativa obsoleta** a 5, sin desactivar ni omitir pruebas.
- Se verificó que `TimelineEditorTest` ya espera 5 y se comprobó la estructura ZIP.
- El APK v0.6.1 todavía requiere pasar la siguiente ejecución GitHub Actions; no se ha verificado un APK ni uso en dispositivo para esta versión.
