# PHONK ZETA v0.7.0 — Editor visual

Esta versión reemplaza la pantalla EDITOR anterior (cuadrícula de casillas con '+', formularios de ciclo y texto extenso) por `VisualStudioEditor.kt`.

## Código incorporado
- Área de previsualización compacta arriba: forma de onda del audio seleccionado o notas del instrumento, siete teclas simples y botón para abrir el piano grande horizontal.
- Editor de pistas debajo, alineado con regla de minutos/segundos y cursor blanco fijo, acercar/alejar y buscar un segundo tocando o arrastrando la regla.
- Clips de audio con forma de onda (siempre que la muestra importada tenga datos), etiquetas y extremos amarillos seleccionados; arrastrar para mover; arrastrar extremos para recortar inicio o final; dividir en cursor, duplicar, repetir, ajustar volumen, silenciar, borrar.
- Clips por compás de batería e instrumentos dibujan eventos del proyecto: toque para seleccionar, arrastre por compases, duplicar, silenciar, editar notas y tocar el instrumento a pantalla completa.
- Repetición visible en la regla y líneas de pista. Botones contextuales de ciclo, 50 segundos y ampliar canción.
- Al crear el ciclo de 50 segundos, la canción se amplía si es necesario (hasta límite de 512 compases).
- El modelo de clips continúa conectado al mismo motor de reproducción y renderizado WAV/M4A de v0.6.x.
- Autosave guarda el nombre real de la canción en el archivo `autosave.json` (antes lo renombraba en pantalla a `autosave`).
- Deshacer/rehacer mantiene la pantalla activa, incluido el editor.
- La fila enorme de GENERAR PHONK/MP3/SONIDO se oculta **solo** dentro del editor (las funciones siguen disponibles desde MI CANCIÓN).

## Límites pendientes reales
No es una copia funcional íntegra de CapCut o de FL Studio. Los clips MIDI se desplazan y duplican por compás, no hay crossfade/estiramiento de audio al BPM, el editor de notas avanzado sigue en PIANO ROLL, y el audio de usuario mantiene los límites de la v0.6 (máximo ocho clips y cuatro archivos cargados). La grabación de micrófono continúa en su sección existente. Motor Kotlin AudioTrack existente, no Oboe todavía. WAV y M4A; no MP3 de salida.

## Pruebas
Se añadió una prueba de desplazamiento de notas por compás y otra de persistencia de clip de audio y ciclo. El ZIP está sometido a comprobaciones estructurales locales; la compilación APK completa se debe confirmar con GitHub Actions y el comportamiento táctil con un dispositivo Android real.
