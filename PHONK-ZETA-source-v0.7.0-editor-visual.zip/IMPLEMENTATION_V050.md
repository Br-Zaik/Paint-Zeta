# PHONK ZETA v0.5.0 — MI CANCIÓN / edición por instrumento

## Hecho en código (no es una promesa de que esté probado en dispositivo)

- La app abre ahora en **MI CANCIÓN**, no en piano roll o mezclador. Tres pestañas básicas: MI CANCIÓN, GRABACIONES, RITMOS. El botón **ESTUDIO / FÁCIL** muestra u oculta las herramientas técnicas previas.
- Nueva biblioteca de 12 sonidos sintetizados/instrumentos en castellano: cada opción tiene botón ▶ de preescucha, botón AÑADIR, opción para importar un sample propio (los 24 WAV del kit siguen en la biblioteca ya existente).
- Modelo de proyecto JSON **schema 4**: `instrumentIds`, `laneNames`, `laneAdded`. Cada una de las **12 pistas melódicas** (4..15) puede seleccionar cualquiera de los 12 sonidos sin cambiar las otras pistas. Se permiten dos o más pianos, campanas o bajos asignados a pistas distintas, hasta que se ocupen los 12 slots; 0..3 son batería. Los proyectos schema 1..3 conservan el mapa de instrumentos previo.
- El motor de audio decide el timbre por `project.instrumentIds[track]` en notas tocadas, secuenciadas y renderizadas/exportadas. El volumen/mute/solo permanece asociado a la pista, no al tipo de timbre. Botón de preescucha no agrega notas al proyecto.
- «MI CANCIÓN» enumera únicamente las pistas con notas o que el usuario añadió. Cada una muestra nombre, timbre, cantidad de notas y tomas; TOCAR/REC horizontal, CAMBIAR SONIDO, SILENCIAR, ▶ SOLO, nivel, EDITAR MIS NOTAS y BORRAR PISTA con confirmación.
- El botón ▶ SOLO también deja fuera el MP3 acompañante temporalmente durante PLAY, y TODAS vuelve a activar la mezcla (salvo pistas silenciadas a propósito).
- Grabaciones de v0.4.0 se mantienen, y EDITAR selecciona primero la pista correcta en el Piano Roll.
- La biblioteca de importación de MP3/WAV como muestra conserva el slot sampler seleccionado en vez de forzar siempre el slot 15.
- Las funciones anteriores permanecen: piano horizontal grande, modo fácil de ocho teclas, batería por pasos, generador de base, grabaciones, fondo importado, guardado, WAV y M4A.
- Tests nuevos: dos pistas de piano con notas independientes serializadas, migración schema 3 a 4.

## Prueba manual obligatoria tras compilar

1. PROYECTOS > NUEVO. En MI CANCIÓN pulsa + AÑADIR INSTRUMENTO, escucha PIANO SUAVE, AÑADIR; abrirá SMART KEYS horizontal. REC → toca → FIN REC.
2. GRABACIONES ▶ SOLO escucha tu toma; ■ STOP. MI CANCIÓN debe mostrar PIANO SUAVE; PLAY suena la toma.
3. + AÑADIR INSTRUMENTO → COWBELL → AÑADIR → REC → toca → FIN REC. MI CANCIÓN lista piano y cowbell por separado; PLAY suenan juntos; ▶ SOLO en cowbell apaga piano y fondo; TODAS restaura la mezcla.
4. + AÑADIR INSTRUMENTO → PIANO SUAVE: aparece un tercer slot sin reemplazar el primer piano. GUARDAR → cerrar/abrir → comprobar instrumentos, notas y nombre.
5. Importar MP3 personal compatible y reproducir con las pistas, comprobar exportaciones WAV/M4A y volumen independiente en MI CANCIÓN.
6. Cambiar un sonido de pista que tenga notas, sin borrar notas. Borrar pista con confirmación y deshacer; comprobar que otra pista no desaparece.
7. Crear base PHONK editable, añadir pista personalizada por encima y comprobar PLAY.

## Límites reales de esta versión

- **No son pistas ilimitadas:** 12 pistas melódicas + 4 canales de batería, hasta 512 compases. La vista de arreglo y el piano roll de v0.4.0 siguen siendo limitados.
- **No son 12 muestras realistas de grandes instrumentos:** son 12 timbres internos de síntesis más 24 WAV originales de batería/FX y una muestra importada compartida.
- Solo una pista de audio importado como acompañamiento por proyecto, hasta ~115 s de audio importado (decodificación actual). No hay multi-clip audio, chopping avanzado, detección de BPM, stems, MP3 de salida ni separación de instrumentos de un MP3.
- Motor Kotlin/AudioTrack existente: no se implementó C++/Oboe ni se promete latencia profesional en todos los equipos.
- No se ha ejecutado Android SDK/Gradle completo en el entorno de entrega; el primer build en GitHub Actions debe verificar compilación y pruebas. No afirmar sin evidencia «APK probado» ni «libre de errores».
