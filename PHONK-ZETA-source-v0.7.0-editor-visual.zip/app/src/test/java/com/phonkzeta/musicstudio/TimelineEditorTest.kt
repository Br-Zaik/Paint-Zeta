package com.phonkzeta.musicstudio

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import kotlin.math.sin

class TimelineEditorTest {
    @Test fun jsonRoundtripRestoresClipPositionsAndCycle() {
        val song = ZetaProject(name = "Prueba").apply {
            bars = 32
            cycleEnabled = true
            cycleStartBeat = 4.0
            cycleEndBeat = 33.5
            audioClips.add(ZetaAudioClip("clip1", "background_123.wav", 12.5, 1.2, 18.25,
                .4, true, "Mi MP3", listOf(.1f, .5f, .8f), muted = true))
        }
        val restored = ZetaProject.fromJson(song.toJson())
        assertEquals(5, restored.toJson().getInt("schema"))
        assertEquals(33.5, restored.cycleEndBeat, .0001)
        assertTrue(restored.cycleEnabled)
        assertEquals(1, restored.audioClips.size)
        assertEquals(12.5, restored.audioClips[0].startBeat, .0001)
        assertEquals("Mi MP3", restored.audioClips[0].label)
        assertTrue(restored.audioClips[0].muted)
        assertTrue(restored.audioClips[0].repeat)
        assertEquals(3, restored.audioClips[0].waveform.size)
    }

    @Test fun movingBarChangesNotesWithoutChangingPitchOrOtherTracks() {
        val song = ZetaProject().apply {
            notes.add(MusicNote(6, 60, 1.0, .5))
            notes.add(MusicNote(6, 63, 1.5, .5))
            notes.add(MusicNote(5, 36, 1.0, 1.0))
        }
        assertTrue(TimelineEdits.moveBar(song, 6, 0, 2))
        assertEquals(2, TimelineEdits.barNotes(song, 6, 2).size)
        assertEquals(60, TimelineEdits.barNotes(song, 6, 2)[0].pitch)
        assertEquals(9.0, TimelineEdits.barNotes(song, 6, 2)[0].start, .001)
        assertEquals(1.0, song.notes.single { it.track == 5 }.start, .001)
        assertTrue(TimelineEdits.moveBar(song, 6, 2, 3, duplicate = true))
        assertEquals(2, TimelineEdits.barNotes(song, 6, 2).size)
        assertEquals(2, TimelineEdits.barNotes(song, 6, 3).size)
        TimelineEdits.deleteBar(song, 6, 2)
        assertTrue(TimelineEdits.barNotes(song, 6, 2).isEmpty())
        assertEquals(2, TimelineEdits.barNotes(song, 6, 3).size)
    }

    @Test fun offlineWavIncludesTimelineAudioAtItsActualPosition() {
        val song = ZetaProject().apply {
            bars = 1
            steps.forEach { it.fill(false) }
            notes.clear()
            drive = 0.0
            audioClips.add(ZetaAudioClip("clip", "background_999.wav", 1.0, 0.0, 1.5))
        }
        val sound = SampleSound(FloatArray(48000) { n -> (sin(n * .03) * .7).toFloat() },
            48000, "background_999.wav")
        val engine = ZetaAudioEngine()
        engine.setAudioSource(sound)
        val wav = File.createTempFile("zeta_timeline_", ".wav")
        try {
            engine.exportWav(song, wav)
            val bytes = wav.readBytes()
            assertTrue(bytes.size > 44 + 48000)
            val before = 44 + (48000 / 10) * 4
            val after = 44 + (48000 / 2) * 4
            assertTrue((before until before + 512).all { bytes[it].toInt() == 0 })
            assertTrue((after until after + 512).any { bytes[it].toInt() != 0 })
        } finally { wav.delete() }
    }
}
