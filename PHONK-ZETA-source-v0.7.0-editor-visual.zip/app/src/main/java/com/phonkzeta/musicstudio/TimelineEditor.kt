package com.phonkzeta.musicstudio

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

/** Editor de bloques ligado al proyecto que realmente reproduce y exporta el motor PCM. */
fun timelineWaveform(sound: SampleSound, bins: Int = 64): List<Float> {
    if (sound.pcm.isEmpty()) return emptyList()
    return (0 until bins).map { bin ->
        val from = (bin.toLong() * sound.pcm.size / bins).toInt()
        val to = ((bin + 1L) * sound.pcm.size / bins).toInt().coerceAtMost(sound.pcm.size)
        var peak = 0f
        val hop = ((to - from) / 600).coerceAtLeast(1)
        for (i in from until to step hop) peak = max(peak, abs(sound.pcm[i]))
        peak.coerceIn(0f, 1f)
    }
}

object TimelineEdits {
    fun barNotes(p: ZetaProject, track: Int, bar: Int) =
        p.notes.filter { it.track == track && it.start >= bar * 4.0 && it.start < (bar + 1) * 4.0 }

    fun moveBar(p: ZetaProject, track: Int, from: Int, to: Int, duplicate: Boolean = false): Boolean {
        if (from !in 0 until p.bars || to !in 0 until p.bars || from == to || track !in 0 until TRACK_COUNT) return false
        val source = barNotes(p, track, from)
        if (track < 4 && !p.arrangement[track][from] && source.isEmpty()) return false
        if (track >= 4 && source.isEmpty()) return false
        if (!duplicate) p.notes.removeAll(source.toSet())
        val delta = (to - from) * 4.0
        p.notes.addAll(source.map { n -> n.copy(start = n.start + delta,
            length = min(n.length, p.bars * 4.0 - n.start - delta).coerceAtLeast(.01)) })
        p.arrangement[track][to] = p.arrangement[track][from] || source.isNotEmpty()
        if (!duplicate) p.arrangement[track][from] = false
        return true
    }

    fun deleteBar(p: ZetaProject, track: Int, bar: Int) {
        p.notes.removeAll(barNotes(p, track, bar).toSet())
        p.arrangement[track][bar] = false
    }

    fun trimNotes(p: ZetaProject, track: Int, bar: Int, beatsToRemove: Double) {
        val selected = barNotes(p, track, bar)
        selected.forEach { note ->
            val index = p.notes.indexOf(note)
            if (index >= 0) p.notes[index] = note.copy(length = (note.length - beatsToRemove).coerceAtLeast(.0625))
        }
    }
}

private val dark = Color(0xFF161820)
private val card = Color(0xFF282A36)
private val accent = Color(0xFFA78BFA)
private val yellow = Color(0xFFFFD169)
private val white = Color(0xFFF4F4F7)
private const val BAR_DP = 80

private fun timeLabel(seconds: Double): String {
    val n = seconds.coerceAtLeast(0.0).toInt()
    return "%02d:%02d".format(n / 60, n % 60)
}

@Composable
fun ZetaTimeline(
    project: ZetaProject,
    playSeconds: Double,
    onChange: ((ZetaProject) -> Unit) -> Unit,
    onSeek: (Double) -> Unit,
    onImport: () -> Unit,
    onAddInstrument: () -> Unit,
    onPiano: (Int, Int) -> Unit
) {
    var selectedTrack by remember(project) { mutableIntStateOf(-1) }
    var selectedBar by remember(project) { mutableIntStateOf(-1) }
    var selectedAudioId by remember(project) { mutableStateOf<String?>(null) }
    val secondsPerBeat = 60.0 / project.bpm
    val currentBar = (playSeconds / (secondsPerBeat * 4.0)).toInt().coerceIn(0, project.bars - 1)
    val tick = secondsPerBeat * 4.0
    fun selectedAudio() = project.audioClips.firstOrNull { it.id == selectedAudioId }
    val density = LocalDensity.current
    var barDp by remember { mutableIntStateOf(BAR_DP) }
    val barWidthPx = with(density) { barDp.dp.toPx() }
    var movePx by remember { mutableFloatStateOf(0f) }
    var windowStart by remember(project) { mutableIntStateOf(0) }
    var followPlay by remember { mutableStateOf(true) }
    val pageSize = 8
    LaunchedEffect(currentBar, followPlay) {
        if (followPlay) windowStart = (currentBar / pageSize) * pageSize
    }
    val windowEnd = min(project.bars, windowStart + pageSize)
    fun shift(barDelta: Int, duplicate: Boolean) {
        if (selectedTrack !in 0 until TRACK_COUNT || selectedBar !in 0 until project.bars) return
        val next = selectedBar + barDelta
        if (next !in 0 until project.bars || next == selectedBar) return
        onChange { p -> TimelineEdits.moveBar(p, selectedTrack, selectedBar, next, duplicate) }
        selectedBar = next
        if (next !in windowStart until windowEnd) {
            followPlay = false
            windowStart = (next / pageSize) * pageSize
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("MI EDITOR MUSICAL", color = yellow, fontSize = 21.sp, fontWeight = FontWeight.Black)
        Text("Como un editor de video: cada bloque suena cuando el cursor pasa por él. Tócalo para editarlo.",
            color = white, fontSize = 15.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("▶ ${timeLabel(playSeconds)} / ${timeLabel(project.bars * tick)}", color = yellow,
                fontWeight = FontWeight.Bold, fontSize = 18.sp)
            OutlinedButton(onClick = { onSeek(0.0) }) { Text("IR AL INICIO", color = white) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { followPlay = false; windowStart = (windowStart - pageSize).coerceAtLeast(0) }) {
                Text("◀ ANTERIOR", color = white)
            }
            Text("  ${windowStart + 1}–$windowEnd  ", color = yellow, fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = { followPlay = false;
                windowStart = (windowStart + pageSize).coerceAtMost(((project.bars - 1) / pageSize) * pageSize)
            }) { Text("SIGUIENTE ▶", color = white) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { followPlay = !followPlay }) {
                Text(if (followPlay) "● SEGUIR" else "○ SEGUIR",
                    color = if (followPlay) yellow else white)
            }
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { barDp = (barDp - 16).coerceAtLeast(48) }) {
                Text("− ZOOM", color = white)
            }
            OutlinedButton(onClick = { barDp = (barDp + 16).coerceAtMost(160) }) {
                Text("+ ZOOM", color = white)
            }
        }
        Text("Toca la regla para ir al segundo. Mantén y mueve un bloque para desplazarlo.",
            color = white.copy(alpha = .9f), fontSize = 13.sp)
        Column(Modifier.fillMaxWidth().height(332.dp).background(dark, RoundedCornerShape(12.dp))
            .verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState())
            .padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row {
                Box(Modifier.width(112.dp).height(43.dp), contentAlignment = Alignment.CenterStart) {
                    Text("TIEMPO →", color = yellow, fontWeight = FontWeight.Bold)
                }
                for (bar in windowStart until windowEnd) {
                    val inCycle = project.cycleEnabled && bar * 4.0 >= project.cycleStartBeat &&
                        bar * 4.0 < project.cycleEndBeat
                    Column(Modifier.width(barDp.dp).height(43.dp)
                        .background(if (bar == currentBar) yellow.copy(alpha = .37f) else if (inCycle)
                            accent.copy(alpha = .2f) else card, RoundedCornerShape(4.dp))
                        .border(1.dp, if (bar == currentBar) yellow else dark, RoundedCornerShape(4.dp))
                        .clickable { onSeek(bar * tick) }.padding(start = 4.dp),
                        verticalArrangement = Arrangement.Center) {
                        Text(timeLabel(bar * tick), color = white, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("parte ${bar + 1}", color = yellow, fontSize = 10.sp)
                    }
                }
            }
            project.audioClips.filter { it.startBeat < windowEnd * 4.0 &&
                it.startBeat + it.lengthBeats > windowStart * 4.0 }.forEach { clip ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎧 AUDIO", color = white, fontSize = 13.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.width(112.dp), maxLines = 1)
                    Box(Modifier.width(((windowEnd - windowStart) * barDp).dp)
                        .height(59.dp).background(card)) {
                        val showStart = max(clip.startBeat, windowStart * 4.0)
                        val showEnd = min(clip.startBeat + clip.lengthBeats, windowEnd * 4.0)
                        val start = ((showStart - windowStart * 4.0) / 4.0 * barDp).dp
                        val length = ((showEnd - showStart) / 4.0 * barDp).dp
                        val selected = clip.id == selectedAudioId
                        Box(Modifier.offset(x = start).width(if (length < 20.dp) 20.dp else length).fillMaxHeight()
                            .background(if (selected) yellow else Color(0xFF248F80), RoundedCornerShape(7.dp))
                            .border(2.dp, if (selected) white else Color(0xFF72E2D2), RoundedCornerShape(7.dp))
                            .pointerInput(clip.id) {
                                detectDragGestures(onDragStart = { movePx = 0f }, onDragEnd = {
                                    val deltaBeat = ((movePx / barWidthPx) * 4.0 * 4.0).roundToInt() / 4.0
                                    if (deltaBeat != 0.0) onChange { p ->
                                        p.audioClips.firstOrNull { it.id == clip.id }?.let {
                                            it.startBeat = (it.startBeat + deltaBeat)
                                                .coerceIn(0.0, p.bars * 4.0 - it.lengthBeats)
                                        }
                                    }
                                    movePx = 0f
                                }, onDrag = { change, amount ->
                                    change.consume(); movePx += amount.x
                                })
                            }.clickable { selectedAudioId = clip.id; selectedTrack = -1 }
                            .padding(horizontal = 6.dp), contentAlignment = Alignment.CenterStart) {
                            if (clip.waveform.isNotEmpty()) Canvas(Modifier.fillMaxSize()) {
                                val h = size.height
                                val step = size.width / clip.waveform.size
                                clip.waveform.forEachIndexed { i, amp ->
                                    val x = i * step
                                    val waveHeight = (amp * h * .72f).coerceAtLeast(2f)
                                    drawLine(if (selected) dark.copy(alpha = .48f) else white.copy(alpha = .68f),
                                        Offset(x, h / 2 - waveHeight / 2),
                                        Offset(x, h / 2 + waveHeight / 2), 2f)
                                }
                            }
                            Text("♪ ${clip.label.take(24)}", color = if (selected) dark else white,
                                fontWeight = FontWeight.Black, fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            for (track in 0 until TRACK_COUNT) {
                if (track >= 4 && !project.laneAdded[track] && project.notes.none { it.track == track }) continue
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(project.laneNames[track], color = if (track < 4) yellow else white,
                        fontSize = 12.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.width(112.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    for (bar in windowStart until windowEnd) {
                        val notes = TimelineEdits.barNotes(project, track, bar)
                        val active = notes.isNotEmpty() || (track < 4 && project.arrangement[track][bar] &&
                            project.steps[track].any { it })
                        val selected = selectedTrack == track && selectedBar == bar && selectedAudioId == null
                        Box(Modifier.width(barDp.dp).height(53.dp)
                            .padding(horizontal = 2.dp, vertical = 3.dp)
                            .background(if (selected) yellow else if (active) accent else card,
                                RoundedCornerShape(7.dp))
                            .border(1.dp, if (bar == currentBar) yellow else dark, RoundedCornerShape(7.dp))
                            .pointerInput(track, bar, active) {
                                if (active) detectDragGestures(onDragStart = { movePx = 0f }, onDragEnd = {
                                    val delta = (movePx / barWidthPx).roundToInt()
                                    if (delta != 0 && bar + delta in 0 until project.bars) {
                                        onChange { p -> TimelineEdits.moveBar(p, track, bar, bar + delta) }
                                        selectedTrack = track; selectedBar = bar + delta; selectedAudioId = null
                                    }
                                    movePx = 0f
                                }, onDrag = { change, amount -> change.consume(); movePx += amount.x })
                            }.clickable {
                                selectedTrack = track; selectedBar = bar; selectedAudioId = null
                            }, contentAlignment = Alignment.Center) {
                            Text(if (active) if (track < 4) "♪ RITMO" else "♫ ${notes.size}"
                                else "+", color = if (selected || active) dark else white,
                                fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        val selectedClip = selectedAudio()
        if (selectedClip != null) {
            Text("EDITAR AUDIO: ${selectedClip.label} · ${timeLabel(selectedClip.startBeat * secondsPerBeat)}",
                color = yellow,
                fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.let {
                        it.startBeat = (it.startBeat - 1.0).coerceAtLeast(0.0)
                    }
                } }) { Text("← MOVER", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.let {
                        it.startBeat = (it.startBeat + 1.0).coerceAtMost(p.bars * 4.0 - it.lengthBeats)
                    }
                } }) { Text("MOVER →", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.let {
                        it.trimSeconds = (it.trimSeconds + .25).coerceAtMost(239.0)
                    }
                } }) { Text("RECORTAR INICIO +0.25 s", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.let {
                        it.lengthBeats = (it.lengthBeats - 1.0).coerceAtLeast(.25)
                    }
                } }) { Text("ACORTAR FINAL", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.let {
                        it.lengthBeats = (it.lengthBeats + 1.0).coerceAtMost(p.bars * 4.0 - it.startBeat)
                    }
                } }) { Text("ALARGAR", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    if (p.audioClips.size < 8) p.audioClips.firstOrNull { it.id == selectedClip.id }?.let {
                        val at = it.startBeat + it.lengthBeats
                        if (at + .25 <= p.bars * 4.0) p.audioClips.add(it.copy(id = System.nanoTime().toString(),
                            startBeat = at, lengthBeats = min(it.lengthBeats, p.bars * 4.0 - at)))
                    }
                } }) { Text("DUPLICAR", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    val original = p.audioClips.firstOrNull { it.id == selectedClip.id }
                    if (original != null && !original.repeat && p.audioClips.size < 8 && original.lengthBeats > .5) {
                        val split = (playSeconds / secondsPerBeat).coerceIn(
                            original.startBeat + .25, original.startBeat + original.lengthBeats - .25)
                        if (split > original.startBeat && split < original.startBeat + original.lengthBeats) {
                            val firstLen = split - original.startBeat
                            val secondLen = original.lengthBeats - firstLen
                            p.audioClips.add(original.copy(id = System.nanoTime().toString(),
                                startBeat = split, trimSeconds = original.trimSeconds + firstLen * secondsPerBeat,
                                lengthBeats = secondLen))
                            original.lengthBeats = firstLen
                        }
                    }
                } }) { Text("CORTAR EN EL CURSOR", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.muted = !selectedClip.muted
                } }) { Text(if (selectedClip.muted) "ESCUCHAR" else "SILENCIAR", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    val was = selectedClip.solo
                    p.audioClips.forEach { it.solo = false }
                    p.solo.fill(false)
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.solo = !was
                } }) { Text(if (selectedClip.solo) "TODO JUNTO" else "▶ SOLO AUDIO", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.repeat = !selectedClip.repeat
                } }) { Text(if (selectedClip.repeat) "DEJAR DE REPETIR" else "REPETIR AUDIO", color = white) }
                OutlinedButton(onClick = { onChange { p ->
                    p.audioClips.removeAll { it.id == selectedClip.id }
                    if (p.audioClips.isEmpty()) p.backgroundName = ""
                }; selectedAudioId = null }) { Text("BORRAR AUDIO", color = Color(0xFFFF95A6)) }
            }
            var gainDraft by remember(selectedClip.id) { mutableFloatStateOf(selectedClip.gain.toFloat()) }
            LaunchedEffect(selectedClip.gain) { gainDraft = selectedClip.gain.toFloat() }
            Text("Volumen del audio: ${(gainDraft * 100).toInt()}%", color = white)
            Slider(value = gainDraft, onValueChange = { v -> gainDraft = v },
                onValueChangeFinished = { onChange { p ->
                    p.audioClips.firstOrNull { it.id == selectedClip.id }?.gain = gainDraft.toDouble()
                } })
        } else if (selectedTrack in 0 until TRACK_COUNT && selectedBar in 0 until project.bars) {
            Text("EDITAR: ${project.laneNames[selectedTrack]} · segundo ${timeLabel(selectedBar * tick)}",
                color = yellow, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedButton(onClick = { shift(-1, false) }) { Text("← MOVER", color = white) }
                OutlinedButton(onClick = { shift(1, false) }) { Text("MOVER →", color = white) }
                OutlinedButton(onClick = { shift(1, true) }) { Text("DUPLICAR", color = white) }
                OutlinedButton(onClick = { onChange { TimelineEdits.trimNotes(it, selectedTrack, selectedBar, .25) } }) {
                    Text("ACORTAR NOTAS", color = white)
                }
                OutlinedButton(onClick = { onPiano(selectedTrack, selectedBar) }) { Text("EDITAR NOTAS", color = white) }
                OutlinedButton(onClick = { onChange { TimelineEdits.deleteBar(it, selectedTrack, selectedBar) } }) {
                    Text("BORRAR BLOQUE", color = Color(0xFFFF95A6))
                }
            }
        }
        Text("CICLO · repite la zona marcada SOLO mientras escuchas (no corta tu exportación)",
            color = white, fontSize = 13.sp)
        var cycleStartDraft by remember(project) { mutableFloatStateOf(project.cycleStartBeat.toFloat()) }
        var cycleEndDraft by remember(project) { mutableFloatStateOf(project.cycleEndBeat.toFloat()) }
        LaunchedEffect(project.cycleStartBeat, project.cycleEndBeat) {
            cycleStartDraft = project.cycleStartBeat.toFloat()
            cycleEndDraft = project.cycleEndBeat.toFloat()
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = project.cycleEnabled, onCheckedChange = { yes ->
                onChange { it.cycleEnabled = yes }
            })
            Text(if (project.cycleEnabled) "REPETIR ACTIVADO" else "ACTIVAR REPETICIÓN", color = white)
            Spacer(Modifier.weight(1f))
            Text("${timeLabel(project.cycleStartBeat * secondsPerBeat)}–${timeLabel(project.cycleEndBeat * secondsPerBeat)}",
                color = yellow, fontWeight = FontWeight.Bold)
        }
        Text("Comienzo del ciclo", color = white, fontSize = 13.sp)
        Slider(value = cycleStartDraft.coerceAtMost(cycleEndDraft - .25f),
            valueRange = 0f..(project.bars * 4.0 - .25).toFloat(),
            onValueChange = { v -> cycleStartDraft = v.coerceAtMost(cycleEndDraft - .25f) },
            onValueChangeFinished = { onChange { p ->
                p.cycleStartBeat = cycleStartDraft.toDouble().coerceAtMost(p.cycleEndBeat - .25)
            } })
        var desiredCycleSeconds by remember(project) { mutableStateOf("50") }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(desiredCycleSeconds, onValueChange = { value ->
                desiredCycleSeconds = value.filter(Char::isDigit).take(5)
            }, label = { Text("Segundos") }, singleLine = true,
                modifier = Modifier.width(140.dp))
            Button(onClick = {
                val duration = desiredCycleSeconds.toIntOrNull()
                if (duration != null && duration > 0) onChange { p ->
                    p.cycleStartBeat = 0.0
                    val beats = duration.toDouble() * p.bpm / 60.0
                    p.bars = max(p.bars, ceil(beats / 4.0).toInt()).coerceAtMost(BAR_LIMIT)
                    p.cycleEndBeat = beats.coerceIn(.25, p.bars * 4.0)
                    p.cycleEnabled = true
                }
            }) { Text("CREAR CICLO") }
        }
        Text("Final del ciclo", color = white, fontSize = 13.sp)
        Slider(value = cycleEndDraft.coerceAtLeast(cycleStartDraft + .25f),
            valueRange = .25f..(project.bars * 4.0).toFloat(),
            onValueChange = { v -> cycleEndDraft = v.coerceAtLeast(cycleStartDraft + .25f) },
            onValueChangeFinished = { onChange { p ->
                p.cycleEndBeat = cycleEndDraft.toDouble().coerceAtLeast(p.cycleStartBeat + .25)
            } })
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onChange { p ->
                p.bars = (p.bars + 8).coerceAtMost(BAR_LIMIT)
            } }) { Text("+ 8 PARTES", color = white) }
            OutlinedButton(onClick = { onChange { p ->
                p.bars = (p.bars + 32).coerceAtMost(BAR_LIMIT)
            } }) { Text("+ 32 PARTES", color = white) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAddInstrument, modifier = Modifier.weight(1f)) { Text("+ INSTRUMENTO") }
            OutlinedButton(onClick = onImport, modifier = Modifier.weight(1f)) {
                Text("+ AUDIO", color = white)
            }
        }
    }
}
