package com.phonkzeta.musicstudio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.min

/** Decode user-selected MP3/M4A/FLAC/OGG/WAV through the installed Android codec. */
object AudioImport {
    fun decode(context: Context, uri: Uri, maximumSeconds: Int = 115): SampleSound {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use {
                extractor.setDataSource(it.fileDescriptor)
            } ?: error("No se puede abrir el audio")
            val track = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("Archivo sin pista de audio")
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: error("Formato desconocido")
            extractor.selectTrack(track)
            val rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            require(rate in 8000..192000) { "Frecuencia de audio no compatible" }
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            require(channels in 1..2) { "Solo audio mono/estéreo" }
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
            val result = java.io.ByteArrayOutputStream()
            var inputEnded = false
            var outputEnded = false
            var outRate = rate
            var outChannels = channels
            var floatPcm = false
            val info = MediaCodec.BufferInfo()
            val maxBytes = maximumSeconds.toLong() * rate * channels * 4L
            var guard = 0
            while (!outputEnded && guard++ < 200000) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex) ?: error("Error leyendo codec")
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEnded = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val index = codec.dequeueOutputBuffer(info, 10000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val decoded = codec.outputFormat
                        outRate = decoded.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        outChannels = decoded.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        floatPcm = decoded.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            decoded.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        require(outChannels in 1..2 && outRate in 8000..192000)
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (index >= 0) {
                        val buffer = codec.getOutputBuffer(index)
                        if (buffer != null && info.size > 0) {
                            require(result.size().toLong() + info.size <= maxBytes) {
                                "Audio demasiado largo: máximo $maximumSeconds segundos"
                            }
                            val chunk = ByteArray(info.size)
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            buffer.get(chunk)
                            result.write(chunk)
                        }
                        outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(index, false)
                    }
                }
            }
            require(outputEnded) { "No se pudo finalizar la decodificación" }
            val bytes = result.toByteArray()
            val size = if (floatPcm) 4 else 2
            val frames = bytes.size / (outChannels * size)
            require(frames > 0) { "Audio vacío" }
            val pcm = FloatArray(frames)
            val buffer = java.nio.ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until frames) {
                var value = 0f
                repeat(outChannels) { value += if (floatPcm) buffer.float else buffer.short / 32768f }
                pcm[i] = (value / outChannels).coerceIn(-1f, 1f)
            }
            return SampleSound(pcm, outRate)
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            extractor.release()
        }
    }
}

object WaveWriter {
    fun writeMono16(sound: SampleSound, destination: File) {
        FileOutputStream(destination).use { output ->
            fun le(value: Long, count: Int) {
                for (i in 0 until count) output.write(((value ushr (8 * i)) and 255).toInt())
            }
            val dataSize = sound.pcm.size.toLong() * 2
            output.write("RIFF".toByteArray(Charsets.US_ASCII)); le(dataSize + 36, 4)
            output.write("WAVEfmt ".toByteArray(Charsets.US_ASCII))
            le(16, 4); le(1, 2); le(1, 2)
            le(sound.sampleRate.toLong(), 4); le(sound.sampleRate * 2L, 4)
            le(2, 2); le(16, 2)
            output.write("data".toByteArray(Charsets.US_ASCII)); le(dataSize, 4)
            val buffer = ByteArray(8192)
            var index = 0
            while (index < sound.pcm.size) {
                val n = min(buffer.size / 2, sound.pcm.size - index)
                for (i in 0 until n) {
                    val sample = (sound.pcm[index + i].coerceIn(-1f, 1f) * 32767f).toInt()
                    buffer[2 * i] = sample.toByte()
                    buffer[2 * i + 1] = (sample shr 8).toByte()
                }
                output.write(buffer, 0, n * 2)
                index += n
            }
        }
    }
}
