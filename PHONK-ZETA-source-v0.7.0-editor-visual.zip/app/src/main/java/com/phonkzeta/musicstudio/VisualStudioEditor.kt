package com.phonkzeta.musicstudio

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

/**
 * Visual editor with a fixed white playhead. All positions are musical beats in ZetaProject;
 * seconds shown on the ruler are calculated from BPM. Edit callbacks mutate the same model
 * used by live playback and offline WAV/M4A export; no decorative/mock clips.
 */
private val VS_BG = Color(0xFF101115)
private val VS_CARD = Color(0xFF232630)
private val VS_TEXT = Color(0xFFF5F5F7)
private val VS_PURPLE = Color(0xFFB39AFF)
private val VS_YELLOW = Color(0xFFFFCF63)
private val VS_AUDIO = Color(0xFF19B6C6)
private val VS_RED = Color(0xFFFF6E83)
private val VS_GRID = Color(0xFF444753)
private const val LABEL_WIDTH = 83
private const val ROW_HEIGHT = 54

private fun vsClock(second: Double): String {
    val safe = second.coerceAtLeast(0.0).toInt()
    return "%02d:%02d".format(safe / 60, safe % 60)
}

private data class VsHit(val track: Int = -1, val bar: Int = -1, val audio: String? = null,
    val resize: Int = 0) // -1 left edge, +1 right edge

@Composable
fun VisualStudioEditor(
    project: ZetaProject,
    playSeconds: Double,
    onChange: ((ZetaProject) -> Unit) -> Unit,
    onSeek: (Double) -> Unit,
    onImport: () -> Unit,
    onAddInstrument: () -> Unit,
    onEditNotes: (Int, Int) -> Unit,
    onOpenPiano: (Int) -> Unit,
    onPreviewNote: (Int, Int) -> Unit
) {
    var selected by remember(project) { mutableStateOf(VsHit()) }
    var zoom by remember { mutableFloatStateOf(22f) } // logical pixels per second, adjusted for density below
    var dragPixels by remember { mutableFloatStateOf(0f) }
    val spb = 60.0 / project.bpm
    val barSec = 4 * spb
    val duration = project.bars * barSec
    val density = LocalDensity.current
    val pxSec = with(density) { zoom.dp.toPx() }
    var viewportCenter by remember { mutableFloatStateOf(220f) }
    var previewTrack by remember(project) { mutableIntStateOf(6) }
    val tracks = (0 until TRACK_COUNT).filter { track ->
        track < 4 || project.laneAdded[track] || project.notes.any { it.track == track }
    }
    val selectedAudio = project.audioClips.firstOrNull { it.id == selected.audio }

    fun setSelection(hit: VsHit) {
        selected = hit
        if (hit.track >= 0) previewTrack = hit.track
    }
    fun getHit(row: Int, x: Float): VsHit {
        val seconds = playSeconds + (x - viewportCenter) / pxSec
        if (row == -1) return VsHit()
        if (row == -2) {
            for (clip in project.audioClips.asReversed()) {
                val left = clip.startBeat * spb
                val right = (clip.startBeat + clip.lengthBeats) * spb
                if (seconds >= left && seconds < right) {
                    val edge = with(density) { 17.dp.toPx() } / pxSec
                    return VsHit(audio = clip.id, resize = when {
                        seconds - left <= edge -> -1
                        right - seconds <= edge -> 1
                        else -> 0
                    })
                }
            }
            return VsHit()
        }
        if (row !in 0 until TRACK_COUNT) return VsHit()
        val bar = (seconds / barSec).toInt()
        return if (bar in 0 until project.bars) VsHit(track = row, bar = bar) else VsHit()
    }
    fun applyDrag(hit: VsHit, deltaPx: Float) {
        val beatDelta = (deltaPx / pxSec / spb * 4.0).roundToInt() / 4.0
        if (hit.audio != null) {
            if (beatDelta == 0.0) return
            onChange { p -> p.audioClips.firstOrNull { it.id == hit.audio }?.let { c ->
                val beforeEnd = c.startBeat + c.lengthBeats
                when (hit.resize) {
                    -1 -> {
                        val next = (c.startBeat + beatDelta).coerceIn(
                            max(0.0, c.startBeat - c.trimSeconds / spb), beforeEnd - .25)
                        val difference = next - c.startBeat
                        c.startBeat = next
                        c.lengthBeats = beforeEnd - next
                        c.trimSeconds = (c.trimSeconds + difference * spb).coerceAtLeast(0.0)
                    }
                    1 -> c.lengthBeats = (c.lengthBeats + beatDelta)
                        .coerceIn(.25, p.bars * 4.0 - c.startBeat)
                    else -> c.startBeat = (c.startBeat + beatDelta)
                        .coerceIn(0.0, p.bars * 4.0 - c.lengthBeats)
                }
            } }
        } else if (hit.track >= 0 && hit.bar >= 0) {
            val move = (deltaPx / pxSec / barSec).roundToInt()
            val to = hit.bar + move
            if (move != 0 && to in 0 until project.bars) {
                onChange { p -> TimelineEdits.moveBar(p, hit.track, hit.bar, to) }
                setSelection(VsHit(track = hit.track, bar = to))
            }
        }
    }

    Column(Modifier.fillMaxSize().background(VS_BG)) {
        // Compact preview, not a page of explanations or controls.
        Box(Modifier.fillMaxWidth().height(120.dp).background(Color(0xFF181B23), RoundedCornerShape(9.dp))) {
            val audio = selectedAudio
            if (audio != null) {
                Column(Modifier.fillMaxSize().padding(10.dp)) {
                    Text("♫ ${audio.label}", color = VS_AUDIO, fontWeight = FontWeight.Bold, maxLines = 1)
                    Canvas(Modifier.fillMaxWidth().weight(1f)) {
                        val samples = audio.waveform
                        if (samples.isNotEmpty()) samples.forEachIndexed { idx, amplitude ->
                            val x = idx * size.width / samples.size
                            val half = (size.height * .47f * amplitude).coerceAtLeast(1f)
                            drawLine(VS_AUDIO, Offset(x, size.height / 2 - half),
                                Offset(x, size.height / 2 + half), 2f)
                        }
                    }
                }
            } else {
                val track = previewTrack.coerceIn(0, TRACK_COUNT - 1)
                val bar = selected.bar.takeIf { selected.track == track && it >= 0 }
                    ?: (playSeconds / barSec).toInt().coerceIn(0, project.bars - 1)
                val notes = TimelineEdits.barNotes(project, track, bar)
                Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(project.laneNames[track].take(20), color = VS_TEXT,
                            fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                        Text("${notes.size} notas", color = VS_YELLOW, fontSize = 12.sp)
                        TextButton(onClick = { onOpenPiano(if (track < 4) 6 else track) },
                            contentPadding = PaddingValues(horizontal = 9.dp)) {
                            Text("🎹 TOCAR", color = VS_PURPLE, fontSize = 13.sp)
                        }
                    }
                    Canvas(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF11131A))) {
                        for (n in 0..16) drawLine(VS_GRID.copy(alpha = .55f),
                            Offset(size.width * n / 16f, 0f), Offset(size.width * n / 16f, size.height), 1f)
                        for (n in 0..8) drawLine(VS_GRID.copy(alpha = .5f),
                            Offset(0f, size.height * n / 8f), Offset(size.width, size.height * n / 8f), 1f)
                        val bottomPitch = ((notes.minOfOrNull { it.pitch } ?: 60) - 1).coerceIn(0, 117)
                        notes.forEach { note ->
                            val x = ((note.start - bar * 4.0) / 4.0 * size.width).toFloat()
                            val w = (note.length / 4.0 * size.width).toFloat()
                            val y = (bottomPitch + 8 - note.pitch) / 8f * size.height
                            if (y >= -12f && y < size.height) drawRect(VS_PURPLE,
                                Offset(x.coerceAtLeast(0f), y),
                                Size(w.coerceIn(2f, size.width - x.coerceAtLeast(0f)), (size.height / 8 - 1f)))
                        }
                    }
                    if (track >= 4) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        val pitches = listOf(60, 62, 64, 65, 67, 69, 71)
                        val names = listOf("DO", "RE", "MI", "FA", "SOL", "LA", "SI")
                        pitches.forEachIndexed { i, pitch ->
                            Box(Modifier.weight(1f).padding(horizontal = 2.dp).height(30.dp)
                                .background(Color(0xFFE8E8ED), RoundedCornerShape(3.dp))
                                .clickable { onPreviewNote(track, pitch) }, contentAlignment = Alignment.Center) {
                                Text(names[i], fontSize = 10.sp, color = Color(0xFF16151D),
                                    fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(49.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${vsClock(playSeconds)} / ${vsClock(duration)}", color = VS_TEXT, fontSize = 15.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { onSeek(0.0) }) { Text("|◀", color = VS_TEXT) }
            TextButton(onClick = { zoom = (zoom / 1.35f).coerceAtLeast(9f) }) {
                Text("−", color = VS_TEXT, fontSize = 24.sp)
            }
            Text("${(zoom / 22f * 100).toInt()}%", color = VS_YELLOW, fontSize = 11.sp)
            TextButton(onClick = { zoom = (zoom * 1.35f).coerceAtMost(105f) }) {
                Text("+", color = VS_TEXT, fontSize = 24.sp)
            }
        }
        // Editor itself occupies the majority of screen: track labels + waveform/MIDI clips.
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).background(VS_BG)) {
            val laneWidth = maxWidth - LABEL_WIDTH.dp
            val viewportPx = with(density) { laneWidth.toPx() }
            viewportCenter = viewportPx / 2f
            val timelineScroll = rememberScrollState()
            Column(Modifier.fillMaxSize().verticalScroll(timelineScroll)) {
                Row(Modifier.fillMaxWidth().height(38.dp)) {
                    Box(Modifier.width(LABEL_WIDTH.dp).fillMaxHeight()
                        .background(Color(0xFF23242C)), contentAlignment = Alignment.Center) {
                        Text("PISTAS", color = VS_TEXT, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Canvas(Modifier.width(laneWidth).fillMaxHeight()
                        .background(Color(0xFF252630))
                        .pointerInput(project, zoom, playSeconds) {
                            detectTapGestures { pos ->
                                val at = (playSeconds + (pos.x - size.width / 2f) / pxSec)
                                    .coerceIn(0.0, duration)
                                onSeek(at)
                            }
                        }.pointerInput(project, zoom, playSeconds) {
                            var delta = 0f
                            detectDragGestures(onDragStart = { delta = 0f }, onDragEnd = {
                                if (delta != 0f) onSeek((playSeconds - delta / pxSec).coerceIn(0.0, duration))
                            }, onDrag = { change, amount -> change.consume(); delta += amount.x })
                        }) {
                        val center = size.width / 2f
                        val step = if (zoom < 16f) 10 else if (zoom < 45f) 5 else 2
                        val start = max(0, (playSeconds - center / pxSec).toInt() - 2)
                        val end = min(duration.toInt() + 1, (playSeconds + center / pxSec).toInt() + 2)
                        if (project.cycleEnabled) {
                            val a = center + ((project.cycleStartBeat * spb - playSeconds) * pxSec).toFloat()
                            val b = center + ((project.cycleEndBeat * spb - playSeconds) * pxSec).toFloat()
                            drawRect(VS_PURPLE.copy(alpha = .26f), Offset(a, 0f),
                                Size((b - a).coerceAtLeast(0f), size.height))
                        }
                        for (s in start..end) if (s % step == 0) {
                            val x = center + ((s - playSeconds) * pxSec).toFloat()
                            drawLine(VS_GRID, Offset(x, size.height * .66f), Offset(x, size.height), 1f)
                            drawContext.canvas.nativeCanvas.drawText(vsClock(s.toDouble()), x + 3f,
                                size.height * .52f, android.graphics.Paint().apply {
                                    isAntiAlias = true; color = android.graphics.Color.WHITE
                                    textSize = 11f * density.density
                                })
                        }
                    }
                }
                val rows = listOf(-2) + tracks
                rows.forEach { row ->
                    val audioRow = row == -2
                    Row(Modifier.fillMaxWidth().height(ROW_HEIGHT.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        val label = if (audioRow) "AUDIO" else project.laneNames[row].take(10)
                        val rowColor = if (audioRow) VS_AUDIO else if (row < 4) VS_YELLOW else VS_PURPLE
                        Box(Modifier.width(LABEL_WIDTH.dp).fillMaxHeight()
                            .background(Color(0xFF1B1D25))
                            .clickable {
                                if (!audioRow) { previewTrack = row; setSelection(VsHit(track = row,
                                    bar = (playSeconds / barSec).toInt().coerceIn(0, project.bars - 1))) }
                                else onImport()
                            }.padding(horizontal = 6.dp), contentAlignment = Alignment.CenterStart) {
                            Text(label, color = rowColor, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        var dragHit by remember(row, project) { mutableStateOf(VsHit()) }
                        Canvas(Modifier.width(laneWidth).fillMaxHeight()
                            .background(if (row % 2 == 0) Color(0xFF20212A) else Color(0xFF252630))
                            .pointerInput(row, project, zoom, playSeconds) {
                                detectTapGestures { at ->
                                    val hit = getHit(row, at.x)
                                    setSelection(hit)
                                    if (hit.track >= 0 && hit.bar >= 0) {
                                        onSeek(hit.bar * barSec)
                                    } else if (hit.audio == null) {
                                        val s = (playSeconds + (at.x - size.width / 2f) / pxSec)
                                            .coerceIn(0.0, duration)
                                        onSeek(s)
                                    }
                                }
                            }.pointerInput(row, project, zoom, playSeconds) {
                                detectDragGestures(onDragStart = { pos ->
                                    dragHit = getHit(row, pos.x)
                                    dragPixels = 0f
                                    if (dragHit.audio != null || dragHit.track >= 0) setSelection(dragHit)
                                }, onDragEnd = {
                                    if (dragHit.audio != null ||
                                        (dragHit.track >= 0 && dragHit.bar >= 0 &&
                                            (TimelineEdits.barNotes(project, dragHit.track, dragHit.bar).isNotEmpty() ||
                                                (dragHit.track < 4 && project.arrangement[dragHit.track][dragHit.bar])))) {
                                        applyDrag(dragHit, dragPixels)
                                    } else if (dragPixels != 0f) {
                                        onSeek((playSeconds - dragPixels / pxSec).coerceIn(0.0, duration))
                                    }
                                    dragPixels = 0f
                                }, onDrag = { c, d -> c.consume(); dragPixels += d.x })
                            }) {
                            val center = size.width / 2f
                            val firstBar = max(0, ((playSeconds - center / pxSec) / barSec).toInt() - 1)
                            val lastBar = min(project.bars - 1,
                                ((playSeconds + center / pxSec) / barSec).toInt() + 1)
                            for (bar in firstBar..lastBar) {
                                val left = center + ((bar * barSec - playSeconds) * pxSec).toFloat()
                                drawLine(VS_GRID, Offset(left, 0f), Offset(left, size.height), 1f)
                            }
                            if (project.cycleEnabled) {
                                val a = center + ((project.cycleStartBeat * spb - playSeconds) * pxSec).toFloat()
                                val b = center + ((project.cycleEndBeat * spb - playSeconds) * pxSec).toFloat()
                                drawRect(VS_PURPLE.copy(alpha = .11f), Offset(a, 0f),
                                    Size((b - a).coerceAtLeast(0f), size.height))
                            }
                            if (audioRow) {
                                project.audioClips.forEach { c ->
                                    val x = center + ((c.startBeat * spb - playSeconds) * pxSec).toFloat()
                                    val width = (c.lengthBeats * spb * pxSec).toFloat()
                                    if (x + width >= 0f && x <= size.width) {
                                        val isSelected = selected.audio == c.id
                                        val color = if (c.muted) VS_GRID else VS_AUDIO
                                        drawRoundRect(color.copy(alpha = .72f), Offset(x + 1f, 6f),
                                            Size(width.coerceAtLeast(3f) - 2f, size.height - 12f),
                                            androidx.compose.ui.geometry.CornerRadius(6f, 6f))
                                        if (c.waveform.isNotEmpty()) c.waveform.forEachIndexed { i, amp ->
                                            val waveX = x + width * i / c.waveform.size
                                            val half = (size.height * amp * .34f).coerceAtLeast(1f)
                                            drawLine(VS_TEXT.copy(alpha = .87f), Offset(waveX, size.height / 2 - half),
                                                Offset(waveX, size.height / 2 + half), 1f)
                                        }
                                        if (isSelected) {
                                            drawLine(VS_YELLOW, Offset(x + 2f, 6f), Offset(x + 2f, size.height - 6f), 5f)
                                            drawLine(VS_YELLOW, Offset(x + width - 2f, 6f),
                                                Offset(x + width - 2f, size.height - 6f), 5f)
                                        }
                                        drawContext.canvas.nativeCanvas.drawText(c.label.take(13), x + 8f,
                                            size.height * .44f, android.graphics.Paint().apply {
                                                color = android.graphics.Color.WHITE; isAntiAlias = true
                                                textSize = 11f * density.density
                                            })
                                    }
                                }
                            } else {
                                for (bar in firstBar..lastBar) {
                                    val ns = TimelineEdits.barNotes(project, row, bar)
                                    val active = ns.isNotEmpty() ||
                                        (row < 4 && project.arrangement[row][bar] && project.steps[row].any { it })
                                    if (!active) continue
                                    val x = center + ((bar * barSec - playSeconds) * pxSec).toFloat()
                                    val width = (barSec * pxSec).toFloat()
                                    val isSelected = selected.track == row && selected.bar == bar
                                    val color = if (row < 4) VS_YELLOW else VS_PURPLE
                                    drawRoundRect(color.copy(alpha = if (project.muted[row]) .25f else .86f),
                                        Offset(x + 2f, 5f), Size((width - 4f).coerceAtLeast(2f), size.height - 10f),
                                        androidx.compose.ui.geometry.CornerRadius(5f, 5f))
                                    if (isSelected) drawRect(VS_TEXT.copy(alpha = .95f), Offset(x + 2f, 4f),
                                        Size((width - 4f).coerceAtLeast(2f), 2f))
                                    if (ns.isNotEmpty()) {
                                        val low = ns.minOf { it.pitch }
                                        val range = (ns.maxOf { it.pitch } - low + 1).coerceAtLeast(3)
                                        ns.take(60).forEach { n ->
                                            val nx = x + (n.start - bar * 4.0).toFloat() / 4f * width
                                            val nw = (n.length / 4.0 * width).toFloat()
                                            val ny = 14f + (1f - (n.pitch - low).toFloat() / range) * (size.height - 28f)
                                            drawRect(Color(0xFF33264B), Offset(nx, ny),
                                                Size(nw.coerceIn(2f, width), 2.5f))
                                        }
                                    } else {
                                        for (beat in 0 until 16) {
                                            val stepIndex = (bar * 16 + beat) % project.patternLength
                                            if (row < 4 && project.steps[row][stepIndex]) {
                                                val at = x + beat / 16f * width
                                                drawRect(Color(0xFF372715), Offset(at, size.height / 2 - 8f),
                                                    Size(max(2f, width / 27f), 16f))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    HorizontalDivider(color = VS_GRID.copy(alpha = .35f), thickness = .5.dp)
                }
            }
            // Playhead stays in a fixed screen position while clips/ruler move under it.
            Canvas(Modifier.fillMaxHeight().width(2.dp)
                .offset(x = LABEL_WIDTH.dp + with(density) { (viewportPx / 2f).toDp() })) {
                drawLine(Color.White, Offset(0f, 0f), Offset(0f, size.height), 2.5f)
            }
        }
        val a = selectedAudio
        val hasNotes = selected.track >= 0 && selected.bar >= 0
        if (a != null || hasNotes) {
            Row(Modifier.fillMaxWidth().height(55.dp).horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                if (a != null) {
                    VsAction("✂ DIVIDIR") {
                        onChange { p -> p.audioClips.firstOrNull { it.id == a.id }?.let { clip ->
                            val atBeat = playSeconds / spb
                            if (!clip.repeat && p.audioClips.size < 8 &&
                                atBeat > clip.startBeat + .25 && atBeat < clip.startBeat + clip.lengthBeats - .25) {
                                val first = atBeat - clip.startBeat
                                val tail = clip.lengthBeats - first
                                p.audioClips.add(clip.copy(id = System.nanoTime().toString(),
                                    startBeat = atBeat, trimSeconds = clip.trimSeconds + first * spb,
                                    lengthBeats = tail))
                                clip.lengthBeats = first
                            }
                        } }
                    }
                    VsAction("⧉ DUPLICAR") {
                        onChange { p -> p.audioClips.firstOrNull { it.id == a.id }?.let { clip ->
                            val at = clip.startBeat + clip.lengthBeats
                            if (p.audioClips.size < 8 && at + .25 <= p.bars * 4.0)
                                p.audioClips.add(clip.copy(id = System.nanoTime().toString(),
                                    startBeat = at, lengthBeats = min(clip.lengthBeats, p.bars * 4.0 - at)))
                        } }
                    }
                    VsAction(if (a.repeat) "REPETIR ✓" else "REPETIR") {
                        onChange { p -> p.audioClips.firstOrNull { it.id == a.id }?.repeat = !a.repeat }
                    }
                    VsAction(if (a.muted) "OÍR" else "SILENCIAR") {
                        onChange { p -> p.audioClips.firstOrNull { it.id == a.id }?.muted = !a.muted }
                    }
                    VsAction("VOL −") { onChange { p -> p.audioClips.firstOrNull { it.id == a.id }?.let {
                        it.gain = (it.gain - .1).coerceAtLeast(0.0)
                    } } }
                    VsAction("VOL +") { onChange { p -> p.audioClips.firstOrNull { it.id == a.id }?.let {
                        it.gain = (it.gain + .1).coerceAtMost(1.0)
                    } } }
                    VsAction("BORRAR") { onChange { it.audioClips.removeAll { c -> c.id == a.id } }; selected = VsHit() }
                } else if (hasNotes) {
                    val track = selected.track; val bar = selected.bar
                    VsAction("✎ NOTAS") { onEditNotes(track, bar) }
                    VsAction("🎹 TOCAR") { onOpenPiano(if (track < 4) 6 else track) }
                    VsAction("⧉ DUPLICAR") {
                        if (bar + 1 < project.bars) onChange { TimelineEdits.moveBar(it, track, bar, bar + 1, duplicate = true) }
                    }
                    VsAction(if (project.muted[track]) "OÍR" else "SILENCIAR") {
                        onChange { it.muted[track] = !it.muted[track] }
                    }
                    VsAction("BORRAR") { onChange { TimelineEdits.deleteBar(it, track, bar) }; selected = VsHit() }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(51.dp).horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Button(onClick = onAddInstrument, colors = ButtonDefaults.buttonColors(containerColor = VS_YELLOW),
                contentPadding = PaddingValues(horizontal = 12.dp)) {
                Text("+ PISTA", color = Color(0xFF161515), fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = onImport) { Text("+ AUDIO", color = VS_TEXT) }
            OutlinedButton(onClick = { onChange { it.cycleEnabled = !it.cycleEnabled } }) {
                Text(if (project.cycleEnabled) "↻ CICLO ✓" else "↻ CICLO", color = VS_TEXT)
            }
            OutlinedButton(onClick = {
                onChange { p ->
                    val beat = playSeconds / spb
                    val wantedBars = ceil((beat + 50.0 / spb) / 4.0).toInt()
                    p.bars = max(p.bars, wantedBars).coerceAtMost(BAR_LIMIT)
                    p.cycleStartBeat = beat.coerceIn(0.0, p.bars * 4.0 - .25)
                    p.cycleEndBeat = (p.cycleStartBeat + 50.0 / spb).coerceAtMost(p.bars * 4.0)
                    p.cycleEnabled = true
                }
            }) { Text("50 s", color = VS_TEXT) }
            OutlinedButton(onClick = { onChange { it.bars = (it.bars + 8).coerceAtMost(BAR_LIMIT) } }) {
                Text("+ TIEMPO", color = VS_TEXT)
            }
        }
    }
}

@Composable
private fun VsAction(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 11.dp),
        modifier = Modifier.height(44.dp)) {
        Text(label, color = VS_TEXT, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}
