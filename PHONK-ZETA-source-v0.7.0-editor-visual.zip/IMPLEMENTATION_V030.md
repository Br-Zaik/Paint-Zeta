# PHONK ZETA v0.3.0 — implementación entregada (20-09-2026)

## Cambios REALES de código respecto a v0.2.3

1. Nuevo modo intérprete horizontal en `PerformanceScreen.kt`: piano de 7/10/14 teclas blancas de alto completo, 8 Smart Keys enormes en escala menor y 16 pads 4×4 con multitouch. Play, REC, Stop, octava, fuerza y selector de 6 instrumentos accesibles sin abandonar la superficie táctil. Cambio de orientación solo al entrar/salir del modo.
2. Contraste general mejorado: etiquetas secundarias claras y texto principal aumentado a 13–14 sp; botones para entrar directamente en Piano / Smart Keys / Pads horizontales.
3. Nuevo modo «Crear PHONK fácil» en `EasyPhonk.kt`, con estilos DRIFT, DARK, AGRESIVO, BRAZILIAN y SLOWED, longitud 15/30/60 s y patrones **originales editables** por capas: batería, 808 y cowbell; cortes intro/drop y una variación cada cuatro compases. No descarga ni reproduce una canción prediseñada.
4. El motor reproduce seis muestras incluidas en el kit original (kick, snare, hat, clap, 808 y cowbell) y las incluye también en el render WAV; la síntesis anterior queda como respaldo.
5. Importar MP3/WAV/M4A/FLAC/OGG según el decodificador de Android como fondo mono PCM, máx. 115 segundos, o como sample en el instrumento SAMPLER. Usar el selector de archivos de Android sin permiso para toda la memoria. El fondo se copia dentro del almacenamiento privado y el proyecto guarda su referencia; volumen editable en MIXER. Se escucha durante PLAY y también en la exportación WAV/M4A.
6. Exportación adicional M4A AAC de 192 kbps mediante encoder Android a partir del mismo WAV que utiliza el proyecto; WAV estéreo sin cambios.
7. Se añadieron pruebas unitarias para generación editable, guardado de referencia de fondo y escritura WAV; la prueba de ejecución de MediaCodec requiere dispositivo Android.

## Límites conocidos: NO presentar como implementado

- MP3 **de salida**: todavía no hay codificador MP3 integrado. Exportar M4A (audio comprimido) o WAV.
- Oboe/AAudio/NDK C++: el motor de baja latencia profesional **no** ha sustituido aún al backend AudioTrack del prototipo.
- Grabación de voz sobre una línea de tiempo libre: el micrófono sigue grabando un WAV para el sampler, no un clip multipista alineado.
- El fondo importado empieza en 0 s: no hay todavía recorte, arrastre, time-stretch ni forma de onda. No se importan canciones completas de más de 115 s. Fondo downmix a mono para bajar la RAM; mix final WAV/M4A estéreo.
- No hay simultaneidad de 16 samples independientes en los pads ni funcionalidad profesional equivalente a FL Studio Mobile.
- El diseño visual y el motor deben probarse en Android 11 real y en GitHub Actions antes de considerarse validados. No se garantiza latencia idéntica en todos los equipos.

## Flujo recomendado de prueba en teléfono

1. Abre la app → «CREAR PHONK 30 s» → DRIFT → Generar base → Play.
2. «PIANO GIGANTE» o «MODO FÁCIL» → teléfono horizontal → REC → toca → FIN REC → VOLVER.
3. Abre PIANO ROLL para ver las notas grabadas; entra a RITMOS para guardar un patrón o PROYECTOS para guardar proyecto.
4. «+ MP3 / FONDO» → selecciona un archivo de audio propio de hasta 115 s → Play → prueba el nivel del fondo en MIXER.
5. Exporta WAV o M4A; abre el archivo resultante con un reproductor para confirmar duración y mezcla.

## GitHub Actions

- En el repositorio raíz tiene que existir `.github/workflows/android.yml` (archivo fuera del ZIP). El workflow incluido en el ZIP da preferencia a `PHONK-ZETA-source-v0.3.0*.zip`.
- Si se conserva el workflow viejo fuera del ZIP y éste da preferencia a `PHONK-ZETA-source-v0.2.2*.zip`, **elimina los ZIP viejos del repositorio**, o reemplaza el archivo workflow raíz con el `android.yml` incluido en esta entrega.
- Descargar `PHONK-ZETA-APK-debug` cuando la ejecución finalice verde. Si falla, el artefacto `PHONK-ZETA-diagnostico` incluye el log.
