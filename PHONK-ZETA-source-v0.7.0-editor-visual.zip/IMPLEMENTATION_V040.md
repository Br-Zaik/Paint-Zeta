# PHONK ZETA v0.4.0 — Legibilidad, grabaciones y duración editable

## Cambios reales en código
- Contraste reforzado: texto principal blanco, secundarios claros, botones inactivos legibles; tabs y selectores con color explícito y mayor tamaño; guardar/WAV/M4A tienen letras visibles.
- INICIO explica con botones grandes el orden elegir base → escuchar → tocar/REC → GRABACIONES.
- REC tiene cuenta regresiva **visual** 3/2/1 (no pre-click de metrónomo); FIN REC crea toma con nombre y notas, se guarda dentro del JSON v3, se activa la pestaña GRABACIONES. Desde piano horizontal al terminar vuelve a vertical.
- GRABACIONES: reproducir SOLO la toma sin base ni fondo, STOP vuelve al proyecto, EDITAR abre Piano Roll, REGRABAR abre instrumento y conserva toma anterior, RENOMBRAR, BORRAR (con confirmación). La preescucha usa captura original de la interpretación; editar en Piano Roll altera la canción pero no reescribe la captura original de la toma.
- Grabación que continúa tras repetirse la base contabiliza vueltas de reproducción y amplía compases al terminar, dentro del límite técnico.
- MODO FÁCIL ajusta 8 teclas grandes a la tónica aproximada de la base generada (derivada del bajo).
- Crear PHONK no fuerza 30/60 segundos: escoge compases libremente (2 a 512), y se pueden añadir posteriormente desde TRACKS. 512 es un límite técnico **real**, no afirmar duración ilimitada. WAV PCM16 RIFF clásico también tiene límite de ~4 GiB; el dispositivo impone memoria/espacio.
- Generador original con pequeñas variaciones/fills en transiciones y sección final, sin afirmar que produzca automáticamente una canción comercial.
- Migración de proyectos JSON antiguos schema 1/2 a schema 3; takes JSON persistidos, audio importado sigue guardado localmente.
- Tests JVM añadidos sobre toma persistida, proyectos anteriores y compases personalizados.

## Cómo probar en Android
1. Crear base → selecciona estilo y escribe por ejemplo 42 compases → GENERAR.
2. PLAY escucha base. PIANO → MODO FÁCIL horizontal → REC → 3/2/1 → toca teclas → FIN REC.
3. GRABACIONES → ▶ SOLO comprueba que no suena la base → ■ STOP → PLAY escucha la canción con tu melodía encima.
4. RENOMBRAR toma → GUARDAR → cerrar y abrir → comprobar toma persistida → WAV/M4A.
5. PADS horizontal → REC → golpes → FIN REC → comprobar segunda toma.
6. Introducir 512 compases no está pensado para exportar en teléfonos de RAM baja: comenzar con 16-40 y ampliar progresivamente.

## Lo que NO incluye aún
No hay MP3 de salida (WAV/M4A sí en fuente); no hay motor C++ Oboe, import de fondos limitado a 115 segundos por archivo, piano roll todavía por compás y no multipista con clips editables, ni grabación de micrófono como audio clip dentro del timeline. No prometemos compilación/funcionamiento verificados en dispositivo hasta pasar Actions y pruebas manuales. La pre-cuenta no incorpora clic sonoro.
