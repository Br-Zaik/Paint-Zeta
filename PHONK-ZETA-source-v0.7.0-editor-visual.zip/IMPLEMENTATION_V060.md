# PHONK ZETA v0.6.0 — Editor musical por tiempo (20/09/2026)

Nuevo en el código fuente:
- Pestaña **EDITOR** también visible en Modo Fácil, y acceso destacado desde MI CANCIÓN.
- Visualización por páginas de ocho compases con tiempo `mm:ss`, cursor, autoseguimiento y navegación manual; no se crean 8192 componentes a la vez en proyectos grandes.
- Bloques por pista musical, selección y desplazamiento por arrastre/barra; mover, duplicar, acortar notas, borrar, abrir Piano Roll.
- **Clips de audio importado independientes** (hasta 8 instancias), con nombre del archivo y forma de onda aproximada; arrastrar, desplazar, recortar inicio, acortar o alargar, duplicar, cortar en el cursor, repetir contenido de origen, volumen, solo, silenciar y borrar.
- El motor de reproducción PCM y el render de WAV/M4A leen esos mismos clips y sus posiciones/recortes/ganancias. Exportación no recorta la canción al área de práctica.
- Ciclo de práctica con comienzo/final visibles; acepta duración en segundos, por ejemplo 50 s, limitada a la duración actual del proyecto; ajuste fino por sliders.
- Tiempo visible en transporte y en piano horizontal; opción `VER NOTAS + TECLAS` en paisaje y notas editables sobre el piano en vertical.
- Proyectos schema=5 con compatibilidad de lectura de schema=1..4 y clips; test de persistencia, desplazamiento y render de audio desplazado.
- Duración ampliable hasta 512 compases; hasta 240 segundos *por audio importado*, condicionado por RAM/codificador Android. En teléfonos modestos conviene usar clips cortos.

## Limitaciones verificables
- Bloques MIDI son grupos de eventos por compás, no todavía regiones MIDI con loops no destructivos independientes para cada instrumento.
- Las notas del modo horizontal se muestran al guardar la toma; no hay onda/notas en vivo para cada pulsación antes de soltar.
- La forma de onda es vista previa por picos del archivo completo, no una vista sample-accurate de cada recorte.
- Audio importado se decodifica a PCM mono mediante codecs Android y se almacena en app interna. Oboe/C++, time-stretch avanzado, MP3 exportado, audio streaming desde disco y editor de 100 pistas siguen pendientes.
- Los .phonkproj JSON exportados NO empaquetan los WAV asociados. Hay que mantener también los audios internos al transferir proyectos.
- El análisis local no equivale a compilación Android ni a prueba en dispositivo. Consultar GitHub Actions.
