# Paint Zeta v8.48 — Estilo de edición (como los edits de anime y manhwa)

Lo que tienen tus 10 capturas, hecho dentro de la app.

## Qué tienen tus ejemplos

- **Anime a color** (Eris, Mushoku Tensei):
  - colores planos con sombra de 2 tonos y líneas negras;
  - un acabado suave: contraste un poco bajo, sombras con tinte frío, luces cálidas y un brillo leve;
  - a veces borde RGB (el color corrido en las orillas).
- **Manga B/N con color** (Toji, Sukuna, el manhwa):
  - **no está pintado**: es un **mapa de degradado**. Cada gris pasa a un color, por ejemplo negro → azul oscuro → violeta → rosa claro (Toji), o negro → gris verdoso → blanco celeste (Sukuna);
  - se suma brillo, **grano** (Sukuna), **partículas de luz** (manhwa) y bordes oscuros;
  - los **ojos rojos o amarillos** son lo único de color: se pintan a mano y se quedan de color sobre el tinte.

## Cómo se usa

1. Menú ⋮ → **IMAGEN** → **Estilo edición**.
2. Arriba, los estilos:
   - **Anime** (para imágenes a color);
   - **Noche violeta**, **Frío con grano**, **Luz celeste**, **Dorado**, **Sepia** y **B/N fuerte** (para B/N).
   La app elige sola entre Anime y Noche violeta según si tu imagen es a color o B/N.
3. Botones:
   - **Grano**;
   - **Partículas** (cada toque las cambia de lugar);
   - **RGB** (borde de color corrido);
   - **Colores**: lo que pintaste de color vivo, como los ojos, se queda de color.
4. Deslizadores: **Fuerza** (cuánto estilo), **Brillo** y **Bordes** (orillas más oscuras).
5. **✓**: lo hace en tamaño real. **X**: lo quita todo.
6. Queda en capas **✦** arriba de todo: el estilo, ✦ Brillo, ✦ Grano y ✦ Partículas. Puedes ocultarlas o bajarles la opacidad. Para animar: Guardar → PNG por capa en ZIP.

**Consejos para que quede como tus ejemplos:**
- **Toji / Sukuna**: tu B/N → Pincel en una capa nueva, pinta los ojos de rojo → Estilo edición → Noche violeta o Frío con grano (con Grano), con Colores prendido.
- **Eris (anime)**: Colorear fácil (paso 2: **2 tonos** y **Sombra auto**) → Estilo edición → **Anime** con un poco de RGB.
- **Manhwa celeste**: Luz celeste con Brillo alto y Partículas.

## YA EXISTÍA

- Colorear fácil con 2 tonos y Sombra auto.
- Luz y ambiente.
- Capas con modos y exportación por capas.

## MODIFICADO

- Menú ⋮: nueva opción **Estilo edición**.
- **Luz y ambiente**: sus capas de luz quedan debajo del Estilo de edición.
- Versión 8.48 (código 86).

## NUEVO

- **Motor de estilos** (core/Looks.java, código propio):
  - mapa de degradado en OKLab;
  - acabado Anime;
  - conservar colores vivos;
  - brillo, grano, partículas, borde RGB y bordes oscuros.

## PENDIENTE

- **Probar en tu teléfono** la barra de estilos. Aquí no hay emulador.
- **El marco de video** (la imagen en el centro con la misma imagen borrosa a los costados, como en tus capturas del manhwa) es de la edición de video. Se hace en Alight Motion o CapCut con "fondo desenfocado". Si quieres, lo agrego después.

## Registro de pruebas

### Pruebas ejecutadas de verdad en PC

- Los estilos sobre tu Horikita y tu Ayanokouji en B/N, y el estilo Anime sobre la Horikita coloreada.
- Para probar "Colores", pinté los ojos de rojo yo mismo (como lo harías tú con Pincel).
- 0,1–0,4 s por imagen en el PC.
- Imagen: v848_estilo_edicion.jpg.
- **Compilación**: todo el código compila contra el Android real (android.jar 34).

### Solo compilado

- La barra, los botones y ✓/X en el teléfono.
