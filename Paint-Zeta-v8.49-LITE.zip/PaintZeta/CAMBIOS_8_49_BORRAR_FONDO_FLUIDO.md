# Paint Zeta v8.49 — Borrar fondo vuelve a ser fluido (sobre la v8.48)

Comparé el Borrar fondo de tu v8.38 y tu v8.39 con la v8.48.

## Qué se comparó

- **El motor del borrado** (cómo decide qué es fondo y qué borra) es **idéntico** en la v8.38, la v8.39 y la v8.48. No cambió.
- Lo que cambió está **alrededor** del borrado. Encontré 2 fallos.

## Fallo 1 (desde la v8.39): el guardado automático trababa el teléfono

- En la v8.39 agregué que "Restaurar" se guarde con la obra, como una imagen PNG completa.
- El error: **cada vez que empezabas un trazo**, la app marcaba esa copia como cambiada, **aunque no hubiera cambiado nada**.
- Como el guardado automático corre 4 segundos después de cada cambio, mientras borrabas el teléfono volvía a comprimir una imagen PNG completa **una y otra vez**. Eso gasta procesador y memoria. Por eso "al rato" el borrado se trababa y la marca salía con retraso.
- **Arreglo**:
  - la copia solo se marca como cambiada si de verdad cambió (si pintaste algo con otra herramienta);
  - además, **el guardado automático espera a que sueltes el dedo** (2,5 s sin tocar). Así nunca compite con el pincel.
  - Al salir de la app o cambiar de obra se guarda igual que siempre.

## Fallo 2 (desde la v8.45): estampas separadas, borrado "tosco"

- En la v8.45 hice que, si el pincel iba lento, separara más las estampas para no atrasarse. En tu teléfono eso hizo que el borrado saliera **a pedazos**: el círculo dejaba bordes con escalones, como en tu captura.
- **Arreglo**: lo quité. El paso entre estampas vuelve a ser **exactamente el de la v8.38**.

## Lo demás

- Nada más cambió en el borrado.
- Las otras funciones (colorear, luz, estilos) no se tocaron.
- Versión 8.49 (código 87).

## PENDIENTE

- **Probar en tu teléfono**, con la misma imagen de tu captura. Aquí no hay emulador: no puedo medir el retraso real del teléfono.
- Si todavía se siente más lento que la v8.38, mándame una captura de la opción "Medir rendimiento" (menú ⋮ → AYUDA Y AJUSTES) justo después de borrar. Así sé exactamente dónde se va el tiempo.

## Registro de pruebas

- **Comparación de código** entre v8.38, v8.39 y v8.48: el motor del borrado es igual; los 2 cambios de arriba son los únicos en el camino del pincel.
- **Compilación**: todo el código compila contra el Android real (android.jar 34).
- **Solo compilado**: la fluidez real en el teléfono.
