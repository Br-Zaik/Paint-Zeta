"""Pruebas estaticas del codigo fuente. No reemplazan ejecutar APK en Android."""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VIEW = (ROOT / 'app/src/main/java/com/pacco/animecut/view/CanvasView.java').read_text()
MAIN = (ROOT / 'app/src/main/java/com/pacco/animecut/MainActivity.java').read_text()


class SourceRegressions(unittest.TestCase):
    def test_paint_allocates_coverage_before_use(self):
        # Fallo reproducible de la version 8.14: stampPaint leia cov[i],
        # pero beginLayerStroke dejaba cov en null para MODE_PAINT.
        section = VIEW[VIEW.index('private boolean needsStrokeCoverage()'):VIEW.index('private boolean beginLayerStroke()')]
        self.assertIn('return mode == MODE_PAINT ||', section)
        paint_section = VIEW[VIEW.index('private void stampPaint(float cx, float cy)'):VIEW.index('private void stampParticles(')]
        self.assertIn('if (cov == null || strokeLayer == null) return;', paint_section)
        self.assertIn('int old = cov[i] & 0xFF;', VIEW)

    def test_liquify_modes_are_reachable(self):
        self.assertIn('String[] names = {"Arrastrar", "Contraer", "Expandir", "Suavizar", "Restaurar"}', MAIN)
        self.assertIn('canvas.setLiquifyType(which);', MAIN)
        self.assertIn('"Grosor\\n" + sizeText + "px"', MAIN)
        self.assertIn('"Fuerza " + v + "%"', MAIN)

    def test_color_and_liquify_strength_not_mixed(self):
        self.assertIn('if (canvas.getMode() != CanvasView.MODE_LIQUIFY) bottomOp.setProgress(op);', MAIN)
        self.assertIn('canvas.setEffectStrength(v / 100f);', MAIN)
        self.assertIn('canvas.setBrushOpacity(v / 100f);', MAIN)

    def test_liquify_edge_and_final_sampling(self):
        self.assertIn('private void invertLiquify(', VIEW)
        self.assertIn('private void sampleLiquifyWithJacobian(', VIEW)
        self.assertIn('Math.min(project.w - 1f, x)', VIEW)
        self.assertIn('Math.min(project.h - 1f, y)', VIEW)
        # No usar la rasterizacion de malla sin antialias como preview.
        self.assertNotIn('drawBitmapMesh(liquifyMesh', VIEW)
        self.assertNotIn('buildLiquifyMeshPreview(', VIEW)
        # Vista previa y final deben invocar EL MISMO sampler de pixel.
        self.assertEqual(VIEW.count('renderLiquifyRegion(r);'), 2)

    def test_liquify_guard_is_applied_before_dirty_commit(self):
        method = VIEW[VIEW.index('private Rect effectLiquifyField('):VIEW.index('private final float[] liquifySample')]
        self.assertIn('LiquifyTopologyGuard.minTriangleRatio(', method)
        self.assertIn('if (minArea < .12f)', method)
        self.assertLess(method.index('if (minArea < .12f)'), method.index('markLiquifyDirty(dirty)'))

    def test_liquify_input_and_preview_are_not_coarsened(self):
        self.assertIn('getHistoricalX(0, hk)', VIEW)
        self.assertIn('!isShapeTool() && mode != MODE_LIQUIFY', VIEW)
        self.assertIn('mode == MODE_LIQUIFY ? 512 : 64', VIEW)
        self.assertNotIn('liquifyMeshPreviewVisible', VIEW)
        self.assertIn('if (liquifyPreviewDirtyValid) liquifyPreviewDirty.union(r);', VIEW)

    def test_all_resource_xml_parses(self):
        for file in ROOT.glob('app/src/main/res/**/*.xml'):
            with self.subTest(file=file.name):
                ET.parse(file)

    def test_simple_tools_and_automatic_lasso_copy(self):
        main_menu = MAIN[MAIN.index('private static final int[][] TOOLS = {'):MAIN.index('private String[] toolInfo(')]
        for removed in ('MODE_WAND', 'MODE_BRUSH', 'MODE_SCISSORS', 'MODE_MAGNET',
                        'MODE_ZONE', 'MODE_PATCH', 'MODE_CLONE', 'MODE_TONE',
                        'MODE_HEAL', 'MODE_LINE'):
            self.assertNotIn(removed, main_menu)
        for kept in ('MODE_LASSO', 'MODE_PAINT', 'MODE_ERASER', 'MODE_BUCKET',
                     'MODE_LIQUIFY', 'MODE_MARKER', 'MODE_BGERASE', 'MODE_TRANSFORM'):
            self.assertIn(kept, main_menu)
        self.assertIn('callback.onLassoCompleted()', VIEW)
        self.assertIn('partFromSelectionDialog(false)', MAIN)
        self.assertIn('canvas.clearTemporarySelectionAfterCopy()', MAIN)

    def test_two_fingers_use_single_transform_pipeline(self):
        touch = VIEW[VIEW.index('public boolean onTouchEvent(MotionEvent e)'):
                     VIEW.index('private void beginPending()')]
        self.assertNotIn('scaleDetector.onTouchEvent(e)', touch)
        zoom = VIEW[VIEW.index('private void twoFingers('):
                    VIEW.index('private void armQuickPick()')]
        self.assertIn('view.postTranslate(', zoom)
        self.assertIn('view.postScale(', zoom)
        self.assertIn('lastPinchDistance', zoom)
        self.assertIn('postInvalidateOnAnimation()', zoom)

    def test_menu_opens_visible_tool_and_guided_workflow(self):
        section = MAIN[MAIN.index('private void afterProjectLoaded('): MAIN.index('private void applyLoaded(')]
        self.assertIn('canvas.setMode(CanvasView.MODE_PAN)', section)
        self.assertIn('animationWorkflowDialog()', MAIN)
        self.assertIn('exportAnimationZip()', MAIN)
        self.assertIn('selectTool(CanvasView.MODE_LASSO)', MAIN)

    def test_auto_save_has_recoverable_backup(self):
        self.assertIn('final File bak = new File(dest.getAbsolutePath() + ".bak")', MAIN)
        self.assertIn('dest.renameTo(bak)', MAIN)
        self.assertIn('tmp.renameTo(dest)', MAIN)
        self.assertIn('recoveredBackup = true', MAIN)
        store = (ROOT / 'app/src/main/java/com/pacco/animecut/core/ProjectStore.java').read_text()
        self.assertIn('n.endsWith(".acut.bak")', store)
        self.assertIn('if (bak.exists()) bak.delete()', store)

    def test_lasso_copy_and_cut_are_available(self):
        self.assertIn('finishPartExtraction(!cut', MAIN)
        self.assertIn('finishPartExtraction(cut', MAIN)
        self.assertIn('canvas.clearTemporarySelectionAfterCopy()', MAIN)

    def test_special_hold_processing_and_alpha_clean_blur(self):
        self.assertIn('handler.postDelayed(liquifyHold, LIQUIFY_HOLD_MS);', VIEW)
        self.assertIn('handler.removeCallbacks(liquifyHold);', VIEW)
        self.assertIn('AlphaColors.mix(base, warped, sel)', VIEW)
        self.assertIn('AlphaColors.mix(px[row + x], avg, f)', VIEW)
        self.assertIn('int as = blurColA[x0] + blurColA[x1] + blurColA[x2]', VIEW)
        exporter = (ROOT / 'app/src/main/java/com/pacco/animecut/core/Exporter.java').read_text()
        self.assertIn('LEEME_Partes.txt', exporter)

    def test_version(self):
        gradle = (ROOT / 'app/build.gradle').read_text()
        self.assertIn('versionCode 55', gradle)
        self.assertIn('versionName "8.18"', gradle)


if __name__ == '__main__':
    unittest.main()
