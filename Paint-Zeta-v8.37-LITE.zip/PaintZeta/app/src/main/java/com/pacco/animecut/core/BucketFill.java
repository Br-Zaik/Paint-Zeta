package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Motor del balde de pintura (v8.24). Sin IA: solo color, distancias y vecinos.
 *
 * Problemas del balde anterior (medidos en v8.23):
 *  1. El relleno avanzaba por "tolerancia + suavidad" (32 + 24): pasaba a colores
 *     parecidos de al lado (por ejemplo de un rosa claro al blanco).
 *  2. Para cerrar cortes engordaba TODAS las lineas 4 px y luego solo crecia de
 *     vuelta en parte: los rincones agudos quedaban blancos y lo que estaba detras
 *     de un corte quedaba pintado a medias.
 *  3. Cerca de la linea multiplicaba el color por el brillo del pixel: copiaba el
 *     ruido del JPEG (manchas) y daba bordes irregulares.
 *
 * Este motor, en 4 pasos:
 *  1. ZONA: relleno por lineas (scanline) de 4 vecinos con la tolerancia ESTRICTA
 *     respecto del color tocado (sin franja de suavidad que deje pasar).
 *  2. CORTES: se mide la distancia de cada pixel de la zona al borde. Lo "ancho"
 *     (mas lejos que el radio) se separa en el lado tocado y los otros lados. Lo
 *     "angosto" (rincones, bordes y cortes) se reparte entre ellos segun quien
 *     llega primero. Un rincon solo lo alcanza el lado tocado: se pinta entero.
 *     Un corte queda partido por la mitad: lo de atras no se pinta. El radio se
 *     ajusta solo si tocaste una zona angosta.
 *  3. AGUJEROS: motas pequenas sin linea dentro de la zona (ruido, JPEG) se rellenan.
 *  4. HASTA LA LINEA: desde el borde se avanza por el antialias y se calcula cuanto
 *     del color de la zona tiene cada pixel (f, proyeccion entre el color de la zona
 *     y el color de enfrente: la linea, u otro color en un borde de sombra). El
 *     color final es mezcla(color de enfrente, color elegido, f): la linea conserva
 *     su forma y su antialias, sin franja blanca, sin manchas y sin dientes.
 *
 * Mascara de salida (byte por pixel): 0 = no se toca; 255 = color elegido entero;
 * 1..254 = pixel del filo con f = valor/255 de color elegido.
 */
public final class BucketFill {
    private BucketFill() { }

    public static final class Params {
        /** Tolerancia ESTRICTA (0..255, escala de ColorDist). */
        public int tolerance = 20;
        /** Radio para cerrar cortes (0 = no). Cierra cortes de hasta ~2*radio px. */
        public int gap = 4;
        /** Avanzar por el antialias hasta el centro de la linea. */
        public boolean toLine = true;
        /** Motas encerradas de hasta este tamano se rellenan (si no son linea). */
        public int holeMax = 64;
        public int colorMode = ColorDist.RGB;
        /** Lineas marcadas (opcional): el relleno no las cruza. */
        public byte[] barrier;
        /** v8.28: con un punto opaco, lo transparente es pared (no papel). */
        public boolean clearIsWall = true;
    }

    public static final class Result {
        public Rect bounds;
        /** Color tocado (sobre papel blanco) y su brillo. */
        public int seedColor, seedLum;
        /** Radio de cierre de cortes que se uso (puede ser menor al pedido). */
        public int gapUsed;
        /** Pixeles de la zona, del filo y de agujeros rellenados (diagnostico). */
        public int area, band, holes;
    }

    /** Pixel compuesto sobre papel blanco (lo transparente cuenta como papel). */
    public static int paper(int c) {
        int a = c >>> 24;
        if (a == 255) return c;
        if (a == 0) return 0xFFFFFFFF;
        int r = (((c >> 16) & 255) * a + 255 * (255 - a)) / 255;
        int g = (((c >> 8) & 255) * a + 255 * (255 - a)) / 255;
        int b = ((c & 255) * a + 255 * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /**
     * v8.28: dentro de compute(), si tocaste algo OPACO (la cara de un dibujo), lo transparente
     * (alfa < 128: el fondo que borraste con Borrar fondo) cuenta como pared negra, no como papel.
     * Antes contaba como papel blanco: el balde se salia por cualquier corte de la linea y pintaba
     * todo el fondo borrado (captura 5). Si tocas algo transparente (lineas sueltas en una capa
     * transparente), todo sigue como antes: lo transparente es papel.
     */
    private static boolean wall;

    static int pz(int c) {
        if (wall && (c >>> 24) < 128) return 0xFF000000;
        return paper(c);
    }

    public static int lum(int c) {
        return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
    }

    /**
     * Calcula la mascara del relleno. 'out' (w*h) debe venir en cero.
     * @return null si el punto no es valido
     */
    public static synchronized Result compute(int[] ref, int w, int h, int sx, int sy, Params p, byte[] out) {
        if (sx < 0 || sy < 0 || sx >= w || sy >= h) return null;
        wall = p.clearIsWall && (ref[sy * w + sx] >>> 24) >= 128;
        try {
            return computeInner(ref, w, h, sx, sy, p, out);
        } finally {
            wall = false;
        }
    }

    private static Result computeInner(int[] ref, int w, int h, int sx, int sy, Params p, byte[] out) {
        byte[] bar = p.barrier;
        int seedI = sy * w + sx;
        if (bar != null && bar[seedI] != 0) bar = null; // tocaste la linea misma: relleno simple
        Result res = new Result();
        int seed = paper(ref[seedI]);
        res.seedColor = seed;
        res.seedLum = lum(seed);

        // ---- 1. zona por tolerancia estricta ----
        int[] bb = flood(ref, w, h, sx, sy, seed, p.tolerance, p.colorMode, bar, out);
        int x0 = bb[0], y0 = bb[1], x1 = bb[2], y1 = bb[3];

        // ---- 2. cortes ----
        int g = Math.max(0, p.gap);
        int m = g + 3;
        int rx0 = Math.max(0, x0 - m), ry0 = Math.max(0, y0 - m);
        int rx1 = Math.min(w, x1 + m), ry1 = Math.min(h, y1 + m);
        int rw = rx1 - rx0, rh = ry1 - ry0;
        byte[] other = null; // zona por tolerancia que queda del otro lado de un corte
        if (g > 0) {
            short[] d = chamfer(out, w, rx0, ry0, rw, rh, (g + 2) * 3);
            // si tocaste una zona angosta, subir al punto mas ancho cercano y achicar el radio
            int cx = sx - rx0, cy = sy - ry0;
            for (int step = 0; step < 64; step++) {
                int best = d[cy * rw + cx], bx = cx, by = cy;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int nx = cx + dx, ny = cy + dy;
                    if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                    if (out[(ny + ry0) * w + nx + rx0] == 0) continue;
                    if (d[ny * rw + nx] > best) { best = d[ny * rw + nx]; bx = nx; by = ny; }
                }
                if (bx == cx && by == cy) break;
                cx = bx; cy = by;
            }
            int r = Math.min(g, d[cy * rw + cx] / 3 - 1);
            if (r >= 1) {
                res.gapUsed = r;
                other = splitAtGaps(out, w, rx0, ry0, rw, rh, d, r * 3, cx, cy);
            }
        }

        // Desde aqui solo se trabaja alrededor de la zona que quedo (tras partir en los
        // cortes puede ser mucho mas chica que lo que alcanzo la tolerancia).
        if (other != null) {
            int bx0 = rx1, by0 = ry1, bx1 = -1, by1 = -1;
            for (int y = ry0; y < ry1; y++) {
                int row = y * w;
                for (int x = rx0; x < rx1; x++) {
                    if (out[row + x] == 0) continue;
                    if (x < bx0) bx0 = x;
                    if (x > bx1) bx1 = x;
                    if (y < by0) by0 = y;
                    if (y > by1) by1 = y;
                }
            }
            if (bx1 >= 0) {
                int nx0 = Math.max(rx0, bx0 - 6), ny0 = Math.max(ry0, by0 - 6);
                int nx1 = Math.min(rx1, bx1 + 7), ny1 = Math.min(ry1, by1 + 7);
                int nw = nx1 - nx0, nh = ny1 - ny0;
                byte[] o2 = new byte[nw * nh];
                for (int y = 0; y < nh; y++)
                    System.arraycopy(other, (y + ny0 - ry0) * rw + (nx0 - rx0), o2, y * nw, nw);
                other = o2;
                rx0 = nx0; ry0 = ny0; rx1 = nx1; ry1 = ny1; rw = nw; rh = nh;
            }
        }

        // ---- 3. agujeros pequenos sin linea ----
        res.holes = fillHoles(ref, w, h, out, other, rx0, ry0, rw, rh, seed, p);

        // ---- 4. filo hasta la linea ----
        int band = edges(ref, w, h, out, other, rx0, ry0, rw, rh, res.seedLum, p.toLine, seed, p.tolerance, p.colorMode);
        res.band = band;

        // limites reales
        int minX = w, minY = h, maxX = -1, maxY = -1, area = 0;
        for (int y = ry0; y < ry1; y++) {
            int row = y * w;
            for (int x = rx0; x < rx1; x++) {
                if (out[row + x] == 0) continue;
                area++;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        res.area = area;
        res.bounds = new Rect(minX, minY, maxX + 1, maxY + 1);
        return res;
    }

    // ------------------------------------------------------------------

    /** Relleno por lineas con tolerancia estricta. Marca 255. @return {x0,y0,x1,y1} exclusivo */
    private static int[] flood(int[] ref, int w, int h, int sx, int sy, int seed, int tol, int mode,
                               byte[] bar, byte[] out) {
        int[] st = new int[1024];
        int sp = 0;
        st[sp++] = sy * w + sx;
        int minX = sx, maxX = sx, minY = sy, maxY = sy;
        while (sp > 0) {
            int i = st[--sp];
            if (out[i] != 0 || !inside(ref, bar, i, seed, tol, mode)) continue;
            int y = i / w, row = y * w;
            int a = i - row, b = a;
            while (a > 0 && out[row + a - 1] == 0 && inside(ref, bar, row + a - 1, seed, tol, mode)) a--;
            while (b < w - 1 && out[row + b + 1] == 0 && inside(ref, bar, row + b + 1, seed, tol, mode)) b++;
            for (int x = a; x <= b; x++) out[row + x] = (byte) 255;
            if (a < minX) minX = a;
            if (b > maxX) maxX = b;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            for (int dy = -1; dy <= 1; dy += 2) {
                int ny = y + dy;
                if (ny < 0 || ny >= h) continue;
                int nrow = ny * w;
                boolean run = false;
                for (int x = a; x <= b; x++) {
                    int j = nrow + x;
                    boolean ok = out[j] == 0 && inside(ref, bar, j, seed, tol, mode);
                    if (ok && !run) {
                        if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                        st[sp++] = j;
                    }
                    run = ok;
                }
            }
        }
        return new int[]{minX, minY, maxX + 1, maxY + 1};
    }

    private static boolean inside(int[] ref, byte[] bar, int i, int seed, int tol, int mode) {
        // Una "linea" detectada que tiene el MISMO color que la zona tocada no es borde
        // para este relleno (p. ej. un color de un relleno anterior junto al blanco, que
        // el detector toma por linea fina oscura).
        return ColorDist.dist(pz(ref[i]), seed, mode) <= (bar != null && bar[i] != 0 ? Math.min(tol, 6) : tol);
    }

    /** Distancia chaflan 3-4 (aprox. 3 x euclidea) al pixel fuera de la zona, tope 'cap'. */
    static short[] chamfer(byte[] out, int w, int rx0, int ry0, int rw, int rh, int cap) {
        short[] d = new short[rw * rh];
        for (int y = 0; y < rh; y++) {
            int row = (y + ry0) * w + rx0;
            for (int x = 0; x < rw; x++) d[y * rw + x] = out[row + x] == 0 ? 0 : (short) cap;
        }
        for (int y = 0; y < rh; y++) for (int x = 0; x < rw; x++) {
            int k = y * rw + x;
            int v = d[k];
            if (v == 0) continue;
            if (x > 0) v = Math.min(v, d[k - 1] + 3);
            if (y > 0) {
                v = Math.min(v, d[k - rw] + 3);
                if (x > 0) v = Math.min(v, d[k - rw - 1] + 4);
                if (x < rw - 1) v = Math.min(v, d[k - rw + 1] + 4);
            }
            d[k] = (short) v;
        }
        for (int y = rh - 1; y >= 0; y--) for (int x = rw - 1; x >= 0; x--) {
            int k = y * rw + x;
            int v = d[k];
            if (v == 0) continue;
            if (x < rw - 1) v = Math.min(v, d[k + 1] + 3);
            if (y < rh - 1) {
                v = Math.min(v, d[k + rw] + 3);
                if (x < rw - 1) v = Math.min(v, d[k + rw + 1] + 4);
                if (x > 0) v = Math.min(v, d[k + rw - 1] + 4);
            }
            d[k] = (short) v;
        }
        return d;
    }

    /**
     * Separa la zona en el lado tocado y las zonas que solo se unen a el por un corte.
     *  - Lo "ancho" (distancia al borde mayor que el radio) se agrupa en pedazos.
     *  - Lo "angosto" se reparte inundando desde lo mas ancho hacia lo mas angosto
     *    (cuencas): dos pedazos se encuentran en el punto MAS ANGOSTO del paso, o sea
     *    justo en el corte, y no a mitad de camino.
     *  - Un pedazo solo cuenta como "zona de atras" si es grande (minimo 150 px, o
     *    8*radio^2). Los pedazos chicos (ruido de JPEG junto a la linea, rincones)
     *    se quedan en el lado tocado.
     * Quita de 'out' lo de atras y lo devuelve marcado (para no pintarlo en el filo).
     * @return mascara local rw*rh (1 = zona de atras) o null
     */
    static byte[] splitAtGaps(byte[] out, int w, int rx0, int ry0, int rw, int rh,
                                      short[] d, int thr, int cx, int cy) {
        int n = rw * rh;
        int[] id = new int[n];
        int[] q = new int[Math.max(64, n / 16)];
        // 1. pedazos anchos (el del punto tocado es el 1)
        int next = 1;
        int seedK = cy * rw + cx;
        for (int pass = 0; pass < 2; pass++) {
            for (int k0 = pass == 0 ? seedK : 0; k0 < (pass == 0 ? seedK + 1 : n); k0++) {
                if (id[k0] != 0 || d[k0] <= thr) continue;
                int lab = next++;
                int qh = 0, qt = 0;
                id[k0] = lab;
                q[qt++] = k0;
                while (qh < qt) {
                    int k = q[qh++];
                    int x = k % rw, y = k / rw;
                    for (int t = 0; t < 4; t++) {
                        int nx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                        if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                        int j = ny * rw + nx;
                        if (id[j] != 0 || d[j] <= thr) continue;
                        id[j] = lab;
                        if (qt == q.length) { q = compact(q, qh, qt); qt -= qh; qh = 0; }
                        q[qt++] = j;
                    }
                }
            }
        }
        if (next <= 2) return null; // un solo pedazo ancho: no hay cortes
        // 2. inundacion por prioridad: de lo mas ancho a lo mas angosto
        int levels = 0;
        for (int k = 0; k < n; k++) if (d[k] > levels) levels = d[k];
        int[][] bucket = new int[levels + 1][];
        int[] bn = new int[levels + 1];
        int top = -1;
        for (int k = 0; k < n; k++) {
            if (id[k] == 0) continue;
            int x = k % rw, y = k / rw;
            for (int t = 0; t < 4; t++) {
                int nx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                int j = ny * rw + nx;
                if (id[j] != 0 || d[j] == 0) continue;
                id[j] = id[k];
                int lv = d[j];
                if (bucket[lv] == null) bucket[lv] = new int[64];
                if (bn[lv] == bucket[lv].length) bucket[lv] = java.util.Arrays.copyOf(bucket[lv], bn[lv] * 2);
                bucket[lv][bn[lv]++] = j;
                if (lv > top) top = lv;
            }
        }
        while (top >= 0) {
            if (bn[top] == 0) { top--; continue; }
            int k = bucket[top][--bn[top]];
            int x = k % rw, y = k / rw;
            for (int t = 0; t < 4; t++) {
                int nx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                int j = ny * rw + nx;
                if (id[j] != 0 || d[j] == 0) continue;
                id[j] = id[k];
                int lv = d[j];
                if (bucket[lv] == null) bucket[lv] = new int[64];
                if (bn[lv] == bucket[lv].length) bucket[lv] = java.util.Arrays.copyOf(bucket[lv], bn[lv] * 2);
                bucket[lv][bn[lv]++] = j;
                if (lv > top) top = lv;
            }
        }
        // 3. solo los pedazos grandes son "zona de atras"
        int[] area = new int[next];
        for (int k = 0; k < n; k++) if (id[k] > 0) area[id[k]]++;
        int r = thr / 3;
        int minOther = Math.max(150, 8 * r * r);
        boolean any = false;
        byte[] other = new byte[n];
        for (int y = 0; y < rh; y++) {
            int row = (y + ry0) * w + rx0;
            for (int x = 0; x < rw; x++) {
                int k = y * rw + x;
                if (d[k] == 0) continue;
                int l = id[k];
                if (l == 1) continue;
                if (l > 1 && area[l] < minOther) continue; // pedazo chico: se queda con el lado tocado
                out[row + x] = 0;
                other[k] = 1;
                any = true;
            }
        }
        return any ? other : null;
    }

    private static int[] compact(int[] q, int qh, int qt) {
        int len = qt - qh;
        int[] r = new int[Math.max(q.length, len * 2 + 64)];
        System.arraycopy(q, qh, r, 0, len);
        return r;
    }

    /**
     * Rellena motas encerradas por la zona (ruido del JPEG, puntitos de antialias
     * sueltos). No rellena un punto que tenga linea oscura (detalle del dibujo).
     */
    private static int fillHoles(int[] ref, int w, int h, byte[] out, byte[] other, int rx0, int ry0,
                                 int rw, int rh, int seed, Params p) {
        if (p.holeMax <= 0) return 0;
        int n = rw * rh;
        // 1. todo lo NO rellenado que toca el borde del recuadro o el otro lado de un corte
        //    queda "afuera" (barrido rapido, sin comparar colores)
        byte[] seen = new byte[n];
        int[] st = new int[1024];
        int sp = 0;
        for (int k = 0; k < n; k++) {
            int x = k % rw, y = k / rw;
            boolean edge = x == 0 || y == 0 || x == rw - 1 || y == rh - 1 || (other != null && other[k] != 0);
            if (!edge || seen[k] != 0) continue;
            if (out[(y + ry0) * w + x + rx0] != 0) continue;
            seen[k] = 1;
            if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
            st[sp++] = k;
            while (sp > 0) {
                int c = st[--sp];
                int cx = c % rw, cy = c / rw;
                for (int t = 0; t < 4; t++) {
                    int nx = cx + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = cy + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                    int j = ny * rw + nx;
                    if (seen[j] != 0 || out[(ny + ry0) * w + nx + rx0] != 0) continue;
                    seen[j] = 1;
                    if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                    st[sp++] = j;
                }
            }
        }
        // 2. lo que queda sin ver esta encerrado por la zona: motas candidatas
        int[] comp = new int[Math.max(16, p.holeMax + 1)];
        int filled = 0;
        int darkLim = Math.max(p.tolerance * 3, 60);
        for (int k0 = 0; k0 < n; k0++) {
            if (seen[k0] != 0) continue;
            int i0 = (k0 / rw + ry0) * w + k0 % rw + rx0;
            if (out[i0] != 0) { seen[k0] = 1; continue; }
            int cn = 0;
            boolean light = true;
            sp = 0;
            st[sp++] = k0;
            seen[k0] = 1;
            while (sp > 0) {
                int k = st[--sp];
                int x = k % rw, y = k / rw, i = (y + ry0) * w + x + rx0;
                if (cn < comp.length) comp[cn] = i;
                cn++;
                if (light && (cn > p.holeMax || ColorDist.dist(pz(ref[i]), seed, p.colorMode) > darkLim)) light = false;
                for (int t = 0; t < 4; t++) {
                    int nx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                    int j = ny * rw + nx;
                    if (seen[j] != 0) continue;
                    if (out[(ny + ry0) * w + nx + rx0] != 0) continue;
                    seen[j] = 1;
                    if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                    st[sp++] = j;
                }
            }
            if (light && cn <= p.holeMax) {
                for (int c = 0; c < cn; c++) out[comp[c]] = (byte) 255;
                filled += cn;
            }
        }
        return filled;
    }

    /** Brillo mas oscuro en los 8 vecinos (y el pixel). */
    private static int darkest3(int[] ref, int w, int h, int x, int y) {
        int best = 255;
        for (int dy = -1; dy <= 1; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= h) continue;
            for (int dx = -1; dx <= 1; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= w) continue;
                int l = lum(pz(ref[yy * w + xx]));
                if (l < best) best = l;
            }
        }
        return best;
    }

    /**
     * El color "de enfrente" del pixel q: el que, mezclado con el color de la zona,
     * mejor explica a q. Candidatos a 2 px o menos: el color mas distinto de la zona
     * (otro color, borde de sombra) y el pixel mas oscuro (centro de una linea).
     * Probar los dos evita errores donde una linea se junta con otra zona clara.
     */
    private static int opposite(int[] ref, int w, int h, int x, int y, int seed, int q) {
        int sr = (seed >> 16) & 255, sg = (seed >> 8) & 255, sb = seed & 255;
        int far = -1, farC = seed, dark = 256, darkC = seed;
        for (int dy = -2; dy <= 2; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= h) continue;
            for (int dx = -2; dx <= 2; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= w) continue;
                int c = pz(ref[yy * w + xx]);
                int dr = ((c >> 16) & 255) - sr, dg = ((c >> 8) & 255) - sg, db = (c & 255) - sb;
                int d = dr * dr + dg * dg + db * db;
                if (d > far) { far = d; farC = c; }
                int l = lum(c);
                if (l < dark) { dark = l; darkC = c; }
            }
        }
        if (farC == darkC) return farC;
        return residual(q, seed, darkC) <= residual(q, seed, farC) ? darkC : farC;
    }

    /** Distancia^2 de q al segmento entre d y seed (0 = q es mezcla exacta de los dos). */
    private static float residual(int q, int seed, int d) {
        float vr = ((seed >> 16) & 255) - ((d >> 16) & 255), vg = ((seed >> 8) & 255) - ((d >> 8) & 255), vb = (seed & 255) - (d & 255);
        float v2 = vr * vr + vg * vg + vb * vb;
        float ur = ((q >> 16) & 255) - ((d >> 16) & 255), ug = ((q >> 8) & 255) - ((d >> 8) & 255), ub = (q & 255) - (d & 255);
        if (v2 < 1f) return ur * ur + ug * ug + ub * ub;
        float f = (ur * vr + ug * vg + ub * vb) / v2;
        f = f < 0f ? 0f : f > 1f ? 1f : f;
        float er = ur - f * vr, eg = ug - f * vg, eb = ub - f * vb;
        return er * er + eg * eg + eb * eb;
    }

    /**
     * Cuanto del color de la zona tiene el pixel (0..1): proyeccion de su color sobre
     * el segmento entre el color de enfrente y el de la zona. 1 si no hay nada
     * distinto cerca o si el pixel no es mezcla de esos dos colores.
     */
    public static float paperFraction(int[] ref, int w, int h, int i, int seed) {
        int y = i / w, x = i - y * w;
        int q = pz(ref[i]);
        int d = opposite(ref, w, h, x, y, seed, q);
        float vr = ((seed >> 16) & 255) - ((d >> 16) & 255), vg = ((seed >> 8) & 255) - ((d >> 8) & 255), vb = (seed & 255) - (d & 255);
        float v2 = vr * vr + vg * vg + vb * vb;
        if (v2 < 35f * 35f) return 1f;
        float ur = ((q >> 16) & 255) - ((d >> 16) & 255), ug = ((q >> 8) & 255) - ((d >> 8) & 255), ub = (q & 255) - (d & 255);
        float f = (ur * vr + ug * vg + ub * vb) / v2;
        f = f < 0f ? 0f : f > 1f ? 1f : f;
        float er = ur - f * vr, eg = ug - f * vg, eb = ub - f * vb;
        if (er * er + eg * eg + eb * eb > Math.max(900f, v2 * .2f)) return 1f; // no es mezcla de esos dos
        return f;
    }

    /** Codifica la fraccion en el valor de mascara que entiende colorFor (255 = entero). */
    public static int encode(float f) { return enc(f) & 255; }

    private static byte enc(float f) {
        if (f >= .92f) return (byte) 255;
        int v = Math.round(f * 255f);
        return (byte) (v < 1 ? 1 : v > 254 ? 254 : v);
    }

    /**
     * v8.27: filo antialias para una zona hecha por otro motor (balde "Por lineas"):
     * 'out' trae 255 en la zona; dentro de 'r' los pixeles pegados a la tinta pasan a
     * 1..254 (fraccion de color) y, con toLine, se avanza por el antialias de la linea.
     * @return pixeles del filo agregados
     */
    public static int edgeBand(int[] ref, int w, int h, byte[] out, Rect r, int seedColor, boolean toLine,
                               int tol, int colorMode) {
        if (r == null || r.width() <= 0 || r.height() <= 0) return 0;
        return edges(ref, w, h, out, null, r.left, r.top, r.width(), r.height(), lum(seedColor), toLine,
                seedColor, tol, colorMode);
    }

    /**
     * Filo: (a) los pixeles de la zona pegados a una linea reciben su fraccion de
     * papel; (b) si toLine, se avanza por el antialias (8 vecinos, max 4 px)
     * mientras se oscurece, hasta el centro de la linea.
     */
    private static int edges(int[] ref, int w, int h, byte[] out, byte[] other, int rx0, int ry0,
                             int rw, int rh, int seedLum, boolean toLine, int seedColor, int tol, int colorMode) {
        int rx1 = rx0 + rw, ry1 = ry0 + rh;
        int[] front = new int[256], next = new int[256];
        int fn = 0, count = 0;
        // (a) borde de la zona
        for (int y = ry0; y < ry1; y++) {
            for (int x = rx0; x < rx1; x++) {
                int i = y * w + x;
                if ((out[i] & 255) != 255) continue;
                boolean border = false;
                for (int dy = -1; dy <= 1 && !border; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                    if (out[yy * w + xx] == 0) { border = true; break; }
                }
                if (!border) continue;
                if (fn == front.length) front = java.util.Arrays.copyOf(front, fn * 2);
                front[fn++] = i;
            }
        }
        // los pixeles del borde de la zona que ya son parte del antialias
        for (int f = 0; f < fn; f++) {
            int i = front[f];
            float pf = paperFraction(ref, w, h, i, seedColor);
            if (pf < .92f) out[i] = enc(pf);
        }
        if (!toLine) return 0;
        // (b) avanzar por el antialias mientras se oscurece
        for (int step = 0; step < 4 && fn > 0; step++) {
            int nn = 0;
            for (int f = 0; f < fn; f++) {
                int i = front[f];
                int y = i / w, x = i - y * w;
                float fi = (out[i] & 255) / 255f;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int xx = x + dx, yy = y + dy;
                    if (xx < rx0 || yy < ry0 || xx >= rx1 || yy >= ry1) continue;
                    int j = yy * w + xx;
                    if (out[j] != 0) continue;
                    if (other != null && other[(yy - ry0) * rw + xx - rx0] != 0) continue;
                    float pf = paperFraction(ref, w, h, j, seedColor);
                    if (pf >= .98f) {
                        // Mota clara pegada a la linea (rebote del JPEG): solo junto a la zona
                        // (paso 0), de color parecido y tocando la tinta. Se pinta y no se sigue.
                        if (step == 0 && ColorDist.dist(pz(ref[j]), seedColor, colorMode) <= Math.max(48, tol * 3)
                                && darkest3(ref, w, h, xx, yy) <= seedLum - 60) {
                            out[j] = (byte) 255;
                            count++;
                        }
                        continue;                            // no es filo (otro color)
                    }
                    if (pf <= .02f) continue;                // centro de la linea / el otro color puro
                    if (pf > fi + .06f) continue;            // vuelve a parecerse a la zona: es el otro lado
                    // v8.33: solo se sigue mientras BAJA de verdad (rampa del antialias). En un
                    // fondo con degradado suave (carta gris oscura con sombra diagonal) la
                    // fraccion casi no cambia: antes se seguia 4 px y quedaba un halo rojizo.
                    if (pf > fi - .08f) continue;
                    out[j] = enc(pf);
                    count++;
                    if (nn == next.length) next = java.util.Arrays.copyOf(next, nn * 2);
                    next[nn++] = j;
                }
            }
            int[] t = front; front = next; next = t;
            fn = nn;
        }
        return count;
    }

    // ------------------------------------------------------------------

    /**
     * Color visible que debe quedar en el pixel i (opaco, con el alfa del color).
     * @param shade conservar sombras: el color toma el brillo del dibujo
     */
    public static int colorFor(int[] ref, int w, int h, int i, int m, int fill, int seedColor, boolean shade) {
        int c = pz(ref[i]);
        if (shade) return LineFill.shade(fill, c, lum(seedColor));
        if (m == 255) return fill;
        float f = m / 255f;
        int y = i / w, x = i - y * w;
        // el color de enfrente (centro de la linea u otro color) se conserva en la mezcla
        int ink = opposite(ref, w, h, x, y, seedColor, c);
        int r = Math.round(((ink >> 16) & 255) * (1 - f) + ((fill >> 16) & 255) * f);
        int g = Math.round(((ink >> 8) & 255) * (1 - f) + ((fill >> 8) & 255) * f);
        int b = Math.round((ink & 255) * (1 - f) + (fill & 255) * f);
        return (fill & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}
