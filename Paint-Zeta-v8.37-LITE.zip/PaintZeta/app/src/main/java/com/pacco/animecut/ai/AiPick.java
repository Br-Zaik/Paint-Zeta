package com.pacco.animecut.ai;

/**
 * v8.36: "pinta encima del personaje que quieres". La IA separa personaje y fondo, pero dos
 * personajes que se tocan son UNA sola pieza para ella. Aqui la pintura del dedo elige:
 *
 *  1) Las zonas cerradas por las lineas del dibujo (las mismas de AiSnap) que la IA ve como
 *     personaje y que la pintura cubre en buena parte, se quedan. Las que la pintura casi no
 *     toca (el otro personaje, aunque este pegado) se van. El corte entre los dos sigue las
 *     lineas del dibujo.
 *  2) Detalles chicos que la pintura no cubrio (ojos, botones, un mechon entre zonas que se
 *     quedan) se recuperan con un "cierre" de la forma elegida.
 *  3) Lo suave (borde) va con el lado mas cercano.
 *
 * Solo actua si la pintura cubre bastante del personaje (si es una raya fina, manda la regla de
 * piezas de AiMatte). Se calcula a una resolucion de hasta ~1,5 MP (rapido y con poca memoria);
 * despues AiSnap afina el borde a resolucion completa. Java puro.
 */
public final class AiPick {

    public static final class Stats {
        public boolean used;
        public int zonesKept, zonesDropped;
        public float coverage;
        public long ms;
    }

    private AiPick() { }

    public static Stats apply(byte[] al, int[] px, int W, int H, int x0, int y0, int x1, int y1, float[] hint, float hw) {
        long t0 = System.nanoTime();
        Stats st = new Stats();
        if (hint == null) return st;
        int cw = x1 - x0, ch = y1 - y0;
        if (cw < 8 || ch < 8) return st;
        float s = (float) Math.min(1.0, Math.sqrt(1.5e6 / ((double) cw * ch)));
        int sw = Math.max(1, Math.round(cw * s)), sh = Math.max(1, Math.round(ch * s)), sn = sw * sh;
        float fx = cw / (float) sw, fy = ch / (float) sh;
        // ---- imagen reducida: luminancia y alfa promedio por celda ----
        byte[] L = new byte[sn], A = new byte[sn];
        {
            int[] sl = new int[sn], sa = new int[sn], cnt = new int[sn];
            for (int y = y0; y < y1; y++) {
                int yy = Math.min(sh - 1, (int) ((y - y0) / fy)), o = y * W;
                for (int x = x0; x < x1; x++) {
                    int xx = Math.min(sw - 1, (int) ((x - x0) / fx)), k = yy * sw + xx;
                    sl[k] += AiSnap.lum(px[o + x]);
                    sa[k] += al[o + x] & 0xFF;
                    cnt[k]++;
                }
            }
            for (int k = 0; k < sn; k++) {
                int c = Math.max(1, cnt[k]);
                L[k] = (byte) (sl[k] / c);
                A[k] = (byte) (sa[k] / c);
            }
        }
        byte[] P = paint(hint, x0, y0, s, sw, sh);
        // ---- la pintura cubre bastante del personaje? ----
        long fgAll = 0, fgPaint = 0;
        for (int k = 0; k < sn; k++) if ((A[k] & 0xFF) >= 128) { fgAll++; if (P[k] != 0) fgPaint++; }
        if (fgAll == 0 || fgPaint == 0) return st;
        st.coverage = fgPaint / (float) fgAll;
        if (st.coverage < 0.12f) return st;
        // ---- zonas cerradas por la linea ----
        float hs = Math.max(0.75f, hw * s);
        int r = (int) Math.ceil(2 * hs) + 2;
        int g = Math.max(1, Math.round(1.5f * hs + 1));
        byte[] ink = AiSnap.inkMap(L, sw, sh, r);
        int[] lab = new int[sn];
        int nl = AiSnap.zones(ink, sw, sh, g, lab);
        int[] zn = new int[nl + 1], zf = new int[nl + 1], zp = new int[nl + 1];
        for (int k = 0; k < sn; k++) {
            int l = lab[k];
            if (l == 0) continue;
            zn[l]++;
            if ((A[k] & 0xFF) >= 128) { zf[l]++; if (P[k] != 0) zp[l]++; }
        }
        boolean[] keepZ = new boolean[nl + 1];
        for (int l = 1; l <= nl; l++) {
            if (zf[l] * 2 < zn[l] || zf[l] == 0) continue;
            keepZ[l] = zp[l] * 100L >= zf[l] * 12L;
            if (keepZ[l]) st.zonesKept++; else st.zonesDropped++;
        }
        // lo que no es zona (tinta, rincon angosto) va con la zona MAS CERCANA (la linea entre una
        // zona que queda y otra que sale se parte al medio; AiSnap afina despues). Si no hay
        // ninguna zona cerca, manda la pintura.
        int[] dIn, dOut0;
        {
            byte[] zi = new byte[sn], zo = new byte[sn];
            for (int k = 0; k < sn; k++) {
                int l = lab[k];
                if (l == 0 || (A[k] & 0xFF) < 128) continue;
                if (keepZ[l]) zi[k] = 1; else zo[k] = 1;
            }
            dIn = AiMatte.edt(zi, sw, sh);
            dOut0 = AiMatte.edt(zo, sw, sh);
        }
        long far2 = (long) (3 * g + 3) * (3 * g + 3);
        // lo elegido: zonas que se quedan + su tinta
        byte[] K = new byte[sn];
        int bx0 = sw, by0 = sh, bx1 = -1, by1 = -1, nk = 0;
        for (int k = 0; k < sn; k++) {
            if ((A[k] & 0xFF) < 128) continue;
            int l = lab[k];
            boolean keep;
            if (l != 0) keep = keepZ[l];
            else if (dIn[k] > far2 && dOut0[k] > far2) keep = P[k] != 0;
            else keep = dIn[k] <= dOut0[k];
            if (!keep) continue;
            K[k] = 1; nk++;
            int x = k % sw, y = k / sw;
            if (x < bx0) bx0 = x; if (x > bx1) bx1 = x; if (y < by0) by0 = y; if (y > by1) by1 = y;
        }
        if (nk == 0) return st;
        // ---- cierre: recupera los detalles chicos rodeados de lo elegido ----
        int rc = Math.max(2, Math.round(0.035f * Math.max(bx1 - bx0 + 1, by1 - by0 + 1)));
        int[] dK = AiMatte.edt(K, sw, sh);
        byte[] notDil = new byte[sn];
        long rc2 = (long) rc * rc;
        for (int k = 0; k < sn; k++) if (dK[k] > rc2) notDil[k] = 1;
        int[] dOut = AiMatte.edt(notDil, sw, sh);
        notDil = null;
        byte[] keepS = new byte[sn], dropS = new byte[sn];
        for (int k = 0; k < sn; k++) {
            if ((A[k] & 0xFF) < 128) continue;
            boolean closed = dOut[k] > rc2;
            // el cierre solo completa tinta, rincones y zonas CHICAS (un ojo, un boton); una zona
            // grande entra o sale entera (sin cortes redondos a mitad de una zona)
            int l = lab[k];
            boolean keep = K[k] != 0 || (closed && (l == 0 || zn[l] <= 3L * rc2));
            if (keep) keepS[k] = 1; else dropS[k] = 1;
        }
        dK = dOut = null;
        // ---- a resolucion completa ----
        int[] dk = AiMatte.edt(keepS, sw, sh), dd = AiMatte.edt(dropS, sw, sh);
        long changed = 0;
        for (int y = y0; y < y1; y++) {
            int yy = Math.min(sh - 1, (int) ((y - y0) / fy)), o = y * W;
            for (int x = x0; x < x1; x++) {
                int i = o + x;
                int a = al[i] & 0xFF;
                if (a == 0) continue;
                int xx = Math.min(sw - 1, (int) ((x - x0) / fx)), k = yy * sw + xx;
                boolean keep = keepS[k] != 0 || (dropS[k] == 0 && dk[k] <= dd[k]);
                if (!keep) { al[i] = 0; changed++; }
            }
        }
        st.used = changed > 0;
        st.ms = (System.nanoTime() - t0) / 1_000_000L;
        return st;
    }

    /** Pintura del dedo en la grilla reducida. hint = (x, y, radio) en la capa; radio < 0 corta. */
    static byte[] paint(float[] hint, int x0, int y0, float s, int sw, int sh) {
        byte[] P = new byte[sw * sh];
        float px0 = Float.NaN, py0 = Float.NaN;
        for (int t = 0; t + 2 < hint.length; t += 3) {
            float rr = hint[t + 2];
            if (rr < 0) { px0 = Float.NaN; continue; }
            float x = (hint[t] - x0) * s, y = (hint[t + 1] - y0) * s, rc = Math.max(1f, rr * s);
            if (Float.isNaN(px0)) { px0 = x; py0 = y; }
            float dx = x - px0, dy = y - py0;
            int steps = Math.max(1, (int) Math.ceil(Math.sqrt(dx * dx + dy * dy) / Math.max(0.5f, rc * 0.5f)));
            for (int k = 0; k <= steps; k++) {
                float cx = px0 + dx * k / steps, cy = py0 + dy * k / steps;
                int ix0 = Math.max(0, (int) Math.floor(cx - rc)), ix1 = Math.min(sw - 1, (int) Math.ceil(cx + rc));
                int iy0 = Math.max(0, (int) Math.floor(cy - rc)), iy1 = Math.min(sh - 1, (int) Math.ceil(cy + rc));
                for (int yy = iy0; yy <= iy1; yy++)
                    for (int xx = ix0; xx <= ix1; xx++) {
                        float ex = xx + 0.5f - cx, ey = yy + 0.5f - cy;
                        if (ex * ex + ey * ey <= rc * rc) P[yy * sw + xx] = 1;
                    }
            }
            px0 = x; py0 = y;
        }
        return P;
    }
}
