# Paint Zeta v8.36 — IA: pintar al personaje y borde que sigue la línea (sobre la v8.35)

Usa la misma IA que ya tienes bajada (168 MB). **No baja nada nuevo** y la app pesa lo mismo. MobileSAM no se agregó: primero se probó lo que no pesa.

## 1. Pintar encima del personaje que quieres (tu idea)

- **Toca el botón de la IA**: queda marcado en azul. **Pinta encima del personaje** que quieres; la pintura se ve celeste.
- **Suelta el dedo y espera un segundo**: la IA trabaja con esa marca. Si quieres pintar más, sigue antes de que pase el segundo.
- **Personajes separados**: basta una raya encima. Los demás se van solos.
- **Dos personajes que se tocan** (para la IA son una sola pieza): pinta encima de casi todo el que quieres (cabeza, cuerpo, brazos, piernas).
  - Se queda cada zona del dibujo, cerrada por sus líneas, que pintaste en buena parte.
  - El corte entre los dos sigue las líneas del dibujo.
  - Lo que no pintes puede quedar afuera: **Restaurar** lo devuelve.
- **Más detalle**: si lo marcado es bastante más chico que la imagen, la IA mira **otra vez solo ahí**. Mira la misma imagen, pero con más píxeles por personaje.
- **Dos dedos**: zoom y mover. **Toque con dos dedos**: borra el último trazo.
- **Tocar la IA otra vez sin pintar**: toda la imagen, como antes.
- Elegir Balde, Pincel, Borrador o Restaurar cancela la marca.

## 2. El borde sigue la línea negra (capturas 1 a 7)

Etapa nueva después de la IA (`ai/AiSnap.java`, código propio):

1. **Tinta**: los píxeles bastante más oscuros que lo que los rodea (líneas y contornos).
2. **Zonas**: el resto se separa en zonas cerradas por la tinta. Un corte de la línea más chico que su grosor no une dos zonas.
3. **Voto**: cada zona chica (un mechón, un hueco entre líneas) entra o sale **entera**, según lo que dijo la IA en ella. Así se van las **manchas a medias** del manga.
   - En una zona grande solo se corrige el filo dudoso y las manchas chicas del mismo color.
   - Lo que la IA dio por seguro se respeta (por si la línea tenía un hueco).
   - El color tiene que darle la razón: un hueco de cielo entre mechones no entra entero.
4. **Línea**: el contorno pegado al personaje entra con él. En un fondo negro no se agrega nada.
5. **Antialias**: el borde sale de desmezclar la línea y el fondo de al lado. Queda **suave, sin escalones y sin el filo blanco** de fondo que se veía en tus capturas 3 y 4.

### Medido en el PC

- **Escenas con verdad conocida** (7 escenas propias), v8.35 → v8.36:
  - **error del borde**: mejora en 6 de 7 (blanco 7,2 → 3,6; dos personajes 10,5 → 6,3; trama 23,7 → 17,5);
  - **halo**: mejora en 5 de 7;
  - **JPEG muy malo**: queda igual (47,8 → 48,2).
  - Tabla: `docs/qa836/metricas_borde.txt`.
- **IA que se equivoca a manchas** (se le borraron y agregaron 6 manchas a propósito): falta de personaje 4013 → 2236 px y error del borde 9,0 → 3,7 en la escena blanca. Parecido en las otras 4 escenas.
  - `docs/qa836/P15_manchas.txt` y `manchas_corregidas.png`.
- **Tus imágenes**:
  - pelo blanco sin el filo claro: `borde_pelo_sin_halo.png`;
  - manga: `manga_borde_linea.png`;
  - pintar al chico entre los dos personajes que se tocan: `marcar_con_el_dedo.png`;
  - raya sobre un personaje separado: `marcar_raya_separados.png`.
- **Tiempo extra del borde por línea**: 1 a 2 s en este PC de 2 núcleos para una imagen de 3 MP. Usa hasta 4 núcleos del teléfono.
- **Tiempo con marca y segunda mirada**: unos 5 s en este PC, contando la IA.

## 3. Marioneta más simple (captura 8)

- **Se quitó el mensaje de abajo** "Parte del dibujo sale del lienzo..."
  - Al Aplicar se sigue preguntando, como antes.
  - El aviso largo de "capa sin fondo transparente" ahora es una línea corta arriba.
  - También se quitaron "Malla: N puntos" y los textos largos de los puntos.
- **Malla tenue mientras no tocas**: se ve el dibujo y la pantalla queda simple.
- **Mientras mueves un punto, la malla se ve clara**, para ver cómo se estira.
- **Las líneas rojas de pliegue** salen solo mientras mueves, y más finas.

## 4. Pintar solo dentro del dibujo (capturas 9 a 11)

- **Al crear una capa** (Capas > Nueva) encima de un dibujo recortado, pregunta: **"¿Pintar solo dentro del dibujo?"**
  - **Solo dentro**: lo que pintes fuera del personaje no se ve ni se exporta.
  - **Libre**: como antes.
  - **"No volver a preguntar"** recuerda tu respuesta.
- **Para una capa que ya tienes** (como tu capa_1): toca la capa elegida > **Recorte**. Ya existía, pero estaba escondido.

## Archivos

- **Nuevos**:
  - `ai/AiSnap.java`: el borde por línea;
  - `ai/AiPick.java`: el personaje pintado.
- **Cambiados**:
  - `ai/AiMatte.java`: la marca del dedo, la segunda mirada y las etapas nuevas;
  - `AiCutFlow.java`: el flujo de pintar y las dos miradas;
  - `view/CanvasView.java`: la pintura celeste, la Marioneta simple y la transparencia de la capa;
  - `MainActivity.java`: el botón de la IA marcado y la pregunta al crear capa;
  - `app/build.gradle`: versión 8.36 (74).
- **Pruebas nuevas**: `tests/jvm833/P15Manchas.java`, `P16Marca.java` y `SnapCompare.java` (en `run_qa833.sh`).
- `.github` sin cambios.

## Lo que NO se probó (verdad)

- **No se probó en un teléfono**:
  - pintar con el dedo;
  - el botón azul;
  - el tiempo real;
  - la malla tenue;
  - la pregunta de la capa.
- **Compila** completo contra android.jar: 741 clases.
- **Las pruebas P11** (sesión de la IA) siguen 13 de 13 OK.
- **Dos personajes que se tocan**: si no pintas una parte grande, esa parte puede quedar afuera (Restaurar la devuelve).
- **Mismo color sin línea entre medio**: si el pelo blanco toca un fondo blanco sin línea, la IA decide sola, igual que antes.
- **No es 100 %**: con tramas muy finas o un JPEG muy malo, el borde queda como en la v8.35.
- **Faltan tus imágenes originales**: para probar con tus mismos dibujos de las capturas, mándalas completas (no capturas de pantalla).
