# Paint Zeta v8.37 — B/N en Borrar fondo (manual), sobre la v8.36

## Qué es

- **Botón nuevo "B/N"** en la barra de Borrar fondo, a la derecha del ojo. Viene **apagado**.
- **Primer toque: se prende.**
  - La pantalla se ve en blanco y negro.
  - El **Balde** y el **Pincel protegido** deciden qué es fondo mirando ese blanco y negro.
- **Lo que se borra se aplica a tu capa original, con sus colores.** El blanco y negro es solo para mirar.
- **Con B/N prendido, otro toque abre los ajustes.** Se ven al momento en el lienzo:
  - **Normal / Rojo / Verde / Azul**: qué color forma el gris. Elige el que más separe al personaje del fondo; por ejemplo, Azul suele borrar mejor un cielo.
  - **Saturación**: cuánto color queda (0 = blanco y negro puro).
  - **Contraste** y **Brillo**.
  - **Listo** guarda los ajustes. **De fábrica** los vuelve a cero.
  - **Volver a color** apaga B/N.
- Restaurar, Borrador, Escoba y Deshacer funcionan igual.
- **La IA no cambia**: sigue mirando en color. En las pruebas, que la IA mirara en blanco y negro mejoraba unas escenas, empeoraba otras y tardaba el doble.
  - Datos: `docs/qa837/IA_en_BN_no_se_uso.txt`.

## Pruebas en el PC (escenas propias con verdad conocida; no en un teléfono)

Se usó el mismo camino que la app: el Balde mira la copia gris y se aplica a la capa real. La prueba simula 6 toques en el fondo.

- **Tu color no cambia**: en las 5 escenas y los 5 modos hay **0 píxeles opacos con otro color**.
  - El filo del borde se limpia igual que siempre.
- **La pantalla y el Balde ven lo mismo**: diferencia máxima de 1 nivel en 20 000 colores al azar.
- **Acierto tras 6 toques, en color → mejor modo B/N**:
  - edificio: 55 % → 97 % (Azul), sin perder personaje;
  - dos personajes: 49 % → 84 % (Azul), sin perder personaje;
  - brillos: 45 % → 84 % (Azul), pero se comió unos 7000 píxeles del personaje;
  - barras: 46 % → 52 % (Rojo), sin perder personaje;
  - JPEG malo: 46 % → 61 % (Azul), pero se comió 185 píxeles del personaje.
- **En color** el Balde nunca tocó al personaje, pero borró menos fondo.
- **Conclusión: B/N es más rápido, pero a veces se come un pedacito.** Por eso viene apagado. Si pasa: Deshacer o Restaurar.
- **Qué modo conviene cambia según la imagen**: Azul fue mejor en estas escenas, que tienen cielo; en otras puede ser otro. Por eso están los botones.
- Datos: `docs/qa837/P17_BN_resultados.txt` y `Balde_color_vs_BN.txt`.

## Archivos

- **Nuevo**: `core/GrayView.java`, el blanco y negro ajustable (la misma matriz para la pantalla y para el análisis).
- **Cambiados**:
  - `core/BgEngine.java`: aplicar a la capa real con su copia y su color de fondo;
  - `view/CanvasView.java`: el B/N en el Balde, el Pincel protegido y la pantalla;
  - `MainActivity.java`: el botón B/N y sus ajustes;
  - `app/build.gradle`: versión 8.37 (75).
- **Pruebas**: `tests/jvm833/P17BN.java`, `BaldeGray.java` y `GrayTest.java`.
- `.github` sin cambios.

## No probado

- **No se probó en un teléfono**:
  - el botón;
  - la ventana de ajustes;
  - la vista gris en pantalla;
  - la velocidad.
- **Memoria**: B/N usa dos copias más de la capa mientras está prendido; se sueltan al salir de Borrar fondo. En una imagen de 3 MP son unos 24 MB.
- **Compila** completo contra android.jar: 749 clases.
