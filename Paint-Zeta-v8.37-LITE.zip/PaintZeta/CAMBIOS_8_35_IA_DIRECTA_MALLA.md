# Paint Zeta v8.35 — IA directa y malla visible (sobre la v8.34)

## 1. La IA ya no abre otra pantalla (captura 2)

- Tocas el boton de la IA, esperas el mismo aviso de progreso de siempre (captura 1, sin cambios) y **el fondo se quita directo en tu lienzo**, en la misma capa.
  - Sigues en Borrar fondo, con tus herramientas de siempre: Balde, Pincel protegido, Borrador y Restaurar.
  - No hay controles nuevos ni ventana "Aplicar".
- **Para devolver algo que la IA quito de mas:**
  - **Restaurar** (pincel): pinta encima y vuelve el original. Funciona desde el primer toque, porque la app guarda una copia de la capa antes de recortar.
  - **Deshacer** (arriba): quita todo el recorte de la IA de un toque.
- Si antes marcas el personaje con el **Lazo**, la IA mira solo ese recuadro, igual que antes.
- Ya no esta la opcion "en una capa nueva". Si quieres conservar el original, usa **Duplicar** en el panel de capas antes de tocar la IA.

## 2. Aviso mas simple (captura 3)

- Al terminar solo sale un aviso corto arriba, por unos 2 segundos: **"Fondo quitado · Restaurar o Deshacer lo devuelven"**.
- Si la IA no encuentra un personaje, o falta memoria, sale un solo mensaje con "Cerrar", como antes.

## 3. Marioneta: malla visible y mas fluida (captura 4)

- **Por que no se veia la malla:** la app leia un ajuste viejo guardado ("malla oculta") que tapaba el cambio de la v8.34.
  - Ahora se usa un ajuste nuevo que empieza en **malla visible**.
  - El boton del ojo la sigue ocultando o mostrando, y se recuerda.
- **Se ve mejor:** lineas cian finas con un borde oscuro suave. Se distinguen sobre colores claros y oscuros sin tapar el dibujo.
  - Vista simulada en el PC con tu recorte de 2 personajes: `docs/qa835/marioneta_malla.png`.
- **Mas fluido al arrastrar:** la vista previa mientras mueves usa menos resolucion. Al soltar se pinta con la calidad completa, igual que antes.
  - Medido en este PC (1048 puntos de malla):
    - vista previa por cuadro: 16 ms (v8.34) → 10 ms;
    - mover un punto: 1,4 ms;
    - la malla sigue tu dedo al instante.

## Archivos cambiados

- `AiCutFlow.java`: al terminar la IA, aplica directo en la capa. No abre el editor.
- `view/CanvasView.java`: copia para Restaurar antes del recorte; aviso corto; malla mas visible y fina; vista previa de arrastre mas liviana.
- `MainActivity.java`: ajuste nuevo de "ver malla", visible de fabrica.
- `app/build.gradle`: version 8.35 (73).
- `.github` sin cambios.

## Pruebas (PC, no telefono)

- **Compila** la app entera contra android.jar: 728 clases.
- **Marioneta**: rendimiento medido en el PC (cifras de arriba) y dibujo de la malla simulado con los mismos colores y grosores.
- **El recorte que se aplica** es el mismo de la v8.34 (misma IA y mismos ajustes de fabrica); solo cambia que va directo a la capa.
- **No se probo en un telefono**: el gesto real, el aviso en pantalla y Restaurar despues de la IA quedan por probar en el tuyo.
