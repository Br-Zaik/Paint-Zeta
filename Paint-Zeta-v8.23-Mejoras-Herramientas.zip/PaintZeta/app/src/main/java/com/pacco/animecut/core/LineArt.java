package com.pacco.animecut.core;

/**
 * Convierte las lineas oscuras del dibujo en una barrera para el relleno.
 * Es lo que hace que la varita magica funcione bien en manga blanco y negro:
 * el relleno se para en la linea en vez de escaparse por toda la pagina.
 */
public final class LineArt {

    private LineArt() {
    }

    /**
     * @param threshold luminancia por debajo de la cual el pixel es "linea" (0..255)
     * @param closeGap  cuantos pixeles engordar la linea para cerrar huecos
     */
    public static byte[] build(int[] px, int w, int h, int threshold, int closeGap) {
        byte[] b = new byte[w * h];
        for (int i = 0; i < b.length; i++) {
            int c = px[i];
            int r = (c >> 16) & 0xFF;
            int g = (c >> 8) & 0xFF;
            int bl = c & 0xFF;
            int lum = (r * 77 + g * 151 + bl * 28) >> 8;
            b[i] = (byte) (lum < threshold ? 255 : 0);
        }
        if (closeGap > 0) MaskOps.dilate(b, w, h, closeGap);
        return b;
    }

    /** Alfa (0..1) por debajo del cual se considera papel (ruido de escaneo/JPEG). */
    public static final float PAPER = .06f;

    /**
     * v8.23 Extraer lineas: el dibujo sobre papel blanco pasa a lineas sobre
     * TRANSPARENTE ("color a alfa" contra el blanco). El papel queda transparente,
     * el negro opaco, el gris del antialias semitransparente y una linea de color
     * conserva su color. Sobre blanco se ve igual que el original. Sin IA.
     * @return pixeles nuevos (mismo tamano)
     */
    public static int[] extract(int[] src) {
        int[] out = new int[src.length];
        for (int i = 0; i < src.length; i++) out[i] = extractPixel(src[i]);
        return out;
    }

    public static int extractPixel(int c) {
        int sa = c >>> 24;
        if (sa == 0) return 0;
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        // alfa minimo que explica el color sobre papel blanco
        float a = (255 - Math.min(r, Math.min(g, b))) / 255f;
        if (a <= PAPER) return 0;
        // color real de la linea: F = 255 - (255 - C) / a
        int fr = clamp(255f - (255 - r) / a), fg = clamp(255f - (255 - g) / a), fb = clamp(255f - (255 - b) / a);
        // quitar el ruido del papel: solo los grises mas palidos (a < 2*PAPER) se
        // atenuan en rampa; el resto del antialias queda exacto.
        float na = a >= 2f * PAPER ? a : (a - PAPER) * 2f;
        int al = Math.round(na * sa);
        if (al <= 0) return 0;
        return (al << 24) | (fr << 16) | (fg << 8) | fb;
    }

    private static int clamp(float v) { return v < 0 ? 0 : v > 255 ? 255 : (int) (v + .5f); }
}
