package com.pacco.animecut.core;

import android.graphics.Rect;

/**
 * Relleno de dibujos con lineas (manga/anime) sin taparlas (v8.23).
 *
 * 1. "Hasta el pixel mas oscuro": desde el borde de la zona rellenada se avanza
 *    hacia la linea solo mientras la imagen se oscurece, y se para en el centro
 *    de la linea. Asi desaparece la franja blanca del antialias sin pasar al
 *    otro lado de la linea (como "Hasta el pixel mas oscuro" de Clip Studio).
 * 2. Sombreado relativo: cada pixel recibe el color multiplicado por su
 *    luminosidad respecto del punto tocado. El papel blanco queda del color
 *    elegido; el gris del antialias y el negro de la linea quedan oscuros. La
 *    linea se conserva aunque el color se pinte en la MISMA capa.
 *
 * No promete proteger lineas que tienen el mismo tono que el relleno: la
 * proteccion se basa en que la linea sea mas oscura que la zona.
 */
public final class LineFill {
    private LineFill() { }

    /** Valor de mascara usado para la franja "hasta la linea". */
    public static final int BAND = 252;

    /** Luminosidad 0..255; lo transparente cuenta como papel blanco. */
    public static int lum(int c) {
        if ((c >>> 24) < 128) return 255;
        return (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
    }

    /**
     * Agranda la mascara hacia la linea mientras la luminosidad no aumente.
     * @param mask    0 = fuera; &gt;= 128 = rellenado
     * @param r       zona a revisar (se amplia con lo que se agrega)
     * @param maxStep pixeles maximos que se avanza (grosor de media linea)
     * @return pixeles agregados
     */
    public static int darkestBand(int[] ref, int w, int h, byte[] mask, Rect r, int maxStep) {
        int x0 = Math.max(0, r.left - maxStep - 1), y0 = Math.max(0, r.top - maxStep - 1);
        int x1 = Math.min(w, r.right + maxStep + 1), y1 = Math.min(h, r.bottom + maxStep + 1);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw <= 0 || rh <= 0) return 0;
        // Frente inicial: pixeles rellenados con algun vecino sin rellenar.
        int[] front = new int[256], next = new int[256];
        int fn = 0;
        for (int y = Math.max(y0, r.top); y < Math.min(y1, r.bottom); y++) {
            for (int x = Math.max(x0, r.left); x < Math.min(x1, r.right); x++) {
                int i = y * w + x;
                if ((mask[i] & 0xFF) < 128) continue;
                if ((x > 0 && (mask[i - 1] & 0xFF) < 128) || (x < w - 1 && (mask[i + 1] & 0xFF) < 128)
                        || (y > 0 && (mask[i - w] & 0xFF) < 128) || (y < h - 1 && (mask[i + w] & 0xFF) < 128)) {
                    if (fn == front.length) front = java.util.Arrays.copyOf(front, fn * 2);
                    front[fn++] = i;
                }
            }
        }
        int added = 0;
        int minX = r.left, minY = r.top, maxX = r.right, maxY = r.bottom;
        for (int step = 0; step < maxStep && fn > 0; step++) {
            int nn = 0;
            for (int f = 0; f < fn; f++) {
                int i = front[f];
                int li = lum(ref[i]);
                int y = i / w, x = i - y * w;
                for (int k = 0; k < 4; k++) {
                    int qx = x + (k == 0 ? -1 : k == 1 ? 1 : 0), qy = y + (k == 2 ? -1 : k == 3 ? 1 : 0);
                    if (qx < x0 || qy < y0 || qx >= x1 || qy >= y1) continue;
                    int q = qy * w + qx;
                    if ((mask[q] & 0xFF) != 0) continue;
                    int lq = lum(ref[q]);
                    // Solo hacia lo mas oscuro (con 3 niveles de margen por ruido).
                    if (lq > li + 3) continue;
                    mask[q] = (byte) BAND;
                    added++;
                    if (qx < minX) minX = qx;
                    if (qy < minY) minY = qy;
                    if (qx + 1 > maxX) maxX = qx + 1;
                    if (qy + 1 > maxY) maxY = qy + 1;
                    if (nn == next.length) next = java.util.Arrays.copyOf(next, nn * 2);
                    next[nn++] = q;
                }
            }
            int[] t = front; front = next; next = t;
            fn = nn;
        }
        r.set(minX, minY, maxX, maxY);
        return added;
    }

    /**
     * Color con el sombreado del dibujo: color * min(1, lum(pixel) / lum(semilla)).
     * Conserva el alfa del color.
     */
    public static int shade(int color, int pixel, int seedLum) {
        int lp = lum(pixel);
        if (lp >= seedLum || seedLum <= 0) return color;
        float f = lp / (float) seedLum;
        int r = (int) (((color >> 16) & 0xFF) * f + .5f);
        int g = (int) (((color >> 8) & 0xFF) * f + .5f);
        int b = (int) ((color & 0xFF) * f + .5f);
        return (color & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}
